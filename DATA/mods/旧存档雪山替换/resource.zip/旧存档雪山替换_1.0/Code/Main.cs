using System;
using UnityEngine;
using HarmonyLib;
using NCMS;

namespace 旧存档雪山替换
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
          Harmony.CreateAndPatchAll(typeof(Main));
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(SaveManager), "loadData")]
	      public static void loadData(SavedMap pData)
	      {
		      SmoothLoader.add(delegate
		      {
            if (pData.saveVersion < 14)
            {
		          WorldTile[] array = World.world.tiles_list;
		          for (int i = 0; i < array.Length; i++)
		          {
                WorldTile tile = array[i];
                if (tile.Type.IsType("snow_block"))
                {
                  tile.setTileTypes(TileLibrary.summit, null, true);
                }
		          }
            }
		      }, "替换雪山中", false, 0.001f);
		    }
    }
}