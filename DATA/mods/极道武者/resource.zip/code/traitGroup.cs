﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset Warrior = new ActorTraitGroupAsset();
            Warrior.id = "Warrior";
            Warrior.name = "trait_group_Warrior";
            Warrior.color = "#FFFF00";
            AssetManager.trait_groups.add(Warrior);

            ActorTraitGroupAsset MartialFoundations = new ActorTraitGroupAsset();
            MartialFoundations.id = "MartialFoundations";
            MartialFoundations.name = "trait_group_MartialFoundations";
            MartialFoundations.color = "#00FF00";
            AssetManager.trait_groups.add(MartialFoundations);

            ActorTraitGroupAsset arcaneTome = new ActorTraitGroupAsset();
            arcaneTome.id = "arcaneTome";
            arcaneTome.name = "trait_group_arcaneTome";
            arcaneTome.color = "#FF00FF";
            AssetManager.trait_groups.add(arcaneTome);

            ActorTraitGroupAsset NineCharacterSecrets = new ActorTraitGroupAsset();
            NineCharacterSecrets.id = "NineCharacterSecrets";
            NineCharacterSecrets.name = "trait_group_NineCharacterSecrets";
            NineCharacterSecrets.color = "#FFA500";
            AssetManager.trait_groups.add(NineCharacterSecrets);
        }
    }
}