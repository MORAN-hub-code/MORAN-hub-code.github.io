﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NeoModLoader;
using NeoModLoader.api;
using NeoModLoader.api.attributes;

namespace PeerlessOverpoweringWarrior.code.Config
{
    internal static class WarriorConfig
    {
        public static bool AutoCollectHarmony = true;  // 合道境收藏开关
        public static bool AutoCollectZhanWo = true;  // 斩我境收藏开关
        public static bool AutoCollectWuJi = true;     // 武极境收藏开关
        // 武极境限制开关（默认关闭）
        public static bool LimitWuJi = false;
        // 斩我境限制开关（默认关闭）
        public static bool LimitZhanWo = false;
        // 合道境限制开关（默认关闭）       
        public static bool BreakthroughLimit = false;
        public static bool LimitWarrior9 = false;
        public static bool LimitWarrior8 = false;
        public static bool LimitWarrior7 = false;
        public static bool LimitWarrior6 = false;
        public static bool LimitWarrior5 = false;
        public static bool LimitWarrior4 = false;
        public static bool LimitWarrior3 = false;
        public static bool LimitWarrior2 = false;
        // 武极境限制回调
        public static void LimitWuJiCallBack(bool newValue)
        {
            LimitWuJi = newValue;
        } 
        // 斩我境限制回调
        public static void LimitZhanWoCallBack(bool newValue)
        {
            LimitZhanWo = newValue;
        }
        // 合道境限制回调    
        public static void BreakthroughLimitCallBack(bool newValue)
        {
            BreakthroughLimit = newValue;
        }
        // 新增回调方法
        public static void LimitWarrior9CallBack(bool newValue)
        {
            LimitWarrior9 = newValue;
        }
        
        public static void LimitWarrior8CallBack(bool newValue)
        {
            LimitWarrior8 = newValue;
        }
        
        public static void LimitWarrior7CallBack(bool newValue)
        {
            LimitWarrior7 = newValue;
        }
        
        public static void LimitWarrior6CallBack(bool newValue)
        {
            LimitWarrior6 = newValue;
        }
        
        public static void LimitWarrior5CallBack(bool newValue)
        {
            LimitWarrior5 = newValue;
        }
        
        public static void LimitWarrior4CallBack(bool newValue)
        {
            LimitWarrior4 = newValue;
        }
        
        public static void LimitWarrior3CallBack(bool newValue)
        {
            LimitWarrior3 = newValue;
        }
        
        public static void LimitWarrior2CallBack(bool newValue)
        {
            LimitWarrior2 = newValue;
        } 
        // 合道境回调
        public static void AutoCollectHarmonyCallBack(bool newValue)
        {
            AutoCollectHarmony = newValue;
        }
        // 斩我境回调
        public static void AutoCollectZhanWoCallBack(bool newValue)
        {
            AutoCollectZhanWo = newValue;
        }
        
        // 武极境回调
        public static void AutoCollectWuJiCallBack(bool newValue)
        {
            AutoCollectWuJi = newValue;
        }
    }
}