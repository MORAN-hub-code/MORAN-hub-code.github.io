﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitAction
    {
        public static bool IsWarrior1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"Warrior{i}") || a.hasTrait($"Warrior{i}+"))
                {
                    return true;
                }
            }
            return false;
        }
        private static readonly Dictionary<string, string> _warriorSuffixMap = new Dictionary<string, string>
{
    {"Warrior1", "锻体"},
    {"Warrior2", "炼骨"},
    {"Warrior3", "通脉"},
    {"Warrior4", "气海"},
    {"Warrior5", "化劲"},
    {"Warrior6", "凝罡"},
    {"Warrior7", "洞虚"},
    {"Warrior8", "劫身"},
    {"Warrior9", "武域"},
    {"Warrior91", "合道"},
    {"Warrior92", "斩我"},
    {"Warrior93", "武极"}
};
// 尊号字典（洞虚境、合道境、武极境）
private static readonly Dictionary<string, string[]> _warriorTitlesMap = new Dictionary<string, string[]>
{
    // 洞虚境尊号
    {"Warrior7", new string[] {
        "断贪刀", "斩妄剑", "破嗔掌", "碎痴爪", "焚傲炎","丹霞孟尝", "寒江钓叟", "过山峰", "听涛叟", "追星", "落霞剑客", "判官", "分水刺", "白额虎", "金翅雕", "赤练蛇",
        "铁掌分江", "青城鬼脸", "碧磷毒手", "寒江独钓", "断碑书生", "铁掌震北", "无痕神偷", "白莲圣使", "不动明王", "风雪狂刀", "镇岳神枪", "血手人屠", "千面神捕", "九尾狐", "赤练蛇", "穿山鼠", "笑面虎", "千面客", "睡罗汉", "妙手回春", "漠北苍狼",
        "雁门孤狼", "沧浪铁佛", "金顶飞鹰", "玉笔判官", "千仞毒叟", "泣血南山", "青铜罗汉", "赤风", "雨水真人", "移山力士" , "通臂猿", "画皮师", "胖米勒", "瞎判官", "布衣神相", "铁面无私", "流火将", "华盖君", "云中游",
        "银蛇郎君", "玄冰老怪", "黑木无常", "五岳摧心", "铁锁横江", "棋魔子", "画圣笔仙" , "铁幕游侠", "天机神算" , "铁笔书生", "炽火剑", "寒山长枪" , "慈悲先生", "大漠孤狼", "泣竹郎", "照夜白" , "鱼肠客", "焦尾生" , "焚琴子", "桑落翁", "醉扶疏" , "金错刀", "斩楼兰",
        "紫霄雷手", "无鞘刀", "三更死", "血鹦鹉", "断肠客栈", "辨忠奸", "解千愁", "乘黄", "穷奇" , "乱黑白", "奔日月", "陵鱼姬", "泣珠引", "采薇翁", "击筑客", "知风凉",
        "纸刀", "幽灵箭", "血玲珑", "断弦琴", "黑雪", " 烂柯子", "弈春秋", "请缨使", "砺肝胆", "漱石生", "然藜客", "秦淮影", "破胡尘", "蓟北枪", "灞陵尉", "半梦半醒",
        "残红泣", "孤灯灭", "空棺客", "寒鸦", "碎梦无痕", "大漠飞沙", "碎骨温柔", "空舟载月", "瘦马驮经", "破钵盛雪", "残灯照影", "断碑刻偈", "惊魂幡", "绝命签", "碎心铃", "裂魂爪", "蚀日幡", 
        "白骨画眉", "冷血追魂", "勾魂引", "醉生梦死", "毒菩萨", "吹角将", "扎草人", "烧丹客", "炼龙虎", "相面客", "镇天元", "走龙蛇", "解牛功", "雕龙手", "挽千帆",
        "血月孤楼", "哭丧人", "大泼血", "黑水车", "冷血残阳", "紫电青霜", "银鞍照雪", "碧落黄泉", "玄冰烈火", "瀚海孤帆", "幸运小猪", "早说先生", "北极星霜", 
        "销魂伞", "无鞘剑", "伤心箭", "白骨哀", "血河车", "大魔", "鬼面", "大力掌", "江城开碑手", "黑大虫", "霹雳火", "云中金刚", "追风客", "春予心", "玄门教主",
        "朝天棍", "碎魂锣", "断肠镖", "噬魂刺", "丧门鼓","垂天剑", "血河剑奴", "生死人屠" , "金乌剑", "圣火王", "沧海王", "清圣医", "万雷手", "九阴灼日", "四象伏魔棍", "翻海龙", "青莲剑", 
        "葬妒绫", "化怨笛", "空欲索", "绝惑瞳", "净疑钟","玉面修罗", "白居士", "篆烟客", "五弦使", "弄宫商", "白泽生", "晓百鬼", "饕餮客", "吞山河", "驺虞刃", "毕方使", "鲲鹏客", "渡沧溟", 
        "撕名帖", "裂冠客", "焚绶者", "碎印人", "折笏手","冰魄寒光", "云台飞絮", "玉箫惊鸿", "幽谷鸣泉", "空山鹤唳", "噬魂长枪", "腐心太岁", "血魔刀客", "铁面人屠", 
        "葬玉匠",  "覆棋生", "裂卷生", "碎镜客", "断弦翁","夜修罗", "催命阎王", "萍踪浪医", "霓裳毒仙", "冰川剑魄", "星海飞槎", "玉弓魅影",
        "孤峰守夜", "寒潭涤剑", "枯冢悟掌", "残阳淬指", "断崖听刀", "快意恩仇", "鬼手佛心", "惊梦钟", "三台客", "雪原葬枪", "沙海焚弓", "雷池拭戟", "瘴林磨爪", "冰谷炼瞳", "孤星葬剑", "还剑公子","麒麟", "烛龙", 
        "十载面壁", "千日负石", "万里量沙", "百川饮马", "孤星伴鹤", "阴煞炼魂君", "夜行舟", "计都踪", "踏月来", "青棠客", "谢春池", "折柳生", "灞桥别",
        "折梅问禅", "扫叶观道", "斫竹见性", "汲泉明心", "拾薪悟真", "劫数刻舟翁", "铁马冰河", "青锋葬雪", "萍踪侠影", "温柔错", "逆水寒","昆仑柱", "须弥圣僧", "毒蛇王", "巨熊王", 
        "裂帛见血", "碎玉闻声", "焚香知寂", "葬花觉空", "覆水证灭", "醉生笑", "孤鸿影", "枯荷听雨", "笑饮霜", "流萤葬火"
    }},
  
    // 武域境尊号
    {"Warrior9", new string[] {
        "裂江断岳宗师", "穿云贯日宗师", "翻江倒海宗师", "分水劈浪宗师", "裂石崩山宗师", "琴心剑胆宗师", "竹影棋风宗师", "松涛鹤唳宗师", "梅雪诗魂宗师", "云影钟声宗师",
        "罡风扫月宗师", "惊雷裂地宗师", "皓月宗师", "苍日横空宗师", "孤星照野宗师", "烟霞醉客宗师", "星月流辉宗师", "山水清音宗师", "乱神宗师", "三秋宗师",
        "观瀑听涛宗师", "踏雪无痕宗师", "凌云步虚宗师", "定海镇波宗师", "镇岳定山宗师", "金石铿锵宗师", "丝竹雅韵宗师", "不动如山宗师", "论道宗师", "书剑飘零宗师",
        "翻江搅浪宗师", "覆海吞江宗师", "擎山托岳宗师", "裂空穿云宗师", "疾风追电宗师", "诗酒风流宗师", "乾坤宗师", "茶禅宗师", "酒仙诗圣宗师", "剑胆琴心宗师",
        "暴雨宗师", "寒霜宗师", "烈火燎原宗师", "落雷破阵宗师", "苍松宗师", "松风竹节宗师", "梅骨兰魂宗师", "莲影荷香宗师", "云帆月楫宗师", "烟蓑雨笠宗师",
        "翠柏凝霜宗师", "古槐盘根宗师", "绿竹穿云宗师", "红梅傲雪宗师", "破晓宗师", "星斗宗师", "魔天宗师", "无间宗师", "丹青宗师", "金石宗师",
        "惊山宗师", "残灯照夜宗师", "晓月残星宗师", "寒星坠野宗师", "惊鸿宗师", "丝桐遗韵宗师", "竹帛烟霞宗师", "琴书雅趣宗师", "棋酒清欢宗师", "诗画通神宗师",
        "游龙临川宗师", "猛虎断岳宗师", "飞龙穿海宗师", "潜蛟出海宗师", "擎天立地宗师", "书画同源宗师", "茶酒论交宗师", "琴剑飘零宗师", "诗酒逍遥宗师", "破风宗师",
        "立地生根宗师", "横江锁浪宗师", "越海翻山宗师", "跨海登舟宗师", "掠影宗师", "茶烟琴韵宗师", "酒旗风暖宗师", "剑影刀光宗师", "诗心剑气宗师", "松月山房宗师",
        "裂石分金宗师", "崩山宗师", "断江截流宗师", "破空裂云宗师", "流云舒卷宗师", "梅雪宗师", "竹雨松风宗师", "茶烟梧月宗师", "箫心合抱宗师", "剑胆双清宗师",
        "飞絮宗师", "飘雪漫空宗师", "落英宗师", "疾风宗师", "玄冰宗师", "松风水月宗师", "烟霞天然宗师", "如云宗师", "琴骨剑心宗师", "同春宗师",
        "赤焰焚天宗师", "青木参天宗师", "黑金裂石宗师", "白水滔天宗师", "孤峰独峙宗师", "竹兰共雅宗师", "菊梅同香宗师", "云客宗师", "星槎月楫宗师", "山灵水韵宗师",
        "藏龙宗师", "大漠烈阳宗师", "瀚海惊涛宗师", "旭日宗师", "松风静听宗师", "剑舞霜华宗师", "红叶闲吟宗师", "青山宗师", "茶烹白雪宗师", "剑倚崆峒宗师",
        "孤月悬空宗师", "寒星宗师", "朗日高悬宗师", "疏星朗月宗师", "酒饮黄花宗师", "棋敲竹露宗师", "书枕松云宗师", "剑横秋水宗师", "琴弹夜月宗师",
        "裂金断铁宗师", "断铁分金宗师", "破玉裂琼宗师", "碎琼乱玉宗师", "迎风逆浪宗师", "诗赋春风宗师", "画染秋云宗师", "茶烹碧涧宗师", "兴逸宗师", "势雄宗师",
        "逆浪行舟宗师", "顶雪踏霜宗师", "冒雨披蓑宗师", "踏霜破冰宗师", "静心守一宗师", "书临青史宗师", "剑倚苍岩宗师", "流泉韵雅宗师", "落照神闲宗师", "烟霞兴畅宗师",
        "剑鸣宗师", "会元宗师", "守意如钢宗师", "存真抱朴宗师", "明心见性宗师", "不迷宗师", "棋斗机锋宗师", "书观今古宗师", "剑荡尘氛宗师","星辰象伟宗师",
        "见性成佛宗师", "悟道参玄宗师", "证理修真宗师", "归真返璞宗师", "撼山动地宗师", "韵正宗师", "画山摹水宗师", "龙胆宗师", "寒冽明镜宗师","云霞色艳宗师",
        "震岳摇川宗师", "动川惊海宗师", "摇海翻江宗师", "惊涛宗师", "穿云破雾宗师", "兵戈势险宗师", "书藏今古宗师", "剑扫妖氛宗师", "琴雅神怡宗师", "诗彩情豪宗师",
        "贯日凌云宗师", "追星逐月宗师", "逐月追星宗师", "揽星摘月宗师", "劈风斩浪宗师", "画染烟岚宗师", "酒泛味醇宗师", "心平宗师", "春秋志远宗师", "潇湘韵远宗师", 
        "斩浪截江宗师", "截江断流宗师", "断河裂岸宗师", "裂涛排浪宗师", "乘风破浪宗师", "剑舞气壮宗师", "格妙宗师", "玉雨玄露宗师",
        "狱罡武王", "战魄武王", "焚劫武王", "镇虚武王", "碎魂武王", "战宇武王", "炼狱武王", "狱灭武王", "罡破武王", "墟陨武王", "陨道武王", "寂灭武王", "劫宇武王", "战虚武王", "焚道武王",
        "镇劫武王", "戮罡武王", "碎战武王", "炼墟武王", "狱神武王", "罡陨武王", "武焚武王", "墟战武王", "战劫武王", "破神武王", "破穹刀王", "焚劫剑王", "镇狱枪王", "碎星拳王", "陨神戟王",
        "戮虚弓王", "战罡锤王", "劫灭刀王", "焚宇剑王", "罡煞枪王", "炼狱戟王", "寂灭弓王", "陨道拳王", "战魄锤王", "焚劫刀王", "碎魂剑王", "墟战枪王", "罡陨戟王", "劫战弓王", "炼神拳王",
        "镇虚锤王", "血魄刀王", "狱罡剑王", "战焚枪王", "破劫戟王", "寂罡弓王", "陨战拳王", "戮道锤王", "罡灭刀王", "劫宇剑王", "炼狱枪王", "战罡戟王", "焚虚弓王", "碎道拳王", "陨劫锤王",
        "罡戮刀王", "劫战剑王", "炼神枪王", "镇狱戟王", "寂灭弓王", "战罡宗师", "焚劫宗师", "陨灭宗师", "破狱宗师", "戮虚宗师", "镇道宗师", "碎宇宗师", "炼神宗师", "寂天宗师", "罡煞宗师",
        "武炼宗师", "墟战宗师", "血魄宗师", "焚轮宗师", "陨神宗师", "狱罡宗师", "战魄宗师", "焚劫宗师", "镇虚宗师", "碎魂宗师", "流云武王", "听风武王", "观山武王", "揽月武王", "镇海武王",
        "栖霞武王", "枕流武王", "漱石武王", "倚松武王", "踏雪武王", "逐日武王", "摘星武王", "惊鸿武王", "游龙武王", "伏虎武王", "鹤唳武王", "猿啼武王", "虎踞武王", "龙蟠武王", "凤栖武王",
        "松涛武王", "竹影武王", "梅骨武王", "莲心武王", "蝉鸣武王", "鹰扬武王", "鹏飞武王", "鲸吞武王", "雷音武王", "电曜武王", "八极宗师", "太极宗师", "形意宗师", "八卦宗师", "通背宗师",
        "劈挂宗师", "螳螂宗师", "鹰爪宗师", "谭腿宗师", "洪拳宗师", "咏春宗师", "六合宗师", "燕青宗师", "查拳宗师", "弹腿宗师", "翻山宗师", "地趟宗师", "红拳宗师", "华拳宗师", "蔡李佛宗师",
        "太极剑王", "流云枪王", "听风刀王", "惊雷戟王", "逐电弓王", "分水棍王", "断岳斧王", "碎星锤王", "揽月钩王", "追魂鞭王", "真我武王", "斩妄战王", "焚血霸侯", "罡魄武王", "劫灭战王", 
        "炼狱霸侯", "战魂武王", "血戮战王", "寂灭霸侯", "破劫武王", "陨神战王", "戮心霸侯", "罡煞武王", "焚我战王", "战魄霸侯", "劫真武王", "炼神战王", "血战霸侯", "寂罡武王", "破妄战王", 
        "陨魄霸侯", "戮虚武王", "罡焚战王", "焚魄霸侯", "战劫武王", "劫战战王", "炼罡霸侯", "血戮武王", "寂墟战王", "破道霸侯", "陨战武王", "戮罡霸侯", "罡陨战王", "焚劫武王", "战灭霸侯",
        "劫魄战王", "炼狱武王", "血焚霸侯", "寂劫战王", "破神武王", "陨罡霸侯", "戮战武王", "罡破战王", "焚战霸侯", "战墟武王", "劫罡霸侯", "炼劫战王", "血陨武王", "寂战霸侯", "破罡战王"
    }},

    // 合道境尊号
    {"Warrior91", new string[] {
        "凌云剑尊", "天道执秤尊者", "鸿蒙演法尊者", "太初问玄君", "法则刻篆使", "玉阙听雷尊者", "金庭炼魄大宗师", "瑶台裁云尊", "璇宫执律尊者", "紫府演法大宗师", "丹霄御气尊", "星汉垂地大宗师", "乾坤清气大宗师", "江河行地大宗师",
        "星河炼魄尊", "轮回磨剑尊者", "星河踏浪尊者", "太虚磨剑大宗师", "碧落斩虹尊", "黄泉渡月尊者", "须弥刻篆大宗师", "吞山摘月尊者", "驺虞碾月大宗师", "毕方蒸霞尊", "渡沧溟月大宗师", "法则镂金大宗师", "乾坤刻雪尊",
        "黄庭大宗师", "南华尊者", "干将剑尊", "刑天战尊" , "精卫刀尊", "天照大宗师", "四极天柱尊者", "乾坤镇北尊者", "铁马踏霜尊者", "青锋削月大宗师", "萍踪踩霞尊", "温柔碾雪尊者", "逆水搓冰大宗师", "昆仑磨月尊", "翠竹凌云大宗师",
        "玉壶承露尊者", "金盏倾霞大宗师", "瑶卮盛月尊", "璇奁藏星尊者", "紫匣封云大宗师", "丹炉煅魂尊", "玄门尊者", "十月环天尊者", "黑天大尊", "星曜大宗师", "千秋看客", "青山盘羊尊者", "星空尊者", "逆反先天大宗师", "太虚织霞尊者",
        "太初炼魂使", "乾坤执子尊", "星望大宗师", "玉衡转斗尊者", "金乌衔日大宗师", "玄武镇渊尊者", "青龙擘海大宗师", "白虎啸岳尊","玉衡转斗尊者", "金乌衔日大宗师", "玄武镇渊尊者", "青龙擘海大宗师", "白虎啸岳尊", "翠柏参天大宗师",
        "毒龙尊者", "寒铁龙骑尊者", "碧落剑圣", "朱雀焚虚尊者", "八卦锁云大宗师", "四象炼罡尊者", "五行凝珠大宗师", "七星贯日尊", "玉杖敲云尊者", "金藜照夜大宗师", "瑶笏指辰尊", "璇圭测斗尊者", "紫璋量天大宗师", "丹璧绘辰尊",
        "黄泉尊者", "盘龙大尊", "玄冰炼魂尊者", "赤焰合道大宗师", "苍梧栖鹤尊", "青冥御龙尊者", "丹丘种玉大宗师", "瑶海尊者", "玉斧开天尊者", "金锤锻地大宗师", "瑶凿穿岳尊", "璇锯截江尊者", "紫袍削月大宗师", "丹凿刻星尊", "月涌大江大宗师",
        "五行尊者", "斩龙弈棋客", "春秋刻篆主", "两仪炼魄尊者", "四象磨剑大宗师", "八卦演法尊", "玉笛横秋尊者", "金弦裂帛大宗师", "瑶琴啸风尊", "璇簫唤月尊者", "紫笙吹露大宗师", "丹瑟鸣霜尊", "苍梧揽月尊者", "青冥御龙大宗师", "星河碾玉尊",
        "太岁尊者", "勾魂尊者", "玉辇巡天尊者", "金鞍踏月大宗师", "瑶辔牵星尊", "璇舆渡汉尊者", "紫缰挽日大宗师", "丹毂碾云尊","天风浪浪大宗师", "海山苍苍大宗师", "河岳英灵大宗师", "日月经天大宗师", "大漠孤烟大宗师", "长河落日大宗师",
        "泰阶平秩大宗师", "云雷经纶大宗师", "风霆行健大宗师", "雨露膏泽大宗师", "苍溟吐曜大宗师", "赤县腾龙大宗师", "神州卧虎大宗师", "九域同风大宗师", "剑扫八荒大宗师", "拳镇四溟大宗师", "掌擎日月大宗师", "指裂苍穹大宗师", "星垂平野大宗师",
        "九天揽月大宗师", "四海屠龙大宗师", "气贯长虹大宗师", "势吞寰宇大宗师", "功昭日月大宗师", "松风万古大宗师", "梅月千秋大宗师", "风云际会大宗师", "龙虎风云大宗师", "鹏举九天大宗师", "凤翔千仞大宗师", "龙腾四海大宗师", "红梅傲雪大宗师",
        "鲸吞沧海大宗师", "鳌戴三山大宗师", "星罗棋布大宗师", "云蒸霞蔚大宗师", "浩然正气大宗师", "至大至刚大宗师", "中庸至德大宗师", "中和至道大宗师", "与天地参大宗师", "并日月明大宗师", "垂宪万世大宗师", "立极千秋大宗师", "青松拔地大宗师",
        "玉阙栖鸾尊者", "金庭驻鹤大宗师", "瑶台驯鹿尊", "璇宫饲凤尊者", "紫府育麟大宗师", "丹霄乘龙尊", "玉阶步月尊者", "金殿踏云大宗师", "瑶墀踩霞尊", "璇廊巡斗尊者", "紫庭观辰大宗师", "丹墀望日尊",
        "战罡尊者", "劫焚尊者", "陨灭尊者", "破狱尊者", "焚宇尊者", "戮劫尊者", "镇虚尊者", "碎星尊者", "炼神尊者", "寂天尊者", "罡煞尊者", "武炼尊者", "墟战尊者", "血魄尊者", "焚轮尊者",
        "陨神尊者", "狱罡尊者", "战魄尊者", "焚劫尊者", "镇道尊者", "碎魂尊者", "战宇尊者", "炼狱尊者", "狱灭尊者", "罡破尊者", "墟陨尊者", "陨道尊者", "寂灭尊者", "劫宇尊者", "战虚尊者",
        "焚道尊者", "镇劫尊者", "戮罡尊者", "碎战尊者", "炼墟尊者", "狱神尊者", "罡陨尊者", "武焚尊者", "墟战尊者", "战劫尊者", "破神尊者", "寂罡尊者", "陨战尊者", "焚狱尊者", "镇虚尊者",
        "戮墟尊者", "劫道尊者", "炼灭尊者", "罡焚尊者", "战陨尊者", "碎劫尊者", "狱宇尊者", "武破尊者", "墟罡尊者", "焚战尊者", "寂道尊者", "陨狱尊者", "镇戮尊者", "劫战尊者", "炼罡尊者",
        "狱墟尊者", "碎焚尊者", "战灭尊者", "罡道尊者", "破墟尊者", "寂战尊者", "陨焚尊者", "劫灭尊者", "武罡尊者", "墟宇尊者", "焚陨尊者", "镇战尊者", "戮灭尊者", "炼劫尊者", "狱道尊者",
        "破穹刀尊", "焚劫剑尊", "镇狱枪尊", "碎星拳尊", "陨神戟尊", "戮虚弓尊", "战罡刀尊", "劫灭剑尊", "焚宇枪尊", "罡煞拳尊", "炼狱戟尊", "寂灭弓尊", "陨道刀尊", "战魄剑尊", "焚劫枪尊",
        "碎魂拳尊", "墟战戟尊", "罡陨弓尊", "劫战刀尊", "炼神剑尊", "镇虚枪尊", "血魄拳尊", "狱罡戟尊", "战焚弓尊", "破劫刀尊", "寂罡剑尊", "陨战枪尊", "戮道拳尊", "罡灭戟尊", "劫宇剑尊",
        "阴阳尊者", "两仪尊者", "四象尊者", "八卦尊者", "周天尊者", "混元尊者", "玄黄尊者", "太虚尊者", "鸿蒙尊者", "无极尊者", "太极尊者", "星穹尊者", "寰宇尊者", "天机尊者", "造化尊者",
        "轮回尊者", "寂灭尊者", "涅槃尊者", "紫霄尊者", "青冥尊者", "九幽尊者", "玄冥尊者", "昊天尊者", "后土尊者", "日耀尊者", "月华尊者", "辰宿尊者", "河洛尊者", "坤元尊者", "乾罡尊者",
        "斩虚武尊", "真我战尊", "炼狱尊者", "焚妄尊者", "罡魄武尊", "劫灭尊者", "战魂武尊", "血炼尊者", "寂灭尊者", "破妄尊者", "陨神战尊", "戮心尊者", "罡煞武尊", "焚我尊者", "战魄尊者",
        "劫真武尊", "炼神尊者", "血战尊者", "寂罡战尊", "破劫武尊", "陨魄尊者", "戮虚战尊", "罡焚武尊", "焚魄尊者", "战劫尊者", "劫战武尊", "炼罡战尊", "血戮尊者", "寂墟武尊", "破道尊者",
        "陨战尊者", "戮罡战尊", "罡陨武尊", "焚劫尊者", "战灭尊者", "劫魄武尊", "炼狱战尊", "血焚尊者", "寂劫武尊", "破神尊者", "陨罡尊者", "戮战战尊", "罡破武尊", "焚战尊者", "战墟尊者",
        "劫罡战尊", "炼劫武尊", "血陨尊者", "寂战尊者", "破罡战尊", "陨劫武尊", "戮陨尊者", "罡戮战尊", "焚罡尊者", "战破尊者", "劫破武尊", "炼战战尊", "血劫尊者", "寂罡尊者", "破战武尊"
    }},

    {"Warrior92", new string[] {
        "万象生灭大尊者", "玄黄演道大圣", "太初启明大圣", "混元开天大尊者", "紫微巡斗大尊", "北辰拱极大圣", "九霄扶摇大尊者", "玉清化炁大尊",
        "星汉垂野大圣", "璇玑悬斡大尊", "钧天广乐大圣", "洛书布阵大尊", "纸纳乾坤大尊", "砚吞沧海大圣", "茶煮春秋大尊者", "乾元资始大圣",
        "禹鼎镇渊大圣", "周礼巡方大圣", "书经载道大尊", "礼乐垂世大圣", "剑胆琴心大尊者", "不朽大圣", "熔炉武圣", "气血大圣", "金身武圣", "玄冥大圣",
        "鲲鹏垂天大尊者", "应龙布雨大尊", "烛龙衔曜大圣", "玄龟负图大尊者", "麒麟踏祥大尊", "青鸾裁霞大圣", "饕餮吞虚大尊者", "穷奇裂宇大尊", "龙章凤姿大圣", 
        "白泽通明大圣", "重明破晦大尊者", "毕方焚荒大尊", "夔雷震世大圣", "昆仑镇岳大尊者", "建木通天大尊者", "浩然正气大尊者", "至大至刚大尊", "中庸合道大圣", "冲虚盈昃大尊", 
        "赤霄焚云大尊者", "碧落裁虹大尊", "黄泉渡厄大圣", "青冥御风大尊者", "玄冥凝霜大尊", "赭壤生春大圣", "齐物玄同大尊者", "逍遥无待大尊", "般若观空大圣", "涅槃寂静大尊者", 
        "光阴长河大尊者", "劫波渡尽大尊", "纪元更始大圣", "宿命织网大尊者", "虚空生灭大圣", "刹那永恒大尊者", "须弥纳芥大圣", "春秋秉笔大尊者", "离骚问天大尊", "易传通神大圣", 
        "冲虚盈昃大圣", "太和保合大圣", "乾元资始大尊者", "坤厚载物大圣", "日躔巡天大尊者", "月离毕雨大尊", "辰宿列张大尊者", "虚空生灭大尊者", "书经垂世大尊", "礼乐合和大圣",
        "玄黄演道大尊者", "混元开天大尊", "太初启明大圣", "玉清化炁大尊者", "上清驭雷大尊", "劫波渡尽大圣", "九幽武圣", "天罡大圣", "地煞武圣", "真炎大圣", "寒冰武圣",
        "昆仑截云大圣", "易水淬锋大尊者", "汤谷煮海大尊", "幽都掌夜大圣", "丰沮玉门大尊者", "钟山烛阴大尊", "羽渊藏鳞大圣", "英招巡疆大尊",
        "云汉回枢大圣", "璇玑玉衡大圣", "启明破晓大尊者", "长庚大圣", "景星庆云大尊者", "雷泽埋剑大尊者", "昆仑磨月大尊者", "星宿量天大圣", "归墟纳川大尊者",
        "昆吾铸锋大尊者", "淬星大尊", "赤水沉珠大尊", "弱水载羽大圣", "雷霆大圣", "风雷武圣", "星辰大圣", "日月武圣", "乾坤大圣", "雪境之主",
        "公输造天大圣", "齐物玄同大尊者", "逍遥无待大尊", "岱宗观日大尊者", "阴阳武圣", "混沌大圣", "虚无武圣", "寂灭大圣", "涅槃武圣",
        "北辰拱极大圣", "紫微巡斗大尊者", "九曜悬枢大圣", "荧惑守心大圣", "璇玑悬斡大尊", "辰宿大圣", "启明大尊者", "长庚大尊", "云汉回枢大圣", "天河注海大尊者", "月离毕雨大圣",
        "日躔巡天大圣", "星汉垂野大尊者", "景星庆云大圣", "雷车奔空大尊者", "电索裂宇大尊", "烛龙衔曜大圣", "鲲鹏垂天大尊者", "应龙布雨大尊", "玄龟负图大圣", "麒麟踏祥大尊者", "重明破晦大圣",
        "霁虹贯霄大圣", "玄冥凝霜大尊者", "赭壤生春大圣", "赤霄焚云大尊者", "碧落裁虹大尊", "白泽通明大圣", "饕餮吞虚大尊者", "穷奇裂宇大尊", "毕方焚荒大圣", "夔雷震世大尊者", "朱雀焚虚大圣",
        "黄泉渡厄大圣", "青冥御风大尊者", "玄穹垂象大圣", "混沌开窍大尊者", "鸿蒙吐纳大尊", "玄武镇渊大圣", "青龙擘海大尊者", "白虎啸岳大尊", "精卫填溟大圣", "刑天舞戚大尊者", "羲和驭日大圣",
        "明鬼天志大圣", "尚同节用大圣", "般若观空大尊者", "涅槃寂静大尊", "格物致知大圣", "阴阳燮理大尊", "五行生克大圣", "句芒司春大圣", "禺彊御海大圣", "陆吾守山大尊者", 
        "昆仑镇岳大尊者", "建木通天大尊者", "不周擎柱大尊", "昆仑截云大圣", "开明启扉大圣", "帝江浑沌大尊者", "天吴涌浪大尊", "弇兹锁宙大圣", "强良掣电大尊者", "奢比尸问天大尊",
        "劫波渡尽大圣", "须弥纳芥大尊", "日晷量天大尊者", "月晷测海大圣", "星槎渡汉大圣", "修罗大圣", "神魔武圣", "永恒大圣", "不灭武圣", "玄黄大圣",
        "云笈藏宙大尊者", "玉衡转斗大尊", "金乌衔日大圣", "素娥碾月大尊者", "金蟾吞岁大尊", "羲和驭日大尊者", "蓐收司秋大圣", "句芒掌春大尊者", "玄冥凝冬大圣", "祝融燃夏大圣",
        "星宿海量天大尊者", "雷泽埋剑大尊", "赤水沉珠大圣", "弱水载羽大尊者", "苍梧栖凤大尊", "汤谷煮海大圣", "归墟纳川大尊者", "羽渊藏鳞大尊", "丰沮启扉大圣", "钟山烛阴大尊者", "崆峒问道大尊",
        "紫霄武圣", "青莲大圣", "白虹武圣", "黑煞大圣", "赤炎武圣", "金乌大圣", "玉龙武圣", "麒麟大圣", "凤凰武圣", "龙象大圣", "虎魄武圣", "玄武大圣", "朱雀武圣", "白虎大圣", "青龙武圣",
        "破天大圣", "碎虚武圣", "炼狱大圣", "深渊武圣", "天元大圣", "地极武圣", "太初大圣", "元始武圣", "造化大圣", "轮回武圣", "斩妄圣者", "真我大圣", "焚血圣者", "罡魄大圣", "劫灭圣者",
        "炼狱大圣", "战魂圣者", "血戮大圣", "寂灭圣者", "破劫大圣", "陨神圣者", "戮心大圣", "罡煞圣者", "焚我大圣", "战魄圣者", "劫真大圣", "炼神圣者", "血战大圣", "寂罡圣者", "破妄大圣",
        "陨魄圣者", "戮虚大圣", "罡焚圣者", "焚魄大圣", "战劫圣者", "劫战大圣", "炼罡圣者", "血戮大圣", "寂墟圣者", "破道大圣", "陨战圣者", "戮罡大圣", "罡陨圣者", "焚劫圣者", "战灭大圣",
        "劫魄圣者", "炼狱大圣", "血焚圣者", "寂劫大圣", "破神圣者", "陨罡大圣", "戮战圣者", "罡破大圣", "焚战圣者", "战墟大圣"
    }},
    
    // 武极境尊号
    {"Warrior93", new string[] {
        "武帝", "神武圣尊", "武神", "武祖", "太极阴阳大帝", "光明帝尊", "东王神武圣尊", "太极崩神帝君", "两仪焚界帝", "血海大帝", "绝情断念帝尊", "诛心炼魄圣尊", "幽冥锁魂帝君", "红尘战狂帝",
        "阎罗大帝", "昆仑血神大帝", "血河弥陀佛主", "绝情帝", "波斯圣帝", "太初道君" , "四象神君", "周天星主", "混沌魔主", "残阳大帝", "昆仑天帝", "沧海龙皇", "焚天炎阳帝君", "炼道至尊", "焚轮至尊",
        "血海慈航大帝", "怒涛卷云大帝", "玄铁无常大帝", "青岚帝君", "星河炼界皇", "太初擘地圣尊", "万劫灭世主", "天道碎碑君", "怒涛卷岳大帝", "玄铁锻骨帝尊", "青岚裁风圣尊", "沧海破岳帝君", "焚天裂日帝",
        "绝灭帝君", "沧海龙皇", "九天真尊", "鸿蒙锻星帝", "虚无裂宇皇", "轮回葬日帝尊", "因果焚天主", "劫数崩岳帝君", "雷霆裂天大帝", "乾坤锻体帝尊", "鸿蒙碎岳圣尊", "太初炼魂帝君", "星河崩刃帝", "天武大帝", "虚无灭神帝尊", "星河擘日帝君", "鸿蒙碎穹帝",
        "梼杌大帝", "狻猊大帝", "青虹剑帝", "太极屠神帝", "两仪灭仙皇", "四象崩宙帝尊", "八卦碎虚主", "混沌炼世帝君", "赤焰焚天大帝", "玄冰裂地帝尊", "紫电裁云圣尊", "青霜斩月帝君", "黄泉渡魂帝", "灭世焚天大帝", "钧天抚琴帝尊", "紫微大帝", "万劫圣尊", "宿命帝君",
        "天武圣帝", "日月分错大帝", "北海大帝", "星河大帝", "惊鸿刀帝", "蚩尤大帝", "天道炼星帝", "混沌擘宇皇", "两仪帝尊", "四象焚穹主", "葬世帝君", "九阳焚宇大帝", "化血弑神帝尊", "三千荡魔圣尊", "万法帝君", "劫火擘日帝",
        "红尘大帝", "阎罗帝君", "混沌云都大帝", "绝情大帝", "诛心大帝", "幽冥大帝", "血河大帝", "至上光明大尊", "罗浮剑主", "饕餮吞武大帝", "梼杌裂甲帝尊", "狻猊镇岳圣尊", "白泽演武帝君", "鲲鹏搏空帝", "葬星炼武大帝", "铸戟凌尘帝尊", "燃燧开天圣尊", "垂天镇岳帝君",
        "天刑劫帝", "人屠刀帝", "周天星主", "葬帝", "裂云大帝", "覆海大帝", "太初锻界大帝", "虚无屠世神皇", "法则崩宙圣尊", "星河灭世主", "鸿蒙碎天帝君", "九天真武大帝", "万劫锻魂帝尊", "宿命裂星圣尊", "劫数葬月帝君", "因果大帝",
        "化血神君", "三千荡神帝", "万法焚宇皇", "宿命大帝尊", "劫火裂穹圣主", "天道葬世帝君", "三千碎神帝", "万法葬宇皇", "劫火擘日帝尊", "宿命炼穹圣主", "玄冥镇北大帝", "断岳帝尊", "龙象般若圣尊", "摘日填渊帝君", "天命大帝",
        "玄冥大帝", "断岳刀皇", "龙象般若大帝", "天命执棋大帝", "芥子须弥未来佛", "凌波剑帝", "北冥剑帝", "紫微星主", "东王公", "光明圣王", "太极阴阳大帝", "苍梧神主", "修罗大帝", "四象裂星尊", "八卦锻天主", "混沌大帝君",
        "灭世大帝", "钧天抚琴尊圣", "紫微剑仙", "万劫锻神帝", "宿命裂界皇","太韶乐圣", "北斗武圣", "三千道纹帝君", "万法归一君", "虚无抱一大天尊", "天道垂钓主", "鸿蒙磨剑道尊",  "劫数碎星尊", "因果炼天主", "太初崩宙君", "太极崩神帝", "两仪焚界皇", 
        "吞日武尊", "听雷渊主", "拭剑云帝", "大黑天", "虚无灭神帝", "法则葬宇皇", "星河擘日帝尊", "鸿蒙碎穹武主", "天道炼世帝君", "玉霄摘星圣尊", "玄霜炼魄大帝", "金阙驭龙帝君", "紫府焚天帝尊", "瑶台煮海圣尊", "战宇武神", 
        "葬星潭皇", "铸戟潮神大帝", "燃燧圣尊", "垂天冥君", "种莲墟圣", "四象裂星大帝", "八卦锻天圣尊", "混沌灭宙帝君", "九霄玄上帝尊", "无量神武大帝", "狠人大帝", "无始大帝", "虚空大帝", "恒宇大帝", "青帝", "寂武大帝",
        "西皇", "太阴人皇", "太阳圣皇", "九黎大帝", "伏羲大帝", "阿弥陀佛大帝", "乱古大帝",  "斗战圣皇", "麒麟古皇", "血凰古皇", "万龙皇", "神皇", "不死天皇", "帝尊","碎虚大帝", "破宇大帝", "断空大帝", "灭劫大帝", "葬界大帝",
        "镇狱大帝", "执幽大帝", "掌轮大帝", "武极大帝", "战天大帝", "绝武大帝", "不灭大帝", "永劫大帝", "亘古大帝", "混沌大帝", "鸿蒙大帝", "太初大帝", "破宇帝", "断空帝", "灭劫帝", "葬界帝", "镇狱帝", "墟宇大帝", "寂罡武神",
        "执幽帝", "掌轮帝", "战天帝", "绝武帝", "不灭帝", "永劫帝", "亘古帝", "混沌帝", "鸿蒙帝", "太初帝", "元始帝", "碎虚圣皇", "破宇圣皇", "断空圣皇", "灭劫圣皇", "葬界圣皇", "镇狱圣皇", "执幽圣皇", "掌轮圣皇", "武极圣皇", "战天圣皇",
        "绝武圣皇", "不灭圣皇", "永劫圣皇", "亘古圣皇", "混沌圣皇", "鸿蒙圣皇", "太初圣皇", "灵宝天尊", "道德天尊", "元始天尊", "逍遥天尊", "长生天尊", "寂灭天尊", "渡劫天尊", "羽化大帝", "道衍大帝", "星河大帝", "武陨大帝", 
        "劫焱武帝", "战罡武神", "陨墟至尊", "焚宇道主", "戮劫武帝", "劫灭大帝", "战墟大帝", "罡极大帝", "狱神大帝", "荒宇大帝", "武寰大帝", "碎虚大帝", "镇轮大帝", "焚天大帝", "陨星大帝", "破穹大帝", "戮神大帝", "战魄武神", 
        "陨劫大帝", "焚宇大帝", "碎道大帝", "镇狱大帝", "战极大帝", "罡武大帝", "劫武大帝", "荒战大帝", "神罡大帝", "灭道大帝", "陨墟大帝", "碎宇大帝", "焚劫大帝", "镇荒大帝", "战狱大帝", "极戮大帝", "罡灭大帝", "劫神大帝",
        "灭罡大帝", "碎战大帝", "焚武大帝", "狱劫大帝", "荒戮大帝", "神墟大帝", "陨武大帝", "罡宇大帝", "劫灭武帝", "战墟武帝", "镇狱武神", "碎星至尊", "炼神道主", "寂天武帝", "破道武神", "罡煞至尊", "武灭道主", "墟神武帝",
        "陨神道主", "狱劫武帝", "罡宇武神", "碎道至尊", "炼狱道主", "战魂武帝", "焚虚武神", "镇宇至尊", "戮道道主", "劫神武帝", "罡战武神", "陨灭至尊", "寂墟道主", "破罡武帝", "武戮武神", "焚劫至尊", "镇神道主", "碎魂武帝", 
        "狱灭道主", "罡破武帝", "墟战武神", "陨道至尊", "寂灭道主", "劫宇武帝", "战虚武神", "焚道至尊", "镇劫道主", "戮罡武帝", "碎战武神", "炼墟至尊", "狱神道主", "罡陨武帝", "武焚武神", "墟灭至尊", "战劫道主", "破神武帝", 
        "焚狱道主", "镇虚武帝", "戮墟武神", "劫道至尊", "炼灭道主", "罡焚武帝", "战陨武神", "碎劫至尊", "狱宇道主", "武破武帝", "墟罡武神", "焚战至尊", "寂道道主", "陨狱武帝", "镇戮武神", "劫战至尊", "炼罡道主", "狱墟武帝",
        "罡道道主", "破墟武帝", "寂战武神", "陨焚至尊", "劫灭道主", "武罡武帝", "墟宇武神", "焚陨至尊", "镇战道主", "戮灭武帝", "炼劫武神", "狱道至尊", "碎寂道主", "罡戮武帝", "战焚武神", "碎焚武神", "战灭至尊", "陨战至尊",
        "陨罡至尊", "寂劫道主", "破狱武帝", "墟灭武神", "焚戮至尊", "劫罡道主", "镇陨武帝", "战道武神", "炼战至尊", "狱焚道主", "炼狱大帝", "战罡大帝"
    }}
};
private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_warriorSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        
        // 1. 分离基础名称（包括尊号）和旧境界后缀
        int lastDashIndex = currentName.LastIndexOf('-');
        string basePart = lastDashIndex >= 0 
            ? currentName.Substring(0, lastDashIndex).Trim() 
            : currentName;
        
        // 2. 设置新名称：基础名称 + 新境界后缀
        actor.data.setName($"{basePart}-{suffix}");
    }
}

private static void ApplyWarriorTitle(Actor actor, string newTrait)
{
    if (_warriorTitlesMap.TryGetValue(newTrait, out string[] titles))
    {
        string currentName = actor.getName();
        
        // 1. 分离境界后缀（最后一个连字符后的内容）
        int lastDashIndex = currentName.LastIndexOf('-');
        string suffixPart = lastDashIndex > 0 
            ? currentName.Substring(lastDashIndex)
            : "";
        
        string basePart = lastDashIndex > 0 
            ? currentName.Substring(0, lastDashIndex).Trim()
            : currentName;
        
        // 2. 移除旧尊号（如果有）
        int firstDashIndex = basePart.IndexOf('-');
        if (firstDashIndex > 0)
        {
            basePart = basePart.Substring(firstDashIndex + 1).Trim();
        }
        
        // 3. 随机选择新尊号
        string title = titles[UnityEngine.Random.Range(0, titles.Length)];
        
        // 4. 设置新名称：新尊号 + 基础名称 + 境界后缀
        actor.data.setName($"{title}-{basePart}{suffixPart}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武域境(Warrior9)、合道境(Warrior91)、斩我境(Warrior92)、武极境(Warrior93)均无视此真伤
                if (targetActor.hasTrait("Warrior9") || targetActor.hasTrait("Warrior91") || 
                    targetActor.hasTrait("Warrior92") || targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.09f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武域境(Warrior9)、合道境(Warrior91)、斩我境(Warrior92)、武极境(Warrior93)均无视此真伤
                if (targetActor.hasTrait("Warrior9") || targetActor.hasTrait("Warrior91") || 
                    targetActor.hasTrait("Warrior92") || targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.1f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.06f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (targetActor.hasTrait("Warrior91") || targetActor.hasTrait("Warrior92") || targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.11f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.07f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 斩我境(Warrior92)、武极境(Warrior93)无视此真伤
                if (targetActor.hasTrait("Warrior92") || targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.12f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.08f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武极境(Warrior93)无视此真伤
                if (targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.13f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武极境(Warrior93)无视此真伤
                if (targetActor.hasTrait("Warrior93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.14f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.15f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }

        public static bool fire1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_bomb_flash", pTile,"Bomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool fire2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile,"NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool TrueDamageByWarrior1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的武道气血值
            float warriorValue = attacker.GetWarrior();
    
            // 3. 计算真实伤害（示例：气血值的20%作为基础伤害）
            float baseDamage = warriorValue * 0.2f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("Warrior93")) // 武极境减免90%伤害
                trueDamage = (int)(trueDamage * 0.1f);
            else if (targetActor.hasTrait("Warrior92")) // 斩我境减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
    
            // 6. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.16f);
    
            return true;
        }

        public static bool TrueDamageByWarrior2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的武道气血值
            float warriorValue = attacker.GetWarrior();
    
            // 3. 计算真实伤害（示例：气血值的30%作为基础伤害）
            float baseDamage = warriorValue * 0.3f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("Warrior93")) // 武极境减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
    
            // 6. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.32f);
    
            return true;
        }

        public static bool TrueDamageByWarrior3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的武道气血值
            float warriorValue = attacker.GetWarrior();
    
            // 3. 计算真实伤害（示例：气血值的50%作为基础伤害）
            float baseDamage = warriorValue * 0.5f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.64f);
    
            return true;
        }


        public static bool Warrior1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Warrior2", "Warrior3", "Warrior4", "Warrior5", "Warrior6", "Warrior7", "Warrior8", "Warrior9", "Warrior91", "Warrior92", "Warrior93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Warrior1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "Warrior1");

            return true;
        }

        public static bool Warrior2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetWarrior() <= 9.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.8;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior1",
                "Warrior2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Warrior22" }
            );
            UpdateNameSuffix(a, "Warrior2");

            return true;
        }

        public static bool Warrior3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 8)
            {
                // 添加Warrior1特质
                upTrait("特质", "Warrior1", a, new string[] { "Warrior2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 19.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Warrior2",
                "Warrior3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior22"
                },
                new string[] { "Warrior3+", selectedTrait }
            );
            UpdateNameSuffix(a, "Warrior3");

            // 随机选择一个低级功法特质添加给人物
            string[] LowGongFa = { "LowGongFaTrait1", "LowGongFaTrait2", "LowGongFaTrait9", "LowGongFaTrait3", "LowGongFaTrait4", "LowGongFaTrait5", "LowGongFaTrait6", "LowGongFaTrait7", "LowGongFaTrait8" }; // 根据实际情况添加更多特质
            int randomIndex1 = UnityEngine.Random.Range(0, LowGongFa.Length);
            string selectedLowGongFa = LowGongFa[randomIndex];
            a.addTrait(selectedLowGongFa);

            return true;
        }

        public static bool Warrior4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 18)
            {
                upTrait("特质", "Warrior2", a, new string[] { "Warrior3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 39.99)
            {
                return false;
            }

            a.ChangeWarrior(-3);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior3",
                "Warrior4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior3+"
                },
                new string[] { "Warrior4+" }
            );
            UpdateNameSuffix(a, "Warrior4");

            return true;
        }

        public static bool Warrior5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 37)
            {
                upTrait("特质", "Warrior3", a, new string[] { "Warrior4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 79.99)
            {
                return false;
            }

            a.ChangeWarrior(-4);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior4",
                "Warrior5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior4+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior5+", selectedTrait } :
                new string[] { "Warrior5+" }
            );
            UpdateNameSuffix(a, "Warrior5");

            return true;
        }

        public static bool Warrior6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 76)
            {
                upTrait("特质", "Warrior4", a, new string[] { "Warrior5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 159.99)
            {
                return false;
            }

            a.ChangeWarrior(-5);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior5",
                "Warrior6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior5+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior6+", "freeze_proof", "fire_proof", "martialBloodline1", selectedTrait } :
                new string[] { "Warrior6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "Warrior6");

            string[] midGongFaTraits = {
                "MidGongFaTrait1", "MidGongFaTrait2", "MidGongFaTrait3", "MidGongFaTrait4",
                "MidGongFaTrait5", "MidGongFaTrait6", "MidGongFaTrait7", "MidGongFaTrait8",
                "MidGongFaTrait9", "MidGongFaTrait10", "MidGongFaTrait11", "MidGongFaTrait12",
                "MidGongFaTrait13", "MidGongFaTrait14"
            };

            // 随机决定获得特质的数量（1 - 2 个）
            int traitCount = UnityEngine.Random.Range(1, 3);

            // 随机选择特质
            List<string> selectedTraits = new List<string>();
            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, midGongFaTraits.Length);
                string traitId = midGongFaTraits[randomIndex];
                if (!selectedTraits.Contains(traitId))
                {
                    selectedTraits.Add(traitId);
                    a.addTrait(traitId, false);
                }
            }

            return true;
        }

        public static bool Warrior7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 155)
            {
                upTrait("特质", "Warrior6", a, new string[] { "Warrior7" }, new string[] { });
                return true;
            }

            if (a.GetWarrior() <= 299.99)
            {
                return false;
            }

            a.ChangeWarrior(-6);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior6",
                "Warrior7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior6+", "martialBloodline1" },
                new string[] { "Warrior7+", "martialBloodline2", "tough" }
            );
            UpdateNameSuffix(a, "Warrior7");
            ApplyWarriorTitle(a, "Warrior7");

            string[] GongFa = { "GongFaTrait1", "GongFaTrait2", "GongFaTrait3", "GongFaTrait4", "GongFaTrait5", "GongFaTrait6", "GongFaTrait7", "GongFaTrait8", "GongFaTrait9", "GongFaTrait10", "GongFaTrait11", "GongFaTrait12", "GongFaTrait13", "GongFaTrait14" };
            int randomIndex2 = UnityEngine.Random.Range(0, GongFa.Length);
            string selectedGongFa = GongFa[randomIndex2];
            a.addTrait(selectedGongFa);

            // 检查是否拥有“先天无漏”特质
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior94");
            }

            return true;
        }

        public static bool Warrior8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 499.99)
            {
                return false;
            }

            a.ChangeWarrior(-9);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior94"};
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior7",
                "Warrior8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior7+", "Warrior94", "martialBloodline2" },
                new string[] { "Warrior8+", "strong_minded", "immune", "martialBloodline3" }
            );
            UpdateNameSuffix(a, "Warrior8");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior95");
            }

            return true;
        }

        public static bool Warrior9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 799.99)
            {
                return false;
            }

            a.ChangeWarrior(-15);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05; 
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior95" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior8",
                "Warrior9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior8+", "Warrior95", "martialBloodline3" },
                new string[] { "Warrior9+" ,"fire_proof", "regeneration", "martialBloodline4"}
            );
            UpdateNameSuffix(a, "Warrior9");
            ApplyWarriorTitle(a, "Warrior9");
       
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior96");
            }

            return true;
        }

        public static bool Warrior91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 1199.99)
            {
                return false;
            }

            a.ChangeWarrior(-20);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.3;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior96" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior9",
                "Warrior91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior9+", "martialBloodline4", "Warrior96" },
                new string[] { "Warrior91+", "martialBloodline5" }
            );
            UpdateNameSuffix(a, "Warrior91");
            ApplyWarriorTitle(a, "Warrior91");

            string[] arcaneTomes = { "arcaneTome1", "arcaneTome2", "arcaneTome3", "arcaneTome4", "arcaneTome5", "arcaneTome6", "arcaneTome7", "arcaneTome8", "arcaneTome9", "arcaneTome10", "arcaneTome11", "arcaneTome12", "arcaneTome13", "arcaneTome14" }; // 可以添加更多传承法特质名
            int randomIndex3 = UnityEngine.Random.Range(0, arcaneTomes.Length);
            string selectedarcaneTome = arcaneTomes[randomIndex3];
            a.addTrait(selectedarcaneTome);

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior97");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior9", "Warrior91");
            a.data.favorite = true;

            return true;
        }

        public static bool Warrior92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 3599.99)
            {
                return false;
            }

            a.ChangeWarrior(-30);
            double successRate = 0.06;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.002;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.2;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior97" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior91",
                "Warrior92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior91+", "martialBloodline5", "Warrior97" },
                new string[] { "Warrior92+", "martialBloodline6" }
            );
            List<string> grottoTraitIds = new List<string>
            {
                "CelestialGrotto1", "CelestialGrotto2", "CelestialGrotto3", "CelestialGrotto4",
                "CelestialGrotto5", "CelestialGrotto6", "CelestialGrotto7", "CelestialGrotto8",
                "CelestialGrotto9", "CelestialGrotto10", "CelestialGrotto11", "CelestialGrotto12",
                "CelestialGrotto13", "CelestialGrotto14", "CelestialGrotto15", "CelestialGrotto16",
                "CelestialGrotto17", "CelestialGrotto18"
            };

            // 检查是否拥有任一洞天特质
            bool hasAnyGrotto = false;
            foreach (string traitId in grottoTraitIds)
            {
                if (a.hasTrait(traitId))
                {
                    hasAnyGrotto = true;
                    break;
                }
            }

            if (!hasAnyGrotto)
            {
                int randomIndex = UnityEngine.Random.Range(0, grottoTraitIds.Count);
                string selectedGrottoTrait = grottoTraitIds[randomIndex];
                a.addTrait(selectedGrottoTrait);
            }
            UpdateNameSuffix(a, "Warrior92");
            ApplyWarriorTitle(a, "Warrior92");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior98");
            }

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Warrior91", "Warrior92");

            return true;
        }

        public static bool Warrior93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetWarrior() <= 9999.99)
            {
                return false;
            }

            a.ChangeWarrior(-60);
            double successRate = 0.02;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.1;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior98" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior92",
                "Warrior93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior92+", "martialBloodline6", "Warrior98" },
                new string[] { "Warrior93+", "immunity", "martialBloodline7" }
            );
            UpdateNameSuffix(a, "Warrior93");
            ApplyWarriorTitle(a, "Warrior93");

            if (UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior99");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior92", "Warrior93");

            // 随机获得一到三个九字秘特质
            string[] nineCharacterSecrets = { "NineCharacterSecret1", "NineCharacterSecret2", "NineCharacterSecret3", "NineCharacterSecret4", "NineCharacterSecret5", "NineCharacterSecret6", "NineCharacterSecret7", "NineCharacterSecret8", "NineCharacterSecret9" };
            int traitCount = UnityEngine.Random.Range(1, 4);
            List<string> selectedTraits = new List<string>();

            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, nineCharacterSecrets.Length);
                string selectedTrait = nineCharacterSecrets[randomIndex];
                if (!selectedTraits.Contains(selectedTrait))
                {
                    selectedTraits.Add(selectedTrait);
                    a.addTrait(selectedTrait);
                }
            }

            return true;
        }

        
        //武者的恢复生命值效果
        public static bool Warrior1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的10%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的20%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的30%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.3f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的40%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.4f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的50%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.5f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的60%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.6f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的70%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.7f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的80%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.8f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的90%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 0.9f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的100%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的110%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 1.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool Warrior93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前气血值
                float warriorValue = actor.GetWarrior();
                // 计算回血量：气血值的120%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(warriorValue * 1.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}