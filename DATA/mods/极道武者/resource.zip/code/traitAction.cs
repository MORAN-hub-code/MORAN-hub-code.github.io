﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitAction
    {
        public static bool IsWarrior1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"Warrior{i}") || a.hasTrait($"Warrior{i}+"))
                {
                    return true;
                }
            }
            return false;
        }
        private static readonly Dictionary<string, string> _warriorSuffixMap = new Dictionary<string, string>
{
    {"Warrior1", "锻体"},
    {"Warrior2", "炼骨"},
    {"Warrior3", "通脉"},
    {"Warrior4", "气海"},
    {"Warrior5", "化劲"},
    {"Warrior6", "凝罡"},
    {"Warrior7", "洞虚"},
    {"Warrior8", "劫身"},
    {"Warrior9", "武域"},
    {"Warrior91", "合道"},
    {"Warrior92", "斩我"},
    {"Warrior93", "武极"}
};
// 尊号字典（洞虚境、合道境、武极境）
private static readonly Dictionary<string, string[]> _warriorTitlesMap = new Dictionary<string, string[]>
{
    // 洞虚境尊号
    {"Warrior7", new string[] {
        "断贪刀", "斩妄剑", "破嗔掌", "碎痴爪", "焚傲炎","丹霞孟尝", "寒江钓叟", "过山峰", "听涛叟", "追星", "落霞剑客", "判官", "分水刺", "白额虎", "金翅雕", "赤练蛇",
        "铁掌分江", "青城鬼脸", "碧磷毒手", "寒江独钓", "断碑书生", "铁掌震北", "无痕神偷", "白莲圣使", "不动明王", "风雪狂刀", "镇岳神枪", "血手人屠", "千面神捕", "九尾狐", "赤练蛇", "穿山鼠", "笑面虎", "千面客", "睡罗汉", "妙手回春", "漠北苍狼",
        "雁门孤狼", "沧浪铁佛", "金顶飞鹰", "玉笔判官", "千仞毒叟", "泣血南山", "青铜罗汉", "赤风", "雨水真人", "移山力士" , "通臂猿", "画皮师", "胖米勒", "瞎判官", "布衣神相", "铁面无私", "流火将", "华盖君", "云中游",
        "银蛇郎君", "玄冰老怪", "黑木无常", "五岳摧心", "铁锁横江", "棋魔子", "画圣笔仙" , "铁幕游侠", "天机神算" , "铁笔书生", "炽火剑", "寒山长枪" , "慈悲先生", "大漠孤狼", "泣竹郎", "照夜白" , "鱼肠客", "焦尾生" , "焚琴子", "桑落翁", "醉扶疏" , "金错刀", "斩楼兰",
        "紫霄雷手", "无鞘刀", "三更死", "血鹦鹉", "断肠客栈", "辨忠奸", "解千愁", "乘黄", "穷奇" , "乱黑白", "奔日月", "陵鱼姬", "泣珠引", "采薇翁", "击筑客",
        "纸刀", "幽灵箭", "血玲珑", "断弦琴", "黑雪", " 烂柯子", "弈春秋", "请缨使", "砺肝胆", "漱石生", "然藜客", "秦淮影", "破胡尘", "蓟北枪", "灞陵尉",
        "残红泣", "孤灯灭", "空棺客", "寒鸦", "碎梦无痕", "大漠飞沙", "碎骨温柔",
        "白骨画眉", "冷血追魂", "勾魂引", "醉生梦死", "毒菩萨", "吹角将", "扎草人", "烧丹客", "炼龙虎", "相面客", "镇天元", "走龙蛇", "解牛功", "雕龙手", "挽千帆",
        "血月孤楼", "哭丧人", "大泼血", "黑水车", "冷血残阳", "紫电青霜", "银鞍照雪", "碧落黄泉", "玄冰烈火", "瀚海孤帆", 
        "销魂伞", "无鞘剑", "伤心箭", "白骨哀", "血河车", "大魔", "鬼面", "大力掌", "江城开碑手", "黑大虫", "霹雳火", "云中金刚", "追风客",
        "朝天棍", "碎魂锣", "断肠镖", "噬魂刺", "丧门鼓","垂天剑", "血河剑奴", "生死人屠" , "金乌剑", "圣火王", "沧海王", "清圣医", "万雷手", "九阴灼日", "四象伏魔棍", "翻海龙", "青莲剑", 
        "葬妒绫", "化怨笛", "空欲索", "绝惑瞳", "净疑钟","玉面修罗", "白居士", "篆烟客", "五弦使", "弄宫商", "白泽生", "晓百鬼", "饕餮客", "吞山河", "驺虞刃", "毕方使", "鲲鹏客", "渡沧溟", 
        "撕名帖", "裂冠客", "焚绶者", "碎印人", "折笏手","冰魄寒光", "云台飞絮", "玉箫惊鸿", "幽谷鸣泉", "空山鹤唳", "噬魂长枪", "腐心太岁", "血魔刀客", "铁面人屠", 
        "葬玉匠",  "覆棋生", "裂卷生", "碎镜客", "断弦翁","夜修罗", "催命阎王", "萍踪浪医", "霓裳毒仙", "冰川剑魄", "星海飞槎", "玉弓魅影",
        "孤峰守夜", "寒潭涤剑", "枯冢悟掌", "残阳淬指", "断崖听刀", "快意恩仇", "鬼手佛心", "惊梦钟", "三台客", 
        "雪原葬枪", "沙海焚弓", "雷池拭戟", "瘴林磨爪", "冰谷炼瞳", "孤星葬剑", "还剑公子","麒麟", "烛龙", 
        "十载面壁", "千日负石", "万里量沙", "百川饮马", "孤星伴鹤", "阴煞炼魂君", "夜行舟", "计都踪", "踏月来", "青棠客", "谢春池", "折柳生", "灞桥别",
        "空舟载月", "瘦马驮经", "破钵盛雪", "残灯照影", "断碑刻偈", "惊魂幡", "绝命签", "碎心铃", "裂魂爪", "蚀日幡", 
        "折梅问禅", "扫叶观道", "斫竹见性", "汲泉明心", "拾薪悟真", "劫数刻舟翁", "铁马冰河", "青锋葬雪", "萍踪侠影", "温柔错", "逆水寒","昆仑柱", "须弥圣僧", "毒蛇王", "巨熊王", 
        "裂帛见血", "碎玉闻声", "焚香知寂", "葬花觉空", "覆水证灭", "醉生笑", "孤鸿影", "枯荷听雨", "笑饮霜", "流萤葬火"
    }},
  
    // 武域境尊号
    {"Warrior9", new string[] {
        "裂江断岳宗师", "穿云贯日宗师", "翻江倒海宗师", "分水劈浪宗师", "裂石崩山宗师", "琴心剑胆宗师", "竹影棋风宗师", "松涛鹤唳宗师", "梅雪诗魂宗师", "云影钟声宗师",
        "罡风扫月宗师", "惊雷裂地宗师", "皓月宗师", "苍日横空宗师", "孤星照野宗师", "烟霞醉客宗师", "星月流辉宗师", "山水清音宗师", "乱神宗师", "三秋宗师",
        "观瀑听涛宗师", "踏雪无痕宗师", "凌云步虚宗师", "定海镇波宗师", "镇岳定山宗师", "金石铿锵宗师", "丝竹雅韵宗师", "不动如山宗师", "论道宗师", "书剑飘零宗师",
        "翻江搅浪宗师", "覆海吞江宗师", "擎山托岳宗师", "裂空穿云宗师", "疾风追电宗师", "诗酒风流宗师", "乾坤宗师", "茶禅宗师", "酒仙诗圣宗师", "剑胆琴心宗师",
        "暴雨宗师", "寒霜宗师", "烈火燎原宗师", "落雷破阵宗师", "苍松宗师", "松风竹节宗师", "梅骨兰魂宗师", "莲影荷香宗师", "云帆月楫宗师", "烟蓑雨笠宗师",
        "翠柏凝霜宗师", "古槐盘根宗师", "绿竹穿云宗师", "红梅傲雪宗师", "破晓宗师", "星斗文章宗师", "魔天宗师", "无间宗师", "丹青宗师", "金石宗师",
        "惊山宗师", "残灯照夜宗师", "晓月残星宗师", "寒星坠野宗师", "惊鸿宗师", "丝桐遗韵宗师", "竹帛烟霞宗师", "琴书雅趣宗师", "棋酒清欢宗师", "诗画通神宗师",
        "游龙临川宗师", "猛虎断岳宗师", "飞龙穿海宗师", "潜蛟出海宗师", "擎天立地宗师", "书画同源宗师", "茶酒论交宗师", "琴剑飘零宗师", "诗酒逍遥宗师", "破风宗师",
        "立地生根宗师", "横江锁浪宗师", "越海翻山宗师", "跨海登舟宗师", "掠影宗师", "茶烟琴韵宗师", "酒旗风暖宗师", "剑影刀光宗师", "诗心剑气宗师", "松月山房宗师",
        "裂石分金宗师", "崩山宗师", "断江截流宗师", "破空裂云宗师", "流云舒卷宗师", "梅雪宗师", "竹雨松风琴韵宗师", "茶烟梧月书声宗师", "剑气箫心合抱宗师", "琴怀剑胆双清宗师",
        "飞絮宗师", "飘雪漫空宗师", "落英宗师", "疾风宗师", "玄冰宗师", "松风水月无尽宗师", "烟霞泉石天然宗师", "诗肠酒胆如云宗师", "琴骨剑心似玉宗师", "梅妻鹤子同春宗师",
        "赤焰焚天宗师", "青木参天宗师", "黑金裂石宗师", "白水滔天宗师", "孤峰独峙宗师", "竹兰共雅宗师", "菊梅同香宗师", "云客宗师", "星槎月楫同游宗师", "山灵水韵同辉宗师",
        "藏龙宗师", "平原纵马宗师", "大漠烈阳宗师", "瀚海惊涛宗师", "旭日宗师", "琴调松风静听宗师", "剑舞霜华寒照宗师", "诗题红叶闲吟宗师", "画写青山静对宗师", "茶烹白雪宗师",
        "孤月悬空宗师", "寒星宗师", "朗日高悬宗师", "疏星朗月宗师", "酒饮黄花笑咏宗师", "棋敲竹露宗师", "书枕松云静卧宗师", "剑横秋水寒凝宗师", "琴弹夜月情幽宗师",
        "裂金断铁宗师", "断铁分金宗师", "破玉裂琼宗师", "碎琼乱玉宗师", "迎风逆浪宗师", "诗赋春风意远宗师", "画染秋云色淡宗师", "茶烹碧涧香幽宗师", "酒泛金波兴逸宗师", "棋布星罗势雄宗师",
        "逆浪行舟宗师", "顶雪踏霜宗师", "冒雨披蓑宗师", "踏霜破冰宗师", "静心守一宗师", "书临青史志高宗师", "剑倚苍岩气壮宗师", "琴抚流泉韵雅宗师", "诗吟落照神闲宗师", "画赏烟霞兴畅宗师",
        "剑鸣宗师", "会元宗师", "守意如钢宗师", "存真抱朴宗师", "明心见性宗师", "不迷宗师", "棋斗机锋智巧宗师", "书观今古心明宗师", "剑荡尘氛气正宗师",
        "见性成佛宗师", "悟道参玄宗师", "证理修真宗师", "归真返璞宗师", "撼山动地宗师", "琴调宫商韵正宗师", "画山摹水宗师", "龙胆宗师", "寒冽明镜宗师",
        "震岳摇川宗师", "动川惊海宗师", "摇海翻江宗师", "惊涛宗师", "穿云破雾宗师", "棋布兵戈势险宗师", "书藏今古情悠宗师", "剑扫妖氛宗师", "琴雅神怡宗师", "诗彩情豪宗师",
        "贯日凌云宗师", "追星逐月宗师", "逐月追星宗师", "揽星摘月宗师", "劈风斩浪宗师", "画染烟岚色润宗师", "酒泛味醇宗师", "心平宗师", "春秋志远宗师",
        "斩浪截江宗师", "截江断流宗师", "断河裂岸宗师", "裂涛排浪宗师", "乘风破浪宗师", "剑舞霓虹气壮宗师", "琴弹霹雳声威宗师", "诗吟才高宗师", "格妙宗师", "玉雨玄露宗师",
        "酒泛云霞色艳宗师", "棋布星辰象伟宗师", "剑倚崆峒气肃宗师", "琴调潇湘韵远宗师"
    }},

    // 合道境尊号
    {"Warrior91", new string[] {
        "凌云剑尊", "天道执秤尊者", "鸿蒙演法尊主", "太初问玄君", "法则刻篆使", "乾坤捻珠客", "玉阙听雷尊者", "金庭炼魄大宗师", "瑶台裁云尊", "璇宫执律尊者", "紫府演法大宗师", "丹霄御气尊", "星汉垂地大宗师", "乾坤清气大宗师", "宇宙精神大宗师", "江河行地大宗师",
        "星河炼魄尊", "虚无塑道者", "轮回磨镜人", "因果织网大宗师", "星河踏浪尊者", "太虚磨剑大宗师", "碧落斩虹尊", "黄泉渡月尊者", "须弥刻篆大宗师", "昆仑铸鼎尊", "吞山嚼星尊者", "驺虞碾月大宗师", "毕方蒸霞尊", "鲲鹏熬云尊者", "渡沧溟月大宗师", "大漠筛霞尊",
        "万神殿主", "黄庭真人", "南华老仙", "干将剑尊", "刑天战尊" , "精卫刀尊", "大日如来", "天照大宗师", "苗疆祖巫", "四极天柱", "天宪使者", "乾坤镇北", "铁马踏霜尊者", "青锋削月大宗师", "萍踪踩霞尊", "温柔碾雪尊者", "逆水搓冰大宗师", "昆仑磨月尊",
        "冰河隐者", "青冥客", "玉壶承露尊者", "金盏倾霞大宗师", "瑶卮盛月尊", "璇奁藏星尊者", "紫匣封云大宗师", "丹炉煅魂尊", "玄门尊者", "十月环天尊者", "黑天大尊", "星曜大宗师", "千秋看客", "青山盘羊尊者", "星空尊者", "逆反先天大宗师",
        "夜游神", "太初炼魂使", "虚无塑道尊者", "法则织网者", "乾坤执子尊", "星河叩关人", "玉衡转斗尊者", "金乌衔日大宗师", "素娥碾月尊", "玄武镇渊尊者", "青龙擘海大宗师", "白虎啸岳尊","玉衡转斗尊者", "金乌衔日大宗师", "素娥碾月尊", "玄武镇渊尊者", "青龙擘海大宗师", "白虎啸岳尊",
        "毒龙尊者", "寒铁龙骑", "碧落剑圣", "醉里乾坤", "罗睺影", "朱雀焚虚尊者", "八卦锁云大宗师", "两仪织雾尊", "四象炼罡尊者", "五行凝珠大宗师", "七星贯日尊", "玉杖敲云尊者", "金藜照夜大宗师", "瑶笏指辰尊", "璇圭测斗尊者", "紫璋量天大宗师", "丹璧绘辰尊",
        "黄泉尊者", "盘龙大尊", "七杀刀魔", "玄冰炼魂尊者", "赤焰合道大宗师", "苍梧栖鹤尊", "青冥御龙尊者", "丹丘种玉大宗师", "瑶海钓鳌尊", "玉斧开天尊者", "金锤锻地大宗师", "瑶凿穿岳尊", "璇锯截江尊者", "紫袍削月大宗师", "丹凿刻星尊",
        "五行尊者", "斩龙弈棋客", "春秋刻篆主", "两仪炼魄尊者", "四象磨剑翁", "八卦演法尊", "玉笛横秋尊者", "金弦裂帛大宗师", "瑶琴啸风尊", "璇簫唤月尊者", "紫笙吹露大宗师", "丹瑟鸣霜尊", "苍梧揽月尊者", "青冥御龙大宗师", "星河碾玉尊", "太虚织霞尊者", "法则镂金大宗师", "乾坤刻雪尊",
        "混沌执笔使", "三千问玄君", "万劫炼真客", "宿命摆渡人", "劫数磨镜仙", "铁尸太岁", "勾魂使者", "玉辇巡天尊者", "金鞍踏月大宗师", "瑶辔牵星尊", "璇舆渡汉尊者", "紫缰挽日大宗师", "丹毂碾云尊","天风浪浪大宗师", "海山苍苍大宗师", "河岳英灵大宗师", "日月经天大宗师",
        "泰阶平秩大宗师", "云雷经纶大宗师", "风霆行健大宗师", "雨露膏泽大宗师", "苍溟吐曜大宗师", "赤县腾龙大宗师", "神州卧虎大宗师", "九域同风大宗师", "剑扫八荒大宗师", "拳镇四溟大宗师", "掌擎日月大宗师", "指裂苍穹大宗师", "星垂平野大宗师", "月涌大江大宗师", "大漠孤烟大宗师", "长河落日大宗师",
        "九天揽月大宗师", "五洋捉鳖大宗师", "气贯长虹大宗师", "势吞寰宇大宗师", "道贯古今大宗师", "理通天人大宗师", "德配天地大宗师", "功昭日月大宗师", "松风万古大宗师", "梅月千秋大宗师", "风云际会大宗师", "龙虎风云大宗师", "鹏举九天大宗师", "凤翔千仞大宗师", "龙腾四海大宗师",
        "鲸吞沧海大宗师", "鳌戴三山大宗师", "星罗棋布大宗师", "云蒸霞蔚大宗师", "浩然正气大宗师", "至大至刚大宗师", "中庸至德大宗师", "中和至道大宗师", "与天地参大宗师", "并日月明大宗师", "垂宪万世大宗师", "立极千秋大宗师", "青松拔地大宗师", "翠柏参天大宗师", "红梅傲雪大宗师", "翠竹凌云大宗师",
        "玉阙栖鸾尊者", "金庭驻鹤大宗师", "瑶台驯鹿尊", "璇宫饲凤尊者", "紫府育麟大宗师", "丹霄乘龙尊", "玉阶步月尊者", "金殿踏云大宗师", "瑶墀踩霞尊", "璇廊巡斗尊者", "紫庭观辰大宗师", "丹墀望日尊"
    }},
    
    // 武极境尊号
    {"Warrior93", new string[] {
        "武帝", "武圣", "武神", "武祖", "太极阴阳大帝", "光明帝尊", "东王神武圣尊", "太极崩神帝君", "两仪焚界帝", "血海大帝", "绝情断念帝尊", "诛心炼魄圣尊", "幽冥锁魂帝君", "红尘战狂帝",
        "赤发阎罗大帝", "昆仑血神大帝", "血河弥陀佛主", "绝情帝","波斯圣王", "太初道君" , "四象神君", "周天星主", "五行大尊", "混沌魔主", "残阳大帝", "昆仑天帝", "沧海龙皇", "焚天炎阳帝君", 
        "血海慈航大帝", "怒涛卷云大帝", "玄铁无常大帝", "青岚帝君", "混沌崩天大帝", "星河炼界皇", "太初擘地圣尊", "万劫灭世主", "天道碎碑君", "怒涛卷岳大帝", "玄铁锻骨帝尊", "青岚裁风圣尊", "沧海破岳帝君", "焚天裂日帝",
        "绝灭帝君", "沧海龙皇", "九天真尊", "鸿蒙锻星帝", "虚无裂宇皇", "轮回葬日帝尊", "因果焚天主", "劫数崩岳帝君", "雷霆裂天大帝", "乾坤锻体帝尊", "鸿蒙碎岳圣尊", "太初炼魂帝君", "星河崩刃帝", "大黑天武大帝", "虚无灭神帝尊", "法则葬宇圣尊", "星河擘日帝君", "鸿蒙碎穹帝",
        "梼杌大帝", "狻猊大帝", "青虹剑帝", "太极屠神帝", "两仪灭仙皇", "四象崩宙帝尊", "八卦碎虚主", "混沌炼世帝君", "赤焰焚天大帝", "玄冰裂地帝尊", "紫电裁云圣尊", "青霜斩月帝君", "黄泉渡魂帝", "灭世焚天大帝", "钧天抚琴帝尊", "紫微斩仙帝", "万劫锻魂圣尊", "宿命裂界帝君",
        "武圣", "日月分错大帝", "北海大帝", "星河大帝", "惊鸿刀帝", "蚩尤大帝", "天道炼星帝", "混沌擘宇皇", "两仪崩日帝尊", "四象焚穹主", "八卦葬世帝君", "九阳焚宇大帝", "化血弑神帝尊", "三千荡魔圣尊", "万法崩天帝君", "劫火擘日帝",
        "红尘大帝", "阎罗帝君", "混沌云都大帝", "绝情大帝", "诛心大帝", "幽冥大帝", "血河大帝", "至上光明大尊", "罗浮剑主", "饕餮吞武大帝", "梼杌裂甲帝尊", "狻猊镇岳圣尊", "白泽演武帝君", "鲲鹏搏空帝", "葬星炼武大帝", "铸戟凌尘帝尊", "燃燧开天圣尊", "垂天镇岳帝君", "种莲锻体帝",
        "天刑劫帝", "人屠刀帝", "周天星主", "葬帝", "裂云大帝", "覆海大帝", "太初锻界大帝", "虚无屠世神皇", "法则崩宙圣尊", "星河灭世主", "鸿蒙碎天帝君", "九天真武大帝", "万劫锻魂帝尊", "宿命裂星圣尊", "劫数葬月帝君", "因果断岳帝",
        "九阳尊者", "化血神君", "三千荡神帝", "万法焚宇皇", "宿命崩星尊", "劫火裂穹主", "天道葬世君", "三千碎神帝", "万法葬宇皇", "劫火擘日尊", "宿命炼穹主", "玄冥镇北大帝", "断岳裂石帝尊", "龙象般若圣尊", "移山填海帝君", "天命执棋帝",
        "玄冥大帝", "断岳刀皇", "龙象般若大帝","移山圣尊", "天命执棋大帝", "芥子须弥未来佛", "凌波剑帝", "北冥剑尊", "紫微星主", "东王公", "波斯光明王", "太极阴阳大帝", "苍梧神主", "断首修罗大帝", 
        "灭世大帝", "钧天抚琴尊圣", "紫微剑仙", "万劫锻神帝", "宿命裂界皇","太韶乐圣", "北斗武圣", "三千道纹帝君", "万法归一君", "虚无抱一", "天道垂钓者", "鸿蒙磨剑人",  "劫数碎星尊", "因果炼天主", "太初崩宙君", "太极崩神帝", "两仪焚界皇", "四象裂星尊", "八卦锻天主", "混沌灭宙君",
        "吞日武尊", "听雷渊主", "凝霜山君", "裁月剑圣", "拭剑云帝","大黑天", "虚无灭神帝", "法则葬宇皇", "星河擘日帝尊", "鸿蒙碎穹武主", "天道炼世帝君", "玉霄摘星圣尊", "玄霜炼魄大帝", "金阙驭龙帝君", "紫府焚天帝尊", "瑶台煮海圣尊",
        "葬星潭皇", "铸戟潮神大帝", "燃燧圣尊", "垂天冥君", "种莲墟圣", "四象裂星大帝", "八卦锻天圣尊", "混沌灭宙帝君", "九霄玄上帝尊", "无量神武大帝"
    }}
};
private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_warriorSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        
        // 1. 分离基础名称（包括尊号）和旧境界后缀
        int lastDashIndex = currentName.LastIndexOf('-');
        string basePart = lastDashIndex >= 0 
            ? currentName.Substring(0, lastDashIndex).Trim() 
            : currentName;
        
        // 2. 设置新名称：基础名称 + 新境界后缀
        actor.data.setName($"{basePart}-{suffix}");
    }
}

private static void ApplyWarriorTitle(Actor actor, string newTrait)
{
    if (_warriorTitlesMap.TryGetValue(newTrait, out string[] titles))
    {
        string currentName = actor.getName();
        
        // 1. 分离境界后缀（最后一个连字符后的内容）
        int lastDashIndex = currentName.LastIndexOf('-');
        string suffixPart = lastDashIndex > 0 
            ? currentName.Substring(lastDashIndex)
            : "";
        
        string basePart = lastDashIndex > 0 
            ? currentName.Substring(0, lastDashIndex).Trim()
            : currentName;
        
        // 2. 移除旧尊号（如果有）
        int firstDashIndex = basePart.IndexOf('-');
        if (firstDashIndex > 0)
        {
            basePart = basePart.Substring(firstDashIndex + 1).Trim();
        }
        
        // 3. 随机选择新尊号
        string title = titles[UnityEngine.Random.Range(0, titles.Length)];
        
        // 4. 设置新名称：新尊号 + 基础名称 + 境界后缀
        actor.data.setName($"{title}-{basePart}{suffixPart}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 1000 点真伤，可根据需要调整该值
                int trueDamage = 1000;
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 2000 点真伤，可根据需要调整该值
                int trueDamage = 2000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.06f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 4000 点真伤，可根据需要调整该值
                int trueDamage = 4000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.07f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 8000 点真伤，可根据需要调整该值
                int trueDamage = 8000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.08f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 16000 点真伤，可根据需要调整该值
                int trueDamage = 16000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 32000 点真伤，可根据需要调整该值
                int trueDamage = 32000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 640000 点真伤，可根据需要调整该值
                int trueDamage = 640000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }

        public static bool fire1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_bomb_flash", pTile,"Bomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool fire2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile,"NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool Warrior1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Warrior2", "Warrior3", "Warrior4", "Warrior5", "Warrior6", "Warrior7", "Warrior8", "Warrior9", "Warrior91", "Warrior92", "Warrior93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Warrior1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "Warrior1");

            return true;
        }

        public static bool Warrior2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetWarrior() <= 9.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.8;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior1",
                "Warrior2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Warrior22" }
            );
            UpdateNameSuffix(a, "Warrior2");

            return true;
        }

        public static bool Warrior3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 8)
            {
                // 添加Warrior1特质
                upTrait("特质", "Warrior1", a, new string[] { "Warrior2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 19.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Warrior2",
                "Warrior3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior22"
                },
                new string[] { "Warrior3+", selectedTrait }
            );
            UpdateNameSuffix(a, "Warrior3");

            // 随机选择一个低级功法特质添加给人物
            string[] LowGongFa = { "LowGongFaTrait1", "LowGongFaTrait2", "LowGongFaTrait9", "LowGongFaTrait3", "LowGongFaTrait4", "LowGongFaTrait5", "LowGongFaTrait6", "LowGongFaTrait7", "LowGongFaTrait8" }; // 根据实际情况添加更多特质
            int randomIndex1 = UnityEngine.Random.Range(0, LowGongFa.Length);
            string selectedLowGongFa = LowGongFa[randomIndex];
            a.addTrait(selectedLowGongFa);

            return true;
        }

        public static bool Warrior4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 18)
            {
                upTrait("特质", "Warrior2", a, new string[] { "Warrior3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 39.99)
            {
                return false;
            }

            a.ChangeWarrior(-3);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior3",
                "Warrior4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior3+"
                },
                new string[] { "Warrior4+" }
            );
            UpdateNameSuffix(a, "Warrior4");

            return true;
        }

        public static bool Warrior5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 37)
            {
                upTrait("特质", "Warrior3", a, new string[] { "Warrior4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 79.99)
            {
                return false;
            }

            a.ChangeWarrior(-4);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior4",
                "Warrior5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior4+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior5+", selectedTrait } :
                new string[] { "Warrior5+" }
            );
            UpdateNameSuffix(a, "Warrior5");

            return true;
        }

        public static bool Warrior6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 76)
            {
                upTrait("特质", "Warrior4", a, new string[] { "Warrior5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 159.99)
            {
                return false;
            }

            a.ChangeWarrior(-5);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior5",
                "Warrior6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior5+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior6+", "freeze_proof", "fire_proof", "martialBloodline1", selectedTrait } :
                new string[] { "Warrior6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "Warrior6");

            string[] midGongFaTraits = {
                "MidGongFaTrait1", "MidGongFaTrait2", "MidGongFaTrait3", "MidGongFaTrait4",
                "MidGongFaTrait5", "MidGongFaTrait6", "MidGongFaTrait7", "MidGongFaTrait8",
                "MidGongFaTrait9", "MidGongFaTrait10", "MidGongFaTrait11", "MidGongFaTrait12",
                "MidGongFaTrait13"
            };

            // 随机决定获得特质的数量（1 - 2 个）
            int traitCount = UnityEngine.Random.Range(1, 3);

            // 随机选择特质
            List<string> selectedTraits = new List<string>();
            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, midGongFaTraits.Length);
                string traitId = midGongFaTraits[randomIndex];
                if (!selectedTraits.Contains(traitId))
                {
                    selectedTraits.Add(traitId);
                    a.addTrait(traitId, false);
                }
            }

            return true;
        }

        public static bool Warrior7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 155)
            {
                upTrait("特质", "Warrior6", a, new string[] { "Warrior7" }, new string[] { });
                return true;
            }

            if (a.GetWarrior() <= 299.99)
            {
                return false;
            }

            a.ChangeWarrior(-6);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior6",
                "Warrior7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior6+", "martialBloodline1" },
                new string[] { "Warrior7+", "martialBloodline2" }
            );
            UpdateNameSuffix(a, "Warrior7");
            ApplyWarriorTitle(a, "Warrior7");

            string[] GongFa = { "GongFaTrait1", "GongFaTrait2", "GongFaTrait3", "GongFaTrait4", "GongFaTrait5", "GongFaTrait6", "GongFaTrait7", "GongFaTrait8", "GongFaTrait9", "GongFaTrait10", "GongFaTrait11", "GongFaTrait12", "GongFaTrait13" };
            int randomIndex2 = UnityEngine.Random.Range(0, GongFa.Length);
            string selectedGongFa = GongFa[randomIndex2];
            a.addTrait(selectedGongFa);

            // 检查是否拥有“先天无漏”特质
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior94");
            }

            return true;
        }

        public static bool Warrior8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 499.99)
            {
                return false;
            }

            a.ChangeWarrior(-9);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior94"};
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior7",
                "Warrior8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior7+", "Warrior94", "martialBloodline2" },
                new string[] { "Warrior8+", "strong_minded", "immune", "martialBloodline3" }
            );
            UpdateNameSuffix(a, "Warrior8");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior95");
            }

            return true;
        }

        public static bool Warrior9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 799.99)
            {
                return false;
            }

            a.ChangeWarrior(-15);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05; 
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior95" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior8",
                "Warrior9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior8+", "Warrior95", "martialBloodline3" },
                new string[] { "Warrior9+" ,"fire_proof", "regeneration", "martialBloodline4"}
            );
            UpdateNameSuffix(a, "Warrior9");
            ApplyWarriorTitle(a, "Warrior9");
       
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior96");
            }

            return true;
        }

        public static bool Warrior91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 1199.99)
            {
                return false;
            }

            a.ChangeWarrior(-20);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.3;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior96" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior9",
                "Warrior91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior9+", "martialBloodline4", "Warrior96" },
                new string[] { "Warrior91+", "martialBloodline5" }
            );
            UpdateNameSuffix(a, "Warrior91");
            ApplyWarriorTitle(a, "Warrior91");

            string[] arcaneTomes = { "arcaneTome1", "arcaneTome2", "arcaneTome3", "arcaneTome4", "arcaneTome5", "arcaneTome6", "arcaneTome7", "arcaneTome8", "arcaneTome9", "arcaneTome10", "arcaneTome11", "arcaneTome12", "arcaneTome13" }; // 可以添加更多传承法特质名
            int randomIndex3 = UnityEngine.Random.Range(0, arcaneTomes.Length);
            string selectedarcaneTome = arcaneTomes[randomIndex3];
            a.addTrait(selectedarcaneTome);

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior97");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior9", "Warrior91");
            a.data.favorite = true;

            return true;
        }

        public static bool Warrior92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 3599.99)
            {
                return false;
            }

            a.ChangeWarrior(-30);
            double successRate = 0.06;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.002;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.3;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior97" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior91",
                "Warrior92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior91+", "martialBloodline5", "Warrior97" },
                new string[] { "Warrior92+", "martialBloodline6" }
            );
            UpdateNameSuffix(a, "Warrior92");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior98");
            }

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Warrior91", "Warrior92");

            return true;
        }

        public static bool Warrior93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetWarrior() <= 9999.99)
            {
                return false;
            }

            a.ChangeWarrior(-60);
            double successRate = 0.02;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.1;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior98" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior92",
                "Warrior93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior92+", "martialBloodline6", "Warrior98" },
                new string[] { "Warrior93+", "immunity", "martialBloodline7" }
            );
            UpdateNameSuffix(a, "Warrior93");
            ApplyWarriorTitle(a, "Warrior93");

            if (UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior99");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior92", "Warrior93");

            // 随机获得一到三个九字秘特质
            string[] nineCharacterSecrets = { "NineCharacterSecret1", "NineCharacterSecret2", /* 其他九字秘特质名 */ };
            int traitCount = UnityEngine.Random.Range(1, 4);
            List<string> selectedTraits = new List<string>();

            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, nineCharacterSecrets.Length);
                string selectedTrait = nineCharacterSecrets[randomIndex];
                if (!selectedTraits.Contains(selectedTrait))
                {
                    selectedTraits.Add(selectedTrait);
                    a.addTrait(selectedTrait);
                }
            }

            return true;
        }

        
        //武者的恢复生命值效果
        public static bool Warrior1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}