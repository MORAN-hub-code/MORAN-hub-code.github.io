﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitAction
    {
        public static bool IsWarrior1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"Warrior{i}") || a.hasTrait($"Warrior{i}+"))
                {
                    return true;
                }
            }
            return false;
        }
        private static readonly Dictionary<string, string> _warriorSuffixMap = new Dictionary<string, string>
{
    {"Warrior1", "锻体"},
    {"Warrior2", "炼骨"},
    {"Warrior3", "通脉"},
    {"Warrior4", "气海"},
    {"Warrior5", "化劲"},
    {"Warrior6", "凝罡"},
    {"Warrior7", "洞虚"},
    {"Warrior8", "劫身"},
    {"Warrior9", "武域"},
    {"Warrior91", "合道"},
    {"Warrior92", "斩我"},
    {"Warrior93", "武极"}
};
// 尊号字典（洞虚境、合道境、武极境）
private static readonly Dictionary<string, string[]> _warriorTitlesMap = new Dictionary<string, string[]>
{
    // 洞虚境尊号
    {"Warrior7", new string[] {
        "断贪刀", "斩妄剑", "破嗔掌", "碎痴爪", "焚傲炎","丹霞孟尝", "寒江钓叟", "过山峰", "听涛叟", "追星", "落霞剑客", "判官", "分水刺", "白额虎", "金翅雕", "赤练蛇",
        "铁掌分江", "青城鬼脸", "碧磷毒手", "寒江独钓", "断碑书生", "铁掌震北", "无痕神偷", "白莲圣使", "不动明王", "风雪狂刀", "镇岳神枪", "血手人屠", "千面神捕", "九尾狐", "赤练蛇", "穿山鼠", "笑面虎", "千面客", "睡罗汉", "妙手回春", "漠北苍狼",
        "雁门孤狼", "沧浪铁佛", "金顶飞鹰", "玉笔判官", "千仞毒叟", "泣血南山", "青铜罗汉", "赤风", "雨水真人", "移山力士" , "通臂猿", "画皮师", "胖米勒", "瞎判官", "布衣神相", "铁面无私", "流火将", "华盖君", "云中游",
        "银蛇郎君", "玄冰老怪", "黑木无常", "五岳摧心", "铁锁横江", "棋魔子", "画圣笔仙" , "铁幕游侠", "天机神算" , "铁笔书生", "炽火剑", "寒山长枪" , "慈悲先生", "大漠孤狼", "泣竹郎", "照夜白" , "鱼肠客", "焦尾生" , "焚琴子", "桑落翁", "醉扶疏" , "金错刀", "斩楼兰",
        "紫霄雷手", "无鞘刀", "三更死", "血鹦鹉", "断肠客栈", "辨忠奸", "解千愁", "乘黄", "穷奇" , "乱黑白", "奔日月", "陵鱼姬", "泣珠引", "采薇翁", "击筑客",
        "纸刀", "幽灵箭", "血玲珑", "断弦琴", "黑雪", " 烂柯子", "弈春秋", "请缨使", "砺肝胆", "漱石生", "然藜客", "秦淮影", "破胡尘", "蓟北枪", "灞陵尉",
        "残红泣", "孤灯灭", "空棺客", "寒鸦", "碎梦无痕",
        "白骨画眉", "冷血追魂", "勾魂引", "醉生梦死", "毒菩萨", "吹角将", "扎草人", "烧丹客", "炼龙虎", "相面客", "镇天元", "走龙蛇", "解牛功", "雕龙手", "挽千帆",
        "血月孤楼", "哭丧人", "大泼血", "黑水车", "冷血残阳",
        "销魂伞", "无鞘剑", "伤心箭", "白骨哀", "血河车", "大魔", "鬼面", "大力掌", "江城开碑手", "黑大虫", "霹雳火", "云中金刚", "追风客",
        "朝天棍", "碎魂锣", "断肠镖", "噬魂刺", "丧门鼓","垂天剑尊", "血河剑奴", "生死人屠" , "金乌剑尊", "圣火明王", "沧海冥王", "玉清圣主", "万神雷主", "九阴灼日神", "四象伏魔棍尊", "焚天煮海尊王", "青莲剑仙", 
        "葬妒绫", "化怨笛", "空欲索", "绝惑瞳", "净疑钟","玉面修罗", 
        "撕名帖", "裂冠客", "焚绶者", "碎印人", "折笏手",
        "葬玉匠",  "覆棋生", "裂卷生", "碎镜客", "断弦翁","暗夜修罗", "催命阎王", 
        "孤峰守夜", "寒潭涤剑", "枯冢悟掌", "残阳淬指", "断崖听刀",
        "雪原葬枪", "沙海焚弓", "雷池拭戟", "瘴林磨爪", "冰谷炼瞳",
        "十载面壁", "千日负石", "万里量沙", "百川饮马", "孤星伴鹤","阴煞炼魂君", 
        "空舟载月", "瘦马驮经", "破钵盛雪", "残灯照影", "断碑刻偈",
        "折梅问禅", "扫叶观道", "斫竹见性", "汲泉明心", "拾薪悟真",
        "裂帛见血", "碎玉闻声", "焚香知寂", "葬花觉空", "覆水证灭"
    }},
  
    // 合道境尊号
    {"Warrior91", new string[] {
        "潇湘夜雨", "落日熔金", "枯骨留香", "冷酒封喉", "断刃天涯","凌云剑尊", 
        "孤星葬剑", "残烛照影", "死水寒潭", "天山雪魅", "还剑公子","麒麟", "烛龙", 
        "萍踪浪医", "霓裳毒仙", "冰川剑魄", "星海飞槎", "玉弓魅影","万神殿主", "黄庭真人", "南华老仙", "干将剑尊", "刑天战神" , "精卫刀客", "大日如来", "东瀛天照巫", "苗疆祖巫", "四极天柱", "天宪使者", "乾坤镇北", 
        "冰河隐者", "飞花摘叶", "云海孤鸿", "寒梅傲雪", "青冥客","太韶乐圣", "北斗武圣", 
        "紫电青霜", "银鞍照雪", "碧落黄泉", "玄冰烈火", "瀚海孤帆", "夜游神", 
        "冰魄寒光", "云台飞絮", "玉箫惊鸿", "幽谷鸣泉", "空山鹤唳", "噬魂长枪", "腐心太岁", "血魔刀客", "铁面人屠", "毒龙尊者", "寒铁龙骑", "碧落剑圣", "醉里乾坤", "三台客", "罗睺影", "夜行舟", "计都踪", "踏月来", "青棠客", "谢春池", "折柳生", "灞桥别",
        "铁马冰河", "青锋葬雪", "萍踪侠影", "温柔错", "逆水寒","昆仑柱", "须弥圣僧", "毒蛇", "巨熊", "黄泉引路人", "藏獒", "七杀刀魔", "画师", "白居士", "篆烟客", "五弦使", "弄宫商", "白泽生", "晓百鬼", "饕餮客", "吞山河", "驺虞刃", "毕方使", "鲲鹏客", "渡沧溟",
        "大漠飞沙", "快意恩仇", "鬼手佛心", "惊梦钟", "碎骨温柔","五行尊者", 
        "惊魂幡", "绝命签", "碎心铃", "裂魂爪", "蚀日幡","周天星主", 
        "醉生笑", "孤鸿影", "枯荷听雨", "笑饮霜", "流萤葬火"
    }},
    
    // 武极境尊号
    {"Warrior93", new string[] {
        "武帝", "武圣", "武神", "武祖",
        "赤发阎罗", "昆仑血驼", "血弥陀", "九阳疯丐", "绝情谷主","波斯圣王", "太初道君" , "四象神君", "周天星主", "五行尊者", "混沌魔主", "不落残阳", "昆仑天柱", "沧海龙皇", "焚天炎君", 
        "峨眉断情", "血海慈航", "怒涛卷云", "玄铁无常", "无泪人","青岚君", 
        "绝灭王", "破军刀", "破军枪", "九阴掌", "紫电剑","沧海龙皇", "九天真尊", 
        "天琊剑", "天罡刀", "雷鸣掌", "紫薇剑", "伏魔拳","梼杌", "狻猊", "青虹剑仙", 
        "武圣人", "分日月", "震北海", "碎星河", "惊鸿刀","蚩尤", 
        "斩红尘", "笑阎罗", "傲昆仑", "绝情弓", "诛心掌","幽冥", "血河教主", "铁尸太岁", "勾魂使者", "至上光明大尊", "罗浮剑仙", 
        "天刑劫", "人屠刀", "葬青锋", "裂云斧", "覆雨翻云",
        "剑心通明", "天刀断岳", "铁掌震岳", "九阳尊者", "化血神君",
        "玄冥老怪", "生死符", "燎原枪", "断岳刀罡", "龙象般若","移山圣尊", "天命执棋", "芥子须弥", "凌波剑仙", "北冥剑尊", "紫微星主", "东王公", "波斯光明王", "太极阴阳子", "苍梧神主", "断首修罗", 
        "嫁衣神功", "鬼医毒仙", "不老童子", "素手裂天", "灭世","钧天琴尊", "紫微剑仙", 
        "吞日武尊", "听雷渊主", "凝霜山君", "裁月剑圣", "拭剑云帝","大黑天",
        "葬星潭皇", "铸戟潮神", "燃燧丘尊", "垂钓冥君", "种莲墟圣", "九霄玄上无量大尊者"
    }}
};
private static void ApplyWarriorTitle(Actor actor, string newTrait)
{
    if (_warriorTitlesMap.TryGetValue(newTrait, out string[] titles))
    {
        string currentName = actor.getName();
        
        // 移除可能存在的旧尊号
        int dotIndex = currentName.IndexOf('·');
        string baseName = dotIndex > 0 
            ? currentName.Substring(dotIndex + 1).Trim()
            : currentName;
        
        // 随机选择新尊号
        string title = titles[UnityEngine.Random.Range(0, titles.Length)];
        
        // 设置新名称：尊号·基础名
        actor.data.setName($"{title}·{baseName}");
    }
}

private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_warriorSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        int dashIndex = currentName.IndexOf('-');
        
        // 如果名称中已包含后缀，移除旧后缀
        string baseName = dashIndex > 0 
            ? currentName.Substring(0, dashIndex).Trim()
            : currentName;
        
        // 设置新名称：基础名 + 后缀
        actor.data.setName($"{baseName}-{suffix}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 1200 点真伤，可根据需要调整该值
                int trueDamage = 1200;
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 3000 点真伤，可根据需要调整该值
                int trueDamage = 3000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 6000 点真伤，可根据需要调整该值
                int trueDamage = 6000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 12000 点真伤，可根据需要调整该值
                int trueDamage = 12000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 24000 点真伤，可根据需要调整该值
                int trueDamage = 24000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 48000 点真伤，可根据需要调整该值
                int trueDamage = 48000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 100000 点真伤，可根据需要调整该值
                int trueDamage = 100000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool lei3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                MapBox.spawnLightningBig(pTile, 0.05f);
            }

            return false;
        }

        public static bool Warrior1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Warrior2", "Warrior3", "Warrior4", "Warrior5", "Warrior6", "Warrior7", "Warrior8", "Warrior9", "Warrior91", "Warrior92", "Warrior93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Warrior1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "Warrior1");

            return true;
        }

        public static bool Warrior2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetWarrior() <= 9.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.8;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior1",
                "Warrior2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Warrior22" }
            );
            UpdateNameSuffix(a, "Warrior2");

            return true;
        }

        public static bool Warrior3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 8)
            {
                // 添加Warrior1特质
                upTrait("特质", "Warrior1", a, new string[] { "Warrior2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 19.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Warrior2",
                "Warrior3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior22"
                },
                new string[] { "Warrior3+", selectedTrait }
            );
            UpdateNameSuffix(a, "Warrior3");

            return true;
        }

        public static bool Warrior4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 18)
            {
                upTrait("特质", "Warrior2", a, new string[] { "Warrior3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 39.99)
            {
                return false;
            }

            a.ChangeWarrior(-3);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior3",
                "Warrior4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior3+"
                },
                new string[] { "Warrior4+" }
            );
            UpdateNameSuffix(a, "Warrior4");

            return true;
        }

        public static bool Warrior5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 37)
            {
                upTrait("特质", "Warrior3", a, new string[] { "Warrior4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 79.99)
            {
                return false;
            }

            a.ChangeWarrior(-4);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior4",
                "Warrior5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior4+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior5+", selectedTrait } :
                new string[] { "Warrior5+" }
            );
            UpdateNameSuffix(a, "Warrior5");

            return true;
        }

        public static bool Warrior6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 76)
            {
                upTrait("特质", "Warrior4", a, new string[] { "Warrior5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 99.99)
            {
                return false;
            }

            a.ChangeWarrior(-5);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior5",
                "Warrior6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior5+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior6+", "freeze_proof", "fire_proof", selectedTrait } :
                new string[] { "Warrior6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "Warrior6");

            return true;
        }

        public static bool Warrior7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 95)
            {
                upTrait("特质", "Warrior6", a, new string[] { "Warrior7" }, new string[] { });
                return true;
            }

            if (a.GetWarrior() <= 299.99)
            {
                return false;
            }

            a.ChangeWarrior(-6);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior6",
                "Warrior7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior6+" },
                new string[] { "Warrior7+" }
            );
            UpdateNameSuffix(a, "Warrior7");
            ApplyWarriorTitle(a, "Warrior7");

            string[] GongFa = { "GongFaTrait1", "GongFaTrait2", "GongFaTrait3", "GongFaTrait4", "GongFaTrait5", "GongFaTrait6", "GongFaTrait7", "GongFaTrait8", "GongFaTrait9", "GongFaTrait10", "GongFaTrait11", "GongFaTrait12", "GongFaTrait13" };
            int randomIndex = UnityEngine.Random.Range(0, GongFa.Length);
            string selectedGongFa = GongFa[randomIndex];
            a.addTrait(selectedGongFa);

            return true;
        }

        public static bool Warrior8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 499.99)
            {
                return false;
            }

            a.ChangeWarrior(-9);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior7",
                "Warrior8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior7+" },
                new string[] { "Warrior8+", "strong_minded", "immune" }
            );
            UpdateNameSuffix(a, "Warrior8");

            return true;
        }

        public static bool Warrior9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 799.99)
            {
                return false;
            }

            a.ChangeWarrior(-15);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04; 
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior8",
                "Warrior9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior8+" },
                new string[] { "Warrior9+" ,"fire_proof"}
            );
            UpdateNameSuffix(a, "Warrior9");

            // 确保获得防火特质
            a.addTrait("fire_proof");

            return true;
        }

        public static bool Warrior91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 999.99)
            {
                return false;
            }

            a.ChangeWarrior(-20);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior9",
                "Warrior91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior9+" },
                new string[] { "Warrior91+" }
            );
            UpdateNameSuffix(a, "Warrior91");
            ApplyWarriorTitle(a, "Warrior91");

            string[] arcaneTomes = { "arcaneTome1", "arcaneTome2", "arcaneTome3", "arcaneTome4", "arcaneTome5", "arcaneTome6", "arcaneTome7", "arcaneTome8", "arcaneTome9", "arcaneTome10", "arcaneTome11", "arcaneTome12", "arcaneTome13" }; // 可以添加更多传承法特质名
            int randomIndex = UnityEngine.Random.Range(0, arcaneTomes.Length);
            string selectedarcaneTome = arcaneTomes[randomIndex];
            a.addTrait(selectedarcaneTome);

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior9", "Warrior91");
            a.data.favorite = true;

            return true;
        }

        public static bool Warrior92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 2999.99)
            {
                return false;
            }

            a.ChangeWarrior(-30);
            double successRate = 0.06;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.03;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior91",
                "Warrior92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior91+" },
                new string[] { "Warrior92+" }
            );
            UpdateNameSuffix(a, "Warrior92");

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Warrior91", "Warrior92");

            return true;
        }

        public static bool Warrior93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetWarrior() <= 8999.99)
            {
                return false;
            }

            a.ChangeWarrior(-60);
            double successRate = 0.02;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior92",
                "Warrior93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior92+" },
                new string[] { "Warrior93+", "immunity" }
            );
            UpdateNameSuffix(a, "Warrior93");
            ApplyWarriorTitle(a, "Warrior93");

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior92", "Warrior93");

            // 随机获得一到三个九字秘特质
            string[] nineCharacterSecrets = { "NineCharacterSecret1", "NineCharacterSecret2", /* 其他九字秘特质名 */ };
            int traitCount = UnityEngine.Random.Range(1, 4);
            List<string> selectedTraits = new List<string>();

            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, nineCharacterSecrets.Length);
                string selectedTrait = nineCharacterSecrets[randomIndex];
                if (!selectedTraits.Contains(selectedTrait))
                {
                    selectedTraits.Add(selectedTrait);
                    a.addTrait(selectedTrait);
                }
            }

            return true;
        }

        
        //武者的恢复生命值效果
        public static bool Warrior1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}