using UnityEngine;

namespace VideoCopilot.code.utils
{
    public static class ActorExtensions
    {
        private const string warrior_key = "wushu.warriorNum";
        private const string true_gang_key = "wushu.trueGangNum";
        private const string lifespan_key = "strings.S.lifespan";
        private const string true_gang_true_damage_multiplier_key = "wushu.trueGangTrueDamageMultiplier";
        private const string true_gang_heal_multiplier_key = "wushu.trueGangHealMultiplier";
        private const string true_gang_damage_reduction_multiplier_key = "wushu.trueGangDamageReductionMultiplier";

        public static float GetWarrior(this Actor actor)
        {
            actor.data.get(warrior_key, out float val, 0);
            return val;
        }

        public static void SetWarrior(this Actor actor, float val)
        {
            actor.data.set(warrior_key, val);
        }

        public static void ChangeWarrior(this Actor actor, float delta)
        {
            actor.data.get(warrior_key, out float val, 0);
            val += delta;
            actor.data.set(warrior_key, Mathf.Max(0, val));
        }

        // 获取角色当前境界
        public static int GetWarriorLevel(this Actor actor)
        {
            // 从高境界到低境界检查，确保返回最高境界
            if (actor.hasTrait("Warrior93") || actor.hasTrait("Warrior93+")) // 武极境
                return 13;
            if (actor.hasTrait("Warrior92") || actor.hasTrait("Warrior92+")) // 斩我境
                return 12;
            if (actor.hasTrait("Warrior91") || actor.hasTrait("Warrior91+")) // 合道境
                return 11;
            if (actor.hasTrait("Warrior9") || actor.hasTrait("Warrior9+")) // 武域境
                return 10;
            if (actor.hasTrait("Warrior8") || actor.hasTrait("Warrior8+")) // 劫身境
                return 9;
            if (actor.hasTrait("Warrior7") || actor.hasTrait("Warrior7+")) // 洞虚境
                return 8;
            if (actor.hasTrait("Warrior6") || actor.hasTrait("Warrior6+")) // 凝罡境
                return 7;
            if (actor.hasTrait("Warrior5") || actor.hasTrait("Warrior5+")) // 化劲境
                return 6;
            if (actor.hasTrait("Warrior4") || actor.hasTrait("Warrior4+")) // 气海境(高)
                return 5;
            if (actor.hasTrait("Warrior3") || actor.hasTrait("Warrior3+")) // 气海境(低)
                return 4;
            if (actor.hasTrait("Warrior2") || actor.hasTrait("Warrior2+")) // 通脉境
                return 3;
            if (actor.hasTrait("Warrior1") || actor.hasTrait("Warrior1+")) // 炼骨境
                return 2;
            
            return 1; // 默认锻体境
        }

        // 获取对应境界的真罡上限
        public static float GetTrueGangLimitByLevel(int level)
        {
            switch (level)
            {
                case 1: // 锻体境
                    return 50f;
                case 2: // 炼骨境
                    return 100f;
                case 3: // 通脉境
                    return 200f;
                case 4: // 气海境(低)
                    return 400f;
                case 5: // 气海境(高)
                    return 800f;
                case 6: // 化劲境
                    return 1600f;
                case 7: // 凝罡境
                    return 3200f;
                case 8: // 洞虚境
                    return 6400f;
                case 9: // 劫身境
                    return 12800f;
                case 10: // 武域境
                    return 25600f;
                case 11: // 合道境
                    return 51200f;
                case 12: // 斩我境
                    return 102400f;
                case 13: // 武极境 - 无上限
                    return float.MaxValue;
                default:
                    return 100f; // 默认锻体境上限
            }
        }

        // 真罡相关的扩展方法
        public static float GetTrueGang(this Actor actor)
        {
            actor.data.get(true_gang_key, out float val, 0);
            return val;
        }

        public static void SetTrueGang(this Actor actor, float val)
        {
            int level = actor.GetWarriorLevel();
            float limit = GetTrueGangLimitByLevel(level);
            val = Mathf.Max(0, Mathf.Min(val, limit));
            
            actor.data.set(true_gang_key, val);
            
            // 真罡值设置后，更新静态属性
            actor.CalculateTrueGangStaticProperties();
        }

        public static void ChangeTrueGang(this Actor actor, float delta)
        {
            actor.data.get(true_gang_key, out float val, 0);
            val += delta;
            
            int level = actor.GetWarriorLevel();
            float limit = GetTrueGangLimitByLevel(level);
            val = Mathf.Max(0, Mathf.Min(val, limit));
            
            actor.data.set(true_gang_key, val);
            
            // 真罡值变化后，更新静态属性
            actor.CalculateTrueGangStaticProperties();
        }

        // 真罡真伤倍数相关的扩展方法
        public static float GetTrueGangTrueDamageMultiplier(this Actor actor)
        {
            actor.data.get(true_gang_true_damage_multiplier_key, out float val, 0.5f); // 默认0.5倍
            return val;
        }

        public static void SetTrueGangTrueDamageMultiplier(this Actor actor, float val)
        {
            actor.data.set(true_gang_true_damage_multiplier_key, val);
        }

        // 真罡回血倍数相关的扩展方法
        public static float GetTrueGangHealMultiplier(this Actor actor)
        {
            actor.data.get(true_gang_heal_multiplier_key, out float val, 0.5f); // 默认0.5倍
            return val;
        }

        public static void SetTrueGangHealMultiplier(this Actor actor, float val)
        {
            actor.data.set(true_gang_heal_multiplier_key, val);
        }

        // 真罡伤害稀释倍数相关的扩展方法
        public static float GetTrueGangDamageReductionMultiplier(this Actor actor)
        {
            actor.data.get(true_gang_damage_reduction_multiplier_key, out float val, 1.0f); // 默认1倍（无稀释）
            return val;
        }

        public static void SetTrueGangDamageReductionMultiplier(this Actor actor, float val)
        {
            actor.data.set(true_gang_damage_reduction_multiplier_key, val);
        }

        // 计算并更新真罡相关静态属性
        public static void CalculateTrueGangStaticProperties(this Actor actor)
        {
            float trueGangValue = actor.GetTrueGang();
            
            // 设置默认倍数
            float trueDamageMultiplier = 0.5f;
            float healMultiplier = 0.5f;
            float damageReductionMultiplier = 1.0f;
            
            // 可以根据真罡值调整倍数（如果需要的话）
            // 这里保持与原逻辑一致
            
            actor.SetTrueGangTrueDamageMultiplier(trueDamageMultiplier);
            actor.SetTrueGangHealMultiplier(healMultiplier);
            actor.SetTrueGangDamageReductionMultiplier(damageReductionMultiplier);
        }
    }
}