﻿using UnityEngine;

namespace VideoCopilot.code.utils
{
    public static class ActorExtensions
    {
        private const string warrior_key = "wushu.warriorNum";
        private const string lifespan_key = "strings.S.lifespan";

        public static float GetWarrior(this Actor actor)
        {
            actor.data.get(warrior_key, out float val, 0);
            return val;
        }

        public static void SetWarrior(this Actor actor, float val)
        {
            actor.data.set(warrior_key, val);
        }

        public static void ChangeWarrior(this Actor actor, float delta)
        {
            actor.data.get(warrior_key, out float val, 0);
            val += delta;
            actor.data.set(warrior_key, Mathf.Max(0, val));
        }
    }
}