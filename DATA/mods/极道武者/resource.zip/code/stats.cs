﻿namespace PeerlessOverpoweringWarrior.code
{
    internal class stats
    {
        public static BaseStatAsset Resist;

        public static void Init()
        {
            BaseStatAsset Warrior = new BaseStatAsset();
            Warrior.id = "Warrior";
            Warrior.normalize = true;
            Warrior.normalize_min = -999999;
            Warrior.normalize_max = 999999;
            //Warrior.multiplier = true;
            Warrior.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Warrior);

            // 定义 Resist 属性
            Resist = new BaseStatAsset();
            Resist.id = "Resist";
            Resist.normalize = true;
            Resist.normalize_min = 0;
            Resist.normalize_max = 999999;
            Resist.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Resist);

            BaseStatAsset Dodge = new BaseStatAsset();
            Dodge.id = "Dodge";// 闪避率
            Dodge.normalize = true;
            Dodge.normalize_min = 0;
            Dodge.normalize_max = 99999;
            Dodge.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Dodge);

            BaseStatAsset Accuracy = new BaseStatAsset();
            Accuracy.id = "Accuracy";// 命中率
            Accuracy.normalize = true;
            Accuracy.normalize_min = 0;
            Accuracy.normalize_max = 99999;
            Accuracy.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Accuracy);
        }
    }
}