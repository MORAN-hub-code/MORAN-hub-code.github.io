﻿namespace PeerlessOverpoweringWarrior.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset Warrior = new BaseStatAsset();
            Warrior.id = "Warrior";
            Warrior.normalize = true;
            Warrior.normalize_min = -999999;
            Warrior.normalize_max = 999999;
            //Warrior.multiplier = true;
            Warrior.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Warrior);
        }
    }
}