﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using strings;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        public static ActorTrait martialAptitude_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait martialAptitude = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "MartialFoundations",
                needs_to_be_explored = false
            };
            martialAptitude.action_special_effect += traitAction.Warrior1_effectAction;
            AssetManager.traits.add(martialAptitude);
            return martialAptitude;
        }
        public static void Init()
        {
            _=martialAptitude_AddActorTrait("martialAptitude1", "trait/martialAptitude1");
            _=martialAptitude_AddActorTrait("martialAptitude2", "trait/martialAptitude2");
            _=martialAptitude_AddActorTrait("martialAptitude3", "trait/martialAptitude3");
            _=martialAptitude_AddActorTrait("martialAptitude4", "trait/martialAptitude4");
            _=martialAptitude_AddActorTrait("martialAptitude7", "trait/martialAptitude7");
            _=martialAptitude_AddActorTrait("martialAptitude8", "trait/martialAptitude8");

            ActorTrait martialAptitude9 = CreateTrait("martialAptitude9", "trait/martialAptitude9", "MartialFoundations");
            martialAptitude9.rate_inherit = 100;
            AssetManager.traits.add(martialAptitude9);

            ActorTrait martialAptitude10 = CreateTrait("martialAptitude10", "trait/martialAptitude10", "MartialFoundations");
            AssetManager.traits.add(martialAptitude10);

            ActorTrait Warrior02 = CreateTrait("Warrior2+", "trait/Warrior2+", "Warrior");
            SafeSetStat(Warrior02.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(Warrior02.base_stats, strings.S.skill_combat, 0.1f);
            AssetManager.traits.add(Warrior02);

            ActorTrait Warrior03 = CreateTrait("Warrior3+", "trait/Warrior3+", "Warrior");
            SafeSetStat(Warrior03.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(Warrior03.base_stats, strings.S.skill_combat, 0.2f);
            AssetManager.traits.add(Warrior03);

            ActorTrait Warrior04 = CreateTrait("Warrior4+", "trait/Warrior4+", "Warrior");
            SafeSetStat(Warrior04.base_stats , strings.S.lifespan, 30f);
            SafeSetStat(Warrior04.base_stats , strings.S.skill_combat, 0.3f);
            AssetManager.traits.add(Warrior04);

            ActorTrait Warrior05 = CreateTrait("Warrior5+", "trait/Warrior5+", "Warrior");
            SafeSetStat(Warrior05.base_stats , strings.S.lifespan, 50f);
            SafeSetStat(Warrior05.base_stats , strings.S.skill_combat, 0.4f);
            AssetManager.traits.add(Warrior05);

            ActorTrait Warrior06 = CreateTrait("Warrior6+", "trait/Warrior6+", "Warrior");
            SafeSetStat(Warrior06.base_stats , strings.S.lifespan, 80f);
            SafeSetStat(Warrior06.base_stats , strings.S.skill_combat, 0.5f);
            AssetManager.traits.add(Warrior06);

            ActorTrait Warrior07 = CreateTrait("Warrior7+", "trait/Warrior7+", "Warrior");
            SafeSetStat(Warrior07.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(Warrior07.base_stats, strings.S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior07);

            ActorTrait Warrior08 = CreateTrait("Warrior8+", "trait/Warrior8+", "Warrior");
            SafeSetStat(Warrior08.base_stats, strings.S.lifespan, 150f);
            SafeSetStat(Warrior08.base_stats, strings.S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior08);

            ActorTrait Warrior09 = CreateTrait("Warrior9+", "trait/Warrior9+", "Warrior");
            SafeSetStat(Warrior09.base_stats, strings.S.lifespan, 240f);
            SafeSetStat(Warrior09.base_stats, strings.S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior09);

            ActorTrait Warrior091 = CreateTrait("Warrior91+", "trait/Warrior91+", "Warrior");
            SafeSetStat(Warrior091.base_stats, strings.S.lifespan, 400f);
            SafeSetStat(Warrior091.base_stats, strings.S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior091);

            ActorTrait Warrior092 = CreateTrait("Warrior92+", "trait/Warrior92+", "Warrior");
            SafeSetStat(Warrior092.base_stats, strings.S.lifespan, 800f);
            SafeSetStat(Warrior092.base_stats, strings.S.skill_combat, 0.7f);
            AssetManager.traits.add(Warrior092);

            ActorTrait Warrior093 = CreateTrait("Warrior93+", "trait/Warrior93+", "Warrior");
            SafeSetStat(Warrior093.base_stats, strings.S.lifespan, 10000f);
            SafeSetStat(Warrior093.base_stats, strings.S.skill_combat, 0.8f);
            AssetManager.traits.add(Warrior093);

            ActorTrait Warrior1 = CreateTrait("Warrior1", "trait/Warrior1", "Warrior");
            SafeSetStat(Warrior1.base_stats, stats.knockback_reduction.id, 0.5f);
            SafeSetStat(Warrior1.base_stats, strings.S.damage, 100f);
            SafeSetStat(Warrior1.base_stats, strings.S.mass, 5.0f);
            SafeSetStat(Warrior1.base_stats, strings.S.health, 200f);
            SafeSetStat(Warrior1.base_stats, strings.S.stamina, 10f);
            SafeSetStat(Warrior1.base_stats, "Shanbi", 20f);
            SafeSetStat(Warrior1.base_stats, "Mingzhong", 10f);
            Warrior1.action_special_effect += traitAction.Warrior2_effectAction;
            Warrior1.action_special_effect += traitAction.Warrior1_Regen;
            AssetManager.traits.add(Warrior1);

            ActorTrait Warrior2 = CreateTrait("Warrior2", "trait/Warrior2", "Warrior");
            SafeSetStat(Warrior2.base_stats, stats.knockback_reduction.id, 1.0f);
            SafeSetStat(Warrior2.base_stats , strings.S.damage, 200f);
            SafeSetStat(Warrior2.base_stats, strings.S.mass, 10f);
            SafeSetStat(Warrior2.base_stats , strings.S.health, 400f);
            SafeSetStat(Warrior2.base_stats , strings.S.accuracy, 2f);
            SafeSetStat(Warrior2.base_stats , strings.S.multiplier_speed, 0.1f);
            SafeSetStat(Warrior2.base_stats , strings.S.stamina, 20f);
            SafeSetStat(Warrior2.base_stats, "Shanbi", 30f);
            SafeSetStat(Warrior2.base_stats, "Mingzhong", 10f);
            Warrior2.action_special_effect += traitAction.Warrior3_effectAction;
            Warrior2.action_special_effect += traitAction.Warrior2_Regen;
            AssetManager.traits.add(Warrior2);

            ActorTrait Warrior3 = CreateTrait("Warrior3", "trait/Warrior3", "Warrior");
            SafeSetStat(Warrior3.base_stats, stats.knockback_reduction.id, 2.0f);
            SafeSetStat(Warrior3.base_stats , strings.S.damage, 400f);
            SafeSetStat(Warrior3.base_stats, strings.S.mass, 10f);
            SafeSetStat(Warrior3.base_stats , strings.S.health, 800f);
            SafeSetStat(Warrior3.base_stats , strings.S.armor, 5f);
            SafeSetStat(Warrior3.base_stats , strings.S.targets, 0.1f);
            SafeSetStat(Warrior3.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(Warrior3.base_stats , strings.S.multiplier_speed, 0.2f);
            SafeSetStat(Warrior3.base_stats , strings.S.stamina, 30f);
            SafeSetStat(Warrior3.base_stats, "Shanbi", 40f);
            SafeSetStat(Warrior3.base_stats, "Mingzhong", 10f);
            Warrior3.action_special_effect += traitAction.Warrior4_effectAction;
            Warrior3.action_special_effect += traitAction.Warrior3_Regen;
            AssetManager.traits.add(Warrior3);

            ActorTrait Warrior4 = CreateTrait("Warrior4", "trait/Warrior4", "Warrior");
            SafeSetStat(Warrior4.base_stats, stats.knockback_reduction.id, 4.0f);
            SafeSetStat(Warrior4.base_stats , strings.S.damage, 500f);
            SafeSetStat(Warrior4.base_stats, strings.S.mass, 10f);
            SafeSetStat(Warrior4.base_stats , strings.S.health, 1000f);
            SafeSetStat(Warrior4.base_stats , strings.S.speed, 5f);
            SafeSetStat(Warrior4.base_stats , strings.S.armor, 10f);
            SafeSetStat(Warrior4.base_stats , strings.S.targets, 1f);
            SafeSetStat(Warrior4.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(Warrior4.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(Warrior4.base_stats , strings.S.multiplier_speed, 0.3f);
            SafeSetStat(Warrior4.base_stats , strings.S.stamina, 40f);
            SafeSetStat(Warrior4.base_stats, "Shanbi", 50f);
            SafeSetStat(Warrior4.base_stats, "Mingzhong", 10f);
            Warrior4.action_special_effect += traitAction.Warrior5_effectAction;
            Warrior4.action_special_effect += traitAction.Warrior4_Regen;
            AssetManager.traits.add(Warrior4);

            ActorTrait Warrior5 = CreateTrait("Warrior5", "trait/Warrior5", "Warrior");
            SafeSetStat(Warrior5.base_stats, stats.knockback_reduction.id, 8.0f);
            SafeSetStat(Warrior5.base_stats , strings.S.warfare, 10f);
            SafeSetStat(Warrior5.base_stats, strings.S.mass, 15f);
            SafeSetStat(Warrior5.base_stats , strings.S.damage, 1000f);
            SafeSetStat(Warrior5.base_stats , strings.S.health, 3000f);
            SafeSetStat(Warrior5.base_stats , strings.S.speed, 10f);
            SafeSetStat(Warrior5.base_stats , strings.S.armor, 15f);
            SafeSetStat(Warrior5.base_stats , strings.S.targets, 2f);
            SafeSetStat(Warrior5.base_stats , strings.S.critical_chance, 0.3f);
            SafeSetStat(Warrior5.base_stats , strings.S.accuracy, 20f);
            SafeSetStat(Warrior5.base_stats , strings.S.multiplier_speed, 0.4f);
            SafeSetStat(Warrior5.base_stats , strings.S.stamina, 50f);
            SafeSetStat(Warrior5.base_stats, "Shanbi", 80f);
            SafeSetStat(Warrior5.base_stats, "Mingzhong", 40f);
            Warrior5.action_special_effect += traitAction.Warrior6_effectAction;
            Warrior5.action_special_effect += traitAction.Warrior5_Regen;
            AssetManager.traits.add(Warrior5);

            ActorTrait Warrior6 = CreateTrait("Warrior6", "trait/Warrior6", "Warrior");
            SafeSetStat(Warrior6.base_stats, stats.knockback_reduction.id, 16.0f);
            SafeSetStat(Warrior6.base_stats , strings.S.warfare, 20f);
            SafeSetStat(Warrior6.base_stats, strings.S.mass, 20f);
            SafeSetStat(Warrior6.base_stats , strings.S.damage, 2000f);
            SafeSetStat(Warrior6.base_stats , strings.S.armor, 25f);
            SafeSetStat(Warrior6.base_stats , strings.S.health, 6000f);
            SafeSetStat(Warrior6.base_stats , strings.S.speed, 15f);
            SafeSetStat(Warrior6.base_stats , strings.S.area_of_effect, 1f);
            SafeSetStat(Warrior6.base_stats , strings.S.targets, 5f);
            SafeSetStat(Warrior6.base_stats , strings.S.critical_chance, 0.5f);
            SafeSetStat(Warrior6.base_stats , strings.S.accuracy, 30f);
            SafeSetStat(Warrior6.base_stats , strings.S.multiplier_speed, 0.6f);
            SafeSetStat(Warrior6.base_stats , strings.S.stamina, 70f);
            SafeSetStat(Warrior6.base_stats, "Shanbi", 100f);
            SafeSetStat(Warrior6.base_stats, "Mingzhong", 60f);
            Warrior6.action_special_effect += traitAction.Warrior7_effectAction;
            Warrior6.action_special_effect += traitAction.Warrior6_Regen;
            Warrior6.action_attack_target += traitAction.TrueDamage1_AttackAction;
            AssetManager.traits.add(Warrior6);

            ActorTrait Warrior7 = CreateTrait("Warrior7", "trait/Warrior7", "Warrior");
            SafeSetStat(Warrior7.base_stats, stats.knockback_reduction.id, 32.0f);
            SafeSetStat(Warrior7.base_stats, strings.S.warfare, 30f);
            SafeSetStat(Warrior7.base_stats, strings.S.damage, 4000f);
            SafeSetStat(Warrior7.base_stats, strings.S.mass, 25f);
            SafeSetStat(Warrior7.base_stats, strings.S.armor, 35f);
            SafeSetStat(Warrior7.base_stats, strings.S.health, 8000f);
            SafeSetStat(Warrior7.base_stats, strings.S.speed, 20f);
            SafeSetStat(Warrior7.base_stats, strings.S.area_of_effect, 2f);
            SafeSetStat(Warrior7.base_stats, strings.S.targets, 7f);
            SafeSetStat(Warrior7.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(Warrior7.base_stats, strings.S.accuracy, 40f);
            SafeSetStat(Warrior7.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(Warrior7.base_stats, strings.S.stamina, 140f);
            SafeSetStat(Warrior7.base_stats, strings.S.range, 2f);
            SafeSetStat(Warrior7.base_stats, strings.S.attack_speed, 2f);
            SafeSetStat(Warrior7.base_stats, strings.S.scale, 0.04f);
            SafeSetStat(Warrior7.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(Warrior7.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(Warrior7.base_stats, "Shanbi", 120f);
            SafeSetStat(Warrior7.base_stats, "Mingzhong", 80f);
            Warrior7.action_attack_target += traitAction.TrueDamage2_AttackAction;
            Warrior7.action_special_effect += traitAction.Warrior8_effectAction;
            Warrior7.action_special_effect += traitAction.Warrior7_Regen;
            AssetManager.traits.add(Warrior7);

            ActorTrait Warrior8 = CreateTrait("Warrior8", "trait/Warrior8", "Warrior");
            SafeSetStat(Warrior8.base_stats, stats.knockback_reduction.id, 64.0f);
            SafeSetStat(Warrior8.base_stats, strings.S.warfare, 40f);
            SafeSetStat(Warrior8.base_stats, strings.S.damage, 8000f);
            SafeSetStat(Warrior8.base_stats, strings.S.mass, 60f);
            SafeSetStat(Warrior8.base_stats, strings.S.armor, 45f);
            SafeSetStat(Warrior8.base_stats, strings.S.health, 16000f);
            SafeSetStat(Warrior8.base_stats, strings.S.speed, 25f);
            SafeSetStat(Warrior8.base_stats, strings.S.area_of_effect, 3f);
            SafeSetStat(Warrior8.base_stats, strings.S.targets, 9f);
            SafeSetStat(Warrior8.base_stats, strings.S.critical_chance, 0.7f);
            SafeSetStat(Warrior8.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(Warrior8.base_stats, strings.S.multiplier_speed, 1.0f);
            SafeSetStat(Warrior8.base_stats, strings.S.stamina, 240f);
            SafeSetStat(Warrior8.base_stats, strings.S.range, 4f);
            SafeSetStat(Warrior8.base_stats, strings.S.attack_speed, 4f);
            SafeSetStat(Warrior8.base_stats, strings.S.multiplier_health, 0.4f);
            SafeSetStat(Warrior8.base_stats, strings.S.multiplier_damage, 0.4f);
            SafeSetStat(Warrior8.base_stats, strings.S.scale, 0.06f);
            SafeSetStat(Warrior8.base_stats, "Shanbi", 160f);
            SafeSetStat(Warrior8.base_stats, "Mingzhong", 120f);
            Warrior8.action_attack_target += traitAction.TrueDamage3_AttackAction;
            Warrior8.action_special_effect += traitAction.Warrior9_effectAction;
            Warrior8.action_special_effect += traitAction.Warrior8_Regen;
            AssetManager.traits.add(Warrior8);

            ActorTrait Warrior9 = CreateTrait("Warrior9", "trait/Warrior9", "Warrior");
            SafeSetStat(Warrior9.base_stats, stats.knockback_reduction.id, 128.0f);
            SafeSetStat(Warrior9.base_stats, strings.S.warfare, 50f);
            SafeSetStat(Warrior9.base_stats, strings.S.damage, 16000f);
            SafeSetStat(Warrior9.base_stats, strings.S.mass, 140f);
            SafeSetStat(Warrior9.base_stats, strings.S.armor, 60f);
            SafeSetStat(Warrior9.base_stats, strings.S.health, 32000f);
            SafeSetStat(Warrior9.base_stats, strings.S.speed, 30f);
            SafeSetStat(Warrior9.base_stats, strings.S.area_of_effect, 4f);
            SafeSetStat(Warrior9.base_stats, strings.S.targets, 12f);
            SafeSetStat(Warrior9.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(Warrior9.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(Warrior9.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(Warrior9.base_stats, strings.S.stamina, 400f);
            SafeSetStat(Warrior9.base_stats, strings.S.range, 6f);
            SafeSetStat(Warrior9.base_stats, strings.S.attack_speed, 6f);
            SafeSetStat(Warrior9.base_stats, strings.S.scale, 0.08f);
            SafeSetStat(Warrior9.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(Warrior9.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(Warrior9.base_stats, "Shanbi", 200f);
            SafeSetStat(Warrior9.base_stats, "Mingzhong", 160f);
            Warrior9.action_attack_target += traitAction.TrueDamage4_AttackAction;
            Warrior9.action_special_effect += traitAction.Warrior91_effectAction;
            Warrior9.action_special_effect += traitAction.Warrior9_Regen;
            AssetManager.traits.add(Warrior9);

            ActorTrait Warrior91 = CreateTrait("Warrior91", "trait/Warrior91", "Warrior");
            SafeSetStat(Warrior91.base_stats, stats.knockback_reduction.id, 160.0f);
            SafeSetStat(Warrior91.base_stats, strings.S.warfare, 70f);
            SafeSetStat(Warrior91.base_stats, strings.S.damage, 32000f);
            SafeSetStat(Warrior91.base_stats, strings.S.mass, 400f);
            SafeSetStat(Warrior91.base_stats, strings.S.armor, 80f);
            SafeSetStat(Warrior91.base_stats, strings.S.health, 80000f);
            SafeSetStat(Warrior91.base_stats, strings.S.speed, 50f);
            SafeSetStat(Warrior91.base_stats, strings.S.area_of_effect, 5f);
            SafeSetStat(Warrior91.base_stats, strings.S.targets, 15f);
            SafeSetStat(Warrior91.base_stats, strings.S.critical_chance, 0.9f);
            SafeSetStat(Warrior91.base_stats, strings.S.accuracy, 80f);
            SafeSetStat(Warrior91.base_stats, strings.S.multiplier_speed, 1.5f);
            SafeSetStat(Warrior91.base_stats, strings.S.stamina, 600f);
            SafeSetStat(Warrior91.base_stats, strings.S.range, 12f);
            SafeSetStat(Warrior91.base_stats, strings.S.attack_speed, 12f);
            SafeSetStat(Warrior91.base_stats, strings.S.scale, 0.1f);
            SafeSetStat(Warrior91.base_stats, strings.S.multiplier_health, 1.2f);
            SafeSetStat(Warrior91.base_stats, strings.S.multiplier_damage, 1.2f);
            SafeSetStat(Warrior91.base_stats, "Shanbi", 240f);
            SafeSetStat(Warrior91.base_stats, "Mingzhong", 200f);
            Warrior91.action_special_effect += traitAction.Warrior92_effectAction;
            Warrior91.action_special_effect += traitAction.Warrior91_Regen;
            Warrior91.action_attack_target += traitAction.TrueDamage5_AttackAction;
            AssetManager.traits.add(Warrior91);

            ActorTrait Warrior92 = CreateTrait("Warrior92", "trait/Warrior92", "Warrior");
            SafeSetStat(Warrior92.base_stats, stats.knockback_reduction.id, 200.0f);
            SafeSetStat(Warrior92.base_stats, strings.S.warfare, 100f);
            SafeSetStat(Warrior92.base_stats, strings.S.damage, 64000f);
            SafeSetStat(Warrior92.base_stats, strings.S.mass, 1600f);
            SafeSetStat(Warrior92.base_stats, strings.S.armor, 100f);
            SafeSetStat(Warrior92.base_stats, strings.S.health, 248000f);
            SafeSetStat(Warrior92.base_stats, strings.S.speed, 100f);
            SafeSetStat(Warrior92.base_stats, strings.S.area_of_effect, 7f);
            SafeSetStat(Warrior92.base_stats, strings.S.targets, 20f);
            SafeSetStat(Warrior92.base_stats, strings.S.critical_chance, 1.0f);
            SafeSetStat(Warrior92.base_stats, strings.S.accuracy, 100f);
            SafeSetStat(Warrior92.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(Warrior92.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(Warrior92.base_stats, strings.S.range, 20f);
            SafeSetStat(Warrior92.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(Warrior92.base_stats, strings.S.scale, 0.15f);
            SafeSetStat(Warrior92.base_stats, strings.S.multiplier_health, 2f);
            SafeSetStat(Warrior92.base_stats, strings.S.multiplier_damage, 2f);
            SafeSetStat(Warrior92.base_stats, "Shanbi", 300f);
            SafeSetStat(Warrior92.base_stats, "Mingzhong", 260f);
            Warrior92.action_special_effect += traitAction.Warrior93_effectAction;
            Warrior92.action_special_effect += traitAction.Warrior92_Regen;
            Warrior92.action_attack_target += traitAction.TrueDamage6_AttackAction;
            AssetManager.traits.add(Warrior92);

            ActorTrait Warrior93 = CreateTrait("Warrior93", "trait/Warrior93", "Warrior");
            SafeSetStat(Warrior93.base_stats, stats.knockback_reduction.id, 240.0f);
            SafeSetStat(Warrior93.base_stats, strings.S.warfare, 150f);
            SafeSetStat(Warrior93.base_stats, strings.S.damage, 128000f);
            SafeSetStat(Warrior93.base_stats, strings.S.mass, 2400f);
            SafeSetStat(Warrior93.base_stats, strings.S.armor, 150f);
            SafeSetStat(Warrior93.base_stats, strings.S.health, 800000f);
            SafeSetStat(Warrior93.base_stats, strings.S.speed, 300f);
            SafeSetStat(Warrior93.base_stats, strings.S.area_of_effect, 10f);
            SafeSetStat(Warrior93.base_stats, strings.S.targets, 25f);
            SafeSetStat(Warrior93.base_stats, strings.S.critical_chance, 1.5f);
            SafeSetStat(Warrior93.base_stats, strings.S.accuracy, 150f);
            SafeSetStat(Warrior93.base_stats, strings.S.multiplier_speed, 3.0f);
            SafeSetStat(Warrior93.base_stats, strings.S.stamina, 10000f);
            SafeSetStat(Warrior93.base_stats, strings.S.range, 30f);
            SafeSetStat(Warrior93.base_stats, strings.S.attack_speed, 30f);
            SafeSetStat(Warrior93.base_stats, strings.S.scale, 0.2f);
            SafeSetStat(Warrior93.base_stats, strings.S.multiplier_health, 3f);
            SafeSetStat(Warrior93.base_stats, strings.S.multiplier_damage, 3f);    
            SafeSetStat(Warrior93.base_stats, "Shanbi", 400f);
            SafeSetStat(Warrior93.base_stats, "Mingzhong", 370f);
            Warrior93.action_attack_target += traitAction.lei3_attackAction;
            Warrior93.action_special_effect += traitAction.Warrior93_Regen;
            Warrior93.action_attack_target += traitAction.TrueDamage7_AttackAction;
            AssetManager.traits.add(Warrior93);

            ActorTrait arcaneTome1 = CreateTrait("arcaneTome1", "trait/arcaneTome1", "arcaneTome");
            SafeSetStat(arcaneTome1.base_stats, strings.S.damage, 500f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.health, 500f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.speed, 30f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.armor, 15f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.stamina, 80f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.attack_speed, 80f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome1.base_stats, strings.S.multiplier_damage, 0.1f);
            arcaneTome1.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome1);

            ActorTrait arcaneTome2 = CreateTrait("arcaneTome2", "trait/arcaneTome2", "arcaneTome");
            SafeSetStat(arcaneTome2.base_stats, strings.S.speed, 80f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.armor, 20f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.damage, 800f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.health, 400f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.stamina, 50f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome2.base_stats, strings.S.multiplier_speed, 0.2f);
            arcaneTome2.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome2);

            ActorTrait arcaneTome3 = CreateTrait("arcaneTome3", "trait/arcaneTome3", "arcaneTome");
            SafeSetStat(arcaneTome3.base_stats, strings.S.damage, 200f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.health, 1000f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.speed, 10f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.armor, 80f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.lifespan, 50f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.stamina, 200f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(arcaneTome3.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome3.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome3);

            ActorTrait arcaneTome4 = CreateTrait("arcaneTome4", "trait/arcaneTome4", "arcaneTome");
            SafeSetStat(arcaneTome4.base_stats, strings.S.speed, 60f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.armor, 50f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.damage, 400f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.health, 400f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.stamina, 120f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.attack_speed, 10f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome4.base_stats, strings.S.multiplier_speed, 0.3f);
            arcaneTome4.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome4);

            ActorTrait arcaneTome5 = CreateTrait("arcaneTome5", "trait/arcaneTome5", "arcaneTome");
            SafeSetStat(arcaneTome5.base_stats, strings.S.speed, 40f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.armor, 60f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.health, 200f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.damage, 300f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.lifespan, 300f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.stamina, 30f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome5.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome5.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome5);

            ActorTrait arcaneTome6 = CreateTrait("arcaneTome6", "trait/arcaneTome6", "arcaneTome");
            SafeSetStat(arcaneTome6.base_stats, strings.S.speed, 50f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.armor, 50f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.health, 100f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.damage, 200f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.stamina, 90f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.attack_speed, 70f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome6.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome6.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome6);

            ActorTrait arcaneTome7 = CreateTrait("arcaneTome7", "trait/arcaneTome7", "arcaneTome");
            SafeSetStat(arcaneTome7.base_stats, strings.S.speed, 60f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.armor, 20f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.health, 180f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.damage, 120f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.lifespan, 50f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.stamina, 40f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome7.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome7.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome7);

            ActorTrait arcaneTome8 = CreateTrait("arcaneTome8", "trait/arcaneTome8", "arcaneTome");
            SafeSetStat(arcaneTome8.base_stats, strings.S.speed, 45f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.armor, 55f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.health, 600f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.damage, 100f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.lifespan, 40f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.stamina, 70f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.attack_speed, 30f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome8.base_stats, strings.S.multiplier_speed, 0.2f);
            arcaneTome8.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome8);

            ActorTrait arcaneTome9 = CreateTrait("arcaneTome9", "trait/arcaneTome9", "arcaneTome");
            SafeSetStat(arcaneTome9.base_stats, strings.S.speed, 40f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.armor, 60f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.health, 800f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.damage, 240f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.stamina, 90f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.attack_speed, 60f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome9.base_stats, strings.S.multiplier_speed, 0.2f);
            arcaneTome9.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome9);

            ActorTrait arcaneTome10 = CreateTrait("arcaneTome10", "trait/arcaneTome10", "arcaneTome");
            SafeSetStat(arcaneTome10.base_stats, strings.S.speed, 10f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.armor, 10f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.health, 2000f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.damage, 90f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.lifespan, 500f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.stamina, 60f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.attack_speed, 50f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(arcaneTome10.base_stats, strings.S.multiplier_speed, 0.3f);
            arcaneTome10.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome10);

            ActorTrait arcaneTome11 = CreateTrait("arcaneTome11", "trait/arcaneTome11", "arcaneTome");
            SafeSetStat(arcaneTome11.base_stats, strings.S.speed, 10f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.armor, -10f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.health, -50f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.damage, 5000f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.lifespan, -10f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.stamina, -30f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.attack_speed, 100f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(arcaneTome11.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome11.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome11);

            ActorTrait arcaneTome12 = CreateTrait("arcaneTome12", "trait/arcaneTome12", "arcaneTome");
            SafeSetStat(arcaneTome12.base_stats, strings.S.speed, 40f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.armor, 1000f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.health, 10000f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.damage, 40f); 
            SafeSetStat(arcaneTome12.base_stats, strings.S.lifespan, 1000f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.multiplier_damage, 0.5f);
            SafeSetStat(arcaneTome12.base_stats, strings.S.multiplier_speed, 0.5f);
            arcaneTome12.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome12);

            ActorTrait arcaneTome13 = CreateTrait("arcaneTome13", "trait/arcaneTome13", "arcaneTome");
            SafeSetStat(arcaneTome13.base_stats, strings.S.speed, 80f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.armor, 80f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.health, 800f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.damage, 800f); 
            SafeSetStat(arcaneTome13.base_stats, strings.S.lifespan, 80f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.stamina, 80f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.attack_speed, 80f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome13.base_stats, strings.S.multiplier_speed, 0.1f);
            arcaneTome13.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome13);

            ActorTrait arcaneTome91 = CreateTrait("arcaneTome91", "trait/arcaneTome91", "arcaneTome");
            SafeSetStat(arcaneTome91.base_stats, strings.S.speed, 100f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.armor, 100f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.health, 6000f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.damage, 6000f); 
            SafeSetStat(arcaneTome91.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.stamina, 80f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.attack_speed, 600f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.multiplier_health, 9.9f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.multiplier_damage, 9.9f);
            SafeSetStat(arcaneTome91.base_stats, strings.S.multiplier_speed, 9.9f);
            AssetManager.traits.add(arcaneTome91);

            ActorTrait NineCharacterSecret1 = CreateTrait("NineCharacterSecret1", "trait/NineCharacterSecret1", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret1.base_stats, strings.S.multiplier_health, 3.0f);
            SafeSetStat(NineCharacterSecret1.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret1.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret1.base_stats, strings.S.area_of_effect, 4f);
            AssetManager.traits.add(NineCharacterSecret1);

            ActorTrait NineCharacterSecret2 = CreateTrait("NineCharacterSecret2", "trait/NineCharacterSecret2", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.multiplier_damage, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.multiplier_health, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.multiplier_speed, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.intelligence, 100f);
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.area_of_effect, 8f);
            AssetManager.traits.add(NineCharacterSecret2);

            ActorTrait NineCharacterSecret3 = CreateTrait("NineCharacterSecret3", "trait/NineCharacterSecret3", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret3.base_stats, strings.S.multiplier_speed, 3.2f);
            SafeSetStat(NineCharacterSecret2.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret3.base_stats, strings.S.intelligence, 50f);
            SafeSetStat(NineCharacterSecret3.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret3.base_stats, strings.S.area_of_effect, 6f);
            AssetManager.traits.add(NineCharacterSecret3);

            ActorTrait NineCharacterSecret4 = CreateTrait("NineCharacterSecret4", "trait/NineCharacterSecret4", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.multiplier_health, 1.0f);
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.knockback, 5f); 
            SafeSetStat(NineCharacterSecret4.base_stats, strings.S.area_of_effect, 4f);
            AssetManager.traits.add(NineCharacterSecret4);

            ActorTrait NineCharacterSecret5 = CreateTrait("NineCharacterSecret5", "trait/NineCharacterSecret5", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.intelligence, 60f);
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret5.base_stats, strings.S.area_of_effect, 8f);
            AssetManager.traits.add(NineCharacterSecret5);

            ActorTrait NineCharacterSecret6 = CreateTrait("NineCharacterSecret6", "trait/NineCharacterSecret6", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.multiplier_damage, 2.0f);
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret6.base_stats, strings.S.area_of_effect, 10f);
            AssetManager.traits.add(NineCharacterSecret6);

            ActorTrait NineCharacterSecret7 = CreateTrait("NineCharacterSecret7", "trait/NineCharacterSecret7", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.intelligence, 20f);
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret7.base_stats, strings.S.area_of_effect, 6f);
            AssetManager.traits.add(NineCharacterSecret7);

            ActorTrait NineCharacterSecret8 = CreateTrait("NineCharacterSecret8", "trait/NineCharacterSecret8", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.multiplier_speed, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.multiplier_damage, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.multiplier_health, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.intelligence, 1000f);
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.knockback, 100f); 
            SafeSetStat(NineCharacterSecret8.base_stats, strings.S.area_of_effect, 100f);
            AssetManager.traits.add(NineCharacterSecret8);

            ActorTrait NineCharacterSecret9 = CreateTrait("NineCharacterSecret9", "trait/NineCharacterSecret9", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret9.base_stats, strings.S.area_of_effect, 10f);
            AssetManager.traits.add(NineCharacterSecret9);

            ActorTrait GongFaTrait1 = CreateTrait("GongFaTrait1", "trait/GongFaTrait1", "GongFa");
            SafeSetStat(GongFaTrait1.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(GongFaTrait1.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(GongFaTrait1.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(GongFaTrait1.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(GongFaTrait1.base_stats, strings.S.stamina, 15f);
            SafeSetStat(GongFaTrait1.base_stats, strings.S.area_of_effect, 10f);
            GongFaTrait1.rate_inherit = 20;
            AssetManager.traits.add(GongFaTrait1);

            ActorTrait GongFaTrait12 = CreateTrait("GongFaTrait12", "trait/GongFaTrait12", "GongFa");
            SafeSetStat(GongFaTrait12.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(GongFaTrait12.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(GongFaTrait12.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(GongFaTrait12.base_stats, strings.S.lifespan, 12f);
            SafeSetStat(GongFaTrait12.base_stats, strings.S.stamina, 10f);
            SafeSetStat(GongFaTrait12.base_stats, strings.S.area_of_effect, 12f);
            GongFaTrait12.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait12);

            ActorTrait GongFaTrait2 = CreateTrait("GongFaTrait2", "trait/GongFaTrait2", "GongFa");
            SafeSetStat(GongFaTrait2.base_stats, strings.S.multiplier_speed, 0.15f);
            SafeSetStat(GongFaTrait2.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(GongFaTrait2.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(GongFaTrait2.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(GongFaTrait2.base_stats, strings.S.stamina, 11f);
            SafeSetStat(GongFaTrait2.base_stats, strings.S.area_of_effect, 10f);
            GongFaTrait12.rate_inherit = 20;
            AssetManager.traits.add(GongFaTrait2);

            ActorTrait GongFaTrait3 = CreateTrait("GongFaTrait3", "trait/GongFaTrait3", "GongFa");
            SafeSetStat(GongFaTrait3.base_stats, strings.S.multiplier_speed, 0.11f);
            SafeSetStat(GongFaTrait3.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(GongFaTrait3.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(GongFaTrait3.base_stats, strings.S.lifespan, 11f);
            SafeSetStat(GongFaTrait3.base_stats, strings.S.stamina, 19f);
            SafeSetStat(GongFaTrait3.base_stats, strings.S.area_of_effect, 11f);
            GongFaTrait3.rate_inherit = 22;
            AssetManager.traits.add(GongFaTrait3);

            ActorTrait GongFaTrait4 = CreateTrait("GongFaTrait4", "trait/GongFaTrait4", "GongFa");
            SafeSetStat(GongFaTrait4.base_stats, strings.S.multiplier_speed, 0.08f);
            SafeSetStat(GongFaTrait4.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(GongFaTrait4.base_stats, strings.S.multiplier_health, 0.19f);
            SafeSetStat(GongFaTrait4.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(GongFaTrait4.base_stats, strings.S.stamina, 10f);
            SafeSetStat(GongFaTrait4.base_stats, strings.S.area_of_effect, 10f);
            GongFaTrait4.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait4);

            ActorTrait GongFaTrait5 = CreateTrait("GongFaTrait5", "trait/GongFaTrait5", "GongFa");
            SafeSetStat(GongFaTrait5.base_stats, strings.S.multiplier_speed, 0.07f);
            SafeSetStat(GongFaTrait5.base_stats, strings.S.multiplier_damage, 0.18f);
            SafeSetStat(GongFaTrait5.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(GongFaTrait5.base_stats, strings.S.lifespan, 18f);
            SafeSetStat(GongFaTrait5.base_stats, strings.S.stamina, 12f);
            SafeSetStat(GongFaTrait5.base_stats, strings.S.area_of_effect, 11f);
            GongFaTrait5.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait5);

            ActorTrait GongFaTrait6 = CreateTrait("GongFaTrait6", "trait/GongFaTrait6", "GongFa");
            SafeSetStat(GongFaTrait6.base_stats, strings.S.multiplier_speed, 0.11f);
            SafeSetStat(GongFaTrait6.base_stats, strings.S.multiplier_damage, 0.11f);
            SafeSetStat(GongFaTrait6.base_stats, strings.S.multiplier_health, 0.15f);
            SafeSetStat(GongFaTrait6.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(GongFaTrait6.base_stats, strings.S.stamina, 15f);
            SafeSetStat(GongFaTrait6.base_stats, strings.S.area_of_effect, 15f);
            GongFaTrait6.rate_inherit = 15;
            AssetManager.traits.add(GongFaTrait6);

            ActorTrait GongFaTrait7 = CreateTrait("GongFaTrait7", "trait/GongFaTrait7", "GongFa");
            SafeSetStat(GongFaTrait7.base_stats, strings.S.multiplier_speed, 0.19f);
            SafeSetStat(GongFaTrait7.base_stats, strings.S.multiplier_damage, 0.19f);
            SafeSetStat(GongFaTrait7.base_stats, strings.S.multiplier_health, 0.19f);
            SafeSetStat(GongFaTrait7.base_stats, strings.S.lifespan, 19f);
            SafeSetStat(GongFaTrait7.base_stats, strings.S.stamina, 19f);
            SafeSetStat(GongFaTrait7.base_stats, strings.S.area_of_effect, 19f);
            GongFaTrait7.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait7);

            ActorTrait GongFaTrait8 = CreateTrait("GongFaTrait8", "trait/GongFaTrait8", "GongFa");
            SafeSetStat(GongFaTrait8.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(GongFaTrait8.base_stats, strings.S.multiplier_damage, 0.13f);
            SafeSetStat(GongFaTrait8.base_stats, strings.S.multiplier_health, 0.17f);
            SafeSetStat(GongFaTrait8.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(GongFaTrait8.base_stats, strings.S.stamina, 13f);
            SafeSetStat(GongFaTrait8.base_stats, strings.S.area_of_effect, 11f);
            GongFaTrait8.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait8);

            ActorTrait GongFaTrait9 = CreateTrait("GongFaTrait9", "trait/GongFaTrait9", "GongFa");
            SafeSetStat(GongFaTrait9.base_stats, strings.S.multiplier_speed, 0.16f);
            SafeSetStat(GongFaTrait9.base_stats, strings.S.multiplier_damage, 0.14f);
            SafeSetStat(GongFaTrait9.base_stats, strings.S.multiplier_health, 0.12f);
            SafeSetStat(GongFaTrait9.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(GongFaTrait9.base_stats, strings.S.stamina, 16f);
            SafeSetStat(GongFaTrait9.base_stats, strings.S.area_of_effect, 12f);
            GongFaTrait9.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait9);

            ActorTrait GongFaTrait10 = CreateTrait("GongFaTrait10", "trait/GongFaTrait10", "GongFa");
            SafeSetStat(GongFaTrait10.base_stats, strings.S.multiplier_speed, 0.17f);
            SafeSetStat(GongFaTrait10.base_stats, strings.S.multiplier_damage, 0.13f);
            SafeSetStat(GongFaTrait10.base_stats, strings.S.multiplier_health, 0.11f);
            SafeSetStat(GongFaTrait10.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(GongFaTrait10.base_stats, strings.S.stamina, 12f);
            SafeSetStat(GongFaTrait10.base_stats, strings.S.area_of_effect, 11f);
            GongFaTrait10.rate_inherit = 20;
            AssetManager.traits.add(GongFaTrait10);

            ActorTrait GongFaTrait11 = CreateTrait("GongFaTrait11", "trait/GongFaTrait11", "GongFa");
            SafeSetStat(GongFaTrait11.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(GongFaTrait11.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(GongFaTrait11.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(GongFaTrait11.base_stats, strings.S.lifespan, 24f);
            SafeSetStat(GongFaTrait11.base_stats, strings.S.stamina, 40f);
            SafeSetStat(GongFaTrait11.base_stats, strings.S.area_of_effect, 20f);
            GongFaTrait11.rate_inherit = 20;
            AssetManager.traits.add(GongFaTrait11);

            ActorTrait GongFaTrait13 = CreateTrait("GongFaTrait13", "trait/GongFaTrait13", "GongFa");
            SafeSetStat(GongFaTrait13.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(GongFaTrait13.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(GongFaTrait13.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(GongFaTrait13.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(GongFaTrait13.base_stats, strings.S.stamina, 90f);
            SafeSetStat(GongFaTrait13.base_stats, strings.S.area_of_effect, 30f);
            GongFaTrait13.rate_inherit = 10;
            AssetManager.traits.add(GongFaTrait13);

            ActorTrait congenitalPerfection = CreateTrait("congenitalPerfection", "trait/congenitalPerfection", "MartialFoundations");
            AssetManager.traits.add(congenitalPerfection);

        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}