﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }


        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            List<Actor> simpleList = World.world.units.getSimpleList();
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        BehaviourTaskActor task = actor.ai.task;
                        SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            __instance.cancelAllBeh();
            __instance.makeWait(pTime);

            // 检查是否具有 Warrior6 到 Warrior93 的特质
            bool hasWarriorTrait = false;
            for (int i = 6; i <= 93; i++)
            {
                string warriorTrait = "Warrior" + i;
                if (__instance.hasTrait(warriorTrait))
                {
                    hasWarriorTrait = true;
                    break;
                }
            }

            // 如果没有 Warrior6 到 Warrior93 的特质，则添加眩晕状态
            if (!hasWarriorTrait)
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            __instance._last_attack_type = pAttackType;
            // 闪避机制
            if (pAttacker is Actor attackerActor && __instance.isAlive())
            {
                float attackerMingzhong = attackerActor.stats["Mingzhong"];
                float targetShanbi = __instance.stats["Shanbi"];
                float effectiveShanbi = Mathf.Clamp(targetShanbi - attackerMingzhong, 0f, 100f);

                if (Randy.randomChance(effectiveShanbi / 100f))
                {
                    __instance.startColorEffect(ActorColorEffect.White);
                    return false;
                }
            }
            return true;
        }
        
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_WarriorPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasmartialAptitude10 = __instance.hasTrait("martialAptitude10");// 检查是否具有特质
            bool hasmartialAptitude9 = __instance.hasTrait("martialAptitude9");
            bool hasCongenitalPerfection = __instance.hasTrait("congenitalPerfection"); // 检查是否拥有“先天圆满”特质

            bool hasObtainedarcaneTome = false;

            // 检查是否拥有“武祖赐福”特质
            bool hasMartialAptitude8 = __instance.hasTrait("martialAptitude8");
            if (hasMartialAptitude8)
            {
                // 检查是否已经获得了九字秘特质
                if (!hasObtainedarcaneTome)
                {
                    string[] arcaneTome = {
                        "arcaneTome91"
                    };

                    int randomIndex = UnityEngine.Random.Range(0, arcaneTome.Length);
                    string selectedarcaneTome = arcaneTome[randomIndex];

                    if (!__instance.hasTrait(selectedarcaneTome))
                    {
                        __instance.addTrait(selectedarcaneTome);
                        hasObtainedarcaneTome = true;
                    }
                }
            }

            // 出生时（年龄为0）有一定概率获得“先天圆满”特质
            if (Mathf.FloorToInt(age) == 0 && !hasCongenitalPerfection && Randy.randomChance(0.05f)) // 5% 的概率
            {
                __instance.addTrait("congenitalPerfection", false);
            }

            // 定义特定种族数组
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };

            // 4岁时获得martialAptitude1-martialAptitude10的随机特质
            if (Mathf.FloorToInt(age) == 4 && !hasmartialAptitude9 && !hasmartialAptitude10 &&
                !HasAnyFlairTalen(__instance) &&
                Randy.randomChance(0.2f) &&
                (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {
                // 修改元组类型为float以支持小数权重
                var martialAptitudeWeights = new (string traitId, float weight)[]
                {
                    ("martialAptitude1", 64f),
                    ("martialAptitude2", 31f),
                    ("martialAptitude3", 4.38f),
                    ("martialAptitude4", 0.51f),
                    ("martialAptitude7", 0.09f),
                    ("martialAptitude8", 0.02f),
                };

                // 计算总权重
                float totalWeight = martialAptitudeWeights.Sum(t => t.weight);

                // 生成随机浮点数
                float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                // 遍历权重选择特质
                string selectedmartialAptitude = "martialAptitude1"; // 默认值
                foreach (var martialAptitude in martialAptitudeWeights)
                {
                    if (randomValue < martialAptitude.weight)
                    {
                        selectedmartialAptitude = martialAptitude.traitId;
                        break;
                    }
                    randomValue -= martialAptitude.weight;
                }

                __instance.addTrait(selectedmartialAptitude, false);
            }

            // 特质增加武者气血的处理
            var martialAptitudeWarriorChanges = new Dictionary<string, (float, float)>
            {
                { "martialAptitude1", (1.0f, 2.0f) },//下
                { "martialAptitude2", (2.5f, 4.5f) },//中
                { "martialAptitude3", (4.5f, 7.5f) },//上
                { "martialAptitude4", (8.0f, 12.5f) },//龙筋虎骨
                { "martialAptitude10", (-1.0f, -2.0f) },//英雄迟暮
                { "martialAptitude7", (10.0f, 16.0f) },//真武转世
                { "martialAptitude8", (14.5f, 20.0f) },//天生至尊
            };

            foreach (var change in martialAptitudeWarriorChanges)
            {
                // 如果具有martialAptitude10特质，并且当前特质是martialAptitude1到martialAptitude4，则跳过
                if ((hasmartialAptitude10 || hasmartialAptitude9) && (change.Key == "martialAptitude1" || change.Key == "martialAptitude2" || change.Key == "martialAptitude3" || change.Key == "martialAptitude4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomWarriorIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeWarrior(randomWarriorIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var WarriorTraitThresholds = new Dictionary<string, float>
            {
                { "Warrior1", 40f },
                { "Warrior2", 50f },
                { "Warrior3", 50f },
                { "Warrior4", 65f },
                { "Warrior5", 70f },
                { "Warrior6", 100f },
                { "Warrior7", 150f },
                { "Warrior8", 220f },
                { "Warrior9", 400f },
                { "Warrior91", 600f },
                { "Warrior92", 1000f },
                { "Warrior93", 2000f }
            };
            const float martialAptitude10Chance = 0.1f;
            foreach (var threshold in WarriorTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(martialAptitude10Chance) && !hasCongenitalPerfection)
                {
                    __instance.addTrait("martialAptitude10", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Warrior1", 10f },
                { "Warrior2", 20f },
                { "Warrior3", 40f },
                { "Warrior4", 80f },
                { "Warrior5", 100f },
                { "Warrior6", 300f },
                { "Warrior7", 500f },
                { "Warrior8", 800f },
                { "Warrior9", 1000f },
                { "Warrior91", 3000f },
                { "Warrior92", 9000f },
                { "Warrior93", 18000f },
            };
            foreach (var grade in grades)
            {
                UpdateWarriorBasedOnGrade(__instance, grade.Key, grade.Value);
            }
        }

        private static void UpdateWarriorBasedOnGrade(Actor actor, string traitName, float maxWarrior)
        {
            if (actor.hasTrait(traitName))
            {
                float currentWarrior = actor.GetWarrior();
                float newValue = Mathf.Min(maxWarrior, currentWarrior);
                actor.SetWarrior(newValue);
            }
        }

        private static readonly string[] FlairmartialAptitudeTraits = new[] { "martialAptitude1", "martialAptitude2", "martialAptitude3", "martialAptitude4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairmartialAptitudeTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}    