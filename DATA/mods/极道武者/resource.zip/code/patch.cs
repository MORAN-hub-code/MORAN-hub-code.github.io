﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);

            Actor actor = __instance.actor;
            // 检查是否为武者并摘除 immortal 特质
            if (traitAction.IsWarrior1To12(actor) && actor.hasTrait("immortal"))
            {
                actor.removeTrait("immortal");
            }
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            __instance.cancelAllBeh();
            __instance.makeWait(pTime);

            // 检查是否具有 Warrior6 到 Warrior12 的特质
            bool hasWarriorTrait = false;
            for (int i = 6; i <= 12; i++)
            {
                string warriorTrait = "Warrior" + i;
                if (__instance.hasTrait(warriorTrait))
                {
                    hasWarriorTrait = true;
                    break;
                }
            }

            // 如果没有 Warrior6 到 Warrior12 的特质，则添加眩晕状态
            if (!hasWarriorTrait)
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            return false;
        }

        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_WarriorPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasmartialAptitude6 = __instance.hasTrait("martialAptitude6");// 检查是否具有特质
            bool hasmartialAptitude5 = __instance.hasTrait("martialAptitude5");
            bool hasCongenitalPerfection = __instance.hasTrait("congenitalPerfection"); // 检查是否拥有“先天圆满”特质

            // 出生时（年龄为0）有一定概率获得“先天圆满”特质
            if (Mathf.FloorToInt(age) == 0 && !hasCongenitalPerfection && Randy.randomChance(0.05f)) // 5% 的概率
            {
                __instance.addTrait("congenitalPerfection", false);
            }

            // 4岁时获得martialAptitude1-martialAptitude4的随机特质
            if (Mathf.FloorToInt(age) == 4 && !hasmartialAptitude5 && !hasmartialAptitude6 &&
                !HasAnyFlairTalen(__instance) &&
                Randy.randomChance(0.3f))
            {
                // 修改元组类型为float以支持小数权重
                var martialAptitudeWeights = new (string traitId, float weight)[]
                {
                    ("martialAptitude1", 30f),
                    ("martialAptitude2", 10f),
                    ("martialAptitude3", 2f),
                    ("martialAptitude4", 0.5f),
                    ("martialAptitude7", 0.1f),
                    ("martialAptitude8", 0.05f),
                };

                // 计算总权重
                float totalWeight = martialAptitudeWeights.Sum(t => t.weight);

                // 生成随机浮点数
                float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                // 遍历权重选择特质
                string selectedmartialAptitude = "martialAptitude1"; // 默认值
                foreach (var martialAptitude in martialAptitudeWeights)
                {
                    if (randomValue < martialAptitude.weight)
                    {
                        selectedmartialAptitude = martialAptitude.traitId;
                        break;
                    }
                    randomValue -= martialAptitude.weight;
                }

                __instance.addTrait(selectedmartialAptitude, false);
            }

            // 特质增加武者气血的处理
            var martialAptitudeWarriorChanges = new Dictionary<string, (float, float)>
            {
                { "martialAptitude1", (1.0f, 2.0f) },//下
                { "martialAptitude2", (2.5f, 4.5f) },//中
                { "martialAptitude3", (4.5f, 7.5f) },//上
                { "martialAptitude4", (8.0f, 12.5f) },//龙筋虎骨
                { "martialAptitude6", (-1.0f, -2.0f) },//英雄迟暮
                { "martialAptitude7", (10.0f, 16.0f) },//真武转世
                { "martialAptitude8", (14.5f, 20.0f) },//天生至尊
            };

            foreach (var change in martialAptitudeWarriorChanges)
            {
                // 如果具有martialAptitude6特质，并且当前特质是martialAptitude1到martialAptitude4，则跳过
                if ((hasmartialAptitude6 || hasmartialAptitude5) && (change.Key == "martialAptitude1" || change.Key == "martialAptitude2" || change.Key == "martialAptitude3" || change.Key == "martialAptitude4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomWarriorIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeWarrior(randomWarriorIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var WarriorTraitThresholds = new Dictionary<string, float>
            {
                { "Warrior1", 40f },
                { "Warrior2", 50f },
                { "Warrior3", 50f },
                { "Warrior4", 65f },
                { "Warrior5", 70f },
                { "Warrior6", 100f },
                { "Warrior7", 150f },
                { "Warrior8", 220f },
                { "Warrior9", 400f },
                { "Warrior10", 600f },
                { "Warrior11", 1000f },
                { "Warrior12", 2000f }
            };
            const float martialAptitude6Chance = 0.1f;
            foreach (var threshold in WarriorTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(martialAptitude6Chance) && !hasCongenitalPerfection)
                {
                    __instance.addTrait("martialAptitude6", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Warrior1", 10f },
                { "Warrior2", 20f },
                { "Warrior3", 40f },
                { "Warrior4", 80f },
                { "Warrior5", 100f },
                { "Warrior6", 300f },
                { "Warrior7", 500f },
                { "Warrior8", 800f },
                { "Warrior9", 1000f },
                { "Warrior10", 3000f },
                { "Warrior11", 9000f },
                { "Warrior12", 18000f },
            };
            foreach (var grade in grades)
            {
                UpdateWarriorBasedOnGrade(__instance, grade.Key, grade.Value);
            }

            // 检查是否突破到合天境（Warrior10）
            if (__instance.hasTrait("Warrior10"))
            {
                __instance.data.favorite = true;
            }

            // 检查是否突破到领域境界（Warrior9），如果是则赋予防火特质
            if (__instance.hasTrait("Warrior9"))
            {
                __instance.addTrait("fire_proof");
            }

            if (__instance.hasTrait("martialAptitude7") || __instance.hasTrait("martialAptitude8"))
            {
                __instance.data.favorite = true;
            }
        }

        private static void UpdateWarriorBasedOnGrade(Actor actor, string traitName, float maxWarrior)
        {
            if (actor.hasTrait(traitName))
            {
                float currentWarrior = actor.GetWarrior();
                float newValue = Mathf.Min(maxWarrior, currentWarrior);
                actor.SetWarrior(newValue);
            }
        }

        private static readonly string[] FlairmartialAptitudeTraits = new[] { "martialAptitude1", "martialAptitude2", "martialAptitude3", "martialAptitude4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairmartialAptitudeTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}    