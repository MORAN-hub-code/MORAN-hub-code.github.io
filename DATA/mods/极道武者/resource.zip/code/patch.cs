﻿﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }


        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            List<Actor> simpleList = World.world.units.getSimpleList();
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        BehaviourTaskActor task = actor.ai.task;
                        SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            __instance.cancelAllBeh();
            __instance.makeWait(pTime);
            // 如果没有防火特质，则添加眩晕状态效果，否则不添加眩晕状态效果
            if (!__instance.hasTrait("fire_proof"))
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "addStunnedEffectOnTarget20")]
        // 添加眩晕效果到目标（20%概率）
        public static bool addStunnedEffectOnTarget20_Patch(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 检查目标是否有效（未死亡、非建筑）
            if (pTarget.isRekt() || pTarget.isBuilding()) 
            {
                return false;
            }

            // 检查随机概率（20%）
            if (!Randy.randomChance(0.2f))
            {
                return false;
            }

            // 检查目标是否具有防火特质
            if (pTarget.isActor() && pTarget.a.hasTrait("fire_proof"))
            {
                return false;
            }

            // 调用眩晕方法
            return ActionLibrary.addStunnedEffectOnTarget(pSelf, pTarget, pTile);
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            __instance._last_attack_type = pAttackType;
            // 闪避机制
            if (pAttacker is Actor attackerActor && __instance.isAlive())
            {
                float attackerMingzhong = attackerActor.stats["Mingzhong"];
                float targetShanbi = __instance.stats["Shanbi"];
                float effectiveShanbi = Mathf.Clamp(targetShanbi - attackerMingzhong, 0f, 100f);

                if (Randy.randomChance(effectiveShanbi / 100f))
                {
                    __instance.startColorEffect(ActorColorEffect.White);
                    return false;
                }
            }
            return true;
        }
        
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
        public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            float tForce = pData.knockback * pMod;

            if (tForce > 0f && pTargetToCheck.isActor())
            {
                float resistValue = pTargetToCheck.a.stats["knockback_reduction"];
                tForce = Mathf.Max(tForce - resistValue, 0);

                if (tForce > 0f)
                {
                    Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                    Vector2 tAttackVec = pData.hit_position;
                    pTargetToCheck.a.calculateForce(
                        tPosStart.x, tPosStart.y,
                        tAttackVec.x, tAttackVec.y,
                        tForce,
                        0f,
                        pCheckCancelJobOnLand
                    );
                }
            }
            return false;
        }
    
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_WarriorPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasmartialAptitude10 = __instance.hasTrait("martialAptitude10");// 检查是否具有特质
            bool hasmartialAptitude9 = __instance.hasTrait("martialAptitude9");
            bool hasCongenitalPerfection = __instance.hasTrait("congenitalPerfection"); // 检查是否拥有“先天圆满”特质

            bool hasObtainedarcaneTome = false;

            // 检查是否拥有“武祖赐福”特质
            bool hasMartialAptitude8 = __instance.hasTrait("martialAptitude8");
            if (hasMartialAptitude8)
            {
                if (!hasObtainedarcaneTome)
                {
                    string[] arcaneTome = {
                        "arcaneTome91"
                    };

                    int randomIndex = UnityEngine.Random.Range(0, arcaneTome.Length);
                    string selectedarcaneTome = arcaneTome[randomIndex];

                    if (!__instance.hasTrait(selectedarcaneTome))
                    {
                        __instance.addTrait(selectedarcaneTome);
                        hasObtainedarcaneTome = true;
                    }
                }
                
                __instance.data.favorite = true;

            }

            // 检查是否拥有混沌帝血特质
            bool hasmartialBloodline7 = __instance.hasTrait("martialBloodline7");
            if (hasmartialBloodline7)
            {
                // 直接觉醒玄玉根骨
                string martialAptitude4Trait = "martialAptitude4";
                // 定义根骨特质数组
                string[] martialAptitudeTraits = {
                    "martialAptitude1",
                    "martialAptitude2",
                    "martialAptitude3",
                    "martialAptitude4",
                    "martialAptitude7",
                    "martialAptitude8",
                    "martialAptitude9",
                    "martialAptitude10"
                };

                // 检查是否已拥有任何根骨特质
                bool hasAnyMartialAptitude = false;
                foreach (string trait in martialAptitudeTraits)
                {
                    if (__instance.hasTrait(trait))
                    {
                        hasAnyMartialAptitude = true;
                        break;
                    }
                }

                // 只有在未拥有任何根骨特质时才觉醒玄玉根骨
                if (!hasAnyMartialAptitude && !__instance.hasTrait("martialAptitude4"))
                {
                    __instance.addTrait("martialAptitude4");
                }
            }

            // 出生时（年龄为1）有一定概率获得“先天圆满”特质
            if (Mathf.FloorToInt(age) == 1 && !hasCongenitalPerfection && Randy.randomChance(0.03f)) // 3% 的概率
            {
                __instance.addTrait("congenitalPerfection", false);
            }

            // 定义特定种族数组
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };

            // 4岁时获得martialAptitude1 - martialAptitude10的随机特质
            if (Mathf.FloorToInt(age) == 4 && !hasmartialAptitude9 && !hasmartialAptitude10 &&
                !HasAnyFlairTalen(__instance) &&
                (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {

                // 如果已经拥有玄玉根骨（因混沌帝血获得），则跳过此次随机根骨觉醒
                if (__instance.hasTrait("martialAptitude4"))
                {
                    return;
                }

                float bloodlineBonus = 0f;
                if (__instance.hasTrait("martialBloodline1"))
                {
                    bloodlineBonus = 0.2f; // 一级血脉提高20%的概率
                }
                else if (__instance.hasTrait("martialBloodline2"))
                {
                    bloodlineBonus = 0.3f; // 二级血脉提高30%的概率
                }
                else if (__instance.hasTrait("martialBloodline3"))
                {
                    bloodlineBonus = 0.4f; // 三级血脉提高40%的概率
                }
                else if (__instance.hasTrait("martialBloodline4"))
                {
                    bloodlineBonus = 0.5f; // 四级血脉提高50%的概率
                }
                else if (__instance.hasTrait("martialBloodline5"))
                {
                    bloodlineBonus = 0.6f; // 五级血脉提高60%的概率
                }
                else if (__instance.hasTrait("martialBloodline6"))
                {
                    bloodlineBonus = 0.7f; // 六级血脉提高70%的概率
                }

                if (Randy.randomChance(0.2f + bloodlineBonus))
                {
                    var martialAptitudeWeights = new (string traitId, float weight)[]
                    {
                        ("martialAptitude1", 64f),
                        ("martialAptitude2", 31f),
                        ("martialAptitude3", 4.58f),
                        ("martialAptitude4", 0.33f),
                        ("martialAptitude7", 0.076f),
                        ("martialAptitude8", 0.014f),
                    };

                    // 计算总权重
                    float totalWeight = martialAptitudeWeights.Sum(t => t.weight);

                    // 生成随机浮点数
                    float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                    // 遍历权重选择特质
                    string selectedmartialAptitude = "martialAptitude1"; // 默认值
                    foreach (var martialAptitude in martialAptitudeWeights)
                    {
                        if (randomValue < martialAptitude.weight)
                        {
                            selectedmartialAptitude = martialAptitude.traitId;
                            break;
                        }
                        randomValue -= martialAptitude.weight;
                    }

                    __instance.addTrait(selectedmartialAptitude, false);
                }
            }

            // 特质增加武者气血的处理
            var martialAptitudeWarriorChanges = new Dictionary<string, (float, float)>
            {
                { "martialAptitude1", (1.0f, 2.0f) },//下
                { "martialAptitude2", (2.0f, 4.0f) },//中
                { "martialAptitude3", (4.0f, 7.0f) },//上
                { "martialAptitude4", (7.0f, 10.0f) },//龙筋虎骨
                { "martialAptitude10", (-1.0f, -2.0f) },//英雄迟暮
                { "martialAptitude7", (10.0f, 14.0f) },//真武转世
                { "martialAptitude8", (14.0f, 18.0f) },//天生至尊
            };

            foreach (var change in martialAptitudeWarriorChanges)
            {
                // 如果具有martialAptitude10特质，并且当前特质是martialAptitude1到martialAptitude4，则跳过
                if ((hasmartialAptitude10 || hasmartialAptitude9) && (change.Key == "martialAptitude1" || change.Key == "martialAptitude2" || change.Key == "martialAptitude3" || change.Key == "martialAptitude4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomWarriorIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeWarrior(randomWarriorIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var WarriorTraitThresholds = new Dictionary<string, float>
            {
                { "Warrior1", 40f },
                { "Warrior2", 50f },
                { "Warrior3", 50f },
                { "Warrior4", 65f },
                { "Warrior5", 70f },
                { "Warrior6", 100f },
                { "Warrior7", 150f },
                { "Warrior8", 220f },
                { "Warrior9", 400f },
                { "Warrior91", 600f },
                { "Warrior92", 1000f },
                { "Warrior93", 2000f }
            };
            const float martialAptitude10Chance = 0.1f;
            foreach (var threshold in WarriorTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(martialAptitude10Chance) && !hasCongenitalPerfection)
                {
                    __instance.addTrait("martialAptitude10", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Warrior1", 10f },
                { "Warrior2", 20f },
                { "Warrior3", 40f },
                { "Warrior4", 80f },
                { "Warrior5", 160f },
                { "Warrior6", 300f },
                { "Warrior7", 500f },
                { "Warrior8", 800f },
                { "Warrior9", 1200f },
                { "Warrior91", 3600f },
                { "Warrior92", 10000f },
                { "Warrior93", 18000f },
            };
            foreach (var grade in grades)
            {
                UpdateWarriorBasedOnGrade(__instance, grade.Key, grade.Value);
            }
        }

        private static void UpdateWarriorBasedOnGrade(Actor actor, string traitName, float maxWarrior)
        {
            if (actor.hasTrait(traitName))
            {
                float currentWarrior = actor.GetWarrior();
                float newValue = Mathf.Min(maxWarrior, currentWarrior);
                actor.SetWarrior(newValue);
            }
        }

        private static readonly string[] FlairmartialAptitudeTraits = new[] { "martialAptitude1", "martialAptitude2", "martialAptitude3", "martialAptitude4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairmartialAptitudeTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}    