﻿using HarmonyLib;

using PeerlessOverpoweringWarrior.code;

using NeoModLoader.api;

namespace PeerlessOverpoweringWarrior
{
    internal class PeerlessOverpoweringWarriorClass : BasicMod<PeerlessOverpoweringWarriorClass>
    {
        public static string id = "shiyue.worldbox.mod.PeerlessOverpoweringWarrior";
        protected override void OnModLoad()
        {
            stats.Init();
            traitGroup.Init();
            traits.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }

    }

}
