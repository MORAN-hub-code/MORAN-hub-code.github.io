﻿using HarmonyLib;
using PeerlessOverpoweringWarrior.code;
using NeoModLoader.api;

namespace PeerlessOverpoweringWarrior
{
    internal class PeerlessOverpoweringWarriorClass : BasicMod<PeerlessOverpoweringWarriorClass>
    {
        public static string id = "shiyue.worldbox.mod.PeerlessOverpoweringWarrior";
        protected override void OnModLoad()
        {
            try
            {
                stats.Init();
                traitGroup.Init();
                traits.Init();
                new Harmony(id).PatchAll(typeof(patch));
            }
            catch (System.Exception ex)
            {
                UnityEngine.Debug.LogError($"Error during mod loading: {ex.Message}\n{ex.StackTrace}");
            }
        }
    }
}