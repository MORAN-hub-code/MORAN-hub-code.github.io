using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using NCMS;
using System.Runtime.CompilerServices;
using ai.behaviours;
using NCMS.Utils;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using life;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;
using Newtonsoft.Json;

namespace 亚种突变强化
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
			SubspeciesTraitup.init();
        }
    }
}