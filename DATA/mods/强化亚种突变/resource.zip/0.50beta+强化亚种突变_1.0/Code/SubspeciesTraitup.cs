using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using NCMS;
using System.Runtime.CompilerServices;
using ai.behaviours;
using NCMS.Utils;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using life;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;
using Newtonsoft.Json;



namespace 亚种突变强化
{
    class SubspeciesTraitup
    {
        public static void init()
        {
            SubspeciesTrait mutation_skin_burger = AssetManager.subspecies_traits.get("mutation_skin_burger");
            mutation_skin_burger.base_stats["multiplier_health"] = 0.5f;
            mutation_skin_burger.base_stats["multiplier_damage"] = 0.5f;
            mutation_skin_burger.base_stats["scale"] = 0.03f;

            SubspeciesTrait mutation_skin_light_orb = AssetManager.subspecies_traits.get("mutation_skin_light_orb");
            mutation_skin_light_orb.base_stats["skill_spell"] = 0.3f;
            mutation_skin_light_orb.base_stats["multiplier_diplomacy"] = 0.1f;

            SubspeciesTrait mutation_skin_living_rock = AssetManager.subspecies_traits.get("mutation_skin_living_rock");
            mutation_skin_living_rock.base_stats["mass"] = 20f;
            mutation_skin_living_rock.base_stats["armor"] = 10f;
            mutation_skin_living_rock.base_stats["multiplier_speed"] = -0.1f;

            SubspeciesTrait mutation_skin_tentacle_horror = AssetManager.subspecies_traits.get("mutation_skin_tentacle_horror");
            mutation_skin_tentacle_horror.base_stats["critical_chance"] = 0.1f;
            mutation_skin_tentacle_horror.base_stats["multiplier_damage"] = 0.3f;

            SubspeciesTrait mutation_skin_fractal = AssetManager.subspecies_traits.get("mutation_skin_fractal");
            mutation_skin_fractal.base_stats["lifespan"] = 1000000f;
            mutation_skin_fractal.base_stats["multiplier_damage"] = -0.9f;
            mutation_skin_fractal.base_stats["multiplier_attack_speed"] = 1000f;

            SubspeciesTrait mutation_skin_abomination = AssetManager.subspecies_traits.get("mutation_skin_abomination");
            mutation_skin_abomination.base_stats["multiplier_damage"] = 0.5f;
            mutation_skin_abomination.base_stats["multiplier_diplomacy"] = -0.3f;

            SubspeciesTrait mutation_skin_void = AssetManager.subspecies_traits.get("mutation_skin_void");
            mutation_skin_void.base_stats["multiplier_health"] = -0.7f;
            mutation_skin_void.base_stats["multiplier_damage"] = 0.3f;
            mutation_skin_void.base_stats["multiplier_attack_speed"] = 0.3f;
            mutation_skin_void.base_stats["critical_chance"] = 0.1f;

            SubspeciesTrait mutation_skin_metalic_orb = AssetManager.subspecies_traits.get("mutation_skin_metalic_orb");
            mutation_skin_metalic_orb.base_stats["skill_spell"] = 1f;
            mutation_skin_metalic_orb.base_stats["critical_chance"] = 0.3f;

            SubspeciesTrait mutation_skin_blood_vortex = AssetManager.subspecies_traits.get("mutation_skin_blood_vortex");
            mutation_skin_blood_vortex.base_stats["multiplier_health"] = 0.5f;
            mutation_skin_blood_vortex.base_stats["multiplier_diplomacy"] = -0.3f;

            SubspeciesTrait mutation_skin_energy = AssetManager.subspecies_traits.get("mutation_skin_energy");
            mutation_skin_energy.base_stats["skill_spell"] = 0.7f;
            mutation_skin_energy.base_stats["multiplier_speed"] = 0.25f;

            BaseStatAsset attack_speed = AssetManager.base_stats_library.get("attack_speed");
            attack_speed.normalize_max = 100f;
        }
    }
}