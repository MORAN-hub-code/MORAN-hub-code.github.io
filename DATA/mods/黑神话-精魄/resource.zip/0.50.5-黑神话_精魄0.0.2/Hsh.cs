﻿using NeoModLoader.api;
using Hsh.code;
using HarmonyLib;

namespace Hsh
{
    internal class HshClass : BasicMod<HshClass>
    {
        public static string id = "shiyue.worldbox.mod.Hsh";

        protected override void OnModLoad()
        {            
            traits.Init();
            traitGroup.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }
    }
}