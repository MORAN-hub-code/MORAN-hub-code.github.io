﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hsh.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset Hsh = new ActorTraitGroupAsset();
            Hsh.id = "Hsh";
            Hsh.name = "trait_group_Hsh";
            Hsh.color = "#FFFAFA";
            AssetManager.trait_groups.add(Hsh);
        }
    }
}
