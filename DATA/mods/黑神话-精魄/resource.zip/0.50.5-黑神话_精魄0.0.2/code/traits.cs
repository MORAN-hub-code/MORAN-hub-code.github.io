using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;

namespace Hsh.code
{
	internal class traits
	{
		private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
		{
			ActorTrait trait = new ActorTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		public static void Init()
		{
			ActorTrait Hsh1 = CreateTrait("Hsh1", "trait/Hsh1", "Hsh");
			AssetManager.traits.add(Hsh1);

			ActorTrait Hsh2 = CreateTrait("Hsh2", "trait/Hsh2", "Hsh");
			AssetManager.traits.add(Hsh2);

			ActorTrait Hsh3 = CreateTrait("Hsh3", "trait/Hsh3", "Hsh");
			AssetManager.traits.add(Hsh3);

			ActorTrait Hsh4 = CreateTrait("Hsh4", "trait/Hsh4", "Hsh");
			AssetManager.traits.add(Hsh4);

			ActorTrait Hsh5 = CreateTrait("Hsh5", "trait/Hsh5", "Hsh");
			AssetManager.traits.add(Hsh5);

			ActorTrait Hsh6 = CreateTrait("Hsh6", "trait/Hsh6", "Hsh");
			AssetManager.traits.add(Hsh6);

			ActorTrait Hsh7 = CreateTrait("Hsh7", "trait/Hsh7", "Hsh");
			AssetManager.traits.add(Hsh7);

			ActorTrait Hsh8 = CreateTrait("Hsh8", "trait/Hsh8", "Hsh");
			AssetManager.traits.add(Hsh8);

			ActorTrait Hsh9 = CreateTrait("Hsh9", "trait/Hsh9", "Hsh");
			AssetManager.traits.add(Hsh9);

			ActorTrait Hsh10 = CreateTrait("Hsh10", "trait/Hsh10", "Hsh");
			AssetManager.traits.add(Hsh10);

			ActorTrait Hsh11 = CreateTrait("Hsh11", "trait/Hsh11", "Hsh");
			AssetManager.traits.add(Hsh11);

			ActorTrait Hsh12 = CreateTrait("Hsh12", "trait/Hsh12", "Hsh");
			AssetManager.traits.add(Hsh12);
		}
		private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
		{
			baseStats[statKey] = value;
		}
    }
}
