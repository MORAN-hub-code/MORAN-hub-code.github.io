﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();
            
            return trait;
        }
        public static ActorTrait martialAptitude_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait martialAptitude = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "MartialFoundations",
                needs_to_be_explored = false
            };
            martialAptitude.action_special_effect += traitAction.Warrior1_effectAction;
            AssetManager.traits.add(martialAptitude);
            return martialAptitude;
        }
        public static void Init()
        {
            _=martialAptitude_AddActorTrait("martialAptitude1", "trait/martialAptitude1");
            _=martialAptitude_AddActorTrait("martialAptitude2", "trait/martialAptitude2");
            _=martialAptitude_AddActorTrait("martialAptitude3", "trait/martialAptitude3");
            _=martialAptitude_AddActorTrait("martialAptitude4", "trait/martialAptitude4");

            ActorTrait martialAptitude5 = CreateTrait("martialAptitude5", "trait/martialAptitude5", "MartialFoundations");
            martialAptitude5.rate_inherit = 100;
            AssetManager.traits.add(martialAptitude5);
            
            ActorTrait martialAptitude6 = CreateTrait("martialAptitude6", "trait/martialAptitude6", "MartialFoundations");
            AssetManager.traits.add(martialAptitude6);

            ActorTrait Warrior02 = CreateTrait("Warrior2+", "trait/Warrior2+", "Warrior");
            SafeSetStat(Warrior02.base_stats, S.lifespan, 10f);
            SafeSetStat(Warrior02.base_stats, S.skill_combat, 0.1f);
            AssetManager.traits.add(Warrior02);

            ActorTrait Warrior03 = CreateTrait("Warrior3+", "trait/Warrior3+", "Warrior");
            SafeSetStat(Warrior03.base_stats , S.lifespan, 20f);
            SafeSetStat(Warrior03.base_stats , S.skill_combat, 0.2f);
            AssetManager.traits.add(Warrior03);
            
            ActorTrait Warrior04 = CreateTrait("Warrior4+", "trait/Warrior4+", "Warrior");
            SafeSetStat(Warrior04.base_stats , S.lifespan, 30f);
            SafeSetStat(Warrior04.base_stats , S.skill_combat, 0.3f);
            AssetManager.traits.add(Warrior04);

            ActorTrait Warrior05 = CreateTrait("Warrior5+", "trait/Warrior5+", "Warrior");
            SafeSetStat(Warrior05.base_stats , S.lifespan, 50f);
            SafeSetStat(Warrior05.base_stats , S.skill_combat, 0.4f);
            AssetManager.traits.add(Warrior05);

            ActorTrait Warrior06 = CreateTrait("Warrior6+", "trait/Warrior6+", "Warrior");
            SafeSetStat(Warrior06.base_stats , S.lifespan, 80f);
            SafeSetStat(Warrior06.base_stats , S.skill_combat, 0.5f);
            AssetManager.traits.add(Warrior06);

            ActorTrait Warrior07 = CreateTrait("Warrior7+", "trait/Warrior7+", "Warrior");
            SafeSetStat(Warrior07.base_stats, S.lifespan, 100f);
            SafeSetStat(Warrior07.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior07);

            ActorTrait Warrior08 = CreateTrait("Warrior8+", "trait/Warrior8+", "Warrior");
            SafeSetStat(Warrior08.base_stats, S.lifespan, 150f);
            SafeSetStat(Warrior08.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior08);

            ActorTrait Warrior09 = CreateTrait("Warrior9+", "trait/Warrior9+", "Warrior");
            SafeSetStat(Warrior09.base_stats, S.lifespan, 300f);
            SafeSetStat(Warrior09.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior09);

            ActorTrait Warrior091 = CreateTrait("Warrior10+", "trait/Warrior10+", "Warrior");
            SafeSetStat(Warrior091.base_stats, S.lifespan, 500f);
            SafeSetStat(Warrior091.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Warrior091);

            ActorTrait Warrior092 = CreateTrait("Warrior11+", "trait/Warrior11+", "Warrior");
            SafeSetStat(Warrior092.base_stats, S.lifespan, 1000f);
            SafeSetStat(Warrior092.base_stats, S.skill_combat, 0.7f);
            AssetManager.traits.add(Warrior092);

            ActorTrait Warrior093 = CreateTrait("Warrior12+", "trait/Warrior12+", "Warrior");
            SafeSetStat(Warrior093.base_stats, S.lifespan, 10000f);
            SafeSetStat(Warrior093.base_stats, S.skill_combat, 0.8f);
            AssetManager.traits.add(Warrior093);

            ActorTrait Warrior1 = CreateTrait("Warrior1", "trait/Warrior1", "Warrior");
            SafeSetStat(Warrior1.base_stats , S.damage, 3000f);
            SafeSetStat(Warrior1.base_stats , S.health, 20000f);
            SafeSetStat(Warrior1.base_stats , S.stamina, 100f);
            //SafeSetStat(Warrior1.base_stats , S.knockback_reduction, 0.5f);
            Warrior1.action_special_effect += traitAction.Warrior2_effectAction;
            Warrior1.action_special_effect += traitAction.Warrior1_Regen;
            AssetManager.traits.add(Warrior1);

            ActorTrait Warrior2 = CreateTrait("Warrior2", "trait/Warrior2", "Warrior");
            SafeSetStat(Warrior2.base_stats , S.damage, 5000f);
            SafeSetStat(Warrior2.base_stats , S.health, 30000f);
            SafeSetStat(Warrior2.base_stats , S.accuracy, 2f);
            SafeSetStat(Warrior2.base_stats , S.multiplier_speed, 0.1f);
            SafeSetStat(Warrior2.base_stats , S.stamina, 200f);
            //SafeSetStat(Warrior2.base_stats , S.knockback_reduction, 0.6f);
            Warrior2.action_special_effect += traitAction.Warrior3_effectAction;
            Warrior2.action_special_effect += traitAction.Warrior2_Regen;
            AssetManager.traits.add(Warrior2);

            ActorTrait Warrior3 = CreateTrait("Warrior3", "trait/Warrior3", "Warrior");
            SafeSetStat(Warrior3.base_stats , S.damage, 6000f);
            SafeSetStat(Warrior3.base_stats , S.health, 40000f);
            SafeSetStat(Warrior3.base_stats , S.armor, 5f);
            SafeSetStat(Warrior3.base_stats , S.targets, 0.1f);
            SafeSetStat(Warrior3.base_stats , S.accuracy, 5f);
            SafeSetStat(Warrior3.base_stats , S.multiplier_speed, 0.2f);
            SafeSetStat(Warrior3.base_stats , S.stamina, 30f);
            //SafeSetStat(Warrior3.base_stats , S.knockback_reduction, 0.7f);
            Warrior3.action_special_effect += traitAction.Warrior4_effectAction;
            Warrior3.action_special_effect += traitAction.Warrior3_Regen;
            AssetManager.traits.add(Warrior3);

            ActorTrait Warrior4 = CreateTrait("Warrior4", "trait/Warrior4", "Warrior");
            SafeSetStat(Warrior4.base_stats , S.damage, 7000f);
            SafeSetStat(Warrior4.base_stats , S.health, 50000f);
            SafeSetStat(Warrior4.base_stats , S.speed, 5f);
            SafeSetStat(Warrior4.base_stats , S.armor, 10f);
            SafeSetStat(Warrior4.base_stats , S.targets, 1f);
            SafeSetStat(Warrior4.base_stats , S.critical_chance, 0.2f);
            SafeSetStat(Warrior4.base_stats , S.accuracy, 10f);
            SafeSetStat(Warrior4.base_stats , S.multiplier_speed, 0.3f);
            SafeSetStat(Warrior4.base_stats , S.stamina, 400f);
            //SafeSetStat(Warrior4.base_stats , S.knockback_reduction, 0.8f);
            Warrior4.action_special_effect += traitAction.Warrior5_effectAction;
            Warrior4.action_special_effect += traitAction.Warrior4_Regen;
            AssetManager.traits.add(Warrior4);

            ActorTrait Warrior5 = CreateTrait("Warrior5", "trait/Warrior5", "Warrior");
            SafeSetStat(Warrior5.base_stats , S.warfare, 10f);
            SafeSetStat(Warrior5.base_stats , S.damage, 10000f);
            SafeSetStat(Warrior5.base_stats , S.health, 80000f);
            SafeSetStat(Warrior5.base_stats , S.speed, 10f);
            SafeSetStat(Warrior5.base_stats , S.armor, 15f);
            SafeSetStat(Warrior5.base_stats , S.targets, 4f);
            SafeSetStat(Warrior5.base_stats , S.critical_chance, 3.0f);
            SafeSetStat(Warrior5.base_stats , S.accuracy, 20f);
            SafeSetStat(Warrior5.base_stats , S.multiplier_speed, 0.4f);
            SafeSetStat(Warrior5.base_stats , S.stamina, 500f);
            //SafeSetStat(Warrior5.base_stats , S.knockback_reduction, 1f);
            Warrior5.action_special_effect += traitAction.Warrior6_effectAction;
            Warrior5.action_special_effect += traitAction.Warrior5_Regen;
            AssetManager.traits.add(Warrior5);

            ActorTrait Warrior6 = CreateTrait("Warrior6", "trait/Warrior6", "Warrior");
            SafeSetStat(Warrior6.base_stats , S.warfare, 20f);
            SafeSetStat(Warrior6.base_stats , S.damage, 18000f);
            SafeSetStat(Warrior6.base_stats , S.armor, 25f);
            SafeSetStat(Warrior6.base_stats , S.health, 150000f);
            SafeSetStat(Warrior6.base_stats , S.speed, 15f);
            SafeSetStat(Warrior6.base_stats , S.area_of_effect, 1f);
            SafeSetStat(Warrior6.base_stats , S.targets, 10f);
            SafeSetStat(Warrior6.base_stats , S.critical_chance, 5.0f);
            SafeSetStat(Warrior6.base_stats , S.accuracy, 30f);
            SafeSetStat(Warrior6.base_stats , S.multiplier_speed, 0.6f);
            SafeSetStat(Warrior6.base_stats , S.stamina, 700f);
            //SafeSetStat(Warrior6.base_stats , S.knockback_reduction, 1f);
            Warrior6.action_special_effect += traitAction.Warrior7_effectAction;
            Warrior6.action_special_effect += traitAction.Warrior6_Regen;
            Warrior6.action_attack_target += traitAction.TrueDamage1_AttackAction;
            AssetManager.traits.add(Warrior6);

            ActorTrait Warrior7 = CreateTrait("Warrior7", "trait/Warrior7", "Warrior");
            SafeSetStat(Warrior7.base_stats, S.warfare, 30f);
            SafeSetStat(Warrior7.base_stats, S.damage, 50000f);
            SafeSetStat(Warrior7.base_stats, S.mass, 25f);
            SafeSetStat(Warrior7.base_stats, S.armor, 35f);
            SafeSetStat(Warrior7.base_stats, S.health, 600000f);
            SafeSetStat(Warrior7.base_stats, S.speed, 20f);
            SafeSetStat(Warrior7.base_stats, S.area_of_effect, 2f);
            SafeSetStat(Warrior7.base_stats, S.targets, 14f);
            SafeSetStat(Warrior7.base_stats, S.critical_chance, 6.0f);
            SafeSetStat(Warrior7.base_stats, S.accuracy, 40f);
            SafeSetStat(Warrior7.base_stats, S.multiplier_speed, 0.8f);
            SafeSetStat(Warrior7.base_stats, S.stamina, 1400f);
            SafeSetStat(Warrior7.base_stats, S.range, 6f);
            SafeSetStat(Warrior7.base_stats, S.attack_speed, 2f);
            SafeSetStat(Warrior7.base_stats, S.multiplier_health, 0.4f);
            SafeSetStat(Warrior7.base_stats, S.multiplier_damage, 0.4f);
            Warrior7.action_attack_target += traitAction.TrueDamage2_AttackAction;
            Warrior7.action_special_effect += traitAction.Warrior8_effectAction;
            Warrior7.action_special_effect += traitAction.Warrior7_Regen;
            AssetManager.traits.add(Warrior7);

            ActorTrait Warrior8 = CreateTrait("Warrior8", "trait/Warrior8", "Warrior");
            SafeSetStat(Warrior8.base_stats, S.warfare, 40f);
            SafeSetStat(Warrior8.base_stats, S.damage, 120000f);
            SafeSetStat(Warrior8.base_stats, S.mass, 60f);
            SafeSetStat(Warrior8.base_stats, S.armor, 45f);
            SafeSetStat(Warrior8.base_stats, S.health, 1200000f);
            SafeSetStat(Warrior8.base_stats, S.speed, 25f);
            SafeSetStat(Warrior8.base_stats, S.area_of_effect, 3f);
            SafeSetStat(Warrior8.base_stats, S.targets, 18f);
            SafeSetStat(Warrior8.base_stats, S.critical_chance, 6.0f);
            SafeSetStat(Warrior8.base_stats, S.accuracy, 50f);
            SafeSetStat(Warrior8.base_stats, S.multiplier_speed, 1.0f);
            SafeSetStat(Warrior8.base_stats, S.stamina, 2400f);
            SafeSetStat(Warrior8.base_stats, S.range, 8f);
            SafeSetStat(Warrior8.base_stats, S.attack_speed, 4f);
            SafeSetStat(Warrior8.base_stats, S.multiplier_health, 0.8f);
            SafeSetStat(Warrior8.base_stats, S.multiplier_damage, 0.8f);
            Warrior8.action_attack_target += traitAction.TrueDamage3_AttackAction;
            Warrior8.action_special_effect += traitAction.Warrior9_effectAction;
            Warrior8.action_special_effect += traitAction.Warrior8_Regen;
            AssetManager.traits.add(Warrior8);

            ActorTrait Warrior9 = CreateTrait("Warrior9", "trait/Warrior9", "Warrior");
            SafeSetStat(Warrior9.base_stats, S.warfare, 50f);
            SafeSetStat(Warrior9.base_stats, S.damage, 240000f);
            SafeSetStat(Warrior9.base_stats, S.mass, 140f);
            SafeSetStat(Warrior9.base_stats, S.armor, 60f);
            SafeSetStat(Warrior9.base_stats, S.health, 2400000f);
            SafeSetStat(Warrior9.base_stats, S.speed, 30f);
            SafeSetStat(Warrior9.base_stats, S.area_of_effect, 4f);
            SafeSetStat(Warrior9.base_stats, S.targets, 24f);
            SafeSetStat(Warrior9.base_stats, S.critical_chance, 8.0f);
            SafeSetStat(Warrior9.base_stats, S.accuracy, 60f);
            SafeSetStat(Warrior9.base_stats, S.multiplier_speed, 1.2f);
            SafeSetStat(Warrior9.base_stats, S.stamina, 4000f);
            SafeSetStat(Warrior9.base_stats, S.range, 12f);
            SafeSetStat(Warrior9.base_stats, S.attack_speed, 6f);
            SafeSetStat(Warrior9.base_stats, S.multiplier_health, 1.2f);
            SafeSetStat(Warrior9.base_stats, S.multiplier_damage, 1.2f);
            Warrior9.action_attack_target += traitAction.TrueDamage4_AttackAction;
            Warrior9.action_special_effect += traitAction.Warrior10_effectAction;
            Warrior9.action_special_effect += traitAction.Warrior9_Regen;
            AssetManager.traits.add(Warrior9);

            ActorTrait Warrior10 = CreateTrait("Warrior10", "trait/Warrior10", "Warrior");
            SafeSetStat(Warrior10.base_stats, S.warfare, 70f);
            SafeSetStat(Warrior10.base_stats, S.damage, 1000000f);
            SafeSetStat(Warrior10.base_stats, S.mass, 400f);
            SafeSetStat(Warrior10.base_stats, S.armor, 80f);
            SafeSetStat(Warrior10.base_stats, S.health, 10000000f);
            SafeSetStat(Warrior10.base_stats, S.speed, 50f);
            SafeSetStat(Warrior10.base_stats, S.area_of_effect, 5f);
            SafeSetStat(Warrior10.base_stats, S.targets, 60f);
            SafeSetStat(Warrior10.base_stats, S.critical_chance, 9.0f);
            SafeSetStat(Warrior10.base_stats, S.accuracy, 80f);
            SafeSetStat(Warrior10.base_stats, S.multiplier_speed, 1.5f);
            SafeSetStat(Warrior10.base_stats, S.stamina, 6000f);
            SafeSetStat(Warrior10.base_stats, S.range, 36f);
            SafeSetStat(Warrior10.base_stats, S.attack_speed, 12f);
            SafeSetStat(Warrior10.base_stats, S.multiplier_health, 3.6f);
            SafeSetStat(Warrior10.base_stats, S.multiplier_damage, 3.6f);
            Warrior10.action_attack_target += traitAction.lei_attackAction;
            Warrior10.action_special_effect += traitAction.Warrior11_effectAction;
            Warrior10.action_special_effect += traitAction.Warrior10_Regen;
            Warrior10.action_attack_target += traitAction.TrueDamage5_AttackAction;
            AssetManager.traits.add(Warrior10);

            ActorTrait Warrior11 = CreateTrait("Warrior11", "trait/Warrior11", "Warrior");
            SafeSetStat(Warrior11.base_stats, S.warfare, 100f);
            SafeSetStat(Warrior11.base_stats, S.damage, 2000000f);
            SafeSetStat(Warrior11.base_stats, S.mass, 1600f);
            SafeSetStat(Warrior11.base_stats, S.armor, 100f);
            SafeSetStat(Warrior11.base_stats, S.health, 20000000f);
            SafeSetStat(Warrior11.base_stats, S.speed, 100f);
            SafeSetStat(Warrior11.base_stats, S.area_of_effect, 7f);
            SafeSetStat(Warrior11.base_stats, S.targets, 80f);
            SafeSetStat(Warrior11.base_stats, S.critical_chance, 12.0f);
            SafeSetStat(Warrior11.base_stats, S.accuracy, 100f);
            SafeSetStat(Warrior11.base_stats, S.multiplier_speed, 2.0f);
            SafeSetStat(Warrior11.base_stats, S.stamina, 10000f);
            SafeSetStat(Warrior11.base_stats, S.range, 60f);
            SafeSetStat(Warrior11.base_stats, S.attack_speed, 20f);
            SafeSetStat(Warrior11.base_stats, S.multiplier_health, 7.2f);
            SafeSetStat(Warrior11.base_stats, S.multiplier_damage, 7.2f);
            Warrior11.action_attack_target += traitAction.lei2_attackAction;
            Warrior11.action_special_effect += traitAction.Warrior12_effectAction;
            Warrior11.action_special_effect += traitAction.Warrior11_Regen;
            Warrior11.action_attack_target += traitAction.TrueDamage6_AttackAction;
            AssetManager.traits.add(Warrior11);

            ActorTrait Warrior12 = CreateTrait("Warrior12", "trait/Warrior12", "Warrior");
            SafeSetStat(Warrior12.base_stats, S.warfare, 150f);
            SafeSetStat(Warrior12.base_stats, S.damage, 8000000f);
            SafeSetStat(Warrior12.base_stats, S.mass, 2000f);
            SafeSetStat(Warrior12.base_stats, S.armor, 150f);
            SafeSetStat(Warrior12.base_stats, S.health, 20000000f);
            SafeSetStat(Warrior12.base_stats, S.speed, 300f);
            SafeSetStat(Warrior12.base_stats, S.area_of_effect, 10f);
            SafeSetStat(Warrior12.base_stats, S.targets, 25f);
            SafeSetStat(Warrior12.base_stats, S.critical_chance, 15.0f);
            SafeSetStat(Warrior12.base_stats, S.accuracy, 150f);
            SafeSetStat(Warrior12.base_stats, S.multiplier_speed, 3.0f);
            SafeSetStat(Warrior12.base_stats, S.stamina, 100000f);
            SafeSetStat(Warrior12.base_stats, S.range, 90f);
            SafeSetStat(Warrior12.base_stats, S.attack_speed, 30f);
            SafeSetStat(Warrior12.base_stats, S.multiplier_health, 8f);
            SafeSetStat(Warrior12.base_stats, S.multiplier_damage, 8f);    
            Warrior12.action_attack_target += traitAction.lei3_attackAction;
            Warrior12.action_special_effect += traitAction.Warrior12_Regen;
            Warrior12.action_attack_target += traitAction.TrueDamage7_AttackAction;
            AssetManager.traits.add(Warrior12);

            ActorTrait arcaneTome1 = CreateTrait("arcaneTome1", "trait/arcaneTome1", "arcaneTome");
            SafeSetStat(arcaneTome1.base_stats, S.damage, 500f); // 示例属性提升
            SafeSetStat(arcaneTome1.base_stats, S.health, 500f);
            SafeSetStat(arcaneTome1.base_stats, S.speed, 30f);
            SafeSetStat(arcaneTome1.base_stats, S.armor, 15f);
            SafeSetStat(arcaneTome1.base_stats, S.lifespan, 10f);
            SafeSetStat(arcaneTome1.base_stats, S.stamina, 80f);
            SafeSetStat(arcaneTome1.base_stats, S.attack_speed, 80f);
            SafeSetStat(arcaneTome1.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome1.base_stats, S.multiplier_damage, 0.1f);
            arcaneTome1.rate_inherit = 20; // 设定一定的遗传率
            AssetManager.traits.add(arcaneTome1);

            ActorTrait arcaneTome2 = CreateTrait("arcaneTome2", "trait/arcaneTome2", "arcaneTome");
            SafeSetStat(arcaneTome2.base_stats, S.speed, 80f);
            SafeSetStat(arcaneTome2.base_stats, S.armor, 20f);
            SafeSetStat(arcaneTome2.base_stats, S.damage, 800f); // 示例属性提升
            SafeSetStat(arcaneTome2.base_stats, S.health, 400f);
            SafeSetStat(arcaneTome2.base_stats, S.lifespan, 30f);
            SafeSetStat(arcaneTome2.base_stats, S.stamina, 50f);
            SafeSetStat(arcaneTome2.base_stats, S.attack_speed, 40f);
            SafeSetStat(arcaneTome2.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome2.base_stats, S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome2.base_stats, S.multiplier_speed, 0.2f);
            arcaneTome2.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome2);

            ActorTrait arcaneTome3 = CreateTrait("arcaneTome3", "trait/arcaneTome3", "arcaneTome");
            SafeSetStat(arcaneTome3.base_stats, S.damage, 200f); // 攻击力 +200
            SafeSetStat(arcaneTome3.base_stats, S.health, 1000f); // 生命值 +1000
            SafeSetStat(arcaneTome3.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(arcaneTome3.base_stats, S.armor, 80f); // 护甲 +80
            SafeSetStat(arcaneTome3.base_stats, S.lifespan, 50f);
            SafeSetStat(arcaneTome3.base_stats, S.stamina, 200f);
            SafeSetStat(arcaneTome3.base_stats, S.attack_speed, 20f);
            SafeSetStat(arcaneTome3.base_stats, S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome3.base_stats, S.multiplier_damage, 0.3f);
            SafeSetStat(arcaneTome3.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome3.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome3);

            ActorTrait arcaneTome4 = CreateTrait("arcaneTome4", "trait/arcaneTome4", "arcaneTome");
            SafeSetStat(arcaneTome4.base_stats, S.speed, 60f); // 速度 +60
            SafeSetStat(arcaneTome4.base_stats, S.armor, 50f); // 护甲 +50
            SafeSetStat(arcaneTome4.base_stats, S.damage, 400f); // 攻击力 +400
            SafeSetStat(arcaneTome4.base_stats, S.health, 400f); // 生命值 +400
            SafeSetStat(arcaneTome4.base_stats, S.lifespan, 100f);
            SafeSetStat(arcaneTome4.base_stats, S.stamina, 120f);
            SafeSetStat(arcaneTome4.base_stats, S.attack_speed, 10f);
            SafeSetStat(arcaneTome4.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome4.base_stats, S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome4.base_stats, S.multiplier_speed, 0.3f);
            arcaneTome4.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome4);

            ActorTrait arcaneTome5 = CreateTrait("arcaneTome5", "trait/arcaneTome5", "arcaneTome");
            SafeSetStat(arcaneTome5.base_stats, S.speed, 40f); // 速度 +40
            SafeSetStat(arcaneTome5.base_stats, S.armor, 60f); // 护甲 +60
            SafeSetStat(arcaneTome5.base_stats, S.health, 200f); // 生命值 +200
            SafeSetStat(arcaneTome5.base_stats, S.damage, 300f); // 攻击力 +300 
            SafeSetStat(arcaneTome5.base_stats, S.lifespan, 300f);
            SafeSetStat(arcaneTome5.base_stats, S.stamina, 30f);
            SafeSetStat(arcaneTome5.base_stats, S.attack_speed, 40f);
            SafeSetStat(arcaneTome5.base_stats, S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome5.base_stats, S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome5.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome5.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome5);

            ActorTrait arcaneTome6 = CreateTrait("arcaneTome6", "trait/arcaneTome6", "arcaneTome");
            SafeSetStat(arcaneTome6.base_stats, S.speed, 50f); // 速度 +50
            SafeSetStat(arcaneTome6.base_stats, S.armor, 50f); // 护甲 +50
            SafeSetStat(arcaneTome6.base_stats, S.health, 100f); // 生命值 +100
            SafeSetStat(arcaneTome6.base_stats, S.damage, 200f); // 攻击力 +200 
            SafeSetStat(arcaneTome6.base_stats, S.lifespan, 30f);
            SafeSetStat(arcaneTome6.base_stats, S.stamina, 90f);
            SafeSetStat(arcaneTome6.base_stats, S.attack_speed, 70f);
            SafeSetStat(arcaneTome6.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome6.base_stats, S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome6.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome6.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome6);

            ActorTrait arcaneTome7 = CreateTrait("arcaneTome7", "trait/arcaneTome7", "arcaneTome");
            SafeSetStat(arcaneTome7.base_stats, S.speed, 60f); // 速度 +60
            SafeSetStat(arcaneTome7.base_stats, S.armor, 20f); // 护甲 +20
            SafeSetStat(arcaneTome7.base_stats, S.health, 180f); // 生命值 +180
            SafeSetStat(arcaneTome7.base_stats, S.damage, 120f); // 攻击力 +120 
            SafeSetStat(arcaneTome7.base_stats, S.lifespan, 50f);
            SafeSetStat(arcaneTome7.base_stats, S.stamina, 40f);
            SafeSetStat(arcaneTome7.base_stats, S.attack_speed, 40f);
            SafeSetStat(arcaneTome7.base_stats, S.multiplier_health, 0.3f);
            SafeSetStat(arcaneTome7.base_stats, S.multiplier_damage, 0.1f);
            SafeSetStat(arcaneTome7.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome7.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome7);

            ActorTrait arcaneTome8 = CreateTrait("arcaneTome8", "trait/arcaneTome8", "arcaneTome");
            SafeSetStat(arcaneTome8.base_stats, S.speed, 45f); // 速度 +45
            SafeSetStat(arcaneTome8.base_stats, S.armor, 55f); // 护甲 +55
            SafeSetStat(arcaneTome8.base_stats, S.health, 600f); // 生命值 +600
            SafeSetStat(arcaneTome8.base_stats, S.damage, 100f); // 攻击力 +100 
            SafeSetStat(arcaneTome8.base_stats, S.lifespan, 40f);
            SafeSetStat(arcaneTome8.base_stats, S.stamina, 70f);
            SafeSetStat(arcaneTome8.base_stats, S.attack_speed, 30f);
            SafeSetStat(arcaneTome8.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome8.base_stats, S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome8.base_stats, S.multiplier_speed, 0.2f);
            arcaneTome8.rate_inherit = 20;
            AssetManager.traits.add(arcaneTome8);

            ActorTrait arcaneTome9 = CreateTrait("arcaneTome9", "trait/arcaneTome9", "arcaneTome");
            SafeSetStat(arcaneTome9.base_stats, S.speed, 40f); // 速度 +40
            SafeSetStat(arcaneTome9.base_stats, S.armor, 60f); // 护甲 +60
            SafeSetStat(arcaneTome9.base_stats, S.health, 800f); // 生命值 +800
            SafeSetStat(arcaneTome9.base_stats, S.damage, 240f); // 攻击力 +240 
            SafeSetStat(arcaneTome9.base_stats, S.lifespan, 30f);
            SafeSetStat(arcaneTome9.base_stats, S.stamina, 90f);
            SafeSetStat(arcaneTome9.base_stats, S.attack_speed, 60f);
            SafeSetStat(arcaneTome9.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome9.base_stats, S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome9.base_stats, S.multiplier_speed, 0.2f);
            arcaneTome9.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome9);

            ActorTrait arcaneTome10 = CreateTrait("arcaneTome10", "trait/arcaneTome10", "arcaneTome");
            SafeSetStat(arcaneTome10.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(arcaneTome10.base_stats, S.armor, 10f); // 护甲 +10
            SafeSetStat(arcaneTome10.base_stats, S.health, 2000f); // 生命值 +2000
            SafeSetStat(arcaneTome10.base_stats, S.damage, 90f); // 攻击力 +90 
            SafeSetStat(arcaneTome10.base_stats, S.lifespan, 500f);
            SafeSetStat(arcaneTome10.base_stats, S.stamina, 60f);
            SafeSetStat(arcaneTome10.base_stats, S.attack_speed, 50f);
            SafeSetStat(arcaneTome10.base_stats, S.multiplier_health, 0.3f);
            SafeSetStat(arcaneTome10.base_stats, S.multiplier_damage, 0.3f);
            SafeSetStat(arcaneTome10.base_stats, S.multiplier_speed, 0.3f);
            arcaneTome10.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome10);
            
            ActorTrait arcaneTome11 = CreateTrait("arcaneTome11", "trait/arcaneTome11", "arcaneTome");
            SafeSetStat(arcaneTome11.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(arcaneTome11.base_stats, S.armor, -10f); // 护甲 -10
            SafeSetStat(arcaneTome11.base_stats, S.health, -50f); // 生命值 -50
            SafeSetStat(arcaneTome11.base_stats, S.damage, 5000f); // 攻击力 +5000 
            SafeSetStat(arcaneTome11.base_stats, S.lifespan, -10f);
            SafeSetStat(arcaneTome11.base_stats, S.stamina, -30f);
            SafeSetStat(arcaneTome11.base_stats, S.attack_speed, 100f);
            SafeSetStat(arcaneTome11.base_stats, S.multiplier_health, 0.1f);
            SafeSetStat(arcaneTome11.base_stats, S.multiplier_damage, 0.6f);
            SafeSetStat(arcaneTome11.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome11.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome11);

            ActorTrait arcaneTome12 = CreateTrait("arcaneTome12", "trait/arcaneTome12", "arcaneTome");
            SafeSetStat(arcaneTome12.base_stats, S.speed, 40f);
            SafeSetStat(arcaneTome12.base_stats, S.armor, 1000f);
            SafeSetStat(arcaneTome12.base_stats, S.health, 10000f);
            SafeSetStat(arcaneTome12.base_stats, S.damage, 40f); 
            SafeSetStat(arcaneTome12.base_stats, S.lifespan, 1000f);
            SafeSetStat(arcaneTome12.base_stats, S.stamina, 1000f);
            SafeSetStat(arcaneTome12.base_stats, S.attack_speed, 20f);
            SafeSetStat(arcaneTome12.base_stats, S.multiplier_health, 0.5f);
            SafeSetStat(arcaneTome12.base_stats, S.multiplier_damage, 0.5f);
            SafeSetStat(arcaneTome12.base_stats, S.multiplier_speed, 0.5f);
            arcaneTome12.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome12);

            ActorTrait arcaneTome13 = CreateTrait("arcaneTome13", "trait/arcaneTome13", "arcaneTome");
            SafeSetStat(arcaneTome13.base_stats, S.speed, 80f);
            SafeSetStat(arcaneTome13.base_stats, S.armor, 80f);
            SafeSetStat(arcaneTome13.base_stats, S.health, 800f);
            SafeSetStat(arcaneTome13.base_stats, S.damage, 800f); 
            SafeSetStat(arcaneTome13.base_stats, S.lifespan, 80f);
            SafeSetStat(arcaneTome13.base_stats, S.stamina, 80f);
            SafeSetStat(arcaneTome13.base_stats, S.attack_speed, 80f);
            SafeSetStat(arcaneTome13.base_stats, S.multiplier_health, 0.2f);
            SafeSetStat(arcaneTome13.base_stats, S.multiplier_damage, 0.2f);
            SafeSetStat(arcaneTome13.base_stats, S.multiplier_speed, 0.1f);
            arcaneTome13.rate_inherit = 10;
            AssetManager.traits.add(arcaneTome13);

            ActorTrait NineCharacterSecret1 = CreateTrait("NineCharacterSecret1", "trait/NineCharacterSecret1", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret1.base_stats, S.multiplier_health, 3.0f);
            SafeSetStat(NineCharacterSecret1.base_stats, S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret1.base_stats, S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret1.base_stats, S.area_of_effect, 4f); // 近战范围+4
            AssetManager.traits.add(NineCharacterSecret1);

            // 定义“兵”特质
            ActorTrait NineCharacterSecret2 = CreateTrait("NineCharacterSecret2", "trait/NineCharacterSecret2", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret2.base_stats, S.multiplier_damage, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, S.multiplier_health, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, S.multiplier_speed, 1.8f);
            SafeSetStat(NineCharacterSecret2.base_stats, S.intelligence, 100f);
            SafeSetStat(NineCharacterSecret2.base_stats, S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret2.base_stats, S.area_of_effect, 8f); // 近战范围+8
            AssetManager.traits.add(NineCharacterSecret2);

            ActorTrait NineCharacterSecret3 = CreateTrait("NineCharacterSecret3", "trait/NineCharacterSecret3", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret3.base_stats, S.multiplier_speed, 3.2f);
            SafeSetStat(NineCharacterSecret2.base_stats, S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret3.base_stats, S.intelligence, 50f);
            SafeSetStat(NineCharacterSecret3.base_stats, S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret3.base_stats, S.area_of_effect, 6f); // 近战范围+6
            AssetManager.traits.add(NineCharacterSecret3);

            ActorTrait NineCharacterSecret4 = CreateTrait("NineCharacterSecret4", "trait/NineCharacterSecret4", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret4.base_stats, S.multiplier_speed, 1.2f);
            SafeSetStat(NineCharacterSecret4.base_stats, S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret4.base_stats, S.multiplier_health, 1.0f);
            SafeSetStat(NineCharacterSecret4.base_stats, S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret4.base_stats, S.knockback, 5f); 
            SafeSetStat(NineCharacterSecret4.base_stats, S.area_of_effect, 4f); // 近战范围+4
            AssetManager.traits.add(NineCharacterSecret4);

            ActorTrait NineCharacterSecret5 = CreateTrait("NineCharacterSecret5", "trait/NineCharacterSecret5", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret5.base_stats, S.multiplier_speed, 0.2f);
            SafeSetStat(NineCharacterSecret5.base_stats, S.multiplier_damage, 0.8f);
            SafeSetStat(NineCharacterSecret5.base_stats, S.multiplier_health, 2.0f);
            SafeSetStat(NineCharacterSecret5.base_stats, S.intelligence, 60f);
            SafeSetStat(NineCharacterSecret5.base_stats, S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret5.base_stats, S.area_of_effect, 8f);
            AssetManager.traits.add(NineCharacterSecret5);

            ActorTrait NineCharacterSecret6 = CreateTrait("NineCharacterSecret6", "trait/NineCharacterSecret6", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret6.base_stats, S.multiplier_speed, 0.8f);
            SafeSetStat(NineCharacterSecret6.base_stats, S.multiplier_damage, 2.0f);
            SafeSetStat(NineCharacterSecret6.base_stats, S.multiplier_health, 0.8f);
            SafeSetStat(NineCharacterSecret6.base_stats, S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret6.base_stats, S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret6.base_stats, S.area_of_effect, 10f); // 近战范围+10
            AssetManager.traits.add(NineCharacterSecret6);

            ActorTrait NineCharacterSecret7 = CreateTrait("NineCharacterSecret7", "trait/NineCharacterSecret7", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret7.base_stats, S.multiplier_speed, 2.0f);
            SafeSetStat(NineCharacterSecret7.base_stats, S.multiplier_damage, 0.8f);
            SafeSetStat(NineCharacterSecret7.base_stats, S.multiplier_health, 0.8f);
            SafeSetStat(NineCharacterSecret7.base_stats, S.intelligence, 20f);
            SafeSetStat(NineCharacterSecret7.base_stats, S.knockback, 20f); 
            SafeSetStat(NineCharacterSecret7.base_stats, S.area_of_effect, 6f);
            AssetManager.traits.add(NineCharacterSecret7);

            ActorTrait NineCharacterSecret8 = CreateTrait("NineCharacterSecret8", "trait/NineCharacterSecret8", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret8.base_stats, S.multiplier_speed, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, S.multiplier_damage, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, S.multiplier_health, 0.9f);
            SafeSetStat(NineCharacterSecret8.base_stats, S.intelligence, 1000f);
            SafeSetStat(NineCharacterSecret8.base_stats, S.knockback, 100f); 
            SafeSetStat(NineCharacterSecret8.base_stats, S.area_of_effect, 100f); // 近战范围+100
            AssetManager.traits.add(NineCharacterSecret8);

            ActorTrait NineCharacterSecret9 = CreateTrait("NineCharacterSecret9", "trait/NineCharacterSecret9", "NineCharacterSecrets");
            SafeSetStat(NineCharacterSecret9.base_stats, S.multiplier_speed, 2.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, S.multiplier_damage, 1.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, S.multiplier_health, 2.0f);
            SafeSetStat(NineCharacterSecret9.base_stats, S.intelligence, 10f);
            SafeSetStat(NineCharacterSecret9.base_stats, S.knockback, 10f); 
            SafeSetStat(NineCharacterSecret9.base_stats, S.area_of_effect, 10f); // 近战范围+10
            AssetManager.traits.add(NineCharacterSecret9);

            ActorTrait congenitalPerfection = CreateTrait("congenitalPerfection", "trait/congenitalPerfection", "MartialFoundations");
            AssetManager.traits.add(congenitalPerfection);

        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}