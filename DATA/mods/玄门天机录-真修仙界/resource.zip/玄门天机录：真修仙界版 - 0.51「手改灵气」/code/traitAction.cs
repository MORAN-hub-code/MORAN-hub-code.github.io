using System.Collections.Generic;
using System.Linq;
using System;
using ai;
using ReflectionUtility;
using UnityEngine;
using Cultivatingimmortals.code.utils;
using System.IO;

namespace Cultivatingimmortals.code
{
    internal class traitAction
    {

// 获取境界对应的法术组（按层级分组）
private static Dictionary<string, string[]> GetSpellGroupsByTier()
{
    return new Dictionary<string, string[]>
    {
        // 学徒境法术（零环） - 随机3篇
        {"Tier1", new[] {"sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07"}},
        
        // 正式境法术（一环） - 随机3篇
        {"Tier2", new[] {"sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17", "sorcery18"}},
        
        // 高级境法术（二环） - 随机3篇（合体/大乘/渡劫共享）
        {"Tier3", new[] {"sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28", "sorcery29"}},
        
        // 仙级法术（天衍篇） - 随机1篇（散仙/真仙共享）
        {"Tier4", new[] {"sorcery31", "sorcery32", "sorcery33", "sorcery34", "sorcery35"}}
    };
}

// 获取境界对应的层级
private static string GetGradeTier(string grade)
{
    switch(grade)
    {
        case "Grade01":
        case "Grade02":
            return "Tier1"; // 学徒境
        
        case "Grade1":
        case "Grade2":
        case "Grade3":
            return "Tier2"; // 正式境
        
        case "Grade4": // 合体
        case "Grade5": // 大乘
        case "Grade6": // 渡劫
            return "Tier3"; // 高级境
        
        case "Grade7": // 散仙
        case "Grade8": // 真仙
        case "Grade9": // 金仙
        case "Grade91": // 混元
            return "Tier4"; // 仙级
        
        default:
            return "";
    }
}

// 为演员添加对应层级的法术
private static void AddTierSpells(Actor actor, string tier)
{
    var spellGroups = GetSpellGroupsByTier();
    if (spellGroups.TryGetValue(tier, out var spells))
    {
        // 确定要添加的法术数量
        int spellsToAdd = (tier == "Tier4") ? 1 : 3;
        
        // 随机选择法术（过滤已拥有的）
        var availableSpells = spells.Where(spell => !actor.hasTrait(spell)).ToList();
        
        // 如果可用法术不足，则添加所有可用
        if (availableSpells.Count <= spellsToAdd)
        {
            foreach (var spell in availableSpells)
            {
                actor.addTrait(spell);
            }
        }
        else
        {
            // 随机选择指定数量的法术
            for (int i = 0; i < spellsToAdd; i++)
            {
                int index = Randy.randomInt(0, availableSpells.Count - 1);
                string spell = availableSpells[index];
                actor.addTrait(spell);
                availableSpells.RemoveAt(index);
            }
        }
    }
}

// 为演员添加从当前到目标境界的所有法术
private static void AddAllSpellsUpToGrade(Actor actor, string startGrade, string targetGrade)
{
    // 所有境界的顺序
    string[] allGrades = {
        "Grade0", "Grade01", "Grade02", 
        "Grade1", "Grade2", "Grade3", 
        "Grade4", "Grade5", "Grade6", 
        "Grade7", "Grade8", "Grade9", "Grade91"
    };
    
    // 找到起始和目标境界的索引
    int startIndex = Array.IndexOf(allGrades, startGrade);
    int targetIndex = Array.IndexOf(allGrades, targetGrade);
    
    if (startIndex < 0 || targetIndex < 0) return;
    
    // 记录已经处理过的层级
    var processedTiers = new HashSet<string>();
    
    // 添加从起始到目标境界的所有法术
    for (int i = startIndex; i <= targetIndex; i++)
    {
        string tier = GetGradeTier(allGrades[i]);
        
        // 跳过无效层级或已处理层级
        if (string.IsNullOrEmpty(tier) || processedTiers.Contains(tier)) continue;
        
        // 添加该层级的法术
        AddTierSpells(actor, tier);
        processedTiers.Add(tier);
    }
}

// 完整的顿悟突破方法（最终版）
public static bool EpiphanyBreakthrough(Actor actor, string targetGrade)
{
    if (actor == null) return false;
    
    // 获取当前境界
    string currentGrade = "";
    foreach (string grade in new[] {"Grade91", "Grade9", "Grade8", "Grade7", "Grade6", "Grade5", 
                                   "Grade4", "Grade3", "Grade2", "Grade1", "Grade02", "Grade01", "Grade0"})
    {
        if (actor.hasTrait(grade))
        {
            currentGrade = grade;
            break;
        }
    }
    
    // 检查目标境界是否高于当前境界
    if (!IsGradeHigher(targetGrade, currentGrade)) return false;
    
    // 执行突破 - 更新境界特质
    upTrait(currentGrade, targetGrade, actor, 
        new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
        new string[] { });
    
    // 添加从当前到目标境界的所有法术
    AddAllSpellsUpToGrade(actor, currentGrade, targetGrade);
    
    // 更新后缀
    UpdateXianSuffix(actor, targetGrade);
    
    // 真仙境使用散仙尊号
    string titleGrade = targetGrade == "Grade8" ? "Grade7" : targetGrade;
    if (new[] {"Grade6", "Grade7", "Grade8", "Grade9", "Grade91"}.Contains(targetGrade))
    {
        ApplyXianTitle(actor, titleGrade);
    }
    
    // 仙级境界处理
    if (new[] {"Grade7", "Grade8", "Grade9", "Grade91"}.Contains(targetGrade))
    {
        // 随机添加一本功法（三选一）
        string[] books = { "meditation1", "meditation2", "meditation3" };
        var availableBooks = books.Where(book => !actor.hasTrait(book)).ToList();
        
        if (availableBooks.Count > 0)
        {
            int index = Randy.randomInt(0, availableBooks.Count - 1);
            actor.addTrait(availableBooks[index]);
        }
        
        // 移除低阶天赋（保留高阶天赋）
        string[] lowTalents = { "flair1", "flair2", "flair3", "flair4","flair5",  };
        foreach (string talent in lowTalents)
        {
            if (actor.hasTrait(talent))
            {
                actor.removeTrait(talent);
            }
        }
    }
    
    // 添加顿悟标记防止重复顿悟
    actor.addTrait("has_epiphany");
    
    return true;
}

// 判断境界高低
private static bool IsGradeHigher(string newGrade, string currentGrade)
{
    // 境界等级顺序
    string[] gradeOrder = {
        "Grade0", "Grade01", "Grade02", 
        "Grade1", "Grade2", "Grade3", 
        "Grade4", "Grade5", "Grade6", 
        "Grade7", "Grade8", "Grade9", "Grade91"
    };
    
    int currentIndex = Array.IndexOf(gradeOrder, currentGrade);
    int newIndex = Array.IndexOf(gradeOrder, newGrade);
    
    return newIndex > currentIndex;
}
private static string GetTizhiDisplayName(string tizhiId)
{
    return tizhiId switch
    {
        "tizhi01" => "星髓玉骨",
        "tizhi02" => "归墟冥脉",
        "tizhi03" => "后土玄躯",
        "tizhi04" => "青帝长生体",
        "tizhi05" => "劫雷法身",
        "tizhi06" => "太阴琉璃心",
        "tizhi07" => "焚世烈阳体",
        "tizhi08" => "虚空无相体",
        "tizhi09" => "血海修罗身",
        "tizhi10" => "剑魄通明体",
        _ => "未知体质"
    };
}
        // ======== 后缀系统 ========
private static readonly Dictionary<string, string> _xianSuffixMap = new Dictionary<string, string>
{
    {"Grade0", "引气"},
    {"Grade01", "筑基"},
    {"Grade02", "金丹"},
    {"Grade1", "元婴"},
    {"Grade2", "化神"},
    {"Grade3", "炼虚"},
    {"Grade4", "合体"},
    {"Grade5", "大乘"},
    {"Grade6", "渡劫"},
    {"Grade7", "散仙"},
    {"Grade8", "真仙"},
    {"Grade9", "金仙"},
    {"Grade91", "混元"}
};

private static void UpdateXianSuffix(Actor actor, string newTrait)
{
    if (_xianSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        
        // 1. 分离基础名称（包括尊号）和旧境界后缀
        int lastDashIndex = currentName.LastIndexOf('-');
        string basePart = lastDashIndex >= 0 
            ? currentName.Substring(0, lastDashIndex).Trim() 
            : currentName;
        
        // 2. 如果达到渡劫期或更高境界，移除"圣体"和"道胎"后缀
        string[] highGradeTraits = {"Grade6", "Grade7", "Grade8", "Grade9", "Grade91"};
        if (highGradeTraits.Contains(newTrait))
        {
            basePart = basePart
                .Replace(" 圣体", "")
                .Replace(" 道胎", "")
                .Trim();
        }
        
        // 3. 设置新名称：基础名称 + 新境界后缀
        actor.setName($"{basePart}-{suffix}");
    }
}

private static void ApplyXianTitle(Actor actor, string newTrait)
{
    if (_xianTitleMap.TryGetValue(newTrait, out string[] titles))
    {
        string currentName = actor.getName();
        
        // 1. 分离境界后缀（最后一个连字符后的内容）
        int lastDashIndex = currentName.LastIndexOf('-');
        string suffixPart = lastDashIndex > 0 
            ? currentName.Substring(lastDashIndex) // 包含连字符和后缀
            : "";
        
        string basePart = lastDashIndex > 0 
            ? currentName.Substring(0, lastDashIndex).Trim()
            : currentName;
        
        // 2. 移除旧尊号（如果有）
        int firstDashIndex = basePart.IndexOf('-');
        if (firstDashIndex > 0)
        {
            basePart = basePart.Substring(firstDashIndex + 1).Trim();
        }
        
        // 3. 如果达到渡劫期或更高境界，移除"圣体"和"道胎"后缀
        string[] highGradeTraits = {"Grade6", "Grade7", "Grade8", "Grade9", "Grade91"};
        if (highGradeTraits.Contains(newTrait))
        {
            basePart = basePart
                .Replace(" 圣体", "")
                .Replace(" 道胎", "")
                .Trim();
        }
        
        // 4. 随机选择新尊号
        string title = titles[UnityEngine.Random.Range(0, titles.Length)];
        
        // 5. 设置新名称：新尊号 + 基础名称 + 境界后缀
        actor.setName($"{title}-{basePart}{suffixPart}");
    }
}


// ======== 尊号系统 ========
private static readonly Dictionary<string, string[]> _xianTitleMap = new Dictionary<string, string[]>
{
    // 渡劫期尊号
    {"Grade6", new string[] {
    "清玄道人",   "玉虚真人",   "玄光真人",   "烈风散人",   "白羽道人",
    "云岚真人",   "空灵道人",   "万象散人",   "赤焰灵君",   "云溪子",
    "青松道人",   "问心上人",   "采薇真人",   "听风子",    "栖霞道人",
    "竹隐子",     "漱石上人",   "怀真真人",   "守拙道人",   "折梅子",
    "听松上人",   "闲云真人",   "清溪道人",   "栖真子",    "抚琴上人",
    "玉尘真人",   "观云道人",   "静虚子",     "月华真人",   "松风道人",
    "寒梅子",     "听雨上人",   "清虚真人",   "丹霞道人",   "玄素子",
    "问道上人",   "玉泉真人",   "云鹤道人",   "静松子",    "听风上人",
    "玄真真人",   "竹溪道人",   "素月子",     "玄清真人",   "云游道人",
    "雪松子",     "听山上人",   "清泉真人",   "闲鹤道人",   "玉松子",
    "观山上人",   "松月道人",   "玄松子",     "听虚上人",   "云泉真人",
    "竹鹤道人",   "明墟真人",   "清微上人",   "玉宸道人",   "太虚子",
    "归藏真人",   "玄霄上人",   "紫阳道人",   "青冥子",    "天枢真人",
    "云华上人",   "玄真道人",   "玉虚子",     "太素真人",   "清玄上人",
    "玉衡道人",   "玄月子",     "太乙真人",   "云虚上人",   "青阳道人",
    "玄光子",     "太清真人",   "玉清上人",   "玄河道人",   "云月子",
    "太玄真人",   "玉阳上人",   "玄风道人",   "云虚子",    "太和真人",
    "玉宸上人",   "赤渊上人",   "血饮道人",   "冥骨真人",   "煞魂子",
    "焚心上人",   "血河道人",   "阴煞真人",   "血魄子",    "冥火上人",
    "血煞道人",   "黄泉真人",   "幽魄上人",   "冥河道人",   "煞月子",
    "葬魂真人",   "阴冥上人",   "鬼河道人",   "幽月子",    "冥魂真人",
    "阴魄上人",   "禅心真人",   "空相上人",   "莲生道人",   "伽蓝子",
    "妙法真人",   "慧觉上人",   "净尘道人",   "慈航真人",   "慧海上人",
    "星谶上人",   "遁甲道人",   "棋枰子",    "符海真人",   "阵枢上人",
    "天衍道人",   "玄算子",     "灵枢真人",   "天机上人",   "符箓道人",
    "丹鼎真人",   "器宗上人",   "药尘子",    "灵傀道人",   "云舟真人",
    "宝鉴上人",   "丹霞道人",   "器灵子",    "药鼎真人",   "云商上人",
    "玄戈上人",   "栖霞道人",   "苍梧子",    "北冥真人",   "南离上人",
    "灵虚真人"
    }},
    
    // 散仙期尊号
    {"Grade7", new string[] {
    "璇玑星君",   "瑶光圣主",   "天罗仙尊",   "紫极圣君",   "洞玄仙尊",
    "玉衡真仙",   "太微圣尊",   "天权仙主",   "开阳圣君",   "摇光仙尊",
    "云笈玉圣",   "天河仙君",   "碧落圣主",   "玄穹仙尊",   "丹霄圣君",
    "青阙仙使",   "玉京真仙",   "太渊圣尊",   "天枢仙主",   "紫垣圣君",
    "太虚仙君",   "玉宸圣主",   "九霄仙尊",   "玄穹圣君",   "紫微仙使",
    "洞冥真仙",   "青冥圣尊",   "天衍仙主",   "琅琊圣君",   "归墟仙尊",
    "北斗玉仙",   "太皓圣主",   "云华仙尊",   "乾坤圣君",   "玄天仙使",
    "青阳玉尊",   "太素仙君",   "玉清圣主",   "天枢仙尊",   "沧溟圣君",
    "紫府真仙",   "九光圣尊",   "玄黄仙主",   "洞玄圣君",   "凌霄仙尊",
    "太乙玉圣",   "天罡仙君",   "青霄圣主",   "玄冥仙尊",   "玉虚圣君",
    "紫垣星君",   "天市仙尊",   "太皓圣君",   "勾陈仙使",   "洞明星主",
    "玉衡圣尊",   "天璇真君",   "北辰仙主",   "南斗圣君",   "文昌仙尊",
    "武曲真宰",   "破军圣主",   "左辅仙君",   "右弼圣尊",   "天魁真宰",
    "天钺仙主",   "禄存圣君",   "文曲仙尊",   "廉贞仙尊",   "天府圣主",
    "太阴仙君",   "太阳圣尊",   "天梁真宰",   "天相仙主",   "七杀圣君",
    "擎羊仙尊",   "陀罗仙君",   "火星圣主",   "铃星仙君",   "地劫圣尊",
    "地空仙君",   "天刑仙主",   "天姚圣君",   "红鸾仙尊",   "天喜仙君",
    "龙池圣主",   "凤阁仙君",   "台辅圣尊",   "封诰仙主",   "恩光仙主",
    "九幽魔尊",   "血狱圣主",   "冥煞仙君",   "噬魂魔尊",   "玄阴圣主",
    "万劫魔君",   "赤炼仙尊",   "黑天魔圣",   "无生魔尊",   "骨煞圣君",
    "冥狱邪尊",   "血煞魔主",   "蚀日鬼君",   "吞界魔尊",   "绝仙煞主",
    "焚宇邪君",   "灭魂魔尊",   "断空煞君",   "陨星鬼主",   "葬神邪尊",
    "万毒尸尊",   "千魂蛊主",   "阴煞傀君",   "血魇毒尊",   "尸魔魂主",
    "骨灵邪君",   "怨煞毒尊",   "腐尸蛊主",   "阴鸦魂君",   "疫鬼毒主",
    "百尸仙君",   "千蛊圣主",   "影劫仙尊",   "阴符魔圣",   "毒煞仙君",
    "魂寂圣主",   "血炼仙尊",   "九阴真圣",   "尸解仙君",   "无常圣尊"
    }},
    
    // 金仙境尊号
    {"Grade9", new string[] {
    "太虚量劫真王", "紫宸星律圣王", "终始轮转仙王", "九重天阙灵尊",
    "洞玄真冥法圣", "玄黄开辟真宰", "混虚通明圣君", "太乙量劫法王",
    "赤混元墟灵王", "玉宸启元圣尊", "清浊分形真君", "禹余太虚法尊",
    "元载空洞圣宰", "虚王劫运真王", "赤明量劫法王", "冥通玄寂灵君",
    "梵炁周流圣主", "碧落归墟真王", "丹华紫宸法王", "青玄劫灭圣尊",
    "白墟量劫真宰", "玄都妙相法尊", "神霄玉宸灵尊", "紫微垣律圣王",
    "勾陈劫运真君", "后劫王极法尊", "南华长生圣王", "东极青华真尊",
    "西极皓灵法君", "北宸量劫圣主", "混虚轮转圣尊", "量劫终始法王",
    "玄穹开辟真宰", "九寰通明灵尊", "太乙道衍圣君", "赤混量生法尊",
    "玉宸玄枢灵尊", "清浊归墟圣尊", "禹余量劫真君", "元载通幽法尊",
    "虚王寂灭圣宰", "赤明道枢真尊", "冥通玄量法尊", "梵炁轮转灵君",
    "碧落道生圣主", "丹华通玄真尊", "青玄量灭法尊", "白墟道枢圣尊",
    "玄都混虚真宰", "神霄通明法尊", "紫微量劫灵尊", "勾陈道衍圣王",
    "后劫通玄真君", "南华量生法尊", "东极道枢圣王", "西极混虚真王",
    "北宸通幽法君", "中天量劫圣主", "天梁玄道真宰", "七杀混虚灵王",
    "天府量劫圣王", "太阴道衍真宰", "太阳通幽法尊", "擎羊玄穹圣君",
    "陀罗混虚真宰", "量劫始源真王", "归墟终律圣王", "玄穹开辟仙王",
    "太易轮转灵尊", "混沌通冥法圣", "鸿蒙量生真宰", "虚海溯光圣君",
    "终焉启元法王", "元初寂灭灵王", "太始归真圣王", "空无分形真君",
    "终末太虚法尊", "万道劫运圣宰", "永劫量生真尊", "玄牝轮转法王",
    "终始寂灭灵君", "梵相周流圣主", "量因归墟真王", "丹元紫极法王",
    "青冥劫灭圣尊", "白洞量生真宰", "玄相妙有法王", "神寂玉宸灵王",
    "紫极终律圣尊", "劫运轮转真君", "后因王极法尊", "南冥长生圣王",
    "东墟青华真王", "西极玄冥法君", "北冥量劫圣主", "太初因轨法王",
    "洞虚玄相圣王", "玄宇星核真宰", "紫寰辰脉灵尊", "太素质生圣君",
    "九因终律真尊", "青霄星漩法尊", "碧落玄核圣尊", "丹寰云汉灵尊",
    "归因星移真君",
    "永劫归墟魔尊", "冥墟焚宇邪尊", "万相寂灭冥君", "无间永夜魔尊",
    "黑渊蚀日邪尊", "赤炼焚宙冥尊", "终湮焚宙魔尊", "永寂蚀空邪主",
    "量劫葬道冥尊", "绝因噬界鬼尊", "玄灭归墟魔君", "终末湮因邪尊",
    "破道焚相冥主", "绝源蚀魂魔尊", "湮宇寂灭邪君", "永夜葬因鬼主"
    }},
    
    // 混元境尊号
    {"Grade91", new string[] {
    "玉虚紫极道祖", "上清玄穹天尊", "太初混元仙帝", "九宸青冥道主",
    "洞真玉华天尊", "玄黄造化道祖", "紫府通明仙帝", "太乙救苦天尊",
    "赤明开天道主", "玉宸启圣道祖", "清微玄化天尊", "禹余大罗仙帝",
    "郁单无量道主", "虚皇太素天尊", "赤混太无道祖", "冥寂玄通仙帝",
    "太虚玄穹道祖", "紫宸星律天尊", "终始轮转仙帝", "九重天阙道主",
    "洞玄真冥天尊", "玄黄开辟道祖", "混虚通明仙帝", "太乙度厄天尊",
    "赤混元墟道主", "玉宸启元道祖", "清浊分形天尊", "禹余太虚仙帝",
    "元载空洞道主", "虚皇劫运天尊", "赤明量劫道祖", "冥通玄寂仙帝",
    "梵炁周流天尊", "碧落归墟道主", "丹华紫宸道祖", "青玄劫灭天尊",
    "白墟量劫仙帝", "玄都妙相道主", "神霄玉宸真祖", "紫微垣律天尊",
    "勾陈劫运仙帝", "后劫皇极道祖", "南华长生天尊", "东极青华道主",
    "西极皓灵仙祖", "北宸量劫天尊", "南垣司命道祖", "五劫轮转仙帝",
    "三垣律令天尊", "雷劫普化道主", "文枢启明仙祖", "真劫荡魔天尊",
    "幽都玄冥道祖", "岱宗量劫仙帝", "太始归真道祖", "鸿蒙量劫天尊",
    "玄元开辟仙帝", "虚海溯光道主", "终焉轮转天尊", "混沌通冥仙帝",
    "太易量生道祖", "元初寂灭天尊", "空无分形仙帝", "终末太虚道主",
    "万道劫运天尊", "永劫量生仙帝", "玄牝轮转道祖", "终始寂灭天尊",
    "梵相周流仙帝", "量因归墟道祖", "丹元紫极天尊", "青冥劫灭仙帝",
    "白洞量生道主", "玄相妙有天尊", "神寂玉宸仙帝", "紫极终律道祖",
    "劫运轮转天尊", "后因皇极仙帝", "南冥长生道主", "东墟青华天尊",
    "西极玄冥仙帝", "北冥量劫道祖", "太初因轨天尊", "洞虚玄相仙帝",
    "玄宇星核道主", "紫寰辰脉天尊", "太素质生仙帝", "九因终律道祖",
    "青霄星漩天尊", "碧落玄核仙帝", "丹寰云汉道主", "归因星移天尊",
    "太素玄枢仙帝", "紫宸终始道祖",

    // 混元魔道
    "永劫归墟魔祖", "冥墟焚宇妖帝", "玄煞量劫道主", "终末劫运天尊",
    "万相寂灭鬼祖", "无间永夜魔帝", "黑渊蚀日道祖", "赤炼焚宙魔尊",
    "阴墟统御天尊", "玄牝噬道寂主", "罗酆永劫鬼帝", "阿鼻量劫魔祖",
    "黄泉渡灭天尊", "幽劫夺道魔帝", "七终劫运道祖", "贪劫噬宇魔尊",
    "破量真空天尊", "灭世劫磨道主", "永寂轮转魔祖", "业劫红莲魔帝"
    }}
};
        //以下为拥有这个巫术状态的效果
        public static bool attack_Ring05(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 10f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示火的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_fire);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        public static bool attack_Ring25(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 900f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示感染的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_infected);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        //以下为巫术
        public static bool attack_sorcery01(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring01", 3f); //零环•轻身术
            }

            return true;
        }

        public static bool attack_sorcery02(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pTarget.a.addStatusEffect("Ring05", 3f); //零环•烈焰之握
            }

            return true;
        }

        public static bool attack_sorcery03(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pTarget.a.addStatusEffect("Ring02", 3f); //零环•水幻迷障
            }

            return true;
        }

        public static bool sorcery04_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(2); //零环•生命祈愈
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery05(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring03", 3f); //零环•大地壁垒
            }

            return true;
        }

        public static bool attack_sorcery06(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring04", 3f); //零环•蔓藤囚牢
            }

            return true;
        }

        public static bool attack_sorcery07(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring06", 3f); //零环•鹰隼凝视
            }

            return true;
        }

        public static bool attack_sorcery11(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.7f)
            {
                pTarget.a.addStatusEffect("Ring11", 6f); //一环•疲惫之手
            }

            return true;
        }

        public static bool attack_sorcery12(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring12", 6f); //一环•缠绕之网
            }

            return true;
        }

        public static bool attack_sorcery13(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring13", 6f); //一环•土之坚甲
            }

            return true;
        }

        public static bool sorcery14_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(23); //一环•复苏之流
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery15(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring14", 6f); //一环•风行术
            }

            return true;
        }

        public static bool attack_sorcery16(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring15", 6f); //一环•水雾术
            }

            return true;
        }

        public static bool attack_sorcery17(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring16", 6f); //一环•气机牵引
            }

            return true;
        }

        public static bool attack_sorcery18(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring17", 6f); //一环•破甲附魔
            }

            return true;
        }

        public static bool attack_sorcery22(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring22", 8f); //二环•星之致幻
            }

            return true;
        }

        public static bool attack_sorcery23(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            const int drainAmount = 150; // 定义要汲取的血量
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false; // 如果施法者无效，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false; // 如果目标是建筑，则返回false
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health <= 1)
            {
                return false; // 如果没有足够的血量，则返回false
            }

            // 目标有足够的血量，执行汲取操作
            pTarget.a.spawnParticle(Toolbox.makeColor("#FF0000"));
            int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health - 1); // 实际汲取的血量，确保目标至少保留1点血量
            pTarget.a.data.health -= actualDrain; // 减少目标的血量
            pSelf.a.data.health = Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量

            return true; // 汲取成功，返回true
        }

        public static bool attack_sorcery24(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring24", 8f); //二环•岩石护壁
            }

            return true;
        }

        public static bool sorcery25_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000); //二环•生命涌泉
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery26(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring25", 5f); //5秒状态:二环•生命流逝
            }

            return true;
        }

        public static bool attack_sorcery27(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring26", 8f); //二环•因果印记
            }

            return true;
        }

        public static bool attack_sorcery28(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring27", 8f); //二环•相位星痕步
            }

            return true;
        }

        public static bool attack_sorcery29(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring28", 8f); //二环•贯穿之锋
            }

            return true;
        }

        public static bool attack_sorcery31(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            if (UnityEngine.Random.value < 1f)//三环•斥力场
            {
                Actor a = pTarget.a;
                Actor s = pSelf.a;

                EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                return false;
            }

            return false;
        }

        public static bool attack_sorcery32(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 特效的随机大小
            float explosionScaleMin = 0.1f;
            float explosionScaleMax = 0.3f;
            float explosionScale = UnityEngine.Random.Range(explosionScaleMin, explosionScaleMax);

            if (UnityEngine.Random.value < 1f) //三环•裂界爆炎
            {
                // 使用随机大小生成爆炸特效
                EffectsLibrary.spawnAtTileRandomScale("fx_explosion_tiny", pTile, explosionScale, explosionScale);
            }

            return true;
        }

        public static bool attack_sorcery33(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //三环•雷霆术
            {
                MapBox.spawnLightningMedium(pTile, 0.25f);
            }

            return false;
        }

        public static bool sorcery34_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }

            // 获取血量
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();

            // 检查血量是否低于60%
            if (currentHealth < maxHealth * 0.6f)
            {
                // 如果血量低于60%，则为目标添加血眸状态
                pSelf.a.addStatusEffect("Ring34", 10f);
            }

            return true;
        }

        public static bool Grade91_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();
            if (currentHealth < maxHealth * 0.8f)
            {
                pSelf.a.addStatusEffect("Ring92", 30f);// 检查血量是否低于80%
            }
            if (currentHealth < maxHealth * 0.5f)
            {
                pSelf.a.addStatusEffect("Ring93", 30f);// 检查血量是否低于50%
            }

            return true;
        }

        public static bool attack_Grade91(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pTarget == null)
            {
                return false;
            }
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }
            if (pTile == null)
            {
                return false;
            }
            if (UnityEngine.Random.value < 0.2f)
            {
                EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
            }
            return true;
        }

                // 特殊体质真伤
        public static bool Tizhi01_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.25f)) // 25%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.8f); // 80%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi02_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.30f)) // 30%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.7f); // 70%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi03_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.20f)) // 20%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 1.5f); // 150%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi04_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.35f)) // 35%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.6f); // 60%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi05_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.40f)) // 40%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.75f); // 75%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi06_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.45f)) // 45%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.5f); // 50%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi07_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.25f)) // 25%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 2.0f); // 200%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi08_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.30f)) // 30%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 0.9f); // 90%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi09_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.35f)) // 35%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 1.2f); // 120%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi10_TrueDamage(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                if (Randy.randomChance(0.20f)) // 20%几率
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 3.0f); // 300%攻击力
                    
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                }
            }
            return false;
        }

        public static bool Tizhi01_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf != null && pSelf.isActor() && Randy.randomChance(0.1f))
            {
                pSelf.a.addStatusEffect("Ring24", 5f); // 岩石护壁效果
                return true;
            }
            return false;
        }

        public static bool Tizhi02_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor() && Randy.randomChance(0.08f))
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                int drainAmount = 50;
                if (targetActor.data.health > drainAmount)
                {
                    targetActor.data.health -= drainAmount;
                    attacker.data.health = Mathf.Min(attacker.getMaxHealth(), attacker.data.health + drainAmount);
                    return true;
                }
            }
            return false;
}

        public static bool Tizhi03_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && Randy.randomChance(0.12f))
            {
                EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.1f, 4f);
                return true;
            }
            return false;
        }

        public static bool Tizhi04_SpecialEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor actor = pTarget.a;
                if (actor.data.health < actor.getMaxHealth())
                {
                    actor.restoreHealth(5);
                    return true;
                }
            }
            return false;
        }

        public static bool Tizhi05_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && Randy.randomChance(0.15f))
            {
                MapBox.spawnLightningMedium(pTile, 0.1f);
                return true;
            }
            return false;
        }

        public static bool Tizhi06_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && Randy.randomChance(0.1f))
            {
                pTarget.a.addStatusEffect("Ring02", 4f); // 水幻迷障效果
                return true;
            }
            return false;
        }

        public static bool Tizhi07_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && Randy.randomChance(0.12f))
            {
                EffectsLibrary.spawn("fx_explosion_tiny", pTile, "Bomb", null, 0f, -1f, -1f);
                return true;
            }
            return false;
        }

        public static bool Tizhi08_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf != null && pSelf.isActor() && Randy.randomChance(0.15f))
            {
                pSelf.a.addStatusEffect("Ring28", 3f); // 相位星痕步效果
                return true;
            }
            return false;
        }


// 血海修罗身特殊效果 - 攻击时10%概率回复自身最大生命值的5%
public static bool Tizhi09_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
{
    if (pSelf != null && pSelf.isActor() && pTarget != null && pTarget.isActor() && Randy.randomChance(0.1f))
    {
        Actor attacker = pSelf.a;
        
        // 计算最大生命值的5%
        float maxHealth = attacker.getMaxHealth();
        int healAmount = (int)(maxHealth * 0.05f);
        
        // 确保至少回复1点生命
        if (healAmount < 10) healAmount = 10;
        
        // 回复生命
        attacker.restoreHealth(healAmount);
        
        return true;
    }
    return false;
}


        public static bool Tizhi10_SpecialEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && Randy.randomChance(0.05f))
            {
                float damage = pSelf.a.stats["damage"] * 0.3f;
                pTarget.getHit(damage, true, AttackType.Other, null, true, false);
                return true;
            }
            return false;
        }

        //以下为手动增加能量
        public static bool Bestow1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+1);
            pTarget.a.removeTrait("Bestow1"); 

            return true;
        }

        public static bool Bestow2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+5);
            pTarget.a.removeTrait("Bestow2"); 

            return true;
        }

        public static bool Bestow3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+10);
            pTarget.a.removeTrait("Bestow3"); 

            return true;
        }

        public static bool Bestow4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+20);
            pTarget.a.removeTrait("Bestow4");

            return true;
        }

        public static bool Bestow5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+50);
            pTarget.a.removeTrait("Bestow5");

            return true;
        }

        public static bool Bestow6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+100);
            pTarget.a.removeTrait("Bestow6");

            return true;
        }

        public static bool Bestow7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+200);
            pTarget.a.removeTrait("Bestow7");

            return true;
        }

        public static bool Bestow8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+500);
            pTarget.a.removeTrait("Bestow8");

            return true;
        }

        public static bool Bestow9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeYuanNeng(+1000);
            pTarget.a.removeTrait("Bestow9");

            return true;
        }

        public static bool Bestow91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.ChangeMeditation(+1);
            pTarget.a.removeTrait("Bestow91");

            return true;
        }

        public static bool Bestow92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+5);
            pTarget.a.removeTrait("Bestow92");
            return true;
        }

        public static bool Bestow93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+10);
            pTarget.a.removeTrait("Bestow93");
            return true;
        }

        public static bool Bestow94_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+20);
            pTarget.a.removeTrait("Bestow94");
            return true;
        }

        public static bool Bestow95_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+50);
            pTarget.a.removeTrait("Bestow95");
            return true;
        }

        public static bool Bestow96_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+100);
            pTarget.a.removeTrait("Bestow96");
            return true;
        }

        public static bool Bestow97_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+200);
            pTarget.a.removeTrait("Bestow97");
            return true;
        }

        public static bool Bestow98_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+500);
            pTarget.a.removeTrait("Bestow98");
            return true;
        }

        public static bool Bestow99_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (!pTarget.isActor()) return false;
            Actor a = pTarget.a;
            a.ChangeMeditation(+1000);
            pTarget.a.removeTrait("Bestow99");
            return true;
        }



        //以下为境界带的再生
        public static bool Grade0_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade01_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(6);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade02_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(220);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(420);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(620);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(7000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(30000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade91_EffectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2000000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(90);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(180);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        
        public static bool flair92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool hunger_Grade91(BaseSimObject pTarget, WorldTile pTile = null) //始祖的饱食度
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            if (a != null)
            {
                a.data.nutrition = 100; // 不会饥饿，饱食度一直为100%
            }
            return true;
        }
        
        public static bool Grade91_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (UnityEngine.Random.value < 0.1f)
            {
                ActionLibrary.castTornado(null, pTarget, null);
            }

            return true;
        }
        private static string GetRandomTrait(string[] additionalTraits)
        {
            return additionalTraits[UnityEngine.Random.Range(0, additionalTraits.Length)];
        }

        public static bool Grade0_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 9.99)
            {
                return false;
            }

            string[] forbiddenTraits =
            {
                "Grade01", "Grade02", "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8",
                "Grade9", "Grade91"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait("特质", "Grade0", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
                new string[] { "特质" });
                UpdateXianSuffix(a, "Grade0");

            return true;
        }

        private static string GetNewRandomTrait(string[] additionalTraits)
        {
            // 逻辑从 additionalTraits 中随机选择一个特质
            int randomIndex = UnityEngine.Random.Range(0, additionalTraits.Length);
            return additionalTraits[randomIndex];
        }

        public static bool Grade01_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 29.99)
            {
                return false;
            }


            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade01", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade0" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade01");
                // ===== 新增逻辑：检查是否为圣体或道胎，并按概率赋予随机体质 =====
if (a.hasTrait("flair6") || a.hasTrait("flair7"))
{
    // 根据特质类型设置不同的概率
    float probability = a.hasTrait("flair7") ? 0.6f : 0.4f; // 道胎60%，圣体40%
    
    if (Randy.randomChance(probability))
    {
        // 体质权重配置
        var tizhiWeights = new (string traitId, int weight, string displayName)[]
        {
            ("tizhi01", 15, "星髓玉骨"),
            ("tizhi02", 12, "归墟冥脉"),
            ("tizhi03", 10, "后土玄躯"),
            ("tizhi04", 18, "青帝长生体"),
            ("tizhi05", 20, "劫雷法身"),
            ("tizhi06", 14, "太阴琉璃心"),
            ("tizhi07", 22, "焚世烈阳体"),
            ("tizhi08", 16, "虚空无相体"),
            ("tizhi09", 16, "血海修罗身"),
            ("tizhi10", 18, "剑魄通明体")
        };
        int totalWeight = tizhiWeights.Sum(t => t.weight);
        int randomValue = Randy.randomInt(0, totalWeight);
        string selectedTizhi = "tizhi01";

        foreach (var tizhi in tizhiWeights)
        {
            if (randomValue < tizhi.weight)
            {
                selectedTizhi = tizhi.traitId;
                break;
            }
            randomValue -= tizhi.weight;
        }

        // 添加体质特质和标记
        a.addTrait(selectedTizhi, false);
        a.addTrait("has_tizhi", false); // 标记已觉醒体质

        // 播放特效和提示
        a.spawnParticle(new Color(0.8f, 0.2f, 0.8f));
        a.startShake(0.7f, 0.3f, true, false);

        string tizhiName = tizhiWeights.First(t => t.traitId == selectedTizhi).displayName;
        string messageKey = a.hasTrait("flair7") ? "Tizhi_Awaken_Base_Daotai" : "Tizhi_Awaken_Base_Shengti";
        string message = string.Format(LocalizedTextManager.getText(messageKey, null), a.getName(), tizhiName);
        ActionLibrary.showWhisperTip(message);
        PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
    }
}

            return true;
        }

        public static bool Grade02_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addStatusEffect("Ring01");
            if (a.GetYuanNeng() <= 59.99)
            {
                return false;
            }

            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade02", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade01" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade02");

            return true;
        }

        public static bool Grade1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 119.99)
            {
                return false;
            }

            a.ChangeYuanNeng(-18);
            double successRate = 0.6; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.9;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.9;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.8;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("flair6"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair7"))
            {
                successRate = 0.9;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }


            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17", "sorcery18" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            // ==== 道源体质觉醒逻辑 ====
            if (randomValue <= successRate && // 突破成功
                !a.hasTrait("has_tizhi") &&   // 还没有道源体质
                a.getAge() < 120 * 60)        // 年龄小于120岁（一年60天）
            {
                // 检查是否拥有任意天赋（flair1到flair7）
                bool hasFlairTrait = false;
                for (int i = 1; i <= 7; i++)
                {
                    if (a.hasTrait($"flair{i}"))
                    {
                        hasFlairTrait = true;
                        break;
                    }
                }
                
                // 0.6%概率觉醒道源体质
                if (hasFlairTrait && Randy.randomChance(0.006f))
                {
                    // 随机选择一种道源体质
                    string[] tizhiTraits = {
                        "tizhi01", "tizhi02", "tizhi03", "tizhi04", "tizhi05",
                        "tizhi06", "tizhi07", "tizhi08", "tizhi09", "tizhi10"
                    };
                    
                    string selectedTizhi = tizhiTraits[Randy.randomInt(0, tizhiTraits.Length - 1)];
                    
                    // 添加体质特质
                    a.addTrait(selectedTizhi);
                    a.addTrait("has_tizhi"); // 标记已觉醒体质
                    
                    // 播放特效
                    a.spawnParticle(new Color(0.8f, 0.2f, 0.8f));
                    a.startShake(0.7f, 0.3f, true, false);
                    a.data.favorite = true;
                    
                    // 显示觉醒消息
                    string actorName = a.getName();
                    int year = (int)(World.world.getCurWorldTime() / 60) + 1;
                    string message = $"[玄门历{year}年] {actorName}于突破元婴时感悟大道本源，觉醒「{GetTizhiDisplayName(selectedTizhi)}」体质！";
                    ActionLibrary.showWhisperTip(message);
                    
                }
            }


            upTrait("特质", "Grade1", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "crippled", "skin_burns", "eyepatch", "Grade02" },
                new string[] { "freeze_proof", "fire_proof", "tough", randomTrait });
                UpdateXianSuffix(a, "Grade1");

            return true;
        }

        public static bool Grade2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 239.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-36);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17", "sorcery18" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("Grade1", "Grade2", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade1" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade2");

            return true;
        }

        public static bool Grade3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 479.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-72);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17", "sorcery18" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade3", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade2" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade3");
                

            return true;
        }

        public static bool Grade4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 799.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-120);
            double successRate = 0.5; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.8;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.7;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair6"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("flair7"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“正式”，如果包含则替换为“高级”

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28", "sorcery29" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade4", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade3" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade4");

            return true;
        }

        public static bool Grade5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 1199.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-180);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28", "sorcery29" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade5", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade4" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade5");
            return true;
        }

        public static bool Grade6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 1499.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-220);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28", "sorcery29" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade6", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade5" },
                new string[] { randomTrait });
                UpdateXianSuffix(a, "Grade6");
            ApplyXianTitle(a, "Grade6");

            return true;
        }

        public static bool Grade7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 1607.99)
            {
                return false;
            }
            
            a.ChangeYuanNeng(-240);
            double successRate = 0.2; //默认概率 
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.5;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("flair6"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("flair7"))
            {
                successRate = 0.38;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            string[] sorceryTraits = { "sorcery31", "sorcery32", "sorcery33", "sorcery34", "sorcery35" };
            string[] meditationTraits = { "meditation1", "meditation2", "meditation3" };
            string randomSorceryTrait = GetNewRandomTrait(sorceryTraits);
            bool hasMeditationTrait = meditationTraits.Any(trait => a.hasTrait(trait));
            string randomMeditationTrait = "";
            if (!hasMeditationTrait)
            {
                randomMeditationTrait = GetNewRandomTrait(meditationTraits); //获取新随机特质
            }
            a.data.favorite = true; // 散仙境界自动收藏

            upTrait("特质", "Grade7", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade6", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" },
                new string[] { "添加升级外的特质", randomSorceryTrait, randomMeditationTrait });
                UpdateXianSuffix(a, "Grade7");
                ApplyXianTitle(a, "Grade7"); // 散仙期尊号
            PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");

            // 获取角色名
            string newName = pTarget.a.getName();

            // 随机选择散仙诗歌
            System.Random random = new System.Random();
            int index = random.Next(grade7Tips.Count);
            string tip = grade7Tips[index];

            // 格式化诗歌内容（加入角色名）
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

             int year = (int)(World.world.getCurWorldTime() / 60) + 1; // 一年60天，年份+1
    tip = $"[玄门历{year}年] " + tip;
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        public static bool Grade8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 799.99)//突破需求
            {
                return false;
            }
            
            a.ChangeMeditation(-120);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.5;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }


            upTrait("特质", "Grade8", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade7", "flair81" },
                new string[] { "添加升级外的特质" });
                UpdateXianSuffix(a, "Grade8");
            PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");

            // 获取角色名
            string newName = pTarget.a.getName();

            // 随机选择真仙诗歌
            System.Random random = new System.Random();
            int index = random.Next(grade8Tips.Count);
            string tip = grade8Tips[index];

            // 格式化诗歌内容（加入角色名）
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

             int year = (int)(World.world.getCurWorldTime() / 60) + 1; // 一年60天，年份+1
    tip = $"[玄门历{year}年] " + tip;
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        public static bool Grade9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 1799.99)//突破需求
            {
                return false;
            }
            
            a.ChangeMeditation(-360);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.35;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.35;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.3;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.3;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“大巫师”，如果包含则替换为“不灭”
            if (!a.hasTrait("flair91") && !a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair8"))
                {
                    a.addTrait("flair8");
                    int randomResurrection = UnityEngine.Random.Range(10, 16);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade9Tips.Count);
            string tip = grade9Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

             int year = (int)(World.world.getCurWorldTime() / 60) + 1; // 一年60天，年份+1
    tip = $"[玄门历{year}年] " + tip;
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade9", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade8", "talent7", "flair81" },
                new string[] { "添加升级外的特质" });
                UpdateXianSuffix(a, "Grade9");
    ApplyXianTitle(a, "Grade9"); // 金仙境尊号

            return true;
        }
        private static readonly List<string> grade9Tips = new List<string>
        {
            "「九重天劫炼金身，「{0}」踏碎轮回门\n三灾焚尽凡胎骨，紫府玄丹证不泯\n待叩玉京混元境，再借造化塑真神！」",
            "「太虚雷火锻仙胎，「{0}」执印破劫来\n胸中五炁吞星斗，顶上三花映灵台\n纵使道消十二万，残魂犹可问元始！」",
            "「紫府玄光耀八荒，「{0}」历劫显锋芒\n血染星河九千转，魂渡归墟三万场\n今朝且驻大罗境，待化混元镇穹苍！」",
            "「混沌青莲绽灵台，「{0}」叩天显道才\n袖纳阴阳吞日月，掌托星斗炼劫灾\n此身虽未证元始，九死神魂自归来！」",
            "「玄黄血染登仙阶，「{0}」执剑问劫灭\n三千雷火锻道骨，八万魔障淬神魂\n纵使玉京门未启，不灭真灵可重燃！」",
            "「轮回镜碎现真灵，「{0}」涅槃塑仙形\n九转玄功吞日月，大罗道果镇幽冥\n此身已渡无量劫，只待混元叩天门！」",
            "「阴阳双鱼演玄机，「{0}」踏罡步星移\n九幽寒泉淬道剑，大日真火炼仙衣\n纵然身陨归墟海，一点真灵复归一！」",
            "「周天星斗汇灵台，「{0}」执符镇劫灾\n血染天河八万里，魂游太虚三千载\n今朝金仙道果成，他日混元自可待！」",
            "「玄冰劫火淬道心，「{0}」挥袖断光阴\n掌中须弥藏日月，眉间混沌演浮沉\n纵使轮回千百转，不灭真性证混元！」",
            "「洪荒龙脉铸仙基，「{0}」吐纳炼玄虚\n九转金丹吞日月，三清道炁化虹霓\n此身已越生死障，只待鸿蒙重开天！」",
            "「混沌钟鸣震九渊，「{0}」执戈破劫渊\n胸藏星河吞寰宇，指划阴阳定坤乾\n纵使道消魂散尽，真灵不朽自涅槃！」",
            "「太初紫气贯苍穹，「{0}」踏歌御长风\n剑斩因果三千丈，鼎炼阴阳十二重\n今朝金仙道果证，他日重开造化功！」",
            "「归墟潮涌证道时，「{0}」擎天立劫池\n九转玄功吞北斗，大罗剑意破南冥\n纵使形神俱消散，真灵永驻混元碑！」",
            "「周天星斗大阵开，「{0}」执印踏劫来\n血染青冥九千界，魂渡玄黄十二灾\n今朝金身永不灭，他日重定封神台！」",
            "「鸿蒙初判显真形，「{0}」吐纳炼玄精\n掌托日月吞星汉，脚踏阴阳定晦明\n纵使劫火焚万古，道心不昧自长存！」",
            "「混沌青莲再绽时，「{0}」破劫显英姿\n剑断因果了尘缘，鼎镇气运炼真知\n今朝金仙道果就，他日重写封神辞！」"
        };
        // 在 grade9Tips 列表之后添加以下代码
            private static readonly List<string> grade7Tips = new List<string>
            {
                "「{0}紫府元婴成，阴尽阳生脱死生\n三花初聚玄关顶，霞举蓬莱第一程」",

                "「{0}金丹碎玉宇，雷火锻得仙骨轻\n九劫洗尽凡尘垢，方见云外白玉京」",

                "「{0}元婴合道胎，未斩三尸名散仙\n乾坤炉中炼真性，待补功行叩天门」",

                "「{0}琴心三叠后，胎仙自向碧霄游\n阎浮名姓消册去，笑指星斗证散流」",

                "「{0}脱劫非为终，三尸未斩道未通\n且驾青鸾观尘世，再积功行三千重」"
            };

            private static readonly List<string> grade8Tips = new List<string>
            {
                
                "「{0}三花耀紫庭，五气氤氲绕玉京\n三尸斩尽道体固，始称大罗真仙名」",
                
                "「{0}千载炼真形，今日方斩善恶嗔\n顶现庆云三万里，真仙榜上刻道纹」",
                
                "「{0}九重罡风劫，炼得纯阳不朽身\n天音渺渺授仙箓，自此方为洞天尊」",
                
                "「{0}劫火焚散胎，一点真性耀灵台\n上清境中录仙籍，方知我命由我来」",
                
                "「{0}三花聚顶彻，五气朝元道始成\n呼吸皆合星斗转，方寸可纳四海倾」"
            };

        public static bool Grade91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 4999.99)
            {
                return false;
            }
            

            a.ChangeMeditation(-900);
            double successRate = 0.08; //突破默认概率
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 检查名称中是否包含“不灭”，如果包含则替换为“始祖”
            if (!a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair91"))
                {
                    a.addTrait("flair91");
                    int randomResurrection = UnityEngine.Random.Range(80, 101);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade91Tips.Count);
            string tip = grade91Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

             int year = (int)(World.world.getCurWorldTime() / 60) + 1; // 一年60天，年份+1
    tip = $"[玄门历{year}年] " + tip;
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade91", a,
                new string[]
                {
                    "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade9", "sorcery31",
                    "sorcery32", "sorcery33", "sorcery34", "sorcery35", "flair8", "flair81"

                },
                new string[] { "特质" });
                UpdateXianSuffix(a, "Grade91");
    ApplyXianTitle(a, "Grade91"); // 混元境尊号

            return true;
        }
        // 定义一组升级提示信息
        private static readonly List<string> grade91Tips = new List<string>
        {
            "混沌初开鸿蒙启，「{0}」登临玉京台\n三花聚顶凝道果，五炁朝元化仙胎\n掌纳天地归芥子，身演周天作法材\n今朝勘破元始境，方知大道为我开",
            "玉府丹元耀宇空，「{0}」铸道显神通\n骨化天柱撑四极，血涌星河贯九穹\n一念真空消万法，诸天星辰系指中\n此身已证混元体，永镇乾坤造化功",
            "太始玄晶凝窍穴，「{0}」证道显庄严\n鸿蒙劫火煅神骨，造化真金铸圣颜\n掌纳归墟湮日月，袖藏宇宙演诸天\n今立鸿蒙最高处，方知我本道中仙",
            "灵台方寸孕真我，「{0}」悟道显金身\n脐下混沌开天地，眉间星海映乾坤\n三千道藏化虹幕，八万魔尊俱俯臣\n此身即道道即我，万劫不磨永称尊",
            "太虚剑鸣二十四,「{0}」悟剑显神通\n诸天神魔皆俯首,三千大道共称臣\n举手截断光阴水,覆掌重开造化门\n今朝证得剑道极,方知我本道剑尊",
            "紫府青莲开十二,「{0}」证道显玄光\n玉京金阙自生香,血脉化作时光江\n身映诸天无穷界,一念重启万物纲\n此身已证道果极,永镇乾坤创世章",
            "鸿蒙造化演玄机，「{0}」炼道镇寰宇\n九转金丹吞星汉，五方真炁化虹霓\n掌托阴阳分清浊，足踏混沌定玄虚\n今朝证得混元果，万界轮回一念移",
            "太虚星海耀金身，「{0}」登临造化门\n三灾九难凝道骨，十方劫火铸仙魂\n袖卷星河吞日月，指划阴阳定乾坤\n此身已越元始境，重开鸿蒙立道尊",
            "万古长河凝道印，「{0}」踏劫显威神\n血染青冥八万里，魂渡玄黄十二轮\n胸藏混沌吞寰宇，指划阴阳定坤乾\n今立鸿蒙最高处，方知我即道本源",
            "归墟潮涌证混元，「{0}」擎天立道碑\n九幽寒泉淬仙骨，大日真火炼神髓\n掌纳诸天无穷界，身映星海亿万辉\n此身已越轮回外，永镇混沌开新规",
            "混沌青莲再绽时，「{0}」执印定玄机\n剑断因果了尘障，鼎镇气运炼真知\n一念真空生万物，双眸星海映诸夷\n今朝混元道果证，重写鸿蒙创世辞",
            "玄黄母气铸道胎，「{0}」登临显圣台\n九转玄功吞北斗，混元剑意破南垓\n血染星河八万转，魂渡归墟十万灾\n此身已证不灭体，永镇诸天掌劫来",
            "太始真火煅仙形，「{0}」踏劫显威灵\n骨化天柱撑四极，血涌长河贯八溟\n掌托日月吞星斗，足踏阴阳定晦暝\n今立鸿蒙最高境，方知大道即吾名",
            "周天星斗大阵开，「{0}」执符御劫来\n胸藏混沌演浮世，指化阴阳定轮回\n九转金丹吞浩宇，混元道果镇劫灰\n此身已越元始外，重定乾坤造化规",
            "鸿蒙初判显真性，「{0}」吐纳炼玄精\n掌托须弥藏芥子，身映诸天化繁星\n剑断因果三千丈，鼎镇阴阳十二庭\n今朝混元道果证，永驻太虚掌劫经",
            "混沌钟鸣震九幽，「{0}」踏歌御劫游\n血染青冥十万里，魂渡玄黄百万秋\n胸藏星海吞浩宇，指化阴阳定浮沤\n此身已证混元体，重写鸿蒙造化筹",
            "太虚紫气贯长空，「{0}」证道显神通\n九转玄功吞日月，混元剑意破鸿蒙\n掌纳诸天无穷界，身映星海亿万重\n今立道极最高处，方知我即造化宗",
            "玄冰劫火淬道心，「{0}」挥袖断光阴\n脐下混沌开天地，眉间星海映浮沉\n三千道藏化虹幕，八万魔尊俱俯音\n此身即道道即我，万劫不磨永称今",
            "洪荒龙脉铸仙基，「{0}」吐纳炼玄微\n九转金丹吞浩宇，混元道炁化虹飞\n掌托阴阳分清浊，足踏混沌定玄机\n今朝已越轮回外，永镇乾坤造化碑",
            "归墟潮涌证道时，「{0}」擎天立劫池\n剑斩因果三千界，鼎镇阴阳十二支\n血染星河九万转，魂渡玄黄十万罹\n此身已证混元体，永驻太虚掌劫辞",
            "混沌青莲绽灵台，「{0}」叩关显道才\n骨化天柱撑四维，血涌长河贯九垓\n一念真空生万物，双眸星海映诸埃\n今立鸿蒙最高境，方知我即道本来"
        };
        public static bool flair8_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」真灵已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair8");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 添加随机 flair 特质
            string[] flairTraits = { "flair3", "flair4", "flair5" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            a.addTrait(selectedFlair);

            // 创建新单位并设置属性
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 触发特效
            new PowerLibrary().divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」真灵已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));
                
            a.addTrait("flair91");
            a.addTrait("flair5");
            activeMeditations.ForEach(t => a.addTrait(t));

            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 特效触发
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair92_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair92");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 随机选择新特质并添加（同时保留到新单位）
            string[] flairTraits = { "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "blessed", "flower_prints" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            a.addTrait(selectedFlair);
            // 创建新单位
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            // 名称清洗：移除"圣体"和"道胎"后缀
            act.setName(new[] { "圣体", "道胎" }
                    .Aggregate(a.getName(), (name, keyword) => name.Replace(keyword, "")));
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            act.ChangeRresurrection(a.GetRresurrection() + 1);
            // 特效触发
            new PowerLibrary().divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool Grade91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            Grade91_Action(a);
            return true;
        }
        private static bool Grade91_Action(Actor a)
        {
            // 首先计算所有存活的小人总数
            int totalAliveCount = 0;
            List<Actor> simpleList = World.world.units.getSimpleList();
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive())
                {
                    totalAliveCount++;
                    // 所有存活且有相应特质的增加源能和无根之源
                    if (actor.hasTrait("flair1") || actor.hasTrait("flair2") || actor.hasTrait("flair3") ||
                        actor.hasTrait("flair4") || actor.hasTrait("flair5") || actor.hasTrait("flair6") || actor.hasTrait("flair7"))
                    {
                        // 随机增加50~100源能
                        int yuanNengIncrease = UnityEngine.Random.Range(50, 101);
                        actor.ChangeYuanNeng(yuanNengIncrease);
                    }
                    if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
                    {
                        // 随机增加500~1000无根之源
                        int meditationIncrease = UnityEngine.Random.Range(500, 1001);
                        actor.ChangeMeditation(meditationIncrease);
                    }
                }
            }
            
            int num = 0;
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive() && !actor.data.favorite && !actor.asset.ignored_by_infinity_coin)
                {
                    num++;
                }
            }

            int num2 = (int)Math.Ceiling(num * 0.30); // 计算30%的小人数量
            int num3 = 0;

            EffectInfinityCoin._temp_list.Clear();
            EffectInfinityCoin._temp_list.AddRange(World.world.units);
            EffectInfinityCoin._temp_list.Shuffle<Actor>();
            foreach (Actor actor2 in EffectInfinityCoin._temp_list)
            {
                if (num2 == 0)
                {
                    break;
                }
                if (actor2.isAlive() && !actor2.data.favorite && !actor2.asset.ignored_by_infinity_coin)
                {
                    num3++;
                    num2--;
                    actor2.getHit((float)(actor2.data.health * 1000 + 1), true, AttackType.Other, null, false, false);
                }
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(Grade91deathTips.Count);
            string tip = Grade91deathTips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }
            
                     int year = (int)(World.world.getCurWorldTime() / 60) + 1; // 一年60天，年份+1
    tip = $"[玄门历{year}年] " + tip;
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        private static readonly List<string> Grade91deathTips = new List<string>
        {
            "「{0}」道体化飞烟，混元道果散诸天。虽遭劫难身暂殒，真灵不灭待重燃。\n三清圣境留残影，混沌深处蕴生机。待到天地重开日，再掌乾坤立新篇。",
            "「{0}」道躯显真灵，虽散乾坤意未停。元神化作三千念，各寻机缘待成形。\n九幽深处藏玄机，三十三天留道印。重聚神魂归本位，再演混元破天经。",
            "「{0}」身遭劫火焚，道果化作漫天星。九天之上留光影，九泉之下存道根。\n虽暂离世去，道意永存宇宙心。待到涅槃劫火熄，重生再造混元身。",
            "「{0}」道体显化终，混元道种散苍穹。虽暂入轮回道，真我本意未曾空。\n三界六道留踪迹，九幽十方藏玄功。待得时机成熟日，重证混元掌天宗。",
            "「{0}」身化万千星，道体归寂显玄冥。虽暂离三界外，混元本性未曾泯。\n周天星斗留道印，混沌虚空蕴真灵。待时重聚道体日，再演混元破劫经。",
            "「{0}」道躯遭道劫，混元道果显真形。虽暂离世间去，天地永记混元名。\n三界六道留道韵，三十三天蕴道音。待到劫数轮回转，重铸道体掌天心。",
            "「{0}」道消星海间，混元灵光化三千。九幽黄泉藏道种，三十三天孕真玄。\n轮回百转道心在，劫火千焚本性全。待得紫气东来日，重开混沌掌乾元",
            "「{0}」身陨道未终，真灵分化入鸿蒙。太虚深处藏道印，归墟海眼蕴神通。\n九转轮回磨道性，三灾涅槃炼真容。他日灵光重聚时，再镇诸天万界中",
            "「{0}」道体归太虚，混元灵识化星雨。混沌海眼藏真性，造化玉碟记玄机。\n虽经无量量劫灭，犹存先天一点曦。待得乾坤重启日，重演大道立新规",
            "「{0}」劫灭道身消，真灵化虹贯九霄。周天星斗铭道韵，天地灵脉孕神苗。\n三清圣境留残影，万佛净土藏道标。涅槃劫尽归来日，重定阴阳掌六道",
            "「{0}」道陨天地恸，混元灵光散苍穹。血染星河成道种，魂渡归墟化鸿蒙。\n九幽十殿留名讳，三十三天刻真容。待得轮回重启日，再开混沌演神通",
            "「{0}」身化太初炁，混元道果散寰宇。先天紫气藏真性，造化玉碟录玄机。\n九转涅槃劫火炼，三生化道因果迷。待到星海重聚日，再掌乾坤定玄虚",
            "「{0}」道消混沌海，真灵分化三千外。九重天阙留道印，十八地狱刻真骸。\n轮回百世磨道性，劫火万载炼灵胎。待到星移斗转日，重开天地掌劫来",
            "「{0}」陨落显道真，混元灵光化星辰。黄泉路上种道莲，三生石前刻真文。\n九转轮回存道印，万劫加身炼道魂。待得天地重开际，再临诸天镇乾坤",
            "「{0}」道体归寂灭，混元灵识化风雪。太虚秘境藏道种，混沌海眼孕真诀。\n九幽深处留残影，紫府天宫刻真页。待得涅槃劫尽时，重掌阴阳破天阙",
            "「{0}」身陨道不消，真灵分化入六道。周天星斗铭道韵，九幽黄泉刻真标。\n轮回百转存道性，劫火千焚炼灵苗。待到紫气东来日，重开混沌演玄妙",
            "「{0}」劫灭显道真，混元灵光散乾坤。先天八卦藏道种，后天五行孕灵根。\n九转轮回存道印，三生化劫炼真魂。待得星海重聚日，再临诸天掌道门",
            "「{0}」道体化飞灰，混元灵识入轮回。三生石上刻真印，六道轮中藏玄机。\n九幽深处孕道种，三十三天养灵胚。待得涅槃劫尽日，重开天地立道威",
            "「{0}」陨落道犹存，真灵分化万千痕。周天星斗蕴道韵，天地灵脉养神魂。\n九转劫火炼真性，三生化道悟玄门。待得紫气重聚日，再掌混沌定乾坤",
            "「{0}」道消混沌中，混元灵光贯长空。九重天外留道印，十八狱底刻真容。\n轮回百世存本性，劫火万载炼神通。待得星移斗转日，重开天地掌鸿蒙",
            "「{0}」身陨道不终，真灵分化入鸿蒙。太虚深处藏道种，时空长河孕灵通。\n九转轮回磨道印，三生化劫炼真功。待得涅槃劫尽日，重临诸天镇苍穹"
        };
        public static bool teleportRandom(Actor a)
        {
            MapBox mapBox = World.world as MapBox;
            if (mapBox == null)
            {
                return false;
            }

            List<City> cities = World.world.cities.list;
            if (cities == null || cities.Count == 0)
            {
                return false;
            }

            int randomIndex = UnityEngine.Random.Range(0, cities.Count);
            City randomCity = cities[randomIndex];

            WorldTile cityCenterTile = randomCity.getTile();
            if (cityCenterTile == null || cityCenterTile.Type.block || !cityCenterTile.Type.ground)
            {
                return false;
            }

            a.cancelAllBeh();
            a.spawnOn(cityCenterTile, 0f);
            return true;
        }
        public static bool flair6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("圣体"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("NewSS");
                        pTarget.a.setName(pTarget.a.getName() + " 圣体");
                        actorTipsShown[pTarget.a] = (true, tipsShown.hasShownSSSTip); // 更新状态
                    }
                    return false;
                }
            }
            return true;
        }
        public static bool flair7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(60);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SSS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("道胎"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("NewSSS");
                        pTarget.a.setName(pTarget.a.getName() + " 道胎");
                        actorTipsShown[pTarget.a] = (tipsShown.hasShownSSTip, true); // 更新状态
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }

        private static Dictionary<Actor, (bool hasShownSSTip, bool hasShownSSSTip)> actorTipsShown = new Dictionary<Actor, (bool, bool)>();
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(string   old_trait, string new_trait, Actor actor, string[] other_Oldtraits = null,
                                   string[] other_newTrait = null)
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
