﻿namespace Cultivatingimmortals.code
{
    internal class stats
    {
        public static void Init()
        {
            // 检查是否已存在，避免重复添加
            if (!AssetManager.base_stats_library.dict.ContainsKey("yuanneng"))
            {
                BaseStatAsset yuanneng = new BaseStatAsset();
                yuanneng.id = "yuanneng";
                yuanneng.normalize = true;
                yuanneng.normalize_min = -99999;
                yuanneng.normalize_max = 1000;
                // yuanneng.multiplier = true;
                yuanneng.used_only_for_civs = false;
                AssetManager.base_stats_library.add(yuanneng);
            }

            if (!AssetManager.base_stats_library.dict.ContainsKey("xiaohao"))
            {
                BaseStatAsset xiaohao = new BaseStatAsset();
                xiaohao.id = "xiaohao";
                xiaohao.normalize = true;
                xiaohao.normalize_min = -99999;
                xiaohao.normalize_max = 99999;
                // xiaohao.multiplier = true;
                xiaohao.used_only_for_civs = false;
                AssetManager.base_stats_library.add(xiaohao);
            }

            if (!AssetManager.base_stats_library.dict.ContainsKey("meditation"))
            {
                BaseStatAsset meditation = new BaseStatAsset();
                meditation.id = "meditation";
                meditation.normalize = true;
                meditation.normalize_min = -99999;
                meditation.normalize_max = 99999;
                // meditation.multiplier = true;
                meditation.used_only_for_civs = false;
                AssetManager.base_stats_library.add(meditation);
            }
            
            // 不再添加resurrection和Rresurrection，因为它们已由其他mod定义
            // 避免重复添加导致的错误
        }
    }
}
