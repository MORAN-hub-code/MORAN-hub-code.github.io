
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace VideoCopilot.code.window;

public class WindowCreatureInfoPatchHelper
{

    public static readonly StatsIconData[] StatsIconDatas = {
        new ("YuanNeng", "ui/YuanNeng.png",true),
        new ("Meditation", "ui/Meditation.png",true),
        new ("Resurrection", "ui/Resurrection.png",true),
        new ("Rresurrection", "ui/Rresurrection.png",true),
        new ("Dodge", "ui/Dodge.png",true),
        new ("Accuracy", "ui/Accuracy.png",true),
        new ("smjj", "ui/smjj.png",true)
    };


    public static void OnEnable(UnitWindow window, Actor actor)
    {
        window.setIconValue("YuanNeng", actor.GetYuanNeng());
        window.setIconValue("Meditation", actor.GetMeditation());
        window.setIconValue("Resurrection", actor.GetResurrection());
        window.setIconValue("Rresurrection", actor.GetRresurrection());
        window.setIconValue("Dodge", actor.stats["Dodge"]);
        window.setIconValue("Accuracy", actor.stats["Accuracy"]);
        window.setIconValue("smjj", actor.stats["smjj"]);
        window.showInfo();
    }







    public static StatsIcon icon;
    public static Transform content_transform;
    public static void Initialize(UnitWindow window)
        {
            window
                .gameObject.transform.Find("Background/Scroll View")
                .GetComponent<ScrollRect>()
                .enabled = true;
            window
                .gameObject.transform.Find("Background/Scroll View/Viewport")
                .GetComponent<Mask>()
                .enabled = true;
            window
                .gameObject.transform.Find("Background/Scroll View/Viewport")
                .GetComponent<Image>()
                .enabled = true;

            content_transform = window.gameObject.transform.Find(
                "Background/Scroll View/Viewport/Content/content_more_icons"
            );

            content_transform.gameObject.AddOrGetComponent<StatsIconContainer>();


            var originalParent = content_transform.GetChild(4);

            var newStatsIconGroup = GameObject.Instantiate(originalParent);
            for (int i = newStatsIconGroup.transform.childCount - 1; i >= 0; i--)
            {
                Transform child = newStatsIconGroup.transform.GetChild(i);
                if (child.name != "i_kills")
                {
                    GameObject.Destroy(child.gameObject); // 销毁子对象
                }
            }

            var i_kills = newStatsIconGroup.Find("i_kills");


            int index = 0;
            foreach (var iconData in StatsIconDatas)
            {
                if (!iconData.is_show)
                {
                    continue;
                }
                if (index ==8)
                {
                    break;
                }
                var base_icon =  GameObject.Instantiate(i_kills, newStatsIconGroup);
                icon = base_icon.GetComponent<StatsIcon>();
                var icon_text =base_icon.GetComponent<TipButton>();
                icon_text.textOnClick = LM.Get("statsIcon_"+iconData.name);
                icon.name = iconData.name;
                icon.getIcon().sprite = Resources.Load<Sprite>(iconData.iconPath);
                index++;
            }


            GameObject.DestroyImmediate(i_kills.gameObject);
            newStatsIconGroup.name = "wushi_worldbox";
            newStatsIconGroup.SetParent(content_transform);
            newStatsIconGroup.transform.localScale = new Vector3(1, 1, 1);
        }



    public class StatsIconData
    {
        public string name;
        public string iconPath;
        public bool is_show = false;

        public StatsIconData(string name,string iconPath,bool is_show = false)
        {
            this.name = name;
            this.iconPath = iconPath;
            this.is_show = is_show;
        }
    }
}
