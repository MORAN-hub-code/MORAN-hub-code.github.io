﻿using System.Collections.Generic;
using System.Linq;
using System;
using ai;
using ReflectionUtility;
using UnityEngine;
using VideoCopilot.code.utils;
using System.IO;

namespace VideoCopilot.code
{
    internal class traitAction
    {
        private static readonly string[] yuanyingTitles =
        {
            // 渡劫期正道称号
            "清玄道人",   "玉虚真人",   "玄光真人",   "烈风散人",   "白羽道人",
            "云岚真人",   "空灵道人",   "万象散人",   "赤焰灵君",   "云溪子",
            "青松道人",   "问心上人",   "采薇真人",   "听风子",    "栖霞道人",
            "竹隐子",     "漱石上人",   "怀真真人",   "守拙道人",   "折梅子",
            "听松上人",   "闲云真人",   "清溪道人",   "栖真子",    "抚琴上人",
            "玉尘真人",   "观云道人",   "静虚子",     "月华真人",   "松风道人",
            "寒梅子",     "听雨上人",   "清虚真人",   "丹霞道人",   "玄素子",
            "问道上人",   "玉泉真人",   "云鹤道人",   "静松子",    "听风上人",
            "玄真真人",   "竹溪道人",   "素月子",     "玄清真人",   "云游道人",
            "雪松子",     "听山上人",   "清泉真人",   "闲鹤道人",   "玉松子",
            "观山上人",   "松月道人",   "玄松子",     "听虚上人",   "云泉真人",
            "竹鹤道人",   "明墟真人",   "清微上人",   "玉宸道人",   "太虚子",
            "归藏真人",   "玄霄上人",   "紫阳道人",   "青冥子",    "天枢真人",
            "云华上人",   "玄真道人",   "玉虚子",     "太素真人",   "清玄上人",
            "玉衡道人",   "玄月子",     "太乙真人",   "云虚上人",   "青阳道人",
            "玄光子",     "太清真人",   "玉清上人",   "玄河道人",   "云月子",
            "太玄真人",   "玉阳上人",   "玄风道人",   "云虚子",    "太和真人",
    
            // 渡劫期魔道/旁门称号
            "玉宸上人",   "赤渊上人",   "血饮道人",   "冥骨真人",   "煞魂子",
            "焚心上人",   "血河道人",   "阴煞真人",   "血魄子",    "冥火上人",
            "血煞道人",   "黄泉真人",   "幽魄上人",   "冥河道人",   "煞月子",
            "葬魂真人",   "阴冥上人",   "鬼河道人",   "幽月子",    "冥魂真人",
            "阴魄上人",   "禅心真人",   "空相上人",   "莲生道人",   "伽蓝子",
            "妙法真人",   "慧觉上人",   "净尘道人",   "慈航真人",   "慧海上人",
            "星谶上人",   "遁甲道人",   "棋枰子",    "符海真人",   "阵枢上人",
            "天衍道人",   "玄算子",     "灵枢真人",   "天机上人",   "符箓道人",
            "丹鼎真人",   "器宗上人",   "药尘子",    "灵傀道人",   "云舟真人",
            "宝鉴上人",   "丹霞道人",   "器灵子",    "药鼎真人",   "云商上人",
            "玄戈上人",   "栖霞道人",   "苍梧子",    "北冥真人",   "南离上人"
        };
        private static readonly string[] sanxianTitles =
        {
            "璇玑星君",   "瑶光圣主",   "天罗仙尊",   "紫极圣君",   "洞玄仙尊",
            "玉衡真仙",   "太微圣尊",   "天权仙主",   "开阳圣君",   "摇光仙尊",
            "云笈玉圣",   "天河仙君",   "碧落圣主",   "玄穹仙尊",   "丹霄圣君",
            "青阙仙使",   "玉京真仙",   "太渊圣尊",   "天枢仙主",   "紫垣圣君",
            // 散仙正道
            "太虚仙君", "玉宸圣主", "九霄仙尊", "玄穹圣君", "紫微仙使",
            "洞冥真仙", "青冥圣尊", "天衍仙主", "琅琊圣君", "归墟仙尊",
            "北斗玉仙", "太皓圣主", "云华仙尊", "乾坤圣君", "玄天仙使",
            "青阳玉尊", "太素仙君", "玉清圣主", "天枢仙尊", "沧溟圣君",
            "紫府真仙", "九光圣尊", "玄黄仙主", "洞玄圣君", "凌霄仙尊",
            "太乙玉圣", "天罡仙君", "青霄圣主", "玄冥仙尊", "玉虚圣君",

            // 散仙魔道
            "九幽魔尊", "血狱圣主", "冥煞仙君", "噬魂魔尊", "玄阴圣主",
            "万劫魔君", "赤炼仙尊", "黑天魔圣", "无生魔尊", "骨煞圣君",

            // 散仙旁门
            "百尸仙君", "千蛊圣主", "影劫仙尊", "阴符魔圣", "毒煞仙君",
            "魂寂圣主", "血炼仙尊", "九阴真圣", "尸解仙君", "无常圣尊"
        };
        private static readonly string[] jinyuanTitles =
        {
            // 正道（30个）- 星律天章
            "太虚量劫真王", "紫宸星律圣帝", "终始轮转仙皇", "九重天阙灵尊",
            "洞玄真冥法圣", "玄黄开辟真宰", "混虚通明圣君", "太乙量劫法王",
            "赤混元墟灵帝", "玉宸启元圣皇", "清浊分形真君", "禹余太虚法尊",
            "元载空洞圣宰", "虚皇劫运真帝", "赤明量劫法皇", "冥通玄寂灵君",
            "梵炁周流圣主", "碧落归墟真皇", "丹华紫宸法帝", "青玄劫灭圣尊",
            "白墟量劫真宰", "玄都妙相法王", "神霄玉宸灵皇", "紫微垣律圣帝",
            "勾陈劫运真君", "后劫皇极法尊", "南华长生圣皇", "东极青华真帝",
            "西极皓灵法君", "北宸量劫圣主",
            // 魔道（10个）- 永夜终章
            "永劫归墟魔皇", "冥墟焚宇邪帝","万相寂灭冥君", "无间永夜魔帝", "黑渊蚀日邪皇", "赤炼焚宙冥帝"
        };
        private static readonly string[] hunyuanTitles =
        {
            // 混元正道
            "玉虚紫极道祖", "上清玄穹天尊", "太初混元仙帝", "九宸青冥道主",
            "洞真玉华天尊", "玄黄造化道祖", "紫府通明仙帝", "太乙救苦天尊",
            "赤明开天道主", "玉宸启圣道祖", "清微玄化天尊", "禹余大罗仙帝",
            "郁单无量道主", "虚皇太素天尊", "赤混太无道祖", "冥寂玄通仙帝",
            "太虚玄穹道祖", "紫宸星律天尊", "终始轮转仙帝", "九重天阙道主",
            "洞玄真冥天尊", "玄黄开辟道祖", "混虚通明仙帝", "太乙度厄天尊",
            "赤混元墟道主", "玉宸启元道祖", "清浊分形天尊", "禹余太虚仙帝",
            "元载空洞道主", "虚皇劫运天尊", "赤明量劫道祖", "冥通玄寂仙帝",
            "梵炁周流天尊", "碧落归墟道主", "丹华紫宸道祖", "青玄劫灭天尊",
            "白墟量劫仙帝", "玄都妙相道主", "神霄玉宸真祖", "紫微垣律天尊",
            "勾陈劫运仙帝", "后劫皇极道祖", "南华长生天尊", "东极青华道主",
            "西极皓灵仙祖", "北宸量劫天尊", "南垣司命道祖", "五劫轮转仙帝",
            "三垣律令天尊", "雷劫普化道主", "文枢启明仙祖", "真劫荡魔天尊",
            "幽都玄冥道祖", "岱宗量劫仙帝",
            // 混元魔道（虚构概念）
            "永劫归墟魔祖", "冥墟焚宇妖帝", "玄煞量劫道主", "终末劫运天尊",
            "万相寂灭鬼祖", "无间永夜魔帝", "黑渊蚀日道祖", "赤炼焚宙魔尊",
            "阴墟统御天尊", "玄牝噬道寂主", "罗酆永劫鬼帝", "阿鼻量劫魔祖",
            "黄泉渡灭天尊", "幽劫夺道魔帝", "七终劫运道祖", "贪劫噬宇魔尊",
            "破量真空天尊", "灭世劫磨道主", "永寂轮转魔祖", "业劫红莲魔帝"
        };
        //以下为拥有这个巫术状态的效果
        public static bool attack_Ring05(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 10f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示火的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_fire);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        public static bool attack_Ring25(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 90f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示感染的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_infected);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        //以下为巫术
        public static bool attack_sorcery01(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring01"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pSelf.a.addStatusEffect("Ring01", 3f); //零环•轻身术
            }

            return true;
        }

        public static bool attack_sorcery02(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring05"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pTarget.a.addStatusEffect("Ring05", 3f); //零环•烈焰之握
            }

            return true;
        }

        public static bool attack_sorcery03(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring02"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pTarget.a.addStatusEffect("Ring02", 3f); //零环•水幻迷障
            }

            return true;
        }

        public static bool sorcery04_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.mana < pTarget.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(1); //零环•生命祈愈
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery05(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring03"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pSelf.a.addStatusEffect("Ring03", 3f); //零环•大地壁垒
            }

            return true;
        }

        public static bool attack_sorcery06(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring04"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pTarget.a.addStatusEffect("Ring04", 3f); //零环•蔓藤囚牢
            }

            return true;
        }

        public static bool attack_sorcery07(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring06"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 10;//灵力消耗
                pSelf.a.addStatusEffect("Ring06", 3f); //零环•鹰隼凝视
            }

            return true;
        }

        public static bool attack_sorcery08(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade999" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring07") || pSelf.hasStatus("Ring17") || pSelf.hasStatus("Ring28") || pSelf.hasStatus("Ring36") || pSelf.hasStatus("Ring94"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                if (pSelf.a.hasTrait("Grade0") || pSelf.a.hasTrait("Grade01") || pSelf.a.hasTrait("Grade02"))
                {
                    pSelf.a.data.mana -= 10;//灵力消耗
                    pSelf.a.addStatusEffect("Ring07", 3f); //零环•灵盾术
                }
                if (pSelf.a.hasTrait("Grade1") || pSelf.a.hasTrait("Grade2") || pSelf.a.hasTrait("Grade3"))
                {
                    pSelf.a.data.mana -= 20;//灵力消耗
                    pSelf.a.addStatusEffect("Ring17", 4f); //零环•灵盾术
                }
                if (pSelf.a.hasTrait("Grade4") || pSelf.a.hasTrait("Grade5") || pSelf.a.hasTrait("Grade6"))
                {
                    pSelf.a.data.mana -= 40;//灵力消耗
                    pSelf.a.addStatusEffect("Ring28", 5f); //零环•灵盾术
                }
                if (pSelf.a.hasTrait("Grade7") || pSelf.a.hasTrait("Grade8") || pSelf.a.hasTrait("Grade9"))
                {
                    pSelf.a.data.mana -= 80;//灵力消耗
                    pSelf.a.addStatusEffect("Ring36", 6f); //零环•灵盾术
                }
                if (pSelf.a.hasTrait("Grade91"))
                {
                    pSelf.a.data.mana -= 160;//灵力消耗
                    pSelf.a.addStatusEffect("Ring94", 10f); //零环•灵盾术
                }
            }

            return true;
        }

        public static bool attack_sorcery11(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring11"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.7f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pTarget.a.addStatusEffect("Ring11", 6f); //一环•疲惫之手
            }

            return true;
        }

        public static bool attack_sorcery12(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring12"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pTarget.a.addStatusEffect("Ring12", 6f); //一环•缠绕之网
            }

            return true;
        }

        public static bool attack_sorcery13(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring13"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pSelf.a.addStatusEffect("Ring13", 6f); //一环•土之坚甲
            }

            return true;
        }

        public static bool sorcery14_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.mana < pTarget.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(4); //一环•复苏之流
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery15(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring14"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pSelf.a.addStatusEffect("Ring14", 6f); //一环•风行术
            }

            return true;
        }

        public static bool attack_sorcery16(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring15"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pTarget.a.addStatusEffect("Ring15", 6f); //一环•水雾术
            }

            return true;
        }

        public static bool attack_sorcery17(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring16"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 20;//灵力消耗
                pSelf.a.addStatusEffect("Ring16", 6f); //一环•气机牵引
            }

            return true;
        }

        public static bool attack_sorcery22(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring22"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 40;//灵力消耗
                pTarget.a.addStatusEffect("Ring22", 8f); //二环•星之致幻
            }

            return true;
        }

        public static bool attack_sorcery23(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            pSelf.a.data.mana -= 40;//灵力消耗
            const int drainAmount = 15; // 定义要汲取的血量
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false; // 如果施法者无效，则返回false
            }
            pTarget.a.spawnParticle(Toolbox.makeColor("#FF0000"));
            if (pTarget.isBuilding())
            {
                return false;
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health > 0)
            {
                int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health); // 实际汲取的血量，不超过目标的当前血量
                pTarget.a.data.health -= actualDrain;                            // 减少目标的血量
                pSelf.a.data.health =
                    Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量
            }

            return true;
        }

        public static bool attack_sorcery24(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring24"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 40;//灵力消耗
                pSelf.a.addStatusEffect("Ring24", 8f); //二环•岩石护壁
            }

            return true;
        }

        public static bool sorcery25_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.mana < pTarget.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(23); //二环•生命涌泉
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery26(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget.hasStatus("Ring25"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.data.mana -= 40;//灵力消耗
                pTarget.a.addStatusEffect("Ring25", 5f); //5秒状态:二环•生命流逝
            }

            return true;
        }

        public static bool attack_sorcery27(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring26"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 40;//灵力消耗
                pSelf.a.addStatusEffect("Ring26", 8f); //二环•因果印记
            }

            return true;
        }

        public static bool attack_sorcery28(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring27"))
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.data.mana -= 40;//灵力消耗
                pSelf.a.addStatusEffect("Ring27", 8f); //二环•相位星痕步
            }

            return true;
        }

        public static bool attack_sorcery31(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (UnityEngine.Random.value < 1f)//三环•斥力场
            {
                pSelf.a.data.mana -= 80;//灵力消耗
                Actor a = pTarget.a;
                Actor s = pSelf.a;

                EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                return false;
            }

            return false;
        }

        public static bool attack_sorcery32(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 特效的随机大小
            float explosionScaleMin = 0.1f;
            float explosionScaleMax = 0.3f;
            float explosionScale = UnityEngine.Random.Range(explosionScaleMin, explosionScaleMax);

            if (UnityEngine.Random.value < 1f) //三环•裂界爆炎
            {
                // 使用随机大小生成爆炸特效
                EffectsLibrary.spawnAtTileRandomScale("fx_explosion_tiny", pTile, explosionScale, explosionScale);
            }

            return true;
        }

        public static bool attack_sorcery33(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pTarget != null) //三环•雷霆术
            {
                pSelf.a.data.mana -= 80;//灵力消耗
                MapBox.spawnLightningMedium(pTile, 0.25f);
            }

            return false;
        }

        public static bool sorcery34_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }
            if (pSelf.a.data.mana < pSelf.a.getMaxMana() / 10)//灵力不够
            {
                return false;
            }
            if (pSelf.hasStatus("Ring34"))
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }

            // 获取血量
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();

            // 检查血量是否低于60%
            if (currentHealth < maxHealth * 0.6f)
            {
                pSelf.a.data.mana -= 80;//灵力消耗
                // 如果血量低于50%，则为目标添加血眸状态
                pSelf.a.addStatusEffect("Ring34", 10f);
            }

            return true;
        }

        public static bool Grade91_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();
            if (currentHealth < maxHealth * 0.8f)
            {
                pSelf.a.addStatusEffect("Ring92", 30f);// 检查血量是否低于80%
            }
            if (currentHealth < maxHealth * 0.5f)
            {
                pSelf.a.addStatusEffect("Ring93", 30f);// 检查血量是否低于50%
            }

            return true;
        }

        /*public static bool attack_Grade6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pTarget == null)
            {
                return false;
            }
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }
            if (pTile == null)
            {
                return false;
            }
            if (UnityEngine.Random.value < 0.2f)
            {
                EffectsLibrary.spawnAtTileRandomScale("fx_lightning_big", pTile, 0.15f, 0.3f);
                MapAction.damageWorld(pTile, 30, TerraformLibrary.atomic_bomb, null);
            }
            if (UnityEngine.Random.value < 0.01f)
            {
                EffectsLibrary.spawnAtTileRandomScale("fx_lightning_big", pTile, 0.15f, 0.3f);
                MapAction.damageWorld(pTile, 30, TerraformLibrary.czar_bomba, null);
            }
            if (UnityEngine.Random.value < 0.3f)
            {
                ActionLibrary.acidBloodEffect(pTarget, pTile);//酸雨
            }
            return true;
        }*/

        public static bool attack_Grade91(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pTarget == null)
            {
                return false;
            }
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }
            if (pTile == null)
            {
                return false;
            }
            if (UnityEngine.Random.value < 0.2f)
            {
                EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
            }
            return true;
        }
        //天赋灵气获取
        public static bool Flair_absorb(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.hasTrait("flair81") || pTarget.a.hasTrait("flair9"))
            {
                return false;
            }
            // 境界源能上限
            var grades = new Dictionary<string, float>
            {
                { "Grade02", 18.0f },
                { "Grade3", 77.0f },
                { "Grade6", 288.0f },
                { "Grade7", 300.0f },
                { "Grade8", 600.0f },
                { "Grade9", 1200.0f },
                { "Grade91", 3000.0f }
            };
            foreach (var grade in grades)
            {
                UpdateYuannengBasedOnGrade(pTarget.a, grade.Key, grade.Value);
            }
            //资质天赋修炼（消耗）速度
            var flairXiaohaoRanges = new Dictionary<string, (float min, float max)>
            {
                { "flair1", (1f, 2f) },
                { "flair2", (1f, 3f) },
                { "flair3", (2f, 5f) },
                { "flair4", (3f, 7f) },
                { "flair5", (4f, 9f) },
                { "flair6", (6f, 19f) },
                { "flair7", (9f, 29f) }
            };
            //悟性天赋真元利用率
            var wuxingXiaohaoRanges = new Dictionary<string, (float min, float max)>
            {
                { "wuxing1", (0.01f, 0.02f) },
                { "wuxing2", (0.02f, 0.04f) },
                { "wuxing3", (0.03f, 0.06f) },
                { "wuxing4", (0.04f, 0.08f) },
                { "wuxing5", (0.05f, 0.10f) }
            };
            //mana为满时消耗一半炼化真元
            if (pTarget.a.data.mana >= pTarget.a.getMaxMana())
            {
                float halfwaymana = pTarget.a.data.mana / 2;
                foreach (var kvp in wuxingXiaohaoRanges)
                {
                    string wuxing = kvp.Key;
                    float min = kvp.Value.min;
                    float max = kvp.Value.max;
                    if (pTarget.a.hasTrait(wuxing))
                    {
                        float xiulian = UnityEngine.Random.Range(min, max);
                        float Maxage = pTarget.stats["lifespan"];
                        float Efficiency = 1f;
                        if (pTarget.a.hasTrait("Grade0") && Maxage > 80f)
                        {
                            Efficiency = 80f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade01") && Maxage > 90f)
                        {
                            Efficiency = 90f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade02") && Maxage > 100f)
                        {
                            Efficiency = 100f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade1") && Maxage > 140f)
                        {
                            Efficiency = 140f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade2") && Maxage > 150f)
                        {
                            Efficiency = 150f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade3") && Maxage > 160f)
                        {
                            Efficiency = 160f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade4") && Maxage > 210f)
                        {
                            Efficiency = 210f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade5") && Maxage > 225f)
                        {
                            Efficiency = 225f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade6") && Maxage > 240f)
                        {
                            Efficiency = 240f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade7") && Maxage > 310f)
                        {
                            Efficiency = 310f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade8") && Maxage > 410f)
                        {
                            Efficiency = 410f / Maxage;
                        }
                        else if (pTarget.a.hasTrait("Grade9") && Maxage > 570f)
                        {
                            Efficiency = 570f / Maxage;
                        }
                        pTarget.a.ChangeYuanNeng(halfwaymana * xiulian * Efficiency);
                        pTarget.a.data.mana -= (int)halfwaymana;
                    }
                }
            }
            //资质天赋修炼（消耗）
            if (pTarget.a.data.mana < pTarget.a.getMaxMana())
            {
                foreach (var kvp in flairXiaohaoRanges)
                {
                    string flair = kvp.Key;
                    float min = kvp.Value.min;
                    float max = kvp.Value.max;

                    if (pTarget.a.hasTrait(flair))
                    {
                        float randomXiaohao = UnityEngine.Random.Range(min, max);
                        if(randomXiaohao<99)
                        {
                            float sswr = randomXiaohao % 1;
                            float sswbr = randomXiaohao / 1;
                            if (sswr >= 0.5)
                            {
                                randomXiaohao = sswbr + 1;
                            }
                            else
                            {
                                randomXiaohao = sswbr;
                            }
                        }
                        if (Globals.Tsotw >= randomXiaohao)
                        {
                            Globals.Tsotw -= randomXiaohao;
                            pTarget.a.data.mana += (int)randomXiaohao;
                        }
                    }
                }

            }
            return true;
        }
        //境界灵气获取
        public static bool Grade_absorb(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.hasTrait("flair81") || pTarget.a.hasTrait("flair9"))
            {
                return false;
            }
            //境界天赋修炼（消耗）速度
            var GradeXiaohaoRanges = new Dictionary<string, (float min, float max)>
            {
                { "Grade4", (2f, 4f) },
                { "Grade5", (2f, 4f) },
                { "Grade6", (2f, 4f) },
                { "Grade7", (18f, 36f) },
                { "Grade8", (36f, 72f) },
                { "Grade9", (72f, 144f) },
                { "Grade91", (200f, 400f) }
            };
            //境界天赋修炼（消耗）
            if (pTarget.a.data.mana < pTarget.a.getMaxMana())
            {
                foreach (var kvp in GradeXiaohaoRanges)
                {
                    string Grade = kvp.Key;
                    float min = kvp.Value.min;
                    float max = kvp.Value.max;

                    if (pTarget.a.hasTrait(Grade))
                    {
                        float randomXiaohao = UnityEngine.Random.Range(min, max);
                        if (randomXiaohao < 999)
                        {
                            float sswr = randomXiaohao % 1;
                            float sswbr = randomXiaohao / 1;
                            if (sswr >= 0.5)
                            {
                                randomXiaohao = sswbr + 1;
                            }
                            else
                            {
                                randomXiaohao = sswbr;
                            }
                        }
                        if (Globals.Tsotw >= randomXiaohao)
                        {
                            Globals.Tsotw -= randomXiaohao;
                            pTarget.a.data.mana += (int)randomXiaohao;
                        }
                    }
                }

            }
            return true;
        }
        //其他灵气获取
        public static bool Other_absorb(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.hasTrait("flair81") || pTarget.a.hasTrait("flair9"))
            {
                return false;
            }
            //其他天赋修炼（消耗）速度
            var OtherXiaohaoRanges = new Dictionary<string, (float min, float max)>
            {
                { "flair8", (2f, 5f) },
                { "flair91", (3f, 7f) },
                { "flair92", (1f, 3f) },
                { "flair93", (1f, 3f) },
                { "flair94", (6f, 19f) },
                { "flair95", (9f, 29f) }
            };
            //其他天赋修炼（消耗）
            if (pTarget.a.data.mana < pTarget.a.getMaxMana())
            {
                foreach (var kvp in OtherXiaohaoRanges)
                {
                    string flair = kvp.Key;
                    float min = kvp.Value.min;
                    float max = kvp.Value.max;

                    if (pTarget.a.hasTrait(flair))
                    {
                        float randomXiaohao = UnityEngine.Random.Range(min, max);
                        if (randomXiaohao < 99)
                        {
                            float sswr = randomXiaohao % 1;
                            float sswbr = randomXiaohao / 1;
                            if (sswr >= 0.5)
                            {
                                randomXiaohao = sswbr + 1;
                            }
                            else
                            {
                                randomXiaohao = sswbr;
                            }
                        }
                        if (Globals.Tsotw >= randomXiaohao)
                        {
                            Globals.Tsotw -= randomXiaohao;
                            pTarget.a.data.mana += (int)randomXiaohao;
                        }
                    }
                }

            }
            return true;
        }
        private static void UpdateYuannengBasedOnGrade(Actor actor, string traitName, float maxYuanneng)
        {
            if (actor.hasTrait(traitName))
            {
                actor.SetYuanNeng(Mathf.Min(maxYuanneng, actor.GetYuanNeng()));
            }
        }
        //以下为境界带的再生
        public static bool Grade0_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)1);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade01_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)1);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade02_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)5);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)8);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)12);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)18);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)27);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)50);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade91_EffectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)6);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        
        public static bool flair92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)1);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool hunger_Grade91(BaseSimObject pTarget, WorldTile pTile = null) //始祖的饱食度
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            if (a != null)
            {
                a.data.nutrition = 100; // 不会饥饿，饱食度一直为100%
            }

            return false;
        }
        
        public static bool Grade91_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (UnityEngine.Random.value < 0.1f)
            {
                ActionLibrary.castTornado(null, pTarget, null);
            }

            return true;
        }
        private static string GetRandomTrait(string[] additionalTraits)
        {
            return additionalTraits[UnityEngine.Random.Range(0, additionalTraits.Length)];
        }

        public static bool Grade0_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 2.99)
            {
                return false;
            }

            string[] forbiddenTraits =
            {
                "Grade01", "Grade02", "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8",
                "Grade9", "Grade91"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }
            string actorName = a.getName();
            if (!actorName.Contains("凝气") && !actorName.Contains("周天") && !actorName.Contains("结丹") && !actorName.Contains("紫府") && !actorName.Contains("元神") && !actorName.Contains("法相") && !actorName.Contains("洞虚") && !actorName.Contains("劫体") && !actorName.Contains("造化") && !actorName.Contains("道种") && !actorName.Contains("鸿蒙") && !actorName.Contains("太初") && !actorName.Contains("混元") && !a.hasTrait("flair8") && !a.hasTrait("flair91"))
            {
                a.data.setName(pTarget.a.getName() + " 凝气");
            }
            upTrait("特质", "Grade0", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
                new string[] { "特质" });

            return true;
        }

        private static string GetNewRandomTrait(string[] additionalTraits)
        {
            // 逻辑从 additionalTraits 中随机选择一个特质
            int randomIndex = UnityEngine.Random.Range(0, additionalTraits.Length);
            return additionalTraits[randomIndex];
        }

        public static bool Grade01_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 5.99)
            {
                return false;
            }
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 凝气"))
            {
                newName = currentName.Replace(" 凝气", " 周天");
                a.data.setName(newName);
            }

            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07", "sorcery08" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade01", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade0" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade02_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addStatusEffect("Ring01");
            if (a.GetYuanNeng() <= 8.99)
            {
                return false;
            }
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 周天"))
            {
                newName = currentName.Replace(" 周天", " 结丹");
                a.data.setName(newName);
            }
            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07", "sorcery08" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade02", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade01" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 17.99)
            {
                return false;
            }

            a.ChangeYuanNeng(-1);
            double successRate = 0.6; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.9;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 混元"))
                {
                    successRate = 0.9;
                }
                else if (currentName.Contains(" 太初"))
                {
                    successRate = 0.8;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            // 初始化newName为当前名称
            string newName = currentName;
            if (currentName.Contains(" 结丹"))
            {
                newName = currentName.Replace(" 结丹", " 紫府");
                a.data.setName(newName);
            }

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade1", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "crippled", "skin_burns", "eyepatch", "Grade02" },
                new string[] { "freeze_proof", "fire_proof", randomTrait, "sorcery08" });

            return true;
        }

        public static bool Grade2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 29.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 紫府"))
            {
                newName = currentName.Replace(" 紫府", " 元神");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-2);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("Grade1", "Grade2", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade1" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 44.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 元神"))
            {
                newName = currentName.Replace(" 元神", " 法相");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-3);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade3", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade2" },
                new string[] { randomTrait });


            return true;
        }

        public static bool Grade4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 69.99)
            {
                return false;
            }
            a.ChangeYuanNeng(-6);
            double successRate = 0.5; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 混元"))
                {
                    successRate = 0.8;
                }
                else if (currentName.Contains(" 太初"))
                {
                    successRate = 0.7;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.5;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            if (currentName.Contains(" 法相"))
            {
                newName = currentName.Replace(" 法相", " 洞虚");
                a.data.setName(newName);
            }

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade4", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade3" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 139.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 洞虚"))
            {
                newName = currentName.Replace(" 洞虚", " 劫体");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-10);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade5", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade4" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 209.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“渡劫”
            var (baseName, _) = ParseName(currentName);
            string newTitle = yuanyingTitles[UnityEngine.Random.Range(0, yuanyingTitles.Length)];
            a.data.setName($"{newTitle} - {baseName} 造化");
            a.ChangeYuanNeng(-20);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade6", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade5" },
                new string[] { randomTrait });

            return true;
        }
        private static (string baseName, string realm) ParseName(string name)
        {
            string[] parts = name.Split(new[] { " - " }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 2)
            {
                string[] nameParts = parts[1].Split(' ');
                return (nameParts[0], nameParts.Last());
            }
            return (name.Split(' ')[0], "");
        }
        public static bool Grade7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 287.99)
            {
                return false;
            }
            a.ChangeYuanNeng(-30);
            double successRate = 0.2; //默认概率 
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 混元"))
                {
                    successRate = 0.5;
                }
                else if (currentName.Contains(" 太初"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.2;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“登仙”
            var (baseName, _) = ParseName(currentName);
            string newTitle = sanxianTitles[UnityEngine.Random.Range(0, sanxianTitles.Length)];
            a.data.setName($"{newTitle} - {baseName} 道种");

            string[] sorceryTraits = { "sorcery31", "sorcery32", "sorcery33", "sorcery34", "sorcery35" };
            string[] meditationTraits = { "meditation1", "meditation2", "meditation3" };
            string randomSorceryTrait = GetNewRandomTrait(sorceryTraits);
            bool hasMeditationTrait = meditationTraits.Any(trait => a.hasTrait(trait));
            string randomMeditationTrait = "";
            if (!hasMeditationTrait)
            {
                randomMeditationTrait = GetNewRandomTrait(meditationTraits); //获取新随机特质
            }

            upTrait("特质", "Grade7", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade6", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" },
                new string[] { "添加升级外的特质", randomSorceryTrait, randomMeditationTrait });

            return true;
        }

        public static bool Grade8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 199.99)//突破需求
            {
                return false;
            }
            a.ChangeMeditation(-30);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 混元"))
                {
                    successRate = 0.5;
                }
                else if (currentName.Contains(" 太初"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“登仙”
            if (currentName.Contains(" 道种"))
            {
                newName = currentName.Replace(" 道种", " 鸿蒙");
                a.data.setName(newName);
            }



            upTrait("特质", "Grade8", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade7", "flair81" },
                new string[] { "添加升级外的特质" });

            return true;
        }

        public static bool Grade9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 379.99)//突破需求
            {
                return false;
            }
            a.ChangeMeditation(-50);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.35;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 混元"))
                {
                    successRate = 0.35;
                }
                else if (currentName.Contains(" 太初"))
                {
                    successRate = 0.3;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.3;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“真仙”，如果包含则替换为“金仙”
            if (currentName.Contains(" 鸿蒙"))
            {
                var (baseName, _) = ParseName(currentName);
                string newTitle = jinyuanTitles[UnityEngine.Random.Range(0, jinyuanTitles.Length)];
                a.data.setName($"{newTitle} - {baseName} 太初");
                a.data.favorite = true;
            }
            if (!a.hasTrait("flair91") && !a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair8"))
                {
                    a.addTrait("flair8");
                    int randomResurrection = UnityEngine.Random.Range(10, 16);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade9Tips.Count);
            string tip = grade9Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade9", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade8", "talent7", "flair81" },
                new string[] { "添加升级外的特质" });

            return true;
        }
        private static readonly List<string> grade9Tips = new List<string>
        {
            "「九重天劫炼金身，「{0}」踏碎轮回门\n三灾焚尽凡胎骨，紫府玄丹证不泯\n待叩玉京混元境，再借造化塑真神！」",
            "「太虚雷火锻仙胎，「{0}」执印破劫来\n胸中五炁吞星斗，顶上三花映灵台\n纵使道消十二万，残魂犹可问元始！」",
            "「紫府玄光耀八荒，「{0}」历劫显锋芒\n血染星河九千转，魂渡归墟三万场\n今朝且驻大罗境，待化混元镇穹苍！」",
            "「混沌青莲绽灵台，「{0}」叩天显道才\n袖纳阴阳吞日月，掌托星斗炼劫灾\n此身虽未证元始，九死神魂自归来！」",
            "「玄黄血染登仙阶，「{0}」执剑问劫灭\n三千雷火锻道骨，八万魔障淬神魂\n纵使玉京门未启，不灭真灵可重燃！」",
            "「轮回镜碎现真灵，「{0}」涅槃塑仙形\n九转玄功吞日月，大罗道果镇幽冥\n此身已渡无量劫，只待混元叩天门！」"
        };
        public static bool Grade91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 999.99)
            {
                return false;
            }

            a.ChangeMeditation(-700);
            double successRate = 0.1; //突破默认概率
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 检查名称中是否包含“金仙”，如果包含则替换为“混元”
            var (baseName, _) = ParseName(currentName);
            string newTitle = hunyuanTitles[UnityEngine.Random.Range(0, hunyuanTitles.Length)];
            a.data.setName($"{newTitle} - {baseName} 混元");
            if (!a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair91"))
                {
                    a.addTrait("flair91");
                    int randomResurrection = UnityEngine.Random.Range(80, 101);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade91Tips.Count);
            string tip = grade91Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade91", a,
                new string[]
                {
                    "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade9", "sorcery31",
                    "sorcery32", "sorcery33", "sorcery34", "sorcery35", "flair8", "flair81"

                },
                new string[] { "特质" });

            return true;
        }
        // 定义一组升级提示信息
        private static readonly List<string> grade91Tips = new List<string>
        {
            "混沌初开鸿蒙启，「{0}」登临玉京台\n三花聚顶凝道果，五炁朝元化仙胎\n掌纳天地归芥子，身演周天作法材\n今朝勘破元始境，方知大道为我开",
            "玉府丹元耀宇空，「{0}」铸道显神通\n骨化天柱撑四极，血涌星河贯九穹\n一念真空消万法，诸天星辰系指中\n此身已证混元体，永镇乾坤造化功",
            "太始玄晶凝窍穴，「{0}」证道显庄严\n鸿蒙劫火煅神骨，造化真金铸圣颜\n掌纳归墟湮日月，袖藏宇宙演诸天\n今立鸿蒙最高处，方知我本道中仙",
            "灵台方寸孕真我，「{0}」悟道显金身\n脐下混沌开天地，眉间星海映乾坤\n三千道藏化虹幕，八万魔尊俱俯臣\n此身即道道即我，万劫不磨永称尊",
            "太虚剑鸣二十四,「{0}」悟剑显神通\n诸天神魔皆俯首,三千大道共称臣\n举手截断光阴水,覆掌重开造化门\n今朝证得剑道极,方知我本道剑尊",
            "紫府青莲开十二,「{0}」证道显玄光\n玉京金阙自生香,血脉化作时光江\n身映诸天无穷界,一念重启万物纲\n此身已证道果极,永镇乾坤创世章"
        };

        public static bool flair8_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」灵魂已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair8");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 添加随机 flair 特质
            string[] flairTraits = { "flair3", "flair4", "flair5" };
            string[] wuxingTraits = { "wuxing3", "wuxing4", "wuxing5" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            string selectedFlair2 = wuxingTraits[UnityEngine.Random.Range(0, wuxingTraits.Length)];
            a.addTrait(selectedFlair);
            a.addTrait(selectedFlair2);

            // 创建新单位并设置属性
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 触发特效
            new PowerLibrary().divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」真灵已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));
                
            a.addTrait("flair91");
            a.addTrait("flair5");
            activeMeditations.ForEach(t => a.addTrait(t));

            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 特效触发
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair92_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair92");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 随机选择新特质并添加（同时保留到新单位）
            string[] flairTraits = { "flair3", "flair4", "flair5", "flair6", "talent1", "talent2", "talent3", "talent4", "blessed", "flower_prints" };
            string[] wuxingTraits = { "wuxing3", "wuxing4", "wuxing5" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            string selectedFlair2 = wuxingTraits[UnityEngine.Random.Range(0, wuxingTraits.Length)];
            a.addTrait(selectedFlair);
            a.addTrait(selectedFlair2);

            // 创建新单位
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            // 名称清洗（优化为链式操作）
            act.data.setName(new[] { " 圣体" }
                        .Aggregate(a.getName(), (name, keyword) => name.Replace(keyword, "")));
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            act.ChangeRresurrection(a.GetRresurrection() + 1);
            // 特效触发
            new PowerLibrary().divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool Grade91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            Grade91_Action(a);
            return true;
        }
        private static bool Grade91_Action(Actor a)
        {
            // 首先计算所有存活的小人总数
            int totalAliveCount = 0;
            List<Actor> simpleList = World.world.units.getSimpleList();
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive())
                {
                    totalAliveCount++;
                    // 所有存活且有相应特质的增加源能和无根之源
                    if (actor.hasTrait("flair1") || actor.hasTrait("flair2") || actor.hasTrait("flair3") ||
                        actor.hasTrait("flair4") || actor.hasTrait("flair5") || actor.hasTrait("flair6") || actor.hasTrait("flair7"))
                    {
                        // 随机增加50~100源能
                        int yuanNengIncrease = UnityEngine.Random.Range(50, 101);
                        actor.ChangeYuanNeng(yuanNengIncrease);
                    }
                    if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
                    {
                        // 随机增加500~1000无根之源
                        int meditationIncrease = UnityEngine.Random.Range(500, 1001);
                        actor.ChangeMeditation(meditationIncrease);
                    }
                }
            }
            
            int num = 0;
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive() && !actor.data.favorite && !actor.asset.ignored_by_infinity_coin)
                {
                    num++;
                }
            }

            int num2 = (int)Math.Ceiling(num * 0.30); // 计算30%的小人数量
            int num3 = 0;

            EffectInfinityCoin._temp_list.Clear();
            EffectInfinityCoin._temp_list.AddRange(World.world.units);
            EffectInfinityCoin._temp_list.Shuffle<Actor>();
            foreach (Actor actor2 in EffectInfinityCoin._temp_list)
            {
                if (num2 == 0)
                {
                    break;
                }
                if (actor2.isAlive() && !actor2.data.favorite && !actor2.asset.ignored_by_infinity_coin)
                {
                    num3++;
                    num2--;
                    actor2.getHit((float)(actor2.data.health * 1000 + 1), true, AttackType.Other, null, false, false);
                }
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(Grade91deathTips.Count);
            string tip = Grade91deathTips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        private static readonly List<string> Grade91deathTips = new List<string>
        {
            "「{0}」道体化飞烟，混元道果散诸天。虽遭劫难身暂殒，真灵不灭待重燃。\n三清圣境留残影，混沌深处蕴生机。待到天地重开日，再掌乾坤立新篇。",
            "「{0}」道躯显真灵，虽散乾坤意未停。元神化作三千念，各寻机缘待成形。\n九幽深处藏玄机，三十三天留道印。重聚神魂归本位，再演混元破天经。",
            "「{0}」身遭劫火焚，道果化作漫天星。九天之上留光影，九泉之下存道根。\n虽暂离世去，道意永存宇宙心。待到涅槃劫火熄，重生再造混元身。",
            "「{0}」道体显化终，混元道种散苍穹。虽暂入轮回道，真我本意未曾空。\n三界六道留踪迹，九幽十方藏玄功。待得时机成熟日，重证混元掌天宗。",
            "「{0}」身化万千星，道体归寂显玄冥。虽暂离三界外，混元本性未曾泯。\n周天星斗留道印，混沌虚空蕴真灵。待时重聚道体日，再演混元破劫经。",
            "「{0}」道躯遭道劫，混元道果显真形。虽暂离世间去，天地永记混元名。\n三界六道留道韵，三十三天蕴道音。待到劫数轮回转，重铸道体掌天心。"
        };
        public static bool teleportRandom(Actor a)
        {
            MapBox mapBox = World.world as MapBox;
            if (mapBox == null)
            {
                return false;
            }

            CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
            if (citiesManager == null)
            {
                return false;
            }

            List<City> cities = citiesManager.list;
            if (cities.Count == 0)
            {
                return false;
            }

            int randomIndex = UnityEngine.Random.Range(0, citiesManager.list.Count);
            City randomCity = citiesManager.list[randomIndex];

            WorldTile cityCenterTile = randomCity.getTile();
            if (cityCenterTile == null || cityCenterTile.Type.block || !cityCenterTile.Type.ground)
            {
                return false;
            }

            a.cancelAllBeh();
            a.spawnOn(cityCenterTile, 0f);
            return true;
        }
        public static bool flair6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("圣体"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("【天道告示•混沌圣体】\n九霄惊雷动，阴阳逆乱生！\n圣体现世，当镇八荒风云！");
                        pTarget.a.data.setName(pTarget.a.getName() + " 圣体");
                        actorTipsShown[pTarget.a] = (true, tipsShown.hasShownSSSTip); // 更新状态
                    }
                    return false;
                }
            }
            return true;
        }
        public static bool flair7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SSS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("道胎"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("【大道昭告•鸿蒙道胎】\n紫气吞寰宇，道纹裂虚空！\n道胎临凡，重开万古洪荒！");
                        pTarget.a.data.setName(pTarget.a.getName() + " 道胎");
                        actorTipsShown[pTarget.a] = (tipsShown.hasShownSSTip, true); // 更新状态
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }
        private static Dictionary<Actor, (bool hasShownSSTip, bool hasShownSSSTip)> actorTipsShown = new Dictionary<Actor, (bool, bool)>();
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(string   old_trait, string new_trait, Actor actor, string[] other_Oldtraits = null,
                                   string[] other_newTrait = null)
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}