﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoCopilot.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset interesting2 = new ActorTraitGroupAsset();
            interesting2.id = "interesting2";
            interesting2.name = "trait_group_interesting2";
            interesting2.color = "#00FFFF";
            AssetManager.trait_groups.add(interesting2);

            ActorTraitGroupAsset interesting3 = new ActorTraitGroupAsset();
            interesting3.id = "interesting3";
            interesting3.name = "trait_group_interesting3";
            interesting3.color = "#D02090";
            AssetManager.trait_groups.add(interesting3);

            ActorTraitGroupAsset interesting4 = new ActorTraitGroupAsset();
            interesting4.id = "interesting4";
            interesting4.name = "trait_group_interesting4";
            interesting4.color = "#FFC20E";
            AssetManager.trait_groups.add(interesting4);
        }
    }
}
