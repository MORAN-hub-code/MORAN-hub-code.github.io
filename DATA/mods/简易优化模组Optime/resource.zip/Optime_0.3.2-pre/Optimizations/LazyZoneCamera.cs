﻿using HarmonyLib;
using UnityEngine;

namespace Optime.Optimizations {
    internal sealed class LazyZoneCamera : Feature<LazyZoneCamera> {
        private static Vector3 _lastMoveCameraPosition;
        private static float _lastOrthographicSize;

        public new static void SetLoaded(bool value) {
            Feature<LazyZoneCamera>.SetLoaded(value);
        }

        [HarmonyPatch(typeof(ZoneCamera), nameof(ZoneCamera.update))]
        [HarmonyPrefix]
        public static bool update() {
            if (_lastOrthographicSize == MapBox.instance.camera.orthographicSize
                && _lastMoveCameraPosition == MoveCamera.instance.transform.position) {
                return false;
            }

            _lastOrthographicSize = MapBox.instance.camera.orthographicSize;
            _lastMoveCameraPosition = MoveCamera.instance.transform.position;

            return true;
        }
    }
}