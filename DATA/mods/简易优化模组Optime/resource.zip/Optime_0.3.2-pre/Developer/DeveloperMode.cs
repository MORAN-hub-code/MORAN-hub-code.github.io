﻿namespace Optime.Developer {
    internal sealed class DeveloperMode : Feature<DeveloperMode> {
        public new static void SetLoaded(bool value) {
            Feature<DeveloperMode>.SetLoaded(value);
        }

        protected override void OnLoad() {
            base.OnLoad();

            Config.isEditor = true;
            DebugConfig.setOption(DebugOption.DebugButton, true);
        }

        protected override void OnUnload() {
            base.OnUnload();

            Config.isEditor = false;

            if (Main.ModConfig["Developer"].ContainsKey("Disable Map Stats")) {
                Main.ModConfig["Developer"]["Disable Map Stats"].SetValue(false);
            }
        }
    }
}