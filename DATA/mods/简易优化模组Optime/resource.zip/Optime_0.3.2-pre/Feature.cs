﻿using HarmonyLib;
using UnityEngine;

namespace Optime {
    internal abstract class Feature<T> : MonoBehaviour where T : Feature<T> {
        // ReSharper disable once StaticMemberInGenericType
        private static bool _enableOnAwake;
        public static Feature<T> Instance { get; private set; }
        protected Harmony Harmony { get; private set; }

        public static void SetLoaded(bool value) {
            if (Instance == null) {
                _enableOnAwake = value;
            } else {
                Instance.enabled = value;
            }
        }

        protected virtual void OnLoad() {
            Harmony.PatchAll(GetType());
        }

        protected virtual void OnUnload() {
            Harmony.UnpatchSelf();
        }

        private void Awake() {
            if (Instance != null) {
                enabled = false;

                return;
            }

            Harmony = new Harmony(typeof(T).ToString());
            Instance = this;
            Instance.enabled = _enableOnAwake;
        }

        private void OnDisable() {
            if (Instance == this) {
                OnUnload();
            }
        }

        private void OnEnable() {
            if (Instance == this) {
                OnLoad();

                return;
            }

            enabled = false;
        }
    }
}