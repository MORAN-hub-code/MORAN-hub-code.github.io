﻿using UnityEngine;

namespace Optime.QoL {
    internal class FPSCounter : Feature<FPSCounter> {
        public new static void SetLoaded(bool value) {
            Feature<FPSCounter>.SetLoaded(value);
        }

        private void OnGUI() {
            GUI.Label(new Rect(0, 0, 100, 50), $"FPS: {(global::FPS.fps)}");
        }
    }
}