﻿namespace Optime.QoL {
    internal sealed class DisableAnalytics : Feature<DisableAnalytics> {
        public new static void SetLoaded(bool value) {
            Feature<DisableAnalytics>.SetLoaded(value);
        }

        protected override void OnLoad() {
            base.OnLoad();

            Config.firebase_available = false;
        }

        protected override void OnUnload() {
            base.OnUnload();

            Config.firebase_available = true;
        }
    }
}