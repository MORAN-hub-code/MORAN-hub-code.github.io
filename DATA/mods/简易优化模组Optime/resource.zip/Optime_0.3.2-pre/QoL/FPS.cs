﻿using HarmonyLib;
using UnityEngine;

namespace Optime.QoL {
    internal sealed class FPS : Feature<FPS> {
        [HarmonyPatch(typeof(MapBox), nameof(MapBox.calculateCurElapsed))]
        [HarmonyPrefix]
        public static bool calculateCurElapsed(ref float __result) {
            float fps = 1.0f / Time.unscaledDeltaTime;

            __result = fps > 60f
                ? Time.fixedDeltaTime * Config.time_scale_asset.multiplier * (60f / fps)
                : Time.fixedDeltaTime * Config.time_scale_asset.multiplier;

            return false;
        }

        public static void SetFrameRate(int value) {
            if (PlayerConfig.optionBoolEnabled("vsync")) {
                return;
            }

            if (PlayerConfig.optionBoolEnabled("fps_lock_30")) {
                return;
            }

            Application.targetFrameRate = value < 60 ? 60 : value;
        }

        protected override void OnLoad() {
            base.OnLoad();

            SetFrameRate(Main.ModConfig["QoL"]["Max Frame Rate"].IntVal);
        }

        protected override void OnUnload() {
            base.OnUnload();

            SetFrameRate(60);
        }
    }
}