﻿using NeoModLoader.api;
using Optime.Developer;
using Optime.Optimizations;
using Optime.QoL;

namespace Optime {
    internal class Main : BasicMod<Main> {
        private static Main _mod;
        public static ModConfig ModConfig => _mod.GetConfig();

        protected override void OnModLoad() {
            if (_mod != null) {
                return;
            }

            _mod = this;
            LoadQoL();
            LoadOptimizations();
            LoadBugFixes();
            LoadDeveloperFeatures();
        }

        private void LoadBugFixes() { }

        private void LoadDeveloperFeatures() {
            gameObject.AddComponent<DeveloperMode>();
            gameObject.AddComponent<DisableMapStats>();

            DeveloperMode.SetLoaded(GetConfig()["Developer"]["Developer Mode"].BoolVal);
            DisableMapStats.SetLoaded(GetConfig()["Developer"]["Disable Map Stats"].BoolVal);
        }

        private void LoadOptimizations() {
            gameObject.AddComponent<LazyZoneCamera>();

            LazyZoneCamera.SetLoaded(GetConfig()["Optimizations"]["Lazy Zone Camera"].BoolVal);
        }

        private void LoadQoL() {
            gameObject.AddComponent<DisableAnalytics>();
            gameObject.AddComponent<TimeStopProjectiles>();
            gameObject.AddComponent<HideWelcomeWindow>();
            gameObject.AddComponent<FPSCounter>();
            gameObject.AddComponent<QoL.FPS>();

            DisableAnalytics.SetLoaded(GetConfig()["QoL"]["Disable Analytics"].BoolVal);
            TimeStopProjectiles.SetLoaded(GetConfig()["QoL"]["Time Stop Projectiles"].BoolVal);
            HideWelcomeWindow.SetLoaded(GetConfig()["QoL"]["Hide Welcome Window"].BoolVal);
            FPSCounter.SetLoaded(GetConfig()["QoL"]["Display FPS Counter"].BoolVal);
            QoL.FPS.SetLoaded(true);
        }
    }
}