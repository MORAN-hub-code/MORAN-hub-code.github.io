﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool lei5_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;

                // 直接连续调用三次，不使用条件判断
                MapBox.spawnLightningBig(pTile, 0.60f);
                MapBox.spawnLightningBig(pTile, 0.60f);
                MapBox.spawnLightningBig(pTile, 0.60f);
                if (pTarget.a.data.health > 1000000)
                {
                    pTarget.a.restoreHealth(-1000000);
                }
                if (pTarget.a.data.health > 30000)
                {
                    pTarget.a.restoreHealth(-30000);
                }
                if (pTarget.a.data.health > 500)
                {
                    pTarget.a.restoreHealth(-500);
                }
                if (pTarget.a.data.health > 30)
                {
                    pTarget.a.restoreHealth(-30);
                }
            }

            return false;
        }

        public static bool lei4_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;

                // 直接连续调用三次，不使用条件判断
                MapBox.spawnLightningBig(pTile, 0.60f);
                if (pTarget.a.data.health > 30000)
                {
                    pTarget.a.restoreHealth(-30000);
                }
                if (pTarget.a.data.health > 500)
                {
                    pTarget.a.restoreHealth(-500);
                }
                if (pTarget.a.data.health > 30)
                {
                    pTarget.a.restoreHealth(-30);
                }
            }

            return false;
        }

        public static bool lei3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningBig(pTile, 0.50f);
                if (pTarget.a.data.health > 3000)
                {
                    pTarget.a.restoreHealth(-3000);
                }
                if (pTarget.a.data.health > 30)
                {
                    pTarget.a.restoreHealth(-30);
                }
            }

            return false;
        }

        public static bool lei2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningBig(pTile, 0.30f);
                if (pTarget.a.data.health > 500)
                {
                    pTarget.a.restoreHealth(-500);
                }
                if (pTarget.a.data.health > 30)
                {
                    pTarget.a.restoreHealth(-30);
                }
            }

            return false;
        }

        public static bool lei_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningMedium(pTile, 0.15f);
                if (pTarget.a.data.health > 30)
                {
                    pTarget.a.restoreHealth(-30);
                }
            }

            return false;
        }

        public static bool Knight1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.学徒骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Knight2", "Knight3", "Knight4", "Knight5", "Knight6", "Knight7", "Knight8", "Knight9", "Knight10", "Knight11", "Knight12", "Knight13" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Knight1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );

            return true;
        }

        public static bool Knight2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetKnight() <= 9.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.8;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight1",
                "Knight2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Knight22" }
            );

            return true;
        }

        public static bool Knight3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 8)
            {
                // 添加Knight1特质
                upTrait("特质", "Knight1", a, new string[] { "Knight2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 17.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Knight2",
                "Knight3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight22"
                },
                new string[] { "Knight3+", selectedTrait }
            );

            return true;
        }

        public static bool Knight4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.中级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 16)
            {
                upTrait("特质", "Knight2", a, new string[] { "Knight3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 31.99)
            {
                return false;
            }

            a.ChangeKnight(-3);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight3",
                "Knight4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight3+"
                },
                new string[] { "Knight4+" }
            );

            return true;
        }

        public static bool Knight5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.高骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 29)
            {
                upTrait("特质", "Knight3", a, new string[] { "Knight4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 52.99)
            {
                return false;
            }

            a.ChangeKnight(-4);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Knight4",
                "Knight5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight4+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight5+", selectedTrait } :
                new string[] { "Knight5+" }
            );

            return true;
        }

        public static bool Knight6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 49)
            {
                upTrait("特质", "Knight4", a, new string[] { "Knight5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 67.99)
            {
                return false;
            }

            a.ChangeKnight(-5);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }

            string actorName = a.getName();
            bool hasTitle = _knightTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _knightTitles.Length);
                string selectedTitle = _knightTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Knight5",
                "Knight6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight5+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight6+", "freeze_proof", "fire_proof", selectedTrait } :
                new string[] { "Knight6+", "freeze_proof", "fire_proof" }
            );

            return true;
        }

        public static bool Knight7_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 63)
            {
                upTrait("特质", "Knight6", a, new string[] { "Knight7" }, new string[] { });
                return true;
            }

            if (a.GetKnight() <= 74.99)
            {
                return false;
            }

            a.ChangeKnight(-6);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight6",
                "Knight7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight6+" },
                new string[] { "Knight7+" }
            );

            return true;
        }

        public static bool Knight8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.皇家骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 119.99)
            {
                return false;
            }

            a.ChangeKnight(-9);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight7",
                "Knight8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight7+" },
                new string[] { "Knight8+", "strong_minded", "immune" }
            );

            return true;
        }

        public static bool Knight9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.传奇骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 199.99)
            {
                return false;
            }

            a.ChangeKnight(-15);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight8",
                "Knight9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight8+" },
                new string[] { "Knight9+" }
            );

            return true;
        }

        public static bool Knight10_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣殿骑士长
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 299.99)
            {
                return false;
            }

            a.ChangeKnight(-20);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight9",
                "Knight10",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight9+" },
                new string[] { "Knight10+" }
            );

            return true;
        }

        public static bool Knight11_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.骑士王
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 499.99)
            {
                return false;
            }

            a.ChangeKnight(-30);
            double successRate = 0.06;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.03;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight10",
                "Knight11",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight10+" },
                new string[] { "Knight11+" }
            );

            return true;
        }

        public static bool Knight12_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.天启骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetKnight() <= 899.99)
            {
                return false;
            }

            a.ChangeKnight(-60);
            double successRate = 0.02;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.001;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight11",
                "Knight12",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight11+" },
                new string[] { "Knight12+" }
            );

            return true;
        }

            public static bool Knight13_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.天启骑士十三境
            {
                if (pTarget == null)
                {
                    return false;
                }

                if (!pTarget.isActor())
                {
                    return false;
                }

                Actor a = pTarget.a;
                // 天启骑士最高境界不会跌落

                // 检查是否已达到十二境巅峰
                if (a.GetKnight() <= 4999.99) // 假设十三境需要1300点修为
                {
                    return false;
                }

                // 消耗修为
                a.ChangeKnight(-150); // 消耗144点修为

                // 根据天赋设置成功率
                double successRate = 0.01; // 基础成功率0.5%
                if (a.hasTrait("talent1"))
                {
                    successRate = 0.01; // 天赋1成功率0.025%
                }
                else if (a.hasTrait("talent2"))
                {
                    successRate = 0.01; // 天赋2成功率0.05%
                }
                else if (a.hasTrait("talent3"))
                {
                    successRate = 0.01; // 天赋3成功率0.25%
                }

                // 随机判定是否成功
                if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
                {
                    return false;
                }

                // 升级特质
                upTrait(
                    "Knight12", // 当前特质
                    "Knight13", // 新特质
                    a,
                    new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight12+" }, // 需要移除的特质
                    new string[] { "Knight13+" } // 需要添加的特质
                );

                return true;
            }

        private static readonly string[] _knightTitles = { "「苍蓝残响」", "「殷红迷雾」", "「堇紫泪滴」", "「漆黑缄默」", "「朱红十字」", "「猩红凝视」", "「靛蓝老者」"
, "「缃碧少女」", "「白月骑士」", "「灰岩猎人」", "「深红法典」", "「黑月女王」", "「绀青巨人」", "「幽蓝校尉」", "「血红屠夫」", "「深蓝智者」", "「墨绿慈父」", "「黛粉妖姬」"
, "「银月公子」", "「暗金帝皇」", "「骨白教士」", "「群青武者」", "「绯红妖姬」", "「深褐雄狮」", "「暗紫行者」", "「猩红匠师」", "「品红旅人」", "「暗黑暴君」"
, "「血红恶狼」", "「漆黑鼯鼠」", "「赤红圣母」", "「明黄辉光」", "「蔚蓝风暴」", "「玫红罗盘」", "「月蓝低语」", "「翠绿圣杯」", "「褐岩猛兽」", "「纯白之扉」"
, "「银蓝学者」", "「蓝晶医师」", "「夜蓝游侠」", "「深红龙骑」", "「墨羽天使」", "「青钢之剑」", "「黑岩长枪」", "「赭黄坚盾」", "「苍月统帅」", "「曦银诗人」"
, "「幽碧影刃」", "「苍青之龙」" , "「救世」", "「真我」", "「戒律」", "「黄金」", "「螺旋」", "「歼灭」", "「金红蔷薇」", "「夜枭巡礼」", "「灰土送葬」", "「刹那」"
, "「天慧」", "「无限」", "「繁星」", "「浮生」", "「红石妙手」", "「五协会」", "「十一协会」", "「墨色使徒」", "「白羊牧者」", "「肤色钢裢」", "「原色画师」", "「白色相簿」"
, "「蓝骑」", "「红骑」", "「紫骑」", "「灰骑」" , "「琥珀号角」", "「雾色艄公」", "「淡色歌者」", "「绯色空想」", "「锈色判官」", "「古铜更夫」", "「雾银裁缝」"
, "「铅灰医者」", "「鸦青律师」", "「黯血魔鹰」", "「丝白女爵」", "「六协会」", "「学士」", "「一协会」", "「二协会」", "「空梦」", "「旭光」", "「中指」"
, "「尾指」", "「圣灰诵者」", "「三协会」" , "「四协会」", "「拇指」", "「食指」", "「环指」", "「暴怒」", "「色欲」", "「忧郁」", "「傲慢」", "「怠惰」", "「希望」"
, "「嫉妒」", "「暴食」", "「晨辉」" };

        //骑士的恢复生命值效果
        public static bool Knight1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(160);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(400);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(600);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(900);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight10_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight11_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(6000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight12_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(80000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight13_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(8000000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
