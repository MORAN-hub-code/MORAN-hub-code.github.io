using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using ai;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace CustomModT001;

internal static class Patches
{
    internal static bool window_favorites_global_mode;
    private static int  window_favorites_global_object_count = 10;
    [HarmonyPrefix, HarmonyPatch(typeof(MapBox), nameof(MapBox.checkObjectsToDestroy))]
    private static void MapBox_checkObjectsToDestroy_prefix(MapBox __instance)
    {
        foreach (var unit in __instance.units.getSimpleList())
        {
            if (unit.isAlive() && unit.hasTrait(Traits.war_ashes.id))
            {
                int x = unit.current_tile.x;
                int y = unit.current_tile.y;
                int new_dead_count = __instance.units._to_destroy_objects.Count(a =>
                    Mathf.Abs(a.current_tile.x - x) < 7 && Mathf.Abs(a.current_tile.y - y) < 7);

                unit.IncWarAshesCount(new_dead_count);
            }
        }
    }
    private static bool window_creature_info_initialized;
    [HarmonyPostfix, HarmonyPatch(typeof(BabyHelper), nameof(BabyHelper.canMakeBabies))]
    private static void BabyHelper_canMakeBabies_postfix(ref bool __result, Actor pActor)
    {
        __result &= !pActor.hasTrait(Traits.summoned.id);
    }
    [HarmonyPostfix]
    [HarmonyPatch(typeof(City), nameof(City.addCapturePoints), [typeof(Kingdom), typeof(int)])]
    private static void City_addCapturePoints_postfix(City __instance)
    {
        if (!ModConfigHelper.WarRuleCitySurrender)
        {
            __instance._capturing_units.Clear();
        }
    }
    
    [HarmonyTranspiler, HarmonyPatch(typeof(BaseSimObject), nameof(BaseSimObject.canAttackTarget))]
    private static IEnumerable<CodeInstruction> BaseSimObject_canAttackTarget(IEnumerable<CodeInstruction> codes, ILGenerator generator)
    {
        var list = codes.ToList();

        var start_idx = 0;
        do
        {
            var world_law_idx =
                list.FindIndex(start_idx, x =>
                    x.opcode == OpCodes.Ldfld &&
                    (x.operand as FieldInfo)?.Name == nameof(WorldLawLibrary.world_law_angry_civilians));
            if (world_law_idx < 0)
            {
                break;
            }

            var jump_target = list[world_law_idx + 2];

            var jump_target_code = list.Find(x => x.labels.Contains((Label)jump_target.operand));

            var new_label = generator.DefineLabel();
            jump_target_code.labels.Add(new_label);
            list.InsertRange(world_law_idx + 3, new List<CodeInstruction>()
            {
                new(OpCodes.Call,
                    AccessTools.Method(typeof(ModConfigHelper), nameof(ModConfigHelper.AllowWarRuleCitySurrender))),
                new(jump_target.opcode, new_label)
            });
            start_idx = world_law_idx + 1;
        } while (true);
        return list;
    }
    
    [HarmonyPostfix]
    [HarmonyPatch(typeof(BabyMaker), nameof(BabyMaker.makeBaby))]
    private static void BabyMaker_makeBaby_postfix(Actor __result, Actor pParent1, Actor pParent2)
    {
        if (pParent1?.hasTrait(Traits.support_future) ?? false)
        {
            __result.addTrait(Traits.all_enabled_traits.GetRandom());
        }

        if (pParent2?.hasTrait(Traits.support_future) ?? false)
        {
            __result.addTrait(Traits.all_enabled_traits.GetRandom());
        }
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(StatusLibrary), nameof(StatusLibrary.burningEffect))]
    private static bool StatusLibrary_burningEffect_prefix(BaseSimObject pTarget)
    {
        if (pTarget.isActor() && pTarget.a.GetCultisysLevel() >= 5) return false;

        return true;
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), nameof(Actor.addTrait), new Type[] { typeof(ActorTrait) , typeof(bool)})]
    private static bool ActorBase_addTrait_prefix(Actor __instance, ActorTrait pTrait)
    {
        if (__instance.GetCultisysLevel() < 5) return true;
        return !Cultisys.TraitsBlacklist.Contains(pTrait.id);
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect))]
    private static bool Actor_addStatusEffect_prefix(Actor __instance, StatusAsset pStatusAsset)
    {
        if (__instance.a.GetCultisysLevel() < 5) return true;
        return !Cultisys.StatusesBlacklist.Contains(pStatusAsset.id);
    }
    [HarmonyPostfix, HarmonyPatch(typeof(BaseSimObject), nameof(BaseSimObject.removeFinishedStatusEffect))]
    private static void BaseSimObject_cleanupStatusEffects_postfix(BaseSimObject __instance,
        Status pStatusData)
    {
        pStatusData.asset.GetExtend().action_finished?.Invoke(__instance, pStatusData.asset);
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(BaseSimObject), nameof(BaseSimObject.addStatusEffect), [typeof(StatusAsset), typeof(float), typeof(bool)])]
    private static bool BaseSimObject_addStatusEffect_prefix(BaseSimObject __instance, StatusAsset pStatusAsset,
                                                             ref float     pOverrideTimer)
    {
        if (pOverrideTimer < 0)
        {
            pOverrideTimer = pStatusAsset.duration;
        }

        if (pStatusAsset.base_stats.hasTag(S_Tag.immovable))
        {
            pOverrideTimer *= 1 + __instance.stats[Stats.control_get.id];
            if (pOverrideTimer < 0) return false;
        }

        pOverrideTimer *= 1 + __instance.stats[Stats.status_time_get.id];
        return pOverrideTimer > 0;
    }
/*
    [HarmonyTranspiler]
    [HarmonyPatch(typeof(WindowFavorites), nameof(WindowFavorites.create))]
    private static IEnumerable<CodeInstruction> WindowFavorites_create_transpiler(IEnumerable<CodeInstruction> codes)
    {
        var list = codes.ToList();

        var idx = list.FindIndex(x =>
            x.opcode == OpCodes.Callvirt && (x.operand as MemberInfo)?.Name == nameof(SortButton.click));
        list.InsertRange(idx, new List<CodeInstruction>
        {
            new(OpCodes.Ldarg_0),
            new(OpCodes.Call, AccessTools.Method(typeof(Patches), nameof(WindowFavorites_create_postfix)))
        });


        return list;
    }
    [HarmonyPostfix, HarmonyPatch(typeof(WindowListBase<PrefabUnitElement, Actor>), nameof(WindowListBase<PrefabUnitElement, Actor>.OnDisable))]
    private static void WindowListBase_OnDisable_postfix()
    {
        window_favorites_global_mode = false;
    }

    private static void WindowFavorites_create_postfix(WindowFavorites __instance)
    {
        __instance.addSortButton("inmny/custommodt001/talent", $"{ModClass.asset_id_prefix}.ui.sort_by_talent",
            () => { __instance.current_sort = (a1, a2) => a2.GetTalent().CompareTo(a1.GetTalent()); });
        __instance.addSortButton("inmny/custommodt001/cultilevel", $"{ModClass.asset_id_prefix}.ui.sort_by_cultilevel",
            () =>
            {
                __instance.current_sort = (a1, a2) =>
                {
                    var level_res = a2.GetCultisysLevel().CompareTo(a1.GetCultisysLevel());
                    if (level_res != 0) return level_res;
                    return a2.GetExp().CompareTo(a1.GetExp());
                };
            });

        var mode_switch = new GameObject("ModeSwitch", typeof(Image), typeof(Button));
        mode_switch.transform.SetParent(__instance.transform);
        mode_switch.transform.localScale = Vector3.one;
        mode_switch.transform.localPosition = new Vector3(-122, 85);
        mode_switch.GetComponent<RectTransform>().sizeDelta = new Vector2(28, 28);
        var image = mode_switch.GetComponent<Image>();
        image.sprite = SpriteTextureLoader.getSprite("ui/icons/iconAge");
        var button = mode_switch.GetComponent<Button>();
        button.OnHover(show_tip);

        void show_tip()
        {
            Tooltip.show(mode_switch, Tooltips.common.id, new TooltipData
            {
                tip_name = $"{ModClass.asset_id_prefix}.ui.mode_switch",
                tip_description = $"显示前{window_favorites_global_object_count}",
                tip_description_2 = "滚轮调节数量"
            });
        }

        button.onClick.AddListener(() =>
        {
            window_favorites_global_mode = !window_favorites_global_mode;
            __instance.show();
        });
        var event_trigger = mode_switch.AddComponent<EventTrigger>();
        var scroll_callback = new EventTrigger.TriggerEvent();
        scroll_callback.AddListener(data =>
        {
            if (data is not PointerEventData pointer_event_data) return;
            if (pointer_event_data.scrollDelta.y > 0)
                window_favorites_global_object_count++;
            else if (pointer_event_data.scrollDelta.y < 0) window_favorites_global_object_count--;

            window_favorites_global_object_count = Math.Max(1, window_favorites_global_object_count);
            __instance.show();
            show_tip();
        });
        event_trigger.triggers.Add(new EventTrigger.Entry
        {
            eventID = EventTriggerType.Scroll,
            callback = scroll_callback
        });
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(WindowFavorites), nameof(WindowFavorites.getObjects))]
    private static void WindowFavorites_getObjects_postfix(WindowFavorites __instance, List<Actor> __result)
    {
        if (!window_favorites_global_mode) return;
        foreach (Actor actor in World.world.units)
            if (actor.isAlive() && !actor.data.favorite)
                __result.Add(actor);

        __result.Sort(__instance.current_sort);
        if (__instance._currentSortButton != null && __instance._currentSortButton.getState() == SortButtonState.Down)
            __result.Reverse();

        if (__result.Count > window_favorites_global_object_count)
            __result.RemoveRange(window_favorites_global_object_count,
                __result.Count - window_favorites_global_object_count);
    }
*/
    [HarmonyPostfix]
    [HarmonyPatch(typeof(BaseStats), nameof(BaseStats.mergeStats))]
    private static void BaseStats_mergeStats_postfix(BaseStats __instance, BaseStats pStats)
    {
        var id = Stats.addition_armor.id;
        var add = pStats[id];
        if (add == 0) return;
        var curr = __instance[id];
        var origin = curr - add;
        __instance[id] = origin + (100 - origin) * add / 100f;
    }
    [HarmonyPrefix,HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
    private static bool ActorBase_addForce_prefix(AttackData pData, BaseSimObject pTargetToCheck, ref float pMod)
    {
        pMod = 1 - pTargetToCheck.stats[S.knockback_reduction];
        if (pTargetToCheck.a == null) return true;
        if (pTargetToCheck.a.GetCultisysLevel() >= 5 || pTargetToCheck.a.hasTrait(Traits.final_resilience.id))
        {
            pMod = 0;
        }

        return true;
    }
    [HarmonyTranspiler]
    [HarmonyPatch(typeof(Actor), nameof(Actor.updateStats))]
    private static IEnumerable<CodeInstruction> Actor_updateStats_transpiler(IEnumerable<CodeInstruction> codes)
    {
        var list = codes.ToList();

        var addition_stats_idx = list.FindIndex(x =>
            x.opcode == OpCodes.Callvirt && (x.operand as MemberInfo)?.Name == nameof(BaseStats.normalize)) - 2;
        var add_codes = new List<CodeInstruction>
        {
            new(OpCodes.Ldarg_0),
            new(OpCodes.Call, AccessTools.Method(typeof(Patches), nameof(addition_stats)))
        };
        list[addition_stats_idx].MoveLabelsTo(add_codes[0]);
        list.InsertRange(addition_stats_idx, add_codes);


        var post_stats_idx = list.FindIndex(x =>
            x.opcode == OpCodes.Callvirt && (x.operand as MemberInfo)?.Name == nameof(BaseStats.checkMultipliers)) + 1;
        list.InsertRange(post_stats_idx, new List<CodeInstruction>
        {
            new(OpCodes.Ldarg_0),
            new(OpCodes.Call, AccessTools.Method(typeof(Patches), nameof(post_stats)))
        });
/*
        for (var i = 1; i < list.Count; i++)
        {
            CodeInstruction ldstr = list[i - 1];
            CodeInstruction call = list[i];
            if (ldstr.opcode == OpCodes.Ldstr && (string)ldstr.operand == "madness" && call.opcode == OpCodes.Call &&
                (call.operand as MemberInfo)?.Name == nameof(Actor.hasTrait))
                call.operand = AccessTools.Method(typeof(Patches), nameof(HasMadness));
        }*/
        var clear_trait_timers_idx = list.FindIndex(x =>
            x.opcode == OpCodes.Call && (x.operand as MethodInfo)?.Name == "Clear" && (x.operand as MethodInfo)?.DeclaringType == typeof(Dictionary<BaseAugmentationAsset, double>));
        list[clear_trait_timers_idx].operand = AccessTools.Method(typeof(Patches), nameof(empty_Dictionary_action));

        return list;
    }

    private static void empty_Dictionary_action(Dictionary<ActorTrait, double> _)
    {
        
    }
    private static bool HasMadness(Actor actor, string _)
    {
        return actor.hasTrait("madness") || actor.hasStatus(Statuses.limited_madness.id);
    }

    private static void addition_stats(Actor actor_base)
    {
        bool stoic = actor_base.a.hasTrait(Traits.final_resilience.id);
        bool has_overwrite_stats = actor_base.a.HasOverwriteStats();
        if (!has_overwrite_stats)
        {
            var level = actor_base.a.GetCultisysLevel();
            if (level >= 0) actor_base.stats.mergeStats(Cultisys.LevelStats[level]);

            foreach (var trait in actor_base.traits)
            {
                TraitExtend trait_extend = trait.GetExtend();
                BaseStats conditional_stats = trait_extend.conditional_basestats?.Invoke(actor_base.a);
                if (conditional_stats != null) actor_base.stats.mergeStats(conditional_stats);
            }
        }

        if (stoic)
        {
            actor_base.stats._tags.Remove("immovable");
            actor_base.stats._tags.Remove("frozen_ai");
            actor_base.stats._tags.Remove("stop_idle_animation");
        }
        if (!actor_base.hasAnyStatusEffect()) return;
        foreach (var status_data in actor_base._active_status_dict.Values)
        {
            StatusExtend status_extend = status_data.asset.GetExtend();
            if (status_data.asset.id == Statuses.stoic.id) stoic = true;
            if (!has_overwrite_stats)
            {
                BaseStats conditional_stats = status_extend.conditional_basestats?.Invoke(actor_base.a);
                if (conditional_stats    != null) actor_base.stats.mergeStats(conditional_stats);
            }
        }

        if (stoic)
        {
            actor_base.stats._tags.Remove("immovable");
            actor_base.stats._tags.Remove("frozen_ai");
            actor_base.stats._tags.Remove("stop_idle_animation");
        }
    }

    private static void post_stats(Actor actor_base)
    {
        BaseStats overwrite_stats = actor_base.a.GetOverwriteStats();
        if (overwrite_stats != null)
        {
            actor_base.stats.clear();
            actor_base.stats.mergeStats(overwrite_stats);
            return;
        }
        foreach (var trait in actor_base.traits)
        {
            TraitExtend trait_extend = trait.GetExtend();
            if (trait_extend.final_basestats == null) continue;
            actor_base.stats.ApplyMods(trait_extend.final_basestats);
        }

        if (actor_base._active_status_dict != null)
            foreach (var status_data in actor_base._active_status_dict.Values)
            {
                StatusExtend status_extend = status_data.asset.GetExtend();
                if (status_extend.final_basestats == null) continue;
                actor_base.stats.ApplyMods(status_extend.final_basestats);
            }

        foreach (var trait in actor_base.traits)
        {
            TraitExtend trait_extend = trait.GetExtend();
            if (trait_extend.final_basestats != null)
            {
                actor_base.stats.mergeStats(trait_extend.final_basestats);
            }

            if (trait_extend.final_conditional_basestats != null)
            {
                var stats = trait_extend.final_conditional_basestats(actor_base.a);
                actor_base.stats.mergeStats(stats);
            }
        }

        if (actor_base._active_status_dict != null)
            foreach (var status_data in actor_base._active_status_dict.Values)
            {
                StatusExtend status_extend = status_data.asset.GetExtend();
                if (status_extend.final_basestats == null) continue;
                actor_base.stats.mergeStats(status_extend.final_basestats);
            }
    }
    [HarmonyPostfix, HarmonyPatch(typeof(BatchActors), nameof(BatchActors.u8_checkUpdateTimers))]
    private static void BatchActors_updateTimers_postfix(BatchActors __instance)
    {
        if (!__instance.check(__instance._cur_container))
        {
            return;
        }
        var elapsed = __instance._elapsed;
        foreach (var a in __instance._array)
        {
            if (a?.data == null || a.traits == null || !a.isAlive()) return;
            Actor_u9_checkUpdateTimers_postfix(a, elapsed);
        }
        //Parallel.ForEach(__instance._array, a => Actor_u9_checkUpdateTimers_postfix(a, elapsed));
    }
    //[HarmonyPostfix, Hotfixable]
    //[HarmonyPatch(typeof(Actor), nameof(Actor.updateParallelChecks))]
    private static void Actor_u9_checkUpdateTimers_postfix(Actor __instance, float pElapsed)
    {
        if (Randy.randomChance(0.1f))
        {
            foreach (var trait in __instance.traits)
            {
                if (trait.GetExtend().conditional_basestats != null) __instance.setStatsDirty();

                if (!trait.GetExtend().HasCooldown) continue;
                __instance.DecreaseCooldown(trait.id, pElapsed);
            }
            if (__instance._active_status_dict != null)
            {
                foreach (var status_data in __instance._active_status_dict.Values)
                {
                    StatusExtend status_extend = status_data.asset.GetExtend();
                    if (status_extend.conditional_basestats != null) __instance.setStatsDirty();
                }
            }
            
            var mana_regen = __instance.stats["inmny.custommodt001.mana_regen"] * pElapsed;
            if (mana_regen < 1)
            {
                if (Randy.randomChance(mana_regen))
                {
                    mana_regen = 1;
                }
            }
            __instance.RestoreMana(mana_regen);
        }
        if (!__instance.HasShield()) return;
        var shields = __instance.GetShields();
        if (shields.Count == 0) return;
        for (var i = 0; i < shields.Count; i++)
        {
            ShieldData shield = shields[i];
            shield.left_time -= pElapsed;
            if (shield.left_time <= 0 || shield.value <= 0)
            {
                shields.RemoveAt(i);
                i--;
            }
            else
            {
                shields[i] = shield;
            }
        }

        __instance.UpdateShields(shields);
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), nameof(Actor.getHit))]
    private static bool Actor_getHit_prefix(Actor __instance, ref float pDamage, ref AttackType pAttackType,
                                            BaseSimObject pAttacker)
    {
        if (pAttacker != null && pAttacker.isActor())
        {
            var a = pAttacker.a;
            if (a.hasTrait(Traits.war_ashes.id) && a.GetWarAshesCount() > 100) pAttackType = AttackType.None;
            if (a.hasTrait(Traits.steel_heart.id)) a.IncSteelHeartCount();

            if (a.hasTrait(Traits.illuminated_glory.id))
                if (a.GetLastAttackTime() + 10 < World.world.getCurWorldTime())
                    pAttackType = AttackType.None;

            if (a.hasTrait(Traits.final_power.id)) pAttackType = AttackType.None;
            if ((a.hasTrait(Traits.survival_of_civilization.id) ||
                 a.asset.id.StartsWith($"{ModClass.asset_id_prefix}.demon_king")) &&
                __instance.hasTrait(Traits.survival_of_civilization.id))
            {
                pDamage = 0;
            }

            var weapon = a.getWeapon();
            if (weapon is { data: { asset_id: "sword", material: "wood", name: "灵剑" } } &&
                __instance.hasStatus(Statuses.active_spirit_sword.id))
            {
                pDamage = 0;
            }

            if (a.GetCultisysLevel() >= 5)
            {
                pDamage *= 100f / (100 - Cultisys.LevelStats[__instance.GetCultisysLevel()][Stats.addition_armor.id]);
            }
        }

        if (pAttacker != null && pAttackType != AttackType.None)
            if (Randy.randomChance(0.01f * __instance.stats[Stats.dodge.id]))
                return false;

        if (pAttacker?.isActor() ?? false) pAttacker.a.SetLastAttackTime((float)World.world.getCurWorldTime());

        if (pAttackType == AttackType.None) return true;
        pDamage *= 1 - __instance.stats[Stats.addition_armor.id] / 100;
        return true;
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(Actor), nameof(Actor.newKillAction))]
    private static void Actor_newKillAction_postfix(Actor __instance, Actor pDeadUnit)
    {
        __instance.IncExp(1000+ModConfigHelper.GetKillExpK() * pDeadUnit.GetExp());
        if (__instance.hasTrait(Traits.meat_eater.id))
            __instance.restoreHealth((int)(__instance.stats[S.health] * 0.01f));
        if (__instance.hasTrait(Traits.summoner.id))
        {
            if (__instance.GetSummonCount(Traits.summoner.id) < 100)
            {
                var new_actor =
                    World.world.units.spawnNewUnit(Actors.skeleton_summoned.id, pDeadUnit.current_tile, true, pSpawnHeight:0);
                if (new_actor != null)
                {
                    var stats = new BaseStats();
                    foreach (var s in __instance.stats._stats_list)
                    {
                        stats[s.id] = s.value * 0.1f;
                    }
                    new_actor.OverwriteStats(stats);
                    new_actor.event_full_stats = true;
                    new_actor.SetSummonSource(Traits.summoner.id);
                    new_actor.SetOwner(__instance);
                }
            }
        }
        else if (__instance.hasTrait(Traits.summoned.id))
        {
            var owner = __instance.GetOwner();
            if (owner != null && owner.hasTrait(Traits.summoner.id) && owner.GetSummonCount(Traits.summoner.id) < 100)
            {
                var new_actor =
                    World.world.units.spawnNewUnit(Actors.skeleton_summoned.id, pDeadUnit.current_tile, true, pSpawnHeight:0);
                if (new_actor != null)
                {
                    var stats = new BaseStats();
                    foreach (var s in owner.stats._stats_list)
                    {
                        stats[s.id] = s.value * 0.1f;
                    }
                    new_actor.OverwriteStats(stats);
                    new_actor.event_full_stats = true;
                    new_actor.SetSummonSource(Traits.summoner.id);
                    new_actor.SetOwner(owner);
                }
            }
        }
        if (__instance.hasTrait(Traits.puppetry_master.id) && __instance.GetSummonCount(Traits.puppetry_master.id) < 5)
        {
            Actor new_actor = World.world.units.spawnNewUnit(pDeadUnit.a.asset.id, pDeadUnit.current_tile, true, pSpawnHeight:0);
            if (new_actor != null)
            {
                ActorTool.copyUnitToOtherUnit(pDeadUnit.a, new_actor);
                new_actor.traits.Clear();
                new_actor.addTrait(Traits.summoned);
                new_actor.SetSummonSource(Traits.puppetry_master.id);
                new_actor.SetOwner(__instance);
                var stats = new BaseStats();
                stats.mergeStats(pDeadUnit.stats);
                stats[S.health] *= 0.5f;
                stats[S.damage] *= 0.5f;
                new_actor.OverwriteStats(stats);
            }
        }

        if (__instance.hasTrait(Traits.mysterious_mage.id) && __instance.GetSummonCount(Traits.mysterious_mage.id) < 5)
        {
            Actor new_actor = World.world.units.spawnNewUnit(pDeadUnit.a.asset.id, pDeadUnit.current_tile, true, pSpawnHeight:0);
            if (new_actor != null)
            {
                ActorTool.copyUnitToOtherUnit(pDeadUnit.a, new_actor);
                new_actor.addTrait(Traits.summoned);
                new_actor.SetSummonSource(Traits.mysterious_mage.id);
                new_actor.SetOwner(__instance);
            }
        }

        if (__instance.HasUndeadWarGodTriggerd() && __instance.hasTrait(Traits.loong_heart.id))
        {
            var count = __instance.IncreaseUndeadWarGodCount();
            if (count >= 10)
            {
                __instance.RemoveUndeadWarGodTrigger();
            }
        }
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), nameof(Actor.die))]
    private static bool Actor_killHimself(Actor __instance, bool pLaunchCallbacks)
    {
        if (!__instance.isAlive()) return true;
        __instance.DecOwnerSummonSource();
        if (!pLaunchCallbacks) return true;
        Actor owner = __instance.GetOwner();
        if (owner != null)
            if (owner.hasTrait(Traits.unrepentant_refactoring.id))
            {
                var half_edge = 1;
                var x = __instance.current_tile.x;
                var y = __instance.current_tile.y;
                for (var i = -half_edge; i <= half_edge; i++)
                for (var j = -half_edge; j <= half_edge; j++)
                {
                    WorldTile tile = World.world.GetTile(x + i, y + j);
                    if (tile == null) continue;
                    var list = tile._units;
                    for (var k = 0; k < list.Count; k++)
                    {
                        Actor unit = list[k];
                        if (unit == null || !unit.isAlive()) continue;
                        if (__instance.kingdom?.isEnemy(unit.kingdom) ?? true)
                            __instance.ApplyStatusEffectTo(unit, Statuses.dizzy.id, 50, true);
                    }
                }
            }
        
        // 时光之终末
        if (__instance.hasTrait(Traits.end_of_time.id) )
        {
            var chance = 0.8f;
            if (__instance.hasTrait(Traits.undead_war_god.id) || __instance.hasTrait(Traits.self_destruct.id) ||
                __instance.hasTrait(Traits.doppelganger.id))
            {
                chance = 0.9f;
            }
            if (Randy.randomChance(chance))
            {
                __instance.data.health = __instance.getMaxHealth();
                if (__instance.hasTrait(Traits.undead_war_god.id))
                {
                    if (__instance.hasTrait(Traits.loong_heart.id))
                    {
                        __instance.addStatusEffect(Statuses.active_undead_war_god.id, 90);
                    }
                    else
                    {
                        __instance.addStatusEffect(Statuses.active_undead_war_god.id);
                    }
                }

                if (__instance.hasTrait(Traits.self_destruct.id))
                {
                    Traits.self_destruct.action_death(__instance, __instance.current_tile);
                }

                if (__instance.hasTrait(Traits.doppelganger.id))
                {
                    Traits.doppelganger.action_death(__instance, __instance.current_tile);
                }

                return false;
            }
        }

        // 亡灵战神
        if (__instance.hasTrait(Traits.undead_war_god.id) && !__instance.HasUndeadWarGodTriggerd())
        {
            if (__instance.hasTrait(Traits.loong_heart.id))
            {
                __instance.addStatusEffect(Statuses.active_undead_war_god.id, 90);
            }
            else
            {
                __instance.addStatusEffect(Statuses.active_undead_war_god.id);
            }
            
            __instance.event_full_stats = true;
            __instance.SetUndeadWarGodTriggerd();
            __instance.updateStats();
            return false;
        }

        // 春秋蝉
        /*
        if (__instance.hasTrait(Traits.age_cicada.id) && !__instance.TraitUnderCooldown(Traits.age_cicada.id))
        {
            __instance.ResetExp();
            __instance.ResetTalent();
            __instance.ResetCultisysLevel();
            __instance.finishAllStatusEffects();
            __instance.AddInvincible(20);
            __instance.StartCooldown(Traits.age_cicada);
            return false;
        }*/
        // 二重身是真正死后触发

        return true;
    }

    private static float calc_shield(Actor actor, BaseSimObject attacker, AttackType type, float damage)
    {
        if (type == AttackType.None) return damage;
        var shields = actor.GetShields();
        for (var i = 0; i < shields.Count; i++)
        {
            ShieldData shield = shields[i];
            if (shield.value > damage)
            {
                shield.value -= damage;
                shields[i] = shield;
                damage = 0;
                break;
            }

            damage -= shield.value;
            shields.RemoveAt(i);
            i--;
        }

        actor.UpdateShields(shields);
        if (actor.hasTrait(Traits.defence_stilling.id) || (attacker != null && attacker.isActor() && attacker.a.hasTrait(Traits.attack_stilling.id)))
        {
            damage = Mathf.Min(damage, actor.stats[S.health] * 0.1f);
        }
        return damage;
    }

    [HarmonyTranspiler]
    [HarmonyPatch(typeof(Actor), nameof(Actor.getHit))]
    private static IEnumerable<CodeInstruction> Actor_getHit_transpiler(IEnumerable<CodeInstruction> codes)
    {
        var list = codes.ToList();
#if CULTIWAY
#else
        for (var i = 1; i < list.Count; i++)
        {
            CodeInstruction ldc = list[i - 1];
            CodeInstruction starg = list[i];
            if (ldc.opcode == OpCodes.Ldc_R4 && starg.opcode == OpCodes.Starg_S)
            {
                ldc.operand = 0.0f;
                break;
            }
        }
#endif
        for (var i = 1; i < list.Count; i++)
        {
            CodeInstruction mul = list[i - 1];
            CodeInstruction starg = list[i];
            if (mul.opcode == OpCodes.Mul && starg.opcode == OpCodes.Starg_S)
            {
                var insert_idx = i + 1;
                CodeInstruction old_code = list[insert_idx];
                list.InsertRange(insert_idx, new[]
                {
                    new CodeInstruction(OpCodes.Ldarg_0),
                    new CodeInstruction(OpCodes.Ldarg_S, 4),
                    new CodeInstruction(OpCodes.Ldarg_3),
                    new CodeInstruction(OpCodes.Ldarg_S, 1),
                    new CodeInstruction(OpCodes.Call,    AccessTools.Method(typeof(Patches), nameof(calc_shield))),
                    new CodeInstruction(OpCodes.Starg_S, 1)
                });
                old_code.MoveLabelsTo(list[insert_idx]);
                break;
            }
        }

        for (var i = 0; i < list.Count - 1; i++)
        {
            CodeInstruction ldc = list[i];
            CodeInstruction stfld = list[i + 1];
            if (ldc.opcode                          == OpCodes.Ldc_R4 && stfld.opcode == OpCodes.Stfld &&
                (stfld.operand as MemberInfo)?.Name == nameof(Actor.timer_action))
            {
                ldc.operand = 0.0f;
                break;
            }
        }

        var life_steal_idx = list.FindIndex(x => (x.operand as MethodInfo)?.Name == nameof(BaseSimObject.changeHealth)) + 1;
        list.InsertRange(life_steal_idx, new[]
        {
            new CodeInstruction(OpCodes.Ldarg_S, 4),
            new CodeInstruction(OpCodes.Ldarg_S, 1),
            new CodeInstruction(OpCodes.Call,    AccessTools.Method(typeof(Patches), nameof(apply_life_steal))),
            new CodeInstruction(OpCodes.Ldarg_0),
            new CodeInstruction(OpCodes.Ldarg_S, 4),
            new CodeInstruction(OpCodes.Ldarg_3),
            new CodeInstruction(OpCodes.Ldarg_S, 1),
            new CodeInstruction(OpCodes.Call,    AccessTools.Method(typeof(Patches), nameof(on_gethit_end))),
        });


        return list;
    }

    private static void on_gethit_end(Actor actor, BaseSimObject attacker, AttackType type, float damage)
    {
        if (attacker == null || !attacker.isAlive()) return;
        if (actor.hasTrait(Traits.thorn_shell.id))
        {
            EventManager.EnqueueDamageEvent(actor, attacker, actor.stats[S.damage] * 0.1f, AttackType.Other);
        }
    }
    private static void apply_life_steal(BaseSimObject attacker, float damage)
    {
        if (attacker == null || !attacker.isAlive()) return;
        var health_steal = damage * attacker.stats[Stats.life_steal.id];
        if (health_steal > 0)
        {
            if (attacker.isActor())
            {
                attacker.a.restoreHealth((int)health_steal);
            }
            else
            {
                attacker.getData().health += (int)health_steal;
            }
        }
        if (attacker.isActor())
        {
            var a = attacker.a;
            var owner = a.GetOwner();
            if (owner != null && owner.hasTrait(Traits.empty_feathered.id))
            {
                owner.restoreHealth((int)(damage * 0.05f));
            }
        }
    }

    [HarmonyPostfix, Hotfixable]
    [HarmonyPatch(typeof(Actor), nameof(Actor.updateAge))]
    private static void Actor_updateAge_postfix(Actor __instance)
    {
        if (__instance.hasTrait(Traits.sign_in.id) && !__instance.TraitUnderCooldown(Traits.sign_in.id))
        {
            __instance.StartCooldown(Traits.sign_in);
            var traits = Traits.all_enabled_traits.Except(__instance.traits.Select(x=>x.id)).ToList();
            if (traits.Count > 0)
            {
                var trait_to_give = traits.GetRandom();
                __instance.addTrait(trait_to_give, true);
            }
        }
        if (__instance.hasTrait(Traits.summoned.id)) return;
        var level = __instance.GetCultisysLevel();
        if (level >= Cultisys.MaxLevel) return;
        var talent = __instance.GetTalent();
        __instance.IncExp(talent * ModConfigHelper.GetTalentMultiplier());
        if (__instance.GetExp() >= Cultisys.LevelExpRequired[level])
        {
            __instance.LevelUp();
            __instance.ResetExp();
        }
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(ActorTraitButton), nameof(ActorTraitButton.tooltipDataBuilder))]
    private static void ActorTraitButton_tooltipDataBuilder_postfix(ActorTraitButton __instance,
        ref TooltipData __result)
    {
        string appended_text = append_text(__instance);
        if (string.IsNullOrEmpty(appended_text)) return;
        __result.tip_description_2 += '\n' + appended_text;
    }
    [Hotfixable]
    private static string append_text(ActorTraitButton trait_button)
    {
        if (SelectedUnit.unit == null) return null;
        ActorTrait trait = trait_button.augmentation_asset;
        TraitExtend trait_extend = trait.GetExtend();

        string text = null;
        if (trait.id == Traits.final_skill.id)
        {
            if (SelectedUnit.unit.HasFinalSkill())
            {
                var skill = SelectedUnit.unit.GetFinalSkill();
                text += $"\n契合特质: {LM.Get("trait_" + skill)}";
            }
        }
        if (trait.id == Traits.summoned.id)
        {
            var owner_name = SelectedUnit.unit.GetOwner()?.getName() ?? "已死亡";
            text = $"所有者: {owner_name}";
        }

        if (!trait_extend.HasCooldown) return text;
        var cooldown = SelectedUnit.unit.GetCooldown(trait.id);
        if (text == null)
            text = $"冷却: {cooldown:F1}s";
        else
            text += $"\n冷却: {cooldown:F1}s";

        return text;
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(TooltipLibrary), nameof(TooltipLibrary.showActor))]
    private static void TooltipLibrary_showActor_postfix(Tooltip pTooltip, TooltipData pData)
    {
        pTooltip.addLineBreak();

        pTooltip.addLineText($"{ModClass.asset_id_prefix}.ui.cultilevel",
            Cultisys.GetName(pData.actor.GetCultisysLevel()));
        pTooltip.addLineText($"{ModClass.asset_id_prefix}.ui.talent", ((int)pData.actor.GetTalent()).ToString());
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(TooltipLibrary), nameof(TooltipLibrary.showTrait))]
    private static void TooltipLibrary_showTrait_transpiler(Tooltip pTooltip, TooltipData pData)
    {
        append_trait_stats(pTooltip, pData.trait, pData);
    }

    private static void append_trait_stats(Tooltip tooltip, ActorTrait trait, TooltipData data)
    {
        if (SelectedUnit.unit == null)
        {
            BaseStatsHelper.showBaseStats(tooltip.stats_description, tooltip.stats_values, trait.base_stats, false);
            return;
        }

        TraitExtend trait_extend = trait.GetExtend();

        BaseStats conditional_stats = trait_extend.conditional_basestats?.Invoke(SelectedUnit.unit);
        if (conditional_stats != null && conditional_stats._stats_list.Count > 0)
        {
            if  (tooltip.stats_description.text.Length > 0)
                BaseStatsHelper.addLineBreak(tooltip.stats_description, tooltip.stats_values);
            BaseStatsHelper.addStatValues(tooltip.stats_description, tooltip.stats_values, "额外加成:", "");
            BaseStatsHelper.showBaseStats(tooltip.stats_description, tooltip.stats_values, conditional_stats);
        }

        var final_stats = trait_extend.final_basestats;
        if (final_stats != null && final_stats._stats_list.Count > 0)
        {
            if  (tooltip.stats_description.text.Length > 0)
                BaseStatsHelper.addLineBreak(tooltip.stats_description, tooltip.stats_values);
            BaseStatsHelper.addStatValues(tooltip.stats_description, tooltip.stats_values, "最终加成:", "");
            BaseStatsHelper.showBaseStats(tooltip.stats_description, tooltip.stats_values, final_stats);
        }

        if (string.IsNullOrEmpty(data.tip_description_2)) return;
        tooltip.addDescription("\n");
        tooltip.addDescription(data.tip_description_2);
    }

    [HarmonyPostfix]
    [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
    private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
    {
        if (__instance.actor == null || !__instance.actor.isAlive()) return;
        if (!window_creature_info_initialized)
        {
            __instance.StartCoroutine(new WaitUntil(() =>
            {
                if (UnitWindowHelper.Initialize(__instance))
                {
                    window_creature_info_initialized = true;
                }

                return window_creature_info_initialized;
            }));
        }
    }
/*
    [HarmonyPostfix]
    [HarmonyPatch(typeof(TraitsContainer<ActorTrait, ActorTraitButton>), nameof(ActorTraitsContainer.loadActiveTrait))]
    private static void WindowCreatureInfo_loadTraitButton_prefix(TraitsContainer<ActorTrait, ActorTraitButton> __instance, ActorTrait pTraitAsset)
    {
        if (Traits.all_traits.Contains(pTraitAsset.id))
        {
            __instance._traits[pTraitAsset].gameObject.SetActive(false);
        }
    }
*/
    [HarmonyPrefix]
    [HarmonyPatch(typeof(CombatActionLibrary), nameof(CombatActionLibrary.attackRangeAction))]
    private static bool CombatActionLibrary_attackRangeAction_prefix(ref AttackData pData, ref bool __result)
    {
        __result = false;
        return AssetManager.projectiles.dict.ContainsKey(pData.initiator.a.getWeaponAsset().projectile);
    }
    [HarmonyTranspiler, HarmonyPatch(typeof(Actor), nameof(Actor.u7_checkAugmentationEffects))]
    private static IEnumerable<CodeInstruction> Actor_u7_checkTraitEffects(IEnumerable<CodeInstruction> codes)
    {
        var list = new List<CodeInstruction>(codes);

        list[3].opcode = OpCodes.Nop;

        return list;
    }
}