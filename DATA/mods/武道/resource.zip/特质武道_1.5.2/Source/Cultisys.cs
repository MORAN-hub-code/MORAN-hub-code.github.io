using System;
using System.Collections.ObjectModel;
using NeoModLoader.General;
using strings;

namespace CustomModT001;

public static class Cultisys
{
    public const            int         MaxLevel = 6;
    private static readonly BaseStats[] _level_stats;
    private static readonly float[]     _level_exp_required;

    private static readonly string[] _traits_blacklist =
    {
        "eyepatch", "crippled", "cursed", "tumorInfection", "mushSpores", "plague", "skin_burns"
    };

    private static readonly string[] _statuses_blacklist =
    {
        "cough", "ash_fever"
    };

    static Cultisys()
    {
        _level_stats = new BaseStats[MaxLevel + 1];
        _level_exp_required = new float[MaxLevel];
        for (var i = 0; i <= MaxLevel; i++) _level_stats[i] = new BaseStats();

        _level_exp_required[0] = 350;
        _level_exp_required[1] = 700;
        _level_exp_required[2] = 1400;
        _level_exp_required[3] = 5600;
        _level_exp_required[4] = 600000;
        _level_exp_required[5] = 6000000;
        LevelExpRequired = new ReadOnlyCollection<float>(_level_exp_required);
        LevelStats = new ReadOnlyCollection<BaseStats>(_level_stats);

        BaseStats stats = _level_stats[0];
        stats[S.mana] = 40;
        stats[Stats.mana_regen.id] = 0.5f;


        stats = _level_stats[1];
        stats[S.mana] = 50;
        stats[Stats.mana_regen.id] = 1;
        stats[S.health] = 200;
        stats[S.damage] = 40;


        stats = _level_stats[2];
        stats[S.mana] = 60;
        stats[Stats.mana_regen.id] = 1;
        stats[S.health] = 400;
        stats[S.damage] = 60;
        stats[S.lifespan] = 25;


        stats = _level_stats[3];
        stats[S.mana] = 100;
        stats[Stats.mana_regen.id] = 2;
        stats[S.health] = 1000;
        stats[S.damage] = 100;
        stats[S.speed] = 40;
        stats[S.lifespan] = 100;


        stats = _level_stats[4];
        stats[S.mana] = 400;
        stats[Stats.mana_regen.id] = 4;
        stats[S.health] = 10000;
        stats[S.damage] = 200;
        stats[S.speed] = 40;
        stats[S.lifespan] = 800;


        stats = _level_stats[5];
        stats[Stats.addition_armor.id] = 50;
        stats[Stats.control_get.id] = -0.5f;
        stats[S.mana] = 2000;
        stats[Stats.mana_regen.id] = 100;
        stats[S.health] = 100000;
        stats[S.damage] = 1000;
        stats[S.speed] = 40;
        stats[S.lifespan] = 5000;


        stats = _level_stats[6];
        stats[Stats.addition_armor.id] = 75;
        stats[Stats.control_get.id] = -0.8f;
        stats[S.mana] = 40000;
        stats[Stats.mana_regen.id] = 500;
        stats[S.health] = 500000;
        stats[S.damage] = 2000;
        stats[S.speed] = 80;
        stats[S.lifespan] = 100000;
        stats[S.knockback_reduction] = 10000;
    }

    public static ReadOnlyCollection<BaseStats> LevelStats       { get; }
    public static ReadOnlyCollection<float>     LevelExpRequired { get; }

    public static ReadOnlyCollection<string> TraitsBlacklist { get; } = new(_traits_blacklist);

    public static ReadOnlyCollection<string> StatusesBlacklist { get; } = new(_statuses_blacklist);

    public static string GetName(int level)
    {
        level = Math.Min(MaxLevel, Math.Max(level, 0));
        return LM.Get($"{ModClass.asset_id_prefix}.wudao.{level}");
    }
}