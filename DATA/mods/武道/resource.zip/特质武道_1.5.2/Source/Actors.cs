using CustomModT001.Abstract;
using strings;

namespace CustomModT001;

public class Actors : ExtendLibrary<ActorAsset, Actors>
{
    [CloneSource(nameof(SA.skeleton))] public static ActorAsset skeleton_summoned { get; private set; }
    [CloneSource(nameof(SA.cold_one))]public static ActorAsset ice_demon_summoned { get; private set; }
    [CloneSource(nameof(SA.demon))] public static ActorAsset demon_summoned { get; private set; }
    [CloneSource(nameof(SA.demon))] public static ActorAsset demon_king_1   { get; private set; }
    [CloneSource(nameof(SA.demon))] public static ActorAsset demon_king_2   { get; private set; }
    [CloneSource(nameof(SA.demon))] public static ActorAsset demon_king_3   { get; private set; }
    [CloneSource(nameof(SA.demon))] public static ActorAsset demon_king_4   { get; private set; }

    protected override void OnInit()
    {
        RegisterAssets(ModClass.asset_id_prefix);

        skeleton_summoned.traits.Add(Traits.summoned.id);
        skeleton_summoned.base_stats[S.health] = 5000;
        skeleton_summoned.base_stats[S.damage] = 50;
        skeleton_summoned.traits.Remove("immortal");
        skeleton_summoned.base_stats[S.lifespan] = 25;
        skeleton_summoned.job = [ActorJobs.summoned_job.id];
        
        ice_demon_summoned.traits.Add(Traits.summoned.id);
        ice_demon_summoned.traits.Remove("cold_aura");
        ice_demon_summoned.base_stats[S.health] = 4500;
        ice_demon_summoned.base_stats[S.damage] = 400;
        ice_demon_summoned.base_stats[S.armor] = 80;
        ice_demon_summoned.traits.Remove("immortal");
        ice_demon_summoned.base_stats[S.lifespan] = 25;
        ice_demon_summoned.job = [ActorJobs.summoned_job.id];

        demon_summoned.traits.Remove("burning_feet");
        demon_summoned.traits.Add(Traits.summoned.id);
        demon_summoned.base_stats[S.health] = 4500;
        demon_summoned.base_stats[S.damage] = 10;
        demon_summoned.base_stats[S.armor] = 80;
        demon_summoned.traits.Remove("immortal");
        demon_summoned.base_stats[S.lifespan] = 25;
        demon_summoned.job = [ActorJobs.summoned_job.id];

        SetupDemonKing(demon_king_1, Traits.undead_war_god);
        SetupDemonKing(demon_king_2, Traits.cyan_fury);
        SetupDemonKing(demon_king_3, Traits.end_of_time);
        SetupDemonKing(demon_king_4, Traits.mercy_lighthouse);
    }

    private void SetupDemonKing(ActorAsset asset, ActorTrait given_trait)
    {
        asset.traits.Remove("burning_feet");
        asset.traits.Add(Traits.summoned.id);
        asset.traits.Add(given_trait.id);
        asset.base_stats[S.health] = 1000000;
        asset.base_stats[S.damage] = 4000;
        asset.base_stats[S.attack_speed] = 50;
        asset.name_locale = asset.id;
        asset.traits.Remove("immortal");
        asset.base_stats[S.lifespan] = 25;
    }

    protected override ActorAsset Add(ActorAsset asset)
    {
        base.Add(asset);
        if (asset.shadow) AssetManager.actor_library.loadShadow(asset);

        return asset;
    }

    protected override ActorAsset Clone(string new_id, string from_id)
    {
        ActorAsset asset = base.Clone(new_id, from_id);
        if (asset.shadow) AssetManager.actor_library.loadShadow(asset);

        return asset;
    }
}