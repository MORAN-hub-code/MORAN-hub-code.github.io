using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ai;
using NeoModLoader.api.attributes;
using NeoModLoader.api; 
using NeoModLoader.General;

namespace avbultratraitspack{
    internal static class StatusesActions{
        public static bool bleedingEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (!pTarget.isActor())
            {
                return false;
            }
            int tDamage = pTarget.getMaxHealthPercent(0.05f);
            pTarget.getHit((float)tDamage, true, AttackType.None, null, true, false, true);
            return true;
        }
    }
}