using System;
// using System.IO;
// using System.Text;
// using System.Reflection;
// using System.Collections;
// using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;

namespace avbultratraitspack{
    internal static class CreatureDeathActions{
        public static bool alienSlayer(BaseSimObject pTarget, WorldTile pTile = null)
	    {
	    	if (pTarget == null || !pTarget.isActor())
	    	{
	    		return false;
	    	}
	    	BaseSimObject attackedBy = pTarget.a.attackedBy;
	    	if (attackedBy != null && attackedBy.isActor() && attackedBy.isAlive())
	    	{
	    		attackedBy.a.addTrait("Alien Slayer", false);
	    		return true;
	    	}
	    	return false;
	    }
        public static bool bugSlayer(BaseSimObject pTarget, WorldTile pTile = null)
	    {
	    	if (pTarget == null || !pTarget.isActor())
	    	{
	    		return false;
	    	}
	    	BaseSimObject attackedBy = pTarget.a.attackedBy;
	    	if (attackedBy != null && attackedBy.isActor() && attackedBy.isAlive())
	    	{
	    		attackedBy.a.addTrait("Bug Slayer", false);
	    		return true;
	    	}
	    	return false;
	    }
		public static bool demonSlayer(BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (pTarget == null || !pTarget.isActor())
		    {
				return false;
		    }
		    BaseSimObject attackedBy = pTarget.a.attackedBy;
		    if (attackedBy != null && attackedBy.isActor() && attackedBy.isAlive())
		    {
		    	attackedBy.a.addTrait("Demon Slayer", false);
		    	return true;
		    }
		    return false;
	    }
		public static bool coldSlayer(BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (pTarget == null || !pTarget.isActor())
		    {
				return false;
		    }
		    BaseSimObject attackedBy = pTarget.a.attackedBy;
		    if (attackedBy != null && attackedBy.isActor() && attackedBy.isAlive())
		    {
		    	attackedBy.a.addTrait("Cold Slayer", false);
		    	return true;
		    }
		    return false;
	    }
    }
}
