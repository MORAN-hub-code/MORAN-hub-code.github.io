using System;
// using System.IO;
// using System.Text;
// using System.Reflection;
// using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;
using ai;

namespace avbultratraitspack{
    internal static class TraitDeathActions{
//Replicative Immortality-------------------------------------------------------------------------------------------------------
        public static bool replicateNow(Actor pTarget, string pAsset, bool pRemoveAcquiredTraits = false, bool pUseCurrentSubspecies = false)
	    {
			if (pTarget == null)
			{
				return false;
			}
			if (!pTarget.inMapBorder())
			{
				return false;
			}
			// if (pTarget.isAlreadyTransformed())
			// {
			// 	return false;
			// }
			pTarget.finishStatusEffect("cursed");
			pTarget.removeTrait("infected");
			pTarget.removeTrait("mush_spores");
			pTarget.removeTrait("tumor_infection");
			Subspecies tPreviousSubspecies = null;
			if (pUseCurrentSubspecies)
			{
				tPreviousSubspecies = pTarget.subspecies;
			}
			Actor tNewUnit = World.world.units.createNewUnit(pAsset, pTarget.current_tile, false, 0f, tPreviousSubspecies, null, false, false, false);
			ActorTool.copyUnitToOtherUnit(pTarget, tNewUnit, false);
			EffectsLibrary.spawn("fx_spawn", tNewUnit.current_tile, null, null, 0f, -1f, -1f, null);
			ActionLibrary.removeUnit(pTarget);
			//pTarget.setTransformed();
			return true;
	    }
//Blood Traits-------------------------------------------------------------------------------------------------------
    	public static bool deathBloodEffect(BaseSimObject pTarget, WorldTile pTile = null, string dropID = "blood_rain"){
			for (int i = 0; i < 5; i++)
			{
				if (Randy.randomBool())
				{
					World.world.drop_manager.spawnParabolicDrop(pTarget.a.current_tile, dropID, 0f, 0.1f, 5f, 0.5f, 4f, 0.15f);
				}
			}
			if (!pTarget.isActor())
			{
				return true;
			}
			if (pTarget.a.asset.actor_size < ActorSize.S17_Dragon)
			{
				return true;
			}
			for (int j = 0; j < 25; j++)
			{
				if (Randy.randomBool())
				{
					World.world.drop_manager.spawnParabolicDrop(pTarget.a.current_tile, dropID, 0f, 0.1f, 10f, 0.5f, 10f, 0.15f);
				}
				for (int k = 0; k < pTarget.a.current_tile.neighboursAll.Length; k++)
				{
					WorldTile pTile2 = pTarget.a.current_tile.neighboursAll[k];
					if (Randy.randomBool())
					{
						World.world.drop_manager.spawnParabolicDrop(pTile2, dropID, 0f, 0.1f, 10f, 0.5f, 7f, 0.15f);
					}
				}
			}
			return true;
		}
//Death Bomb & Monolithic-------------------------------------------------------------------------------------------------------
        public static bool deathGrenadeBomb(BaseSimObject pTarget, WorldTile pTile = null){
		    pTarget.a.findCurrentTile(true);
		    DropsLibrary.action_grenade(pTarget.current_tile, null);
		    return true;
	    }//end of grenade
        public static bool deathNapalmBomb(BaseSimObject pTarget, WorldTile pTile = null){
		    pTarget.a.findCurrentTile(true);
		    DropsLibrary.action_napalm_bomb(pTarget.current_tile, null);
		    return true;
	    }//end of napalm
        public static bool deathTsarbomba(BaseSimObject pTarget, WorldTile pTile = null){
		    pTarget.a.findCurrentTile(true);
		    DropsLibrary.action_czar_bomba(pTarget.current_tile, null);
		    return true;
	    }//end of tsar
        public static bool deathAntimatterBomb(BaseSimObject pTarget, WorldTile pTile = null){
		    pTarget.a.findCurrentTile(true);
		    DropsLibrary.action_antimatter_bomb(pTarget.current_tile, null);
		    return true;
	    }//end of antimatter   
        public static bool deathCrabBomb(BaseSimObject pTarget, WorldTile pTile = null){
		    pTarget.a.findCurrentTile(true);
		    DropsLibrary.action_crab_bomb_shrapnel(pTarget.current_tile, null);
		    return true;
	    }//end of crab
        public static bool deathMonoMark(BaseSimObject pTarget, WorldTile pTile = null){
            pTarget.a.findCurrentTile(true);
            DropsLibrary.action_spawn_building(pTarget.current_tile, "monolith");
            return true;
        }//end of monolith
//Morph-------------------------------------------------------------------------------------------------------
		public static bool specialMorphIntoMage(Actor pTarget, bool pRemoveAcquiredTraits = false, bool pUseCurrentSubspecies = false)
		{
			List<string> mageListCustom = new List<string>{"evil_mage","white_mage","druid","necromancer","plague_doctor"};
    	    System.Random rnd = new System.Random();
    	    int selectedMage = rnd.Next(mageListCustom.Count);
			if (pTarget == null)
			{
				return false;
			}
			if (!pTarget.inMapBorder())
			{
				return false;
			}
			if (pTarget.isAlreadyTransformed())
			{
				return false;
			}
			pTarget.finishStatusEffect("cursed");
			pTarget.removeTrait("infected");
			pTarget.removeTrait("mush_spores");
			pTarget.removeTrait("tumor_infection");
    	    pTarget.removeTrait("Magic Heart");
			Actor tNewUnit = World.world.units.createNewUnit(mageListCustom[selectedMage], pTarget.current_tile, false, 0f, null, null, false, false, false);
			ActorTool.copyUnitToOtherUnit(pTarget, tNewUnit, true);
			EffectsLibrary.spawn("fx_spawn", tNewUnit.current_tile, null, null, 0f, -1f, -1f, null);
			ActionLibrary.removeUnit(pTarget);
			//pTarget.setTransformed();
			return true;
		}
    	public static bool specialMorphIntoCreature(Actor pTarget, string pAsset, string removeThisTrait, bool pRemoveAcquiredTraits = false, bool pUseCurrentSubspecies = false)
		{
			if (pTarget == null)
			{
				return false;
			}
			if (!pTarget.inMapBorder())
			{
				return false;
			}
			if (pTarget.isAlreadyTransformed())
			{
				return false;
			}
			pTarget.finishStatusEffect("cursed");
			pTarget.removeTrait("infected");
			pTarget.removeTrait("mush_spores");
			pTarget.removeTrait("tumor_infection");
    	    pTarget.removeTrait(removeThisTrait);
			Actor tNewUnit = World.world.units.createNewUnit(pAsset, pTarget.current_tile, false, 0f, null, null, false, false, false);
			ActorTool.copyUnitToOtherUnit(pTarget, tNewUnit, true);
			EffectsLibrary.spawn("fx_spawn", tNewUnit.current_tile, null, null, 0f, -1f, -1f, null);
			ActionLibrary.removeUnit(pTarget);
			//pTarget.setTransformed();
			return true;
		}
    }
}
