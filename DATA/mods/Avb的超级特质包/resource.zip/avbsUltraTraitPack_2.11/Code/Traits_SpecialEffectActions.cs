using System;
// using System.IO;
// using System.Text;
// using System.Reflection;
// using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;
using ai;

namespace avbultratraitspack{
    internal static class TraitSpecialEffectActions{
//World Age Traits
    	public static bool demonChildEffect(BaseSimObject pTarget, WorldTile pTile = null){
			if (World.world_era.overlay_sun || World.world_era.overlay_chaos)
			{
				pTarget.a.addStatusEffect("awakenedDemonchild", -1f);
			}
			return false;
		}
		public static bool gloomChildEffect(BaseSimObject pTarget, WorldTile pTile = null){
			if (World.world_era.overlay_rain)
			{
				pTarget.a.addStatusEffect("awakenedGloomchild", -1f);
			}
			return false;
		}
		public static bool sparkChildEffect(BaseSimObject pTarget, WorldTile pTile = null){
			if (World.world_era.overlay_magic)
			{
				pTarget.a.addStatusEffect("awakenedSparkchild", -1f);
			}
			return false;
		}
		public static bool doomChildEffect(BaseSimObject pTarget, WorldTile pTile = null){
			if (World.world_era.overlay_ash)
			{
				pTarget.a.addStatusEffect("awakenedDoomchild", -1f);
			}
			return false;
		}
		public static bool frostChildEffect(BaseSimObject pTarget, WorldTile pTile = null){
			if (World.world_era.overlay_winter)
			{
				pTarget.a.addStatusEffect("awakenedFrostchild", -1f);
			}
			return false;
		}
//Other Special Effect Traits
        public static bool hateAuraEffect(BaseSimObject pTarget, WorldTile pTile = null)
	    {
			//Actor actor = pTarget.a;
			if (Randy.randomChance(0.2f))
			{
				foreach (Actor tActor in Finder.getUnitsFromChunk(pTile, 1, 4f, false))
				{
					if (tActor != pTarget.a && !tActor.hasMaxHealth())
					{
						if (!tActor.hasTag("strong_mind")){
							tActor.addStatusEffect("rage", -1);
						}
					}
				}
			}
		    return true;
	    }
    	public static bool highEffect(BaseSimObject pSelf, WorldTile pTile = null)
		{
        	if (Randy.randomChance(0.05f))
			{
				pSelf.a.addStatusEffect("high", -1f);
			}
        	return false;
		}
		public static bool cloneNow(BaseSimObject pTarget, WorldTile pTile = null)
	    {
			if (pTarget == null)
			{
				return false;
			}
			if (!pTarget.a.inMapBorder())
			{
				return false;
			}
			if (pTarget.a.hasTrait("clone") || pTarget.a.hasTrait("Unstable Clone"))
			{
	    		return false;
	    	}
			if(Randy.randomChance(0.95f)){
                return false;
            }
			// if (pTarget.isAlreadyTransformed())
			// {
			// 	return false;
			// }
			pTarget.finishStatusEffect("cursed");
			pTarget.a.removeTrait("infected");
			pTarget.a.removeTrait("mush_spores");
			pTarget.a.removeTrait("tumor_infection");
			pTarget.a.removeTrait("Duplicator");
			Subspecies tPreviousSubspecies = pTarget.a.subspecies;
			Actor tNewUnit = World.world.units.createNewUnit(pTarget.a.asset.id, pTarget.current_tile, false, 0f, tPreviousSubspecies, null, false, false, false);
			ActorTool.copyUnitToOtherUnit(pTarget.a, tNewUnit, false);
			EffectsLibrary.spawn("fx_spawn", tNewUnit.current_tile, null, null, 0f, -1f, -1f, null);
			tNewUnit.addTrait("Unstable Clone");
			//ActionLibrary.removeUnit(pTarget);
			//pTarget.setTransformed();
			return true;
	    }
		public static bool cloneRemoveDupe(BaseSimObject pTarget, WorldTile pTile = null)
	    {
            if(pTarget.a.hasTrait("Duplicator")){
				pTarget.a.removeTrait("Duplicator");
			}
            return true;
        }
        public static bool cloneTryKillAndRemoveDupe(BaseSimObject pTarget, WorldTile pTile = null)
	    {
            if(pTarget.a.hasTrait("Duplicator")){
				pTarget.a.removeTrait("Duplicator");
			}
			if (Randy.randomChance(0.05f))
		    {
		    	pTarget.a.getHitFullHealth(AttackType.Divine);
		    }
            return true;
        }
        public static bool landmineFeetEffect(BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (!(pTarget.a.isInLiquid()))
		    {
		    	pTarget.current_tile.setTopTileType(TopTileLibrary.landmine, false);
		    }
		    return true;
	    }
		public static bool chemistExperiment(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTile.tile_up == null)
			{
				return false;
			}
			if (!MapBox.isRenderGameplay())
			{
				return false;
			}
			List<string> effectListCustom = new List<string>();
        	System.Random rnd1 = new System.Random();
			effectListCustom.Add("fx_cast_ground_blue");
			effectListCustom.Add("fx_cast_top_blue");
			effectListCustom.Add("fx_cast_ground_red");
			effectListCustom.Add("fx_cast_top_red");
			effectListCustom.Add("fx_cast_ground_green");
			effectListCustom.Add("fx_cast_top_green");
			effectListCustom.Add("fx_teleport_blue");
			effectListCustom.Add("fx_teleport_red");
			effectListCustom.Add("fx_shield_hit");
			effectListCustom.Add("fx_enchanted_sparkle");
			effectListCustom.Add("fx_building_sparkle");
			effectListCustom.Add("fx_weapon_particle");
			effectListCustom.Add("fx_hit");
			effectListCustom.Add("fx_miss");
			effectListCustom.Add("fx_hit_critical");
			effectListCustom.Add("fx_boat_explosion");
			effectListCustom.Add("fx_fishnet");

			List<string> statusChemListCustomGood = new List<string>();
        	System.Random rnd2 = new System.Random();
			statusChemListCustomGood.Add("powerup");
			statusChemListCustomGood.Add("enchanted");
			statusChemListCustomGood.Add("caffeinated");
			statusChemListCustomGood.Add("shield");
			statusChemListCustomGood.Add("invincible");
			statusChemListCustomGood.Add("high");//custom
			List<string> statusChemListCustomBad = new List<string>();
        	System.Random rnd3 = new System.Random();
			statusChemListCustomBad.Add("rage");
			statusChemListCustomBad.Add("slowness");
			statusChemListCustomBad.Add("cough");
			statusChemListCustomBad.Add("ash_fever");
			statusChemListCustomBad.Add("frozen");
			statusChemListCustomBad.Add("burning");
			statusChemListCustomBad.Add("poisoned");
			statusChemListCustomBad.Add("tbleeding");//custom
			statusChemListCustomBad.Add("depressed");//custom
			statusChemListCustomBad.Add("sleepy");//custom

			int selectedEffect = rnd1.Next(effectListCustom.Count);
        	if(Randy.randomChance(0.75f)){
			EffectsLibrary.spawnAtTile(effectListCustom[selectedEffect], pTile, 0.1f);
        	}
			int selectedChemStatusGood = rnd2.Next(statusChemListCustomGood.Count);
			int selectedChemStatusBad = rnd3.Next(statusChemListCustomBad.Count);
			if(Randy.randomChance(0.15f)){
				if(Randy.randomChance(0.5f)){
					pTarget.addStatusEffect(statusChemListCustomGood[selectedChemStatusGood], -1f);
				}
				else if (Randy.randomChance(0.5f)){
					pTarget.addStatusEffect(statusChemListCustomGood[selectedChemStatusGood], -1f);
					pTarget.addStatusEffect(statusChemListCustomBad[selectedChemStatusBad], -1f);
				}
				else {
					pTarget.addStatusEffect(statusChemListCustomBad[selectedChemStatusBad], -1f);
				}
        	}
			return true;
		}
		public static bool addSleepyEffectOnSelf(BaseSimObject pTarget, WorldTile pTile = null){
    	    if (pTarget.isBuilding())
			{
				return false;
			}
			if (Randy.randomChance(0.1f))
			{
				if (Randy.randomChance(0.01f))
				{
				pTarget.a.addStatusEffect("sleepy", -1f);
				}
			}
    	    return false;
		}
        public static bool removeCripple(BaseSimObject pTarget, WorldTile pTile = null)
	    {
	    	if(pTarget.a.hasTrait("crippled")){
				if (Randy.randomChance(0.75f)){
					pTarget.a.removeTrait("crippled");
				}
			}
		    return true;
	    }
		public static bool removeNoEye(BaseSimObject pTarget, WorldTile pTile = null)
	    {
	    	if(pTarget.a.hasTrait("eyepatch")){
				if (Randy.randomChance(0.5f)){
					pTarget.a.removeTrait("eyepatch");
					return true;
				}
			}
			if (pTarget.a.hasTrait("Zero Eyed")){
				if (Randy.randomChance(0.75f)){
					pTarget.a.removeTrait("Zero Eyed");
					pTarget.a.addTrait("eyepatch", false);
					return true;
				}
			}
		    return false;
	    }
    }
}
