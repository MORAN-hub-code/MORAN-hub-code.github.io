using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ai;
using NeoModLoader.api.attributes;
using NeoModLoader.api; 
using NeoModLoader.General;

namespace avbultratraitspack{
    internal static class Statuses{
        public static void init(){
//Bleeding (Cruel)
            StatusAsset bleeding = new StatusAsset()
            {
                id = "tbleeding",
                locale_id = "status_title_tbleeding",
                locale_description = "status_description_tbleeding",
                duration = 8f,
                action = new WorldAction(StatusesActions.bleedingEffect),
			    action_interval = 1f,
                path_icon = $"ui/Icons/iconBloodRain",
                decision_id = null
            };
            bleeding.base_stats = new BaseStats();
            bleeding.base_stats.set("attack_speed", -1f);
            bleeding.base_stats.set("multiplier_damage", -0.15f);
            bleeding.base_stats.set("multiplier_speed", -0.5f);
            AssetManager.status.add(bleeding);
//High (Stoner)
            StatusAsset high = new StatusAsset()
            {
                id = "high",
                locale_id = "status_title_high",
                locale_description = "status_description_high",
                duration = 15f,
                path_icon = $"ui/Icons/iconHigh",
                decision_id = null
            };
            high.base_stats = new BaseStats();
            high.base_stats.set("health", 500f);
            high.base_stats.set("armor", 10f);
            high.base_stats.set("critical_chance", -0.99f);
            high.base_stats.set("attack_speed", -2f);
            high.base_stats.set("intelligence", -10f);
            AssetManager.status.add(high);
//Depressed (Mean)
            StatusAsset depressed = new StatusAsset()
            {
                id = "depressed",
                locale_id = "status_title_depressed",
                locale_description = "status_description_depressed",
                duration = 90f,
                path_icon = $"ui/Icons/iconDepressed",
                decision_id = null
            };
            depressed.base_stats = new BaseStats();
            depressed.base_stats.set("diplomacy", -5f);
            depressed.base_stats.set("damage", -5f);
            depressed.base_stats.set("armor", -5f);
            depressed.base_stats.set("intelligence", -3f);
            depressed.base_stats.set("critical_chance",  -0.4f);
            depressed.base_stats.set("attack_speed", -1.5f);
            AssetManager.status.add(depressed);
//Sleepy (Lazy)
            StatusAsset sleepy = new StatusAsset()
            {
                id = "sleepy",
                locale_id = "status_title_sleepy",
                locale_description = "status_description_sleepy",
                duration = 30f,
                path_icon = $"ui/Icons/iconSleepy",
                decision_id = null
            };
            sleepy.base_stats = new BaseStats();
            sleepy.base_stats.set("multiplier_speed", -0.70f);
            sleepy.base_stats.set("attack_speed", -2.5f);
            sleepy.action_finish = delegate(BaseSimObject pActor, WorldTile _)
            {
                if (Randy.randomChance(0.35f))
                {
                    pActor.a.addStatusEffect("sleeping", 10f, true); 
                    return true;
                }
                return false;
            };
            AssetManager.status.add(sleepy);
//Awakened Demonchild
            StatusAsset demonchild = new StatusAsset()
            {
                id = "awakenedDemonchild",
                locale_id = "status_title_awakenedDemonchild",
                locale_description = "status_description_awakenedDemonchild",
                duration = 100f,
                path_icon = $"ui/Icons/iconDemonStatus",
                decision_id = null
            };
            demonchild.base_stats = new BaseStats();
            demonchild.base_stats.set("damage", 10f);
            demonchild.base_stats.set("warfare", 5f);
            demonchild.base_stats.set("attack_speed", 2f);
            AssetManager.status.add(demonchild);
//Awakened Gloomchild
            StatusAsset gloomchild = new StatusAsset()
            {
                id = "awakenedGloomchild",
                locale_id = "status_title_awakenedGloomchild",
                locale_description = "status_description_awakenedGloomchild",
                duration = 100f,
                path_icon = $"ui/Icons/iconGloomStatus",
                decision_id = null
            };
            gloomchild.base_stats = new BaseStats();
            gloomchild.base_stats.set("armor", 15f);
            gloomchild.base_stats.set("damage", 5f);
            gloomchild.base_stats.set("opinion", -75f);
            AssetManager.status.add(gloomchild);
//Awakened Sparkchild
            StatusAsset sparkchild = new StatusAsset()
            {
                id = "awakenedSparkchild",
                locale_id = "status_title_awakenedSparkchild",
                locale_description = "status_description_awakenedSparkchild",
                duration = 100f,
                path_icon = $"ui/Icons/iconSparkStatus",
                decision_id = null
            };
            sparkchild.base_stats = new BaseStats();
            sparkchild.base_stats.set("lifepsan", 100f);
            sparkchild.base_stats.set("speed", 50f);
            sparkchild.base_stats.set("intelligence", 25f);
            sparkchild.base_stats.set("offspring", 5f);
            AssetManager.status.add(sparkchild);
//Awakened Doomchild
            StatusAsset doomchild = new StatusAsset()
            {
                id = "awakenedDoomchild",
                locale_id = "status_title_awakenedDoomchild",
                locale_description = "status_description_awakenedDoomchild",
                duration = 100f,
                path_icon = $"ui/Icons/iconDoomStatus",
                decision_id = null
            };
            doomchild.base_stats = new BaseStats();
            doomchild.base_stats.set("damage", 15f);
            doomchild.base_stats.set("warfare", 10f);
            doomchild.base_stats.set("critical_chance", 0.50f);
            doomchild.base_stats.set("loyalty_traits", -30f);
            AssetManager.status.add(doomchild);
//Awakened Frostchild
            StatusAsset frostchild = new StatusAsset()
            {
                id = "awakenedFrostchild",
                locale_id = "status_title_awakenedFrostchild",
                locale_description = "status_description_awakenedFrostchild",
                duration = 100f,
                path_icon = $"ui/Icons/iconFrostStatus",
                decision_id = null
            };
            frostchild.base_stats = new BaseStats();
            frostchild.base_stats.set("armor", 45f);
            frostchild.base_stats.set("damage", 5f);
            frostchild.base_stats.set("loyalty_traits", -30f);
            AssetManager.status.add(frostchild);
//Shining
            StatusAsset shining = new StatusAsset()
            {
                id = "shining",
                locale_id = "status_title_shining",
                locale_description = "status_description_shining",
                duration = 60f,
                path_icon = $"ui/Icons/iconShining",
                decision_id = null
            };
            shining.base_stats = new BaseStats();
            shining.base_stats.set("armor", 5f);
            shining.action = new WorldAction(ActionLibrary.shiny);
            shining.action_interval = 3f;
            AssetManager.status.add(shining);
        }//end of status creation
    }
}