using System;
// using System.IO;
// using System.Text;
// using System.Reflection;
// using System.Collections;
// using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;

namespace avbultratraitspack{
    internal static class Traits{
        public static void init(){
            AssetManager.trait_groups.add(new ActorTraitGroupAsset{
               id = "Super",
               name = "trait_group_super",
               color = "#FDDC5C"
            });
            AssetManager.trait_groups.add(new ActorTraitGroupAsset{
               id = "Horrible",
               name = "trait_group_horrible",
               color = "#CE8946"
            });
            AssetManager.trait_groups.add(new ActorTraitGroupAsset{
               id = "Blood",
               name = "trait_group_blood",
               color = "#DC143C"
            });
            AssetManager.trait_groups.add(new ActorTraitGroupAsset{
               id = "Morph",
               name = "trait_group_morph",
               color = "#F2F3F4"
            });
//Super Traits-------------------------------------------------------------------------------------------------------
            ActorTrait superhealth = AssetManager.traits.get("super_health");
            superhealth.group_id = "Super";
            superhealth.addOpposite("Horrible Health");
//SArmor
            ActorTrait superarmor = new ActorTrait()
            {
                id = "Super Armor",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperArmor",
                needs_to_be_explored = false
            };
            superarmor.base_stats = new BaseStats();
            superarmor.base_stats.set("armor", 99f);
            superarmor.addOpposite("Horrible Health");
            AssetManager.traits.add(superarmor);
//SDamage
	        ActorTrait superdamage = new ActorTrait()
            {
                id = "Super Damage",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperDamage",
                needs_to_be_explored = false
            };
            superdamage.base_stats = new BaseStats();
            superdamage.base_stats.set("damage", 999f);
            superdamage.addOpposite("Horrible Damage");
            AssetManager.traits.add(superdamage);
//SCritical
            ActorTrait supercrit = new ActorTrait()
            {
                id = "Super Critical Chance",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperCritical",
                needs_to_be_explored = false
            };
            supercrit.base_stats = new BaseStats();
            supercrit.base_stats.set("critical_chance", 1f);
            supercrit.addOpposite("Horrible Critical Chance");
            AssetManager.traits.add(supercrit);
//SSpeed
	        ActorTrait superspeed = new ActorTrait()
            {
                id = "Super Speed",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperSpeed",
                needs_to_be_explored = false
            };
            superspeed.base_stats = new BaseStats();
            superspeed.base_stats.set("speed", 999f);
            superspeed.addOpposite("Horrible Speed");
            AssetManager.traits.add(superspeed);
//SAttack Speed
            ActorTrait superattackspeed = new ActorTrait()
            {
                id = "Super Attack Speed",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperAttackSpeed",
                needs_to_be_explored = false
            };
            superattackspeed.base_stats = new BaseStats();
            superattackspeed.base_stats.set("attack_speed", 10f);
            superattackspeed.addOpposite("Horrible Attack Speed");
            AssetManager.traits.add(superattackspeed);
//SDiplomacy
            ActorTrait superdiplomacy = new ActorTrait()
            {
                id = "Super Diplomacy",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperDiplomacy",
                needs_to_be_explored = false
            };
            superdiplomacy.base_stats = new BaseStats();
            superdiplomacy.base_stats.set("diplomacy", 999f);
            superdiplomacy.addOpposite("Horrible Diplomacy");
            AssetManager.traits.add(superdiplomacy);
//SWarfare
            ActorTrait superwarfare = new ActorTrait()
            {
                id = "Super Warfare",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperWarfare",
                needs_to_be_explored = false
            };
            superwarfare.base_stats = new BaseStats();
            superwarfare.base_stats.set("warfare", 999f);
            superwarfare.addOpposite("Horrible Warfare");
            AssetManager.traits.add(superwarfare);
//SStewardship
            ActorTrait superstewardship = new ActorTrait()
            {
                id = "Super Stewardship",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperStewardship",
                needs_to_be_explored = false
            };
            superstewardship.base_stats = new BaseStats();
            superstewardship.base_stats.set("stewardship", 999f);
            superstewardship.addOpposite("Horrible Stewardship");
            AssetManager.traits.add(superstewardship);
//SIntelligence
            ActorTrait superintelligence = new ActorTrait()
            {
                id = "Super Intelligence",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperIntelligence",
                needs_to_be_explored = false
            };
            superintelligence.base_stats = new BaseStats();
            superintelligence.base_stats.set("intelligence", 999f);
            superintelligence.addOpposite("Horrible Intelligence");
            AssetManager.traits.add(superintelligence);
//SLoyalty
            ActorTrait superloyalty = new ActorTrait()
            {
                id = "Super Loyalty",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperLoyalty",
                needs_to_be_explored = false
            };
            superloyalty.base_stats = new BaseStats();
            superloyalty.base_stats.set("loyalty_traits", 999f);
            superloyalty.addOpposite("Horrible Loyalty");
            AssetManager.traits.add(superloyalty);
//SOpinion
            ActorTrait superopinion = new ActorTrait()
            {
                id = "Super Opinion",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperOpinion",
                needs_to_be_explored = false
            };
            superopinion.base_stats = new BaseStats();
            superopinion.base_stats.set("opinion", 999f);
            superopinion.addOpposite("Horrible Opinion");
            AssetManager.traits.add(superopinion);
//SKnockback
            ActorTrait superknockback = new ActorTrait()
            {
                id = "Super Knockback",
                group_id = "Super",
                path_icon = $"ui/Icons/iconSuperKnockback",
                needs_to_be_explored = false
            };
            superknockback.base_stats = new BaseStats();
            superknockback.base_stats.set("knockback", 10f);
            superknockback.addOpposite("Horrible Knockback");
            AssetManager.traits.add(superknockback);
//SRange (Psychic)
            ActorTrait psychic = new ActorTrait()
            {
                id = "Psychic",
                group_id = "Super",
                path_icon = $"ui/Icons/iconPsychic",
                needs_to_be_explored = false
            };
            psychic.base_stats = new BaseStats();
            psychic.base_stats.set("range", 999);
            AssetManager.traits.add(psychic);
//Horrible Traits-------------------------------------------------------------------------------------------------------
//HHealth
            ActorTrait horriblehealth = new ActorTrait()
            {
                id = "Horrible Health",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleHealth",
                needs_to_be_explored = false
            };
            horriblehealth.base_stats = new BaseStats();
            horriblehealth.base_stats.set("health", -9999f);
            horriblehealth.addOpposite("Super Health");
            AssetManager.traits.add(horriblehealth);
//HArmor
            ActorTrait horriblearmor = new ActorTrait()
            {
                id = "Horrible Armor",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleArmor",
                needs_to_be_explored = false
            };
            horriblearmor.base_stats = new BaseStats();
            horriblearmor.base_stats.set("armor", -99f);
            horriblearmor.addOpposite("Super Armor");
            AssetManager.traits.add(horriblearmor);
//HDamage
            ActorTrait horribledamage = new ActorTrait()
            {
                id = "Horrible Damage",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleDamage",
                needs_to_be_explored = false
            };
            horribledamage.base_stats = new BaseStats();
            horribledamage.base_stats.set("damage", -999f);
            horribledamage.addOpposite("Super Damage");
            AssetManager.traits.add(horribledamage);
//HCritical
            ActorTrait horriblecrit = new ActorTrait()
            {
                id = "Horrible Critical Chance",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleCritical",
                needs_to_be_explored = false
            };
            horriblecrit.base_stats = new BaseStats();
            horriblecrit.base_stats.set("critical_chance", -1f);
            horriblecrit.addOpposite("Super Critical Chance");
            AssetManager.traits.add(horriblecrit);
//HSpeed
            ActorTrait horriblespeed = new ActorTrait()
            {
                id = "Horrible Speed",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleSpeed",
                needs_to_be_explored = false
            };
            horriblespeed.base_stats = new BaseStats();
            horriblespeed.base_stats.set("speed", -999f);
            horriblespeed.addOpposite("Super Speed");
            AssetManager.traits.add(horriblespeed);
//HAttack Speed
            ActorTrait horribleattackspeed = new ActorTrait()
            {
                id = "Horrible Attack Speed",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleAttackSpeed",
                needs_to_be_explored = false
            };
            horribleattackspeed.base_stats = new BaseStats();
            horribleattackspeed.base_stats.set("attack_speed", -9.5f);
            horribleattackspeed.addOpposite("Super Attack Speed");
            AssetManager.traits.add(horribleattackspeed);
//HDiplomacy
            ActorTrait horriblediplomacy = new ActorTrait()
            {
                id = "Horrible Diplomacy",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleDiplomacy",
                needs_to_be_explored = false
            };
            horriblediplomacy.base_stats = new BaseStats();
            horriblediplomacy.base_stats.set("diplomacy", -999f);
            horriblediplomacy.addOpposite("Super Diplomacy");
            AssetManager.traits.add(horriblediplomacy);
//HWarfare
            ActorTrait horriblewarfare = new ActorTrait()
            {
                id = "Horrible Warfare",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleWarfare",
                needs_to_be_explored = false
            };
            horriblewarfare.base_stats = new BaseStats();
            horriblewarfare.base_stats.set("warfare", -999f);
            horriblewarfare.addOpposite("Super Warfare");
            AssetManager.traits.add(horriblewarfare);
//HStewardship
            ActorTrait horriblestewardship = new ActorTrait()
            {
                id = "Horrible Stewardship",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleStewardship",
                needs_to_be_explored = false
            };
            horriblestewardship.base_stats = new BaseStats();
            horriblestewardship.base_stats.set("stewardship", -999f);
            horriblestewardship.addOpposite("Super Stewardship");
            AssetManager.traits.add(horriblestewardship);
//HIntelligence
            ActorTrait horribleintelligence = new ActorTrait()
            {
                id = "Horrible Intelligence",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleIntelligence",
                needs_to_be_explored = false
            };
            horribleintelligence.base_stats = new BaseStats();
            horribleintelligence.base_stats.set("intelligence", -999f);
            horribleintelligence.addOpposite("Super Intelligence");
            AssetManager.traits.add(horribleintelligence);
//HLoyalty
            ActorTrait horribleloyalty = new ActorTrait()
            {
                id = "Horrible Loyalty",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleLoyalty",
                needs_to_be_explored = false
            };
            horribleloyalty.base_stats = new BaseStats();
            horribleloyalty.base_stats.set("loyalty_traits", -999f);
            horribleloyalty.addOpposite("Super Loyalty");
            AssetManager.traits.add(horribleloyalty);
//HLifespan
            ActorTrait horriblelifespan = new ActorTrait()
            {
                id = "Horrible Lifespan",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleLifespan",
                needs_to_be_explored = false
            };
            horriblelifespan.base_stats = new BaseStats();
            horriblelifespan.base_stats.set("lifespan", -9999f);
            AssetManager.traits.add(horriblelifespan);
//HOpinion
            ActorTrait horribleopinion = new ActorTrait()
            {
                id = "Horrible Opinion",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleOpinion",
                needs_to_be_explored = false
            };
            horribleopinion.base_stats = new BaseStats();
            horribleopinion.base_stats.set("opinion", -999f);
            horribleopinion.addOpposite("Super Opinion");
            AssetManager.traits.add(horribleopinion);
//HKnockback
            ActorTrait horribleknockback = new ActorTrait()
            {
                id = "Horrible Knockback",
                group_id = "Horrible",
                path_icon = $"ui/Icons/iconHorribleKnockback",
                needs_to_be_explored = false
            };
            horribleknockback.base_stats = new BaseStats();
            horribleknockback.base_stats.set("knockback", -10f);
            horribleknockback.addOpposite("Super Knockback");
            AssetManager.traits.add(horribleknockback);
//Blood Traits-------------------------------------------------------------------------------------------------------
            ActorTrait fireblood = AssetManager.traits.get("fire_blood");
            fireblood.group_id = "Blood";
            ActorTrait acidblood = AssetManager.traits.get("acid_blood");
            acidblood.group_id = "Blood";
//Water Blood
            ActorTrait waterblood = new ActorTrait()
            {
                id = "Water Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconWaterBlood",
                needs_to_be_explored = false
            };
            //waterblood.action_death = new WorldAction(TraitDeathActions.waterBloodEffect);
            waterblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "rain");
                return true;
            };
            AssetManager.traits.add(waterblood);
//Bloody Blood
            ActorTrait bloodyblood = new ActorTrait()
            {
                id = "Bloody Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconBloodyBlood",
                needs_to_be_explored = false
            };
            bloodyblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "blood_rain");
                return true;
            };
            AssetManager.traits.add(bloodyblood);
//Frost Blood
            ActorTrait frostblood = new ActorTrait()
            {
                id = "Frost Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconFrostBlood",
                needs_to_be_explored = false
            };
            frostblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "snow");
                return true;
            };
            AssetManager.traits.add(frostblood);
//Pure Blood
            ActorTrait pureblood = new ActorTrait()
            {
                id = "Pure Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconPureBlood",
                needs_to_be_explored = false
            };
            pureblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "cure");
                return true;
            };
            AssetManager.traits.add(pureblood);
//30-Dirty Blood
            ActorTrait ashblood = new ActorTrait()
            {
                id = "Ash Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconAshBlood",
                needs_to_be_explored = false
            };
            ashblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "ash");
                return true;
            };
            AssetManager.traits.add(ashblood);
//Magic Blood
            ActorTrait magicblood = new ActorTrait()
            {
                id = "Magic Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconMagicBlood",
                needs_to_be_explored = false
            };
            magicblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "magic_rain");
                return true;
            };
            AssetManager.traits.add(magicblood);
//Raging Blood
            ActorTrait rageblood = new ActorTrait()
            {
                id = "Raging Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconRagingBlood",
                needs_to_be_explored = false
            };
            rageblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "rage");
                return true;
            };
            AssetManager.traits.add(rageblood);
//Biome Blood-------------------------------------------------------------------------------------------------------
//Grass Blood
            ActorTrait grassblood = new ActorTrait()
            {
                id = "Grass Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconGrassBlood",
                needs_to_be_explored = false
            };
            grassblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_grass");
                return true;
            };
            AssetManager.traits.add(grassblood);
//Enchanted Blood
            ActorTrait enchantedblood = new ActorTrait()
            {
                id = "Enchanted Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconEnchantedBlood",
                needs_to_be_explored = false
            };
            enchantedblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_enchanted");
                return true;
            };
            AssetManager.traits.add(enchantedblood);
//Savanna Blood
            ActorTrait savannablood = new ActorTrait()
            {
                id = "Savanna Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconSavannaBlood",
                needs_to_be_explored = false
            };
            savannablood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_savanna");
                return true;
            };
            AssetManager.traits.add(savannablood);
//Corrupted Blood
            ActorTrait corruptedblood = new ActorTrait()
            {
                id = "Corrupted Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconCorruptedBlood",
                needs_to_be_explored = false
            };
            corruptedblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_corrupted");
                return true;
            };
            AssetManager.traits.add(corruptedblood);
//Mushroom Blood
            ActorTrait mushroomblood = new ActorTrait()
            {
                id = "Mushroom Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconMushroomBlood",
                needs_to_be_explored = false
            };
            mushroomblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_mushroom");
                return true;
            };
            AssetManager.traits.add(mushroomblood);
//Jungle Blood
            ActorTrait jungleblood = new ActorTrait()
            {
                id = "Jungle Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconJungleBlood",
                needs_to_be_explored = false
            };
            jungleblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_jungle");
                return true;
            };
            AssetManager.traits.add(jungleblood);
//Arcane Desert Blood
            ActorTrait arcaneblood = new ActorTrait()
            {
                id = "Arcane Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconArcaneBlood",
                needs_to_be_explored = false
            };
            arcaneblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_desert");
                return true;
            };
            AssetManager.traits.add(arcaneblood);
//Lemon Blood
            ActorTrait lemonblood = new ActorTrait()
            {
                id = "Lemon Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconLemonBlood",
                needs_to_be_explored = false
            };
            lemonblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_lemon");
                return true;
            };
            AssetManager.traits.add(lemonblood);
//Permafrost Blood
            ActorTrait permablood = new ActorTrait()
            {
                id = "Permafrost Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconPermafrostBlood",
                needs_to_be_explored = false
            };
            permablood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_permafrost");
                return true;
            };
            AssetManager.traits.add(permablood);
//Candy Blood
            ActorTrait candyblood = new ActorTrait()
            {
                id = "Candy Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconCandyBlood",
                needs_to_be_explored = false
            };
            candyblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_candy");
                return true;
            };
            AssetManager.traits.add(candyblood);
//Crystal Blood
            ActorTrait crystalblood = new ActorTrait()
            {
                id = "Crystal Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconCrystalBlood",
                needs_to_be_explored = false
            };
            crystalblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_crystal");
                return true;
            };
            AssetManager.traits.add(crystalblood);
//Swamp Blood
            ActorTrait swampblood = new ActorTrait()
            {
                id = "Swamp Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconSwampBlood",
                needs_to_be_explored = false
            };
            swampblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_swamp");
                return true;
            };
            AssetManager.traits.add(swampblood);
//Infernal Blood
            ActorTrait infernalblood = new ActorTrait()
            {
                id = "Infernal Blood",
                group_id = "Blood",
                path_icon = $"ui/Icons/iconInfernalBlood",
                needs_to_be_explored = false
            };
            infernalblood.action_death = delegate(BaseSimObject pSimObject, WorldTile pTile)
            {
                TraitDeathActions.deathBloodEffect(pSimObject, pTile, "seeds_infernal");
                return true;
            };
            AssetManager.traits.add(infernalblood);
//Death Bomb Traits-------------------------------------------------------------------------------------------------------
//Napalm
            ActorTrait napalmfall = new ActorTrait()
            {
                id = "Death Napalm",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDeathNapalm",
                needs_to_be_explored = false
            };
            napalmfall.action_death = new WorldAction(TraitDeathActions.deathNapalmBomb);
            AssetManager.traits.add(napalmfall);
//Grenade 
            ActorTrait grenadefall = new ActorTrait()
            {
                id = "Death Grenade",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDeathGrenade",
                needs_to_be_explored = false
            };
            grenadefall.action_death = new WorldAction(TraitDeathActions.deathGrenadeBomb);
            AssetManager.traits.add(grenadefall);
//Antimatter
            ActorTrait antimatterfall = new ActorTrait()
            {
                id = "Death Antimatter",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDeathAntimatter",
                needs_to_be_explored = false
            };
            antimatterfall.action_death = new WorldAction(TraitDeathActions.deathAntimatterBomb);
            AssetManager.traits.add(antimatterfall);
//Tsar
            ActorTrait tsarfall = new ActorTrait()
            {
                id = "Death Tsar",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDeathTsar",
                needs_to_be_explored = false
            };
            tsarfall.action_death = new WorldAction(TraitDeathActions.deathTsarbomba);
            AssetManager.traits.add(tsarfall);
//Crab
            ActorTrait crabfall = new ActorTrait()
            {
                id = "Death Crab",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDeathCrab",
                needs_to_be_explored = false
            };
            crabfall.action_death = new WorldAction(TraitDeathActions.deathCrabBomb);
            AssetManager.traits.add(crabfall);
//Monolithic
            ActorTrait monolithgrave = new ActorTrait()
            {
                id = "Monolithic",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconMonolithic",
                needs_to_be_explored = false
            };
            monolithgrave.action_death = new WorldAction(TraitDeathActions.deathMonoMark);
            AssetManager.traits.add(monolithgrave);
//Morph Traits-------------------------------------------------------------------------------------------------------
//Dragon Heart
            ActorTrait dragonheart = new ActorTrait()
            {
                id = "Dragon Heart",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconDragonHeart",
                needs_to_be_explored = false
            };
            dragonheart.base_stats = new BaseStats();
            dragonheart.base_stats.set("damage", 10f);
            dragonheart.base_stats.set("armor", 10f);
            dragonheart.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "dragon", "Dragon Heart", true, true);
                return true;
            };
            AssetManager.traits.add(dragonheart);
//Magic Heart
            ActorTrait magicheart = new ActorTrait()
            {
                id = "Magic Heart",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconMagicHeart",
                needs_to_be_explored = false
            };
            magicheart.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoMage(tActor, true, true);
                return true;
            };
            AssetManager.traits.add(magicheart);
//Human Morph
            ActorTrait humanmorph = new ActorTrait()
            {
                id = "Human Morph",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconHumanMorph",
                needs_to_be_explored = false
            };
            humanmorph.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "human", "Human Morph", true, true);
                return true;
            };
            AssetManager.traits.add(humanmorph);
//Elf Morph
            ActorTrait elfmorph = new ActorTrait()
            {
                id = "Elf Morph",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconElfMorph",
                needs_to_be_explored = false
            };
            elfmorph.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "elf", "Elf Morph", true, true);
                return true;
            };
            AssetManager.traits.add(elfmorph);
//Dwarf Morph
            ActorTrait dwarfmorph = new ActorTrait()
            {
                id = "Dwarf Morph",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconDwarfMorph",
                needs_to_be_explored = false
            };
            dwarfmorph.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "dwarf", "Dwarf Morph", true, true);
                return true;
            };
            AssetManager.traits.add(dwarfmorph);
//Orc Morph
            ActorTrait orcmorph = new ActorTrait()
            {
                id = "Orc Morph",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconOrcMorph",
                needs_to_be_explored = false
            };
            orcmorph.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "orc", "Orc Morph", true, true);
                return true;
            };
            AssetManager.traits.add(orcmorph);
//Bandit Morph
            ActorTrait banditmorph = new ActorTrait()
            {
                id = "Bandit Morph",
                group_id = "Morph",
                path_icon = $"ui/Icons/iconBanditMorph",
                needs_to_be_explored = false
            };
            banditmorph.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                // if (!tActor.isPrettyOld())
                // {
                //     return false;
                // }
                TraitDeathActions.specialMorphIntoCreature(tActor, "bandit", "Bandit Morph", true, true);
                return true;
            };
            AssetManager.traits.add(banditmorph);
//Slayer Traits-------------------------------------------------------------------------------------------------------
//Alien Slayer
            ActorTrait alienslayer = new ActorTrait()
            {
                id = "Alien Slayer",
                group_id = "merits",
                path_icon = $"ui/Icons/iconAlienSlayer",
                needs_to_be_explored = false
            };
            alienslayer.base_stats = new BaseStats();
            alienslayer.base_stats.set("range", 6f);
            alienslayer.base_stats.set("diplomacy", 5f);
            alienslayer.base_stats.set("warfare", 3f);
            alienslayer.base_stats.set("critical_chance", 0.10f);
            AssetManager.traits.add(alienslayer);

            ActorAsset alien = AssetManager.actor_library.get("alien");
            alien.action_death = new WorldAction(CreatureDeathActions.alienSlayer);
//Bug Slayer
            ActorTrait bugslayer = new ActorTrait()
            {
                id = "Bug Slayer",
                group_id = "merits",
                path_icon = $"ui/Icons/iconVermin",
                needs_to_be_explored = false
            };
            bugslayer.base_stats = new BaseStats();
            bugslayer.base_stats.set("warfare", 1f);
            bugslayer.base_stats.set("stewardship", -3f);
            bugslayer.base_stats.set("loyalty_traits", -5f);
            AssetManager.traits.add(bugslayer);

            ActorAsset bug1 = AssetManager.actor_library.get("beetle");
            bug1.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
            ActorAsset civbug1 = AssetManager.actor_library.get("civ_beetle");
            civbug1.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
            ActorAsset bug2 = AssetManager.actor_library.get("grasshopper");
            bug2.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
            ActorAsset bug3 = AssetManager.actor_library.get("fly");
            bug3.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
            ActorAsset bug4 = AssetManager.actor_library.get("butterfly");
            bug4.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
            ActorAsset bug5 = AssetManager.actor_library.get("bee");
            bug5.action_death = new WorldAction(CreatureDeathActions.bugSlayer);
//Boss Slayer
            ActorTrait bossslayer = new ActorTrait()
            {
                id = "Boss Slayer",
                group_id = "merits",
                path_icon = $"ui/Icons/iconBossSlayer",
                needs_to_be_explored = false
            };
            bossslayer.base_stats = new BaseStats();
            bossslayer.base_stats.set("health", 100f);
            bossslayer.base_stats.set("warfare", 50f);
            bossslayer.base_stats.set("diplomacy", 20f);
            bossslayer.base_stats.set("stewardship", 10f);
            bossslayer.base_stats.set("critical_chance", 0.90f);
            bossslayer.base_stats.set("loyalty_traits", -10f);
            AssetManager.traits.add(bossslayer);
//Demon Slayer
            ActorTrait demonslayer = new ActorTrait()
            {
                id = "Demon Slayer",
                group_id = "merits",
                path_icon = $"ui/Icons/iconDemonSlayer",
                needs_to_be_explored = false
            };
            demonslayer.base_stats = new BaseStats();
            demonslayer.base_stats.set("warfare", 5f);
            demonslayer.base_stats.set("stewardship", 3f);
            demonslayer.base_stats.set("critical_chance", 0.05f);
            AssetManager.traits.add(demonslayer);

            ActorAsset demon1 = AssetManager.actor_library.get("demon");
            demon1.action_death = new WorldAction(CreatureDeathActions.demonSlayer);
//Cold Slayer
            ActorTrait coldslayer = new ActorTrait()
            {
                id = "Cold Slayer",
                group_id = "merits",
                path_icon = $"ui/Icons/iconColdSlayer",
                needs_to_be_explored = false
            };
            coldslayer.base_stats = new BaseStats();
            coldslayer.base_stats.set("armor", 5f);
            coldslayer.base_stats.set("warfare", 3f);
            AssetManager.traits.add(coldslayer);

            ActorAsset walker = AssetManager.actor_library.get("cold_one");
            walker.action_death = new WorldAction(CreatureDeathActions.coldSlayer);
//World Age Traits-------------------------------------------------------------------------------------------------------
//Demonchild
            ActorTrait demonchild = new ActorTrait()
            {
                id = "Demonchild",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconDemonChild",
                needs_to_be_explored = false
            };
            demonchild.base_stats = new BaseStats();
            demonchild.base_stats.set("warfare", 1f);
            demonchild.action_special_effect = new WorldAction(TraitSpecialEffectActions.demonChildEffect);
            AssetManager.traits.add(demonchild);
//Gloomchild
            ActorTrait gloomchild = new ActorTrait()
            {
                id = "Gloomchild",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconGloomChild",
                needs_to_be_explored = false
            };
            gloomchild.base_stats = new BaseStats();
            gloomchild.base_stats.set("opinion", -5f);
            gloomchild.action_special_effect = new WorldAction(TraitSpecialEffectActions.gloomChildEffect);
            AssetManager.traits.add(gloomchild);
//Sparkchild
            ActorTrait sparkchild = new ActorTrait()
            {
                id = "Sparkchild",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconSparkChild",
                needs_to_be_explored = false
            };
            sparkchild.base_stats = new BaseStats();
            sparkchild.base_stats.set("intelligence", 1f);
            sparkchild.action_special_effect = new WorldAction(TraitSpecialEffectActions.sparkChildEffect);
            AssetManager.traits.add(sparkchild);
//Doomchild
            ActorTrait doomchild = new ActorTrait()
            {
                id = "Doomchild",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconDoomChild",
                needs_to_be_explored = false
            };
            doomchild.base_stats = new BaseStats();
            doomchild.base_stats.set("loyalty_traits", -10f);
            doomchild.action_special_effect = new WorldAction(TraitSpecialEffectActions.doomChildEffect);
            AssetManager.traits.add(doomchild);
//Frostchild
            ActorTrait frostchild = new ActorTrait()
            {
                id = "Frostchild",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconFrostChild",
                needs_to_be_explored = false
            };
            frostchild.base_stats = new BaseStats();
            frostchild.base_stats.set("armor", 1f);
            frostchild.action_special_effect = new WorldAction(TraitSpecialEffectActions.frostChildEffect);
            AssetManager.traits.add(frostchild);
//Other Death Action Traits-------------------------------------------------------------------------------------------------------
//Replicative Immortality
            ActorTrait repimm = new ActorTrait()
            {
                id = "Replicative Immortality",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconReplicativeImmortality",
                needs_to_be_explored = false
            };
            repimm.base_stats = new BaseStats();
            repimm.base_stats.set("loyalty_traits", -10f);
            repimm.action_death = delegate(BaseSimObject pSimObject, WorldTile _)
            {
                Actor tActor = pSimObject.a;
                TraitDeathActions.replicateNow(tActor, tActor.asset.id, true, true);
                return true;
            };
            AssetManager.traits.add(repimm);
//Mega Giant
            ActorTrait megagiant = new ActorTrait()
            {
                id = "Mega Giant",
                group_id = "physique",
                path_icon = $"ui/Icons/iconMegaGiant",
                needs_to_be_explored = false
            };
            megagiant.base_stats = new BaseStats();
            megagiant.base_stats.set("scale", 0.2f);
            megagiant.base_stats.set("health", 500f);
            megagiant.base_stats.set("damage", 15f);
            megagiant.base_stats.set("multiplier_speed", -0.25f);
            megagiant.base_stats.set("multiplier_attack_speed", -0.25f);
            megagiant.action_death = new WorldAction(ActionLibrary.megaHeartbeat);
            AssetManager.traits.add(megagiant);
//Other Attack Action Traits-------------------------------------------------------------------------------------------------------
//Scale Hands
            ActorTrait scalehands = new ActorTrait()
            {
                id = "Scale Hands",
                group_id = "body",
                path_icon = $"ui/Icons/iconScaleHands",
                needs_to_be_explored = false
            };
            scalehands.action_attack_target = new AttackAction(TraitAttackActions.addBurningEffectOnTarget);
            AssetManager.traits.add(scalehands);
//Frost Bite
            ActorTrait frostbite = new ActorTrait()
            {
                id = "Frost Bite",
                group_id = "body",
                path_icon = $"ui/Icons/iconFrostBite",
                needs_to_be_explored = false
            };
            frostbite.action_attack_target = new AttackAction(TraitAttackActions.addFrozenEffectOnTarget);
            AssetManager.traits.add(frostbite);
//Iron Fist
            ActorTrait ironfist = new ActorTrait()
            {
                id = "Iron Fist",
                group_id = "body",
                path_icon = $"ui/Icons/iconIronFist",
                needs_to_be_explored = false
            };
            ironfist.base_stats = new BaseStats();
            ironfist.base_stats.set("damage", 10f);
            ironfist.base_stats.set("stewardship", 5f);
            ironfist.base_stats.set("diplomacy", -5f);
            ironfist.base_stats.set("attack_speed", -20f);
            ironfist.action_attack_target = new AttackAction(TraitAttackActions.addShockEffectOnTarget);
            AssetManager.traits.add(ironfist);
//Wildcard
            ActorTrait wildcardt = new ActorTrait()
            {
                id = "Wildcard",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconUnpredictable",
                needs_to_be_explored = false
            };
            wildcardt.base_stats = new BaseStats();
            wildcardt.base_stats.set("speed", 15f);
            wildcardt.base_stats.set("warfare", 8f);
            wildcardt.base_stats.set("diplomacy", -5f);
            wildcardt.base_stats.set("critical_chance", -0.10f);
            wildcardt.action_attack_target = new AttackAction(TraitAttackActions.unpredictableRoll);
            AssetManager.traits.add(wildcardt);
//Mean
            ActorTrait mean = new ActorTrait()
            {
                id = "Mean",
                group_id = "mind",
                path_icon = $"ui/Icons/iconMean",
                needs_to_be_explored = false
            };
            mean.base_stats = new BaseStats();
            mean.base_stats.set("damage", 5f);
            mean.base_stats.set("critical_chance", 0.15f);
            mean.base_stats.set("intelligence", -1f);
            mean.base_stats.set("diplomacy", -3f);
            mean.base_stats.set("stewardship", -5f);
            mean.base_stats.set("loyalty_traits", -20f);
            mean.action_attack_target = new AttackAction(TraitAttackActions.addDepressedEffectOnTarget);
            AssetManager.traits.add(mean);
//Cruel
            ActorTrait cruel = new ActorTrait()
            {
                id = "tCruel",
                group_id = "mind",
                path_icon = $"ui/Icons/iconCruel",
                needs_to_be_explored = false
            };
            cruel.base_stats = new BaseStats();
            cruel.base_stats.set("stewardship", 1f);
            cruel.base_stats.set("warfare", -1f);
            cruel.base_stats.set("damage", -3f);
            cruel.base_stats.set("loyalty_traits", -25f);
            cruel.base_stats.set("critical_chance", -0.10f);
            cruel.action_attack_target = new AttackAction(TraitAttackActions.addBleedEffectOnTarget);
            AssetManager.traits.add(cruel);
//Vine Arms
            ActorTrait vinearms = new ActorTrait()
            {
                id = "Vine Arms",
                group_id = "body",
                path_icon = $"ui/Icons/iconVineArms",
                needs_to_be_explored = false
            };
            vinearms.base_stats = new BaseStats();
            vinearms.base_stats.set("attack_speed", -5f);
            vinearms.base_stats.set("multiplier_damage", -0.1f);
            vinearms.action_attack_target = new AttackAction(TraitAttackActions.addSlowEffectOnTarget);
            AssetManager.traits.add(vinearms);
//Siphon
            ActorTrait siphon = new ActorTrait()
            {
                id = "Siphon",
                group_id = "health",
                path_icon = $"ui/Icons/iconSiphon",
                needs_to_be_explored = false
            };
            siphon.base_stats = new BaseStats();
            siphon.base_stats.set("damage", -5f);
            siphon.base_stats.set("multiplier_attack_speed", -0.5f);
            siphon.action_attack_target = new AttackAction(TraitAttackActions.restoreHealthOnHit2);
            AssetManager.traits.add(siphon);
//Guilt
            ActorTrait guilt = new ActorTrait()
            {
                id = "Guilt",
                group_id = "mind",
                path_icon = $"ui/Icons/iconGuilt",
                needs_to_be_explored = false
            };
            guilt.base_stats = new BaseStats();
            guilt.base_stats.set("diplomacy", 3f);
            guilt.base_stats.set("damage", -3f);
            guilt.base_stats.set("warfare", -8f);
            guilt.action_attack_target = new AttackAction(TraitAttackActions.loseHealthOnHit);
            AssetManager.traits.add(guilt);
//Alchemist 
            ActorTrait alch = new ActorTrait()
            {
                id = "Alchemist",
                group_id = "fun",
                path_icon = $"ui/Icons/iconAlchemist",
                needs_to_be_explored = false
            };
            alch.base_stats = new BaseStats();
            alch.base_stats.set("stewardship", 3f);
            alch.base_stats.set("intelligence", -3f);
            alch.action_attack_target = new AttackAction(TraitAttackActions.alchEffect);
            AssetManager.traits.add(alch);
//Void Touch
            ActorTrait voidtouch = new ActorTrait()
            {
                id = "Void Touch",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconVoidTouch",
                needs_to_be_explored = false
            };
            voidtouch.base_stats = new BaseStats();
            voidtouch.action_attack_target = new AttackAction(TraitAttackActions.instantKill);
            AssetManager.traits.add(voidtouch);
//Other Special Effect Actions Traits-------------------------------------------------------------------------------------------------------
//Hate Aura
            ActorTrait hateaura = new ActorTrait()
            {
                id = "Hate Aura",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconHateAura",
                needs_to_be_explored = false
            };
            hateaura.base_stats = new BaseStats();
            hateaura.base_stats.set("damage", 10f);
            hateaura.base_stats.set("warfare", 3f);
            hateaura.base_stats.set("diplomacy", -5f);
            hateaura.base_stats.set("stewardship", -5f);
            hateaura.action_special_effect = new WorldAction(TraitSpecialEffectActions.hateAuraEffect);
            AssetManager.traits.add(hateaura);
//Stoner
            ActorTrait stoner = new ActorTrait()
            {
                id = "Stoner",
                group_id = "cognitive",
                path_icon = $"ui/Icons/iconStoner",
                needs_to_be_explored = false
            };
            stoner.base_stats = new BaseStats();
            stoner.base_stats.set("armor", 5f);
            stoner.base_stats.set("damage", 3f);
            stoner.base_stats.set("intelligence", -3f);
            stoner.action_special_effect = new WorldAction(TraitSpecialEffectActions.highEffect);
            AssetManager.traits.add(stoner);
//Duplicator
            ActorTrait dupe = new ActorTrait()
            {
                id = "Duplicator",
                group_id = "fun",
                path_icon = $"ui/Icons/iconDuplicator",
                needs_to_be_explored = false
            };
            dupe.base_stats = new BaseStats();
            dupe.base_stats.set("loyalty_traits", -15f);
            dupe.base_stats.set("offspring", -20f);
            dupe.base_stats.set("multiplier_health", -0.5f);
            dupe.action_special_effect = new WorldAction(TraitSpecialEffectActions.cloneNow);
            AssetManager.traits.add(dupe);
//Clone
            ActorTrait unstableclone = new ActorTrait()
            {
                id = "Unstable Clone",
                group_id = "special",
                path_icon = $"ui/Icons/iconUnstableClone",
                needs_to_be_explored = false
            };
            unstableclone.base_stats = new BaseStats();
            unstableclone.base_stats.set("multiplier_speed", -0.5f);
            unstableclone.base_stats.set("multiplier_health", -0.75f);
            unstableclone.action_special_effect = new WorldAction(TraitSpecialEffectActions.cloneRemoveDupe);
            //clone.action_special_effect = new AttackAction(TraitSpecialEffectActions.cloneTryKillAndRemoveDupe);
            AssetManager.traits.add(unstableclone);
//Planter
            ActorTrait planter = new ActorTrait()
            {
                id = "Planter",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconPlanter",
                needs_to_be_explored = false
            };
            planter.action_special_effect = new WorldAction(TraitSpecialEffectActions.landmineFeetEffect);
            AssetManager.traits.add(planter);
//Chemist 
            ActorTrait chemist = new ActorTrait()
            {
                id = "Chemist",
                group_id = "fun",
                path_icon = $"ui/Icons/iconChemist",
                needs_to_be_explored = false
            };
            chemist.base_stats = new BaseStats();
            chemist.base_stats.set("intelligence", 3f);
            chemist.action_special_effect = new WorldAction(TraitSpecialEffectActions.chemistExperiment);
            chemist.special_effect_interval = 5f;
            AssetManager.traits.add(chemist);
//Lazy
            ActorTrait lazy = new ActorTrait()
            {
                id = "Lazy",
                group_id = "mind",
                path_icon = $"ui/Icons/iconLazy",
                needs_to_be_explored = false
            };
            lazy.base_stats = new BaseStats();
            lazy.base_stats.set("multiplier_health", 0.20f);
            lazy.base_stats.set("diplomacy", -1f);
            lazy.base_stats.set("stewardship", -1f);
            lazy.base_stats.set("warfare", -1f);
            lazy.base_stats.set("damage", -2f);
            lazy.base_stats.set("speed", -5f);
            lazy.base_stats.set("attack_speed", -30f);
            lazy.action_special_effect = new WorldAction(TraitSpecialEffectActions.addSleepyEffectOnSelf);
            AssetManager.traits.add(lazy);
//Mending 
            ActorTrait mending = new ActorTrait()
            {
                id = "Mending",
                group_id = "body",
                path_icon = $"ui/Icons/iconMending",
                needs_to_be_explored = false
            };
            mending.action_special_effect = new WorldAction(TraitSpecialEffectActions.removeCripple);
            AssetManager.traits.add(mending);
//Ocular Mutant
            ActorTrait ocularmutant = new ActorTrait()
            {
                id = "Ocular Mutant",
                group_id = "body",
                path_icon = $"ui/Icons/iconOcularMutant",
                needs_to_be_explored = false
            };
            ocularmutant.action_special_effect = new WorldAction(TraitSpecialEffectActions.removeNoEye);
            AssetManager.traits.add(ocularmutant);
//Other Traits-------------------------------------------------------------------------------------------------------
//Traits with a special effect or quirk beyond basic stats (not like action_special_effect)
//Zero Eyed
            ActorTrait zeroeye = new ActorTrait()
            {
                id = "Zero Eyed",
                group_id = "appearance",
                path_icon = $"ui/Icons/iconZeroEyed",
                same_trait_mod = 10,
                needs_to_be_explored = false
            };
            zeroeye.base_stats = new BaseStats();
            zeroeye.base_stats.set("diplomacy", 3f);
            zeroeye.base_stats.set("warfare", -3f);
            zeroeye.base_stats.set("attack_speed", -30f);
            zeroeye.base_stats.set("birth_rate", -2f);
            zeroeye.base_stats.set("critical_chance", -1f);
            AssetManager.traits.add(zeroeye);
//Acid Scar 
            ActorTrait acidburn = new ActorTrait()
            {
                id = "Acid Burn",
                group_id = "appearance",
                path_icon = $"ui/Icons/iconAcidBurn",
                same_trait_mod = 30,
                needs_to_be_explored = false
            };
            acidburn.base_stats = new BaseStats();
            acidburn.base_stats.set("warfare", 3f);
            acidburn.base_stats.set("speed", 3f);
            acidburn.base_stats.set("diplomacy", -5f);
            acidburn.base_stats.set("attack_speed", -5f);
            acidburn.base_stats.set("lifespan", -5f);
            acidburn.base_stats.set("birth_rate", -1f);
            acidburn.base_stats.set("offspring", 2f);
            AssetManager.traits.add(acidburn);
//Slowness Immunity
            ActorTrait slownessimm = new ActorTrait()
            {
                id = "Slowness Immunity",
                group_id = "protection",
                path_icon = $"ui/Icons/iconSlownessImmunity",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(slownessimm);

            StatusAsset slowness = AssetManager.status.get("slowness");
            slowness.opposite_traits = AssetLibrary<StatusAsset>.a<string>(new string[]
            {
                "Slowness Immunity"
            });
//Curse Immunity
            ActorTrait curseimmune = new ActorTrait()
            {
                id = "Curse Immunity",
                group_id = "protection",
                path_icon = $"ui/Icons/iconCurseImmunity",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(curseimmune);

            StatusAsset cursed = AssetManager.status.get("cursed");
            cursed.opposite_traits = AssetLibrary<StatusAsset>.a<string>(new string[]
            {
                "evil",
                "Curse Immunity"
            });
//Metamorph Immunity
            ActorTrait metamorphimm = new ActorTrait()
            {
                id = "Metamorph Immunity",
                group_id = "protection",
                path_icon = $"ui/Icons/iconTransmutationImmunity",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(metamorphimm);
//Infinity Immunity
            ActorTrait infintyimmunity = new ActorTrait()
            {
                id = "Infinity Immunity",
                group_id = "protection",
                path_icon = $"ui/Icons/iconInfinityImmunity",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(infintyimmunity);
//Natural Leader
            ActorTrait naturallead = new ActorTrait()
            {
                id = "Natural Leader",
                group_id = "cognitive",
                path_icon = $"ui/Icons/iconNaturalLeader",
                needs_to_be_explored = false
            };
            naturallead.base_stats = new BaseStats();
            naturallead.base_stats.set("warfare", 3f);
            naturallead.base_stats.set("diplomacy", 2f);
            naturallead.base_stats.set("stewardship", 2f);
            naturallead.base_stats.set("intelligence", 2f);
            AssetManager.traits.add(naturallead);
//Eternal Invincibility 
            ActorTrait eternalin = new ActorTrait()
            {
                id = "Eternal Invincibility",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconEternalInvincibility",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(eternalin);
//Air Fist
            ActorTrait airfist = new ActorTrait()
            {
                id = "Air Fist",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconAirFist",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(airfist);
//Curtain Mind
            ActorTrait curtainmind = new ActorTrait()
            {
                id = "Curtain Mind",
                group_id = "mind",
                path_icon = $"ui/Icons/iconCurtainMind",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(curtainmind);

            StatusAsset voicesinhead = AssetManager.status.get("voices_in_my_head");
            voicesinhead.opposite_traits = AssetLibrary<StatusAsset>.a<string>(new string[]
            {
                "Curtain Mind"
            });
//Youthful
            ActorTrait youthfl = new ActorTrait()
            {
                id = "Youthful",
                group_id = "cognitive",
                path_icon = $"ui/Icons/iconYouthful",
                same_trait_mod = 10,
                needs_to_be_explored = false
            };
            youthfl.base_stats = new BaseStats();
            youthfl.base_stats.set("birth_rate", -1f);
            youthfl.base_stats.set("diplomacy", -3f);
            AssetManager.traits.add(youthfl);
//Autotroph
            ActorTrait autofood = new ActorTrait()
            {
                id = "Autotroph",
                group_id = "body",
                path_icon = $"ui/Icons/iconAutotroph",
                needs_to_be_explored = false
            };
            autofood.addOpposite("Antitroph");
            AssetManager.traits.add(autofood);
//Antitroph
            ActorTrait antifood = new ActorTrait()
            {
                id = "Antitroph",
                group_id = "body",
                path_icon = $"ui/Icons/iconAntitroph",
                needs_to_be_explored = false
            };
            antifood.addOpposite("Autotroph");
            AssetManager.traits.add(antifood);
//Enhanced Mind
            ActorTrait enhancedmind = new ActorTrait() //always gains civil stats when aging
            {
                id = "Enhanced Mind",
                group_id = "mind",
                path_icon = $"ui/Icons/iconEnhancedMind",
                needs_to_be_explored = false
            };
            enhancedmind.base_stats = new BaseStats();
            enhancedmind.base_stats.set("intelligence", 3f);
            enhancedmind.addOpposite("Broken Mind");
            AssetManager.traits.add(enhancedmind);
//Broken Mind
            ActorTrait brokemind = new ActorTrait() //can't gain civil stats when aging
            {
                id = "Broken Mind",
                group_id = "mind",
                path_icon = $"ui/Icons/iconBrokenMind",
                needs_to_be_explored = false
            };
            brokemind.base_stats = new BaseStats();
            brokemind.base_stats.set("intelligence", -3f);
            brokemind.addOpposite("Enhanced Mind");
            AssetManager.traits.add(brokemind);
//Obsessed
            ActorTrait obsessed = new ActorTrait()
            {
                id = "Obsessed",
                group_id = "mind",
                path_icon = $"ui/Icons/iconObsessed",
                needs_to_be_explored = false
            };
            obsessed.base_stats = new BaseStats();
            obsessed.base_stats.set("warfare", 8f);
            obsessed.base_stats.set("stewardship", -5f);
            obsessed.base_stats.set("diplomacy", -10f);
            AssetManager.traits.add(obsessed);

            PlotAsset attackerstopwar = AssetManager.plots_library.get("attacker_stop_war");
            attackerstopwar.check_is_possible = ((Actor pActor) => pActor.kingdom.hasEnemies() && !pActor.hasTrait("Obsessed"));

//Immovable
            ActorTrait immovable = new ActorTrait()
            {
                id = "Immovable",
                group_id = "miscellaneous",
                path_icon = $"ui/Icons/iconImmovable",
                needs_to_be_explored = false
            };
            AssetManager.traits.add(immovable);
//Traits that just increase stats
//Microscopic
            ActorTrait microscopic = new ActorTrait()
            {
                id = "Microscopic",
                group_id = "physique",
                path_icon = $"ui/Icons/iconMicroscopic",
                needs_to_be_explored = false
            };
            microscopic.base_stats = new BaseStats();
            microscopic.base_stats.set("warfare", 5f);
            microscopic.base_stats.set("scale", -0.06f);
            microscopic.base_stats.set("speed", -5f);
            microscopic.base_stats.set("diplomacy", -10f);
            microscopic.base_stats.set("birth_rate", -5f);
            microscopic.base_stats.set("multiplier_health", -0.8f);
            AssetManager.traits.add(microscopic);
//Relaxed
            ActorTrait relaxed = new ActorTrait()
            {
                id = "Relaxed",
                group_id = "mind",
                path_icon = $"ui/Icons/iconRelaxed",
                same_trait_mod = 10,
                needs_to_be_explored = false
            };
            relaxed.base_stats = new BaseStats();
            relaxed.base_stats.set("loyalty_traits", 20f);
            relaxed.base_stats.set("lifespan", 5f);
            relaxed.base_stats.set("diplomacy", 5f);
            relaxed.base_stats.set("stewardship", -2f);
            relaxed.base_stats.set("damage", -5f);
            relaxed.base_stats.set("multiplier_supply_timer", -0.8f);
            AssetManager.traits.add(relaxed);
//Opportunistic
            ActorTrait opportunistic = new ActorTrait()
            {
                id = "Opportunistic",
                group_id = "mind",
                path_icon = $"ui/Icons/iconOpportunistic",
                needs_to_be_explored = false
            };
            opportunistic.base_stats = new BaseStats();
            opportunistic.base_stats.set("speed", 10f);
            opportunistic.base_stats.set("warfare", 5f);
            opportunistic.base_stats.set("diplomacy", 3f);
            opportunistic.base_stats.set("intelligence", 1f);
            opportunistic.base_stats.set("critical_chance", 0.25f);
            opportunistic.base_stats.set("loyalty_traits", -5f);
            AssetManager.traits.add(opportunistic);
//Loyal
            ActorTrait loyal = new ActorTrait()
            {
                id = "Loyal",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconLoyal",
                needs_to_be_explored = false
            };
            loyal.base_stats = new BaseStats();
            loyal.base_stats.set("loyalty_traits", 150f);
            loyal.base_stats.set("diplomacy", 3f);
            loyal.base_stats.set("stewardship", 1f);
            loyal.base_stats.set("intelligence", -2f);
            AssetManager.traits.add(loyal);
//Annoying
            ActorTrait annoying = new ActorTrait()
            {
                id = "Annoying",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconAnnoying",
                needs_to_be_explored = false
            };
            annoying.base_stats = new BaseStats();
            annoying.base_stats.set("attack_speed", 4f);
            annoying.base_stats.set("speed", 10f);
            annoying.base_stats.set("diplomacy", -3f);
            annoying.base_stats.set("stewardship", -5f);
            annoying.base_stats.set("critical_chance", -0.05f);
            annoying.base_stats.set("birth_rate", -1f);
            annoying.base_stats.set("multiplier_damage", -0.5f);
            AssetManager.traits.add(annoying);
//Glass Cannon
            ActorTrait glasscannon = new ActorTrait()
            {
                id = "Glass Cannon",
                group_id = "body",
                path_icon = $"ui/Icons/iconGlassCannon",
                needs_to_be_explored = false
            };
            glasscannon.base_stats = new BaseStats();
            glasscannon.base_stats.set("damage", 200f);
            glasscannon.base_stats.set("attack_speed", 3f);
            glasscannon.base_stats.set("critical_chance", 0.25f);
            glasscannon.base_stats.set("armor", -10f);
            glasscannon.base_stats.set("multiplier_health", -0.80f);
            AssetManager.traits.add(glasscannon);
//Unaware
            ActorTrait unaware = new ActorTrait()
            {
                id = "Unaware",
                group_id = "mind",
                path_icon = $"ui/Icons/iconUnaware",
                needs_to_be_explored = false
            };
            unaware.base_stats = new BaseStats();
            unaware.base_stats.set("speed", 25f);
            unaware.base_stats.set("attack_speed", -1f);
            unaware.base_stats.set("intelligence", -3f);
            unaware.base_stats.set("stewardship", -3f);
            unaware.base_stats.set("critical_chance", -0.25f);
            AssetManager.traits.add(unaware);
//Charismatic
            ActorTrait charismatic = new ActorTrait()
            {
                id = "Charismatic",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconCharismatic",
                needs_to_be_explored = false
            };
            charismatic.base_stats = new BaseStats();
            charismatic.base_stats.set("stewardship", 5f);
            charismatic.base_stats.set("diplomacy", 3f);
            charismatic.base_stats.set("critical_chance", 0.15f);
            charismatic.base_stats.set("multiplier_supply_timer", 1.25f);
            AssetManager.traits.add(charismatic);
//Rebel
            ActorTrait rebel = new ActorTrait()
            {
                id = "Rebel",
                group_id = "mind",
                path_icon = $"ui/Icons/iconRebel",
                needs_to_be_explored = false
            };
            rebel.base_stats = new BaseStats();
            rebel.base_stats.set("opinion", 10f);
            rebel.base_stats.set("stewardship", 3f);
            rebel.base_stats.set("warfare", 3f);
            rebel.base_stats.set("loyalty_traits", -100f);
            AssetManager.traits.add(rebel);
//Friendly
            ActorTrait friendly = new ActorTrait()
            {
                id = "Friendly",
                group_id = "spirit",
                path_icon = $"ui/Icons/iconFriendly",
                needs_to_be_explored = false
            };
            friendly.base_stats = new BaseStats();
            friendly.base_stats.set("loyalty_traits", 25f);
            friendly.base_stats.set("opinion", 10f);
            friendly.base_stats.set("diplomacy", 5f);
            friendly.base_stats.set("stewardship", 5f);
            friendly.base_stats.set("offspring", 1f);
            friendly.base_stats.set("birth_rate", 1f);
            friendly.base_stats.set("warfare", -5f);
            AssetManager.traits.add(friendly);
//Competitive
            ActorTrait competitive = new ActorTrait()
            {
                id = "Competitive",
                group_id = "mind",
                path_icon = $"ui/Icons/iconCompetitive",
                needs_to_be_explored = false
            };
            competitive.base_stats = new BaseStats();
            competitive.base_stats.set("warfare", 5f);
            competitive.base_stats.set("critical_chance", 0.10f);
            competitive.base_stats.set("stewardship", -2f);
            competitive.base_stats.set("loyalty_traits", -25f);
            AssetManager.traits.add(competitive);
//Resentful
            ActorTrait resentful = new ActorTrait()
            {
                id = "Resentful",
                group_id = "mind",
                path_icon = $"ui/Icons/iconResentful",
                needs_to_be_explored = false
            };
            resentful.base_stats = new BaseStats();
            resentful.base_stats.set("damage", 5f);
            resentful.base_stats.set("stewardship", -3f);
            resentful.base_stats.set("intelligence", -3f);
            resentful.base_stats.set("loyalty_traits", -50f);
            AssetManager.traits.add(resentful);
//Prideful
            ActorTrait prideful = new ActorTrait()
            {
                id = "Prideful",
                group_id = "mind",
                path_icon = $"ui/Icons/iconPrideful",
                needs_to_be_explored = false
            };
            prideful.base_stats = new BaseStats();
            prideful.base_stats.set("loyalty_traits", 50f);
            prideful.base_stats.set("stewardship", 10f);
            prideful.base_stats.set("speed", 5f);
            prideful.base_stats.set("damage", 3f);
            AssetManager.traits.add(prideful);
//Coward
            ActorTrait coward = new ActorTrait()
            {
                id = "Coward",
                group_id = "mind",
                path_icon = $"ui/Icons/iconCoward",
                needs_to_be_explored = false
            };
            coward.base_stats = new BaseStats();
            coward.base_stats.set("speed", 30f);
            coward.base_stats.set("stewardship", -2f);
            coward.base_stats.set("damage", -3f);
            coward.base_stats.set("loyalty_traits", -5f);
            coward.base_stats.set("scale", -0.02f);
            coward.base_stats.set("offspring", -2f);
            AssetManager.traits.add(coward);
        }
    }
}