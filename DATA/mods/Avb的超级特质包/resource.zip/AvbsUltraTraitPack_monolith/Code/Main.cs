using System;
// using System.IO;
// using System.Text;
// using System.Reflection;
// using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;

namespace avbultratraitspack{
    class Main : BasicMod<Main>{
        public static Main instance;
        static Harmony _harmony;
        protected override void OnModLoad(){
            Traits.init();
            _harmony = new Harmony("AvbTraits");
            _harmony.PatchAll();
        }
    }
//Patches-------------------------------------------------------------------------------------------------------
    [HarmonyPatch(typeof(Army), "findCaptain")]
    public class NaturalLeaderPatch1nocap{
        static bool Prefix(Army __instance)
        {
            if (__instance.hasCaptain())
            {
                if (__instance.captain.isKingdomCiv())
                {
                    return false;
                }
                __instance.setCaptain(null);
            }
            if (__instance.units.Count == 0)
            {
                return false;
            }
            Actor tBest;
            if (__instance._prev_captain_position == null)
            {
                tBest = __instance.units.GetRandom<Actor>();

				//__instance.units.doChecks();
				List<Actor> naturalLeaderList = new List<Actor>();
                System.Random rnd = new System.Random();
                foreach (Actor actorNL in __instance.units){
                    if (actorNL.isAlive()){
                        if(actorNL.hasTrait("Natural Leader")){
							naturalLeaderList.Add(actorNL);
						}
                    }
                }
				if (naturalLeaderList.Count > 0){
					int selectedActor = rnd.Next(naturalLeaderList.Count);
        			tBest = naturalLeaderList[selectedActor];
				}
            }
            else
            {
                tBest = __instance.getNearbyUnit(__instance._prev_captain_position);

            }
            if (tBest != null)
            {
                __instance.setCaptain(tBest);
            }
            return false;
        }
    }
    [HarmonyPatch(typeof(Army), "getNearbyUnit")]
    public class NaturalLeaderPatch2dedcap{
        static bool Prefix(MetaObject<ArmyData> __instance, ref Actor __result, WorldTile pLastPosition)
        {
            Actor tBest = null;
            int tBestFastDist = int.MaxValue;
            List<Actor> list = __instance.units;
            List<Actor> naturalLeaderList = new List<Actor>();
            foreach (Actor actor in list){
                if (actor.isAlive()){
                    if(actor.hasTrait("Natural Leader")){
						naturalLeaderList.Add(actor);
					}
                }
            }
            //Natural Leaders
            for (int i = 0; i < naturalLeaderList.Count; i++)
            {
                Actor tActor = naturalLeaderList[i];
                if (tActor.isAlive())
                {
                    int tFastDist = Toolbox.SquaredDistTile(tActor.current_tile, pLastPosition);
                    if (tFastDist < tBestFastDist)
                    {
                        tBest = tActor;
                        tBestFastDist = tFastDist;
                    }
                }
            }
            if (tBest != null){
                __result = tBest;
                return false;
            }
            //Normal Units
            for (int i = 0; i < list.Count; i++)
            {
                Actor tActor = list[i];
                if (tActor.isAlive())
                {
                    int tFastDist = Toolbox.SquaredDistTile(tActor.current_tile, pLastPosition);
                    if (tFastDist < tBestFastDist)
                    {
                        tBest = tActor;
                        tBestFastDist = tFastDist;
                    }
                }
            }
            __result = tBest;
            return false;
        }
    }
	[HarmonyPatch(typeof(Actor), "getHit")]
	public class EternalInvinceandZeroEye{
		static bool Prefix(Actor __instance, float pDamage, bool pFlash, AttackType pAttackType, BaseSimObject pAttacker = null, bool pSkipIfShake = true, bool pMetallicWeapon = false, bool pCheckDamageReduction = true)
    	{
            __instance._last_attack_type = pAttackType;
            if (__instance._cache_check_has_status_removed_on_damage)
            {
                foreach (Status tStatusData in __instance.getStatuses())
                {
                    if (tStatusData.asset.removed_on_damage && !tStatusData.is_finished)
                    {
                        __instance.finishStatusEffect(tStatusData.asset.id);
                    }
                }
            }
            if (DebugConfig.isOn(DebugOption.IgnoreDamage))
            {
                return false;
            }
            if (pSkipIfShake && __instance.shake_active)
            {
                return false;
            }
            __instance.attackedBy = null;
            if (pAttacker.isRekt())
            {
                pAttacker = null;
            }
            if (pAttacker != __instance)
            {
                __instance.attackedBy = pAttacker;
            }
            if (!__instance.hasHealth())
            {
                return false;
            }
            if (__instance.hasStatus("invincible"))
            {
                return false;
            }
            if (__instance.hasTrait("Eternal Invincibility"))
			{
				return false;
			}
			if(pAttacker != null && pAttacker != __instance && pAttacker.isActor() && !pAttacker.isRekt())
			{
				if (pAttacker.a.hasTrait("Air Fist"))
				{
					return false;
				}
			}
            Actor tAttackerUnit = (pAttacker != null) ? pAttacker.a : null;
            if (pAttackType == AttackType.Weapon)
            {
                bool tClank = false;
                if (pMetallicWeapon && __instance.haveMetallicWeapon())
                {
                    tClank = true;
                }
                if (tClank)
                {
                    MusicBox.playSound("event:/SFX/HIT/HitSwordSword", __instance.current_tile, false, true);
                }
                else if (__instance.asset.has_sound_hit)
                {
                    MusicBox.playSound(__instance.asset.sound_hit, __instance.current_tile, false, true);
                }
                if (tAttackerUnit != null && !__instance.hasStatus("shield"))
                {
                    __instance.damageEquipmentOnGetHit(tAttackerUnit);
                }
            }
            if (pCheckDamageReduction)
            {
                if (pAttackType == AttackType.Other || pAttackType == AttackType.Weapon)
                {
                    float tArmorPercent = 1f - __instance.stats["armor"] / 100f;
                    pDamage *= tArmorPercent;
                }
                if (pDamage < 1f)
                {
                    pDamage = 1f;
                }
                if (tAttackerUnit != null)
                {
                    float tFinalDamage;
                    __instance.checkSpecialAttackLogic(tAttackerUnit, pAttackType, pDamage, out tFinalDamage);
                    pDamage = tFinalDamage;
                    SignalManager.add(SignalLibrary.check_achievement_clone_wars, new ValueTuple<Actor, Actor>(__instance, tAttackerUnit));
                }
            }
            __instance.changeHealth((int)(-(int)pDamage));
            __instance.timer_action = 0.002f;
            GetHitAction getHitAction = __instance.s_get_hit_action;
            if (getHitAction != null)
            {
                getHitAction(__instance, pAttacker, __instance.current_tile);
            }
            if (pFlash)
            {
                __instance.startColorEffect(ActorColorEffect.Red);
            }
            if (!__instance.hasHealth())
            {
                __instance.batch.c_check_deaths.Add(__instance);
            }
            if (pAttackType == AttackType.Weapon && !__instance.asset.immune_to_injuries && !__instance.hasStatus("shield"))
            {
                if (Randy.randomChance(0.02f))
				{
					__instance.addInjuryTrait("crippled");
				}
				if (Randy.randomChance(0.02f) && !__instance.hasTrait("Zero Eyed"))
				{
					__instance.addInjuryTrait("eyepatch");
				}
				if (Randy.randomChance(0.01f) && __instance.hasTrait("eyepatch"))
				{
					__instance.removeTrait("eyepatch");
					__instance.addInjuryTrait("Zero Eyed");
				}
            }
            __instance.startShake(0.3f, 0.1f, true, true);
            if (!__instance.has_attack_target)
            {
                if (__instance.attackedBy != null && !__instance.shouldIgnoreTarget(__instance.attackedBy) && __instance.canAttackTarget(__instance.attackedBy, false))
                {
                    __instance.setAttackTarget(__instance.attackedBy);
                }
            }
            else if (__instance.hasMeleeAttack() && __instance.attackedBy != null && __instance.canAttackTarget(__instance.attackedBy, false))
            {
                float tDistToCurrentTarget = Toolbox.SquaredDistVec2Float(__instance.current_position, __instance.attack_target.current_position);
                float tDistToAttacker = Toolbox.SquaredDistVec2Float(__instance.current_position, pAttacker.current_position);
                if (tDistToCurrentTarget > __instance.getAttackRangeSquared() && tDistToAttacker < tDistToCurrentTarget)
                {
                    __instance.setAttackTarget(pAttacker);
                }
            }
            if (__instance.hasAnyStatusEffect())
            {
                foreach (Status status in __instance.getStatuses())
                {
                    GetHitAction action_get_hit = status.asset.action_get_hit;
                    if (action_get_hit != null)
                    {
                        action_get_hit(__instance, pAttacker, __instance.current_tile);
                    }
                }
            }
            GetHitAction action_get_hit2 = __instance.asset.action_get_hit;
            if (action_get_hit2 != null)
            {
                action_get_hit2(__instance, pAttacker, __instance.current_tile);
            }
            if (!__instance.hasHealth())
            {
                __instance.checkCallbacksOnDeath();
            }
            return false;
		}
	}
	[HarmonyPatch(typeof(DropsLibrary), "action_acid")]
	public class AcidBurnPatch{
		static bool Prefix(WorldTile pTile = null, string pDropID = null)
    	{
            MapAction.checkAcidTerraform(pTile);
            if (Randy.randomChance(0.2f))
            {
                World.world.particles_smoke.spawn(pTile.posV3);
            }
            if (pTile.hasBuilding() && pTile.building.asset.affected_by_acid && pTile.building.isAlive())
            {
                pTile.building.getHit(20f, true, AttackType.Other, null, true, false, true);
            }
            foreach (Actor tActor in Finder.getUnitsFromChunk(pTile, 1, 3f, false))
            {
                if (!Randy.randomChance(0.6f) && !tActor.hasTrait("acid_proof") && !tActor.hasTrait("acid_blood"))
                {
                    tActor.getHit(20f, true, AttackType.Acid, null, true, false, true);
					if (!tActor.hasTrait("Acid Burn") && Randy.randomChance(0.3f)){
						tActor.addTrait("Acid Burn", false);
					}
                }
            }
            World.world.conway_layer.checkKillRange(pTile.pos, 2);
            BiomeAsset biome = pTile.getBiome();
            if (biome != null && biome.spread_by_drops_acid)
            {
                WorldBehaviourActionBiomes.trySpreadBiomeAround(pTile, pTile, false, false, true);
            }
            return false;
		}
	}
	[HarmonyPatch(typeof(Actor), "isAlreadyTransformed")]
	public class transimmPatch{
		static bool Prefix(Actor __instance, ref bool __result)
    	{
            
            if (__instance.hasTrait("Transmutation Immunity")){
				__result = true;
                return false;
			}
			return true;
		}
	}
	[HarmonyPatch(typeof(Actor), "updateAge")]
	public class wiseforyouthFix{
		static bool Prefix(Actor __instance)
    	{
            __instance.checkGrowthEvent();
            float tAge = (float)__instance.getAge();
            if (__instance.hasSubspecies())
            {
                WorldAction action_growth = __instance.subspecies.action_growth;
                if (action_growth != null)
                {
                    action_growth(__instance, __instance.current_tile);
                }
                __instance.updateAttributes();
            }
            if (__instance.hasCity())
            {
                if (__instance.isKing())
                {
                    __instance.addExperience(20);
                }
                if (__instance.isCityLeader())
                {
                    __instance.addExperience(10);
                }
            }
            if (__instance.isSapient() && tAge > 300f && __instance.hasTrait("immortal") && Randy.randomBool())
            {
                __instance.addTrait("evil", false);
            }
            if (tAge > 40f && Randy.randomChance(0.3f) && !__instance.hasTrait("Youthful"))
            {
                __instance.addTrait("wise", false);
            }
            return false;
		}
	}
	[HarmonyPatch(typeof(Actor), "decreaseNutrition")]
	public class immunetohungertraitFix{
		static bool Prefix(Actor __instance, int pValue = -1)
    	{
			if (__instance.hasTrait("Autotroph"))
			{
				__instance.data.nutrition = 100;
                if(__instance.subspecies.hasTrait("big_stomach")){
                    __instance.data.nutrition = 200;
                }
			}
			else if (__instance.hasTrait("Antitroph"))
			{
				__instance.data.nutrition = 0;
			}
            else { 
                __instance.setNutrition(__instance.getNutrition() - pValue, true);
            }
			return false;
		}
	}
	[HarmonyPatch(typeof(Actor), "updateAttributes")]
	public class hundredcapFix{
		static bool Prefix(Actor __instance)
    	{
            if (!Randy.randomChance(0.3f) && !__instance.hasTrait("Enduring Mind"))
            {
                return false;
            }
            if (__instance.hasTrait("Broken Mind")){
                return false;
            }
            string tAttribute = __instance.subspecies.getPossibleAttribute();
            if (string.IsNullOrEmpty(tAttribute))
            {
                return false;
            }
            ActorData actorData = __instance.data;
            string pKey = tAttribute;
            float num = actorData[pKey];
            actorData[pKey] = num + 1f;
            return false;
	    }
    }
	[HarmonyPatch(typeof(Actor), "addForce")]
	public class immovableFix{
		static bool Prefix(Actor __instance, float pX, float pY, float pHeight, bool pCheckLandCancelAllActions = false)
    	{
            if (!__instance.asset.can_be_moved_by_powers)
            {
                return false;
            }
            if (__instance.hasTrait("Immovable"))
            {
                return false;
            }
            if (pCheckLandCancelAllActions)
            {
                __instance.setCheckLanding();
            }
            if (__instance.position_height > 0f)
            {
                return false;
            }
            __instance.velocity.x = pX;
            __instance.velocity.y = pY;
            __instance.velocity.z = pHeight;
            __instance.velocity_speed = pHeight;
            __instance.under_forces = true;
            return false;
	    }
    }
	[HarmonyPatch(typeof(EffectInfinityCoin), "doAction")]
	public class infinityImmFix{
		static bool Prefix()
    	{
            int tTotal = 0;
            List<Actor> tActorList = World.world.units.getSimpleList();
            for (int i = 0; i < tActorList.Count; i++)
            {
                Actor tActor = tActorList[i];
                if (tActor.isAlive() && !tActor.isFavorite() && !tActor.asset.ignored_by_infinity_coin && !tActor.hasTrait("Infinity Immunity") && !tActor.hasTrait("Eternal Invincibility"))
                {
                    tTotal++;
                }
            }
            int tToRemove;
            if (tTotal % 2 == 0)
            {
                tToRemove = tTotal / 2;
            }
            else
            {
                tToRemove = tTotal / 2 + 1;
            }
            int tKilled = 0;
            EffectInfinityCoin._temp_list.AddRange(World.world.units);
            for (int j = 0; j < EffectInfinityCoin._temp_list.Count; j++)
            {
                EffectInfinityCoin._temp_list.ShuffleOne(j);
                Actor tAc = EffectInfinityCoin._temp_list[j];
                if (tToRemove == 0)
                {
                    break;
                }
                if (tAc.isAlive() && !tAc.isFavorite() && !tAc.asset.ignored_by_infinity_coin && !tAc.hasTrait("Infinity Immunity") && !tAc.hasTrait("Eternal Invincibility"))
                {
                    tKilled++;
                    tToRemove--;
                    tAc.getHitFullHealth(AttackType.Divine);
                }
            }
            WorldTip.addWordReplacement("$removed$", tKilled.ToString());
            WorldTip.showNow("infinity_coin_used", true, "top", 3f, "#F3961F");
            //WorldTip.showNow("cool color test", true, "top", 3f, "#13e240ff");
            EffectInfinityCoin._temp_list.Clear();
            return false;
		}
	}
//Postfixes
	[HarmonyPatch(typeof(ActionLibrary), "startCrabzillaNuke")]
	public class CrabzillaSlayerPatch{
		static void Postfix(BaseSimObject pTarget, WorldTile pTile = null)
    	{
			bool checkS = true;
			if (pTarget == null || !pTarget.isActor())
	    	{
	    		checkS = false;
	    	}
	    	BaseSimObject attackedBy = pTarget.a.attackedBy;
	    	if (attackedBy != null && attackedBy.isActor() && attackedBy.isAlive() && checkS == true)
	    	{
	    		attackedBy.a.addTrait("Boss Slayer", false);
                pTarget.a.getHitFullHealth(AttackType.Divine);
	    	}
		}
	}
}