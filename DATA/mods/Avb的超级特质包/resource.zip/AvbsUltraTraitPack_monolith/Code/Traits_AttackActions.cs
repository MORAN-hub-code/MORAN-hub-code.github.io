using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using UnityEngine.Analytics;
using NeoModLoader;
using NeoModLoader.General;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ReflectionUtility;
using HarmonyLib;
using ai;

namespace avbultratraitspack{
    internal static class TraitAttackActions{
    	public static bool addBurningEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null){
			if (Randy.randomChance(0.3f))
			{
				if (pTarget.isBuilding() && pTarget.b.asset.burnable)
				{
					pTarget.b.addStatusEffect("burning", -1f);
					return true;
				}
				if (pTarget.isActor())
				{
					pTarget.a.addStatusEffect("burning", -1f);
					return true;
				}
			}
			return false;
		}
		public static bool addFrozenEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null){
			if (pTarget.isBuilding() || !pTarget.isActor())
			{
				return false;
			}
			if (pTarget.current_tile.Type.lava)
			{
				return false;
			}
			if (pTarget.current_tile.isOnFire())
			{
				return false;
			}
			if (pTarget.a.hasTrait("freeze_proof"))
			{
				return false;
			}
			if (Randy.randomChance(0.3f))
			{
				pTarget.a.addStatusEffect("frozen", -1f);
			}
			return false;
		}
    	public static bool addSlowEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
			{
			if (pTarget.isBuilding() || !pTarget.isActor())
			{
				return false;
			}
        	if (Randy.randomChance(0.3f))
			{
				pTarget.a.addStatusEffect("slowness", -1f);
			}
        	return false;
		}
		public static bool unpredictableRoll(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null){
        	bool burning = true;
        	bool frozen = true;
        	bool poisoned = true;
        	bool slowness = true;
        	List<string> statusListCustom = new List<string>();
        	System.Random rnd = new System.Random();
        	if (pTarget.isBuilding() || !pTarget.isActor())
        	{
				frozen = false;
        	    poisoned = false;
        	    slowness = false;
			}
        	if (pTarget.a.hasTrait("fire_proof"))
			{
				burning = false;
			}
        	else if (pTarget.isBuilding() && !pTarget.b.asset.burnable)
			{
				burning = false;
			}//end of burning check
        	if (pTarget.a.hasTrait("freeze_proof"))
			{
				frozen = false;
			}
        	else if (pTarget.current_tile.Type.lava)
			{
				frozen = false;
			}
        	else if (pTarget.current_tile.isOnFire())
			{
				frozen = false;
			}//end of frozen check
        	if (pTarget.a.hasTrait("poison_immune"))
			{
				poisoned = false;
			}
        	if (!pTarget.a.asset.has_skin)
			{
				poisoned = false;
			}
			if (pTarget.a.asset.immune_to_injuries)
			{
				poisoned = false;
			}//end of poisoned check
        	if (pTarget.a.hasTrait("Slowness Immunity"))
			{
			slowness = false;
			}//end of slowness check
        	if (burning == false || frozen == false || poisoned == false || slowness == false){
        	    return false;
        	}
        	else {
        	    if (burning = true){
        	        string sburning = "burning";
        	        statusListCustom.Add(sburning);
        	    }
        	    if (frozen = true){
        	        string sfrozen = "frozen";
        	        statusListCustom.Add(sfrozen);
        	    }
        	    if (poisoned = true){
        	        string spoisoned = "poisoned";
        	        statusListCustom.Add(spoisoned);
        	    }
        	    if (slowness = true){
        	        string sslowness = "slowness";
        	        statusListCustom.Add(sslowness);
        	    }
        	}
        	int selectedStatus = rnd.Next(statusListCustom.Count);
        	if(Randy.randomChance(0.25f)){
        	pTarget.a.addStatusEffect(statusListCustom[selectedStatus], -1f);
        	}
        	return false;
   		}
        public static bool addDepressedEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
			{
			if (pTarget.isBuilding() || !pTarget.isActor())
			{
				return false;
			}
        	if (Randy.randomChance(0.05f))
			{
				pTarget.a.addStatusEffect("depressed", -1f);
			}
        	return false;
		}
        public static bool addBleedEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null){
			if (pTarget.isBuilding() || !pTarget.isActor())
			{
				return false;
			}
			if (pTarget.a.hasTrait("tough"))
			{
				return false;
			}
			if (Randy.randomChance(0.3f))
			{
				pTarget.a.addStatusEffect("tbleeding", -1f);
			}
			return false;
		}
		public static bool bleedingEffect(BaseSimObject pTarget, WorldTile pTile = null)
		{
			int num = (int)((float)pTarget.getMaxHealth() * 0.1f) + 1;
			pTarget.getHit((float)num, true, AttackType.Fire, null, true, false);   
			return true;
		}
        public static bool restoreHealthOnHit2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (pTarget == null)
		    {
		    	return false;
		    }
		    if (!pTarget.isActor())
		    {
		    	return false;
		    }
		    if (!pSelf.isActor())
		    {
		    	return false;
		    }
		    int num = (int)((float)pTarget.a.getHealth() * 0.25f) + 1;
		    num = Mathf.Clamp(num, 0, pSelf.a.getMaxHealth());
		    pSelf.a.restoreHealth(num);
		    return true;
	    }
        public static bool loseHealthOnHit(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if(pSelf.a.hasTrait("Eternal Invincibility"))
			{
				return false;
			}
			if (pTarget == null)
		    {
		    	return false;
		    }
		    if (!pTarget.isActor())
		    {
		    	return false;
		    }
		    if (!pSelf.isActor())
		    {
		    	return false;
		    }
		    int num = (int)((float)pSelf.a.data.health * 0.05f) + 1;
		    num = Mathf.Clamp(num, 1, pSelf.a.getMaxHealth());
		    pSelf.a.data.health -= num;
			if(pSelf.a.data.health <= 0){
				pSelf.a.getHitFullHealth(AttackType.Divine);
			}
		    return true;
	    }
        public static bool alchEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (pTarget == null)
		    {
		    	return false;
		    }
		    if (!pTarget.isActor())
		    {
		    	return false;
		    }
		    if (!pSelf.isActor())
		    {
		    	return false;
		    }
            Actor a = pTarget.a;
			foreach (ActorTrait tTrait in a.getTraits())
			{
				if(tTrait.id == "Replicative Immortality" || tTrait.id == "Eternal Invincibility" || tTrait.id == "Transmutation Immunity")
				{
                    return false;
                }
			}
            if (Randy.randomChance(0.03f))
		    {
                WorldTile current_tile = pTarget.a.current_tile;
                TraitAttackActions.growMineralGold(current_tile, false, false);
				pTarget.a.getHitFullHealth(AttackType.Divine);
                pSelf.a.data.kills++;
		    }
		    return true;
	    }
        public static void growMineralGold(WorldTile pTile, bool pOnStart = false, bool pCheckLimit = true)
	    {
		World.world.buildings.addBuilding("mineral_gold", pTile, false, false, BuildPlacingType.New);
	    }
        public static bool instantKill(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (pTarget == null)
		    {
		    	return false;
		    }
		    if (!pTarget.isActor())
		    {
		    	return false;
		    }
		    if (!pSelf.isActor())
		    {
		    	return false;
		    }
			pTarget.a.getHitFullHealth(AttackType.Divine);
            pSelf.a.data.kills++;
		    return true;
	    }
		public static bool addShockEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null){
			if (pTarget.isBuilding() || !pTarget.isActor())
			{
				return false;
			}
			if (Randy.randomChance(0.2f))
			{
				pTarget.a.addStatusEffect("stunned", 3f, true);
			}
			if (Randy.randomChance(0.35f)){
				pTarget.a.addStatusEffect("recovery_spell", 2f, true);
				pTarget.a.addStatusEffect("recovery_combat_action", 1f, true);
			}
			return false;
		}
    }
}
