﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Tilemaps;
using HarmonyLib;

namespace WarriorWorld.code
{
    internal static class stats
    {

        public static void Init()
        {
            BaseStatAsset mana = AssetManager.base_stats_library.get("mana");
            mana.normalize_max = 2100000000;

            BaseStatAsset stamina = AssetManager.base_stats_library.get("stamina");
            stamina.normalize_max = 2100000000;

            BaseStatAsset diplomacy = AssetManager.base_stats_library.get("diplomacy");
            diplomacy.normalize_max = 2100000000;

            BaseStatAsset warfare = AssetManager.base_stats_library.get("warfare");
            warfare.normalize_max = 2100000000;

            BaseStatAsset stewardship = AssetManager.base_stats_library.get("stewardship");
            stewardship.normalize_max = 2100000000;

            BaseStatAsset intelligence = AssetManager.base_stats_library.get("intelligence");
            intelligence.normalize_max = 2100000000;

            BaseStatAsset health = AssetManager.base_stats_library.get("health");
            health.normalize_max = 2100000000;

            BaseStatAsset damage = AssetManager.base_stats_library.get("damage");
            damage.normalize_max = 210000000;

            BaseStatAsset critical_chance = AssetManager.base_stats_library.get("critical_chance");
            critical_chance.normalize_max = 21000000;

            // 初始化 Harmony 补丁
            var harmony = new Harmony("warriorworld.stats.patch");
            harmony.PatchAll();
        }
    }

    // 金币上限补丁
    [HarmonyPatch(typeof(Actor), "addMoney")]
    public class Patch_Actor_addMoney
    {
        [HarmonyPrefix]
        public static bool Prefix(Actor __instance, int pValue)
        {
            if (pValue == 0)
                return false; // 跳过原方法

            __instance.data.money += pValue;
            // 21亿上限
            __instance.data.money = Mathf.Clamp(__instance.data.money, 0, 2100000000);
            EffectsLibrary.showMoneyEffect("fx_money_got_money", __instance.current_position, __instance.current_zone, __instance.actor_scale);
            return false; // 跳过原方法
        }
    }

    // 等级上限补丁
    [HarmonyPatch(typeof(Actor), "getMaxPossibleLevel", MethodType.Normal)]
    public class Patch_Actor_getMaxPossibleLevel
    {
        [HarmonyPostfix]
        public static void Postfix(ref int __result)
        {
            __result = 2100000000; // 21亿
        }
    }
}