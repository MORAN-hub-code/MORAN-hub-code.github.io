using NCMS;
using UnityEngine;
using HarmonyLib;
using System;
using System.Collections.Generic;
using NeoModLoader.api;
using NeoModLoader.constants;
namespace Ayoooo
{
    class Main : MonoBehaviour, IMod
    {
        static readonly List<string> SoundFiles = new List<string>()
        {
            "CatGirl1",
            "CatGirl2",
            "Baka",
            "OniChan"
        };
        [HarmonyPrefix]
        [HarmonyPatch(typeof(MusicBox), nameof(MusicBox.playSound), new Type[] { typeof(string), typeof(float), typeof(float), typeof(bool), typeof(bool) })]
        [HarmonyPriority(Priority.High)]
        static void ReplaceSounds(ref string pSoundPath)
        {
            pSoundPath = SoundFiles.GetRandom();
        }

        public ModDeclare GetDeclaration()
        {
            return modDeclare;
        }

        public GameObject GetGameObject()
        {
            return transform.gameObject;
        }

        public string GetUrl()
        {
            return "https://www.youtube.com/watch?v=dQw4w9WgXcQ";
        }

        ModDeclare modDeclare;

        public void OnLoad(ModDeclare pModDecl, GameObject pGameObject)
        {
            modDeclare = pModDecl;
            Harmony.CreateAndPatchAll(typeof(Main));
        }
    }
}
