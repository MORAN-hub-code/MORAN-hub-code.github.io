namespace Cultiway.Abstract;

public abstract class ExtendComponentManager<TExtendComponent>
{
}