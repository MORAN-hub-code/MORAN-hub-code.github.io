namespace Cultiway.Abstract;

public interface ICanInit
{
    public void Init();
}