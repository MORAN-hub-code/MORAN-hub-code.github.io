using System;

namespace Cultiway.Abstract;

public class IgnoreDeepCopyAttribute : Attribute
{
}