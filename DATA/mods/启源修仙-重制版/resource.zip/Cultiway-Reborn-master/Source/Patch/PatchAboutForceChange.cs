using Cultiway.Core.Components;
using Cultiway.Utils.Extension;
using HarmonyLib;

namespace Cultiway.Patch;

internal static class PatchAboutForceChange
{
}