namespace Cultiway.Const;

public static class DamageIndex
{
    public const int Iron  = 0;
    public const int Wood  = 1;
    public const int Water = 2;
    public const int Fire  = 3;
    public const int Earth = 4;
    public const int Soul  = 5;
}