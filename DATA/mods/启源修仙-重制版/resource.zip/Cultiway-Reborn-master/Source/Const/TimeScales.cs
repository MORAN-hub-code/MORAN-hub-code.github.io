namespace Cultiway.Const;

public static class TimeScales
{
    public const float SecPerMonth = 5f;
    public const float SecPerYear = SecPerMonth * 12;
    public static bool precise_simulate = false;
}