namespace Cultiway.Content.Libraries;

public class YuanyingAsset : Asset
{
    
}