namespace Cultiway.Content.Const;

public enum ElixirEffectType
{
    DataGain,
    StatusGain,
    DataChange,
    Restore
}