using Cultiway.Core.SkillLibV2;
using Cultiway.Core.SkillLibV2.Extensions;
using UnityEngine;

namespace Cultiway.Utils.ProjectionSkillTools;

public partial class ProjectionSkillTool
{
    public ProjectionSkillTool AddTrajectory()
    {
        return this;
    }
}