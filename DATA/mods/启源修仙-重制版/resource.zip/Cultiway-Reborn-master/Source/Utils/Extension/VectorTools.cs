namespace Cultiway.Utils.Extension;

public class VectorTools
{
    
}