namespace Cultiway.LocaleKeys.UI.Window;

public class Locale : LocalComponent
{
    [Postfix(" Title")] public LocalComponent WindowNewCreatureInfo;
}