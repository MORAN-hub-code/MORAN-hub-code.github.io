namespace Cultiway.AbstractGame.AbstractEngine;

public abstract class AEngine
{
}