namespace Cultiway.Core.SkillLibV2.Api;

public interface IHasObserver
{
    public int GetObserverCode();
}