using Friflo.Engine.ECS;

namespace Cultiway.Core.SkillLibV2.Components;

public struct ColliderComponent : IComponent
{
    public ColliderType type;
}