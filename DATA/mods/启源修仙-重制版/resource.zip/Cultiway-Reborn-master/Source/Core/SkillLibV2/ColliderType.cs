namespace Cultiway.Core.SkillLibV2;

public enum ColliderType
{
    Sphere,
    Box
}