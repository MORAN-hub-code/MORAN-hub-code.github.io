namespace Cultiway.Core.SkillLibV2.Predefined;

public static class SkillEntities
{
    internal static void Init()
    {
    }
}