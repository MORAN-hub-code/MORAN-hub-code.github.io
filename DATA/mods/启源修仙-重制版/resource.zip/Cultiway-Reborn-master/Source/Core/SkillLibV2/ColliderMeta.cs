using Friflo.Engine.ECS;

namespace Cultiway.Core.SkillLibV2;

public class ColliderMeta<TColliderComponent> where TColliderComponent : struct, IComponent
{
}