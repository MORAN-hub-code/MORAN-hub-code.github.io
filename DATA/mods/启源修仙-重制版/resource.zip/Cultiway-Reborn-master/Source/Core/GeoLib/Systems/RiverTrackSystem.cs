using Cultiway.Core.Components;
using Friflo.Engine.ECS.Systems;

namespace Cultiway.Core.GeoLib.Systems;

public class RiverTrackSystem : QuerySystem<TileBinder>
{
    protected override void OnUpdate()
    {
    }
}