namespace Cultiway.Core.Libraries;

public class RandomEventLibrary : AssetLibrary<RandomEventAsset>
{
}