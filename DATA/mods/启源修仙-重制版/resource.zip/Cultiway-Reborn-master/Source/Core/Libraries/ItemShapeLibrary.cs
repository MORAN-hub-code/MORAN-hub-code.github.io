namespace Cultiway.Core.Libraries;

public class ItemShapeLibrary : AssetLibrary<ItemShapeAsset>
{
}