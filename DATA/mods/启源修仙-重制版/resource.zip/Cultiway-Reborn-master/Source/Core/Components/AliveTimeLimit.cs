using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct AliveTimeLimit : IComponent
{
    public float value;
}