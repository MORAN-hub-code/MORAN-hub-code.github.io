using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct AliveTimer : IComponent
{
    public float value;
}