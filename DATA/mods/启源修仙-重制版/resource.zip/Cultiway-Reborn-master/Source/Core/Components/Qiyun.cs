using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct Qiyun : IComponent
{
    public float MaxValue;
    public float Value;
}