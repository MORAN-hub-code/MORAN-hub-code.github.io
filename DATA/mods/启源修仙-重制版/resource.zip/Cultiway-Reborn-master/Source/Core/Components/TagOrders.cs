using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct TagOrder1 : ITag;

public struct TagOrder2 : ITag;

public struct TagOrder3 : ITag;

public struct TagOrder4 : ITag;

public struct TagOrder5 : ITag;