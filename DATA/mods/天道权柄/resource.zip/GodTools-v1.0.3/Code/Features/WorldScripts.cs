using GodTools.Abstract;

namespace GodTools.Features;

public class WorldScripts : IManager
{
    public void Initialize()
    {
    }
}