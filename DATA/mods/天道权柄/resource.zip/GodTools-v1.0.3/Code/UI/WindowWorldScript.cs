using NeoModLoader.api;

namespace GodTools.UI;

public class WindowWorldScript : AbstractWideWindow<WindowWorldScript>
{
    protected override void Init()
    {
        
    }
}