﻿using Narutobox;
using Narutobox.Content;
using NarutoboxRevised.Content.Config;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using System;
using System.Collections.Generic;
using UnityEngine;


namespace NarutoboxRevised.Content.Traits;

internal static class CustomTraits
{
    private static string Identifier = NarutoBoxMain.Identifier;

    private static string TraitGroupId = $"{Identifier}_narutobox_revised";
    private static string TraitGroupIdLegend = $"{Identifier}_narutobox_revised_legend";
    private static string TraitGroupIdShinobi = $"{Identifier}_narutobox_revised_shinobi";
    private static string TraitGroupIdChakra = $"{Identifier}_narutobox_revised_chakra";
    private static string TraitGroupIdClan = $"{Identifier}_narutobox_revised_clan";

    private static string PathToTraitIcon = "ui/Icons/actor_traits/narutobox_revised_traits";


    private static int NoChance = 0;
    private static int Rare = 3;
    private static int LowChance = 15;
    private static int MediumChance = 30;
    private static int ExtraChance = 45;
    private static int HighChance = 75;
    private static int AlwaysChance = 100;

    [Hotfixable]
    public static void Init()
    {
        loadCustomTraitGroup();
        loadCustomTrait();
        loadCustomTraitShinobi();
        loadCustomTraitClans();
        loadCustomLegendTraits();
        loadCustomTraitChakra();
    }


    private static void loadCustomTraitGroup()
    {
        ActorTraitGroupAsset group = new ActorTraitGroupAsset()
        {
            id = TraitGroupId,
            name = $"trait_group_{TraitGroupId}",
            color = "#ff9500",
        };
        // Add trait group to trait group library
        AssetManager.trait_groups.add(group);

        ActorTraitGroupAsset group2 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdLegend,
            name = $"trait_group_{TraitGroupIdLegend}",
            color = "#fc0303",
        };
        AssetManager.trait_groups.add(group2);

        ActorTraitGroupAsset group3 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdShinobi,
            name = $"trait_group_{TraitGroupIdShinobi}",
            color = "#ffae00",
        };
        AssetManager.trait_groups.add(group3);
        ActorTraitGroupAsset group4 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdChakra,
            name = $"trait_group_{TraitGroupIdChakra}",
            color = "#f00a5e",
        };
        AssetManager.trait_groups.add(group4);

        ActorTraitGroupAsset group5 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdClan,
            name = $"trait_group_{TraitGroupIdClan}",
            color = "#f00a5e",
        };
        AssetManager.trait_groups.add(group5);
    }

    private static void loadCustomTrait()
    {
        #region lionstyle
        ActorTrait lionstyle = new ActorTrait()
        {
            id = $"{Identifier}_lionstyle",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/lionstyle",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
        };

        lionstyle.base_stats = new BaseStats();
        lionstyle.base_stats.set(CustomBaseStatsConstant.Damage, 100f);
        lionstyle.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        lionstyle.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.3f);
        lionstyle.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 0.5f);
        lionstyle.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.3f);
        lionstyle.base_stats.set(CustomBaseStatsConstant.Speed, 30f);

        lionstyle.addOpposites(new List<string> { $"{Identifier}_uhboss", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3" });

        lionstyle.type = TraitType.Positive;
        lionstyle.unlock(true);
        lionstyle.action_special_effect = (WorldAction)Delegate.Combine(lionstyle.action_special_effect, new WorldAction(CustomTraitActions.lionstyleSpecialEffect));
        lionstyle.action_attack_target = new AttackAction(CustomTraitActions.lionstyleAttackEffect);
        AssetManager.traits.add(lionstyle);
        addToLocale(lionstyle.id, "lionstyle", "lionstyle No Jutsu! The true leaders of leoin clan, with special abilities of wood and the ultimate bloodline of leoin!");
        #endregion

        #region cell
        ActorTrait cell = new ActorTrait()
        {
            id = $"{Identifier}_cell",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Cell",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
        };
        cell.base_stats = new BaseStats();
        cell.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        cell.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.9f);
        cell.type = TraitType.Other;
        cell.unlock(true);
        cell.action_special_effect = (WorldAction)Delegate.Combine(cell.action_special_effect, new WorldAction(CustomTraitActions.cellSpecialEffect));
        AssetManager.traits.add(cell);
        addToLocale(cell.id, "ranksigma's Cell", "The blood cell of The Ninja God! Give this trait to rankX to unlock ultimate form!");
        #endregion

        #region survive1
        ActorTrait survive1 = new ActorTrait()
        {
            id = $"{Identifier}_survive1",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/survive1",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
        };

        survive1.base_stats = new BaseStats();
        survive1.base_stats.set(CustomBaseStatsConstant.Damage, 25f);
        survive1.base_stats.set(CustomBaseStatsConstant.Armor, 5f);
        survive1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        survive1.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        survive1.base_stats.set(CustomBaseStatsConstant.Intelligence, 20f);
        survive1.base_stats.set(CustomBaseStatsConstant.Speed, 10f);

        survive1.type = TraitType.Positive;
        survive1.unlock(true);

        survive1.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive2", $"{Identifier}_survive3" });
        survive1.action_attack_target = new AttackAction(CustomTraitActions.sharingan1AttackEffect);
        survive1.action_special_effect = (WorldAction)Delegate.Combine(survive1.action_special_effect, new WorldAction(CustomTraitActions.sharingan1SpecialEffect));

        AssetManager.traits.add(survive1);
        addToLocale(survive1.id, "Sharingan 1", "The Eyes Of The uhboss! Can slow enemy and make them stop whatever they are doing!", "Have small chance to evolve into Sharingan level 2 in fiercest battles or through sheer luck!");
        #endregion

        #region survive2
        ActorTrait survive2 = new ActorTrait()
        {
            id = $"{Identifier}_survive2",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/survive2",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
        };

        survive2.base_stats = new BaseStats();
        survive2.base_stats.set(CustomBaseStatsConstant.Damage, 95f);
        survive2.base_stats.set(CustomBaseStatsConstant.Armor, 10f);
        survive2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        survive2.base_stats.set(CustomBaseStatsConstant.Health, 150f);
        survive2.base_stats.set(CustomBaseStatsConstant.Intelligence, 40f);
        survive2.base_stats.set(CustomBaseStatsConstant.Speed, 15f);

        survive2.type = TraitType.Positive;
        survive2.unlock(true);

        survive2.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive3" });
        survive2.action_attack_target = new AttackAction(CustomTraitActions.sharingan2AttackEffect);
        survive2.action_special_effect = (WorldAction)Delegate.Combine(survive2.action_special_effect, new WorldAction(CustomTraitActions.sharingan2SpecialEffect));

        AssetManager.traits.add(survive2);
        addToLocale(survive2.id, "Sharingan 2", "The Stage 2 Sharingan! Can slow enemy and make them stop whatever they are doing!", "Have small chance to evolve into Sharingan level 3 in fiercest battles or killed many people, or through sheer luck!");
        #endregion

        #region survive3
        ActorTrait survive3 = new ActorTrait()
        {
            id = $"{Identifier}_survive3",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/survive3",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
        };

        survive3.base_stats = new BaseStats();
        survive3.base_stats.set(CustomBaseStatsConstant.Damage, 110f);
        survive3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        survive3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.1f);
        survive3.base_stats.set(CustomBaseStatsConstant.Health, 200f);
        survive3.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);
        survive3.base_stats.set(CustomBaseStatsConstant.Speed, 20f);

        survive3.type = TraitType.Positive;
        survive3.unlock(true);

        survive3.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive2" });
        survive3.action_attack_target = new AttackAction(CustomTraitActions.sharingan3AttackEffect);
        survive3.action_special_effect = (WorldAction)Delegate.Combine(survive3.action_special_effect, new WorldAction(CustomTraitActions.MangenkyouSpecialEffect));

        AssetManager.traits.add(survive3);
        addToLocale(survive3.id, "Sharingan 3", "The last and strongest stage of Sharingan! This is the foundation to become a legend!", "Rename unit to uhboss rankomega or uhboss rankzeta, or add Cell trait to evolve further!");
        #endregion

        #region beargery
        ActorTrait beargery = new ActorTrait()
        {
            id = $"{Identifier}_beargery",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/beargery",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        beargery.base_stats = new BaseStats();
        beargery.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.13f);
        beargery.base_stats.set(CustomBaseStatsConstant.MultiplierCrit, 0.35f);
        beargery.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.1f);
        beargery.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.1f);
        beargery.base_stats.set(CustomBaseStatsConstant.Range, 2f);

        beargery.type = TraitType.Positive;
        beargery.unlock(true);

        beargery.addOpposites(new List<string> {
            $"{Identifier}_survive1",
            $"{Identifier}_survive2",
            $"{Identifier}_survive3",
            $"{Identifier}_bearchaos"
        });

        beargery.action_attack_target = new AttackAction(CustomTraitActions.beargery1AttackEffect);
        beargery.action_special_effect = (WorldAction)Delegate.Combine(beargery.action_special_effect, new WorldAction(CustomTraitActions.beargeryEvo));

        AssetManager.traits.add(beargery);
        addToLocale(beargery.id, "beargery", "beargery of the hbear with piercing vision! Can throw ash at enemy!", "Can evolve to Pure beargery in fiercest battle!");
        #endregion

        #region bearchaos
        ActorTrait bearchaos = new ActorTrait()
        {
            id = $"{Identifier}_bearchaos",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Bearchao2",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        bearchaos.base_stats = new BaseStats();
        bearchaos.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.25f);
        bearchaos.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.75f);
        bearchaos.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        bearchaos.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.3f);
        bearchaos.base_stats.set(CustomBaseStatsConstant.Range, 0.4f);

        bearchaos.type = TraitType.Positive;
        bearchaos.unlock(true);

        bearchaos.addOpposites(new List<string> {
            $"{Identifier}_survive1",
            $"{Identifier}_survive2",
            $"{Identifier}_survive3",
            $"{Identifier}_beargery"
        });

        bearchaos.action_attack_target = new AttackAction(CustomTraitActions.beargery2AttackEffect);

        AssetManager.traits.add(bearchaos);
        addToLocale(bearchaos.id, "Pure beargery", "Prodigy of the hbear! A perfected beargery form — grants unmatched clarity and agility", "Can throw ash at enemy!");
        #endregion

    }
    private static void loadCustomLegendTraits()
    {
        #region ranksigma
        ActorTrait ranksigma = new ActorTrait()
        {
            id = $"{Identifier}_ranksigma",
            group_id = TraitGroupIdLegend,
            path_icon = $"{PathToTraitIcon}/ranksigma",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
            can_be_given = NarutoBoxConfig.UnlockLegendTraits,
        };

        ranksigma.base_stats = new BaseStats();
        ranksigma.base_stats.set(CustomBaseStatsConstant.Damage, 800f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.Armor, 50f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.3f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.Health, 2000f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.9f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.Speed, 30f);
        ranksigma.base_stats.set(CustomBaseStatsConstant.Mass, 100f);

        ranksigma.addOpposites(new List<string> { $"{Identifier}_uhboss", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3" });

        ranksigma.type = TraitType.Positive;
        ranksigma.unlock(true);
        ranksigma.action_special_effect = (WorldAction)Delegate.Combine(ranksigma.action_special_effect, new WorldAction(CustomTraitActions.ranksigmaSpecialEffect));
        ranksigma.action_attack_target = new AttackAction(CustomTraitActions.lionstyleAttackEffect);
        AssetManager.traits.add(ranksigma);
        addToLocale(ranksigma.id, "ranksigma", "leoin ranksigma! The Ninja God has appeared!", "Rename someone with lionstyle trait to leoin ranksigma to get this!");
        #endregion


        #region rankzeta
        ActorTrait rankzeta = new ActorTrait()
        {
            id = $"{Identifier}_rankzeta",
            group_id = TraitGroupIdLegend,
            path_icon = $"{PathToTraitIcon}/rankzeta",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
            can_be_given = NarutoBoxConfig.UnlockLegendTraits,
        };

        rankzeta.base_stats = new BaseStats();
        rankzeta.base_stats.set(CustomBaseStatsConstant.Damage, 100f);
        rankzeta.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        rankzeta.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.5f);
        rankzeta.base_stats.set(CustomBaseStatsConstant.Health, 2000f);
        rankzeta.base_stats.set(CustomBaseStatsConstant.Intelligence, 150f);
        rankzeta.base_stats.set(CustomBaseStatsConstant.Speed, 25f);

        rankzeta.type = TraitType.Positive;
        rankzeta.unlock(true);

        rankzeta.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3", $"{Identifier}_rankomega", $"{Identifier}_rankX", $"{Identifier}_final_form" });

        rankzeta.action_attack_target = new AttackAction(CustomTraitActions.rankzetaSpecialAttack);

        AssetManager.traits.add(rankzeta);
        addToLocale(rankzeta.id, "rankzeta", "The uhboss rankzeta! Extremely deadly legend with supreme Black Fire attack!", "Unlock by evolving to Sharingan 3 and renaming to uhboss rankzeta!");
        #endregion

        #region rankomega
        ActorTrait rankomega = new ActorTrait()
        {
            id = $"{Identifier}_rankomega",
            group_id = TraitGroupIdLegend,
            path_icon = $"{PathToTraitIcon}/rankomega",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
            can_be_given = NarutoBoxConfig.UnlockLegendTraits,
        };

        rankomega.base_stats = new BaseStats();
        rankomega.base_stats.set(CustomBaseStatsConstant.Damage, 100f);
        rankomega.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        rankomega.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.5f);
        rankomega.base_stats.set(CustomBaseStatsConstant.Health, 2200f);
        rankomega.base_stats.set(CustomBaseStatsConstant.Intelligence, 150f);
        rankomega.base_stats.set(CustomBaseStatsConstant.Speed, 25f);

        rankomega.type = TraitType.Positive;
        rankomega.unlock(true);

        rankomega.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3", $"{Identifier}_rankzeta", $"{Identifier}_rankX", $"{Identifier}_final_form" });


        rankomega.action_attack_target = new AttackAction(CustomTraitActions.rankomegaSpecialAttack);
        rankomega.action_special_effect = (WorldAction)Delegate.Combine(rankomega.action_special_effect, new WorldAction(CustomTraitActions.kamuiSpecialEffect));
        rankomega.action_death = new WorldAction(CustomTraitActions.rankomegaDeathEffect);

        AssetManager.traits.add(rankomega);
        addToLocale(rankomega.id, "rankomega", "The uhboss rankomega! Extremely powerful and can be evasive, will become rankX if defeated!", "Unlock by evolving to Sharingan 3 and renaming to uhboss rankomega!");
        #endregion

        #region rankX
        ActorTrait rankX = new ActorTrait()
        {
            id = $"{Identifier}_rankX",
            group_id = TraitGroupIdLegend,
            path_icon = $"{PathToTraitIcon}/rankX",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
            can_be_given = NarutoBoxConfig.UnlockLegendTraits,
        };

        rankX.base_stats = new BaseStats();
        rankX.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.5f);
        rankX.base_stats.set(CustomBaseStatsConstant.Armor, 25f);
        rankX.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        rankX.base_stats.set(CustomBaseStatsConstant.Speed, 50f);
        rankX.base_stats.set(CustomBaseStatsConstant.Health, 5500f);
        rankX.base_stats.set(CustomBaseStatsConstant.Intelligence, 250f);
        rankX.base_stats.set(CustomBaseStatsConstant.Mass, 100f);
        rankX.base_stats.set(CustomBaseStatsConstant.Mana, 100f);

        rankX.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3", $"{Identifier}_rankzeta", $"{Identifier}_rankomega", $"{Identifier}_final_form" });

        rankX.type = TraitType.Positive;
        rankX.unlock(true);

        rankX.action_attack_target = new AttackAction(CustomTraitActions.rankXSpecialAttack);
        rankX.action_special_effect = (WorldAction)Delegate.Combine(rankX.action_special_effect, new WorldAction(CustomTraitActions.rankXSpecialEffect));

        AssetManager.traits.add(rankX);
        addToLocale(rankX.id, "rankX", "The uhboss Legend — rankX!", "Unlock by defeating rankomega!");
        #endregion

        #region rankX_final_form
        ActorTrait rankEX = new ActorTrait()
        {
            id = $"{Identifier}_final_form",
            group_id = TraitGroupIdLegend,
            path_icon = $"{PathToTraitIcon}/rinengan",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R3_Legendary,
            can_be_given = NarutoBoxConfig.UnlockLegendTraits,
        };

        rankEX.base_stats = new BaseStats();
        rankEX.base_stats.set(CustomBaseStatsConstant.Damage, 800f);
        rankEX.base_stats.set(CustomBaseStatsConstant.Armor, 70f);
        rankEX.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f); // 500%
        rankEX.base_stats.set(CustomBaseStatsConstant.Health, 8500f);
        rankEX.base_stats.set(CustomBaseStatsConstant.Intelligence, 300f);
        rankEX.base_stats.set(CustomBaseStatsConstant.Speed, 80f);
        rankEX.base_stats.set(CustomBaseStatsConstant.Mass, 100f);
        rankEX.base_stats.set(CustomBaseStatsConstant.Range, 10f);

        rankEX.type = TraitType.Positive;
        rankEX.unlock(true);

        rankEX.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3", $"{Identifier}_rankzeta", $"{Identifier}_rankomega", $"{Identifier}_rankX" });

        rankEX.action_attack_target = new AttackAction(CustomTraitActions.tengaiShinseiAttack);

        AssetManager.traits.add(rankEX);
        addToLocale(rankEX.id, "rankX Final Form", "God of War! rankX in his Rinnegan-powered final form!", "Fuse rankX with ranksigma's cell to unlock this!");
        #endregion
    }


    private static void loadCustomTraitShinobi()
    {
        #region rank
        ActorTrait rankF = new ActorTrait()
        {
            id = $"{Identifier}_rankF",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/RankStudent",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        rankF.base_stats = new BaseStats();
        rankF.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        rankF.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        rankF.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        rankF.type = TraitType.Positive;
        rankF.unlock(true);

        rankF.action_special_effect = (WorldAction)Delegate.Combine(rankF.action_special_effect, new WorldAction(CustomTraitActions.rankEvolutionSpecialEffect));
        AssetManager.traits.add(rankF);
        addToLocale(rankF.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region rankE
        ActorTrait rankE = new ActorTrait()
        {
            id = $"{Identifier}_rankE",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/RankGenin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        rankE.base_stats = new BaseStats();
        rankE.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        rankE.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        rankE.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        rankE.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        rankE.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        rankE.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        rankE.type = TraitType.Positive;
        rankE.unlock(true);

        rankE.action_special_effect = (WorldAction)Delegate.Combine(rankE.action_special_effect, new WorldAction(CustomTraitActions.rank2EvolutionSpecialEffect));

        AssetManager.traits.add(rankE);
        addToLocale(rankE.id, "Genin", "A low-rank shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region rankD
        ActorTrait rankD = new ActorTrait()
        {
            id = $"{Identifier}_rankD",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/RankChunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        rankD.base_stats = new BaseStats();
        rankD.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        rankD.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        rankD.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        rankD.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        rankD.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        rankD.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        rankD.type = TraitType.Positive;
        rankD.unlock(true);

        rankD.action_special_effect = (WorldAction)Delegate.Combine(rankD.action_special_effect, new WorldAction(CustomTraitActions.rank3EvolutionSpecialEffect));

        AssetManager.traits.add(rankD);
        addToLocale(rankD.id, "Chunin", "A mid-rank shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region rankC
        ActorTrait rankC = new ActorTrait()
        {
            id = $"{Identifier}_rankC",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/RankJonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        rankC.base_stats = new BaseStats();
        rankC.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        rankC.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        rankC.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        rankC.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        rankC.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        rankC.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        rankC.type = TraitType.Positive;
        rankC.unlock(true);

        rankC.action_special_effect = (WorldAction)Delegate.Combine(rankC.action_special_effect, new WorldAction(CustomTraitActions.rank4EvolutionSpecialEffect));
        rankC.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(rankC);
        addToLocale(rankC.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region rankB
        ActorTrait rankB = new ActorTrait()
        {
            id = $"{Identifier}_rankB",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/AnbuNinja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        rankB.base_stats = new BaseStats();
        rankB.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        rankB.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        rankB.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        rankB.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        rankB.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        rankB.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        rankB.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        rankB.type = TraitType.Positive;
        rankB.unlock(true);

        rankB.addOpposites(new List<string> {
            $"{Identifier}_rankF",
            $"{Identifier}_rankE",
            $"{Identifier}_rankD",
            $"{Identifier}_rankC"
        });

        rankB.action_special_effect = (WorldAction)Delegate.Combine(rankB.action_special_effect, new WorldAction(CustomTraitActions.rank5SpecialEffect));
        rankB.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(rankB);
        addToLocale(rankB.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region rankA
        ActorTrait rankA = new ActorTrait()
        {
            id = $"{Identifier}_rankA",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/AnbuCaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        rankA.base_stats = new BaseStats();
        rankA.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        rankA.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        rankA.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        rankA.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        rankA.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        rankA.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        rankA.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        rankA.type = TraitType.Positive;
        rankA.unlock(true);

        rankA.addOpposites(new List<string> {
            $"{Identifier}_rankF",
            $"{Identifier}_rankE",
            $"{Identifier}_rankD",
            $"{Identifier}_rankC",
            $"{Identifier}_rankB",
        });

        rankA.action_special_effect = (WorldAction)Delegate.Combine(rankA.action_special_effect, new WorldAction(CustomTraitActions.rank6SpecialEffect));
        rankA.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(rankA);
        addToLocale(rankA.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region rankS
        ActorTrait rankS = new ActorTrait()
        {
            id = $"{Identifier}_rankS",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/RankS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        rankS.base_stats = new BaseStats();
        rankS.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        rankS.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        rankS.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        rankS.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        rankS.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        rankS.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        rankS.type = TraitType.Positive;
        rankS.unlock(true);

        rankS.action_special_effect = (WorldAction)Delegate.Combine(rankS.action_special_effect, new WorldAction(CustomTraitActions.rank4EvolutionSpecialEffect));
        rankS.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(rankS);
        addToLocale(rankS.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region rankSS
        ActorTrait rankSS = new ActorTrait()
        {
            id = $"{Identifier}_rankSS",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/rankSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        rankSS.base_stats = new BaseStats();
        rankSS.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        rankSS.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        rankSS.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        rankSS.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        rankSS.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        rankSS.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        rankSS.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        rankSS.type = TraitType.Positive;
        rankSS.unlock(true);

        rankSS.addOpposites(new List<string> {
            $"{Identifier}_rankF",
            $"{Identifier}_rankE",
            $"{Identifier}_rankD",
            $"{Identifier}_rankS"
        });

        rankSS.action_special_effect = (WorldAction)Delegate.Combine(rankSS.action_special_effect, new WorldAction(CustomTraitActions.rank8SpecialEffect));
        rankSS.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(rankSS);
        addToLocale(rankSS.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region rankSSS
        ActorTrait rankSSS = new ActorTrait()
        {
            id = $"{Identifier}_rankSSS",
            group_id = TraitGroupIdShinobi,
            path_icon = $"{PathToTraitIcon}/rankSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        rankSSS.base_stats = new BaseStats();
        rankSSS.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        rankSSS.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        rankSSS.type = TraitType.Positive;
        rankSSS.unlock(true);

        rankSSS.addOpposites(new List<string> {
            $"{Identifier}_rankF",
            $"{Identifier}_rankE",
            $"{Identifier}_rankD",
            $"{Identifier}_rankS",
            $"{Identifier}_rankSS",
        });

        rankSSS.action_special_effect = (WorldAction)Delegate.Combine(rankSSS.action_special_effect, new WorldAction(CustomTraitActions.rank9SpecialEffect));
        rankSSS.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(rankSSS);
        addToLocale(rankSSS.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        

    }

    private static void loadCustomTraitClans()
    {
        //leoin clan
        #region leoin
        ActorTrait leoin = new ActorTrait()
        {
            id = $"{Identifier}_leoin",
            group_id = TraitGroupIdClan,
            path_icon = $"{PathToTraitIcon}/leoin",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };

        leoin.base_stats = new BaseStats();
        leoin.base_stats.set(CustomBaseStatsConstant.Damage, 85f);
        leoin.base_stats.set(CustomBaseStatsConstant.Armor, 10f);
        leoin.base_stats.set(CustomBaseStatsConstant.Health, 200f);
        leoin.base_stats.set(CustomBaseStatsConstant.Intelligence, 50f);
        leoin.base_stats.set(CustomBaseStatsConstant.Speed, 15f);
        leoin.base_stats.set(CustomBaseStatsConstant.MultiplierStamina, 0.1f);
        leoin.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.1f);

        leoin.addOpposites(new List<string> { $"{Identifier}_uhboss", $"{Identifier}_survive1", $"{Identifier}_survive2", $"{Identifier}_survive3" });

        leoin.type = TraitType.Positive;
        leoin.unlock(true);
        leoin.action_special_effect = (WorldAction)Delegate.Combine(leoin.action_special_effect, new WorldAction(CustomTraitActions.leoinClanAwakeningSpecialEffect));
        AssetManager.traits.add(leoin);
        addToLocale(leoin.id, "leoin", "leoin Clan! Clan members can have the chance to awake lionstyle trait in the fiercest battle!");
        #endregion


        #region uhboss
        ActorTrait uhboss = new ActorTrait()
        {
            id = $"{Identifier}_uhboss",
            group_id = TraitGroupIdClan,
            path_icon = $"{PathToTraitIcon}/uhboss",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };
        uhboss.base_stats = new BaseStats();
        uhboss.base_stats.set(CustomBaseStatsConstant.Damage, 85f);
        uhboss.base_stats.set(CustomBaseStatsConstant.Armor, 10f);
        uhboss.base_stats.set(CustomBaseStatsConstant.Health, 200f);
        uhboss.base_stats.set(CustomBaseStatsConstant.Intelligence, 50f);
        uhboss.base_stats.set(CustomBaseStatsConstant.Speed, 15f);
        uhboss.base_stats.set(CustomBaseStatsConstant.MultiplierStamina, 0.1f);
        uhboss.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.1f);
        uhboss.type = TraitType.Positive;
        uhboss.unlock(true);

        uhboss.addOpposites(new List<string> { $"{Identifier}_leoin", $"{Identifier}_ranksigma", $"{Identifier}_lionstyle" });

        uhboss.action_special_effect = (WorldAction)Delegate.Combine(uhboss.action_special_effect, new WorldAction(CustomTraitActions.uhbossClanAwakeningSpecialEffect));

        AssetManager.traits.add(uhboss);
        addToLocale(uhboss.id, "uhboss", "uhboss Clan! Clan members can have the chance to awake Sharingan trait in the fiercest battle!");
        #endregion

        #region hbear
        ActorTrait hbear = new ActorTrait()
        {
            id = $"{Identifier}_hbear",
            group_id = TraitGroupIdClan,
            path_icon = $"{PathToTraitIcon}/hbear",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        hbear.base_stats = new BaseStats();
        hbear.base_stats.set(CustomBaseStatsConstant.Damage, 75f);
        hbear.base_stats.set(CustomBaseStatsConstant.Health, 200f);
        hbear.base_stats.set(CustomBaseStatsConstant.Speed, 50f);
        hbear.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5f);
        hbear.base_stats.set(CustomBaseStatsConstant.Intelligence, 10f);

        hbear.type = TraitType.Positive;
        hbear.unlock(true);

        hbear.addOpposites(new List<string> {
            $"{Identifier}_leoin",
            $"{Identifier}_uhboss",
            $"{Identifier}_moonwolf"
        });

        hbear.action_special_effect = (WorldAction)Delegate.Combine(hbear.action_special_effect, new WorldAction(CustomTraitActions.hbearAwakenSpecialEffect));

        AssetManager.traits.add(hbear);
        addToLocale(hbear.id, "hbear", "hbear Clan. Users of the beargery. Renowned for their Gentle Fist technique", "Clan members can have the chance to awake power trait in the normal battle");
        #endregion

        #region moonwolf
        ActorTrait moonwolf = new ActorTrait()
        {
            id = $"{Identifier}_moonwolf",
            group_id = TraitGroupIdClan,
            path_icon = $"{PathToTraitIcon}/moonwolf",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        moonwolf.base_stats = new BaseStats();
        moonwolf.base_stats.set(CustomBaseStatsConstant.Damage, 75f);
        moonwolf.base_stats.set(CustomBaseStatsConstant.Health, 200f);
        moonwolf.base_stats.set(CustomBaseStatsConstant.Speed, 10f);
        moonwolf.base_stats.set(CustomBaseStatsConstant.AttackSpeed, 5f);
        moonwolf.base_stats.set(CustomBaseStatsConstant.Intelligence, 10f);
        moonwolf.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 2.0f);

        moonwolf.type = TraitType.Positive;
        moonwolf.unlock(true);

        moonwolf.addOpposites(new List<string> {
            $"{Identifier}_leoin",
            $"{Identifier}_hbear",
            $"{Identifier}_uhboss"
        });

        AssetManager.traits.add(moonwolf);
        addToLocale(moonwolf.id, "moonwolf", "moonwolf Clan", "Possess immense chakra and sealing prowess.");
        #endregion

    }


    /// <summary>
    /// W.I.P.
    /// Not yet finished
    /// </summary>
    private static void loadCustomTraitChakra()
    {
        #region element5
        ActorTrait element5 = new ActorTrait()
        {
            id = $"{Identifier}_element5",
            group_id = TraitGroupIdChakra,
            path_icon = $"{PathToTraitIcon}/elementFire",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        element5.base_stats = new BaseStats();
        element5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.2f);
        element5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.1f);
        element5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.1f);

        element5.type = TraitType.Positive;
        element5.unlock(true);

        AssetManager.traits.add(element5);
        addToLocale(element5.id, "Fire Style", "Fire Chakra Nature", "Mastery of Fire — aggressive and overwhelming style.");
        #endregion

        #region element6
        ActorTrait element6 = new ActorTrait()
        {
            id = $"{Identifier}_element6",
            group_id = TraitGroupIdChakra,
            path_icon = $"{PathToTraitIcon}/elementWater",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };

        element6.base_stats = new BaseStats();
        element6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.1f);
        element6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 0.15f);
        element6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.12f);

        element6.type = TraitType.Positive;
        element6.unlock(true);

        AssetManager.traits.add(element6);
        addToLocale(element6.id, "Water Style", "Water Chakra Nature", "Fluid, reactive, and versatile combat style.");
        #endregion

        #region element7
        ActorTrait element7 = new ActorTrait()
        {
            id = $"{Identifier}_element7",
            group_id = TraitGroupIdChakra,
            path_icon = $"{PathToTraitIcon}/elementLightening",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };

        element7.base_stats = new BaseStats();
        element7.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.2f);
        element7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.2f);
        element7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.15f);
        element7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.15f);

        element7.type = TraitType.Positive;
        element7.unlock(true);

        AssetManager.traits.add(element7);
        addToLocale(element7.id, "Lightning Style", "Lightning Chakra Nature", "High speed, precision strikes — shocking and deadly.");
        #endregion

        #region element8
        ActorTrait element8 = new ActorTrait()
        {
            id = $"{Identifier}_element8",
            group_id = TraitGroupIdChakra,
            path_icon = $"{PathToTraitIcon}/elementWind",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };

        element8.base_stats = new BaseStats();
        element8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.2f);
        element8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.15f);
        element8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.14f);
        element8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.12f);

        element8.type = TraitType.Positive;
        element8.unlock(true);

        AssetManager.traits.add(element8);
        addToLocale(element8.id, "Wind Style", "Wind Chakra Nature", "Deadly precision and speed — the edge of the blade.");
        #endregion

        #region element9
        ActorTrait element9 = new ActorTrait()
        {
            id = $"{Identifier}_element9",
            group_id = TraitGroupIdChakra,
            path_icon = $"{PathToTraitIcon}/elementEarth",
            rate_birth = NoChance,
            rate_inherit = AlwaysChance,
            rarity = Rarity.R0_Normal,
        };

        element9.base_stats = new BaseStats();
        element9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 0.25f);
        element9.base_stats.set(CustomBaseStatsConstant.Armor, 2f);
        element9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 0.1f);

        element9.type = TraitType.Positive;
        element9.unlock(true);

        AssetManager.traits.add(element9);
        addToLocale(element9.id, "Earth Style", "Earth Chakra Nature", "Strong, unyielding, and resilient power.");
        #endregion

    }


    private static void addToLocale(string id, string name, string description, string description_2 = "")
    {
    }
}