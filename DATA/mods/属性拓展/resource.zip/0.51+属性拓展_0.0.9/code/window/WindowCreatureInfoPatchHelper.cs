
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Collections.Generic;
using AttributeExpansion.code.utils;

namespace AttributeExpansion.code.window;

public class WindowCreatureInfoPatchHelper
{

    public static readonly StatsIconData[] StatsIconDatas = {
        new ("Dodge", "",true),
        new ("Accuracy", "",true),
        new ("Resist", "",true),
        new ("ArmorPenPercent", "",true),
        new ("Vampire", "",true)
    };


    public static void OnEnable(UnitWindow window, Actor actor)
    {
        window.setIconValue("Dodge", actor.stats["Dodge"]);
        window.setIconValue("Accuracy", actor.stats["Accuracy"]);
        window.setIconValue("Resist", actor.stats["Resist"]);
        window.setIconValue("ArmorPenPercent", actor.stats["ArmorPenPercent"]);
        window.setIconValue("Vampire", actor.stats["Vampire"]);
        window.showInfo();
    }


    public static StatsIcon icon;
    public static Transform content_transform;
    public static void Initialize(UnitWindow window)
        {
            window
                .gameObject.transform.Find("Background/Scroll View")
                .GetComponent<ScrollRect>()
                .enabled = true;
            window
                .gameObject.transform.Find("Background/Scroll View/Viewport")
                .GetComponent<Mask>()
                .enabled = true;
            window
                .gameObject.transform.Find("Background/Scroll View/Viewport")
                .GetComponent<Image>()
                .enabled = true;

            content_transform = window.gameObject.transform.Find(
                "Background/Scroll View/Viewport/Content/content_more_icons"
            );

            content_transform.gameObject.AddOrGetComponent<StatsIconContainer>();


            var originalParent = content_transform.GetChild(4);

            var newStatsIconGroup = GameObject.Instantiate(originalParent);
            for (int i = newStatsIconGroup.transform.childCount - 1; i >= 0; i--)
            {
                Transform child = newStatsIconGroup.transform.GetChild(i);
                if (child.name != "i_kills")
                {
                    GameObject.Destroy(child.gameObject); // 销毁子对象
                }
            }

            var i_kills = newStatsIconGroup.Find("i_kills");


            int index = 0;
            foreach (var iconData in StatsIconDatas)
            {
                if (!iconData.is_show)
                {
                    continue;
                }
                if (index ==5)
                {
                    break;
                }
                var base_icon =  GameObject.Instantiate(i_kills, newStatsIconGroup);
                icon = base_icon.GetComponent<StatsIcon>();
                var icon_text =base_icon.GetComponent<TipButton>();
                icon_text.textOnClick = LM.Get("statsIcon_"+iconData.name);
                icon.name = iconData.name;
                // 判断是否需要显示文本
                if (new List<string> { "Dodge", "Accuracy", "Resist", "ArmorPenPercent", "Vampire" }.Contains(iconData.name))
                {
                    Image img = icon.getIcon();
                    img.enabled = false; // 隐藏原图标

                    // 创建文本组件
                    GameObject textObj = new GameObject("IconText");
                    textObj.transform.SetParent(img.transform);
                    RectTransform rt = textObj.AddComponent<RectTransform>();
                    rt.anchorMin = Vector2.zero;
                    rt.anchorMax = Vector2.one;
                    rt.offsetMin = Vector2.zero;
                    rt.offsetMax = Vector2.zero;
                    
                    Text txt = textObj.AddComponent<Text>();
                    txt.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                    txt.color = new Color(255f/255f, 155f/255f, 28f/255f);
                    txt.alignment = TextAnchor.MiddleCenter;
                    txt.fontSize = 7;
                    txt.text = GetStatDisplayName(iconData.name);
                }
                else
                {
                    // 正常加载图标
                    if (!string.IsNullOrEmpty(iconData.iconPath))
                    {
                        icon.getIcon().sprite = Resources.Load<Sprite>(iconData.iconPath);
                    }
                }
                index++;
            }


            GameObject.DestroyImmediate(i_kills.gameObject);
            newStatsIconGroup.name = "wushi_worldbox";
            newStatsIconGroup.SetParent(content_transform);
            newStatsIconGroup.transform.localScale = new Vector3(1, 1, 1);
        }
        private static string GetStatDisplayName(string statName)
            {
                switch (statName)
                {
                    case "Dodge": return "闪避";
                    case "Accuracy": return "命中";
                    case "Resist": return "抵抗";
                    case "ArmorPenPercent": return "击破";
                    case "Vampire": return "吸血";
                    default: return statName;
                }
            }



    public class StatsIconData
    {
        public string name;
        public string iconPath;
        public bool is_show = false;

        public StatsIconData(string name, string iconPath, bool is_show = false)
        {
            this.name = name;
            this.iconPath = iconPath;
            this.is_show = is_show;
        }
    }
}
