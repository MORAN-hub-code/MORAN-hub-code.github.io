using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;

namespace AttributeExpansion.code
{
    internal class traits
    {
        private static ActorTrait AddExpandTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        public static void Init()
        {
            ActorTrait God = AddExpandTrait("God", "trait/God", "acquired");//神之位格
            God.rarity = Rarity.R3_Legendary;
            AssetManager.traits.add(God);
        }
        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}