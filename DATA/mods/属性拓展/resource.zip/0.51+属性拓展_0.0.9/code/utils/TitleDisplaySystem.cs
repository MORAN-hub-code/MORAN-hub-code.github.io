using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using NeoModLoader.General;
using NeoModLoader.General.UI;
using NeoModLoader.api.attributes;
using System.Collections.Generic;

namespace AttributeExpansion.code.utils
{
    public class TitleDisplaySystem : MonoBehaviour
    {
        internal static void Init()
        {
            var canvas = Instantiate(CanvasMain.instance.canvas_tooltip, CanvasMain.instance.transform);
            canvas.name = "TitleDisplaySystem";
            canvas.gameObject.AddComponent<TitleDisplaySystem>();
        }

        private void Start()
        {
            CanvasRect = GetComponent<RectTransform>();
        }

        public RectTransform CanvasRect { get; private set; }

        private void Update()
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            // 检查是否启用头衔显示
            if (!AttributeExpansionConfig.ShowAttributeTitles)
            {
                // 如果未启用头衔显示，清理所有单位的头衔UI对象
                foreach (var unit in World.world.units.getSimpleList())
                {
                    if (unit == null) continue;
                    CleanupTitleForUnit(unit); // 只移除UI对象，不删除头衔数据
                }
                return;
            }
            
            if (ScrollWindow.isWindowActive())
            {
                // 如果有任何窗口激活，清理所有单位的头衔UI对象
                foreach (var unit in World.world.units.getSimpleList())
                {
                    if (unit == null) continue;
                    CleanupTitleForUnit(unit); // 只移除UI对象，不删除头衔数据
                }
            }
            else
            {
                // 清理存活但不可见单位的头衔UI对象
                foreach (var unit in World.world.units.getSimpleList())
                {
                    if (unit == null) continue;
                    if (unit.isAlive() && !unit.is_visible)
                    {
                        CleanupTitleForUnit(unit); // 只移除UI对象，不删除头衔数据
                    }
                }

                // 为可见且存活的单位显示头衔
                foreach (var unit in World.world.units.getSimpleList())
                {
                    if (unit == null) continue;
                    if (!unit.isAlive()) continue;
                    if (!unit.is_visible) continue;

                    var title_guids = unit.GetTitleGuids();
                    if (title_guids.Count == 0) continue;

                    DisplayTitle(unit, title_guids.Select(x => unit.GetTitle(x)));
                }
            }
        }

        private void DisplayTitle(Actor actor, System.Collections.Generic.IEnumerable<string> titles)
        {
            var titleGuids = actor.GetTitleGuids();
            var titleList = titles.ToList();
            var richTextBuilder = new System.Text.StringBuilder();
            
            for (int i = 0; i < titleList.Count; i++)
            {
                if (i > 0)
                {
                    richTextBuilder.Append("\n");
                }
                
                string titleGuid = titleGuids[i];
                Color titleColor = GetTitleColor(actor, titleGuid);
                string colorHex = ColorUtility.ToHtmlStringRGBA(titleColor);
                
                richTextBuilder.Append($"<color=#{colorHex}>{titleList[i]}</color>");
            }
            
            if (richTextBuilder.Length > 0)
            {
                CreateTitleText(actor, richTextBuilder.ToString(), Color.white);
            }
        }

        private void CreateTitleText(Actor actor, string titleText, Color titleColor)
        {
            // 检查是否已经为该单位创建了头衔文本
            GameObject existingTitle = null;
            actor.data.get("attribute_title_object_id", out string titleObjectId);
            
            if (!string.IsNullOrEmpty(titleObjectId))
            {
                existingTitle = GameObject.Find(titleObjectId);
            }
            
            if (existingTitle == null)
            {
                // 创建新的文本对象
                var titleObject = new GameObject("TitleText_" + actor.data.id);
                titleObject.transform.SetParent(transform);
                
                var textComponent = titleObject.AddComponent<Text>();
                textComponent.text = titleText;
                textComponent.font = LocalizedTextManager.current_font;
                textComponent.color = titleColor;
                textComponent.alignment = TextAnchor.UpperCenter;
                textComponent.fontSize = 12;
                
                var rectTransform = titleObject.GetComponent<RectTransform>();
                // 根据文本行数动态调整高度
                int lineCount = titleText.Split('\n').Length;
                rectTransform.sizeDelta = new Vector2(200, 20 * lineCount);
                
                // 保存对象ID以便后续查找
                actor.data.set("attribute_title_object_id", titleObject.name);
            }
            else
            {
                // 更新现有文本
                var textComponent = existingTitle.GetComponent<Text>();
                if (textComponent != null)
                {
                    textComponent.text = titleText;
                    textComponent.color = titleColor;
                }
            }
            
            // 更新文本位置
            UpdateTitlePosition(actor, titleText);
        }

        private void UpdateTitlePosition(Actor actor, string titleText)
        {
            actor.data.get("attribute_title_object_id", out string titleObjectId);
            if (!string.IsNullOrEmpty(titleObjectId))
            {
                var titleObject = GameObject.Find(titleObjectId);
                if (titleObject != null)
                {
                    var textComponent = titleObject.GetComponent<Text>();
                    if (textComponent != null)
                    {
                        // 计算文本行数
                        int lineCount = titleText.Split('\n').Length;
                        
                        // 根据行数调整垂直偏移量
                        float verticalOffset = actor.stats[strings.S.scale] * actor.getSpriteToRender().rect.height;
                        verticalOffset += (lineCount - 1) * 0;
                        
                        // 将世界坐标转换为屏幕坐标
                        var screenPos = WorldToScreenPosition(
                            actor.cur_transform_position + new Vector3(0, verticalOffset),
                            CanvasRect
                        );
                        
                        textComponent.rectTransform.localPosition = screenPos;
                        textComponent.rectTransform.localScale = Vector3.one / World.world.camera.orthographicSize * 8;
                    }
                }
            }
        }
    
        private Color GetTitleColor(Actor actor, string titleGuid)
        {
            if (string.IsNullOrEmpty(titleGuid))
                return Color.white;
            
            // 从actor数据中读取颜色信息
            actor.data.get("attribute.title_color_" + titleGuid, out string colorHex);
            if (!string.IsNullOrEmpty(colorHex) && ColorUtility.TryParseHtmlString("#" + colorHex, out Color color))
            {
                return color;
            }
            
            return Color.white;
        }

        [Hotfixable]
        static Vector2 WorldToScreenPosition(Vector3 position, RectTransform canvas_rect)
        {
            Vector2 vector = World.world.camera.WorldToViewportPoint(position);
            return new Vector2(
                vector.x * canvas_rect.sizeDelta.x - canvas_rect.sizeDelta.x * 0.5f,
                vector.y * canvas_rect.sizeDelta.y - canvas_rect.sizeDelta.y * 0.5f);
        }
        
        /// <summary>
        /// 清理指定单位的头衔显示
        /// </summary>
        public void CleanupTitleForUnit(Actor unit)
        {
            unit.data.get("attribute_title_object_id", out string titleObjectId);
            if (!string.IsNullOrEmpty(titleObjectId))
            {
                var titleObject = GameObject.Find(titleObjectId);
                if (titleObject != null)
                {
                    Destroy(titleObject);
                }
                unit.data.removeString("attribute_title_object_id");
            }
        }
        
        /// <summary>
        /// 清理所有单位的头衔显示（包括残留对象）
        /// </summary>
        public void CleanupAllTitles()
        {
            // 清理所有单位的头衔数据引用
            if (World.world != null && World.world.units != null)
            {
                foreach (var unit in World.world.units.getSimpleList())
                {
                    if (unit == null) continue;
                    CleanupTitleForUnit(unit);
                }
            }
                
            // 清理当前Canvas下的所有子对象
            for (int i = transform.childCount - 1; i >= 0; i--)
            {
                var child = transform.GetChild(i);
                if (child != null && child.gameObject != null &&
                    child.gameObject.name.StartsWith("TitleText_"))
                {
                    DestroyImmediate(child.gameObject);
                }
            }
                
            // 查找所有场景中的头衔对象（包括未激活的）
            var allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>(true);
            foreach (var obj in allObjects)
            {
                if (obj != null && obj.name.StartsWith("TitleText_"))
                {
                    DestroyImmediate(obj);
                }
            }
                
            // 通过Text组件查找
            var allTexts = UnityEngine.Object.FindObjectsOfType<Text>(true);
            foreach (var text in allTexts)
            {
                if (text != null && text.gameObject != null &&
                    text.gameObject.name.StartsWith("TitleText_"))
                {
                    DestroyImmediate(text.gameObject);
                }
            }
                
            // 清理DontDestroyOnLoad场景中的对象
            CleanupDontDestroyOnLoadTitles();
                
            // 强制资源清理
            Resources.UnloadUnusedAssets();
        }
        
        private void CleanupDontDestroyOnLoadTitles()
        {
            // 创建临时对象来访问 DontDestroyOnLoad 场景
            GameObject tempObject = new GameObject("TempTitleCleanupObject");
            UnityEngine.Object.DontDestroyOnLoad(tempObject);
                
            // 获取 DontDestroyOnLoad 场景中的所有对象
            var dontDestroyObjects = tempObject.scene.GetRootGameObjects();
            foreach (var rootObj in dontDestroyObjects)
            {
                    if (rootObj.name.StartsWith("TitleText_"))
                {
                    DestroyImmediate(rootObj);
                }
                    
                // 递归查找子对象
                var children = rootObj.GetComponentsInChildren<Transform>(true);
                foreach (var child in children)
                {
                    if (child != null && child.gameObject.name.StartsWith("TitleText_"))
                    {
                        DestroyImmediate(child.gameObject);
                    }
                }
            }
                
            DestroyImmediate(tempObject);
        }
    }
}