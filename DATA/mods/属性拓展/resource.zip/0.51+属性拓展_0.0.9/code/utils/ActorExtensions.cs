using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using System.Reflection;

namespace AttributeExpansion.code.utils;

public static class ActorExtensions
{
    private const string resurrection_key = "wushu.resurrectionNum";
    private const string Rresurrection_key = "wushu.RresurrectionNum";
    private const string accuracy_key = "wushu.accuracy";
    private const string dodge_key = "wushu.dodge";
    
    // 头衔管理相关常量和方法
    private const string title_guid_key = "attribute.title_guid";
    
    public static float GetAccuracy(this Actor actor)
    {
        actor.data.get(accuracy_key, out float val, 0);
        return val;
    }

    public static void SetAccuracy(this Actor actor, float val)
    {
        actor.data.set(accuracy_key, val);
    }

    public static void ChangeAccuracy(this Actor actor, float delta)
    {
        actor.data.get(accuracy_key, out float val, 0);
        val += delta;
        actor.data.set(accuracy_key, Mathf.Max(0, val));
    }

    public static float GetDodge(this Actor actor)
    {
        actor.data.get(dodge_key, out float val, 0);
        return val;
    }

    public static void SetDodge(this Actor actor, float val)
    {
        actor.data.set(dodge_key, val);
    }

    public static void ChangeDodge(this Actor actor, float delta)
    {
        actor.data.get(dodge_key, out float val, 0);
        val += delta;
        actor.data.set(dodge_key, Mathf.Max(0, val));
    }
    public static float GetRresurrection(this Actor actor)
    {
        actor.data.get(Rresurrection_key, out float val, 1);
        return val;
    }
    public static void SetRresurrection(this Actor actor, float val)
    {
        actor.data.set(Rresurrection_key, val);
    }
    public static void ChangeRresurrection(this Actor actor, float delta)
    {
        actor.data.get(Rresurrection_key, out float val, 0);
        val += delta;
        actor.data.set(Rresurrection_key, Mathf.Max(1, val));
    }

    public static float GetResurrection(this Actor actor)
    {
        actor.data.get(resurrection_key, out float val, 0);
        return val;
    }
    public static void SetResurrection(this Actor actor, float val)
    {
        actor.data.set(resurrection_key, val);
    }
    public static void ChangeResurrection(this Actor actor, float delta)
    {
        actor.data.get(resurrection_key, out float val, 0);
        val += delta;
        actor.data.set(resurrection_key, Mathf.Max(0, val));
    }
    
    // 头衔管理扩展方法
    public static string GetTitle(this Actor actor, string title_guid)
    {
        actor.data.get(title_guid, out string title, "头衔");
        return title;
    }
    
    public static List<string> GetTitleGuids(this Actor actor)
    {
        actor.data.get(title_guid_key, out string title_guids_str);
        if (string.IsNullOrEmpty(title_guids_str))
        {
            return new List<string>();
        }
        return new List<string>(title_guids_str.Split(','));
    }
    
    public static void AddTitleGuid(this Actor actor, string title_guid)
    {
        var title_guids = actor.GetTitleGuids();
        if (!title_guids.Contains(title_guid))
        {
            title_guids.Add(title_guid);
            actor.data.set(title_guid_key, string.Join(",", title_guids));
        }
    }
    
    public static void RemoveTitleGuid(this Actor actor, string title_guid)
    {
        var title_guids = actor.GetTitleGuids();
        if (title_guids.Contains(title_guid))
        {
            title_guids.Remove(title_guid);
            actor.data.set(title_guid_key, string.Join(",", title_guids));
        }
    }
    
    // 设置头衔的方法
    public static void SetTitle(this Actor actor, string title_guid, string title_text, Color title_color)
    {
        actor.data.set(title_guid, title_text);
        actor.AddTitleGuid(title_guid);
        string colorHex = ColorUtility.ToHtmlStringRGBA(title_color);
        actor.data.set("attribute.title_color_" + title_guid, colorHex);
    }
    
    // 移除头衔的方法
    public static void RemoveTitle(this Actor actor, string title_guid)
    {
        actor.RemoveTitleGuid(title_guid);
    }
}