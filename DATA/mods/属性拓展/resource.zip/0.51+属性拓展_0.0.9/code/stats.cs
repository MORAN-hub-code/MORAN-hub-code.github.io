﻿using ai;
namespace AttributeExpansion.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset damage = new BaseStatAsset();
            damage.id = "damage";// 伤害
            damage.normalize = true;
            damage.normalize_min = 1f;
            damage.normalize_max = 210000000f;
            damage.sort_rank = 999;
            AssetManager.base_stats_library.add(damage);

            BaseStatAsset health = new BaseStatAsset();
            health.id = "health";// 生命值
            health.normalize = true;
            health.normalize_min = 1f;
            health.normalize_max = 1000000000f;
            health.sort_rank = 1000;
            AssetManager.base_stats_library.add(health);

            BaseStatAsset armor = new BaseStatAsset();
            armor.id = "armor";// 防御
            armor.normalize = true;
            armor.show_as_percents = true;
            armor.normalize_min = 0;
            armor.normalize_max = 99999;
            armor.used_only_for_civs = false;
            AssetManager.base_stats_library.add(armor);

            BaseStatAsset intelligence = new BaseStatAsset();
            intelligence.id = "intelligence";// 智力
            intelligence.normalize = true;
            intelligence.normalize_min = 0;
            intelligence.normalize_max = 99999;
            intelligence.used_only_for_civs = false;
            AssetManager.base_stats_library.add(intelligence);

            // 复活次数
            BaseStatAsset resurrection = new BaseStatAsset();
            resurrection.id = "resurrection";// 复活次数
            resurrection.normalize = true;
            resurrection.normalize_min = -99999;
            resurrection.normalize_max = 99999;
            resurrection.used_only_for_civs = false;
            AssetManager.base_stats_library.add(resurrection);

            BaseStatAsset Rresurrection = new BaseStatAsset();
            Rresurrection.id = "Rresurrection";// 轮回记录
            Rresurrection.normalize = true;
            Rresurrection.normalize_min = 1;
            Rresurrection.normalize_max = 99999;
            Rresurrection.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Rresurrection);

            BaseStatAsset Accuracy = new BaseStatAsset();
            Accuracy.id = "Accuracy";// 命中率
            Accuracy.normalize = true;
            Accuracy.show_as_percents = true;
            Accuracy.normalize_min = 0;
            Accuracy.normalize_max = 99999;
            Accuracy.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Accuracy);

            BaseStatAsset Dodge = new BaseStatAsset();
            Dodge.id = "Dodge";// 闪避率
            Dodge.normalize = true;
            Dodge.show_as_percents = true;
            Dodge.normalize_min = 0;
            Dodge.normalize_max = 99999;
            Dodge.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Dodge);

            BaseStatAsset Resist = new BaseStatAsset();
            Resist.id = "Resist";// 击退扺抗
            Resist.normalize = true;
            Resist.normalize_min = 0;
            Resist.normalize_max = 99999;
            Resist.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Resist);

            BaseStatAsset ArmorPenPercent = new BaseStatAsset();
            ArmorPenPercent.id = "ArmorPenPercent";// 护甲穿透百分比
            ArmorPenPercent.normalize = true;
            ArmorPenPercent.show_as_percents = true;
            ArmorPenPercent.normalize_min = 0;
            ArmorPenPercent.normalize_max = 99999;
            ArmorPenPercent.used_only_for_civs = false;
            AssetManager.base_stats_library.add(ArmorPenPercent);

            BaseStatAsset Vampire = new BaseStatAsset();
            Vampire.id = "Vampire";// 吸血百分比
            Vampire.normalize = true;
            Vampire.show_as_percents = true;
            Vampire.normalize_min = 0;
            Vampire.normalize_max = 100;
            Vampire.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Vampire);

            BaseStatAsset Healback = new BaseStatAsset();
            Healback.id = "Healback";// 生命回复
            Healback.normalize = true;
            Healback.normalize_min = 0;
            Healback.normalize_max = 99999;
            Healback.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Healback);
        }
    }
}