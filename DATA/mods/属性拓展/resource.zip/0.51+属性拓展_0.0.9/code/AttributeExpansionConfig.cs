using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeExpansion.code
{
    public class AttributeExpansionConfig
    {
        /// <summary>
        /// 是否显示属性拓展头衔
        /// </summary>
        public static bool ShowAttributeTitles { get; set; } = true;
        
        /// <summary>
        /// 是否播放死亡动画
        /// </summary>
        public static bool PlayDeathAnimation { get; set; } = true;
        
        /// <summary>
        /// 头衔显示配置回调
        /// <param name="pCurrentValue">当前值</param>
        /// </summary>
        public static void TitleDisplayConfigCallBack(bool pCurrentValue)
        {
            ShowAttributeTitles = pCurrentValue;
        }
        
        /// <summary>
        /// 死亡动画播放配置回调
        /// <param name="pCurrentValue">当前值</param>
        /// </summary>
        public static void PlayDeathAnimationConfigCallBack(bool pCurrentValue)
        {
            PlayDeathAnimation = pCurrentValue;
        }
    }
}
