﻿using NeoModLoader.api;
using AttributeExpansion.code;
using AttributeExpansion.code.utils;
using AttributeExpansion.code.window;
using HarmonyLib;

namespace AttributeExpansion
{
    internal class AttributeExpansionClass : BasicMod<AttributeExpansionClass>,IReloadable
    {
        public static ModConfig config;
        public static string id = "shiyue.worldbox.mod.AttributeExpansion";

        protected override void OnModLoad()
        {
            // 初始化配置
            config = new ModConfig("AttributeExpansion_mod_config_title");
            
            stats.Init();
            traits.Init();
            // 初始化头衔显示系统
            TitleDisplaySystem.Init();
            
            new Harmony(id).PatchAll(typeof(patch));
        }

        public void Reload()
        {
            
        }
    }
}