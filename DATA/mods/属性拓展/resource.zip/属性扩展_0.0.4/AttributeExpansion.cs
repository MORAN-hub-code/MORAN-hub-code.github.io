﻿using NeoModLoader.api;
using AttributeExpansion.code;
using AttributeExpansion.code.window;
using HarmonyLib;

namespace AttributeExpansion
{
    internal class AttributeExpansionClass : BasicMod<AttributeExpansionClass>,IReloadable
    {
        public static ModConfig config;
        public static string id = "shiyue.worldbox.mod.AttributeExpansion";

        protected override void OnModLoad()
        {            
            stats.Init();
            
            new Harmony(id).PatchAll(typeof(patch));
        }

        public void Reload()
        {
            
        }
    }
}