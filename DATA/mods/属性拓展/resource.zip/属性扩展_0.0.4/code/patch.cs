﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using AttributeExpansion.code.utils;
using AttributeExpansion.code.window;

namespace AttributeExpansion.code;

internal class patch
{
    // 禁用物理力
    [HarmonyPrefix]
    [HarmonyPatch(typeof(MapAction), nameof(MapAction.damageWorld))]
    private static bool DamageWorldPrefix(
        WorldTile pTile, 
        int pRad, 
        TerraformOptions pOptions)
    {
        // 检查需要禁用物理力的效果ID
        if (pOptions?.id != null)
        {
            // 需要禁用物理力的效果列表
            string[] disabledPhysicsEffects = {
                "lightning_normal",    // 普通闪电
                "cannonball"           // 炮弹
            };
            foreach (string effectId in disabledPhysicsEffects)
            {
                if (pOptions.id == effectId)
                {
                    if (pOptions.shake)
                    {
                        World.world.startShake(pOptions.shake_duration, 
                                            pOptions.shake_interval, 
                                            pOptions.shake_intensity, 
                                            false, true);
                    }
                    MapAction.applyTileDamage(pTile, (float)pRad, pOptions);
                    return false;
                }
            }
        }
        return true;
    }
    public static bool window_creature_info_initialized;
    [HarmonyPostfix]
    [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
    private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
    {
        if (__instance.actor == null || !__instance.actor.isAlive()) return;
        if (!window_creature_info_initialized)
        {
            window_creature_info_initialized = true;
            WindowCreatureInfoPatchHelper.Initialize(__instance);
        }

        //WindowCreatureInfoPatchHelper.OnEnable(__instance, __instance.actor);
    }
    [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
    private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
    {
        var actor = __instance.actor;
        if (actor == null || !actor.isAlive()) return;
        __instance.setIconValue("Dodge", actor.stats["Dodge"]);
        __instance.setIconValue("Accuracy", actor.stats["Accuracy"]);
        __instance.setIconValue("Resist", actor.stats["Resist"]);
        __instance.setIconValue("ArmorPenPercent", actor.stats["ArmorPenPercent"]);
        __instance.setIconValue("Vampire", actor.stats["Vampire"]);
    }

    private static bool IsActorDead(Actor actor)
    {
        return !actor.hasHealth();
    }
    //禁止雷电劈出永生
    [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
    public static bool checkLightningAction(Vector2Int pPos, int pRad)
    {
        bool flag = false;
        List<Actor> simpleList = World.world.units.getSimpleList();
        for (int i = 0; i < simpleList.Count; i++)
        {
            Actor actor = simpleList[i];
            if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
            {
                if (actor.asset.flag_finger)
                {
                    actor.getActorComponent<GodFinger>().lightAction();
                }
                else
                {
                    if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                    {
                        flag = true;
                    }

                    SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                    BehaviourTaskActor task = actor.ai.task;
                    SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                }
            }
        }
        return false;
    }
    /*[HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateStamina")]
                            public static void Postfix(Actor __instance)
                            {
                                if (__instance.data.health < __instance.getMaxHealth())
                                    {
                                        __instance.restoreHealth(10);
                                        __instance.spawnParticle(Toolbox.color_heal);
                                }
                            }*/
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
    public static bool actorGetHit_prefix(
        Actor __instance,
        ref float pDamage,
        bool pFlash,
        AttackType pAttackType,
        BaseSimObject pAttacker,
        bool pSkipIfShake,
        bool pMetallicWeapon,
        bool pCheckDamageReduction = true)
    {
        __instance._last_attack_type = pAttackType;

        // 状态移除检查
        if (__instance._cache_check_has_status_removed_on_damage)
        {
            foreach (Status tStatusData in __instance.getStatuses())
            {
                if (tStatusData.asset.removed_on_damage && !tStatusData.is_finished)
                {
                    __instance.finishStatusEffect(tStatusData.asset.id);
                }
            }
        }

        // 调试模式或跳过条件检查
        if (DebugConfig.isOn(DebugOption.IgnoreDamage)) return false;
        if (pSkipIfShake && __instance.shake_active) return false;

        __instance.attackedBy = null;
        if (pAttacker != null && pAttacker.isRekt())
        {
            pAttacker = null;
        }
        if (pAttacker != __instance)
        {
            __instance.attackedBy = pAttacker;
        }

        // 单位状态检查
        if (!__instance.hasHealth()) return false;
        if (__instance.hasStatus("invincible")) return false;

        // 闪避机制
        if (pAttacker is Actor attackerActor && __instance.isAlive())
        {
            float attackerAccuracy = attackerActor.stats["Accuracy"];
            float targetDodge = __instance.stats["Dodge"];
            float effectiveDodge = Mathf.Clamp(targetDodge - attackerAccuracy, 0f, 100f);

            if (Randy.randomChance(effectiveDodge / 100f))
            {
                __instance.startColorEffect(ActorColorEffect.White);
                return false;
            }
        }

        // 真伤计算
        if (pAttacker != null && pAttacker.a != null && pAttacker.a.stats != null)
        {
            Actor attacker = pAttacker.a;
            float intelligence = attacker.stats[strings.S.intelligence];

            float minMultiplier = 0f, maxMultiplier = 0f;
            if (attacker.hasTrait("Grade91"))
            {
                minMultiplier = 4800f;
                maxMultiplier = 5600f;
            }
            else if (attacker.hasTrait("Grade9"))
            {
                minMultiplier = 67f;
                maxMultiplier = 77f;
            }
            else if (attacker.hasTrait("Grade8"))
            {
                minMultiplier = 30f;
                maxMultiplier = 50f;
            }
            else if (attacker.hasTrait("Grade7"))
            {
                minMultiplier = 20f;
                maxMultiplier = 40f;
            }
            else if (attacker.hasTrait("Grade6"))
            {
                minMultiplier = 14f;
                maxMultiplier = 15f;
            }
            else if (attacker.hasTrait("Grade5"))
            {
                minMultiplier = 12f;
                maxMultiplier = 15f;
            }
            else if (attacker.hasTrait("Grade4"))
            {
                minMultiplier = 10f;
                maxMultiplier = 13f;
            }
            else
            {
                goto SkipMagicDamage;
            }

            float multiplier = UnityEngine.Random.Range(minMultiplier, maxMultiplier);
            int magicDamage = Mathf.FloorToInt(intelligence * multiplier);
            __instance.changeHealth(-magicDamage);
            __instance.spawnParticle(new Color(255, 0, 255));
        }

    SkipMagicDamage:
        Actor tAttackerUnit = (pAttacker != null) ? pAttacker.a : null;

        // 武器攻击处理
        if (pAttackType == AttackType.Weapon)
        {
            bool flag = false;
            if (pMetallicWeapon && __instance.haveMetallicWeapon())
            {
                flag = true;
            }

            if (flag)
            {
                MusicBox.playSound("event:/SFX/HIT/HitSwordSword", __instance.current_tile, false, true);
            }
            else if (__instance.asset.has_sound_hit) // 使用has_sound_hit检查
            {
                MusicBox.playSound(__instance.asset.sound_hit, __instance.current_tile, false, true);
            }

            if (!__instance.hasStatus("shield") && tAttackerUnit != null)
            {
                __instance.damageEquipmentOnGetHit(tAttackerUnit);
            }
        }

        // 护甲计算逻辑（新增pCheckDamageReduction检查）
        if (pCheckDamageReduction && (pAttackType == AttackType.Other || pAttackType == AttackType.Weapon))
        {
            // 获取攻击者的护甲穿透百分比
            float armorPen = tAttackerUnit?.stats["ArmorPenPercent"] ?? 0f;
            // 计算有效护甲
            float effectiveArmor = __instance.stats["armor"] - armorPen;
            // 计算减伤比例
            float tArmorPercent = 1f - effectiveArmor / 100f;
            pDamage *= tArmorPercent;

            if (pDamage < 1f) pDamage = 1f;
        }

        // 特殊攻击逻辑
        if (pAttacker != null && pAttacker.isActor())
        {
            float tFinalDamage;
            __instance.checkSpecialAttackLogic(pAttacker.a, pAttackType, pDamage, out tFinalDamage);
            pDamage = tFinalDamage;
        }

        // 成就信号
        if (tAttackerUnit != null)
        {
            SignalManager.add(SignalLibrary.check_achievement_clone_wars,
                            new ValueTuple<Actor, Actor>(__instance, tAttackerUnit));
        }

        // 应用伤害
        __instance.changeHealth((int)(-(int)pDamage));

        // 吸血计算逻辑
        if (tAttackerUnit != null && tAttackerUnit.isAlive())
        {
            float vampirePercent = tAttackerUnit.stats["Vampire"];
            if (vampirePercent > 0)
            {
                int healAmount = (int)(pDamage * vampirePercent / 100f);
                tAttackerUnit.changeHealth(healAmount);
            }
        }

        __instance.timer_action = 0.002f;

        // 受击动作
        GetHitAction getHitAction = __instance.s_get_hit_action;
        if (getHitAction != null)
        {
            getHitAction(__instance, pAttacker, __instance.current_tile);
        }

        if (pFlash)
        {
            __instance.startColorEffect(ActorColorEffect.Red);
        }

        // 死亡处理
        if (!__instance.hasHealth())
        {
            __instance.batch.c_check_deaths.Add(__instance);
        }

        // 受伤添加特质（防火特质检查）
        if (pAttackType == AttackType.Weapon &&
            !__instance.asset.immune_to_injuries &&
            !__instance.hasStatus("shield"))
        {
            if (!__instance.hasTrait("fire_proof"))
            {
                if (Randy.randomChance(0.02f)) __instance.addInjuryTrait("crippled");
                if (Randy.randomChance(0.02f)) __instance.addInjuryTrait("eyepatch");
            }
        }

        __instance.startShake(0.3f, 0.1f, true, true);

        // 目标选择逻辑（优化距离计算）
        if (!__instance.has_attack_target)
        {
            if (__instance.attackedBy != null &&
                !__instance.shouldIgnoreTarget(__instance.attackedBy) &&
                __instance.canAttackTarget(__instance.attackedBy, false))
            {
                __instance.setAttackTarget(__instance.attackedBy);
            }
        }
        else if (__instance.hasMeleeAttack() &&
                __instance.attackedBy != null &&
                __instance.canAttackTarget(__instance.attackedBy, false))
        {
            float tDistToCurrentTarget = Toolbox.SquaredDistVec2Float(__instance.current_position,
                                                                    __instance.attack_target.current_position);
            float tDistToAttacker = Toolbox.SquaredDistVec2Float(__instance.current_position,
                                                            pAttacker.current_position);

            if (tDistToCurrentTarget > __instance.getAttackRangeSquared() &&
                tDistToAttacker < tDistToCurrentTarget)
            {
                __instance.setAttackTarget(pAttacker);
            }
        }

        // 状态效果处理
        if (__instance.hasAnyStatusEffect())
        {
            foreach (Status status in __instance.getStatuses())
            {
                GetHitAction action_get_hit = status.asset.action_get_hit;
                if (action_get_hit != null)
                {
                    action_get_hit(__instance, pAttacker, __instance.current_tile);
                }
            }
        }

        // 资产受击动作
        GetHitAction action_get_hit2 = __instance.asset.action_get_hit;
        if (action_get_hit2 != null)
        {
            action_get_hit2(__instance, pAttacker, __instance.current_tile);
        }

        // 死亡回调
        if (!__instance.hasHealth())
        {
            __instance.checkCallbacksOnDeath();
        }

        return false;
    }
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
    public static bool makeStunned(Actor __instance, float pTime = 5f)
    {
        pTime += Randy.randomFloat(0f, pTime * 0.1f);
        __instance.cancelAllBeh();
        __instance.makeWait(pTime);
        // 如果没有防火特质，则添加眩晕状态效果，否则不添加眩晕状态效果
        if (!__instance.hasTrait("fire_proof"))
        {
            if (__instance.addStatusEffect("stunned", pTime, true))
            {
                __instance.finishAngryStatus();
            }
        }
        return false;
    }
    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "addStunnedEffectOnTarget20")]
    // 添加眩晕效果到目标（20%概率）
    public static bool addStunnedEffectOnTarget20_Patch(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
    {
        // 检查目标是否有效（未死亡、非建筑）
        if (pTarget.isRekt() || pTarget.isBuilding())
        {
            return false;
        }

        // 检查随机概率（20%）
        if (!Randy.randomChance(0.2f))
        {
            return false;
        }

        // 检查目标是否具有防火特质
        if (pTarget.isActor() && pTarget.a.hasTrait("fire_proof"))
        {
            return false;
        }

        // 调用眩晕方法
        return ActionLibrary.addStunnedEffectOnTarget(pSelf, pTarget, pTile);
    }
    [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
    public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
    {
        float tForce = pData.knockback * pMod;

        if (tForce > 0f && pTargetToCheck.isActor())
        {
            float resistValue = pTargetToCheck.a.stats["Resist"];
            tForce = Mathf.Max(tForce - resistValue, 0);

            if (tForce > 0f)
            {
                Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                Vector2 tAttackVec = pData.hit_position;
                pTargetToCheck.a.calculateForce(
                    tPosStart.x, tPosStart.y,
                    tAttackVec.x, tAttackVec.y,
                    tForce,
                    0f,
                    pCheckCancelJobOnLand
                );
            }
        }
        return false;
    }
    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "turnIntoSkeleton")]
    public static bool turnIntoSkeleton(BaseSimObject pTarget, WorldTile pTile = null)
    {
        Actor pActor = pTarget.a;
        // 检查角色是否具有阻止转换的特质
        if (pActor.hasTrait("ancestry91") || pActor.hasTrait("flair8") || pActor.hasTrait("flair91") || pActor.hasTrait("flair92")
        || pActor.hasTrait("extraordinary5") || pActor.hasTrait("extraordinary6") || pActor.hasTrait("extraordinary7"))
        {
            return false; // 如果具有这些特质，则不执行转换，直接返回false
        }
        if (string.IsNullOrEmpty(pActor.asset.skeleton_id))
        {
            return false;
        }
        if (pActor == null)
        {
            return false;
        }
        if (!pActor.hasStatus("cursed"))
        {
            return false;
        }
        if (!pActor.inMapBorder())
        {
            return false;
        }
        if (pActor.isAlreadyTransformed())
        {
            return false;
        }
        string tStatsID = pActor.asset.skeleton_id;
        pActor.finishStatusEffect("cursed");
        pActor.removeTrait("infected");
        pActor.removeTrait("mush_spores");
        pActor.removeTrait("tumor_infection");
        Actor tSkeleton = World.world.units.createNewUnit(tStatsID, pActor.current_tile, false, 0f, null, null, false);
        ActorTool.copyUnitToOtherUnit(pActor, tSkeleton, true);
        tSkeleton.data.setName("Un" + Toolbox.LowerCaseFirst(pActor.getName()));
        EffectsLibrary.spawn("fx_spawn", tSkeleton.current_tile, null, null, 0f, -1f, -1f);
        ActionLibrary.removeUnit(pTarget.a);
        pActor.setTransformed();
        return false;
    }
    [HarmonyTranspiler, HarmonyPatch(typeof(Actor), nameof(Actor.updateStats))]
    private static IEnumerable<CodeInstruction> Actor_updateStats_transpiler(IEnumerable<CodeInstruction> codes)
    {
        var list = codes.ToList();

        var insert_idx = 1 + list.FindIndex(x =>
            x.opcode == OpCodes.Call && (x.operand as MethodBase)?.Name == nameof(Actor.addSpecialEffectAugmentations));
        list.InsertRange(insert_idx, new[]
        {
            new CodeInstruction(OpCodes.Ldarg_0),
            new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(patch), nameof(FixTraitActionMissing)))
        });
        return list;
    }

    private static void FixTraitActionMissing(Actor actor)
    {
        foreach (var trait in actor.traits)
        {
            if (!trait.only_active_on_era_flag || ((!trait.era_active_moon || World.world_era.flag_moon) && (!trait.era_active_night || World.world_era.overlay_darkness)))
            {
                if (trait.action_get_hit != null)
                    actor.s_get_hit_action += trait.action_get_hit;
            }
        }
    }
}