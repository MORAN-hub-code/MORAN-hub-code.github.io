namespace Chinese_Name;

public interface IPatch
{
    public void Initialize();
}