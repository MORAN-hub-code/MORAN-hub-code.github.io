﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using strings;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        public static void Init()
        {
            ActorTrait ZhanXun1 = new ActorTrait();
            ZhanXun1.id = "ZhanXun1";
            ZhanXun1.path_icon = "trait/ZhanXun1";
            ZhanXun1.needs_to_be_explored = false;
            ZhanXun1.group_id = "ZhanXun";
            ZhanXun1.base_stats = new BaseStats();
            ZhanXun1.base_stats[strings.S.lifespan] = 1f;
            ZhanXun1.base_stats[strings.S.damage] = 1f;
            ZhanXun1.base_stats[strings.S.health] = 10f;
            ZhanXun1.base_stats[strings.S.targets] = 1f;
            AssetManager.traits.add(ZhanXun1);

            ActorTrait ZhanXun2 = new ActorTrait();
            ZhanXun2.id = "ZhanXun2";
            ZhanXun2.path_icon = "trait/ZhanXun2";
            ZhanXun2.needs_to_be_explored = false;
            ZhanXun2.group_id = "ZhanXun";
            ZhanXun2.base_stats = new BaseStats();
            ZhanXun2.base_stats[strings.S.lifespan] = 10f;
            ZhanXun2.base_stats[strings.S.damage] = 10f;
            ZhanXun2.base_stats[strings.S.health] = 100f;
            ZhanXun2.base_stats[strings.S.targets] = 2f;
            ZhanXun2.base_stats[strings.S.accuracy] = 1f;
            ZhanXun2.base_stats[strings.S.warfare] = 1f;
            ZhanXun2.base_stats[strings.S.stewardship] = 1f;
            ZhanXun2.base_stats[strings.S.armor] = 1f;
            ZhanXun2.base_stats[strings.S.attack_speed] = 2f;
            ZhanXun2.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun2.action_special_effect,
                    new WorldAction(traitAction.ZhanXun2_effectAction)); 
            AssetManager.traits.add(ZhanXun2);

            ActorTrait ZhanXun3 = new ActorTrait();
            ZhanXun3.id = "ZhanXun3";
            ZhanXun3.path_icon = "trait/ZhanXun3";
            ZhanXun3.needs_to_be_explored = false;
            ZhanXun3.group_id = "ZhanXun";
            ZhanXun3.base_stats = new BaseStats();
            ZhanXun3.base_stats[strings.S.lifespan] = 20f;
            ZhanXun3.base_stats[strings.S.damage] = 20f;
            ZhanXun3.base_stats[strings.S.health] = 200f;
            ZhanXun3.base_stats[strings.S.targets] = 3f;
            ZhanXun3.base_stats[strings.S.accuracy] = 2f;
            ZhanXun3.base_stats[strings.S.warfare] = 2f;
            ZhanXun3.base_stats[strings.S.stewardship] = 2f;
            ZhanXun3.base_stats[strings.S.armor] = 2f;
            ZhanXun3.base_stats[strings.S.attack_speed] = 2f;
            ZhanXun3.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun3.action_special_effect,
                new WorldAction(traitAction.ZhanXun3_effectAction));
            AssetManager.traits.add(ZhanXun3);

            ActorTrait ZhanXun4 = new ActorTrait();
            ZhanXun4.id = "ZhanXun4";
            ZhanXun4.path_icon = "trait/ZhanXun4";
            ZhanXun4.needs_to_be_explored = false;
            ZhanXun4.group_id = "ZhanXun";
            ZhanXun4.base_stats = new BaseStats();
            ZhanXun4.base_stats[strings.S.lifespan] = 30f;
            ZhanXun4.base_stats[strings.S.damage] = 30f;
            ZhanXun4.base_stats[strings.S.health] = 300f;
            ZhanXun4.base_stats[strings.S.targets] = 4f;
            ZhanXun4.base_stats[strings.S.accuracy] = 3f;
            ZhanXun4.base_stats[strings.S.warfare] = 3f;
            ZhanXun4.base_stats[strings.S.stewardship] = 3f;
            ZhanXun4.base_stats[strings.S.armor] = 3f;
            ZhanXun4.base_stats[strings.S.attack_speed] = 2f;
            ZhanXun4.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun4.action_special_effect,
                new WorldAction(traitAction.ZhanXun4_effectAction));
            AssetManager.traits.add(ZhanXun4);

            ActorTrait ZhanXun5 = new ActorTrait();
            ZhanXun5.id = "ZhanXun5";
            ZhanXun5.path_icon = "trait/ZhanXun5";
            ZhanXun5.needs_to_be_explored = false;
            ZhanXun5.group_id = "ZhanXun";
            ZhanXun5.base_stats = new BaseStats();
            ZhanXun5.base_stats[strings.S.lifespan] = 50f;
            ZhanXun5.base_stats[strings.S.damage] = 50f;
            ZhanXun5.base_stats[strings.S.health] = 500f;
            ZhanXun5.base_stats[strings.S.targets] = 5f;
            ZhanXun5.base_stats[strings.S.accuracy] = 5f;
            ZhanXun5.base_stats[strings.S.warfare] = 5f;
            ZhanXun5.base_stats[strings.S.stewardship] = 5f;
            ZhanXun5.base_stats[strings.S.armor] = 5f;
            ZhanXun5.base_stats[strings.S.attack_speed] = 4f;
            ZhanXun5.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun5.action_special_effect,
                new WorldAction(traitAction.ZhanXun5_effectAction));
            AssetManager.traits.add(ZhanXun5);

            ActorTrait ZhanXun6 = new ActorTrait();
            ZhanXun6.id = "ZhanXun6";
            ZhanXun6.path_icon = "trait/ZhanXun6";
            ZhanXun6.needs_to_be_explored = false;
            ZhanXun6.group_id = "ZhanXun";
            ZhanXun6.base_stats = new BaseStats();
            ZhanXun6.base_stats[strings.S.lifespan] = 70f;
            ZhanXun6.base_stats[strings.S.damage] = 70f;
            ZhanXun6.base_stats[strings.S.health] = 700f;
            ZhanXun6.base_stats[strings.S.targets] = 6f;
            ZhanXun6.base_stats[strings.S.accuracy] = 7f;
            ZhanXun6.base_stats[strings.S.warfare] = 7f;
            ZhanXun6.base_stats[strings.S.stewardship] = 7f;
            ZhanXun6.base_stats[strings.S.armor] = 7f;
            ZhanXun6.base_stats[strings.S.attack_speed] = 4f;
            ZhanXun6.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun6.action_special_effect,
                new WorldAction(traitAction.ZhanXun6_effectAction));
            AssetManager.traits.add(ZhanXun6);

            ActorTrait ZhanXun7 = new ActorTrait();
            ZhanXun7.id = "ZhanXun7";
            ZhanXun7.path_icon = "trait/ZhanXun7";
            ZhanXun7.needs_to_be_explored = false;
            ZhanXun7.group_id = "ZhanXun";
            ZhanXun7.base_stats = new BaseStats();
            ZhanXun7.base_stats[strings.S.lifespan] = 100f;
            ZhanXun7.base_stats[strings.S.damage] = 100f;
            ZhanXun7.base_stats[strings.S.health] = 1000f;
            ZhanXun7.base_stats[strings.S.targets] = 7f;
            ZhanXun7.base_stats[strings.S.accuracy] = 10f;
            ZhanXun7.base_stats[strings.S.warfare] = 10f;
            ZhanXun7.base_stats[strings.S.stewardship] = 10f;
            ZhanXun7.base_stats[strings.S.armor] = 10f;
            ZhanXun7.base_stats[strings.S.attack_speed] = 6f;
            ZhanXun7.base_stats[strings.S.multiplier_damage] = 0.5f;
            ZhanXun7.base_stats[strings.S.multiplier_health] = 0.5f;
            ZhanXun7.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun7.action_special_effect,
                new WorldAction(traitAction.ZhanXun7_effectAction));
            AssetManager.traits.add(ZhanXun7);

            ActorTrait ZhanXun8 = new ActorTrait();
            ZhanXun8.id = "ZhanXun8";
            ZhanXun8.path_icon = "trait/ZhanXun8";
            ZhanXun8.needs_to_be_explored = false;
            ZhanXun8.group_id = "ZhanXun";
            ZhanXun8.base_stats = new BaseStats();
            ZhanXun8.base_stats[strings.S.lifespan] = 200f;
            ZhanXun8.base_stats[strings.S.damage] = 200f;
            ZhanXun8.base_stats[strings.S.health] = 2000f;
            ZhanXun8.base_stats[strings.S.targets] = 8f;
            ZhanXun8.base_stats[strings.S.accuracy] = 20f;
            ZhanXun8.base_stats[strings.S.warfare] = 20f;
            ZhanXun8.base_stats[strings.S.stewardship] = 20f;
            ZhanXun8.base_stats[strings.S.armor] = 20f;
            ZhanXun8.base_stats[strings.S.attack_speed] = 6f;
            ZhanXun8.base_stats[strings.S.multiplier_damage] = 0.7f;
            ZhanXun8.base_stats[strings.S.multiplier_health] = 0.7f;
            ZhanXun8.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun8.action_special_effect,
                new WorldAction(traitAction.ZhanXun8_effectAction));
            AssetManager.traits.add(ZhanXun8);

            ActorTrait ZhanXun9 = new ActorTrait();
            ZhanXun9.id = "ZhanXun9";
            ZhanXun9.path_icon = "trait/ZhanXun9";
            ZhanXun9.needs_to_be_explored = false;
            ZhanXun9.group_id = "ZhanXun";
            ZhanXun9.base_stats = new BaseStats();
            ZhanXun9.base_stats[strings.S.lifespan] = 300f;
            ZhanXun9.base_stats[strings.S.damage] = 300f;
            ZhanXun9.base_stats[strings.S.health] = 300f;
            ZhanXun9.base_stats[strings.S.targets] = 9f;
            ZhanXun9.base_stats[strings.S.accuracy] = 30f;
            ZhanXun9.base_stats[strings.S.warfare] = 30f;
            ZhanXun9.base_stats[strings.S.stewardship] = 30f;
            ZhanXun9.base_stats[strings.S.armor] = 30f;
            ZhanXun9.base_stats[strings.S.attack_speed] = 6f;
            ZhanXun9.base_stats[strings.S.multiplier_damage] = 1f;
            ZhanXun9.base_stats[strings.S.multiplier_health] = 1f;
            ZhanXun9.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun9.action_special_effect,
                new WorldAction(traitAction.ZhanXun9_effectAction));
            AssetManager.traits.add(ZhanXun9);

            ActorTrait ZhanXun91 = new ActorTrait();
            ZhanXun91.id = "ZhanXun91";
            ZhanXun91.path_icon = "trait/ZhanXun91";
            ZhanXun91.needs_to_be_explored = false;
            ZhanXun91.group_id = "ZhanXun";
            ZhanXun91.base_stats = new BaseStats();
            ZhanXun91.base_stats[strings.S.lifespan] = 500f;
            ZhanXun91.base_stats[strings.S.damage] = 500f;
            ZhanXun91.base_stats[strings.S.health] = 5000f;
            ZhanXun91.base_stats[strings.S.targets] = 10f;
            ZhanXun91.base_stats[strings.S.accuracy] = 50f;
            ZhanXun91.base_stats[strings.S.warfare] = 50f;
            ZhanXun91.base_stats[strings.S.stewardship] = 50f;
            ZhanXun91.base_stats[strings.S.armor] = 50f;
            ZhanXun91.base_stats[strings.S.attack_speed] = 8f;
            ZhanXun91.base_stats[strings.S.multiplier_damage] = 1.5f;
            ZhanXun91.base_stats[strings.S.multiplier_health] = 1.5f;
            ZhanXun91.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun91.action_special_effect,
                new WorldAction(traitAction.ZhanXun91_effectAction));
            AssetManager.traits.add(ZhanXun91);

            ActorTrait ZhanXun92 = new ActorTrait();
            ZhanXun92.id = "ZhanXun92";
            ZhanXun92.path_icon = "trait/ZhanXun92";
            ZhanXun92.needs_to_be_explored = false;
            ZhanXun92.group_id = "ZhanXun";
            ZhanXun92.base_stats = new BaseStats();
            ZhanXun92.base_stats[strings.S.lifespan] = 700f;
            ZhanXun92.base_stats[strings.S.damage] = 700f;
            ZhanXun92.base_stats[strings.S.health] = 7000f;
            ZhanXun92.base_stats[strings.S.targets] = 11f;
            ZhanXun92.base_stats[strings.S.accuracy] = 70f;
            ZhanXun92.base_stats[strings.S.warfare] = 70f;
            ZhanXun92.base_stats[strings.S.stewardship] = 70f;
            ZhanXun92.base_stats[strings.S.armor] = 70f;
            ZhanXun92.base_stats[strings.S.attack_speed] = 8f;
            ZhanXun92.base_stats[strings.S.multiplier_damage] = 1.7f;
            ZhanXun92.base_stats[strings.S.multiplier_health] = 1.7f;
            ZhanXun92.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun92.action_special_effect,
                new WorldAction(traitAction.ZhanXun92_effectAction));
            AssetManager.traits.add(ZhanXun92);

            ActorTrait ZhanXun93 = new ActorTrait();
            ZhanXun93.id = "ZhanXun93";
            ZhanXun93.path_icon = "trait/ZhanXun93";
            ZhanXun93.needs_to_be_explored = false;
            ZhanXun93.group_id = "ZhanXun";
            ZhanXun93.base_stats = new BaseStats();
            ZhanXun93.base_stats[strings.S.lifespan] = 1000f;
            ZhanXun93.base_stats[strings.S.damage] = 1000f;
            ZhanXun93.base_stats[strings.S.health] = 10000f;
            ZhanXun93.base_stats[strings.S.targets] = 12f;
            ZhanXun93.base_stats[strings.S.accuracy] = 100f;
            ZhanXun93.base_stats[strings.S.warfare] = 100f;
            ZhanXun93.base_stats[strings.S.stewardship] = 100f;
            ZhanXun93.base_stats[strings.S.armor] = 100f;
            ZhanXun93.base_stats[strings.S.attack_speed] = 10f;
            ZhanXun93.base_stats[strings.S.multiplier_damage] = 2f;
            ZhanXun93.base_stats[strings.S.multiplier_health] = 2f;
            ZhanXun93.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun93.action_special_effect,
                new WorldAction(traitAction.ZhanXun93_effectAction));
            AssetManager.traits.add(ZhanXun93);

            ActorTrait ZhanXun94 = new ActorTrait();
            ZhanXun94.id = "ZhanXun94";
            ZhanXun94.path_icon = "trait/ZhanXun94";
            ZhanXun94.needs_to_be_explored = false;
            ZhanXun94.group_id = "ZhanXun";
            ZhanXun94.base_stats = new BaseStats();
            ZhanXun94.base_stats[strings.S.lifespan] = 2000f;
            ZhanXun94.base_stats[strings.S.damage] = 2000f;
            ZhanXun94.base_stats[strings.S.health] = 20000f;
            ZhanXun94.base_stats[strings.S.targets] = 13f;
            ZhanXun94.base_stats[strings.S.accuracy] = 200f;
            ZhanXun94.base_stats[strings.S.warfare] = 200f;
            ZhanXun94.base_stats[strings.S.stewardship] = 200f;
            ZhanXun94.base_stats[strings.S.armor] = 200f;
            ZhanXun94.base_stats[strings.S.attack_speed] = 10f;
            ZhanXun94.base_stats[strings.S.multiplier_damage] = 3f;
            ZhanXun94.base_stats[strings.S.multiplier_health] = 3f;
            ZhanXun94.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun94.action_special_effect,
                new WorldAction(traitAction.ZhanXun94_effectAction));
            AssetManager.traits.add(ZhanXun94);

            ActorTrait ZhanXun95 = new ActorTrait();
            ZhanXun95.id = "ZhanXun95";
            ZhanXun95.path_icon = "trait/ZhanXun95";
            ZhanXun95.needs_to_be_explored = false;
            ZhanXun95.group_id = "ZhanXun";
            ZhanXun95.base_stats = new BaseStats();
            ZhanXun95.base_stats[strings.S.lifespan] = 3000f;
            ZhanXun95.base_stats[strings.S.damage] = 3000f;
            ZhanXun95.base_stats[strings.S.health] = 30000f;
            ZhanXun95.base_stats[strings.S.targets] = 14f;
            ZhanXun95.base_stats[strings.S.accuracy] = 300f;
            ZhanXun95.base_stats[strings.S.warfare] = 300f;
            ZhanXun95.base_stats[strings.S.stewardship] = 300f;
            ZhanXun95.base_stats[strings.S.armor] = 300f;
            ZhanXun95.base_stats[strings.S.attack_speed] = 10f;
            ZhanXun95.base_stats[strings.S.multiplier_damage] = 4f;
            ZhanXun95.base_stats[strings.S.multiplier_health] = 4f;
            ZhanXun95.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun95.action_special_effect,
                new WorldAction(traitAction.ZhanXun95_effectAction));
            AssetManager.traits.add(ZhanXun95);

            ActorTrait ZhanXun96 = new ActorTrait();
            ZhanXun96.id = "ZhanXun96";
            ZhanXun96.path_icon = "trait/ZhanXun96";
            ZhanXun96.needs_to_be_explored = false;
            ZhanXun96.group_id = "ZhanXun";
            ZhanXun96.base_stats = new BaseStats();
            ZhanXun96.base_stats[strings.S.lifespan] = 5000f;
            ZhanXun96.base_stats[strings.S.damage] = 5000f;
            ZhanXun96.base_stats[strings.S.health] = 50000f;
            ZhanXun96.base_stats[strings.S.targets] = 15f;
            ZhanXun96.base_stats[strings.S.accuracy] = 500f;
            ZhanXun96.base_stats[strings.S.warfare] = 500f;
            ZhanXun96.base_stats[strings.S.stewardship] = 500f;
            ZhanXun96.base_stats[strings.S.armor] = 500f;
            ZhanXun96.base_stats[strings.S.attack_speed] = 12f;
            ZhanXun96.base_stats[strings.S.multiplier_damage] = 5f;
            ZhanXun96.base_stats[strings.S.multiplier_health] = 5f;
            ZhanXun96.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun96.action_special_effect,
                new WorldAction(traitAction.ZhanXun96_effectAction));
            AssetManager.traits.add(ZhanXun96);

            ActorTrait ZhanXun97 = new ActorTrait();
            ZhanXun97.id = "ZhanXun97";
            ZhanXun97.path_icon = "trait/ZhanXun97";
            ZhanXun97.needs_to_be_explored = false;
            ZhanXun97.group_id = "ZhanXun";
            ZhanXun97.base_stats = new BaseStats();
            ZhanXun97.base_stats[strings.S.lifespan] = 7000f;
            ZhanXun97.base_stats[strings.S.damage] = 7000f;
            ZhanXun97.base_stats[strings.S.health] = 70000f;
            ZhanXun97.base_stats[strings.S.targets] = 16f;
            ZhanXun97.base_stats[strings.S.accuracy] = 700f;
            ZhanXun97.base_stats[strings.S.warfare] = 700f;
            ZhanXun97.base_stats[strings.S.stewardship] = 700f;
            ZhanXun97.base_stats[strings.S.armor] = 700f;
            ZhanXun97.base_stats[strings.S.attack_speed] = 12f;
            ZhanXun97.base_stats[strings.S.multiplier_damage] = 7f;
            ZhanXun97.base_stats[strings.S.multiplier_health] = 7f;
            ZhanXun97.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun97.action_special_effect,
                new WorldAction(traitAction.ZhanXun97_effectAction));
            AssetManager.traits.add(ZhanXun97);

            ActorTrait ZhanXun98 = new ActorTrait();
            ZhanXun98.id = "ZhanXun98";
            ZhanXun98.path_icon = "trait/ZhanXun98";
            ZhanXun98.needs_to_be_explored = false;
            ZhanXun98.group_id = "ZhanXun";
            ZhanXun98.base_stats = new BaseStats();
            ZhanXun98.base_stats[strings.S.lifespan] = 10000f;
            ZhanXun98.base_stats[strings.S.damage] = 10000f;
            ZhanXun98.base_stats[strings.S.health] = 100000f;
            ZhanXun98.base_stats[strings.S.targets] = 20f;
            ZhanXun98.base_stats[strings.S.accuracy] = 1000f;
            ZhanXun98.base_stats[strings.S.warfare] = 1000f;
            ZhanXun98.base_stats[strings.S.stewardship] = 1000f;
            ZhanXun98.base_stats[strings.S.armor] = 1000f;
            ZhanXun98.base_stats[strings.S.attack_speed] = 14f;
            ZhanXun98.base_stats[strings.S.multiplier_damage] = 10f;
            ZhanXun98.base_stats[strings.S.multiplier_health] = 10f;
            ZhanXun98.action_special_effect += (WorldAction)Delegate.Combine(ZhanXun98.action_special_effect,
                new WorldAction(traitAction.ZhanXun98_effectAction));
            AssetManager.traits.add(ZhanXun98);

            //猎王者
            ActorTrait HunterKing = new ActorTrait();
            HunterKing.id = "HunterKing";
            HunterKing.path_icon = "trait/HunterKing";
            HunterKing.needs_to_be_explored = false;
            HunterKing.group_id = "ZhanXun";
            HunterKing.base_stats = new BaseStats();
            HunterKing.base_stats[strings.S.lifespan] = 200f;
            HunterKing.base_stats[strings.S.damage] = 400f;
            HunterKing.base_stats[strings.S.health] = 4000f;
            HunterKing.base_stats[strings.S.accuracy] = 20f;
            HunterKing.base_stats[strings.S.warfare] = 20f;
            HunterKing.base_stats[strings.S.stewardship] = 20f;
            HunterKing.base_stats[strings.S.targets] = 8f;
            HunterKing.base_stats[strings.S.armor] = 20f;
            HunterKing.base_stats[strings.S.attack_speed] =2f;
            HunterKing.base_stats[strings.S.mana] = 200f;
            HunterKing.base_stats[strings.S.stamina] = 400f;
            HunterKing.action_special_effect += (WorldAction)Delegate.Combine(HunterKing.action_special_effect,
                new WorldAction(traitAction.HunterKing_effectAction));
            AssetManager.traits.add(HunterKing);

            ActorTrait Gongmin1 = new ActorTrait();
            Gongmin1.id = "Gongmin1";
            Gongmin1.path_icon = "trait/Gongmin1";
            Gongmin1.needs_to_be_explored = false;
            Gongmin1.group_id = "Diversification";
            Gongmin1.base_stats = new BaseStats();
            Gongmin1.base_stats[strings.S.damage] = 1f;
            Gongmin1.base_stats[strings.S.health] = 10f;
            Gongmin1.base_stats[strings.S.targets] = 1f;          
            AssetManager.traits.add(Gongmin1);

            ActorTrait Gongmin2 = new ActorTrait();
            Gongmin2.id = "Gongmin2";
            Gongmin2.path_icon = "trait/Gongmin2";
            Gongmin2.needs_to_be_explored = false;
            Gongmin2.group_id = "Diversification";
            Gongmin2.base_stats = new BaseStats();
            Gongmin2.base_stats[strings.S.damage] = 10f;
            Gongmin2.base_stats[strings.S.health] = 100f;
            Gongmin2.base_stats[strings.S.targets] = 2f;
            Gongmin2.base_stats[strings.S.warfare] = 1f;
            Gongmin2.action_special_effect += (WorldAction)Delegate.Combine(Gongmin2.action_special_effect,
                    new WorldAction(traitAction.ZhanXun2_effectAction)); 
            AssetManager.traits.add(Gongmin2);

            ActorTrait Gongmin3 = new ActorTrait();
            Gongmin3.id = "Gongmin3";
            Gongmin3.path_icon = "trait/Gongmin3";
            Gongmin3.needs_to_be_explored = false;
            Gongmin3.group_id = "Diversification";
            Gongmin3.base_stats = new BaseStats();
            Gongmin3.base_stats[strings.S.damage] = 20f;
            Gongmin3.base_stats[strings.S.health] = 200f;
            Gongmin3.base_stats[strings.S.targets] = 3f;
            Gongmin3.base_stats[strings.S.warfare] = 2f;
            Gongmin3.action_special_effect += (WorldAction)Delegate.Combine(Gongmin3.action_special_effect,
                new WorldAction(traitAction.ZhanXun3_effectAction));
            AssetManager.traits.add(Gongmin3);

            ActorTrait Gongmin4 = new ActorTrait();
            Gongmin4.id = "Gongmin4";
            Gongmin4.path_icon = "trait/Gongmin4";
            Gongmin4.needs_to_be_explored = false;
            Gongmin4.group_id = "Diversification";
            Gongmin4.base_stats = new BaseStats();
            Gongmin4.base_stats[strings.S.damage] = 30f;
            Gongmin4.base_stats[strings.S.health] = 300f;
            Gongmin4.base_stats[strings.S.targets] = 4f;
            Gongmin4.base_stats[strings.S.warfare] = 3f;
            Gongmin4.action_special_effect += (WorldAction)Delegate.Combine(Gongmin4.action_special_effect,
                new WorldAction(traitAction.ZhanXun4_effectAction));
            AssetManager.traits.add(Gongmin4);

            ActorTrait Gongmin5 = new ActorTrait();
            Gongmin5.id = "Gongmin5";
            Gongmin5.path_icon = "trait/Gongmin5";
            Gongmin5.needs_to_be_explored = false;
            Gongmin5.group_id = "Diversification";
            Gongmin5.base_stats = new BaseStats();
            Gongmin5.base_stats[strings.S.damage] = 50f;
            Gongmin5.base_stats[strings.S.health] = 500f;
            Gongmin5.base_stats[strings.S.targets] = 5f;
            Gongmin5.base_stats[strings.S.warfare] = 5f;
            Gongmin5.action_special_effect += (WorldAction)Delegate.Combine(Gongmin5.action_special_effect,
                new WorldAction(traitAction.ZhanXun5_effectAction));
            AssetManager.traits.add(Gongmin5);

            ActorTrait Gongmin6 = new ActorTrait();
            Gongmin6.id = "Gongmin6";
            Gongmin6.path_icon = "trait/Gongmin6";
            Gongmin6.needs_to_be_explored = false;
            Gongmin6.group_id = "Diversification";
            Gongmin6.base_stats = new BaseStats();
            Gongmin6.base_stats[strings.S.damage] = 70f;
            Gongmin6.base_stats[strings.S.health] = 700f;
            Gongmin6.base_stats[strings.S.targets] = 6f;
            Gongmin6.base_stats[strings.S.warfare] = 7f;
            Gongmin6.action_special_effect += (WorldAction)Delegate.Combine(Gongmin6.action_special_effect,
                new WorldAction(traitAction.ZhanXun6_effectAction));
            AssetManager.traits.add(Gongmin6);

            ActorTrait Gongmin7 = new ActorTrait();
            Gongmin7.id = "Gongmin7";
            Gongmin7.path_icon = "trait/Gongmin7";
            Gongmin7.needs_to_be_explored = false;
            Gongmin7.group_id = "Diversification";
            Gongmin7.base_stats = new BaseStats();
            Gongmin7.base_stats[strings.S.damage] = 100f;
            Gongmin7.base_stats[strings.S.health] = 1000f;
            Gongmin7.base_stats[strings.S.targets] = 7f;
            Gongmin7.base_stats[strings.S.warfare] = 10f;
            Gongmin7.base_stats[strings.S.birth_rate] = 5f;
            Gongmin7.base_stats[strings.S.offspring] = 5f;
            Gongmin7.action_special_effect += (WorldAction)Delegate.Combine(Gongmin7.action_special_effect,
                new WorldAction(traitAction.ZhanXun7_effectAction));
            AssetManager.traits.add(Gongmin7);

            ActorTrait Gongmin8 = new ActorTrait();
            Gongmin8.id = "Gongmin8";
            Gongmin8.path_icon = "trait/Gongmin8";
            Gongmin8.needs_to_be_explored = false;
            Gongmin8.group_id = "Diversification";
            Gongmin8.base_stats = new BaseStats();
            Gongmin8.base_stats[strings.S.damage] = 200f;
            Gongmin8.base_stats[strings.S.health] = 2000f;
            Gongmin8.base_stats[strings.S.targets] = 8f;
            Gongmin8.base_stats[strings.S.warfare] = 20f;
            Gongmin8.base_stats[strings.S.birth_rate] = 7f;
            Gongmin8.base_stats[strings.S.offspring] = 7f;
            Gongmin8.action_special_effect += (WorldAction)Delegate.Combine(Gongmin8.action_special_effect,
                new WorldAction(traitAction.ZhanXun8_effectAction));
            AssetManager.traits.add(Gongmin8);

            ActorTrait Gongmin9 = new ActorTrait();
            Gongmin9.id = "Gongmin9";
            Gongmin9.path_icon = "trait/Gongmin9";
            Gongmin9.needs_to_be_explored = false;
            Gongmin9.group_id = "Diversification";
            Gongmin9.base_stats = new BaseStats();
            Gongmin9.base_stats[strings.S.damage] = 300f;
            Gongmin9.base_stats[strings.S.health] = 300f;
            Gongmin9.base_stats[strings.S.targets] = 9f;
            Gongmin9.base_stats[strings.S.warfare] = 30f;
            Gongmin9.base_stats[strings.S.birth_rate] = 10f;
            Gongmin9.base_stats[strings.S.offspring] = 10f;
            Gongmin9.action_special_effect += (WorldAction)Delegate.Combine(Gongmin9.action_special_effect,
                new WorldAction(traitAction.ZhanXun9_effectAction));
            AssetManager.traits.add(Gongmin9);

            ActorTrait Yiyuan1 = new ActorTrait();
            Yiyuan1.id = "Yiyuan1";
            Yiyuan1.path_icon = "trait/Yiyuan1";
            Yiyuan1.needs_to_be_explored = false;
            Yiyuan1.group_id = "Diversification";
            Yiyuan1.base_stats = new BaseStats();
            Yiyuan1.base_stats[strings.S.damage] = 500f;
            Yiyuan1.base_stats[strings.S.health] = 5000f;
            Yiyuan1.base_stats[strings.S.targets] = 10f;
            Yiyuan1.base_stats[strings.S.warfare] = 50f;
            Yiyuan1.base_stats[strings.S.birth_rate] = 15f;
            Yiyuan1.base_stats[strings.S.offspring] = 15f;
            Yiyuan1.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan1.action_special_effect,
                new WorldAction(traitAction.ZhanXun91_effectAction));
            AssetManager.traits.add(Yiyuan1);

            ActorTrait Yiyuan2 = new ActorTrait();
            Yiyuan2.id = "Yiyuan2";
            Yiyuan2.path_icon = "trait/Yiyuan2";
            Yiyuan2.needs_to_be_explored = false;
            Yiyuan2.group_id = "Diversification";
            Yiyuan2.base_stats = new BaseStats();
            Yiyuan2.base_stats[strings.S.damage] = 700f;
            Yiyuan2.base_stats[strings.S.health] = 7000f;
            Yiyuan2.base_stats[strings.S.targets] = 11f;
            Yiyuan2.base_stats[strings.S.warfare] = 70f;
            Yiyuan2.base_stats[strings.S.birth_rate] = 17f;
            Yiyuan2.base_stats[strings.S.offspring] = 17f;
            Yiyuan2.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan2.action_special_effect,
                new WorldAction(traitAction.ZhanXun92_effectAction));
            AssetManager.traits.add(Yiyuan2);

            ActorTrait Yiyuan3 = new ActorTrait();
            Yiyuan3.id = "Yiyuan3";
            Yiyuan3.path_icon = "trait/Yiyuan3";
            Yiyuan3.needs_to_be_explored = false;
            Yiyuan3.group_id = "Diversification";
            Yiyuan3.base_stats = new BaseStats();
            Yiyuan3.base_stats[strings.S.damage] = 1000f;
            Yiyuan3.base_stats[strings.S.health] = 10000f;
            Yiyuan3.base_stats[strings.S.targets] = 12f;
            Yiyuan3.base_stats[strings.S.warfare] = 100f;
            Yiyuan3.base_stats[strings.S.birth_rate] = 20f;
            Yiyuan3.base_stats[strings.S.offspring] = 20f;
            Yiyuan3.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan3.action_special_effect,
                new WorldAction(traitAction.ZhanXun93_effectAction));
            AssetManager.traits.add(Yiyuan3);

            ActorTrait Yiyuan4 = new ActorTrait();
            Yiyuan4.id = "Yiyuan4";
            Yiyuan4.path_icon = "trait/Yiyuan4";
            Yiyuan4.needs_to_be_explored = false;
            Yiyuan4.group_id = "Diversification";
            Yiyuan4.base_stats = new BaseStats();
            Yiyuan4.base_stats[strings.S.damage] = 2000f;
            Yiyuan4.base_stats[strings.S.health] = 20000f;
            Yiyuan4.base_stats[strings.S.targets] = 13f;
            Yiyuan4.base_stats[strings.S.warfare] = 200f;
            Yiyuan4.base_stats[strings.S.birth_rate] = 30f;
            Yiyuan4.base_stats[strings.S.offspring] = 30f;
            Yiyuan4.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan4.action_special_effect,
                new WorldAction(traitAction.ZhanXun94_effectAction));
            AssetManager.traits.add(Yiyuan4);

            ActorTrait Yiyuan5 = new ActorTrait();
            Yiyuan5.id = "Yiyuan5";
            Yiyuan5.path_icon = "trait/Yiyuan5";
            Yiyuan5.needs_to_be_explored = false;
            Yiyuan5.group_id = "Diversification";
            Yiyuan5.base_stats = new BaseStats();
            Yiyuan5.base_stats[strings.S.damage] = 3000f;
            Yiyuan5.base_stats[strings.S.health] = 30000f;
            Yiyuan5.base_stats[strings.S.targets] = 14f;
            Yiyuan5.base_stats[strings.S.warfare] = 300f;
            Yiyuan5.base_stats[strings.S.birth_rate] = 40f;
            Yiyuan5.base_stats[strings.S.offspring] = 40f;
            Yiyuan5.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan5.action_special_effect,
                new WorldAction(traitAction.ZhanXun95_effectAction));
            AssetManager.traits.add(Yiyuan5);

            ActorTrait Yiyuan6 = new ActorTrait();
            Yiyuan6.id = "Yiyuan6";
            Yiyuan6.path_icon = "trait/Yiyuan6";
            Yiyuan6.needs_to_be_explored = false;
            Yiyuan6.group_id = "Diversification";
            Yiyuan6.base_stats = new BaseStats();
            Yiyuan6.base_stats[strings.S.damage] = 5000f;
            Yiyuan6.base_stats[strings.S.health] = 50000f;
            Yiyuan6.base_stats[strings.S.targets] = 15f;
            Yiyuan6.base_stats[strings.S.warfare] = 500f;
            Yiyuan6.base_stats[strings.S.birth_rate] = 50f;
            Yiyuan6.base_stats[strings.S.offspring] = 50f;
            Yiyuan6.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan6.action_special_effect,
                new WorldAction(traitAction.ZhanXun96_effectAction));
            AssetManager.traits.add(Yiyuan6);

            ActorTrait Yiyuan7 = new ActorTrait();
            Yiyuan7.id = "Yiyuan7";
            Yiyuan7.path_icon = "trait/Yiyuan7";
            Yiyuan7.needs_to_be_explored = false;
            Yiyuan7.group_id = "Diversification";
            Yiyuan7.base_stats = new BaseStats();
            Yiyuan7.base_stats[strings.S.damage] = 7000f;
            Yiyuan7.base_stats[strings.S.health] = 70000f;
            Yiyuan7.base_stats[strings.S.targets] = 16f;
            Yiyuan7.base_stats[strings.S.warfare] = 700f;
            Yiyuan7.base_stats[strings.S.birth_rate] = 70f;
            Yiyuan7.base_stats[strings.S.offspring] = 70f;
            Yiyuan7.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan7.action_special_effect,
                new WorldAction(traitAction.ZhanXun97_effectAction));
            AssetManager.traits.add(Yiyuan7);

            ActorTrait Yiyuan8 = new ActorTrait();
            Yiyuan8.id = "Yiyuan8";
            Yiyuan8.path_icon = "trait/Yiyuan8";
            Yiyuan8.needs_to_be_explored = false;
            Yiyuan8.group_id = "Diversification";
            Yiyuan8.base_stats = new BaseStats();
            Yiyuan8.base_stats[strings.S.damage] = 10000f;
            Yiyuan8.base_stats[strings.S.health] = 100000f;
            Yiyuan8.base_stats[strings.S.targets] = 20f;
            Yiyuan8.base_stats[strings.S.warfare] = 1000f;
            Yiyuan8.base_stats[strings.S.birth_rate] = 100f;
            Yiyuan8.base_stats[strings.S.offspring] = 100f;
            Yiyuan8.action_special_effect += (WorldAction)Delegate.Combine(Yiyuan8.action_special_effect,
                new WorldAction(traitAction.ZhanXun98_effectAction));
            AssetManager.traits.add(Yiyuan8);

            ActorTrait Diversification1 = new ActorTrait();
            Diversification1.id = "Diversification1";
            Diversification1.path_icon = "trait/Diversification1";
            Diversification1.needs_to_be_explored = false;
            Diversification1.group_id = "Diversification";
            Diversification1.base_stats = new BaseStats();
            Diversification1.rate_inherit = 100;
            Diversification1.base_stats[strings.S.mana] = 100f;
            Diversification1.base_stats[strings.S.stamina] = 100f;
            Diversification1.action_special_effect += (WorldAction)Delegate.Combine(Diversification1.action_special_effect,
                    new WorldAction(traitAction.Diversification1_effectAction));  
            AssetManager.traits.add(Diversification1);

        }
    }
}