﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using ai.behaviours;
using life.taxi;
using EpPathFinding.cs;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {10, "ZhanXun1"},
            {50, "ZhanXun2"},
            {100, "ZhanXun3"},
            {150, "ZhanXun4"},
            {200, "ZhanXun5"},
            {250, "ZhanXun6"},
            {300, "ZhanXun7"},
            {350, "ZhanXun8"},
            {400, "ZhanXun9"},
            {500, "ZhanXun91"},
            {1000, "ZhanXun92"},
            {1500, "ZhanXun93"},
            {3000, "ZhanXun94"},
            {5000, "ZhanXun95"},
            {7500, "ZhanXun96"},
            {10000, "ZhanXun97"},
            {12500, "ZhanXun98"}
        };

        private static readonly Dictionary<string, int> ZhanXunLevels = new()
        {
            {"ZhanXun1", 1},
            {"ZhanXun2", 2},
            {"ZhanXun3", 3},
            {"ZhanXun4", 4},
            {"ZhanXun5", 5},
            {"ZhanXun6", 6},
            {"ZhanXun7", 7},
            {"ZhanXun8", 8},
            {"ZhanXun9", 9},
            {"ZhanXun91", 10},
            {"ZhanXun92", 11},
            {"ZhanXun93", 12},
            {"ZhanXun94", 13},
            {"ZhanXun95", 14},
            {"ZhanXun96", 15},
            {"ZhanXun97", 16},
            {"ZhanXun98", 17}
        };

        private static readonly Dictionary<long, int> KingKillCounts = new();

        private static int GetZhanXunLevel(Actor actor)
        {
            if (actor == null) return 0;

            int highestLevel = 0;
            foreach (var trait in actor.getTraits())
            {
                if (trait.group_id == "ZhanXun" && ZhanXunLevels.ContainsKey(trait.id))
                {
                    int level = ZhanXunLevels[trait.id];
                    if (level > highestLevel)
                    {
                        highestLevel = level;
                    }
                }
            }
            return highestLevel;
        }

        private static int GetKingKillCount(Actor actor)
        {
            if (actor == null) return 0;
            return KingKillCounts.TryGetValue(actor.getID(), out int count) ? count : 0;
        }

        private static void IncrementKingKillCount(Actor actor)
        {
            if (actor == null) return;
            long actorId = actor.getID();
            if (KingKillCounts.ContainsKey(actorId))
            {
                KingKillCounts[actorId]++;
            }
            else
            {
                KingKillCounts[actorId] = 1;
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance, Actor pDeadUnit)
        {
            if (__instance == null || !__instance.isAlive()) return;

            if (pDeadUnit != null && pDeadUnit.isKing())
            {
                IncrementKingKillCount(__instance);
                int kingKillCount = GetKingKillCount(__instance);

                if (kingKillCount >= 10 && !__instance.hasTrait("HunterKing"))
                {
                    __instance.addTrait("HunterKing", false);
                }
            }

            string highestTraitId = null;
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.renown >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                __instance.addTrait(highestTraitId, false);

                if (__instance.data.renown >= 10 && !__instance.hasTrait("fire_proof"))
                {
                    __instance.addTrait("fire_proof", false);
                }

                if (__instance.data.renown >= 100 && !__instance.hasTrait("freeze_proof"))
                {
                    __instance.addTrait("freeze_proof", false);
                }

                if (__instance.data.renown >= 100 && !__instance.hasTrait("immune"))
                {
                    __instance.addTrait("immune", false);
                }

                if (__instance.data.renown >= 100 && !__instance.hasTrait("strong_minded"))
                {
                    __instance.addTrait("strong_minded", false);
                }
            }
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.newArmy))]
        public static bool ArmyManager_newArmy_Prefix(ArmyManager __instance, Actor pActor, City pCity)
        {
            // 验证参数
            if (pActor == null || pCity == null) return true;
            
            // 确保士兵属于指定的城市和国家
            if (pActor.city != pCity || 
                pActor.city.kingdom == null || 
                pCity.kingdom == null || 
                pActor.city.kingdom != pCity.kingdom)
            {
                // 如果士兵不属于指定城市，阻止创建军队
                return false;
            }
            
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), nameof(Army.newArmy))]
        public static bool Army_newArmy_Prefix(Army __instance, Actor pActor, City pCity)
        {
            // 验证参数
            if (pActor == null || pCity == null) return true;
            
            // 确保士兵属于指定的城市和国家
            if (pActor.city != pCity || 
                pActor.city.kingdom == null || 
                pCity.kingdom == null || 
                pActor.city.kingdom != pCity.kingdom)
            {
                // 如果士兵不属于指定城市，阻止创建军队
                return false;
            }
            
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "setCitizenJob")]
        public static bool City_setCitizenJob_Prefix(City __instance, Actor pActor)
        {
            // 必须是本城市和本国家的单位
            if (pActor == null || pActor.city != __instance || pActor.city == null || pActor.city.kingdom != __instance.kingdom)
            {
                return true;
            }
            if (pActor.isKing() || pActor.isCityLeader())
            {
                return true;
            }
            // 确保只能招募本城市的士兵
            if (pActor.getCity() != __instance)
            {
                return true;
            }
            // 额外检查：确保士兵不属于其他军队
            if (pActor.army != null && pActor.army.getCity() != __instance)
            {
                return true;
            }
            // 额外检查：确保士兵不属于其他国家
            if (pActor.city != null && pActor.city.kingdom != __instance.kingdom)
            {
                return true;
            }
            bool hasZhanXun = pActor.getTraits().Any(trait => trait.group_id == "ZhanXun");
            if (hasZhanXun && __instance.checkCanMakeWarrior(pActor))
            {
                __instance.makeWarrior(pActor);
                var timerField = typeof(City).GetField("_timer_warrior", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (timerField != null)
                {
                    timerField.SetValue(__instance, 15f);
                }
                return false;
            }
            if (!__instance.isGettingCaptured() &&
                __instance._timer_warrior <= 0f &&
                pActor.isProfession(UnitProfession.Unit) &&
                __instance.getResourcesAmount("gold") > 10 &&
                __instance.hasEnoughFoodForArmy() &&
                __instance.tryToMakeWarrior(pActor))
            {
                return false;
            }
            if (__instance.checkCitizenJobList(AssetManager.citizen_job_library.list_priority_high, pActor))
            {
                return false;
            }
            if (!__instance.hasAnyFood() && __instance.checkCitizenJobList(AssetManager.citizen_job_library.list_priority_high_food, pActor))
            {
                return false;
            }
            List<CitizenJobAsset> tJobList = AssetManager.citizen_job_library.list_priority_normal;
            for (int i = 0; i < tJobList.Count; i++)
            {
                __instance._last_checked_job_id++;
                if (__instance._last_checked_job_id > tJobList.Count - 1)
                {
                    __instance._last_checked_job_id = 0;
                }
                CitizenJobAsset tCitizenJobAsset = tJobList[__instance._last_checked_job_id];
                if ((tCitizenJobAsset.ok_for_king || !pActor.isKing()) && (tCitizenJobAsset.ok_for_leader || !pActor.isCityLeader()) && __instance.checkCitizenJob(tCitizenJobAsset, __instance, pActor))
                {
                    return false;
                }
            }
            return false;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), nameof(Army.setCaptain))]
        public static bool Army_setCaptain_Prefix(Army __instance, Actor pActor)
        {
            // 如果要设置队长
            if (pActor != null)
            {
                var armyCity = __instance.getCity();
                // 如果军队有城市，检查队长是否属于该城市
                if (armyCity != null)
                {
                    // 如果队长没有城市，或者队长的城市不是军队所属城市，阻止设置队长
                    if (pActor.city == null || pActor.city != armyCity)
                    {
                        return false;
                    }
                    // 只有在两个王国都存在且不同时才阻止
                    if (pActor.city.kingdom != null && armyCity.kingdom != null && 
                        pActor.city.kingdom != armyCity.kingdom)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        // 实时检查并更换队长的方法
        private static void CheckAndUpdateCaptain(Army army)
        {
            if (army == null || army.units.Count == 0) return;
            
            // 获取军队所属城市
            City armyCity = army.getCity();
            
            Actor bestCandidate = null;
            int highestZhanXunLevel = -1;
            int bestDistance = int.MaxValue;
            
            // 第一优先级：查找战勋等级最高的单位
            foreach (var unit in army.units)
            {
                // 基本验证：单位必须存活且属于这个军队
                if (unit == null || !unit.isAlive() || unit.army != army) continue;
                
                // 验证单位属于该城市
                if (armyCity != null)
                {
                    if (unit.city == null || unit.city != armyCity) continue;
                    // 验证国家一致性（如果都有国家的话）
                    if (unit.city.kingdom != null && armyCity.kingdom != null && 
                        unit.city.kingdom != armyCity.kingdom) continue;
                }

                int zhanXunLevel = GetZhanXunLevel(unit);

                if (zhanXunLevel > 0)
                {
                    int distance = int.MaxValue;
                    if (army._prev_captain_position != null)
                    {
                        distance = Toolbox.SquaredDistTile(unit.current_tile, army._prev_captain_position);
                    }

                    if (zhanXunLevel > highestZhanXunLevel ||
                        (zhanXunLevel == highestZhanXunLevel && distance < bestDistance))
                    {
                        bestCandidate = unit;
                        highestZhanXunLevel = zhanXunLevel;
                        bestDistance = distance;
                    }
                }
            }

            // 第二优先级：如果没有战勋单位，选择战士
            if (bestCandidate == null)
            {
                var warriors = army.units.Where(u => 
                    u != null && u.isAlive() && u.army == army && u.isWarrior()
                ).ToList();
                
                if (armyCity != null)
                {
                    warriors = warriors.Where(u => 
                        u.city != null && u.city == armyCity &&
                        (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom)
                    ).ToList();
                }
                
                if (warriors.Count > 0)
                {
                    if (army._prev_captain_position == null)
                    {
                        // 随机选择战士
                        bestCandidate = warriors[UnityEngine.Random.Range(0, warriors.Count)];
                    }
                    else
                    {
                        // 选择距离前队长位置最近的战士
                        Actor nearestWarrior = null;
                        int nearestDistance = int.MaxValue;
                        foreach (var warrior in warriors)
                        {
                            int distance = Toolbox.SquaredDistTile(warrior.current_tile, army._prev_captain_position);
                            if (distance < nearestDistance)
                            {
                                nearestWarrior = warrior;
                                nearestDistance = distance;
                            }
                        }
                        bestCandidate = nearestWarrior;
                    }
                }
            }

            // 第三优先级：如果没有战士，按照原版逻辑选择任何单位
            if (bestCandidate == null)
            {
                if (army._prev_captain_position == null)
                {
                    // 随机选择一个单位
                    var aliveUnits = army.units.Where(u => 
                        u != null && u.isAlive() && u.army == army
                    ).ToList();
                    
                    if (armyCity != null)
                    {
                        aliveUnits = aliveUnits.Where(u => 
                            u.city != null && u.city == armyCity &&
                            (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom)
                        ).ToList();
                    }
                    
                    if (aliveUnits.Count > 0)
                    {
                        bestCandidate = aliveUnits[UnityEngine.Random.Range(0, aliveUnits.Count)];
                    }
                }
                else
                {
                    // 选择距离前队长位置最近的单位
                    Actor nearestUnit = null;
                    int nearestDistance = int.MaxValue;
                    foreach (var unit in army.units)
                    {
                        if (unit == null || !unit.isAlive() || unit.army != army) continue;
                        
                        if (armyCity != null)
                        {
                            if (unit.city == null || unit.city != armyCity) continue;
                            if (unit.city.kingdom != null && armyCity.kingdom != null && 
                                unit.city.kingdom != armyCity.kingdom) continue;
                        }
                        
                        int distance = Toolbox.SquaredDistTile(unit.current_tile, army._prev_captain_position);
                        if (distance < nearestDistance)
                        {
                            nearestUnit = unit;
                            nearestDistance = distance;
                        }
                    }
                    bestCandidate = nearestUnit;
                }
            }

            // 最后的兜底：选择任何存活的单位
            if (bestCandidate == null)
            {
                foreach (var unit in army.units)
                {
                    if (unit != null && unit.isAlive())
                    {
                        bestCandidate = unit;
                        break;
                    }
                }
            }

            // 检查是否需要更换队长
            if (bestCandidate != null && (!army.hasCaptain() || army.captain != bestCandidate))
            {
                // 只有当新队长的战勋等级严格大于当前队长时才更换
                if (!army.hasCaptain() || 
                    GetZhanXunLevel(bestCandidate) > GetZhanXunLevel(army.captain))
                {
                    army.setCaptain(bestCandidate);
                }
            }
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), "findCaptain")]
        public static bool Army_findCaptain_Prefix(Army __instance)
        {
            // 基本验证
            if (__instance == null) return true;
            
            // 检查队长是否死亡或无效
            if (__instance.hasCaptain() && (__instance.captain.isRekt() || !__instance.captain.isAlive()))
            {
                __instance.setCaptain(null);
            }

            // 如果队长是文明单位且有效，保持现状
            if (__instance.hasCaptain() && __instance.captain.isKingdomCiv())
            {
                return true;
            }

            // 移除无效队长
            if (__instance.hasCaptain())
            {
                __instance.setCaptain(null);
            }

            // 如果没有单位，无法选择队长
            if (__instance.units.Count == 0)
            {
                return true;
            }

            // 获取军队所属城市
            City armyCity = __instance.getCity();

            Actor bestCandidate = null;
            int highestZhanXunLevel = -1;
            int bestDistance = int.MaxValue;

            // 第一优先级：查找战勋等级最高的单位
            foreach (var unit in __instance.units)
            {
                // 基本验证：单位必须存活且属于这个军队
                if (unit == null || !unit.isAlive() || unit.army != __instance) continue;
                
                // 验证单位属于该城市
                if (armyCity != null)
                {
                    if (unit.city == null || unit.city != armyCity) continue;
                    // 验证国家一致性（如果都有国家的话）
                    if (unit.city.kingdom != null && armyCity.kingdom != null && 
                        unit.city.kingdom != armyCity.kingdom) continue;
                }

                int zhanXunLevel = GetZhanXunLevel(unit);

                if (zhanXunLevel > 0)
                {
                    int distance = int.MaxValue;
                    if (__instance._prev_captain_position != null)
                    {
                        distance = Toolbox.SquaredDistTile(unit.current_tile, __instance._prev_captain_position);
                    }

                    if (zhanXunLevel > highestZhanXunLevel ||
                        (zhanXunLevel == highestZhanXunLevel && distance < bestDistance))
                    {
                        bestCandidate = unit;
                        highestZhanXunLevel = zhanXunLevel;
                        bestDistance = distance;
                    }
                }
            }

            // 第二优先级：如果没有战勋单位，选择战士
            if (bestCandidate == null)
            {
                var warriors = __instance.units.Where(u => 
                    u != null && u.isAlive() && u.army == __instance && u.isWarrior()
                ).ToList();
                
                if (armyCity != null)
                {
                    warriors = warriors.Where(u => 
                        u.city != null && u.city == armyCity &&
                        (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom)
                    ).ToList();
                }
                
                if (warriors.Count > 0)
                {
                    if (__instance._prev_captain_position == null)
                    {
                        // 随机选择战士
                        bestCandidate = warriors[UnityEngine.Random.Range(0, warriors.Count)];
                    }
                    else
                    {
                        // 选择距离前队长位置最近的战士
                        Actor nearestWarrior = null;
                        int nearestDistance = int.MaxValue;
                        foreach (var warrior in warriors)
                        {
                            int distance = Toolbox.SquaredDistTile(warrior.current_tile, __instance._prev_captain_position);
                            if (distance < nearestDistance)
                            {
                                nearestWarrior = warrior;
                                nearestDistance = distance;
                            }
                        }
                        bestCandidate = nearestWarrior;
                    }
                }
            }

            // 第三优先级：如果没有战士，按照原版逻辑选择任何单位
            if (bestCandidate == null)
            {
                if (__instance._prev_captain_position == null)
                {
                    // 随机选择一个单位
                    var aliveUnits = __instance.units.Where(u => 
                        u != null && u.isAlive() && u.army == __instance
                    ).ToList();
                    
                    if (armyCity != null)
                    {
                        aliveUnits = aliveUnits.Where(u => 
                            u.city != null && u.city == armyCity &&
                            (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom)
                        ).ToList();
                    }
                    
                    if (aliveUnits.Count > 0)
                    {
                        bestCandidate = aliveUnits[UnityEngine.Random.Range(0, aliveUnits.Count)];
                    }
                }
                else
                {
                    // 选择距离前队长位置最近的单位
                    Actor nearestUnit = null;
                    int nearestDistance = int.MaxValue;
                    foreach (var unit in __instance.units)
                    {
                        if (unit == null || !unit.isAlive() || unit.army != __instance) continue;
                        
                        if (armyCity != null)
                        {
                            if (unit.city == null || unit.city != armyCity) continue;
                            if (unit.city.kingdom != null && armyCity.kingdom != null && 
                                unit.city.kingdom != armyCity.kingdom) continue;
                        }
                        
                        int distance = Toolbox.SquaredDistTile(unit.current_tile, __instance._prev_captain_position);
                        if (distance < nearestDistance)
                        {
                            nearestUnit = unit;
                            nearestDistance = distance;
                        }
                    }
                    bestCandidate = nearestUnit;
                }
            }

            // 最后的兜底：选择任何存活的单位
            if (bestCandidate == null)
            {
                foreach (var unit in __instance.units)
                {
                    if (unit != null && unit.isAlive())
                    {
                        bestCandidate = unit;
                        break;
                    }
                }
            }

            // 设置队长
            if (bestCandidate != null)
            {
                __instance.setCaptain(bestCandidate);
            }

            return false; // 完全拦截原版方法
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
        public static bool applyForceToUnit_Protection(AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            if (pTargetToCheck.isActor() && HasProtectedTrait(pTargetToCheck.a))
            {
                return false;
            }
            return true;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
        {
            return !HasProtectedTrait(__instance);
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
        {
            return !HasProtectedTrait(__instance);
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
        {
            return !HasProtectedTrait(__instance);
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
            {
                return !HasProtectedTrait(__instance);
            }
            return true;
        }

        private static readonly HashSet<string> ProtectedTraits = new()
        {
            "ZhanXun7", "ZhanXun8", "ZhanXun9", "ZhanXun91", "ZhanXun92",
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97",
            "ZhanXun98"
        };

        private static bool HasProtectedTrait(Actor actor)
        {
            if (actor == null) return false;
            return ProtectedTraits.Any(trait => actor.hasTrait(trait));
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.updateDirtyUnits))]
        public static void ArmyManager_updateDirtyUnits_Postfix(ArmyManager __instance)
        {
            // 在units列表更新后，移除不符合条件的士兵
            foreach (var army in __instance)
            {
                var armyCity = army.getCity();
                if (armyCity != null && army.units != null)
                {
                    // 收集需要移除的士兵
                    var toRemove = new List<Actor>();
                    foreach (var unit in army.units)
                    {
                        // 检查士兵是否属于这个军队且属于这个城市
                        if (unit == null || 
                            unit.army != army ||  // 士兵的军队引用不是当前军队
                            unit.city == null ||  // 士兵没有城市
                            unit.city != armyCity)  // 士兵的城市不是军队所属城市
                        {
                            toRemove.Add(unit);
                        }
                    }
                    
                    // 只有在不会导致军队完全为空的情况下才移除士兵
                    if (toRemove.Count < army.units.Count)
                    {
                        // 执行移除
                        foreach (var unit in toRemove)
                        {
                            if (unit != null)
                            {
                                unit.removeFromArmy();
                            }
                        }
                    }
                    // 如果移除所有士兵会导致军队为空，则不移除任何士兵
                    // 这样可以避免军队被认为是不活跃的
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.update))]
        public static void ForceOnlyFollowOrFightOrBoatAI(ArmyManager __instance, float pElapsed)
        {
            HashSet<string> allowedTasks = new HashSet<string>
            {
                "fighting",
                "warrior_army_follow_leader",
                "force_into_a_boat",
                "embark_into_boat",
                "sit_inside_boat",
                "taxi_check",
                "taxi_embark",
                "taxi_sit_inside",
                "taxi_find_ship_tile",
                "city_actor_warrior_taxi_check",
                "city_actor_attack_zone",
                "city_actor_attack_target",
                "city_actor_attack_building",
                "city_actor_attack_enemy_unit",
                "city_actor_attack_enemy_army",
                "city_actor_attack_enemy_city",
                "city_actor_attack_enemy_king",
                "city_actor_attack_enemy_leader",
                "check_warrior_transport",
                "boat_transport_check_taxi",
                "boat_transport_check",
                "boat_transport_go_load",
                "boat_transport_go_unload",
                "try_to_return_to_home_city"
            };
            foreach (var army in World.world.armies)
            {
                // 检查队长是否属于军队所属城市
                var armyCity = army.getCity();
                if (armyCity != null && army.captain != null)
                {
                    // 如果队长不属于军队所属城市或国家，移除队长
                    if (army.captain.city == null || 
                        army.captain.city != armyCity || 
                        (army.captain.city.kingdom != null && armyCity.kingdom != null && 
                         army.captain.city.kingdom != armyCity.kingdom))
                    {
                        army.setCaptain(null);
                    }
                }
                
                // 注意：不在这里移除士兵，让原版的units管理机制处理
                // 这样可以避免与findCaptain方法的冲突
                
                if (!IsPersonalArmy(army)) continue;
                var captain = army.captain;
                if (captain == null || !captain.isAlive()) continue;
                var allMembers = new List<Actor> { captain };
                allMembers.AddRange(army.units);
                foreach (var member in allMembers)
                {
                    if (member == null || !member.isAlive()) continue;
                    if (member.isCarryingResources())
                    {
                        member.giveInventoryResourcesToCity();
                    }
                    if (member.loot > 0)
                    {
                        member.takeAllOwnLoot();
                    }
                    var lover = member.lover;
                    if (lover != null && lover != member && !member.isClonedFrom(lover) && !member.isChildOf(lover) && !member.isParentOf(lover))
                    {
                        if (!(member.hasLover() && member.lover == lover))
                        {
                            member.becomeLoversWith(lover);
                        }
                    }
                    if (
                        lover != null &&
                        member.isSexFemale() &&
                        member.canBreed() &&
                        lover.canBreed() &&
                        member.isAdult() &&
                        lover.isAdult() &&
                        !member.hasReachedOffspringLimit() &&
                        !member.hasStatus("afterglow") &&
                        !lover.hasStatus("afterglow") &&
                        !member.hasStatus("pregnant") &&
                        member.city != null &&
                        member.city.getPopulationPeople() < member.city.getPopulationMaximum() * 2
                        )
                    {
                        float maturationTime = member.getMaturationTimeSeconds();
                        member.addStatusEffect("pregnant", maturationTime, true);
                        float afterglowTime = maturationTime + 60f;
                        member.addStatusEffect("afterglow", afterglowTime, true);
                        lover.addStatusEffect("afterglow", afterglowTime, true);
                    }
                    if (member.isHungry())
                    {
                        member.addNutritionFromEating(member.getMaxNutrition(), false, true);
                        member.countConsumed();
                    }
                    if (member.isWarrior() && member.getHappiness() < 50)
                    {
                        int newHappiness = member.getHappiness() + 20;
                        int maxHappiness = member.getMaxHappiness();
                        if (newHappiness > maxHappiness) newHappiness = maxHappiness;
                        member.setHappiness(newHappiness, true);
                    }
                    if (member.hasStatus("burning"))
                    {
                        member.finishStatusEffect("burning");
                    }
                    if (member.hasTrait("crippled"))
                    {
                        member.removeTrait("crippled");
                    }
                    if (member.hasTrait("eyepatch"))
                    {
                        member.removeTrait("eyepatch");
                    }
                    if (member.hasTrait("skin_burns"))
                    {
                        member.removeTrait("skin_burns");
                    }
                    if (member.city != null && member.city.hasAttackZoneOrder())
                    {
                        var targetTile = member.city.target_attack_zone.centerTile;
                        if (targetTile != null && !targetTile.isSameIsland(member.current_tile))
                        {
                            TaxiManager.newRequest(member, targetTile);
                        }
                    }
                    if (member != captain)
                    {
                        var curTask = member.ai?.task?.id;
                        if (string.IsNullOrEmpty(curTask) || !allowedTasks.Contains(curTask))
                        {
                            member.cancelAllBeh();
                            member.setTask("warrior_army_follow_leader", true, false, true);
                        }

                        if (curTask == "warrior_army_follow_leader" && member.ai?.task?.id == "warrior_army_follow_leader")
                        {
                            bool isStuck = false;

                            if (member.current_path.Count == 0)
                            {
                                var testPath = new List<WorldTile>();
                                AStarParam pathfindingParam = World.world.pathfinding_param;
                                pathfindingParam.resetParam();
                                pathfindingParam.block = false;
                                pathfindingParam.lava = !member.asset.die_in_lava;
                                pathfindingParam.ocean = member.isWaterCreature();
                                pathfindingParam.ground = (!member.isWaterCreature() || member.asset.force_land_creature);

                                if (!PathfinderTools.tryToGetSimplePath(member.current_tile, captain.current_tile, testPath, member.asset, pathfindingParam))
                                {
                                    isStuck = true;
                                }
                            }
                            else if (member.beh_tile_target != null)
                            {
                                var testPath = new List<WorldTile>();
                                AStarParam pathfindingParam = World.world.pathfinding_param;
                                pathfindingParam.resetParam();
                                pathfindingParam.block = false;
                                pathfindingParam.lava = !member.asset.die_in_lava;
                                pathfindingParam.ocean = member.isWaterCreature();
                                pathfindingParam.ground = (!member.isWaterCreature() || member.asset.force_land_creature);

                                if (!PathfinderTools.tryToGetSimplePath(member.current_tile, member.beh_tile_target, testPath, member.asset, pathfindingParam))
                                {
                                    isStuck = true;
                                }
                            }

                            if (isStuck)
                            {
                                WorldTile targetTile = captain.current_tile;
                                if (targetTile != null)
                                {
                                    var nearbyTiles = new List<WorldTile>();
                                    for (int dx = -3; dx <= 3; dx++)
                                    {
                                        for (int dy = -3; dy <= 3; dy++)
                                        {
                                            int newX = targetTile.pos.x + dx;
                                            int newY = targetTile.pos.y + dy;
                                            WorldTile nearbyTile = World.world.GetTile(newX, newY);
                                            if (nearbyTile != null &&
                                                !nearbyTile.Type.block &&
                                                !nearbyTile.Type.lava &&
                                                (member.isWaterCreature() ? nearbyTile.Type.ocean : nearbyTile.Type.ground))
                                            {
                                                nearbyTiles.Add(nearbyTile);
                                            }
                                        }
                                    }

                                    if (nearbyTiles.Count > 0)
                                    {
                                        WorldTile bestTile = nearbyTiles[0];
                                        float bestScore = float.MaxValue;
                                        foreach (var tile in nearbyTiles)
                                        {
                                            float tileDistanceToCaptain = Toolbox.SquaredDistTile(tile, captain.current_tile);
                                            if (tileDistanceToCaptain >= 4f && tileDistanceToCaptain <= 16f)
                                            {
                                                float score = tileDistanceToCaptain;
                                                if (score < bestScore)
                                                {
                                                    bestScore = score;
                                                    bestTile = tile;
                                                }
                                            }
                                        }

                                        if (bestScore == float.MaxValue)
                                        {
                                            bestTile = nearbyTiles[0];
                                            float bestDistance = float.MaxValue;
                                            foreach (var tile in nearbyTiles)
                                            {
                                                float tileDistance = Toolbox.SquaredDistTile(tile, captain.current_tile);
                                                if (tileDistance < bestDistance)
                                                {
                                                    bestDistance = tileDistance;
                                                    bestTile = tile;
                                                }
                                            }
                                        }

                                        member.cancelAllBeh();
                                        member.spawnOn(bestTile, 0f);
                                        member.setTask("warrior_army_follow_leader", true, false, true);
                                    }
                                }
                            }
                        }
                    }
                }
                if (captain != null && captain.isAlive())
                {
                    int captainZhanXunLevel = GetZhanXunLevel(captain);
                    long armyId = army.data.id;
                    if (!armySpellCooldowns.ContainsKey(armyId))
                        armySpellCooldowns[armyId] = new Dictionary<string, float>();
                    var cooldownDict = armySpellCooldowns[armyId];
                    foreach (var spell in ArmySpells)
                    {
                        if (captainZhanXunLevel < spell.minZhanXunLevel || captainZhanXunLevel > spell.maxZhanXunLevel)
                        {
                            continue;
                        }
                        if ((spell.id == "Johnson" || spell.id == "Selfde" || spell.id == "Ironarmor" || spell.id == "shield" || spell.id == "enhancement" || spell.id == "andblood" || spell.id == "Overload" || spell.id == "evilenergy_aura"))
                        {
                            bool anyFighting = allMembers.Exists(m => m != null && m.isAlive() && m.isFighting());
                            if (!anyFighting)
                            {
                                continue;
                            }
                        }
                        float cooldown = 0f;
                        cooldownDict.TryGetValue(spell.id, out cooldown);
                        if (cooldown <= 0f)
                        {
                            var allMembersForSpell = new List<Actor> { captain };
                            allMembersForSpell.AddRange(army.units);
                            if (spell.id == "teleport")
                            {
                                City targetCity = FindNearestEnemyCity(captain);
                                bool teleportSuccess = false;
                                if (targetCity != null)
                                {
                                    TileZone targetZone = targetCity.zones.GetRandom<TileZone>();
                                    if (targetZone != null)
                                    {
                                        WorldTile targetTile = targetZone.centerTile;
                                        if (targetTile != null)
                                        {
                                            foreach (var member2 in allMembersForSpell)
                                            {
                                                if (member2 != null && member2.isAlive())
                                                {
                                                    ActionLibrary.teleportEffect(member2, targetTile);
                                                    member2.cancelAllBeh();
                                                    member2.spawnOn(targetTile, 0f);
                                                }
                                            }
                                            teleportSuccess = true;
                                        }
                                    }
                                }
                                if (teleportSuccess)
                                {
                                    cooldownDict[spell.id] = spell.cooldown;
                                }
                            }
                            else
                            {
                                bool spellSuccess = false;
                                foreach (var member2 in allMembersForSpell)
                                {
                                    if (member2 != null && member2.isAlive())
                                    {
                                        if (spell.id == "heal_small")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.1f);
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_medium")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.2f);
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_large")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.5f);
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_Super")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.7f);
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_Ultimate")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(1f);
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else
                                        {
                                            member2.addStatusEffect(spell.statusId, spell.duration, true);
                                            spellSuccess = true;
                                        }
                                    }
                                }
                                if (spellSuccess)
                                {
                                    cooldownDict[spell.id] = spell.cooldown;
                                }
                            }
                        }
                        else
                        {
                            cooldownDict[spell.id] = cooldown - pElapsed;
                        }
                    }
                }
            }
        }
        private static bool IsPersonalArmy(Army army)
        {
            return true;
        }

        private class ArmySpell
        {
            public string id;
            public string statusId;
            public float duration;
            public float cooldown;
            public int minZhanXunLevel;
            public int maxZhanXunLevel;
            public string displayName;
        }

        private static readonly ArmySpell[] ArmySpells = new ArmySpell[]
        {
            new ArmySpell { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new ArmySpell { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new ArmySpell { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new ArmySpell { id = "shield", statusId = "shield", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "护盾术" },
            new ArmySpell { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new ArmySpell { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new ArmySpell { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new ArmySpell { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new ArmySpell { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new ArmySpell { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new ArmySpell { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new ArmySpell { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "御风术" },
            new ArmySpell { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new ArmySpell { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new ArmySpell { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new ArmySpell { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new ArmySpell { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" },
            // 可继续添加更多法术
        };

        private static readonly Dictionary<long, Dictionary<string, float>> armySpellCooldowns = new();

        private static City FindNearestEnemyCity(Actor captain)
        {
            if (captain == null || !captain.hasCity()) return null;

            City captainCity = captain.getCity();
            if (captainCity == null) return null;

            Kingdom captainKingdom = captainCity.kingdom;
            if (captainKingdom == null) return null;

            City nearestEnemyCity = null;
            float nearestDistance = float.MaxValue;

            foreach (var city in World.world.cities)
            {
                if (city == null || city == captainCity) continue;

                if (city.kingdom != null && captainKingdom.isEnemy(city.kingdom))
                {
                    float distance = float.MaxValue;
                    if (city.zones != null && city.zones.Count > 0)
                    {
                        TileZone firstZone = city.zones[0];
                        if (firstZone != null && firstZone.centerTile != null)
                        {
                            distance = Toolbox.SquaredDistTile(captain.current_tile, firstZone.centerTile);
                        }
                    }
                    if (distance < nearestDistance)
                    {
                        nearestDistance = distance;
                        nearestEnemyCity = city;
                    }
                }
            }

            return nearestEnemyCity;
        }

        private static City FindEnemyCapital(Kingdom kingdom)
        {
            if (kingdom == null) return null;

            City nearestEnemyCapital = null;
            float nearestDistance = float.MaxValue;

            foreach (var city in World.world.cities)
            {
                if (city == null) continue;

                if (city.kingdom != null && kingdom.isEnemy(city.kingdom) && city.kingdom.capital == city)
                {
                    float distance = float.MaxValue;
                    if (city.zones != null && city.zones.Count > 0)
                    {
                        TileZone firstZone = city.zones[0];
                        if (firstZone != null && firstZone.centerTile != null)
                        {
                            if (kingdom.capital != null && kingdom.capital.zones != null && kingdom.capital.zones.Count > 0)
                            {
                                TileZone kingdomZone = kingdom.capital.zones[0];
                                if (kingdomZone != null && kingdomZone.centerTile != null)
                                {
                                    distance = Toolbox.SquaredDistTile(kingdomZone.centerTile, firstZone.centerTile);
                                }
                            }
                        }
                    }
                    if (distance < nearestDistance)
                    {
                        nearestDistance = distance;
                        nearestEnemyCapital = city;
                    }
                }
            }

            return nearestEnemyCapital;
        }

        private static readonly HashSet<string> MilitarismTraits = new()
        {
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97", "ZhanXun98"
        };
        private const string MilitarismKingdomTrait = "militarism";

        private static readonly Dictionary<KingdomData, bool> MilitarismField = new();
        public static bool GetMilitarism(KingdomData data) => MilitarismField.TryGetValue(data, out var v) && v;
        public static void SetMilitarism(KingdomData data, bool value) => MilitarismField[data] = value;

        private static Actor FindHighestZhanXunActor(IEnumerable<Actor> actors)
        {
            Actor best = null;
            int bestLevel = -1;
            foreach (var actor in actors)
            {
                if (!actor.isAlive()) continue;
                int level = GetZhanXunLevel(actor);
                if (level > bestLevel)
                {
                    best = actor;
                    bestLevel = level;
                }
            }
            return best;
        }

        private static void SyncMilitarismLeaders(Kingdom kingdom)
        {
            if (!GetMilitarism(kingdom.data)) return;
            // 1. 国王 = 全体军勋最高者（只有当新国王战勋等级严格大于当前国王时才更换）
            var allUnits = kingdom.getUnits();
            var king = FindHighestZhanXunActor(allUnits);
            var oldKing = kingdom.king;
            
            // 只有当新国王存在、不是当前国王、且战勋等级严格大于当前国王时才更换
            if (king != null && king != oldKing && 
                (oldKing == null || GetZhanXunLevel(king) > GetZhanXunLevel(oldKing)))
            {
                if (king.city != null && king.city.leader == king)
                {
                    king.city.removeLeader();
                    king.setProfession(UnitProfession.Unit, true);
                }
                if (king.isWarrior())
                    king.stopBeingWarrior();
                king.setProfession(UnitProfession.Unit, true);

                if (oldKing != null)
                {
                    int year = Date.getYear(World.world.getCurWorldTime());
                    new WorldLogMessage(
                        WorldLogLibrary.king_new,
                        kingdom.name,
                        $"{kingdom.name}：{oldKing.getName()}于{year}年将王位传位于{king.getName()}",
                        year.ToString()
                    ).add();
                    kingdom.removeKing();
                    if (oldKing.city != null && oldKing.city.leader == oldKing)
                    {
                        oldKing.city.removeLeader();
                        oldKing.setProfession(UnitProfession.Unit, true);
                    }
                    if (oldKing.isWarrior())
                        oldKing.stopBeingWarrior();
                    if (oldKing.isKing())
                        oldKing.setProfession(UnitProfession.Unit, true);
                }
                kingdom.setKing(king, true);
                king.startShake();
                king.startColorEffect();
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "updateCityStatus")]
        public static void City_updateCityStatus_MilitarismPatch(City __instance)
        {
            if (__instance.kingdom == null) return;
            var kingdom = __instance.kingdom;
            bool shouldBeMilitarism = GetMilitarism(kingdom.data);
            if (!shouldBeMilitarism)
            {
                foreach (var actor in kingdom.getUnits())
                {
                    foreach (var trait in MilitarismTraits)
                    {
                        if (actor.hasTrait(trait))
                        {
                            shouldBeMilitarism = true;
                            break;
                        }
                    }
                    if (shouldBeMilitarism) break;
                }
            }
            if (shouldBeMilitarism && !GetMilitarism(kingdom.data))
            {
                SetMilitarism(kingdom.data, true);
                foreach (var city in kingdom.cities)
                {
                    if (city != null) city.updateCityStatus();
                }
            }
            if (GetMilitarism(kingdom.data))
            {
                SyncMilitarismLeaders(kingdom);
                int adultPop = 0;
                foreach (var actor in __instance.units)
                {
                    if (actor != null && actor.isAlive() && actor.isAdult())
                        adultPop++;
                }
                __instance.status.warrior_slots = (int)(adultPop * 0.9f);
            }
        }



        private class CountrySpell
        {
            public string id;
            public string statusId;
            public float duration;
            public float cooldown;
            public int minZhanXunLevel;
            public int maxZhanXunLevel;
            public string displayName;
        }

        private static readonly CountrySpell[] CountrySpells = new CountrySpell[]
        {
            new CountrySpell { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new CountrySpell { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new CountrySpell { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new CountrySpell { id = "shield", statusId = "shield", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "护盾术" },
            new CountrySpell { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new CountrySpell { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new CountrySpell { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new CountrySpell { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new CountrySpell { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new CountrySpell { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new CountrySpell { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new CountrySpell { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "御风术" },
            new CountrySpell { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new CountrySpell { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new CountrySpell { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new CountrySpell { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new CountrySpell { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" },
        };
        private static readonly Dictionary<long, Dictionary<string, float>> countrySpellCooldowns = new();

        private static bool IsKingdomInWar(Kingdom kingdom)
        {
            if (kingdom == null) return false;

            foreach (var war in World.world.wars.getWars(kingdom))
            {
                if (war != null && !war.hasEnded())
                {
                    return true;
                }
            }

            foreach (var otherKingdom in World.world.kingdoms)
            {
                if (otherKingdom != null && otherKingdom != kingdom && kingdom.isEnemy(otherKingdom))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsSpellRequireWar(string spellId)
        {
            HashSet<string> warRequiredSpells = new HashSet<string>
            {
                "Johnson",
                "Selfde",
                "Ironarmor",
                "shield",
                "Accelerate",
                "enhancement",
                "andblood",
                "Overload",
                "evilenergy_aura",
                "teleport"
            };

            return warRequiredSpells.Contains(spellId);
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "update")]
        public static void City_update_CountrySpell_Postfix(City __instance, float pElapsed)
        {
            if (__instance == null || __instance.kingdom == null) return;
            
            if (GetMilitarism(__instance.kingdom.data))
            {
                int currentWarriors = __instance.countWarriors();
                int maxWarriors = __instance.getMaxWarriors();
                if (currentWarriors < maxWarriors)
                {
                    var candidates = __instance.units.Where(a =>
                        a != null &&
                        a.isAlive() &&
                        a.isAdult() &&
                        a.city == __instance &&
                        a.city.kingdom == __instance.kingdom &&
                        !a.isWarrior() &&
                        !a.isCityLeader() &&
                        !a.isKing() &&
                        __instance.checkCanMakeWarrior(a)
                    ).ToList();
                    int need = maxWarriors - currentWarriors;
                    foreach (var actor in candidates.Take(need))
                    {
                        __instance.makeWarrior(actor);
                    }
                }
            }
            
            var kingdom = __instance.kingdom;
            var king = kingdom.king;
            if (king == null || !king.isAlive()) return;

            int kingZhanXunLevel = GetZhanXunLevel(king);
            long kingdomId = kingdom.data.id;
            if (!countrySpellCooldowns.ContainsKey(kingdomId))
                countrySpellCooldowns[kingdomId] = new Dictionary<string, float>();
            var cooldownDict = countrySpellCooldowns[kingdomId];
            foreach (var spell in CountrySpells)
            {
                if (kingZhanXunLevel < spell.minZhanXunLevel || kingZhanXunLevel > spell.maxZhanXunLevel)
                    continue;

                if (IsSpellRequireWar(spell.id) && !IsKingdomInWar(kingdom))
                    continue;

                float cooldown = 0f;
                cooldownDict.TryGetValue(spell.id, out cooldown);
                if (cooldown <= 0f)
                {
                    bool spellSuccess = false;
                    // 给所有本国单位施加buff或治疗
                    foreach (var unit in kingdom.getUnits())
                    {
                        if (unit != null && unit.isAlive())
                        {
                            if (spell.id == "heal_small")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.1f);
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_medium")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.2f);
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_large")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.5f);
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_Super")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.7f);
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_Ultimate")
                            {
                                int healAmount = unit.getMaxHealthPercent(1f);
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "teleport")
                            {
                                // 传送术：找到敌方首都并传送国王和所有军队成员
                                City targetCapital = FindEnemyCapital(kingdom);
                                if (targetCapital != null)
                                {
                                    TileZone targetZone = targetCapital.zones.GetRandom<TileZone>();
                                    if (targetZone != null)
                                    {
                                        WorldTile targetTile = targetZone.centerTile;
                                        if (targetTile != null)
                                        {
                                            var teleported = new HashSet<Actor>();
                                            // 传送国王
                                            if (king != null && king.isAlive())
                                            {
                                                ActionLibrary.teleportEffect(king, targetTile);
                                                king.cancelAllBeh();
                                                king.spawnOn(targetTile, 0f);
                                                teleported.Add(king);
                                            }
                                            // 传送所有军队成员（不重复传送国王）
                                            foreach (var army in World.world.armies)
                                            {
                                                if (army != null && army.getCity() != null && army.getCity().kingdom == kingdom)
                                                {
                                                    foreach (var armyUnit in army.units)
                                                    {
                                                        if (armyUnit != null && armyUnit.isAlive() && !teleported.Contains(armyUnit))
                                                        {
                                                            ActionLibrary.teleportEffect(armyUnit, targetTile);
                                                            armyUnit.cancelAllBeh();
                                                            armyUnit.spawnOn(targetTile, 0f);
                                                            teleported.Add(armyUnit);
                                                        }
                                                    }
                                                    // 传送队长
                                                    if (army.captain != null && army.captain.isAlive() && !teleported.Contains(army.captain))
                                                    {
                                                        ActionLibrary.teleportEffect(army.captain, targetTile);
                                                        army.captain.cancelAllBeh();
                                                        army.captain.spawnOn(targetTile, 0f);
                                                        teleported.Add(army.captain);
                                                    }
                                                }
                                            }
                                            spellSuccess = teleported.Count > 0;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                unit.addStatusEffect(spell.statusId, spell.duration, true);
                                spellSuccess = true;
                            }
                        }
                    }
                    if (spellSuccess)
                    {
                        cooldownDict[spell.id] = spell.cooldown;
                    }
                }
                else
                {
                    cooldownDict[spell.id] = cooldown - pElapsed;
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), nameof(City.addZone))]
        public static void MilitarismExpandNeighboursPatch(City __instance, TileZone pZone)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                foreach (var neighbour in pZone.neighbours_all)
                {
                    if (neighbour != null && neighbour.city == null)
                    {
                        neighbour.setCity(__instance);
                        __instance.zones.Add(neighbour);
                        __instance.updateCityCenter();
                        __instance.setStatusDirty();
                    }
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.getConstructionSpeed))]
        public static void GetConstructionSpeed_MilitarismPatch(Actor __instance, ref int __result)
        {
            if (__instance.city != null && __instance.city.kingdom != null && GetMilitarism(__instance.city.kingdom.data))
            {
                __result *= 10;
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ai.behaviours.CityBehBuild), "execute")]
        public static void CityBehBuild_execute_MilitarismPatch(City pCity)
        {
            if (pCity.kingdom != null && GetMilitarism(pCity.kingdom.data))
            {
                pCity.timer_build = 0.5f;
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ai.behaviours.CityBehSupplyKingdomCities), "updateSupplyTimer")]
        public static void CityBehSupplyKingdomCities_updateSupplyTimer_Postfix(City pCity)
        {
            if (pCity.kingdom != null && GetMilitarism(pCity.kingdom.data))
            {
                pCity.data.timer_supply = 0f;
            }
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "addResourcesToRandomStockpile")]
        public static void City_addResourcesToRandomStockpile_Prefix(City __instance, string pResourceID, ref int pAmount)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                var stack = new System.Diagnostics.StackTrace();
                for (int i = 0; i < stack.FrameCount; i++)
                {
                    var method = stack.GetFrame(i).GetMethod();
                    if (method.DeclaringType != null && method.DeclaringType.FullName == "ai.behaviours.CityBehSupplyKingdomCities" && method.Name == "shareResource")
                    {
                        return;
                    }
                }
                pAmount *= 999;
            }
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        [HarmonyPriority(Priority.First)]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            __instance._last_attack_type = pAttackType;
            if (__instance._cache_check_has_status_removed_on_damage)
            {
                foreach (Status tStatusData in __instance.getStatuses())
                {
                    if (tStatusData.asset.removed_on_damage && !tStatusData.is_finished)
                    {
                        __instance.finishStatusEffect(tStatusData.asset.id);
                    }
                }
            }
            if (DebugConfig.isOn(DebugOption.IgnoreDamage))
            {
                return false;
            }
            if (pSkipIfShake && __instance.shake_active)
            {
                return false;
            }
            __instance.attackedBy = null;
            if (pAttacker != null && pAttacker.isRekt())
            {
                pAttacker = null;
            }
            if (pAttacker != null && pAttacker != __instance)
            {
                __instance.attackedBy = pAttacker;
            }
            if (pAttacker != null && pAttacker.a != null && pAttacker.a.stats != null)
            {
                Actor attacker = pAttacker.a;
                float damage = attacker.stats["damage"];

                float minMultiplier = 0f, maxMultiplier = 0f;
                if (attacker.hasStatus("evilenergy_aura"))
                {
                    minMultiplier = 1f;
                    maxMultiplier = 1f;
                }
                else
                {
                    goto SkipMagicDamage;
                }

                float multiplier = UnityEngine.Random.Range(minMultiplier, maxMultiplier);
                int magicDamage = UnityEngine.Mathf.FloorToInt(damage * multiplier);
                __instance.changeHealth(-magicDamage);
                __instance.spawnParticle(new UnityEngine.Color(255, 0, 255));
            }

        SkipMagicDamage:
            if (__instance.hasStatus("invincible"))
            {
                return false;
            }
            Actor tAttackerUnit = (pAttacker != null) ? pAttacker.a : null;
            if (pAttackType == AttackType.Weapon)
            {
                bool tClank = false;
                if (pMetallicWeapon && __instance.haveMetallicWeapon())
                {
                    tClank = true;
                }
                if (tClank)
                {
                    MusicBox.playSound("event:/SFX/HIT/HitSwordSword", __instance.current_tile, false, true);
                }
                else if (__instance.asset.has_sound_hit)
                {
                    MusicBox.playSound(__instance.asset.sound_hit, __instance.current_tile, false, true);
                }
                if (tAttackerUnit != null && !__instance.hasStatus("shield"))
                {
                    __instance.damageEquipmentOnGetHit(tAttackerUnit);
                }
            }
            if (pCheckDamageReduction)
            {
                if (pAttackType == AttackType.Other || pAttackType == AttackType.Weapon)
                {
                    float tArmorPercent = 1f - __instance.stats["armor"] / 100f;
                    pDamage *= tArmorPercent;
                }
                if (pDamage < 1f)
                {
                    pDamage = 1f;
                }
                if (tAttackerUnit != null)
                {
                    float tFinalDamage;
                    __instance.checkSpecialAttackLogic(tAttackerUnit, pAttackType, pDamage, out tFinalDamage);
                    pDamage = tFinalDamage;
                    SignalManager.add(SignalLibrary.check_achievement_clone_wars, new ValueTuple<Actor, Actor>(__instance, tAttackerUnit));
                }
            }
            __instance.changeHealth((int)(-(int)pDamage));
            __instance.timer_action = 0.002f;
            GetHitAction getHitAction = __instance.s_get_hit_action;
            if (getHitAction != null)
            {
                getHitAction(__instance, pAttacker, __instance.current_tile);
            }
            if (pFlash)
            {
                __instance.startColorEffect(ActorColorEffect.Red);
            }
            if (!__instance.hasHealth())
            {
                __instance.batch.c_check_deaths.Add(__instance);
            }
            if (pAttackType == AttackType.Weapon && !__instance.asset.immune_to_injuries && !__instance.hasStatus("shield"))
            {
                if (Randy.randomChance(0.02f))
                {
                    __instance.addInjuryTrait("crippled");
                }
                if (Randy.randomChance(0.02f))
                {
                    __instance.addInjuryTrait("eyepatch");
                }
            }
            __instance.startShake(0.3f, 0.1f, true, true);
            if (!__instance.has_attack_target)
            {
                if (__instance.attackedBy != null && !__instance.shouldIgnoreTarget(__instance.attackedBy) && __instance.canAttackTarget(__instance.attackedBy, false))
                {
                    __instance.setAttackTarget(__instance.attackedBy);
                }
            }
            else if (__instance.hasMeleeAttack() && __instance.attackedBy != null && __instance.canAttackTarget(__instance.attackedBy, false))
            {
                float tDistToCurrentTarget = Toolbox.SquaredDistVec2Float(__instance.current_position, __instance.attack_target.current_position);
                float tDistToAttacker = Toolbox.SquaredDistVec2Float(__instance.current_position, pAttacker.current_position);
                if (tDistToCurrentTarget > __instance.getAttackRangeSquared() && tDistToAttacker < tDistToCurrentTarget)
                {
                    __instance.setAttackTarget(pAttacker);
                }
            }
            if (__instance.hasAnyStatusEffect())
            {
                foreach (Status status in __instance.getStatuses())
                {
                    GetHitAction action_get_hit = status.asset.action_get_hit;
                    if (action_get_hit != null)
                    {
                        action_get_hit(__instance, pAttacker, __instance.current_tile);
                    }
                }
            }
            GetHitAction action_get_hit2 = __instance.asset.action_get_hit;
            if (action_get_hit2 != null)
            {
                action_get_hit2(__instance, pAttacker, __instance.current_tile);
            }
            if (!__instance.hasHealth())
            {
                __instance.checkCallbacksOnDeath();
            }
            return false;
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "checkArmyExistance")]
        public static void City_checkArmyExistance_Postfix(City __instance)
        {
            // 确保军队存在且有效
            if (__instance.hasArmy() && __instance.army != null)
            {
                var army = __instance.army;
                
                // 如果军队没有队长，尝试重新选择
                if (!army.hasCaptain())
                {
                    // 首先尝试从军队现有单位中选择
                    if (army.units.Count > 0)
                    {
                        army.findCaptain();
                    }
                    else
                    {
                        // 如果军队没有单位，从城市中找战士加入军队
                        var cityWarriors = __instance.units.Where(u => 
                            u != null && u.isAlive() && u.isWarrior() && 
                            u.city == __instance && 
                            (u.city.kingdom == null || __instance.kingdom == null || u.city.kingdom == __instance.kingdom) &&
                            u.army == null  // 不属于其他军队
                        ).ToList();
                        
                        if (cityWarriors.Count > 0)
                        {
                            // 优先选择战勋等级最高的战士
                            var bestWarrior = cityWarriors.OrderByDescending(w => GetZhanXunLevel(w)).First();
                            bestWarrior.setArmy(army);
                            army.setCaptain(bestWarrior);
                        }
                        else
                        {
                            // 如果没有战士，尝试从城市中找任何合适的单位
                            var cityUnits = __instance.units.Where(u => 
                                u != null && u.isAlive() && 
                                u.city == __instance && 
                                (u.city.kingdom == null || __instance.kingdom == null || u.city.kingdom == __instance.kingdom) &&
                                u.army == null &&  // 不属于其他军队
                                !u.isKing() && !u.isCityLeader()  // 不是重要人物
                            ).ToList();
                            
                            if (cityUnits.Count > 0)
                            {
                                // 优先选择战勋等级最高的单位
                                var bestUnit = cityUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                                bestUnit.setArmy(army);
                                army.setCaptain(bestUnit);
                            }
                        }
                    }
                }
                
                // 如果军队有队长但没有单位，确保队长被添加到军队中
                if (army.hasCaptain() && army.units.Count == 0 && 
                    army.captain != null && army.captain.isAlive())
                {
                    army.captain.setArmy(army);
                }
                
                // 如果军队既没有单位也没有队长，尝试创建新的军队
                if (army.units.Count == 0 && !army.hasCaptain())
                {
                    // 从城市中找一个合适的单位创建新军队
                    var suitableUnits = __instance.units.Where(u => 
                        u != null && u.isAlive() && 
                        u.city == __instance && 
                        (u.city.kingdom == null || __instance.kingdom == null || u.city.kingdom == __instance.kingdom) &&
                        u.army == null &&  // 不属于其他军队
                        !u.isKing() && !u.isCityLeader()  // 不是重要人物
                    ).ToList();
                    
                    if (suitableUnits.Count > 0)
                    {
                        // 优先选择战勋等级最高的单位
                        var bestUnit = suitableUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                        
                        // 创建新军队
                        var newArmy = World.world.armies.newArmy(bestUnit, __instance);
                        if (newArmy != null)
                        {
                            newArmy.setCaptain(bestUnit);
                        }
                    }
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.update))]
        public static void ArmyManager_update_Postfix(ArmyManager __instance, float pElapsed)
        {
            // 确保每个军队都有队长，并实时检查是否需要更换队长
            foreach (var army in __instance)
            {
                if (army == null) continue;
                
                var armyCity = army.getCity();
                if (armyCity == null) continue;
                
                // 实时检查并更换队长（优先选择战勋等级最高者）
                CheckAndUpdateCaptain(army);
                
                // 如果军队仍然没有队长，尝试从城市中重新选择
                if (!army.hasCaptain())
                {
                    // 首先尝试从军队现有单位中选择
                    if (army.units.Count > 0)
                    {
                        army.findCaptain();
                    }
                    else
                    {
                        // 如果军队没有单位，从城市中找战士加入军队
                        var cityWarriors = armyCity.units.Where(u => 
                            u != null && u.isAlive() && u.isWarrior() && 
                            u.city == armyCity && 
                            (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom) &&
                            u.army == null  // 不属于其他军队
                        ).ToList();
                        
                        if (cityWarriors.Count > 0)
                        {
                            // 优先选择战勋等级最高的战士
                            var bestWarrior = cityWarriors.OrderByDescending(w => GetZhanXunLevel(w)).First();
                            bestWarrior.setArmy(army);
                            army.setCaptain(bestWarrior);
                        }
                    }
                }
                
                // 如果军队仍然没有队长，尝试从城市中找任何合适的单位
                if (!army.hasCaptain())
                {
                    var cityUnits = armyCity.units.Where(u => 
                        u != null && u.isAlive() && 
                        u.city == armyCity && 
                        (u.city.kingdom == null || armyCity.kingdom == null || u.city.kingdom == armyCity.kingdom) &&
                        u.army == null &&  // 不属于其他军队
                        !u.isKing() && !u.isCityLeader()  // 不是重要人物
                    ).ToList();
                    
                    if (cityUnits.Count > 0)
                    {
                        // 优先选择战勋等级最高的单位
                        var bestUnit = cityUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                        bestUnit.setArmy(army);
                        army.setCaptain(bestUnit);
                    }
                }
            }
            
            // 定期强制检查所有城市
            lastForceCheckTime += pElapsed;
            if (lastForceCheckTime >= FORCE_CHECK_INTERVAL)
            {
                lastForceCheckTime = 0f;
                ForceCheckAllCities();
            }
        }
        
        private static void CheckAndFixAllCities()
        {
            foreach (var city in World.world.cities)
            {
                if (city == null) continue;
                
                // 检查城市是否有军队
                if (!city.hasArmy())
                {
                    CreateArmyForCity(city);
                    continue;
                }
                
                // 检查军队是否有队长
                if (city.army != null && !city.army.hasCaptain())
                {
                    FixArmyCaptain(city.army, city);
                }
            }
        }
        
        private static void CreateArmyForCity(City city)
        {
            // 从城市中找一个合适的单位创建军队
            var suitableUnits = city.units.Where(u => 
                u != null && u.isAlive() && 
                u.city == city && 
                (u.city.kingdom == null || city.kingdom == null || u.city.kingdom == city.kingdom) &&
                u.army == null &&  // 不属于其他军队
                !u.isKing() && !u.isCityLeader()  // 不是重要人物
            ).ToList();
            
            if (suitableUnits.Count > 0)
            {
                // 优先选择战勋等级最高的单位
                var bestUnit = suitableUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                
                // 创建新军队
                var newArmy = World.world.armies.newArmy(bestUnit, city);
                if (newArmy != null)
                {
                    newArmy.setCaptain(bestUnit);
                }
            }
        }
        
        private static void FixArmyCaptain(Army army, City city)
        {
            // 首先尝试从军队现有单位中选择
            if (army.units.Count > 0)
            {
                army.findCaptain();
                return;
            }
            
            // 如果军队没有单位，从城市中找战士加入军队
            var cityWarriors = city.units.Where(u => 
                u != null && u.isAlive() && u.isWarrior() && 
                u.city == city && 
                (u.city.kingdom == null || city.kingdom == null || u.city.kingdom == city.kingdom) &&
                u.army == null  // 不属于其他军队
            ).ToList();
            
            if (cityWarriors.Count > 0)
            {
                // 优先选择战勋等级最高的战士
                var bestWarrior = cityWarriors.OrderByDescending(w => GetZhanXunLevel(w)).First();
                bestWarrior.setArmy(army);
                army.setCaptain(bestWarrior);
                return;
            }
            
            // 如果没有战士，尝试从城市中找任何合适的单位
            var cityUnits = city.units.Where(u => 
                u != null && u.isAlive() && 
                u.city == city && 
                (u.city.kingdom == null || city.kingdom == null || u.city.kingdom == city.kingdom) &&
                u.army == null &&  // 不属于其他军队
                !u.isKing() && !u.isCityLeader()  // 不是重要人物
            ).ToList();
            
            if (cityUnits.Count > 0)
            {
                // 优先选择战勋等级最高的单位
                var bestUnit = cityUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                bestUnit.setArmy(army);
                army.setCaptain(bestUnit);
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "newCityEvent")]
        public static void City_newCityEvent_Postfix(City __instance, Actor pActor)
        {
            // 确保新城市有军队
            if (!__instance.hasArmy())
            {
                // 从城市中找一个合适的单位创建军队
                var suitableUnits = __instance.units.Where(u => 
                    u != null && u.isAlive() && 
                    u.city == __instance && 
                    (u.city.kingdom == null || __instance.kingdom == null || u.city.kingdom == __instance.kingdom) &&
                    u.army == null &&  // 不属于其他军队
                    !u.isKing() && !u.isCityLeader()  // 不是重要人物
                ).ToList();
                
                if (suitableUnits.Count > 0)
                {
                    // 优先选择战勋等级最高的单位
                    var bestUnit = suitableUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                    
                    // 创建新军队
                    var newArmy = World.world.armies.newArmy(bestUnit, __instance);
                    if (newArmy != null)
                    {
                        newArmy.setCaptain(bestUnit);
                    }
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "loadCity")]
        public static void City_loadCity_Postfix(City __instance, CityData pData)
        {
            // 确保加载的城市有军队
            if (!__instance.hasArmy())
            {
                // 延迟检查，确保城市完全加载
                World.world.StartCoroutine(EnsureCityHasArmy(__instance));
            }
        }
        
        private static System.Collections.IEnumerator EnsureCityHasArmy(City city)
        {
            // 等待几帧，确保城市完全加载
            for (int i = 0; i < 5; i++)
            {
                yield return null;
            }
            
            if (city == null || city.hasArmy()) yield break;
            
            // 从城市中找一个合适的单位创建军队
            var suitableUnits = city.units.Where(u => 
                u != null && u.isAlive() && 
                u.city == city && 
                (u.city.kingdom == null || city.kingdom == null || u.city.kingdom == city.kingdom) &&
                u.army == null &&  // 不属于其他军队
                !u.isKing() && !u.isCityLeader()  // 不是重要人物
            ).ToList();
            
            if (suitableUnits.Count > 0)
            {
                // 优先选择战勋等级最高的单位
                var bestUnit = suitableUnits.OrderByDescending(u => GetZhanXunLevel(u)).First();
                
                // 创建新军队
                var newArmy = World.world.armies.newArmy(bestUnit, city);
                if (newArmy != null)
                {
                    newArmy.setCaptain(bestUnit);
                }
            }
        }

        private static float lastForceCheckTime = 0f;
        private static readonly float FORCE_CHECK_INTERVAL = 10f; // 每10秒强制检查一次
        
        private static void ForceCheckAllCities()
        {
            int citiesWithoutArmy = 0;
            int armiesWithoutCaptain = 0;
            
            foreach (var city in World.world.cities)
            {
                if (city == null) continue;
                
                // 检查城市是否有军队
                if (!city.hasArmy())
                {
                    citiesWithoutArmy++;
                    CreateArmyForCity(city);
                    continue;
                }
                
                // 检查军队是否有队长
                if (city.army != null && !city.army.hasCaptain())
                {
                    armiesWithoutCaptain++;
                    FixArmyCaptain(city.army, city);
                }
            }
            
            // 如果发现问题，输出调试信息
            if (citiesWithoutArmy > 0 || armiesWithoutCaptain > 0)
            {
                UnityEngine.Debug.Log($"[ZhanXun] Force check: {citiesWithoutArmy} cities without army, {armiesWithoutCaptain} armies without captain");
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "update")]
        public static void City_update_ArmyFix_Postfix(City __instance, float pElapsed)
        {
            // 确保城市有军队和队长
            if (!__instance.hasArmy())
            {
                CreateArmyForCity(__instance);
            }
            else if (__instance.army != null && !__instance.army.hasCaptain())
            {
                FixArmyCaptain(__instance.army, __instance);
            }
        }
        
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "die")]
        public static void Actor_die_ArmyFix_Postfix(Actor __instance)
        {
            // 当单位死亡时，检查其所属城市的军队是否需要修复
            if (__instance.city != null && __instance.city.hasArmy())
            {
                var army = __instance.city.army;
                if (army != null && !army.hasCaptain())
                {
                    FixArmyCaptain(army, __instance.city);
                }
            }
        }
        
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "removeFromArmy")]
        public static void Actor_removeFromArmy_ArmyFix_Postfix(Actor __instance)
        {
            // 当单位从军队中移除时，检查军队是否需要修复
            if (__instance.city != null && __instance.city.hasArmy())
            {
                var army = __instance.city.army;
                if (army != null && !army.hasCaptain())
                {
                    FixArmyCaptain(army, __instance.city);
                }
            }
        }
    }
}