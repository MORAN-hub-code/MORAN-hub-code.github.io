﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitAction
    {
        // 定义晋升途径字典
        private static readonly Dictionary<string, Dictionary<string, string>> _warriorPathways = new Dictionary<string, Dictionary<string, string>>
        {
            // 占卜家途径
            {"占卜家", new Dictionary<string, string>
            {
                {"Warrior2", "占卜家"},
                {"Warrior3", "小丑"},
                {"Warrior4", "魔术师"},
                {"Warrior5", "无面人"},
                {"Warrior6", "秘偶大师"},
                {"Warrior7", "诡法师"},
                {"Warrior8", "古代学者"},
                {"Warrior9", "奇迹师"},
                {"Warrior91", "诡秘侍者"},
                {"Warrior92", "愚者"},
                {"Warrior93", "诡秘之主"}
            }},
            // 偷盗者途径
            {"偷盗者", new Dictionary<string, string>
            {
                {"Warrior2", "偷盗者"},
                {"Warrior3", "诈骗师"},
                {"Warrior4", "解密学者"},
                {"Warrior5", "盗火人"},
                {"Warrior6", "窃梦家"},
                {"Warrior7", "寄生者"},
                {"Warrior8", "欺瞒导师"},
                {"Warrior9", "命运木马"},
                {"Warrior91", "时之虫"},
                {"Warrior92", "错误"},
                {"Warrior93", "诡秘之主"}
            }},
            // 学徒途径
            {"学徒", new Dictionary<string, string>
            {
                {"Warrior2", "学徒"},
                {"Warrior3", "戏法大师"},
                {"Warrior4", "占星人"},
                {"Warrior5", "记录官"},
                {"Warrior6", "旅行家"},
                {"Warrior7", "秘法师"},
                {"Warrior8", "漫游者"},
                {"Warrior9", "旅法师"},
                {"Warrior91", "星之钥"},
                {"Warrior92", "门"},
                {"Warrior93", "诡秘之主"}
            }},
            // 观众途径
            {"观众", new Dictionary<string, string>
            {
                {"Warrior2", "观众"},
                {"Warrior3", "读心者"},
                {"Warrior4", "心理医生"},
                {"Warrior5", "催眠师"},
                {"Warrior6", "梦境行者"},
                {"Warrior7", "操纵师"},
                {"Warrior8", "织梦人"},
                {"Warrior9", "洞察者"},
                {"Warrior91", "作家"},
                {"Warrior92", "空想家"},
                {"Warrior93", "全知全能者"}
            }},
            // 歌颂者途径
            {"歌颂者", new Dictionary<string, string>
            {
                {"Warrior2", "歌颂者"},
                {"Warrior3", "祈光人"},
                {"Warrior4", "太阳神官"},
                {"Warrior5", "公证人"},
                {"Warrior6", "光之祭司"},
                {"Warrior7", "无暗者"},
                {"Warrior8", "正义导师"},
                {"Warrior9", "逐光者"},
                {"Warrior91", "纯白天使"},
                {"Warrior92", "太阳"},
                {"Warrior93", "全知全能者"}
            }},
            // 水手途径
            {"水手", new Dictionary<string, string>
            {
                {"Warrior2", "水手"},
                {"Warrior3", "暴怒之民"},
                {"Warrior4", "航海家"},
                {"Warrior5", "风眷者"},
                {"Warrior6", "海洋歌者"},
                {"Warrior7", "灾难主祭"},
                {"Warrior8", "海王"},
                {"Warrior9", "天灾"},
                {"Warrior91", "雷神"},
                {"Warrior92", "暴君"},
                {"Warrior93", "全知全能者"}
            }},
            // 阅读者途径
            {"阅读者", new Dictionary<string, string>
            {
                {"Warrior2", "阅读者"},
                {"Warrior3", "推理学员"},
                {"Warrior4", "侦探"},
                {"Warrior5", "博学者"},
                {"Warrior6", "秘术导师"},
                {"Warrior7", "预言家"},
                {"Warrior8", "洞悉者"},
                {"Warrior9", "智天使"},
                {"Warrior91", "全知之眼"},
                {"Warrior92", "白塔"},
                {"Warrior93", "全知全能者"}
            }},
            // 秘祈人途径
            {"秘祈人", new Dictionary<string, string>
            {
                {"Warrior2", "秘祈人"},
                {"Warrior3", "倾听者"},
                {"Warrior4", "隐修士"},
                {"Warrior5", "蔷薇主教"},
                {"Warrior6", "牧羊人"},
                {"Warrior7", "黑骑士"},
                {"Warrior8", "三首圣堂"},
                {"Warrior9", "秽语长老"},
                {"Warrior91", "暗天使"},
                {"Warrior92", "倒吊人"},
                {"Warrior93", "全知全能者"}
            }},
            // 收尸人途径
            {"收尸人", new Dictionary<string, string>
            {
                {"Warrior2", "收尸人"},
                {"Warrior3", "掘墓人"},
                {"Warrior4", "通灵者"},
                {"Warrior5", "死灵导师"},
                {"Warrior6", "看门人"},
                {"Warrior7", "不死者"},
                {"Warrior8", "摆渡人"},
                {"Warrior9", "死亡执政官"},
                {"Warrior91", "苍白皇帝"},
                {"Warrior92", "死神"},
                {"Warrior93", "时空归一者"}
            }},
            // 不眠者途径
            {"不眠者", new Dictionary<string, string>
            {
                {"Warrior2", "不眠者"},
                {"Warrior3", "午夜诗人"},
                {"Warrior4", "梦魇"},
                {"Warrior5", "安魂师"},
                {"Warrior6", "灵巫"},
                {"Warrior7", "守夜人"},
                {"Warrior8", "恐惧主教"},
                {"Warrior9", "隐秘之仆"},
                {"Warrior91", "厄难天使"},
                {"Warrior92", "黑暗"},
                {"Warrior93", "时空归一者"}
            }},
            // 战士途径
            {"战士", new Dictionary<string, string>
            {
                {"Warrior2", "战士"},
                {"Warrior3", "格斗家"},
                {"Warrior4", "武器大师"},
                {"Warrior5", "黎明骑士"},
                {"Warrior6", "守护者"},
                {"Warrior7", "猎魔者"},
                {"Warrior8", "银骑士"},
                {"Warrior9", "荣耀者"},
                {"Warrior91", "神明之手"},
                {"Warrior92", "黄昏巨人"},
                {"Warrior93", "时空归一者"}
            }},
            // 刺客途径
            {"刺客", new Dictionary<string, string>
            {
                {"Warrior2", "刺客"},
                {"Warrior3", "教唆者"},
                {"Warrior4", "女巫"},
                {"Warrior5", "欢愉魔女"},
                {"Warrior6", "痛苦魔女"},
                {"Warrior7", "绝望魔女"},
                {"Warrior8", "不老魔女"},
                {"Warrior9", "灾难魔女"},
                {"Warrior91", "末日魔女"},
                {"Warrior92", "原初魔女"},
                {"Warrior93", "毁灭天灾"}
            }},
            // 猎人途径
            {"猎人", new Dictionary<string, string>
            {
                {"Warrior2", "猎人"},
                {"Warrior3", "挑衅者"},
                {"Warrior4", "纵火家"},
                {"Warrior5", "阴谋家"},
                {"Warrior6", "收割者"},
                {"Warrior7", "铁血骑士"},
                {"Warrior8", "战争主教"},
                {"Warrior9", "天气术士"},
                {"Warrior91", "征服者"},
                {"Warrior92", "红祭司"},
                {"Warrior93", "毁灭天灾"}
            }},
            // 窥秘人途径
            {"窥秘人", new Dictionary<string, string>
            {
                {"Warrior2", "窥秘人"},
                {"Warrior3", "格斗学者"},
                {"Warrior4", "巫师"},
                {"Warrior5", "卷轴教授"},
                {"Warrior6", "星象师"},
                {"Warrior7", "神秘学家"},
                {"Warrior8", "预言大师"},
                {"Warrior9", "贤者"},
                {"Warrior91", "知识皇帝"},
                {"Warrior92", "隐者"},
                {"Warrior93", "知识之妖"}
            }},
            // 通识者途径
            {"通识者", new Dictionary<string, string>
            {
                {"Warrior2", "通识者"},
                {"Warrior3", "考古学家"},
                {"Warrior4", "鉴定师"},
                {"Warrior5", "机械专家"},
                {"Warrior6", "天文学家"},
                {"Warrior7", "炼金术士"},
                {"Warrior8", "奥秘学者"},
                {"Warrior9", "知识导师"},
                {"Warrior91", "启蒙者"},
                {"Warrior92", "完美者"},
                {"Warrior93", "知识之妖"}
            }},
            // 怪物途径
            {"怪物", new Dictionary<string, string>
            {
                {"Warrior2", "怪物"},
                {"Warrior3", "机器"},
                {"Warrior4", "幸运儿"},
                {"Warrior5", "灾祸教士"},
                {"Warrior6", "赢家"},
                {"Warrior7", "厄运法师"},
                {"Warrior8", "混乱行者"},
                {"Warrior9", "先知"},
                {"Warrior91", "水银之蛇"},
                {"Warrior92", "命运之轮"},
                {"Warrior93", "光之钥"}
            }},
            // 耕种者途径
            {"耕种者", new Dictionary<string, string>
            {
                {"Warrior2", "耕种者"},
                {"Warrior3", "医师"},
                {"Warrior4", "丰收祭司"},
                {"Warrior5", "生物学家"},
                {"Warrior6", "德鲁伊"},
                {"Warrior7", "古代炼金士"},
                {"Warrior8", "抬棺人"},
                {"Warrior9", "荒芜主母"},
                {"Warrior91", "自然行者"},
                {"Warrior92", "母亲"},
                {"Warrior93", "万物之母"}
            }},
            // 药师途径
            {"药师", new Dictionary<string, string>
            {
                {"Warrior2", "药师"},
                {"Warrior3", "驯兽师"},
                {"Warrior4", "吸血鬼"},
                {"Warrior5", "魔药教授"},
                {"Warrior6", "深红学者"},
                {"Warrior7", "巫王"},
                {"Warrior8", "召唤大师"},
                {"Warrior9", "创生者"},
                {"Warrior91", "美神"},
                {"Warrior92", "月亮"},
                {"Warrior93", "万物之母"}
            }},
            // 罪犯途径
            {"罪犯", new Dictionary<string, string>
            {
                {"Warrior2", "罪犯"},
                {"Warrior3", "冷血者"},
                {"Warrior4", "连环杀手"},
                {"Warrior5", "恶魔"},
                {"Warrior6", "欲望使徒"},
                {"Warrior7", "魔鬼"},
                {"Warrior8", "呓语者"},
                {"Warrior9", "鲜血大公"},
                {"Warrior91", "污秽君王"},
                {"Warrior92", "深渊"},
                {"Warrior93", "诅咒之源"}
            }},
            // 仲裁人途径
            {"仲裁人", new Dictionary<string, string>
            {
                {"Warrior2", "仲裁人"},
                {"Warrior3", "治安官"},
                {"Warrior4", "审讯者"},
                {"Warrior5", "法官"},
                {"Warrior6", "惩戒骑士"},
                {"Warrior7", "律令法师"},
                {"Warrior8", "混乱猎手"},
                {"Warrior9", "平衡者"},
                {"Warrior91", "秩序之手"},
                {"Warrior92", "审判者"},
                {"Warrior93", "混沌之子"}
            }},
            // 律师途径
            {"律师", new Dictionary<string, string>
            {
                {"Warrior2", "律师"},
                {"Warrior3", "野蛮人"},
                {"Warrior4", "贿赂者"},
                {"Warrior5", "腐化男爵"},
                {"Warrior6", "混乱导师"},
                {"Warrior7", "堕落伯爵"},
                {"Warrior8", "狂乱法师"},
                {"Warrior9", "熵之公爵"},
                {"Warrior91", "弑序亲王"},
                {"Warrior92", "黑皇帝"},
                {"Warrior93", "混沌之子"}
            }},
            // 掮客途径
            {"掮客", new Dictionary<string, string>
            {
                {"Warrior2", "掮客"},
                {"Warrior3", "阴影商人"},
                {"Warrior4", "公诉人"},
                {"Warrior5", "野心家"},
                {"Warrior6", "暗箱"},
                {"Warrior7", "监督者"},
                {"Warrior8", "漩涡编织者"},
                {"Warrior9", "亵渎者"},
                {"Warrior91", "真理"},
                {"Warrior92", "混沌迷雾"},
                {"Warrior93", "混沌之子"}
            }},
            // 囚犯途径
            {"囚犯", new Dictionary<string, string>
            {
                {"Warrior2", "囚犯"},
                {"Warrior3", "疯子"},
                {"Warrior4", "狼人"},
                {"Warrior5", "活尸"},
                {"Warrior6", "怨魂"},
                {"Warrior7", "木偶"},
                {"Warrior8", "沉默门徒"},
                {"Warrior9", "古代邪物"},
                {"Warrior91", "神孽"},
                {"Warrior92", "被缚者"},
                {"Warrior93", "诅咒之源"}
            }},
            // 恶棍途径
            {"恶棍", new Dictionary<string, string>
            {
                {"Warrior2", "恶棍"},
                {"Warrior3", "园丁"},
                {"Warrior4", "邪术师"},
                {"Warrior5", "播种者"},
                {"Warrior6", "女妖"},
                {"Warrior7", "夫人"},
                {"Warrior8", "孕神者"},
                {"Warrior9", "至高者"},
                {"Warrior91", "树神"},
                {"Warrior92", "混沌源胎"},
                {"Warrior93", "万物之母"}
            }},
            // 吝啬鬼途径
            {"吝啬鬼", new Dictionary<string, string>
            {
                {"Warrior2", "吝啬鬼"},
                {"Warrior3", "性瘾病人"},
                {"Warrior4", "演员"},
                {"Warrior5", "受勋者"},
                {"Warrior6", "堕落树精"},
                {"Warrior7", "祈树人"},
                {"Warrior8", "欲望祭司"},
                {"Warrior9", "爱神"},
                {"Warrior91", "利维坦"},
                {"Warrior92", "主父"},
                {"Warrior93", "诅咒之源"}
            }},
            // 舞蹈家途径
            {"舞蹈家", new Dictionary<string, string>
            {
                {"Warrior2", "舞蹈家"},
                {"Warrior3", "托钵僧侣"},
                {"Warrior4", "受契之人"},
                {"Warrior5", "苦修士"},
                {"Warrior6", "猎命师"},
                {"Warrior7", "环中人"},
                {"Warrior8", "受难者"},
                {"Warrior9", "罪人"},
                {"Warrior91", "救赎天使"},
                {"Warrior92", "永劫者"},
                {"Warrior93", "宿命之环"}
            }},
            // 失梦人途径
            {"失梦人", new Dictionary<string, string>
            {
                {"Warrior2", "失梦人"},
                {"Warrior3", "乐师"},
                {"Warrior4", "窥命师"},
                {"Warrior5", "哑巴"},
                {"Warrior6", "逝者"},
                {"Warrior7", "改命人"},
                {"Warrior8", "命运侍者"},
                {"Warrior9", "织网者"},
                {"Warrior91", "命运之刃"},
                {"Warrior92", "永生律"},
                {"Warrior93", "命运女神"}
            }},
            // 流浪汉途径
            {"流浪汉", new Dictionary<string, string>
            {
                {"Warrior2", "流浪汉"},
                {"Warrior3", "贪吃者"},
                {"Warrior4", "美食家"},
                {"Warrior5", "厨师"},
                {"Warrior6", "剥夺者"},
                {"Warrior7", "海怪"},
                {"Warrior8", "九头蛇"},
                {"Warrior9", "噬之天使"},
                {"Warrior91", "混沌胃液"},
                {"Warrior92", "吞尾者"},
                {"Warrior93", "原初饥饿"}
            }},
            // 天文爱好者途径
            {"天文爱好者", new Dictionary<string, string>
            {
                {"Warrior2", "天文爱好者"},
                {"Warrior3", "拜星人"},
                {"Warrior4", "祭星师"},
                {"Warrior5", "领航员"},
                {"Warrior6", "潮汐学者"},
                {"Warrior7", "沉重者"},
                {"Warrior8", "牧星人"},
                {"Warrior9", "璀璨天使"},
                {"Warrior91", "星之巨龙"},
                {"Warrior92", "致密者"},
                {"Warrior93", "超星主宰"}
            }},
            // 病患途径
            {"病患", new Dictionary<string, string>
            {
                {"Warrior2", "病患"},
                {"Warrior3", "秘书"},
                {"Warrior4", "蛀虫"},
                {"Warrior5", "疾病使者"},
                {"Warrior6", "腐烂之子"},
                {"Warrior7", "必死之人"},
                {"Warrior8", "衰败左手"},
                {"Warrior9", "时光巨人"},
                {"Warrior91", "衰老之神"},
                {"Warrior92", "第二定律"},
                {"Warrior93", "衰败君王"}
            }},
            // 萨满途径
            {"萨满", new Dictionary<string, string>
            {
                {"Warrior2", "萨满"},
                {"Warrior3", "记者"},
                {"Warrior4", "画家"},
                {"Warrior5", "文学爱好者"},
                {"Warrior6", "妖精"},
                {"Warrior7", "旅客"},
                {"Warrior8", "弦之弹奏者"},
                {"Warrior9", "维度之影子"},
                {"Warrior91", "观察者"},
                {"Warrior92", "尘世之眼"},
                {"Warrior93", "高维俯视者"}
            }},
            // 入门者途径
            {"入门者", new Dictionary<string, string>
            {
                {"Warrior2", "入门者"},
                {"Warrior3", "评论人"},
                {"Warrior4", "演讲者"},
                {"Warrior5", "歌唱家"},
                {"Warrior6", "传密人"},
                {"Warrior7", "哲学家"},
                {"Warrior8", "神之信使"},
                {"Warrior9", "旧日侍者"},
                {"Warrior91", "心之声"},
                {"Warrior92", "不朽者"},
                {"Warrior93", "不熄的呓语"}
            }}
        };

        // 记录角色选择的途径
        private static readonly Dictionary<Actor, string> _actorPathways = new Dictionary<Actor, string>();

        public static bool IsWarrior1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"Warrior{i}") || a.hasTrait($"Warrior{i}+"))
                {
                    return true;
                }
            }
            return false;
        }

        private static readonly Dictionary<string, string> _warriorSuffixMap = new Dictionary<string, string>
        {
            {"Warrior1", "超凡者"},
            {"Warrior2", "序列九"},
            {"Warrior3", "序列八"},
            {"Warrior4", "序列七"},
            {"Warrior5", "序列六"},
            {"Warrior6", "序列五"},
            {"Warrior7", "序列四_半神"},
            {"Warrior8", "序列三_半神"},
            {"Warrior9", "序列二_天使"},
            {"Warrior91", "序列一_天使"},
            {"Warrior92", "真神"},
            {"Warrior93", "旧日"}
        };

        // 尊号字典（洞虚境、合道境、武极境）
        private static readonly Dictionary<string, string[]> _warriorTitlesMap = new Dictionary<string, string[]>
        {
            {"Warrior2", new string[] {
                "占卜家","学徒","偷盗者","观众","水手","歌颂者","阅读者","秘祈人","收尸人","不眠者","战士","刺客","猎人","窥秘人","通识者","怪物","耕种者","药师","恶棍","仲裁人","律师","掮客","囚犯","罪犯","吝啬鬼","舞蹈家","失梦人","流浪汉","天文爱好者","病患","萨满","入门者"
            }},
            // 其他境界尊号保持不变
            {"Warrior3", new string[] {
                "小丑","戏法大师","诈骗师","读心者","暴怒之民","祈光人","推理学员","倾听者","掘墓人","午夜诗人","格斗家","教唆者","挑衅者","格斗学者","考古学家","机器","医师","驯兽师","园丁","治安官","野蛮人","阴影商人","疯子","冷血者","性瘾病人","托钵僧侣","乐师","贪吃者","拜星人","秘书","记者","评论人"
            }},
            {"Warrior4", new string[] {
                "魔术师","解密学者","占星人","心理医生","太阳神官","航海家","侦探","隐修士","梦魇","通灵者","武器大师","女巫","纵火家","巫师","幸运儿","丰收祭司","吸血鬼","连环杀手","狼人","贿赂者","审讯者","鉴定师","邪术师","公诉人","演员","受契之人","窥命师","美食家","祭星师","蛀虫","画家","演讲者"
            }},
            {"Warrior5", new string[] {
                "无面人","盗火人","记录官","催眠师","公证人","风眷者","博学者","蔷薇主教","安魂师","死灵导师","黎明骑士","欢愉魔女","阴谋家","卷轴教授","机械专家","灾祸教士","生物学家","魔药教授","恶魔","活尸","腐化男爵","法官","播种者","野心家","受勋者","苦修士","哑巴","厨师","领航员","疾病使者","文学爱好者","歌唱家"
            }},
            {"Warrior6", new string[] {
                "秘偶大师","窃梦家","旅行家","梦境行者","光之祭司","秘术导师","海洋歌者","牧羊人","灵巫","看门人","守护者","痛苦魔女","收割者","星象师","天文学家","赢家","德鲁伊","深红学者","欲望使徒","怨魂","混乱导师","惩戒骑士","女妖","暗箱","堕落树精","猎命师","逝者","剥夺者","潮汐学者","腐烂之子","妖精","传密人"
            }},
            {"Warrior7", new string[] {
                "诡法师","寄生者","秘法师","操纵师","无暗者","灾难主祭","预言家","黑骑士","守夜人","不死者","猎魔者","绝望魔女","铁血骑士","神秘学家","炼金术士","厄运法师","古代炼金士","巫王","魔鬼","木偶","堕落伯爵","律令法师","夫人","监督者","祈树人","环中人","改命人","海怪","沉重者","必死之人","旅客","哲学家"
            }},
            {"Warrior8", new string[] {
                "古代学者","欺瞒导师","漫游者","织梦人","正义导师","海王","洞悉者","三首圣堂","恐惧主教","摆渡人","银骑士","不老魔女","战争主教","预言大师","奥秘学者","混乱行者","抬棺人","召唤大师","呓语者","沉默门徒","狂乱法师","混乱猎手","孕神者","漩涡编织者","欲望祭司","受难者","命运侍者","九头蛇","牧星人","衰败左手","弦之弹奏者","神之信使"
            }},
            {"Warrior9", new string[] {
                "奇迹师","命运木马","旅法师","洞察者","逐光者","天灾","智天使","秽语长老","隐秘之仆","死亡执政官","荣耀者","灾难魔女","天气术士","贤者","知识导师","先知","荒芜主母","创生者","鲜血大公","古代邪物","熵之公爵","平衡者","至高者","亵渎者","爱神","罪人","织网者","噬之天使","璀璨天使","时光巨人","维度之影子","旧日侍者"
            }},
            {"Warrior91", new string[] {
                "诡秘侍者","星之钥","时之虫","作家","雷神","纯白天使","全知之眼","暗天使","苍白皇帝","厄难天使","神明之手","末日魔女","征服者","知识皇帝","启蒙者","水银之蛇","自然行者","美神","秩序之手","弑序亲王","神孽","污秽君王","谷神","真理","利维坦","救赎天使","命运之刃","混沌胃液","星之巨龙","衰老之神","观察者","心之声"
            }},
            // 合道境尊号
            {"Warrior92", new string[] {
                "愚者","门","错误","空想家","暴君","太阳","白塔","倒吊人","死神","黑暗","黄昏巨人","原初魔女","红祭司","隐者","完美者","命运之轮","母亲","月亮","混沌原胎","审判者","黑皇帝","混沌迷雾","被缚者","深渊","主父","永劫者","永生律","吞尾者","致密者","第二定律","尘世之眼","不朽者"
            }},
            // 武极境尊号
            {"Warrior93", new string[] {
                "诡秘之主","全知全能者","时空归一者" ,"毁灭天灾","知识之妖","光之钥","万物之母","混沌之子","诅咒之源","宿命之环","命运女神","原初饥饿","超星主宰","衰败君王","高维俯视者","不熄的呓语"
            }}
        };

        private static void ApplyWarriorTitle(Actor actor, string newTrait)
        {
            if (newTrait == "Warrior2")
            {
                // 晋升Warrior1时，随机选择一个前缀
                string[] titles = _warriorTitlesMap["Warrior2"];
                string title = titles[UnityEngine.Random.Range(0, titles.Length)];
                _actorPathways[actor] = title; // 记录角色选择的途径

                string currentName = actor.getName();
                int dotIndex = currentName.IndexOf('·');
                string baseName = dotIndex > 0 
                    ? currentName.Substring(dotIndex + 1).Trim()
                    : currentName;

                actor.data.setName($"{title}·{baseName}");
            }
            else if (_actorPathways.ContainsKey(actor))
            {
                // 后续晋升时，根据记录的途径选择对应的前缀
                string pathway = _actorPathways[actor];
                if (_warriorPathways[pathway].TryGetValue(newTrait, out string title))
                {
                    string currentName = actor.getName();
                    int dotIndex = currentName.IndexOf('·');
                    string baseName = dotIndex > 0 
                        ? currentName.Substring(dotIndex + 1).Trim()
                        : currentName;

                    actor.data.setName($"{title}·{baseName}");
                }
            }
        }

private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_warriorSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        int dashIndex = currentName.IndexOf('-');
        
        // 如果名称中已包含后缀，移除旧后缀
        string baseName = dashIndex > 0 
            ? currentName.Substring(0, dashIndex).Trim()
            : currentName;
        
        // 设置新名称：基础名 + 后缀
        actor.data.setName($"{baseName}-{suffix}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 1200 点真伤，可根据需要调整该值
                int trueDamage = 1200;
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 3000 点真伤，可根据需要调整该值
                int trueDamage = 3000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 6000 点真伤，可根据需要调整该值
                int trueDamage = 6000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 12000 点真伤，可根据需要调整该值
                int trueDamage = 12000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 24000 点真伤，可根据需要调整该值
                int trueDamage = 24000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 48000 点真伤，可根据需要调整该值
                int trueDamage = 48000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 100000 点真伤，可根据需要调整该值
                int trueDamage = 100000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool lei3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                MapBox.spawnLightningBig(pTile, 0.05f);
            }

            return false;
        }

        public static bool Warrior1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Warrior2", "Warrior3", "Warrior4", "Warrior5", "Warrior6", "Warrior7", "Warrior8", "Warrior9", "Warrior91", "Warrior92", "Warrior93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Warrior1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "Warrior1");

            return true;
        }

        public static bool Warrior2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetWarrior() <= 9.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.8;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior1",
                "Warrior2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Warrior22" }
            );
            UpdateNameSuffix(a, "Warrior2");
            ApplyWarriorTitle(a, "Warrior2");

            return true;
        }

        public static bool Warrior3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 8)
            {
                // 添加Warrior1特质
                upTrait("特质", "Warrior1", a, new string[] { "Warrior2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 19.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Warrior2",
                "Warrior3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior22"
                },
                new string[] { "Warrior3+", selectedTrait }
            );
            UpdateNameSuffix(a, "Warrior3");
            ApplyWarriorTitle(a, "Warrior3");

            // 随机选择一个低级功法特质添加给人物
            string[] LowGongFa = { "LowGongFaTrait1", "LowGongFaTrait2", "LowGongFaTrait9", "LowGongFaTrait3", "LowGongFaTrait4", "LowGongFaTrait5", "LowGongFaTrait6", "LowGongFaTrait7", "LowGongFaTrait8" }; // 根据实际情况添加更多特质
            int randomIndex1 = UnityEngine.Random.Range(0, LowGongFa.Length);
            string selectedLowGongFa = LowGongFa[randomIndex];
            a.addTrait(selectedLowGongFa);

            return true;
        }

        public static bool Warrior4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 18)
            {
                upTrait("特质", "Warrior2", a, new string[] { "Warrior3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 39.99)
            {
                return false;
            }

            a.ChangeWarrior(-3);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior3",
                "Warrior4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior3+"
                },
                new string[] { "Warrior4+" }
            );
            UpdateNameSuffix(a, "Warrior4");
            ApplyWarriorTitle(a, "Warrior4");

            return true;
        }

        public static bool Warrior5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 37)
            {
                upTrait("特质", "Warrior3", a, new string[] { "Warrior4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 79.99)
            {
                return false;
            }

            a.ChangeWarrior(-4);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior4",
                "Warrior5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior4+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior5+", selectedTrait } :
                new string[] { "Warrior5+" }
            );
            UpdateNameSuffix(a, "Warrior5");
            ApplyWarriorTitle(a, "Warrior5");

            return true;
        }

        public static bool Warrior6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 76)
            {
                upTrait("特质", "Warrior4", a, new string[] { "Warrior5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 99.99)
            {
                return false;
            }

            a.ChangeWarrior(-5);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior5",
                "Warrior6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior5+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior6+", "freeze_proof", "fire_proof", "martialBloodline1", selectedTrait } :
                new string[] { "Warrior6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "Warrior6");
            ApplyWarriorTitle(a, "Warrior6");

            return true;
        }

        public static bool Warrior7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 95)
            {
                upTrait("特质", "Warrior6", a, new string[] { "Warrior7" }, new string[] { });
                return true;
            }

            if (a.GetWarrior() <= 299.99)
            {
                return false;
            }

            a.ChangeWarrior(-6);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior6",
                "Warrior7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior6+", "martialBloodline1" },
                new string[] { "Warrior7+", "martialBloodline2" }
            );
            UpdateNameSuffix(a, "Warrior7");
            ApplyWarriorTitle(a, "Warrior7");

            string[] GongFa = { "GongFaTrait1", "GongFaTrait2", "GongFaTrait3", "GongFaTrait4", "GongFaTrait5", "GongFaTrait6", "GongFaTrait7", "GongFaTrait8", "GongFaTrait9", "GongFaTrait10", "GongFaTrait11", "GongFaTrait12", "GongFaTrait13" };
            int randomIndex2 = UnityEngine.Random.Range(0, GongFa.Length);
            string selectedGongFa = GongFa[randomIndex2];
            a.addTrait(selectedGongFa);

            return true;
        }

        public static bool Warrior8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 499.99)
            {
                return false;
            }

            a.ChangeWarrior(-9);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.9;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior7",
                "Warrior8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior7+", "martialBloodline2" },
                new string[] { "Warrior8+", "strong_minded", "immune", "martialBloodline3" }
            );
            UpdateNameSuffix(a, "Warrior8");
            ApplyWarriorTitle(a, "Warrior8");

            return true;
        }

        public static bool Warrior9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 799.99)
            {
                return false;
            }

            a.ChangeWarrior(-15);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04; 
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.9;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior8",
                "Warrior9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior8+", "martialBloodline3" },
                new string[] { "Warrior9+" ,"fire_proof", "regeneration", "martialBloodline4"}
            );
            UpdateNameSuffix(a, "Warrior9");
            ApplyWarriorTitle(a, "Warrior9");

            // 确保获得防火特质
            a.addTrait("fire_proof");

            return true;
        }

        public static bool Warrior91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 999.99)
            {
                return false;
            }

            a.ChangeWarrior(-20);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.04;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.9;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior9",
                "Warrior91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior9+", "martialBloodline4" },
                new string[] { "Warrior91+", "martialBloodline5" }
            );
            UpdateNameSuffix(a, "Warrior91");
            ApplyWarriorTitle(a, "Warrior91");

            string[] arcaneTomes = { "arcaneTome1", "arcaneTome2", "arcaneTome3", "arcaneTome4", "arcaneTome5", "arcaneTome6", "arcaneTome7", "arcaneTome8", "arcaneTome9", "arcaneTome10", "arcaneTome11", "arcaneTome12", "arcaneTome13" }; // 可以添加更多传承法特质名
            int randomIndex3 = UnityEngine.Random.Range(0, arcaneTomes.Length);
            string selectedarcaneTome = arcaneTomes[randomIndex3];
            a.addTrait(selectedarcaneTome);

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior9", "Warrior91");
            a.data.favorite = true;

            return true;
        }

        public static bool Warrior92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 2999.99)
            {
                return false;
            }

            a.ChangeWarrior(-30);
            double successRate = 0.06;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.03;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.5;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior91",
                "Warrior92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior91+", "martialBloodline5" },
                new string[] { "Warrior92+", "martialBloodline6" }
            );
            UpdateNameSuffix(a, "Warrior92");
            ApplyWarriorTitle(a, "Warrior92");

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Warrior91", "Warrior92");

            return true;
        }

        public static bool Warrior93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetWarrior() <= 8999.99)
            {
                return false;
            }

            a.ChangeWarrior(-60);
            double successRate = 0.02;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.1;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior92",
                "Warrior93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior92+", "martialBloodline6" },
                new string[] { "Warrior93+", "immunity", "martialBloodline7" }
            );
            UpdateNameSuffix(a, "Warrior93");
            ApplyWarriorTitle(a, "Warrior93");

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior92", "Warrior93");

            // 随机获得一到三个九字秘特质
            string[] nineCharacterSecrets = { "NineCharacterSecret1", "NineCharacterSecret2", /* 其他九字秘特质名 */ };
            int traitCount = UnityEngine.Random.Range(1, 4);
            List<string> selectedTraits = new List<string>();

            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, nineCharacterSecrets.Length);
                string selectedTrait = nineCharacterSecrets[randomIndex];
                if (!selectedTraits.Contains(selectedTrait))
                {
                    selectedTraits.Add(selectedTrait);
                    a.addTrait(selectedTrait);
                }
            }

            return true;
        }

        
        //武者的恢复生命值效果
        public static bool Warrior1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}