using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XuLie
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset XuLie = new ActorTraitGroupAsset();
            XuLie.id = "XuLie";
            XuLie.name = "trait_group_XuLie";
            XuLie.color = "#FFFF00";
            AssetManager.trait_groups.add(XuLie);

            ActorTraitGroupAsset JinSheng = new ActorTraitGroupAsset();
            JinSheng.id = "JinSheng";
            JinSheng.name = "trait_group_JinSheng";
            JinSheng.color = "#00FF00";
            AssetManager.trait_groups.add(JinSheng);


            ActorTraitGroupAsset NineYuanZhi = new ActorTraitGroupAsset();
            NineYuanZhi.id = "NineYuanZhi";
            NineYuanZhi.name = "trait_group_NineYuanZhi";
            NineYuanZhi.color = "#FFA500";
            AssetManager.trait_groups.add(NineYuanZhi);

            ActorTraitGroupAsset ChaofanXuemai = new ActorTraitGroupAsset();
            ChaofanXuemai.id = "ChaofanXuemai";
            ChaofanXuemai.name = "trait_group_ChaofanXuemai";
            ChaofanXuemai.color = "#FF4500"; // 橙红色
            AssetManager.trait_groups.add(ChaofanXuemai);

            ActorTraitGroupAsset weiYixingGroup = new ActorTraitGroupAsset
            {
                id = "WeiYixing",
                name = "trait_group_WeiYixing",
                color = "#8A2BE2" // 紫罗兰色
            };
            AssetManager.trait_groups.add(weiYixingGroup);
        }
    }
}