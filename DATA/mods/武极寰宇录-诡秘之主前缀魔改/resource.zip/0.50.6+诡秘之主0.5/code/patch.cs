using System.Collections; 
using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using VideoCopilot.code.utils;

namespace XuLie.code
{
    internal class patch
    {
        // 标记窗口初始化状态的静态变量
        public static bool window_creature_info_initialized;

        // 为UnitWindow的OnEnable方法添加后缀补丁
        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            // 如果实例的actor为空或已死亡，则直接返回
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            
            // 添加延迟初始化
            __instance.StartCoroutine(DelayedInit(__instance));
        }

        // 延迟初始化方法，确保原生UI完成初始化后再执行自定义UI初始化
        private static IEnumerator DelayedInit(UnitWindow window) 
        {
            // 等待一帧确保原生UI完成初始化
            yield return null; 
    
            // 如果窗口信息未初始化，则进行初始化
            if (!window_creature_info_initialized) {
                UnitWindowStatsIcon.Initialize(window);
                window_creature_info_initialized = true;
            }
    
            // 启用窗口统计图标
            UnitWindowStatsIcon.OnEnable(window, window.actor);
        }

        // 为MapAction的checkLightningAction方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            // 获取世界中所有单位的列表
            List<Actor> simpleList = World.world.units.getSimpleList();
            
            // 遍历所有单位，检查是否在闪电范围内
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    // 如果是神之手指，则执行相应动作
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        // 如果不是不朽且随机概率为20%，设置标志位
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        // 添加成就检查信号
                        SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        BehaviourTaskActor task = actor.ai.task;
                        SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }

        // 为Actor的makeStunned方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            // 随机增加眩晕时间的10%
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            // 取消所有行为
            __instance.cancelAllBeh();
            // 设置等待时间
            __instance.makeWait(pTime);
            
            // 如果没有防火特质，则添加眩晕状态效果，否则不添加眩晕状态效果
            if (!__instance.hasTrait("fire_proof"))
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }

        // 为ActionLibrary的addStunnedEffectOnTarget20方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "addStunnedEffectOnTarget20")]
        // 添加眩晕效果到目标（20%概率）
        public static bool addStunnedEffectOnTarget20_Patch(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 检查目标是否有效（未死亡、非建筑）
            if (pTarget.isRekt() || pTarget.isBuilding()) 
            {
                return false;
            }

            // 检查随机概率（20%）
            if (!Randy.randomChance(0.2f))
            {
                return false;
            }

            // 检查目标是否具有防火特质
            if (pTarget.isActor() && pTarget.a.hasTrait("fire_proof"))
            {
                return false;
            }

            // 调用眩晕方法
            return ActionLibrary.addStunnedEffectOnTarget(pSelf, pTarget, pTile);
        }

        // 为Actor的getHit方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            // 记录最后一次攻击类型
            __instance._last_attack_type = pAttackType;
            
            // 闪避机制
            if (pAttacker is Actor attackerActor && __instance.isAlive())
            {
                // 获取攻击者的准确率和目标的闪避率
                float attackerAccuracy = attackerActor.stats["Accuracy"];
                float targetDodge = __instance.stats["Dodge"];
                // 计算有效闪避率，确保在0-100之间
                float effectiveDodge = Mathf.Clamp(targetDodge - attackerAccuracy, 0f, 100f);

                // 如果随机概率超过有效闪避率，则闪避成功
                if (Randy.randomChance(effectiveDodge / 100f))
                {
                    __instance.startColorEffect(ActorColorEffect.White);
                    return false;
                }
            }
        
            // 死亡处理
            if (!__instance.hasHealth())
            {
                __instance.batch.c_check_deaths.Add(__instance);
            }
            
            // 返回true继续执行原方法
            return true;
        }
        
        // 为ActorTool的applyForceToUnit方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
        public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            // 计算力量值
            float tForce = pData.knockback * pMod;

            // 如果力量大于0且目标是Actor
            if (tForce > 0f && pTargetToCheck.isActor())
            {
                // 获取目标的抵抗值
                float resistValue = pTargetToCheck.a.stats["Resist"];
                // 计算实际力量，确保不小于0
                tForce = Mathf.Max(tForce - resistValue, 0);

                // 如果力量仍大于0，则应用力量
                if (tForce > 0f)
                {
                    Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                    Vector2 tAttackVec = pData.hit_position;
                    pTargetToCheck.a.calculateForce(
                        tPosStart.x, tPosStart.y,
                        tAttackVec.x, tAttackVec.y,
                        tForce,
                        0f,
                        pCheckCancelJobOnLand
                    );
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }
    
        // 为Actor的updateAge方法添加后缀补丁
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_XuLiePostfix(Actor __instance)
        {
            // 如果实例为空，直接返回
            if (__instance == null)
            {
                return;
            }

            // 获取实例的年龄
            float age = (float)__instance.getAge();
            // 检查是否具有各种特质
            bool hasjinSheng10 = __instance.hasTrait("jinSheng10");// 检查是否具有特质
            bool hasjinSheng9 = __instance.hasTrait("jinSheng9");
            bool hasYizhiYoncun = __instance.hasTrait("yizhiYoncun"); // 检查是否拥有“意志永存”特质

            // 检查是否拥有“赐福”特质
            bool hasjinSheng8 = __instance.hasTrait("jinSheng8");
            if (hasjinSheng8)
            {
                __instance.data.favorite = true;
            }

            // 检查是否拥有混沌帝血特质
            bool haschaofanXuemai7 = __instance.hasTrait("chaofanXuemai7");
            if (haschaofanXuemai7)
            {
                // 直接觉醒扮演法
                string jinSheng4Trait = "jinSheng4";
                // 定义晋升特质数组
                string[] jinShengTraits = {
                    "jinSheng1",
                    "jinSheng2",
                    "jinSheng3",
                    "jinSheng4",
                    "jinSheng7",
                    "jinSheng8",
                    "jinSheng9",
                    "jinSheng10",
                    "martialAptitude1",
                    "martialAptitude2",
                    "martialAptitude3",
                    "martialAptitude4",
                    "martialAptitude7",
                    "martialAptitude8"
                };

                // 检查是否已拥有任何晋升特质
                bool hasAnyjinSheng = false;
                foreach (string trait in jinShengTraits)
                {
                    if (__instance.hasTrait(trait))
                    {
                        hasAnyjinSheng = true;
                        break;
                    }
                }

                // 只有在未拥有任何晋升特质时才觉醒扮演法
                if (!hasAnyjinSheng && !__instance.hasTrait("jinSheng4"))
                {
                    __instance.addTrait("jinSheng4");
                }
            }

            // 出生时（年龄为1）有一定概率获得“意志永存”特质
            if (Mathf.FloorToInt(age) == 1 && !hasYizhiYoncun && Randy.randomChance(0.03f)) // 3% 的概率
            {
                __instance.addTrait("yizhiYoncun", false);
            }

            // 定义特定种族数组
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };

            // 4岁时获得jinSheng1 - jinSheng10的随机特质
            if (Mathf.FloorToInt(age) == 5 && !hasjinSheng9 && !hasjinSheng10 &&
                !HasAnyFlairTalen(__instance) &&
                (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {

                // 如果已经拥有扮演法（因混沌帝血获得），则跳过此次随机晋升特质觉醒
                if (__instance.hasTrait("jinSheng4"))
                {
                    return;
                }

                // 根据血脉等级计算额外概率
                float bloodlineBonus = 0f;
                if (__instance.hasTrait("chaofanXuemai1"))
                {
                    bloodlineBonus = 0.2f; // 一级血脉提高20%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai2"))
                {
                    bloodlineBonus = 0.3f; // 二级血脉提高30%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai3"))
                {
                    bloodlineBonus = 0.4f; // 三级血脉提高40%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai4"))
                {
                    bloodlineBonus = 0.5f; // 四级血脉提高50%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai5"))
                {
                    bloodlineBonus = 0.6f; // 五级血脉提高60%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai6"))
                {
                    bloodlineBonus = 0.7f; // 六级血脉提高70%的概率
                }

                // 随机概率是否触发特质获得
                if (Randy.randomChance(0.2f + bloodlineBonus))
                {
                    // 定义各晋升特质的权重
                var jinShengWeights = new (string traitId, float weight)[]
                {
                    ("jinSheng1", 64f),
                    ("jinSheng2", 31f),
                    ("jinSheng3", 4.58f),
                    ("jinSheng4", 0.33f),
                    ("jinSheng7", 0.076f),
                    ("jinSheng8", 0.014f),
                };

                // 计算总权重
                float totalWeight = jinShengWeights.Sum(t => t.weight);

                // 生成随机浮点数
                float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                // 遍历权重选择特质
                string selectedjinSheng = "jinSheng1"; // 默认值
                foreach (var jinSheng in jinShengWeights)
                {
                    if (randomValue < jinSheng.weight)
                    {
                        selectedjinSheng = jinSheng.traitId;
                        break;
                    }
                    randomValue -= jinSheng.weight;
                }

                // 添加选中的特质
                __instance.addTrait(selectedjinSheng, false);
                }
            }


            // 定义闱异星特质对序列值的影响字典
            var weiYixingXuLieChanges = new Dictionary<string, float>
            {
                {"WeiYixing1", 10.0f},
                {"WeiYixing2", 10.0f},
                {"WeiYixing3", 10.0f},
                {"WeiYixing4", 10.0f},
                {"WeiYixing5", 10.0f},
                {"WeiYixing6", 10.5f},
                {"WeiYixing7", 10.0f},
                {"WeiYixing8", 10.0f},
                {"WeiYixing9", 10.0f},
                {"WeiYixing10", 10.0f},
                {"WeiYixing11", 10.0f},
                {"WeiYixing1+", 10.0f},
                {"WeiYixing2+", 10.0f},
                {"WeiYixing3+", 10.0f},
                {"WeiYixing4+", 10.0f},
                {"WeiYixing5+", 10.0f},
                {"WeiYixing6+", 10.0f},
                {"WeiYixing7+", 10.0f},
                {"WeiYixing8+", 10.0f},
                {"WeiYixing9+", 10.0f},
                {"WeiYixing10+", 10.0f},
                {"WeiYixing11+", 10.0f},
            };

            // 应用闱异星特质对序列值的影响
            foreach (var weiYixing in weiYixingXuLieChanges)
            {
                if (__instance.hasTrait(weiYixing.Key))
                {
                    float weiYixingBonus = weiYixing.Value;
                    __instance.ChangeXuLie(weiYixingBonus);
                }
            }

            // 特质增加序列值的处理
            var jinShengXuLieChanges = new Dictionary<string, (float, float)>
            {
                { "jinSheng1", (1.0f, 2.0f) },//魔药主材
                { "jinSheng2", (2.0f, 4.0f) },//完整魔药
                { "jinSheng3", (4.0f, 6.0f) },//消化法
                { "jinSheng4", (6.0f, 9.0f) },//扮演法
                { "jinSheng10", (-1.0f, -2.0f) },//灵性衰败
                { "jinSheng7", (9.0f, 12.0f) },//晋升仪式
                { "jinSheng8", (12.0f, 16.0f) },//旧日赐福
            };

            // 应用晋升特质对序列值的影响
            foreach (var change in jinShengXuLieChanges)
            {
                // 如果具有jinSheng10特质，并且当前特质是jinSheng1到jinSheng4，则跳过
                if ((hasjinSheng10 || hasjinSheng9) && (change.Key == "jinSheng1" || change.Key == "jinSheng2" || change.Key == "jinSheng3" || change.Key == "jinSheng4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    // 在指定范围内随机增加序列值
                    float randomXuLieIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeXuLie(randomXuLieIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var XuLieTraitThresholds = new Dictionary<string, float>
            {
                { "XuLie1", 40f },
                { "XuLie2", 50f },
                { "XuLie3", 50f },
                { "XuLie4", 65f },
                { "XuLie5", 70f },
                { "XuLie6", 100f },
                { "XuLie7", 150f },
                { "XuLie8", 220f },
                { "XuLie9", 400f },
                { "XuLie91", 600f },
                { "XuLie92", 1000f },
                { "XuLie93", 2000f }
            };
            
            // 灵性衰败特质的触发概率
            const float jinSheng10Chance = 0.1f;
            foreach (var threshold in XuLieTraitThresholds)
            {
                // 检查是否满足触发灵性衰败特质的条件
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(jinSheng10Chance) && !hasYizhiYoncun)
                {
                    __instance.addTrait("jinSheng10", false);
                }
            }

            // 定义各境界的最大序列值
            var grades = new Dictionary<string, float>
            {
                { "XuLie1", 10f },
                { "XuLie2", 20f },
                { "XuLie3", 40f },
                { "XuLie4", 80f },
                { "XuLie5", 160f },
                { "XuLie6", 300f },
                { "XuLie7", 500f },
                { "XuLie8", 800f },
                { "XuLie9", 1200f },
                { "XuLie91", 3600f },
                { "XuLie92", 10000f },
                { "XuLie93", 999999f },
            };
            
            // 根据境界更新序列值上限
            foreach (var grade in grades)
            {
                UpdateXuLieBasedOnGrade(__instance, grade.Key, grade.Value);
            }
        }

        // 根据境界更新序列值上限的方法
        private static void UpdateXuLieBasedOnGrade(Actor actor, string traitName, float maxXuLie)
        {
            if (actor.hasTrait(traitName))
            {
                float currentXuLie = actor.GetXuLie();
                // 设置序列值为当前值和最大值中的较小值
                float newValue = Mathf.Min(maxXuLie, currentXuLie);
                actor.SetXuLie(newValue);
            }
        }

        // 定义包含晋升和天赋特质的数组
        private static readonly string[] FlairjinShengTraits = new[] { "jinSheng1", "jinSheng2", "jinSheng3", "jinSheng4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7", "martialAptitude1", "martialAptitude2", "martialAptitude3", "martialAptitude4", "martialAptitude7", "martialAptitude8" };
        
        // 检查是否具有任何晋升或天赋特质的方法
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairjinShengTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}