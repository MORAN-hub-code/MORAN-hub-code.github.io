using UnityEngine;

namespace VideoCopilot.code.utils
{
    public static class ActorExtensions
    {
        private const string xuLie_key = "xulie.xuLieNum";
        private const string lifespan_key = "strings.S.lifespan";

        public static float GetXuLie(this Actor actor)
        {
            actor.data.get(xuLie_key, out float val, 0);
            return val;
        }

        public static void SetXuLie(this Actor actor, float val)
        {
            actor.data.set(xuLie_key, val);
        }

        public static void ChangeXuLie(this Actor actor, float delta)
        {
            actor.data.get(xuLie_key, out float val, 0);
            val += delta;
            actor.data.set(xuLie_key, Mathf.Max(0, val));
        }
    }
}