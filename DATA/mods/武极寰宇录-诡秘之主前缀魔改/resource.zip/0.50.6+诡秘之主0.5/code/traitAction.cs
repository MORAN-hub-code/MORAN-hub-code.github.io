using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace XuLie.code
{
    internal class traitAction
    {
        // 定义晋升途径字典
        private static readonly Dictionary<string, Dictionary<string, string>> _xuLiePathways = new Dictionary<string, Dictionary<string, string>>
        {
            // 占卜家途径
            {"占卜家", new Dictionary<string, string>
            {
                {"XuLie2", "占卜家"},
                {"XuLie3", "小丑"},
                {"XuLie4", "魔术师"},
                {"XuLie5", "无面人"},
                {"XuLie6", "秘偶大师"},
                {"XuLie7", "诡法师"},
                {"XuLie8", "古代学者"},
                {"XuLie9", "奇迹师"},
                {"XuLie91", "诡秘侍者"},
                {"XuLie93", "愚者"},
                {"XuLie00", "诡秘之主"}
            }},
            // 偷盗者途径
            {"偷盗者", new Dictionary<string, string>
            {
                {"XuLie2", "偷盗者"},
                {"XuLie3", "诈骗师"},
                {"XuLie4", "解密学者"},
                {"XuLie5", "盗火人"},
                {"XuLie6", "窃梦家"},
                {"XuLie7", "寄生者"},
                {"XuLie8", "欺瞒导师"},
                {"XuLie9", "命运木马"},
                {"XuLie91", "时之虫"},
                {"XuLie93", "错误"},
                {"XuLie00", "诡秘之主"}
            }},
            // 学徒途径
            {"学徒", new Dictionary<string, string>
            {
                {"XuLie2", "学徒"},
                {"XuLie3", "戏法大师"},
                {"XuLie4", "占星人"},
                {"XuLie5", "记录官"},
                {"XuLie6", "旅行家"},
                {"XuLie7", "秘法师"},
                {"XuLie8", "漫游者"},
                {"XuLie9", "旅法师"},
                {"XuLie91", "星之钥"},
                {"XuLie93", "门"},
                {"XuLie00", "诡秘之主"}
            }},
            // 观众途径
            {"观众", new Dictionary<string, string>
            {
                {"XuLie2", "观众"},
                {"XuLie3", "读心者"},
                {"XuLie4", "心理医生"},
                {"XuLie5", "催眠师"},
                {"XuLie6", "梦境行者"},
                {"XuLie7", "操纵师"},
                {"XuLie8", "织梦人"},
                {"XuLie9", "洞察者"},
                {"XuLie91", "作家"},
                {"XuLie93", "空想家"},
                {"XuLie00", "上帝"}
            }},
            // 歌颂者途径
            {"歌颂者", new Dictionary<string, string>
            {
                {"XuLie2", "歌颂者"},
                {"XuLie3", "祈光人"},
                {"XuLie4", "太阳神官"},
                {"XuLie5", "公证人"},
                {"XuLie6", "光之祭司"},
                {"XuLie7", "无暗者"},
                {"XuLie8", "正义导师"},
                {"XuLie9", "逐光者"},
                {"XuLie91", "纯白天使"},
                {"XuLie93", "太阳"},
                {"XuLie00", "上帝"}
            }},
            // 水手途径
            {"水手", new Dictionary<string, string>
            {
                {"XuLie2", "水手"},
                {"XuLie3", "暴怒之民"},
                {"XuLie4", "航海家"},
                {"XuLie5", "风眷者"},
                {"XuLie6", "海洋歌者"},
                {"XuLie7", "灾难主祭"},
                {"XuLie8", "海王"},
                {"XuLie9", "天灾"},
                {"XuLie91", "雷神"},
                {"XuLie93", "暴君"},
                {"XuLie00", "上帝"}
            }},
            // 阅读者途径
            {"阅读者", new Dictionary<string, string>
            {
                {"XuLie2", "阅读者"},
                {"XuLie3", "推理学员"},
                {"XuLie4", "侦探"},
                {"XuLie5", "博学者"},
                {"XuLie6", "秘术导师"},
                {"XuLie7", "预言家"},
                {"XuLie8", "洞悉者"},
                {"XuLie9", "智天使"},
                {"XuLie91", "全知之眼"},
                {"XuLie93", "白塔"},
                {"XuLie00", "上帝"}
            }},
            // 秘祈人途径
            {"秘祈人", new Dictionary<string, string>
            {
                {"XuLie2", "秘祈人"},
                {"XuLie3", "倾听者"},
                {"XuLie4", "隐修士"},
                {"XuLie5", "蔷薇主教"},
                {"XuLie6", "牧羊人"},
                {"XuLie7", "黑骑士"},
                {"XuLie8", "三首圣堂"},
                {"XuLie9", "秽语长老"},
                {"XuLie91", "暗天使"},
                {"XuLie93", "倒吊人"},
                {"XuLie00", "上帝"}
            }},
            // 收尸人途径
            {"收尸人", new Dictionary<string, string>
            {
                {"XuLie2", "收尸人"},
                {"XuLie3", "掘墓人"},
                {"XuLie4", "通灵者"},
                {"XuLie5", "死灵导师"},
                {"XuLie6", "看门人"},
                {"XuLie7", "不死者"},
                {"XuLie8", "摆渡人"},
                {"XuLie9", "死亡执政官"},
                {"XuLie91", "苍白皇帝"},
                {"XuLie93", "死神"},
                {"XuLie00", "时空归一者"}
            }},
            // 不眠者途径
            {"不眠者", new Dictionary<string, string>
            {
                {"XuLie2", "不眠者"},
                {"XuLie3", "午夜诗人"},
                {"XuLie4", "梦魇"},
                {"XuLie5", "安魂师"},
                {"XuLie6", "灵巫"},
                {"XuLie7", "守夜人"},
                {"XuLie8", "恐惧主教"},
                {"XuLie9", "隐秘之仆"},
                {"XuLie91", "厄难天使"},
                {"XuLie93", "黑暗"},
                {"XuLie00", "时空归一者"}
            }},
            // 战士途径
            {"战士", new Dictionary<string, string>
            {
                {"XuLie2", "战士"},
                {"XuLie3", "格斗家"},
                {"XuLie4", "武器大师"},
                {"XuLie5", "黎明骑士"},
                {"XuLie6", "守护者"},
                {"XuLie7", "猎魔者"},
                {"XuLie8", "银骑士"},
                {"XuLie9", "荣耀者"},
                {"XuLie91", "神明之手"},
                {"XuLie93", "黄昏巨人"},
                {"XuLie00", "时空归一者"}
            }},
            // 刺客途径
            {"刺客", new Dictionary<string, string>
            {
                {"XuLie2", "刺客"},
                {"XuLie3", "教唆者"},
                {"XuLie4", "女巫"},
                {"XuLie5", "欢愉魔女"},
                {"XuLie6", "痛苦魔女"},
                {"XuLie7", "绝望魔女"},
                {"XuLie8", "不老魔女"},
                {"XuLie9", "灾难魔女"},
                {"XuLie91", "末日魔女"},
                {"XuLie93", "原初魔女"},
                {"XuLie00", "毁灭天灾"}
            }},
            // 猎人途径
            {"猎人", new Dictionary<string, string>
            {
                {"XuLie2", "猎人"},
                {"XuLie3", "挑衅者"},
                {"XuLie4", "纵火家"},
                {"XuLie5", "阴谋家"},
                {"XuLie6", "收割者"},
                {"XuLie7", "铁血骑士"},
                {"XuLie8", "战争主教"},
                {"XuLie9", "天气术士"},
                {"XuLie91", "征服者"},
                {"XuLie93", "红祭司"},
                {"XuLie00", "毁灭天灾"}
            }},
            // 窥秘人途径
            {"窥秘人", new Dictionary<string, string>
            {
                {"XuLie2", "窥秘人"},
                {"XuLie3", "格斗学者"},
                {"XuLie4", "巫师"},
                {"XuLie5", "卷轴教授"},
                {"XuLie6", "星象师"},
                {"XuLie7", "神秘学家"},
                {"XuLie8", "预言大师"},
                {"XuLie9", "贤者"},
                {"XuLie91", "知识皇帝"},
                {"XuLie93", "隐者"},
                {"XuLie00", "知识之妖"}
            }},
            // 通识者途径
            {"通识者", new Dictionary<string, string>
            {
                {"XuLie2", "通识者"},
                {"XuLie3", "考古学家"},
                {"XuLie4", "鉴定师"},
                {"XuLie5", "机械专家"},
                {"XuLie6", "天文学家"},
                {"XuLie7", "炼金术士"},
                {"XuLie8", "奥秘学者"},
                {"XuLie9", "知识导师"},
                {"XuLie91", "启蒙者"},
                {"XuLie93", "完美者"},
                {"XuLie00", "知识之妖"}
            }},
            // 怪物途径
            {"怪物", new Dictionary<string, string>
            {
                {"XuLie2", "怪物"},
                {"XuLie3", "机器"},
                {"XuLie4", "幸运儿"},
                {"XuLie5", "灾祸教士"},
                {"XuLie6", "赢家"},
                {"XuLie7", "厄运法师"},
                {"XuLie8", "混乱行者"},
                {"XuLie9", "先知"},
                {"XuLie91", "水银之蛇"},
                {"XuLie93", "命运之轮"},
                {"XuLie00", "光之钥"}
            }},
            // 耕种者途径
            {"耕种者", new Dictionary<string, string>
            {
                {"XuLie2", "耕种者"},
                {"XuLie3", "医师"},
                {"XuLie4", "丰收祭司"},
                {"XuLie5", "生物学家"},
                {"XuLie6", "德鲁伊"},
                {"XuLie7", "古代炼金士"},
                {"XuLie8", "抬棺人"},
                {"XuLie9", "荒芜主母"},
                {"XuLie91", "自然行者"},
                {"XuLie93", "母亲"},
                {"XuLie00", "万物之母"}
            }},
            // 药师途径
            {"药师", new Dictionary<string, string>
            {
                {"XuLie2", "药师"},
                {"XuLie3", "驯兽师"},
                {"XuLie4", "吸血鬼"},
                {"XuLie5", "魔药教授"},
                {"XuLie6", "深红学者"},
                {"XuLie7", "巫王"},
                {"XuLie8", "召唤大师"},
                {"XuLie9", "创生者"},
                {"XuLie91", "美神"},
                {"XuLie93", "月亮"},
                {"XuLie00", "万物之母"}
            }},
            // 罪犯途径
            {"罪犯", new Dictionary<string, string>
            {
                {"XuLie2", "罪犯"},
                {"XuLie3", "冷血者"},
                {"XuLie4", "连环杀手"},
                {"XuLie5", "恶魔"},
                {"XuLie6", "欲望使徒"},
                {"XuLie7", "魔鬼"},
                {"XuLie8", "呓语者"},
                {"XuLie9", "鲜血大公"},
                {"XuLie91", "污秽君王"},
                {"XuLie93", "深渊"},
                {"XuLie00", "诅咒之源"}
            }},

            // 仲裁人途径
            {"仲裁人", new Dictionary<string, string>
            {
                {"XuLie2", "仲裁人"},
                {"XuLie3", "治安官"},
                {"XuLie4", "审讯者"},
                {"XuLie5", "法官"},
                {"XuLie6", "惩戒骑士"},
                {"XuLie7", "律令法师"},
                {"XuLie8", "混乱猎手"},
                {"XuLie9", "平衡者"},
                {"XuLie91", "秩序之手"},
                {"XuLie93", "审判者"},
                {"XuLie00", "混沌之子"}
            }},
            // 律师途径
            {"律师", new Dictionary<string, string>
            {
                {"XuLie2", "律师"},
                {"XuLie3", "野蛮人"},
                {"XuLie4", "贿赂者"},
                {"XuLie5", "腐化男爵"},
                {"XuLie6", "混乱导师"},
                {"XuLie7", "堕落伯爵"},
                {"XuLie8", "狂乱法师"},
                {"XuLie9", "熵之公爵"},
                {"XuLie91", "弑序亲王"},
                {"XuLie93", "黑皇帝"},
                {"XuLie00", "混沌之子"}
            }},
            // 囚犯途径
            {"囚犯", new Dictionary<string, string>
            {
                {"XuLie2", "囚犯"},
                {"XuLie3", "疯子"},
                {"XuLie4", "狼人"},
                {"XuLie5", "活尸"},
                {"XuLie6", "怨魂"},
                {"XuLie7", "木偶"},
                {"XuLie8", "沉默门徒"},
                {"XuLie9", "古代邪物"},
                {"XuLie91", "神孽"},
                {"XuLie93", "被缚者"},
                {"XuLie00", "诅咒之源"}
            }},
        };

        // 记录角色选择的途径
        private static readonly Dictionary<Actor, string> _actorPathways = new Dictionary<Actor, string>();

        // 定义相邻途径关系
        private static readonly Dictionary<string, List<string>> _adjacentPathways = new Dictionary<string, List<string>>
        {
            {"占卜家", new List<string> {"偷盗者", "学徒"}},
            {"偷盗者", new List<string> {"占卜家", "学徒"}},
            {"学徒", new List<string> {"占卜家", "偷盗者"}},
            {"观众", new List<string> {"歌颂者", "水手", "阅读者", "秘祈人"}},
            {"歌颂者", new List<string> {"观众", "水手", "阅读者", "秘祈人"}},
            {"水手", new List<string> {"观众", "歌颂者", "阅读者", "秘祈人"}},
            {"阅读者", new List<string> {"观众", "歌颂者", "水手", "秘祈人"}},
            {"秘祈人", new List<string> {"观众", "歌颂者", "水手", "阅读者"}},
            {"收尸人", new List<string> {"不眠者", "战士"}},
            {"不眠者", new List<string> {"收尸人", "战士"}},
            {"战士", new List<string> {"收尸人", "不眠者"}},
            {"刺客", new List<string> {"猎人"}},
            {"猎人", new List<string> {"刺客"}},
            {"窥秘人", new List<string> {"通识者"}},
            {"通识者", new List<string> {"窥秘人"}},
            {"耕种者", new List<string> {"药师"}},
            {"药师", new List<string> {"耕种者"}},
            {"罪犯", new List<string> {"囚犯"}},
            {"囚犯", new List<string> {"罪犯"}},
            {"仲裁人", new List<string> {"律师"}},
            {"律师", new List<string> {"仲裁人"}}
            // 怪物途径没有相邻途径，不需要添加
        };

        // 记录唯一性特质的持有者，实现全局唯一性
        private static readonly Dictionary<string, Actor> _uniquenessOwners = new Dictionary<string, Actor>();

        // 记录源质的持有者，实现全局唯一性
        private static readonly Dictionary<string, Actor> _sourceQualityOwners = new Dictionary<string, Actor>();

        // 定义途径与源质的对应关系
        private static readonly Dictionary<string, string> _pathwayToSourceQuality = new Dictionary<string, string>
        {
            // 混沌海 (NineYuanZhi1)
            {"观众", "NineYuanZhi1"},
            {"歌颂者", "NineYuanZhi1"},
            {"水手", "NineYuanZhi1"},
            {"阅读者", "NineYuanZhi1"},
            {"秘祈人", "NineYuanZhi1"},
            
            // 源堡 (NineYuanZhi2)
            {"占卜家", "NineYuanZhi2"},
            {"学徒", "NineYuanZhi2"},
            {"偷盗者", "NineYuanZhi2"},
            
            // 母巢 (NineYuanZhi3)
            {"耕种者", "NineYuanZhi3"},
            {"药师", "NineYuanZhi3"},
            
            // 永暗之河 (NineYuanZhi4)
            {"收尸人", "NineYuanZhi4"},
            {"不眠者", "NineYuanZhi4"},
            {"战士", "NineYuanZhi4"},
            
            // 灾祸之城 (NineYuanZhi5)
            {"刺客", "NineYuanZhi5"},
            {"猎人", "NineYuanZhi5"},
            
            // 失序之国 (NineYuanZhi6)
            {"律师", "NineYuanZhi6"},
            {"仲裁人", "NineYuanZhi6"},
            
            // 知识荒野 (NineYuanZhi7)
            {"窥秘人", "NineYuanZhi7"},
            {"通识者", "NineYuanZhi7"},
            
            // 光之钥 (NineYuanZhi8)
            {"怪物", "NineYuanZhi8"},
            
            // 暗影世界 (NineYuanZhi9)
            {"罪犯", "NineYuanZhi9"},
            {"囚犯", "NineYuanZhi9"}
        };

        // 记录各途径高序列角色数量
        private static readonly Dictionary<string, Dictionary<string, int>> _pathwayHighSequenceCounts = new Dictionary<string, Dictionary<string, int>>();
        // 初始化高序列计数字典
        static traitAction()
        {
            // 初始化所有途径的高序列计数
            foreach (string pathway in _xuLiePathways.Keys)
            {
                _pathwayHighSequenceCounts[pathway] = new Dictionary<string, int>
                {
                    { "XuLie9", 0 },  // 序列二
                    { "XuLie91", 0 }, // 序列一
                    { "XuLie92", 0 }, // 天使之王
                    { "XuLie93", 0 }  // 真神
                };
            }
        }

        // 获取角色的途径
        private static string GetActorPathway(Actor actor)
        {
            if (_actorPathways.TryGetValue(actor, out string pathway))
            {
                return pathway;
            }
            
            // 如果没有记录，尝试通过尊号获取
            string highestXuLie = GetHighestXuLieTrait(actor);
            if (highestXuLie != null)
            {
                ApplyXuLieTitle(actor, highestXuLie);
                if (_actorPathways.TryGetValue(actor, out pathway))
                {
                    return pathway;
                }
            }
            
            return null;
        }

        // 更新高序列计数
        private static void UpdateHighSequenceCount(string pathway, string traitId, int change)
        {
            if (_pathwayHighSequenceCounts.ContainsKey(pathway) && _pathwayHighSequenceCounts[pathway].ContainsKey(traitId))
            {
                _pathwayHighSequenceCounts[pathway][traitId] += change;
                // 确保计数不为负数
                if (_pathwayHighSequenceCounts[pathway][traitId] < 0)
                {
                    _pathwayHighSequenceCounts[pathway][traitId] = 0;
                }
            }
        }

        // 检查是否可以晋升到指定高序列
        private static bool CanPromoteToHighSequence(Actor actor, string targetTraitId)
        {
            string pathway = GetActorPathway(actor);
            string originalPathway = pathway; // 保存原始途径

            // 检查是否是相邻途径晋升
            if (targetTraitId == "XuLie92" || targetTraitId == "XuLie93")
            {
                // 获取角色当前的最高序列特质
                string currentHighestTrait = GetHighestXuLieTrait(actor);
                if (currentHighestTrait == "XuLie91") // 从序列一晋升
                {
                    // 检查是否是晋升到相邻途径
                    if (_adjacentPathways.ContainsKey(originalPathway) && _adjacentPathways[originalPathway].Contains(pathway))
                    {
                        // 序列一可以晋升相邻途径的天使之王，但不能晋升真神
                        if (targetTraitId == "XuLie93")
                        {
                            NotificationHelper.ShowNotification(actor, $"{actor.getName()}作为序列一，无法晋升到相邻途径的真神！");
                            return false;
                        }
                    }
                }
            }

            if (pathway == null || !_pathwayHighSequenceCounts.ContainsKey(pathway))
            {
                return true; // 如果无法确定途径，默认允许晋升
            }

            var counts = _pathwayHighSequenceCounts[pathway];
            int existingXuLie9 = counts["XuLie9"];
            int existingXuLie91 = counts["XuLie91"];
            int existingXuLie92 = counts["XuLie92"];
            int existingXuLie93 = counts["XuLie93"];

            // 如果已有真神，不允许晋升天使之王和序列一
            if (existingXuLie93 > 0)
            {
                if (targetTraitId == "XuLie92" || targetTraitId == "XuLie91")
                {
                    if (targetTraitId == "XuLie91")
                    {
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有真神，无法晋升序列一！");
                    }
                    else
                    {
                        NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有真神，无法晋升为{targetTraitId}！");
                    }
                    return false;
                }
                // 允许晋升序列二，但最多3个
                if (targetTraitId == "XuLie9" && existingXuLie9 >= 3)
                {
                    NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有3个序列二，无法晋升！");
                    return false;
                }
            }
            else
            {
                // 没有真神的情况
                switch (targetTraitId)
                {
                    case "XuLie92":// 天使之王
                        if (existingXuLie92 >= 2) // 最多2个天使之王
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王，无法晋升！");
                            return false;
                        }
                        break;
                    case "XuLie91":// 序列一
                        if (existingXuLie92 >= 2) // 有2个天使之王时不能有序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王，无法晋升为序列一！");
                            return false;
                        }
                        if (existingXuLie92 == 1 && existingXuLie91 >= 2) // 有1个天使之王时最多2个序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王和2个序列一，无法晋升！");
                            return false;
                        }
                        if (existingXuLie92 == 0 && existingXuLie91 >= 3) // 没有天使之王时最多3个序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有3个序列一，无法晋升！");
                            return false;
                        }
                        break;
                    case "XuLie9":// 序列二
                        if (existingXuLie92 >= 2 && existingXuLie9 >= 3) // 有2个天使之王时最多3个序列二
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王和3个序列二，无法晋升！");
                            return false;
                        }
                        if (existingXuLie92 == 1)
                        {
                            if (existingXuLie91 > 0 && existingXuLie9 >= 3) // 有1个天使之王和序列一时最多3个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王、序列一和3个序列二，无法晋升！");
                                return false;
                            }
                            if (existingXuLie91 == 0 && existingXuLie9 >= 5) // 有1个天使之王但无序列一时最多5个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王和5个序列二，无法晋升！");
                                return false;
                            }
                        }
                        if (existingXuLie92 == 0)
                        {
                            if (existingXuLie91 > 0 && existingXuLie9 >= 3) // 没有天使之王但有序列一时最多3个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有序列一和3个序列二，无法晋升！");
                                return false;
                            }
                            if (existingXuLie91 == 0 && existingXuLie9 >= 6) // 没有天使之王和序列一时最多6个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有6个序列二，无法晋升！");
                                return false;
                            }
                        }
                        break;
                }
            }

            return true;
        }

        // 当出现真神时，降级现有高序列角色
        private static void DemoteHighSequenceActors(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;

            // 获取该途径所有天使之王和序列一角色
            List<Actor> actorsToDemote = new List<Actor>();
            foreach (var kvp in _actorPathways)
            {
                Actor actor = kvp.Key;
                string actorPathway = kvp.Value;
                if (actorPathway == pathway && (actor.hasTrait("XuLie92") || actor.hasTrait("XuLie91")))
                {
                    actorsToDemote.Add(actor);
                }
            }

            // 获取该途径序列二数量
            int xuLie9Count = _pathwayHighSequenceCounts[pathway]["XuLie9"];

            foreach (Actor actor in actorsToDemote)
            {
                if (actor.hasTrait("XuLie92"))
                {
                    // 天使之王降级
                    if (xuLie9Count < 3)
                    {
                        // 降级到序列二
                        upTrait("XuLie92", "XuLie9", actor, 
                            new string[] { "XuLie92+", "chaofanXuemai6" }, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                        xuLie9Count++;
                    }
                    else
                    {
                        // 降级到序列三
                        upTrait("XuLie92", "XuLie8", actor, 
                            new string[] { "XuLie92+", "chaofanXuemai6" }, 
                            new string[] { "XuLie8+", "fire_proof", "regeneration", "chaofanXuemai3" });
                        UpdateNameSuffix(actor, "XuLie8");
                        ApplyXuLieTitle(actor, "XuLie8");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                    }
                    // 更新计数
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                }
                else if (actor.hasTrait("XuLie91"))
                {
                    // 序列一降级
                    if (xuLie9Count < 3)
                    {
                        // 降级到序列二
                        upTrait("XuLie91", "XuLie9", actor, 
                            new string[] { "XuLie91+", "chaofanXuemai5" }, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                        xuLie9Count++;
                    }
                    else
                    {
                        // 降级到序列三
                        upTrait("XuLie91", "XuLie8", actor, 
                            new string[] { "XuLie91+", "chaofanXuemai5" }, 
                            new string[] { "XuLie8+", "fire_proof", "regeneration", "chaofanXuemai3" });
                        UpdateNameSuffix(actor, "XuLie8");
                        ApplyXuLieTitle(actor, "XuLie8");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                    }
                    // 更新计数
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                }
            }
        }

        public static bool IsXuLie1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"XuLie{i}") || a.hasTrait($"XuLie{i}+"))
                {
                    return true;
                }
            }
            return false;
        }

        private static readonly Dictionary<string, string> _xuLieSuffixMap = new Dictionary<string, string>
        {
            {"XuLie1", "半超凡"},
            {"XuLie2", "序列九"},
            {"XuLie3", "序列八"},
            {"XuLie4", "序列七"},
            {"XuLie5", "序列六"},
            {"XuLie6", "序列五"},
            {"XuLie7", "序列四_半神"},
            {"XuLie8", "序列三_半神"},
            {"XuLie9", "序列二_天使"},
            {"XuLie91", "序列一_天使"},
            {"XuLie92", "天使之王"},
            {"XuLie93", "真神"}
        };


        // 尊号字典
        private static readonly Dictionary<string, string[]> _xuLieTitlesMap = new Dictionary<string, string[]>
        {
            {"XuLie2", new string[] {
                "占卜家","学徒","偷盗者","观众","水手","歌颂者","阅读者","秘祈人","收尸人","不眠者","战士","刺客","猎人","窥秘人","通识者","怪物","耕种者","药师","仲裁人","律师","囚犯","罪犯"
            }},
            // 其他境界尊号保持不变
            {"XuLie3", new string[] {
                "小丑","戏法大师","诈骗师","读心者","暴怒之民","祈光人","推理学员","倾听者","掘墓人","午夜诗人","格斗家","教唆者","挑衅者","格斗学者","考古学家","机器","医师","驯兽师","治安官","野蛮人","疯子","冷血者"
            }},
            {"XuLie4", new string[] {
                "魔术师","解密学者","占星人","心理医生","太阳神官","航海家","侦探","隐修士","梦魇","通灵者","武器大师","女巫","纵火家","巫师","幸运儿","丰收祭司","吸血鬼","连环杀手","狼人","贿赂者","审讯者","鉴定师"
            }},
            {"XuLie5", new string[] {
                "无面人","盗火人","记录官","催眠师","公证人","风眷者","博学者","蔷薇主教","安魂师","死灵导师","黎明骑士","欢愉魔女","阴谋家","卷轴教授","机械专家","灾祸教士","生物学家","魔药教授","恶魔","活尸","腐化男爵","法官"
            }},
            {"XuLie6", new string[] {
                "秘偶大师","窃梦家","旅行家","梦境行者","光之祭司","秘术导师","海洋歌者","牧羊人","灵巫","看门人","守护者","痛苦魔女","收割者","星象师","天文学家","赢家","德鲁伊","深红学者","欲望使徒","怨魂","混乱导师","惩戒骑士"
            }},
            {"XuLie7", new string[] {
                "诡法师","寄生者","秘法师","操纵师","无暗者","灾难主祭","预言家","黑骑士","守夜人","不死者","猎魔者","绝望魔女","铁血骑士","神秘学家","炼金术士","厄运法师","古代炼金士","巫王","魔鬼","木偶","堕落伯爵","律令法师"
            }},
            {"XuLie8", new string[] {
                "古代学者","欺瞒导师","漫游者","织梦人","正义导师","海王","洞悉者","三首圣堂","恐惧主教","摆渡人","银骑士","不老魔女","战争主教","预言大师","奥秘学者","混乱行者","抬棺人","召唤大师","呓语者","沉默门徒","狂乱法师","混乱猎手"
            }},
            {"XuLie9", new string[] {
                "奇迹师","命运木马","旅法师","洞察者","逐光者","天灾","智天使","秽语长老","隐秘之仆","死亡执政官","荣耀者","灾难魔女","天气术士","贤者","知识导师","先知","荒芜主母","创生者","鲜血大公","古代邪物","熵之公爵","平衡者"
            }},
            {"XuLie91", new string[] {
                "诡秘侍者","星之钥","时之虫","作家","雷神","纯白天使","全知之眼","暗天使","苍白皇帝","厄难天使","神明之手","末日魔女","征服者","知识皇帝","启蒙者","水银之蛇","自然行者","美神","秩序之手","弑序亲王","神孽","污秽君王"
            }},
            // 真神尊号
            {"XuLie93", new string[] {
                "愚者","门","错误","空想家","暴君","太阳","白塔","倒吊人","死神","黑暗","黄昏巨人","原初魔女","红祭司","隐者","完美者","命运之轮","母亲","月亮","审判者","黑皇帝","被缚者","深渊"
            }},
            // 旧日尊号
            {"XuLie00", new string[] {
                "诡秘之主","全知全能者","时空归一者","毁灭天灾","知识之妖","光之钥","万物之母","混沌之子","诅咒之源","宿命之环","命运女神","原初饥饿","超星主宰","衰败君王","高维俯视者","不熄的呓语","上帝"
            }}
        };

        private static void ApplyXuLieTitle(Actor actor, string newTrait)
        {
            if (newTrait == "XuLie2")
        {
            // 晋升XuLie2时，随机选择一个前缀
            string[] titles = _xuLieTitlesMap["XuLie2"];
            string title = titles[UnityEngine.Random.Range(0, titles.Length)];
            _actorPathways[actor] = title; // 记录角色选择的途径

            string currentName = actor.getName();
            int separatorIndex = currentName.IndexOfAny(new[] { '|' });
            string baseName = separatorIndex > 0 
                ? currentName.Substring(separatorIndex + 1).Trim()
                : currentName;

            actor.data.setName($"{title}|{baseName}");
        }
            else if (_actorPathways.ContainsKey(actor))
        {
            // 后续晋升时，根据记录的途径选择对应的前缀
            string pathway = _actorPathways[actor];
            
            // 检查是否可以晋升到相邻途径
            // 序列四(XuLie7/XuLie8)及以上有一个概率，序列二(XuLie9及以上)有更高概率
            float promotionChance = 0.0f;
            
            if (newTrait == "XuLie9" || newTrait == "XuLie91")
            {
                // 序列二及以上：40%概率
                promotionChance = 0.4f;
            }
            else if (newTrait == "XuLie7" || newTrait == "XuLie8")
            {
                // 序列四及以上：20%概率
                promotionChance = 0.2f;
            }
            
            if (promotionChance > 0 && UnityEngine.Random.Range(0.0f, 1.0f) <= promotionChance && _adjacentPathways.ContainsKey(pathway))
            {
                // 获取相邻途径
                List<string> adjacentPaths = _adjacentPathways[pathway];
                if (adjacentPaths != null && adjacentPaths.Count > 0)
                {
                    // 优先考虑相邻途径是否有空位（没有真神）
                    List<string> availablePaths = new List<string>();
                    foreach (string adjacentPath in adjacentPaths)
                    {
                        if (_pathwayHighSequenceCounts.ContainsKey(adjacentPath) && 
                            _pathwayHighSequenceCounts[adjacentPath]["XuLie93"] == 0)
                        {
                            availablePaths.Add(adjacentPath);
                        }
                    }
                    
                    if (availablePaths.Count > 0)
                    {
                        // 如果有可用的相邻途径，选择一个
                        pathway = availablePaths[UnityEngine.Random.Range(0, availablePaths.Count)];
                        // 更新角色的途径记录
                        _actorPathways[actor] = pathway;
                        string actorName = actor.getName();
                        int separatorIndex = actorName.IndexOfAny(new[] { '|' });
                        string baseName = separatorIndex > 0 
                            ? actorName.Substring(separatorIndex + 1).Trim()
                            : actorName;
                        NotificationHelper.ShowNotification(actor, $"{baseName}晋升到相邻途径[{pathway}]！");
                    }
                }
            }
            
            if (_xuLiePathways.ContainsKey(pathway) && _xuLiePathways[pathway].TryGetValue(newTrait, out string title))
            {
                string currentName = actor.getName();
                int separatorIndex = currentName.IndexOfAny(new[] { '|' });
                string baseName = separatorIndex > 0 
                    ? currentName.Substring(separatorIndex + 1).Trim()
                    : currentName;

                actor.data.setName($"{title}|{baseName}");
            }
        }
        else
        {
            // 无序列时，随机选择一个完整序列途径
            var allPathways = _xuLiePathways.Keys.ToList();
            if (allPathways.Count > 0)
            {
                // 随机选择一个途径
                string randomPathway = allPathways[UnityEngine.Random.Range(0, allPathways.Count)];
                // 记录该途径
                _actorPathways[actor] = randomPathway;
                
                // 检测角色是否有更高序列等级的特性
                string highestXuLieTrait = GetHighestXuLieTrait(actor);
                string title;
                
                if (!string.IsNullOrEmpty(highestXuLieTrait))
                {
                    // 如果有更高序列等级，使用对应等级的尊号
                    if (_xuLiePathways[randomPathway].TryGetValue(highestXuLieTrait, out title))
                    {
                        // 找到了对应等级的尊号
                    }
                    else
                    {
                        // 没有找到对应等级的尊号，使用序列九尊号
                        title = _xuLiePathways[randomPathway]["XuLie2"];
                    }
                }
                else
                {
                    // 没有更高序列等级，使用序列九尊号
                    title = _xuLiePathways[randomPathway]["XuLie2"];
                }
                
                string currentName = actor.getName();
                int separatorIndex = currentName.IndexOfAny(new[] { '|' });
                string baseName = separatorIndex > 0 
                    ? currentName.Substring(separatorIndex + 1).Trim()
                    : currentName;
                actor.data.setName($"{title}|{baseName}");
            }
        }
        }
            private static string GetHighestXuLieTrait(Actor actor)
        {
            // 定义序列等级的优先级顺序（从高到低）
            string[] xuLieTraits = { "XuLie00", "XuLie93", "XuLie91", "XuLie9", "XuLie8", "XuLie7", "XuLie6", "XuLie5", "XuLie4", "XuLie3", "XuLie2" };
            
            foreach (string trait in xuLieTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return trait;
                }
            }
            
            return null;
        }

private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_xuLieSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        int dashIndex = currentName.IndexOf('-');
        
        // 如果名称中已包含后缀，移除旧后缀
        string baseName = dashIndex > 0 
            ? currentName.Substring(0, dashIndex).Trim()
            : currentName;
        
        // 设置新名称：基础名 + 后缀
        actor.data.setName($"{baseName}-{suffix}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武域境(XuLie9)、合道境(XuLie91)、斩我境(XuLie92)、武极境(XuLie93)均无视此真伤
                if (targetActor.hasTrait("XuLie9") || targetActor.hasTrait("XuLie91") || 
                    targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.09f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 序列二_天使(XuLie9)、序列一_天使(XuLie91)、天使之王(XuLie92)、真神(XuLie93)均无视此真伤
                if (targetActor.hasTrait("XuLie9") || targetActor.hasTrait("XuLie91") || 
                    targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.1f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.06f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (targetActor.hasTrait("XuLie91") || targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.11f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.07f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 天使之王(XuLie92)、真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.12f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.08f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.13f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie93"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.14f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.15f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                }
                // 可以添加一些视觉效果，例如粒子效果
                AssetManager.terraform.get("lightning_normal").apply_force = false;
                MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }

        public static bool fire1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_bomb_flash", pTile,"Bomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool fire2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile,"NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool TrueDamageByXuLie1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的20%作为基础伤害）
            float baseDamage = xuLieValue * 0.2f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("XuLie93")) // 真神减免90%伤害
                trueDamage = (int)(trueDamage * 0.1f);
            else if (targetActor.hasTrait("XuLie92")) // 天使之王减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
    
            // 6. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.16f);
    
            return true;
        }

        public static bool TrueDamageByXuLie2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的30%作为基础伤害）
            float baseDamage = xuLieValue * 0.3f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("XuLie93")) // 真神减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
    
            // 6. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.32f);
    
            return true;
        }

        public static bool TrueDamageByXuLie3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的50%作为基础伤害）
            float baseDamage = xuLieValue * 0.5f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            AssetManager.terraform.get("lightning_normal").apply_force = false;
            MapBox.spawnLightningMedium(pTile, 0.64f);
    
            return true;
        }

        public static bool MartialGodTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 2. 获取攻击者的序列值
                float xuLieValue = attacker.GetXuLie();
    
                // 3. 计算真实伤害（示例：序列值的500%作为基础伤害）
                float baseDamage = xuLieValue * 5f;
    
                // 4. 添加伤害波动（±10%随机波动）
                float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
                int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
                // 5. 施加真实伤害（无视防御）
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                else
               {
                    // 如果伤害超过目标血量，直接击杀
                    targetActor.restoreHealth(-targetActor.data.health);
                }
            }

            return false;
        }

        public static bool TaiChuTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 2. 获取攻击者的序列值
                float xuLieValue = attacker.GetXuLie();
    
                // 3. 计算真实伤害（示例：序列值的550%作为基础伤害）
                float baseDamage = xuLieValue * 5.5f;
    
                // 4. 添加伤害波动（±10%随机波动）
                float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
                int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
                // 5. 施加真实伤害（无视防御）
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                else
               {
                    // 如果伤害超过目标血量，直接击杀
                    targetActor.restoreHealth(-targetActor.data.health);
                }
            }

            return false;
        }

        public static bool YunXingTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor())
                return false;

            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 获取攻击者当前生命值
            float currentHealth = attacker.data.health;
    
            // 计算真实伤害 = 攻击者生命值的4%
            int trueDamage = (int)(currentHealth / 25);
    
            // 确保至少造成1点伤害
            if (trueDamage < 1) trueDamage = 1;
    
            // 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }
            else
            {
                // 如果伤害超过目标血量，直接击杀
                targetActor.restoreHealth(-targetActor.data.health);
            }

            return true;
        }

        public static bool WanZhanTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor())
                return false;

            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 获取攻击者当前生命值
            float currentHealth = attacker.data.health;
    
            // 计算真实伤害 = 攻击者生命值的5%
            int trueDamage = (int)(currentHealth / 20);
    
            // 确保至少造成1点伤害
            if (trueDamage < 1) trueDamage = 1;
    
            // 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }
            else
            {
                // 如果伤害超过目标血量，直接击杀
                targetActor.restoreHealth(-targetActor.data.health);
            }

            return true;
        }

        public static bool BloodSeaTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                float killCount = attacker.data.kills;
                int trueDamage =  (int)(killCount* 50f); 

                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                else
               {
                    // 如果伤害超过目标血量，直接击杀
                    targetActor.restoreHealth(-targetActor.data.health);
                }
            }
            return false;
        }

        public static bool ArmorBasedTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
        
                // 获取攻击者的防御值（armor属性）
                float armorValue = attacker.stats[strings.S.armor];
        
                // 计算真实伤害 = 防御值 * 100
                int trueDamage = Mathf.RoundToInt(armorValue * 100f);
        
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    // 施加真实伤害（无视护甲/抗性）
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-actualDamage);
                }
            }
            return false; // 允许后续攻击动作继续执行
        }

        public static bool ManLongTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
        
                float healthValue = attacker.stats[strings.S.health];
        
                int trueDamage = Mathf.RoundToInt(healthValue * 0.01f);
        
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    // 施加真实伤害（无视护甲/抗性）
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-actualDamage);
                }
            }
            return false; // 允许后续攻击动作继续执行
        }

        public static bool XingChenTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
        
                float staminaValue = attacker.stats[strings.S.stamina];
        
                int trueDamage = Mathf.RoundToInt(staminaValue * 3f);
        
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    // 施加真实伤害（无视护甲/抗性）
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-actualDamage);
                }
            }
            return false; // 允许后续攻击动作继续执行
        }

        public static bool HunDunTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
        
                float speedValue = attacker.stats[strings.S.speed];
        
                int trueDamage = Mathf.RoundToInt(speedValue * 50f);
        
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    // 施加真实伤害（无视护甲/抗性）
                    int actualDamage = Mathf.Min(trueDamage, targetActor.data.health);
                    targetActor.restoreHealth(-actualDamage);
                }
            }
            return false; // 允许后续攻击动作继续执行
        }

        public static bool MaintainFullNutrition(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor actor = pTarget.a;
                if (actor.hasTrait("XuLie91") || 
                    actor.hasTrait("XuLie92") || 
                    actor.hasTrait("XuLie93"))
                {
                    // 保持饱食度100%
                    actor.data.nutrition = 100;
                }
            }
            return true;
        }      

        public static bool XuLie1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "XuLie2", "XuLie3", "XuLie4", "XuLie5", "XuLie6", "XuLie7", "XuLie8", "XuLie9", "XuLie91", "XuLie92", "XuLie93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "XuLie1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "XuLie1");

            return true;
        }

        public static bool XuLie2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetXuLie() <= 9.99)
            {
                return false;
            }

            a.ChangeXuLie(-2);
            double successRate = 0.8;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "XuLie1",
                "XuLie2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "XuLie22" }
            );
            UpdateNameSuffix(a, "XuLie2");
            ApplyXuLieTitle(a, "XuLie2");

            return true;
        }

        public static bool XuLie3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查序列值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 8)
            {
                // 添加XuLie1特质
                upTrait("特质", "XuLie1", a, new string[] { "XuLie2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 19.99)
            {
                return false;
            }

            a.ChangeXuLie(-2);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "XuLie2",
                "XuLie3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie22"
                },
                new string[] { "XuLie3+", selectedTrait }
            );
            UpdateNameSuffix(a, "XuLie3");
            ApplyXuLieTitle(a, "XuLie3");

            return true;
        }

        public static bool XuLie4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 18)
            {
                upTrait("特质", "XuLie2", a, new string[] { "XuLie3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 39.99)
            {
                return false;
            }

            a.ChangeXuLie(-3);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "XuLie3",
                "XuLie4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie3+"
                },
                new string[] { "XuLie4+" }
            );
            UpdateNameSuffix(a, "XuLie4");
            ApplyXuLieTitle(a, "XuLie4");

    
            return true;
        }

        public static bool XuLie5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 37)
            {
                upTrait("特质", "XuLie3", a, new string[] { "XuLie4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 79.99)
            {
                return false;
            }

            a.ChangeXuLie(-4);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }


            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "XuLie4",
                "XuLie5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie4+"
                },
                (selectedTrait != null) ?
                new string[] { "XuLie5+", selectedTrait } :
                new string[] { "XuLie5+" }
            );
            UpdateNameSuffix(a, "XuLie5");
            ApplyXuLieTitle(a, "XuLie5");

            return true;
        }

        public static bool XuLie6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 76)
            {
                upTrait("特质", "XuLie4", a, new string[] { "XuLie5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 159.99)
            {
                return false;
            }

            a.ChangeXuLie(-5);
            double successRate = 0.1;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "XuLie5",
                "XuLie6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie5+"
                },
                (selectedTrait != null) ?
                new string[] { "XuLie6+", "freeze_proof", "fire_proof", "chaofanXuemai1", selectedTrait } :
                new string[] { "XuLie6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "XuLie6");
            ApplyXuLieTitle(a, "XuLie6");

            return true;
        }

        public static bool XuLie7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 155)
            {
                upTrait("特质", "XuLie6", a, new string[] { "XuLie7" }, new string[] { });
                return true;
            }

            if (a.GetXuLie() <= 299.99)
            {
                return false;
            }

            a.ChangeXuLie(-6);
            double successRate = 0.1;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "XuLie6",
                "XuLie7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie6+", "chaofanXuemai1" },
                new string[] { "XuLie7+", "chaofanXuemai2", "tough" }
            );
            UpdateNameSuffix(a, "XuLie7");
            ApplyXuLieTitle(a, "XuLie7");

            return true;
        }

        public static bool XuLie8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 499.99)
            {
                return false;
            }

            a.ChangeXuLie(-9);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "XuLie7",
                "XuLie8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie7+", "chaofanXuemai2" },
                new string[] { "XuLie8+", "strong_minded", "immune", "chaofanXuemai3" }
            );
            UpdateNameSuffix(a, "XuLie8");
            ApplyXuLieTitle(a, "XuLie8");

            return true;
        }

        public static bool XuLie9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 799.99)
            {
                return false;
            }

            a.ChangeXuLie(-15);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.05; 
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            // 检查是否可以晋升到序列二
            if (!CanPromoteToHighSequence(a, "XuLie9"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie91"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                }
            }
            if (a.hasTrait("XuLie92"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie8",
                "XuLie9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie8+", "chaofanXuemai3" },
                new string[] { "XuLie9+" ,"fire_proof", "regeneration", "chaofanXuemai4"}
            );
            UpdateNameSuffix(a, "XuLie9");
            ApplyXuLieTitle(a, "XuLie9");
            a.data.favorite = true;

            // 更新高序列计数
            string actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie9", 1);
            }
       
            return true;
        }

        public static bool XuLie91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 1199.99)
            {
                return false;
            }

            a.ChangeXuLie(-200);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.3;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            // 检查是否可以晋升到序列一
            if (!CanPromoteToHighSequence(a, "XuLie91"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie9", -1);
                }
            }
            if (a.hasTrait("XuLie92"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie9",
                "XuLie91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie9+", "chaofanXuemai4" },
                new string[] { "XuLie91+", "chaofanXuemai5" }
            );
            UpdateNameSuffix(a, "XuLie91");
            ApplyXuLieTitle(a, "XuLie91");

            // 显示突破通知，参数为角色对象、当前特质(XuLie9)和突破后特质(XuLie91)
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie9", "XuLie91"); // 参数名已更新为 oldTraitId 和 newTraitId，但调用时参数位置不变
            // 将角色标记为收藏状态
            a.data.favorite = true;

            // 更新高序列计数
            string actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie91", 1);
            }

            return true;
        }

        public static bool XuLie92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 3599.99)
            {
                return false;
            }

            a.ChangeXuLie(-200);
            double successRate = 0.06;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.002;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.2;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            // 检查是否可以晋升到天使之王
            if (!CanPromoteToHighSequence(a, "XuLie92"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie9", -1);
                }
            }
            if (a.hasTrait("XuLie91"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie91",
                "XuLie92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie91+", "chaofanXuemai5" },
                new string[] { "XuLie92+", "chaofanXuemai6" }
            );
            List<string> grottoTraitIds = new List<string>
            {
                "WeiYixing1", "WeiYixing2", "WeiYixing3", "WeiYixing4",
                "WeiYixing5", "WeiYixing6", "WeiYixing7", "WeiYixing8",
                "WeiYixing9", "WeiYixing10", "WeiYixing11", "WeiYixing1+",
                "WeiYixing2+", "WeiYixing3+", "WeiYixing4+", "WeiYixing5+",
                "WeiYixing6+", "WeiYixing7+", "WeiYixing8+", "WeiYixing9+",
                "WeiYixing10+", "WeiYixing11+"
            };

            // 根据前缀获得对应唯一性 - XuLie92晋升专用
            string currentName = a.getName();
            int separatorIndex = currentName.IndexOf('|');
            if (separatorIndex > 0)
            {
                string prefix = currentName.Substring(0, separatorIndex).Trim();
                if (_uniquenessMap.TryGetValue(prefix, out string uniquenessTrait))
                {
                    // 检查该唯一性特质是否已被其他角色持有
                    if (!_uniquenessOwners.ContainsKey(uniquenessTrait) || _uniquenessOwners[uniquenessTrait] == a)
                    {
                        // 如果未被持有或持有者是当前角色，则添加唯一性特质
                        a.addTrait(uniquenessTrait);
                        // 记录唯一性特质到角色数据中
                        a.data.set("uniqueness", uniquenessTrait);
                        // 更新唯一性持有者记录
                        _uniquenessOwners[uniquenessTrait] = a;
                        // 显示获得唯一性的通知
                        string uniquenessName = NotificationHelper.GetUniquenessName(uniquenessTrait);
                        NotificationHelper.ShowNotification(a, $"{a.getName()}获得唯一性: {uniquenessName}");
                    }
                    else
                    {
                        // 该唯一性已被其他角色持有，显示通知
                        string uniquenessName = NotificationHelper.GetUniquenessName(uniquenessTrait);
                        NotificationHelper.ShowNotification(a, $"唯一性 {uniquenessName} 已被其他角色持有，无法获得");
                    }
                }
            }
            
            UpdateNameSuffix(a, "XuLie92");
            ApplyXuLieTitle(a, "XuLie92");

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie91", "XuLie92"); // 参数名已更新为 oldTraitId 和 newTraitId，但调用时参数位置不变

            // 更新高序列计数
            string actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie92", 1);
            }

            return true;
        }

        // 定义XuLie92晋升时的唯一性特质映射字典 - WeiYixing系列
        private static readonly Dictionary<string, string> _uniquenessMap = new Dictionary<string, string>
        {
            {"诡秘侍者", "WeiYixing1"},
            {"星之钥", "WeiYixing2"},
            {"时之虫", "WeiYixing3"},
            {"作家", "WeiYixing5"},
            {"雷神", "WeiYixing7"},
            {"纯白天使", "WeiYixing4"},
            {"全知之眼", "WeiYixing6"},
            {"暗天使", "WeiYixing8"},
            {"苍白皇帝", "WeiYixing4+"},
            {"厄难天使", "WeiYixing10"},
            {"神明之手", "WeiYixing11"},
            {"末日魔女", "WeiYixing2+"},
            {"征服者", "WeiYixing1+"},
            {"知识皇帝", "WeiYixing9+"},
            {"启蒙者", "WeiYixing10+"},
            {"水银之蛇", "WeiYixing11+"},
            {"自然行者", "WeiYixing3+"},
            {"美神", "WeiYixing9"},
            {"秩序之手", "WeiYixing6+"},
            {"弑序亲王", "WeiYixing5+"},
            {"神孽", "WeiYixing8+"},
            {"污秽君王", "WeiYixing7+"},
        };

        public static bool XuLie93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetXuLie() <= 9999.99)
            {
                return false;
            }

            a.ChangeXuLie(-300);
            double successRate = 0.02;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.1;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            // 检查角色的途径
            string originalPathway = GetActorPathway(a);
            string pathway = originalPathway;
            if (pathway == null)
            {
                ApplyXuLieTitle(a, "XuLie92"); // 尝试获取途径
                pathway = GetActorPathway(a);
                if (pathway == null)
                {
                    NotificationHelper.ShowNotification(a, "无法确定晋升途径，晋升失败！");
                    return false;
                }
            }

            // 检查是否从相邻途径晋升而来且当前是天使之王
            string currentHighestTrait = GetHighestXuLieTrait(a);
            if (currentHighestTrait == "XuLie92") // 当前是天使之王
            {
                // 检查原始途径与目标途径是否为相邻途径
                if (originalPathway != null && originalPathway != pathway && 
                    _adjacentPathways.ContainsKey(originalPathway) && 
                    _adjacentPathways[originalPathway].Contains(pathway))
                {
                    // 天使之王无法晋升相邻途径真神
                    NotificationHelper.ShowNotification(a, $"{a.getName()}作为天使之王，无法晋升到相邻途径的真神！");
                    return false;
                }
            }

            // 检查该途径是否已有真神
            if (_pathwayHighSequenceCounts.ContainsKey(pathway) && _pathwayHighSequenceCounts[pathway]["XuLie93"] >= 1)
            {
                NotificationHelper.ShowNotification(a, $"[{pathway}]途径已有真神，无法晋升！");
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie9", -1);
            }
            if (a.hasTrait("XuLie91"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie91", -1);
            }
            if (a.hasTrait("XuLie92"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie92", -1);
            }

            upTrait(
                "XuLie92",
                "XuLie93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie92+", "chaofanXuemai6" },
                new string[] { "XuLie93+", "immunity", "chaofanXuemai7" }
            );
            UpdateNameSuffix(a, "XuLie93");
            ApplyXuLieTitle(a, "XuLie93");


            NotificationHelper.ShowBreakthroughNotification(a, "XuLie92", "XuLie93");

            // 更新高序列计数
            UpdateHighSequenceCount(pathway, "XuLie93", 1);

            // 检查是否晋升到了相邻途径，如果是则失去原途径的唯一性
            if (originalPathway != null && originalPathway != pathway && _adjacentPathways.ContainsKey(originalPathway) && _adjacentPathways[originalPathway].Contains(pathway))
            {
                // 检查角色是否持有原途径的唯一性
                string originalUniqueness = null;
                foreach (var kvp in _uniquenessOwners)
                {
                    if (kvp.Value == a)
                    {
                        originalUniqueness = kvp.Key;
                        break;
                    }
                }

                if (originalUniqueness != null && a.hasTrait(originalUniqueness))
                {
                    // 让角色失去原途径的唯一性
                    a.removeTrait(originalUniqueness);
                    a.data.set("uniqueness", null);
                    _uniquenessOwners.Remove(originalUniqueness);
                    string uniquenessName = NotificationHelper.GetUniquenessName(originalUniqueness);
                    NotificationHelper.ShowNotification(a, $"晋升相邻途径，失去唯一性: {uniquenessName}");
                }
            }

            // 自动获得本途径唯一性，原持有者失去唯一性
            string currentName = a.getName();
            int separatorIndex = currentName.IndexOf('|');
            if (separatorIndex > 0)
            {
                string prefix = currentName.Substring(0, separatorIndex).Trim();
                if (_uniquenessMap.TryGetValue(prefix, out string uniquenessTrait))
                {
                    string uniquenessName = NotificationHelper.GetUniquenessName(uniquenessTrait);
                    // 检查当前唯一性持有者
                    if (_uniquenessOwners.ContainsKey(uniquenessTrait))
                    {
                        Actor oldOwner = _uniquenessOwners[uniquenessTrait];
                        if (oldOwner != null && oldOwner != a)
                        {
                            // 让原持有者失去唯一性
                            oldOwner.removeTrait(uniquenessTrait);
                            oldOwner.data.set("uniqueness", null);
                            NotificationHelper.ShowNotification(oldOwner, $"唯一性 {uniquenessName} 被夺走！");
                        }
                    }
                    
                    // 授予真神唯一性
                    a.addTrait(uniquenessTrait);
                    a.data.set("uniqueness", uniquenessTrait);
                    _uniquenessOwners[uniquenessTrait] = a;
                    NotificationHelper.ShowNotification(a, $"获得唯一性: {uniquenessName}");
                }

                // 处理源质获取
                if (_pathwayToSourceQuality.TryGetValue(pathway, out string sourceQuality))
                {
                    // 源质名称映射
                    Dictionary<string, string> sourceQualityNames = new Dictionary<string, string>
                    {
                        {"NineYuanZhi1", "混沌海"},
                        {"NineYuanZhi2", "源堡"},
                        {"NineYuanZhi3", "母巢"},
                        {"NineYuanZhi4", "永暗之河"},
                        {"NineYuanZhi5", "灾祸之城"},
                        {"NineYuanZhi6", "失序之国"},
                        {"NineYuanZhi7", "知识荒野"},
                        {"NineYuanZhi8", "光之钥"},
                        {"NineYuanZhi9", "暗影世界"}
                    };

                    string sourceQualityName = sourceQualityNames.TryGetValue(sourceQuality, out string name) ? name : sourceQuality;

                    // 检查源质是否已被持有
                    if (!_sourceQualityOwners.ContainsKey(sourceQuality))
                    {
                        // 授予源质
                        a.addTrait(sourceQuality);
                        a.data.set("sourceQuality", sourceQuality);
                        _sourceQualityOwners[sourceQuality] = a;
                        NotificationHelper.ShowNotification(a, $"{a.getName()}获得源质: {sourceQualityName}");
                    }
                    else
                    {
                        Actor owner = _sourceQualityOwners[sourceQuality];
                        if (owner != a)
                        {
                            NotificationHelper.ShowNotification(a, $"源质 {sourceQualityName} 已被 {owner.getName()} 持有，无法获取！");
                        }
                    }
                }
            }

            // 当出现真神时，降级该途径所有天使之王和序列一角色
            DemoteHighSequenceActors(pathway);


            return true;
        }

        
        //序列的恢复生命值效果
        public static bool XuLie1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的10%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的20%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的30%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.3f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的40%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.4f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的50%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.5f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的60%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.6f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的70%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.7f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的80%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.8f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的90%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.9f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的100%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的110%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的120%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}