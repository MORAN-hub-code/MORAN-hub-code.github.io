using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using HarmonyLib;
using NeoModLoader.api.attributes;

namespace XuLie.code
{
    internal class MoYaoCrafting
    {
        // 检查指定序列的魔药合成（在晋升时调用）
        public static void CheckMoYaoOnPromotion(Actor actor, string promotionXuLieId)
        {
            try
            {
                if (actor == null || !actor.isAlive())
                    return;

                // 根据晋升的序列特质ID，检查对应的魔药合成
                switch (promotionXuLieId)
                {
                    case "XuLie2":// 晋升序列九
                        // 检查序列九魔药
                        CheckAndCraftMoYao(actor, "MoYao1", "XulieTexing1", "FuzhuCailiao1", "序列九魔药");
                        break;
                    case "XuLie3":// 晋升序列八
                        // 检查序列八魔药
                        CheckAndCraftMoYao(actor, "MoYao2", "XulieTexing2", "FuzhuCailiao2", "序列八魔药");
                        break;
                    case "XuLie4":// 晋升序列七
                        // 检查序列七魔药
                        CheckAndCraftMoYao(actor, "MoYao3", "XulieTexing3", "FuzhuCailiao3", "序列七魔药");
                        break;
                    case "XuLie5":// 晋升序列六
                        // 检查序列六魔药
                        CheckAndCraftMoYao(actor, "MoYao4", "XulieTexing4", "FuzhuCailiao4", "序列六魔药");
                        break;
                    case "XuLie6":// 晋升序列五
                        // 检查序列五魔药
                        CheckAndCraftMoYao(actor, "MoYao5", "XulieTexing5", "FuzhuCailiao5", "序列五魔药");
                        break;
                    case "XuLie7":// 晋升序列四
                        // 检查序列四魔药
                        CheckAndCraftMoYao(actor, "MoYao6", "XulieTexing6", "FuzhuCailiao6", "序列四魔药");
                        break;
                    case "XuLie8":// 晋升序列三
                        // 检查序列三魔药
                        CheckAndCraftMoYao(actor, "MoYao7", "XulieTexing7", "FuzhuCailiao7", "序列三魔药");
                        break;
                    case "XuLie9":// 晋升序列二
                        // 检查序列二魔药
                        CheckAndCraftMoYao(actor, "MoYao8", "XulieTexing8", "FuzhuCailiao8", "序列二魔药");
                        break;
                    case "XuLie91":// 晋升序列一
                        // 检查序列一魔药
                        CheckAndCraftSequenceOneMoYao(actor);
                        break;
                    case "XuLie93":// 晋升真神
                        // 检查序列零魔药
                        CheckAndCraftSequenceZeroMoYao(actor);
                        break;
                }
            }
            catch (Exception e)
            {
                Debug.LogError("晋升时检查魔药制作过程中出现错误: " + e.Message);
            }
        }

        // 检查所有角色是否可以制作魔药（保留原方法以兼容可能的其他调用）
        private static void CheckAllMoYaoCrafting()
        {
            try
            {
                // 获取所有角色
                List<Actor> allActors = World.world.units.getSimpleList();
                foreach (Actor actor in allActors)
                {
                    if (actor == null || !actor.isAlive())
                        continue;

                    // 检查并制作序列九魔药
                    CheckAndCraftMoYao(actor, "MoYao1", "XulieTexing1", "FuzhuCailiao1", "序列九魔药");
                    
                    // 检查并制作序列八魔药
                    CheckAndCraftMoYao(actor, "MoYao2", "XulieTexing2", "FuzhuCailiao2", "序列八魔药");
                    
                    // 检查并制作序列七魔药
                    CheckAndCraftMoYao(actor, "MoYao3", "XulieTexing3", "FuzhuCailiao3", "序列七魔药");
                    
                    // 检查并制作序列六魔药
                    CheckAndCraftMoYao(actor, "MoYao4", "XulieTexing4", "FuzhuCailiao4", "序列六魔药");
                    
                    // 检查并制作序列五魔药
                    CheckAndCraftMoYao(actor, "MoYao5", "XulieTexing5", "FuzhuCailiao5", "序列五魔药");
                    
                    // 检查并制作序列四魔药
                    CheckAndCraftMoYao(actor, "MoYao6", "XulieTexing6", "FuzhuCailiao6", "序列四魔药");
                    
                    // 检查并制作序列三魔药
                    CheckAndCraftMoYao(actor, "MoYao7", "XulieTexing7", "FuzhuCailiao7", "序列三魔药");
                    
                    // 检查并制作序列二魔药
                    CheckAndCraftMoYao(actor, "MoYao8", "XulieTexing8", "FuzhuCailiao8", "序列二魔药");
                    
                    // 检查并制作序列一魔药
                    CheckAndCraftSequenceOneMoYao(actor);
                    
                    // 检查并制作序列零魔药
                    CheckAndCraftSequenceZeroMoYao(actor);
                }
            }
            catch (Exception e)
            {
                // 简单的错误处理，避免程序崩溃
                Debug.LogError("魔药制作检查过程中出现错误: " + e.Message);
            }
        }

        // 获取角色的最高序列特质
        private static string GetHighestXuLieTrait(Actor actor)
        {
            try
            {
                // 按照从高到低的顺序检查序列特质
                // 真神 -> 天使之王 -> 序列一 -> 序列二 -> ... -> 序列九 -> 半超凡
                if (actor.hasTrait("XuLie93")) // 真神
                    return "XuLie93";
                if (actor.hasTrait("XuLie92")) // 天使之王
                    return "XuLie92";
                if (actor.hasTrait("XuLie91")) // 序列一
                    return "XuLie91";
                if (actor.hasTrait("XuLie9"))  // 序列二
                    return "XuLie9";
                if (actor.hasTrait("XuLie8"))  // 序列三
                    return "XuLie8";
                if (actor.hasTrait("XuLie7"))  // 序列四
                    return "XuLie7";
                if (actor.hasTrait("XuLie6"))  // 序列五
                    return "XuLie6";
                if (actor.hasTrait("XuLie5"))  // 序列六
                    return "XuLie5";
                if (actor.hasTrait("XuLie4"))  // 序列七
                    return "XuLie4";
                if (actor.hasTrait("XuLie3"))  // 序列八
                    return "XuLie3";
                if (actor.hasTrait("XuLie2"))  // 序列九
                    return "XuLie2";
                if (actor.hasTrait("XuLie1"))  // 半超凡
                    return "XuLie1";
                
                return null; // 没有序列特质
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        // 检查并制作普通魔药（序列九至序列二）
        private static void CheckAndCraftMoYao(Actor actor, string moYaoId, string sequenceTraitId, string materialTraitId, string moYaoName)
        {
            try
            {
                // 检查角色是否已经有该魔药或者已经制作过
                if (actor.hasTrait(moYaoId) || actor.hasTrait($"{moYaoId}_crafted"))
                {
                    return;
                }

                // 获取角色的最高序列
                string highestXuLie = GetHighestXuLieTrait(actor);
                
                // 根据魔药ID检查角色是否有资格合成该魔药
                bool canCraft = false;
                
                switch (moYaoId)
                {
                    case "MoYao1":// 序列九魔药
                        // 半超凡可以合成序列九魔药
                        canCraft = highestXuLie == "XuLie1";
                        break;
                    case "MoYao2":// 序列八魔药
                        // 序列九可以合成序列八魔药
                        canCraft = highestXuLie == "XuLie2";
                        break;
                    case "MoYao3":// 序列七魔药
                        // 序列八可以合成序列七魔药
                        canCraft = highestXuLie == "XuLie3";
                        break;
                    case "MoYao4":// 序列六魔药
                        // 序列七可以合成序列六魔药
                        canCraft = highestXuLie == "XuLie4";
                        break;
                    case "MoYao5":// 序列五魔药
                        // 序列六可以合成序列五魔药
                        canCraft = highestXuLie == "XuLie5";
                        break;
                    case "MoYao6":// 序列四魔药
                        // 序列五可以合成序列四魔药
                        canCraft = highestXuLie == "XuLie6";
                        break;
                    case "MoYao7":// 序列三魔药
                        // 序列四可以合成序列三魔药
                        canCraft = highestXuLie == "XuLie7";
                        break;
                    case "MoYao8":// 序列二魔药
                        // 序列三可以合成序列二魔药
                        canCraft = highestXuLie == "XuLie8";
                        break;
                    default:
                        canCraft = true; // 默认允许合成
                        break;
                }

                // 检查角色是否拥有序列特性、辅助材料，并且有资格合成该魔药
                if (canCraft && actor.hasTrait(sequenceTraitId) && actor.hasTrait(materialTraitId))
                {
                    // 给予魔药特质
                    actor.addTrait(moYaoId, false);
                    
                    // 添加已制作标记，防止重复制作
                    actor.addTrait($"{moYaoId}_crafted");
                    
                    // 删除使用的材料
                    if (actor.hasTrait(sequenceTraitId))
                        actor.removeTrait(sequenceTraitId);
                    if (actor.hasTrait(materialTraitId))
                        actor.removeTrait(materialTraitId);
                    

                }
            }
            catch (Exception e)
            {
                Debug.LogError($"制作{moYaoName}时出错: " + e.Message);
            }
        }

        // 检查并制作序列一魔药（任意序列一特性+序列一辅助材料）
        private static void CheckAndCraftSequenceOneMoYao(Actor actor)
        {
            const string moYaoId = "MoYao9";
            const string materialTraitId = "FuzhuCailiao9";
            const string moYaoName = "序列一魔药";

            try
            {
                // 检查角色是否已经有该魔药或者已经制作过
                if (actor.hasTrait(moYaoId) || actor.hasTrait($"{moYaoId}_crafted"))
                {
                    return;
                }

                // 获取角色的最高序列
                string highestXuLie = GetHighestXuLieTrait(actor);
                
                // 检查角色是否有资格合成序列一魔药：序列二可以合成序列一魔药
                bool canCraft = highestXuLie == "XuLie9";
                
                // 检查角色是否拥有任意序列一特性、辅助材料，并且有资格合成该魔药
                bool hasSequenceOneTrait = actor.hasTrait("XulieTexing9") || 
                                           actor.hasTrait("XulieTexing91") || 
                                           actor.hasTrait("XulieTexing92");

                if (canCraft && hasSequenceOneTrait && actor.hasTrait(materialTraitId))
                {
                    // 给予魔药特质
                    actor.addTrait(moYaoId, false);
                    
                    // 添加已制作标记，防止重复制作
                    actor.addTrait($"{moYaoId}_crafted");
                    
                    // 删除使用的材料
                    if (actor.hasTrait("XulieTexing9"))
                        actor.removeTrait("XulieTexing9");
                    if (actor.hasTrait("XulieTexing91"))
                        actor.removeTrait("XulieTexing91");
                    if (actor.hasTrait("XulieTexing92"))
                        actor.removeTrait("XulieTexing92");
                    if (actor.hasTrait(materialTraitId))
                        actor.removeTrait(materialTraitId);
                    

                }
            }
            catch (Exception e)
            {
                Debug.LogError($"制作{moYaoName}时出错: " + e.Message);
            }
        }

        // 检查并制作序列零魔药
        private static void CheckAndCraftSequenceZeroMoYao(Actor actor)
        {
            const string moYaoId = "MoYao91";
            const string materialTraitId = "FuzhuCailiao91";
            const string moYaoName = "序列零魔药";

            try
            {
                // 检查角色是否已经有该魔药或者已经制作过
                if (actor.hasTrait(moYaoId) || actor.hasTrait($"{moYaoId}_crafted"))
                {
                    return;
                }

                // 获取角色的最高序列
                string highestXuLie = GetHighestXuLieTrait(actor);
                
                // 检查角色是否有资格合成序列零魔药：天使之王可以合成序列零魔药
                bool canCraft = highestXuLie == "XuLie92";
                
                // 检查角色是否拥有所有必要的材料：序列一特性XulieTexing9+XulieTexing91+XulieTexing92+唯一性+序列零辅助材料
                bool hasAllRequiredTraits = actor.hasTrait("XulieTexing9") &&
                                            actor.hasTrait("XulieTexing91") &&
                                            actor.hasTrait("XulieTexing92") &&
                                            HasUniquenessTrait(actor) &&
                                            actor.hasTrait(materialTraitId);

                if (canCraft && hasAllRequiredTraits)
                {
                    // 给予魔药特质
                    actor.addTrait(moYaoId, false);
                    
                    // 添加已制作标记，防止重复制作
                    actor.addTrait($"{moYaoId}_crafted");
                    
                    // 删除使用的材料
                    if (actor.hasTrait("XulieTexing9"))
                        actor.removeTrait("XulieTexing9");
                    if (actor.hasTrait("XulieTexing91"))
                        actor.removeTrait("XulieTexing91");
                    if (actor.hasTrait("XulieTexing92"))
                        actor.removeTrait("XulieTexing92");
                    if (actor.hasTrait("jinSheng9"))
                        actor.removeTrait("jinSheng9");
                    if (actor.hasTrait("XuLie93"))
                        actor.removeTrait("XuLie93");
                    if (actor.hasTrait(materialTraitId))
                        actor.removeTrait(materialTraitId);
                    

                }
            }
            catch (Exception e)
            {
                Debug.LogError($"制作{moYaoName}时出错: " + e.Message);
            }
        }

        // 检查角色是否拥有唯一性特质
        private static bool HasUniquenessTrait(Actor actor)
        {
            try
            {
                // 唯一性特质通常与高序列相关
                return actor.hasTrait("jinSheng9") || // 假设jinSheng9代表唯一性
                       actor.hasTrait("XuLie93") || // 序列零（真神）可能拥有唯一性
                       // WeiYixing系列特质也是唯一性
                       actor.hasTrait("WeiYixing1") ||
                       actor.hasTrait("WeiYixing2") ||
                       actor.hasTrait("WeiYixing3") ||
                       actor.hasTrait("WeiYixing4") ||
                       actor.hasTrait("WeiYixing5") ||
                       actor.hasTrait("WeiYixing6") ||
                       actor.hasTrait("WeiYixing7") ||
                       actor.hasTrait("WeiYixing8") ||
                       actor.hasTrait("WeiYixing9") ||
                       actor.hasTrait("WeiYixing10") ||
                       actor.hasTrait("WeiYixing11") ||
                       actor.hasTrait("WeiYixing1+") ||
                       actor.hasTrait("WeiYixing2+") ||
                       actor.hasTrait("WeiYixing3+") ||
                       actor.hasTrait("WeiYixing4+") ||
                       actor.hasTrait("WeiYixing5+") ||
                       actor.hasTrait("WeiYixing6+") ||
                       actor.hasTrait("WeiYixing7+") ||
                       actor.hasTrait("WeiYixing8+") ||
                       actor.hasTrait("WeiYixing9+") ||
                       actor.hasTrait("WeiYixing10+") ||
                       actor.hasTrait("WeiYixing11+");
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}