using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using strings;

namespace XuLie.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        public static ActorTrait jinSheng_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait jinSheng = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "JinSheng",
                needs_to_be_explored = false
            };
            jinSheng.action_special_effect += traitAction.XuLie1_effectAction;
            AssetManager.traits.add(jinSheng);
            return jinSheng;
        }
        public static void Init()
        {
            ActorTrait jinSheng4 = jinSheng_AddActorTrait("jinSheng4", "trait/jinSheng4");
            jinSheng4.rarity = Rarity.R2_Epic;

            ActorTrait jinSheng7 = jinSheng_AddActorTrait("jinSheng7", "trait/jinSheng7");
            jinSheng7.rarity = Rarity.R2_Epic;
        
            ActorTrait jinSheng8 = jinSheng_AddActorTrait("jinSheng8", "trait/jinSheng8");
            jinSheng8.rarity = Rarity.R3_Legendary;

            ActorTrait jinSheng1 = jinSheng_AddActorTrait("jinSheng1", "trait/jinSheng1");
            
            ActorTrait jinSheng2 = jinSheng_AddActorTrait("jinSheng2", "trait/jinSheng2");
            
            ActorTrait jinSheng3 = jinSheng_AddActorTrait("jinSheng3", "trait/jinSheng3");

            ActorTrait jinSheng9 = CreateTrait("jinSheng9", "trait/jinSheng9", "JinSheng");
            jinSheng9.rate_inherit = 100;
            AssetManager.traits.add(jinSheng9);

            ActorTrait jinSheng10 = CreateTrait("jinSheng10", "trait/jinSheng10", "JinSheng");
            AssetManager.traits.add(jinSheng10);

            ActorTrait XuLie02 = CreateTrait("XuLie2+", "trait/XuLie2+", "XuLie");
            SafeSetStat(XuLie02.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(XuLie02.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(XuLie02.base_stats, strings.S.loyalty_traits, -1f);
            AssetManager.traits.add(XuLie02);

            ActorTrait XuLie03 = CreateTrait("XuLie3+", "trait/XuLie3+", "XuLie");
            SafeSetStat(XuLie03.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(XuLie03.base_stats, strings.S.skill_combat, 0.2f);
            SafeSetStat(XuLie03.base_stats, strings.S.loyalty_traits, -5f);
            AssetManager.traits.add(XuLie03);

            ActorTrait XuLie04 = CreateTrait("XuLie4+", "trait/XuLie4+", "XuLie");
            SafeSetStat(XuLie04.base_stats , strings.S.lifespan, 30f);
            SafeSetStat(XuLie04.base_stats , strings.S.skill_combat, 0.3f);
            SafeSetStat(XuLie04.base_stats, strings.S.loyalty_traits, -10f);
            AssetManager.traits.add(XuLie04);

            ActorTrait XuLie05 = CreateTrait("XuLie5+", "trait/XuLie5+", "XuLie");
            SafeSetStat(XuLie05.base_stats , strings.S.lifespan, 50f);
            SafeSetStat(XuLie05.base_stats , strings.S.skill_combat, 0.4f);
            SafeSetStat(XuLie05.base_stats, strings.S.loyalty_traits, -20f);
            AssetManager.traits.add(XuLie05);

            ActorTrait XuLie06 = CreateTrait("XuLie6+", "trait/XuLie6+", "XuLie");
            SafeSetStat(XuLie06.base_stats , strings.S.lifespan, 80f);
            SafeSetStat(XuLie06.base_stats , strings.S.skill_combat, 0.5f);
            SafeSetStat(XuLie06.base_stats, strings.S.loyalty_traits, -30f);
            AssetManager.traits.add(XuLie06);

            ActorTrait XuLie07 = CreateTrait("XuLie7+", "trait/XuLie7+", "XuLie");
            SafeSetStat(XuLie07.base_stats, strings.S.lifespan, 200f);
            SafeSetStat(XuLie07.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(XuLie07.base_stats, strings.S.loyalty_traits, -40f);
            // 每年增加50点心情
            XuLie07.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie07);

            ActorTrait XuLie08 = CreateTrait("XuLie8+", "trait/XuLie8+", "XuLie");
            SafeSetStat(XuLie08.base_stats, strings.S.lifespan, 350f);
            SafeSetStat(XuLie08.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(XuLie08.base_stats, strings.S.loyalty_traits, -60f);
            // 每年增加50点心情
            XuLie08.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie08);

            ActorTrait XuLie09 = CreateTrait("XuLie9+", "trait/XuLie9+", "XuLie");
            SafeSetStat(XuLie09.base_stats, strings.S.lifespan, 500f);
            SafeSetStat(XuLie09.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(XuLie09.base_stats, strings.S.loyalty_traits, -80f);
            // 每年增加50点心情
            XuLie09.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie09);

            ActorTrait XuLie091 = CreateTrait("XuLie91+", "trait/XuLie91+", "XuLie");
            SafeSetStat(XuLie091.base_stats, strings.S.lifespan, 1000f);
            SafeSetStat(XuLie091.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(XuLie091.base_stats, strings.S.loyalty_traits, -120f);
            // 每年增加50点心情
            XuLie091.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie091);

            ActorTrait XuLie092 = CreateTrait("XuLie92+", "trait/XuLie92+", "XuLie");
            SafeSetStat(XuLie092.base_stats, strings.S.lifespan, 1500f);
            SafeSetStat(XuLie092.base_stats, strings.S.skill_combat, 0.7f);
            SafeSetStat(XuLie092.base_stats, strings.S.loyalty_traits, -300f);
            // 每年增加50点心情
            XuLie092.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie092);

            ActorTrait XuLie093 = CreateTrait("XuLie93+", "trait/XuLie93+", "XuLie");
            SafeSetStat(XuLie093.base_stats, strings.S.lifespan, 10000f);
            SafeSetStat(XuLie093.base_stats, strings.S.skill_combat, 0.8f);
            SafeSetStat(XuLie093.base_stats, strings.S.loyalty_traits, -500f);
            // 每年增加50点心情
            XuLie093.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie093);

            ActorTrait XuLie094 = CreateTrait("XuLie94+", "trait/XuLie94+", "XuLie");
            SafeSetStat(XuLie094.base_stats, strings.S.lifespan, 100000f);
            SafeSetStat(XuLie094.base_stats, strings.S.skill_combat, 0.9f);
            SafeSetStat(XuLie094.base_stats, strings.S.loyalty_traits, -1000f);
            // 每年增加50点心情
            XuLie094.action_special_effect += traitAction.XuLie7_HappinessBoost;
            AssetManager.traits.add(XuLie094);

            ActorTrait XuLie1 = CreateTrait("XuLie1", "trait/XuLie1", "XuLie");
            SafeSetStat(XuLie1.base_stats, stats.Resist.id, 0.5f);
            SafeSetStat(XuLie1.base_stats, strings.S.damage, 60f);
            SafeSetStat(XuLie1.base_stats, strings.S.mass, 5.0f);
            SafeSetStat(XuLie1.base_stats, strings.S.health, 200f);
            SafeSetStat(XuLie1.base_stats, strings.S.stamina, 10f);
            SafeSetStat(XuLie1.base_stats, "Dodge", 120f);
            SafeSetStat(XuLie1.base_stats, "Accuracy", 110f);
            XuLie1.action_special_effect += traitAction.XuLie2_effectAction;
            XuLie1.action_special_effect += traitAction.XuLie1_Regen;
            // 添加购买序列九特性和辅助材料的方法
            XuLie1.action_special_effect += traitAction.BuyXulieTexing1;
            XuLie1.action_special_effect += traitAction.BuyFuzhuCailiao1;
            AssetManager.traits.add(XuLie1);

            ActorTrait XuLie2 = CreateTrait("XuLie2", "trait/XuLie2", "XuLie");
            SafeSetStat(XuLie2.base_stats, stats.Resist.id, 1.0f);
            SafeSetStat(XuLie2.base_stats , strings.S.damage, 120f);
            SafeSetStat(XuLie2.base_stats, strings.S.mass, 10f);
            SafeSetStat(XuLie2.base_stats , strings.S.health, 500f);
            SafeSetStat(XuLie2.base_stats , strings.S.accuracy, 2f);
            SafeSetStat(XuLie2.base_stats , strings.S.multiplier_speed, 0.1f);
            SafeSetStat(XuLie2.base_stats , strings.S.stamina, 20f);
            SafeSetStat(XuLie2.base_stats, "Dodge", 130f);
            SafeSetStat(XuLie2.base_stats, "Accuracy", 110f);
            XuLie2.action_special_effect += traitAction.XuLie3_effectAction;
            XuLie2.action_special_effect += traitAction.XuLie2_Regen;
            // 添加购买序列八特性和辅助材料的方法
            XuLie2.action_special_effect += traitAction.BuyXulieTexing2;
            XuLie2.action_special_effect += traitAction.BuyFuzhuCailiao2;
            // 序列九，造成1倍灵性真实伤害
            XuLie2.action_attack_target += traitAction.TrueDamageByLingXing1_AttackAction;
            AssetManager.traits.add(XuLie2);

            ActorTrait XuLie3 = CreateTrait("XuLie3", "trait/XuLie3", "XuLie");
            SafeSetStat(XuLie3.base_stats, stats.Resist.id, 2.0f);  
            SafeSetStat(XuLie3.base_stats , strings.S.damage, 240f);
            SafeSetStat(XuLie3.base_stats, strings.S.mass, 10f);
            SafeSetStat(XuLie3.base_stats , strings.S.health, 1000f);
            SafeSetStat(XuLie3.base_stats , strings.S.armor, 5f);
            SafeSetStat(XuLie3.base_stats , strings.S.targets, 0.1f);
            SafeSetStat(XuLie3.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(XuLie3.base_stats , strings.S.multiplier_speed, 0.2f);
            SafeSetStat(XuLie3.base_stats , strings.S.stamina, 30f);
            SafeSetStat(XuLie3.base_stats, "Dodge", 140f);
            SafeSetStat(XuLie3.base_stats, "Accuracy", 110f);
            XuLie3.action_special_effect += traitAction.XuLie4_effectAction;
            XuLie3.action_special_effect += traitAction.XuLie3_Regen;
            // 添加购买序列七特性和辅助材料的方法
            XuLie3.action_special_effect += traitAction.BuyXulieTexing3;
            XuLie3.action_special_effect += traitAction.BuyFuzhuCailiao3;
            // 序列八，造成1倍灵性真实伤害
            XuLie3.action_attack_target += traitAction.TrueDamageByLingXing1_AttackAction;
            AssetManager.traits.add(XuLie3);

            ActorTrait XuLie4 = CreateTrait("XuLie4", "trait/XuLie4", "XuLie");
            SafeSetStat(XuLie4.base_stats, stats.Resist.id, 4.0f);
            SafeSetStat(XuLie4.base_stats , strings.S.damage, 480f);
            SafeSetStat(XuLie4.base_stats, strings.S.mass, 10f);
            SafeSetStat(XuLie4.base_stats , strings.S.health, 5000f);
            SafeSetStat(XuLie4.base_stats , strings.S.speed, 5f);
            SafeSetStat(XuLie4.base_stats , strings.S.armor, 10f);
            SafeSetStat(XuLie4.base_stats , strings.S.targets, 1f); 
            SafeSetStat(XuLie4.base_stats , strings.S.critical_chance, 0.2f);
            // 添加购买序列六特性和辅助材料的方法
            XuLie4.action_special_effect += traitAction.BuyXulieTexing4;
            XuLie4.action_special_effect += traitAction.BuyFuzhuCailiao4;
            SafeSetStat(XuLie4.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(XuLie4.base_stats , strings.S.multiplier_speed, 0.3f);
            SafeSetStat(XuLie4.base_stats , strings.S.stamina, 40f);
            SafeSetStat(XuLie4.base_stats, "Dodge", 150f);
            SafeSetStat(XuLie4.base_stats, "Accuracy", 110f);
            XuLie4.action_special_effect += traitAction.XuLie5_effectAction;
            XuLie4.action_special_effect += traitAction.XuLie4_Regen;
            // 序列七，造成1倍灵性真实伤害
            XuLie4.action_attack_target += traitAction.TrueDamageByLingXing1_AttackAction;
            AssetManager.traits.add(XuLie4);

            ActorTrait XuLie5 = CreateTrait("XuLie5", "trait/XuLie5", "XuLie");
            SafeSetStat(XuLie5.base_stats, stats.Resist.id, 8.0f);
            SafeSetStat(XuLie5.base_stats , strings.S.warfare, 10f);
            SafeSetStat(XuLie5.base_stats, strings.S.mass, 15f);
            SafeSetStat(XuLie5.base_stats , strings.S.damage, 1000f);
            SafeSetStat(XuLie5.base_stats , strings.S.health, 10000f);
            SafeSetStat(XuLie5.base_stats , strings.S.speed, 10f);
            SafeSetStat(XuLie5.base_stats , strings.S.armor, 15f);
            SafeSetStat(XuLie5.base_stats , strings.S.targets, 2f);
            SafeSetStat(XuLie5.base_stats , strings.S.critical_chance, 0.3f);
            SafeSetStat(XuLie5.base_stats , strings.S.accuracy, 20f);
            SafeSetStat(XuLie5.base_stats , strings.S.multiplier_speed, 0.4f);
            SafeSetStat(XuLie5.base_stats , strings.S.stamina, 50f);
            SafeSetStat(XuLie5.base_stats, "Dodge", 180f);
            SafeSetStat(XuLie5.base_stats, "Accuracy", 140f);
            XuLie5.action_special_effect += traitAction.XuLie6_effectAction;
            XuLie5.action_special_effect += traitAction.XuLie5_Regen;
            // 添加购买序列五特性和辅助材料的方法
            XuLie5.action_special_effect += traitAction.BuyXulieTexing5;
            XuLie5.action_special_effect += traitAction.BuyFuzhuCailiao5;
            // 序列六，造成1倍灵性真实伤害
            XuLie5.action_attack_target += traitAction.TrueDamageByLingXing1_AttackAction;
            AssetManager.traits.add(XuLie5);

            ActorTrait XuLie6 = CreateTrait("XuLie6", "trait/XuLie6", "XuLie");
            XuLie6.rarity = Rarity.R2_Epic;
            SafeSetStat(XuLie6.base_stats, stats.Resist.id, 16.0f);
            SafeSetStat(XuLie6.base_stats , strings.S.warfare, 20f);
            SafeSetStat(XuLie6.base_stats, strings.S.mass, 20f);
            SafeSetStat(XuLie6.base_stats , strings.S.damage, 5000f);
            SafeSetStat(XuLie6.base_stats , strings.S.armor, 25f);
            SafeSetStat(XuLie6.base_stats , strings.S.health, 50000f);
            SafeSetStat(XuLie6.base_stats , strings.S.speed, 15f);
            SafeSetStat(XuLie6.base_stats , strings.S.area_of_effect, 1f);
            SafeSetStat(XuLie6.base_stats , strings.S.targets, 5f);
            SafeSetStat(XuLie6.base_stats , strings.S.critical_chance, 0.5f);
            SafeSetStat(XuLie6.base_stats , strings.S.accuracy, 30f);
            SafeSetStat(XuLie6.base_stats , strings.S.multiplier_speed, 0.6f);
            SafeSetStat(XuLie6.base_stats , strings.S.stamina, 70f);
            SafeSetStat(XuLie6.base_stats, "Dodge", 200f);
            SafeSetStat(XuLie6.base_stats, "Accuracy", 160f);
            XuLie6.action_special_effect += traitAction.XuLie7_effectAction;
            XuLie6.action_special_effect += traitAction.XuLie6_Regen;
            // 添加购买序列四特性和辅助材料的方法
            XuLie6.action_special_effect += traitAction.BuyXulieTexing6;
            XuLie6.action_special_effect += traitAction.BuyFuzhuCailiao6;
            // 移除原真实伤害，添加1倍灵性真实伤害
            XuLie6.action_attack_target -= traitAction.TrueDamage1_AttackAction;
            XuLie6.action_attack_target += traitAction.TrueDamageByLingXing1_AttackAction;
            AssetManager.traits.add(XuLie6);

            ActorTrait XuLie7 = CreateTrait("XuLie7", "trait/XuLie7", "XuLie");
            XuLie7.rarity = Rarity.R2_Epic;
            SafeSetStat(XuLie7.base_stats, stats.Resist.id, 32.0f);
            SafeSetStat(XuLie7.base_stats, strings.S.warfare, 30f);
            SafeSetStat(XuLie7.base_stats, strings.S.damage, 10000f);
            SafeSetStat(XuLie7.base_stats, strings.S.mass, 25f);
            SafeSetStat(XuLie7.base_stats, strings.S.armor, 35f);
            SafeSetStat(XuLie7.base_stats, strings.S.health, 100000f);
            SafeSetStat(XuLie7.base_stats, strings.S.speed, 20f);
            SafeSetStat(XuLie7.base_stats, strings.S.area_of_effect, 2f);
            SafeSetStat(XuLie7.base_stats, strings.S.targets, 7f);
            SafeSetStat(XuLie7.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(XuLie7.base_stats, strings.S.accuracy, 40f);
            SafeSetStat(XuLie7.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(XuLie7.base_stats, strings.S.stamina, 140f);
            SafeSetStat(XuLie7.base_stats, strings.S.range, 2f);
            SafeSetStat(XuLie7.base_stats, strings.S.attack_speed, 2f);
            SafeSetStat(XuLie7.base_stats, strings.S.scale, 0.04f);
            SafeSetStat(XuLie7.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(XuLie7.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(XuLie7.base_stats, "Dodge", 220f);
            SafeSetStat(XuLie7.base_stats, "Accuracy", 180f);
            // 移除原真实伤害，添加10倍灵性真实伤害
            XuLie7.action_attack_target -= traitAction.TrueDamage2_AttackAction;
            XuLie7.action_attack_target += traitAction.TrueDamageByLingXing10_AttackAction;
            XuLie7.action_special_effect += traitAction.XuLie8_effectAction;
            XuLie7.action_special_effect += traitAction.XuLie7_Regen;
            // 添加购买序列三特性和辅助材料的方法
            XuLie7.action_special_effect += traitAction.BuyXulieTexing7;
            XuLie7.action_special_effect += traitAction.BuyFuzhuCailiao7;
            AssetManager.traits.add(XuLie7);

            ActorTrait XuLie8 = CreateTrait("XuLie8", "trait/XuLie8", "XuLie");
            XuLie8.rarity = Rarity.R2_Epic;
            SafeSetStat(XuLie8.base_stats, stats.Resist.id, 64.0f);
            SafeSetStat(XuLie8.base_stats, strings.S.warfare, 40f);
            SafeSetStat(XuLie8.base_stats, strings.S.damage, 50000f);
            SafeSetStat(XuLie8.base_stats, strings.S.mass, 60f);
            SafeSetStat(XuLie8.base_stats, strings.S.armor, 45f);
            SafeSetStat(XuLie8.base_stats, strings.S.health, 500000f);
            SafeSetStat(XuLie8.base_stats, strings.S.speed, 25f);
            SafeSetStat(XuLie8.base_stats, strings.S.area_of_effect, 3f);
            SafeSetStat(XuLie8.base_stats, strings.S.targets, 9f);
            SafeSetStat(XuLie8.base_stats, strings.S.critical_chance, 0.7f);
            SafeSetStat(XuLie8.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(XuLie8.base_stats, strings.S.multiplier_speed, 1.0f);
            SafeSetStat(XuLie8.base_stats, strings.S.stamina, 240f);
            SafeSetStat(XuLie8.base_stats, strings.S.range, 4f);
            SafeSetStat(XuLie8.base_stats, strings.S.attack_speed, 4f);
            SafeSetStat(XuLie8.base_stats, strings.S.multiplier_health, 0.4f);
            SafeSetStat(XuLie8.base_stats, strings.S.multiplier_damage, 0.4f);
            SafeSetStat(XuLie8.base_stats, strings.S.scale, 0.06f);
            SafeSetStat(XuLie8.base_stats, "Dodge", 260f);
            SafeSetStat(XuLie8.base_stats, "Accuracy", 220f);
            // 移除原真实伤害，添加10倍灵性真实伤害
            XuLie8.action_attack_target -= traitAction.TrueDamage3_AttackAction;
            XuLie8.action_attack_target += traitAction.TrueDamageByLingXing10_AttackAction;
            XuLie8.action_special_effect += traitAction.XuLie9_effectAction;
            XuLie8.action_special_effect += traitAction.XuLie8_Regen;
            // 添加购买序列二特性和辅助材料的方法
            XuLie8.action_special_effect += traitAction.BuyXulieTexing8;
            XuLie8.action_special_effect += traitAction.BuyFuzhuCailiao8;
            AssetManager.traits.add(XuLie8);

            ActorTrait XuLie9 = CreateTrait("XuLie9", "trait/XuLie9", "XuLie");
            XuLie9.rarity = Rarity.R2_Epic;
            SafeSetStat(XuLie9.base_stats, stats.Resist.id, 128.0f);
            SafeSetStat(XuLie9.base_stats, strings.S.warfare, 50f);
            SafeSetStat(XuLie9.base_stats, strings.S.damage, 100000f);
            SafeSetStat(XuLie9.base_stats, strings.S.mass, 140f);
            SafeSetStat(XuLie9.base_stats, strings.S.armor, 60f);
            SafeSetStat(XuLie9.base_stats, strings.S.health, 1000000f);
            SafeSetStat(XuLie9.base_stats, strings.S.speed, 30f);
            SafeSetStat(XuLie9.base_stats, strings.S.area_of_effect, 4f);
            SafeSetStat(XuLie9.base_stats, strings.S.targets, 12f);
            SafeSetStat(XuLie9.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(XuLie9.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(XuLie9.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(XuLie9.base_stats, strings.S.stamina, 400f);
            SafeSetStat(XuLie9.base_stats, strings.S.range, 6f);
            SafeSetStat(XuLie9.base_stats, strings.S.attack_speed, 6f);
            SafeSetStat(XuLie9.base_stats, strings.S.scale, 0.08f); 
            SafeSetStat(XuLie9.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(XuLie9.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(XuLie9.base_stats, "Dodge", 300f);
            SafeSetStat(XuLie9.base_stats, "Accuracy", 260f);
            // 移除原真实伤害，添加100倍灵性真实伤害
            XuLie9.action_attack_target -= traitAction.TrueDamage4_AttackAction;
            XuLie9.action_attack_target += traitAction.TrueDamageByLingXing100_AttackAction;
            XuLie9.action_special_effect += traitAction.XuLie91_effectAction;
            XuLie9.action_special_effect += traitAction.XuLie9_Regen;
            // 添加购买序列一特性和辅助材料的方法
            XuLie9.action_special_effect += traitAction.BuyXulieTexing9;
            XuLie9.action_special_effect += traitAction.BuyFuzhuCailiao9;
            AssetManager.traits.add(XuLie9);    

            ActorTrait XuLie91 = CreateTrait("XuLie91", "trait/XuLie91", "XuLie");
            XuLie91.rarity = Rarity.R3_Legendary;
            SafeSetStat(XuLie91.base_stats, stats.Resist.id, 160.0f);
            SafeSetStat(XuLie91.base_stats, strings.S.warfare, 70f);
            SafeSetStat(XuLie91.base_stats, strings.S.damage, 300000f);
            SafeSetStat(XuLie91.base_stats, strings.S.mass, 400f);
            SafeSetStat(XuLie91.base_stats, strings.S.armor, 80f);
            SafeSetStat(XuLie91.base_stats, strings.S.health, 3000000f);
            SafeSetStat(XuLie91.base_stats, strings.S.speed, 50f);
            SafeSetStat(XuLie91.base_stats, strings.S.area_of_effect, 5f);
            SafeSetStat(XuLie91.base_stats, strings.S.targets, 15f);
            SafeSetStat(XuLie91.base_stats, strings.S.critical_chance, 0.9f);
            SafeSetStat(XuLie91.base_stats, strings.S.accuracy, 80f);
            SafeSetStat(XuLie91.base_stats, strings.S.multiplier_speed, 1.5f);
            SafeSetStat(XuLie91.base_stats, strings.S.stamina, 600f);
            SafeSetStat(XuLie91.base_stats, strings.S.range, 12f);
            SafeSetStat(XuLie91.base_stats, strings.S.attack_speed, 12f);
            SafeSetStat(XuLie91.base_stats, strings.S.scale, 0.1f);
            SafeSetStat(XuLie91.base_stats, strings.S.multiplier_health, 1.2f);
            SafeSetStat(XuLie91.base_stats, strings.S.multiplier_damage, 1.2f);
            SafeSetStat(XuLie91.base_stats, "Dodge", 340f);
            SafeSetStat(XuLie91.base_stats, "Accuracy", 300f);
            XuLie91.action_special_effect += traitAction.XuLie92_effectAction;
            XuLie91.action_special_effect += traitAction.XuLie91_Regen;
            // 移除原真实伤害，添加100倍灵性真实伤害
            XuLie91.action_attack_target -= traitAction.TrueDamage5_AttackAction;
            XuLie91.action_attack_target += traitAction.TrueDamageByLingXing100_AttackAction;
            XuLie91.action_attack_target += traitAction.fire1_attackAction;
            XuLie91.action_attack_target += traitAction.TrueDamageByXuLie1_AttackAction;
            XuLie91.action_special_effect += traitAction.MaintainFullNutrition;
            // 添加序列一的特殊购买方法
            XuLie91.action_special_effect += traitAction.BuyUniqueness;
            XuLie91.action_special_effect += traitAction.BuyOtherSequenceOneTrait;
            AssetManager.traits.add(XuLie91);

            ActorTrait XuLie92 = CreateTrait("XuLie92", "trait/XuLie92", "XuLie");
            XuLie92.rarity = Rarity.R3_Legendary;
            SafeSetStat(XuLie92.base_stats, stats.Resist.id, 200.0f);
            SafeSetStat(XuLie92.base_stats, strings.S.warfare, 100f);
            SafeSetStat(XuLie92.base_stats, strings.S.damage, 600000f);
            SafeSetStat(XuLie92.base_stats, strings.S.mass, 1600f);
            SafeSetStat(XuLie92.base_stats, strings.S.armor, 100f);
            SafeSetStat(XuLie92.base_stats, strings.S.health, 6000000f);
            SafeSetStat(XuLie92.base_stats, strings.S.speed, 100f);
            SafeSetStat(XuLie92.base_stats, strings.S.area_of_effect, 7f);
            SafeSetStat(XuLie92.base_stats, strings.S.targets, 20f);
            SafeSetStat(XuLie92.base_stats, strings.S.critical_chance, 1.0f);
            SafeSetStat(XuLie92.base_stats, strings.S.accuracy, 100f);
            SafeSetStat(XuLie92.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(XuLie92.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(XuLie92.base_stats, strings.S.range, 20f);
            SafeSetStat(XuLie92.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(XuLie92.base_stats, strings.S.scale, 0.15f);
            SafeSetStat(XuLie92.base_stats, strings.S.multiplier_health, 2f);
            SafeSetStat(XuLie92.base_stats, strings.S.multiplier_damage, 2f);
            SafeSetStat(XuLie92.base_stats, "Dodge", 380f);
            SafeSetStat(XuLie92.base_stats, "Accuracy", 340f);
            XuLie92.action_special_effect += traitAction.XuLie93_effectAction;
            XuLie92.action_special_effect += traitAction.XuLie92_Regen;
            XuLie92.action_attack_target += traitAction.TrueDamage6_AttackAction;
            XuLie92.action_attack_target += traitAction.fire1_attackAction;
            XuLie92.action_attack_target += traitAction.TrueDamageByXuLie2_AttackAction;
            XuLie92.action_special_effect += traitAction.MaintainFullNutrition;
            XuLie92.action_special_effect += traitAction.BuyFuzhuCailiao91;
            XuLie92.action_special_effect += traitAction.BuyOtherSequenceOneTrait;
            AssetManager.traits.add(XuLie92);

            ActorTrait XuLie93 = CreateTrait("XuLie93", "trait/XuLie93", "XuLie");
            XuLie93.rarity = Rarity.R3_Legendary;
            SafeSetStat(XuLie93.base_stats, stats.Resist.id, 240.0f);
            SafeSetStat(XuLie93.base_stats, strings.S.warfare, 160f);
            SafeSetStat(XuLie93.base_stats, strings.S.damage, 1000000f);
            SafeSetStat(XuLie93.base_stats, strings.S.mass, 2400f);
            SafeSetStat(XuLie93.base_stats, strings.S.armor, 160f);
            SafeSetStat(XuLie93.base_stats, strings.S.health, 10000000f);
            SafeSetStat(XuLie93.base_stats, strings.S.speed, 300f);    
            SafeSetStat(XuLie93.base_stats, strings.S.area_of_effect, 10f);
            SafeSetStat(XuLie93.base_stats, strings.S.targets, 25f);
            SafeSetStat(XuLie93.base_stats, strings.S.critical_chance, 1.5f);
            SafeSetStat(XuLie93.base_stats, strings.S.accuracy, 160f);
            SafeSetStat(XuLie93.base_stats, strings.S.multiplier_speed, 3.0f);
            SafeSetStat(XuLie93.base_stats, strings.S.stamina, 10000f);
            SafeSetStat(XuLie93.base_stats, strings.S.range, 30f);
            SafeSetStat(XuLie93.base_stats, strings.S.attack_speed, 30f);
            SafeSetStat(XuLie93.base_stats, strings.S.scale, 0.2f);
            SafeSetStat(XuLie93.base_stats, strings.S.multiplier_health, 3f);
            SafeSetStat(XuLie93.base_stats, strings.S.multiplier_damage, 3f);    
            SafeSetStat(XuLie93.base_stats, "Dodge", 500f);
            SafeSetStat(XuLie93.base_stats, "Accuracy", 480f);
            XuLie93.action_special_effect += traitAction.XuLie94_effectAction;
            XuLie93.action_special_effect += traitAction.XuLie93_Regen;
            // 移除原真实伤害，添加1000倍灵性真实伤害
            XuLie93.action_attack_target -= traitAction.TrueDamage7_AttackAction;
            XuLie93.action_attack_target += traitAction.TrueDamageByLingXing1000_AttackAction;
            XuLie93.action_attack_target += traitAction.fire2_attackAction;
            XuLie93.action_attack_target += traitAction.TrueDamageByXuLie3_AttackAction;
            XuLie93.action_special_effect += traitAction.MaintainFullNutrition;
            AssetManager.traits.add(XuLie93);

            ActorTrait XuLie94 = CreateTrait("XuLie94", "trait/XuLie94", "XuLie");
            XuLie94.rarity = Rarity.R3_Legendary;
            SafeSetStat(XuLie94.base_stats, stats.Resist.id, 480.0f);
            SafeSetStat(XuLie94.base_stats, strings.S.warfare, 320f);
            SafeSetStat(XuLie94.base_stats, strings.S.damage, 3000000f);
            SafeSetStat(XuLie94.base_stats, strings.S.mass, 4800f);
            SafeSetStat(XuLie94.base_stats, strings.S.armor, 320f);
            SafeSetStat(XuLie94.base_stats, strings.S.health, 30000000f);
            SafeSetStat(XuLie94.base_stats, strings.S.speed, 300f);    
            SafeSetStat(XuLie94.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(XuLie94.base_stats, strings.S.targets, 50f);
            SafeSetStat(XuLie94.base_stats, strings.S.critical_chance, 3.0f);
            SafeSetStat(XuLie94.base_stats, strings.S.accuracy, 320f);
            SafeSetStat(XuLie94.base_stats, strings.S.multiplier_speed, 6.0f);
            SafeSetStat(XuLie94.base_stats, strings.S.stamina, 20000f);
            SafeSetStat(XuLie94.base_stats, strings.S.range, 60f);
            SafeSetStat(XuLie94.base_stats, strings.S.attack_speed, 60f);
            SafeSetStat(XuLie94.base_stats, strings.S.scale, 0.4f);
            SafeSetStat(XuLie94.base_stats, strings.S.multiplier_health, 6f);
            SafeSetStat(XuLie94.base_stats, strings.S.multiplier_damage, 6f);    
            SafeSetStat(XuLie94.base_stats, "Dodge", 1000f);
            SafeSetStat(XuLie94.base_stats, "Accuracy", 960f);
            XuLie94.action_special_effect += traitAction.XuLie93_Regen;
            // 移除原真实伤害，添加3000倍灵性真实伤害
            XuLie94.action_attack_target -= traitAction.TrueDamage7_AttackAction;
            XuLie94.action_attack_target += traitAction.TrueDamageByLingXing3000_AttackAction;
            XuLie94.action_attack_target += traitAction.fire2_attackAction;
            XuLie94.action_attack_target += traitAction.TrueDamageByXuLie3_AttackAction;
            XuLie94.action_special_effect += traitAction.MaintainFullNutrition;
            // 添加旧日晋升效果
            XuLie94.action_special_effect += traitAction.XuLie94_effectAction;
            AssetManager.traits.add(XuLie94);

            ActorTrait NineYuanZhi1 = CreateTrait("NineYuanZhi1", "trait/NineYuanZhi1", "NineYuanZhi");
            NineYuanZhi1.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi1.base_stats, strings.S.multiplier_health, 3.0f);
            SafeSetStat(NineYuanZhi1.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineYuanZhi1.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineYuanZhi1.base_stats, strings.S.area_of_effect, 4f);
            NineYuanZhi1.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi1);

            ActorTrait NineYuanZhi2 = CreateTrait("NineYuanZhi2", "trait/NineYuanZhi2", "NineYuanZhi");
            NineYuanZhi2.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.multiplier_damage, 1.8f);
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.multiplier_health, 1.8f);
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.multiplier_speed, 1.8f);
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.intelligence, 100f);
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.area_of_effect, 8f);
            NineYuanZhi2.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi2);

            ActorTrait NineYuanZhi3 = CreateTrait("NineYuanZhi3", "trait/NineYuanZhi3", "NineYuanZhi");
            NineYuanZhi3.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi3.base_stats, strings.S.multiplier_speed, 3.2f);
            SafeSetStat(NineYuanZhi2.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineYuanZhi3.base_stats, strings.S.intelligence, 50f);
            SafeSetStat(NineYuanZhi3.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineYuanZhi3.base_stats, strings.S.area_of_effect, 6f);
            NineYuanZhi3.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi3);

            ActorTrait NineYuanZhi4 = CreateTrait("NineYuanZhi4", "trait/NineYuanZhi4", "NineYuanZhi");
            NineYuanZhi4.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.multiplier_health, 1.0f);
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.knockback, 5f); 
            SafeSetStat(NineYuanZhi4.base_stats, strings.S.area_of_effect, 4f);
            NineYuanZhi4.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi4);

            ActorTrait NineYuanZhi5 = CreateTrait("NineYuanZhi5", "trait/NineYuanZhi5", "NineYuanZhi");
            NineYuanZhi5.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.intelligence, 60f);
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineYuanZhi5.base_stats, strings.S.area_of_effect, 8f);
            NineYuanZhi5.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi5);

            ActorTrait NineYuanZhi6 = CreateTrait("NineYuanZhi6", "trait/NineYuanZhi6", "NineYuanZhi");
            NineYuanZhi6.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.multiplier_damage, 2.0f);
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineYuanZhi6.base_stats, strings.S.area_of_effect, 10f);
            NineYuanZhi6.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi6);

            ActorTrait NineYuanZhi7 = CreateTrait("NineYuanZhi7", "trait/NineYuanZhi7", "NineYuanZhi");
            NineYuanZhi7.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.intelligence, 20f);
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineYuanZhi7.base_stats, strings.S.area_of_effect, 6f);
            NineYuanZhi7.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi7);

            ActorTrait NineYuanZhi8 = CreateTrait("NineYuanZhi8", "trait/NineYuanZhi8", "NineYuanZhi");
            NineYuanZhi8.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.multiplier_speed, 0.9f);
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.multiplier_damage, 0.9f);
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.multiplier_health, 0.9f);
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.intelligence, 1000f);
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.knockback, 100f); 
            SafeSetStat(NineYuanZhi8.base_stats, strings.S.area_of_effect, 100f);
            NineYuanZhi8.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi8);

            ActorTrait NineYuanZhi9 = CreateTrait("NineYuanZhi9", "trait/NineYuanZhi9", "NineYuanZhi");
            NineYuanZhi9.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.multiplier_damage, 2.0f);
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.intelligence, 500f);
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.knockback, 50f); 
            SafeSetStat(NineYuanZhi9.base_stats, strings.S.area_of_effect, 50f);
            NineYuanZhi9.action_attack_target += traitAction.TrueDamageByNineYuanZhi_AttackAction;
            AssetManager.traits.add(NineYuanZhi9);

            ActorTrait yizhiYoncun = CreateTrait("yizhiYoncun", "trait/yizhiYoncun", "JinSheng");
        AssetManager.traits.add(yizhiYoncun);

            // 定义五个等级的血脉特质
            ActorTrait chaofanXuemai1 = CreateTrait("chaofanXuemai1", "trait/chaofanXuemai1", "ChaofanXuemai");
            chaofanXuemai1.rate_inherit = 10;
            SafeSetStat(chaofanXuemai1.base_stats, strings.S.multiplier_health, 0.01f);
            SafeSetStat(chaofanXuemai1.base_stats, strings.S.multiplier_damage, 0.01f);
            SafeSetStat(chaofanXuemai1.base_stats, strings.S.lifespan, 5f);
            AssetManager.traits.add(chaofanXuemai1);

            ActorTrait chaofanXuemai2 = CreateTrait("chaofanXuemai2", "trait/chaofanXuemai2", "ChaofanXuemai");
            chaofanXuemai2.rate_inherit = 10;
            SafeSetStat(chaofanXuemai2.base_stats, strings.S.multiplier_health, 0.05f);
            SafeSetStat(chaofanXuemai2.base_stats, strings.S.multiplier_damage, 0.05f);
            SafeSetStat(chaofanXuemai2.base_stats, strings.S.lifespan, 10f);
            AssetManager.traits.add(chaofanXuemai2);

            ActorTrait chaofanXuemai3 = CreateTrait("chaofanXuemai3", "trait/chaofanXuemai3", "ChaofanXuemai");
            chaofanXuemai3.rate_inherit = 9; 
            SafeSetStat(chaofanXuemai3.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(chaofanXuemai3.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(chaofanXuemai3.base_stats, strings.S.lifespan, 15f);
            AssetManager.traits.add(chaofanXuemai3);

            ActorTrait chaofanXuemai4 = CreateTrait("chaofanXuemai4", "trait/chaofanXuemai4", "ChaofanXuemai");
            chaofanXuemai4.rarity = Rarity.R2_Epic;
            chaofanXuemai4.rate_inherit = 8;
            SafeSetStat(chaofanXuemai4.base_stats, strings.S.multiplier_health, 0.15f);
            SafeSetStat(chaofanXuemai4.base_stats, strings.S.multiplier_damage, 0.15f);
            SafeSetStat(chaofanXuemai4.base_stats, strings.S.lifespan, 20f);
            AssetManager.traits.add(chaofanXuemai4);

            ActorTrait chaofanXuemai5 = CreateTrait("chaofanXuemai5", "trait/chaofanXuemai5", "ChaofanXuemai");
            chaofanXuemai5.rarity = Rarity.R2_Epic;
            chaofanXuemai5.rate_inherit = 7; 
            SafeSetStat(chaofanXuemai5.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(chaofanXuemai5.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(chaofanXuemai5.base_stats, strings.S.lifespan, 30f);
            AssetManager.traits.add(chaofanXuemai5);

            ActorTrait chaofanXuemai6 = CreateTrait("chaofanXuemai6", "trait/chaofanXuemai6", "ChaofanXuemai");
            chaofanXuemai6.rarity = Rarity.R3_Legendary;
            chaofanXuemai6.rate_inherit = 6; 
            SafeSetStat(chaofanXuemai6.base_stats, strings.S.multiplier_health, 0.25f);
            SafeSetStat(chaofanXuemai6.base_stats, strings.S.multiplier_damage, 0.25f);
            SafeSetStat(chaofanXuemai6.base_stats, strings.S.lifespan, 50f);
            AssetManager.traits.add(chaofanXuemai6);

            ActorTrait chaofanXuemai7 = CreateTrait("chaofanXuemai7", "trait/chaofanXuemai7", "ChaofanXuemai");
            chaofanXuemai7.rarity = Rarity.R3_Legendary;
            chaofanXuemai7.rate_inherit = 5; 
            SafeSetStat(chaofanXuemai7.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(chaofanXuemai7.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(chaofanXuemai7.base_stats, strings.S.lifespan, 100f);
            AssetManager.traits.add(chaofanXuemai7);

            ActorTrait weiYixing1 = CreateTrait("WeiYixing1", "trait/WeiYixing1", "WeiYixing");
            weiYixing1.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing1.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(weiYixing1.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(weiYixing1.base_stats, strings.S.intelligence, 100f);
            SafeSetStat(weiYixing1.base_stats, strings.S.lifespan, 180f);
            SafeSetStat(weiYixing1.base_stats, strings.S.stamina, 300f);
            SafeSetStat(weiYixing1.base_stats, strings.S.area_of_effect, 16f);
            SafeSetStat(weiYixing1.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(weiYixing1.base_stats, strings.S.targets, 10f);
            SafeSetStat(weiYixing1.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(weiYixing1.base_stats, "Accuracy", 50f);
            SafeSetStat(weiYixing1.base_stats, "Dodge", 50f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing1.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing1.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing1);

            ActorTrait weiYixing2 = CreateTrait("WeiYixing2", "trait/WeiYixing2", "WeiYixing");
            weiYixing2.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing2.base_stats, strings.S.multiplier_damage, 0.7f);
            SafeSetStat(weiYixing2.base_stats, strings.S.multiplier_health, 0.9f);
            SafeSetStat(weiYixing2.base_stats, strings.S.intelligence, 40f);
            SafeSetStat(weiYixing2.base_stats, strings.S.lifespan, 120f);
            SafeSetStat(weiYixing2.base_stats, strings.S.stamina, 200f);
            SafeSetStat(weiYixing2.base_stats, strings.S.area_of_effect, 28f);
            SafeSetStat(weiYixing2.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(weiYixing2.base_stats, strings.S.targets, 15f);
            SafeSetStat(weiYixing2.base_stats, strings.S.accuracy, 40f);
            SafeSetStat(weiYixing2.base_stats, "Accuracy", 40f);
            SafeSetStat(weiYixing2.base_stats, "Dodge", 60f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing2.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing2.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing2);

            ActorTrait weiYixing3 = CreateTrait("WeiYixing3", "trait/WeiYixing3", "WeiYixing");
            weiYixing3.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing3.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(weiYixing3.base_stats, strings.S.multiplier_health, 0.4f);
            SafeSetStat(weiYixing3.base_stats, strings.S.intelligence, 120f);
            SafeSetStat(weiYixing3.base_stats, strings.S.lifespan, 150f);
            SafeSetStat(weiYixing3.base_stats, strings.S.stamina, 240f);
            SafeSetStat(weiYixing3.base_stats, strings.S.area_of_effect, 12f);
            SafeSetStat(weiYixing3.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(weiYixing3.base_stats, strings.S.targets, 8f);
            SafeSetStat(weiYixing3.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(weiYixing3.base_stats, "Accuracy", 60f);
            SafeSetStat(weiYixing3.base_stats, "Dodge", 40f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing3.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing3.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing3);

            ActorTrait weiYixing4 = CreateTrait("WeiYixing4", "trait/WeiYixing4", "WeiYixing");
            weiYixing4.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing4.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing4.base_stats, strings.S.multiplier_health, 0.36f);
            SafeSetStat(weiYixing4.base_stats, strings.S.intelligence, 60f);
            SafeSetStat(weiYixing4.base_stats, strings.S.lifespan, 140f);
            SafeSetStat(weiYixing4.base_stats, strings.S.stamina, 240f);
            SafeSetStat(weiYixing4.base_stats, strings.S.area_of_effect, 12f);
            SafeSetStat(weiYixing4.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(weiYixing4.base_stats, strings.S.targets, 15f);
            SafeSetStat(weiYixing4.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(weiYixing4.base_stats, "Accuracy", 70f);
            SafeSetStat(weiYixing4.base_stats, "Dodge", 30f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing4.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing4.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing4);

            ActorTrait weiYixing5 = CreateTrait("WeiYixing5", "trait/WeiYixing5", "WeiYixing");
            weiYixing5.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing5.base_stats, strings.S.multiplier_damage, 0.98f);
            SafeSetStat(weiYixing5.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(weiYixing5.base_stats, strings.S.intelligence, 260f);
            SafeSetStat(weiYixing5.base_stats, strings.S.lifespan, 140f);
            SafeSetStat(weiYixing5.base_stats, strings.S.stamina, 40f);
            SafeSetStat(weiYixing5.base_stats, strings.S.area_of_effect, 8f);
            SafeSetStat(weiYixing5.base_stats, strings.S.critical_chance, 0.1f);
            SafeSetStat(weiYixing5.base_stats, strings.S.targets, 10f);
            SafeSetStat(weiYixing5.base_stats, strings.S.accuracy, 20f);
            SafeSetStat(weiYixing5.base_stats, strings.S.targets, 20f);
            SafeSetStat(weiYixing5.base_stats, strings.S.accuracy, 45f);
            SafeSetStat(weiYixing5.base_stats, "Accuracy", 80f);
            SafeSetStat(weiYixing5.base_stats, "Dodge", 20f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing5.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing5.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing5);

            ActorTrait weiYixing6 = CreateTrait("WeiYixing6", "trait/WeiYixing6", "WeiYixing");
            weiYixing6.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing6.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(weiYixing6.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(weiYixing6.base_stats, strings.S.intelligence, 20f);
            SafeSetStat(weiYixing6.base_stats, strings.S.lifespan, 200f);
            SafeSetStat(weiYixing6.base_stats, strings.S.stamina, 240f);
            SafeSetStat(weiYixing6.base_stats, strings.S.area_of_effect, 22f);
            SafeSetStat(weiYixing6.base_stats, strings.S.critical_chance, 0.4f);
            SafeSetStat(weiYixing6.base_stats, strings.S.targets, 15f);
            SafeSetStat(weiYixing6.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(weiYixing6.base_stats, "Accuracy", 90f);
            SafeSetStat(weiYixing6.base_stats, "Dodge", 10f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing6.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing6.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing6);

            ActorTrait weiYixing7 = CreateTrait("WeiYixing7", "trait/WeiYixing7", "WeiYixing");
            weiYixing7.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing7.base_stats, strings.S.multiplier_health, 0.36f);
            SafeSetStat(weiYixing7.base_stats, strings.S.multiplier_damage, 0.48f);
            SafeSetStat(weiYixing7.base_stats, strings.S.intelligence, 320f);
            SafeSetStat(weiYixing7.base_stats, strings.S.lifespan, 160f);
            SafeSetStat(weiYixing7.base_stats, strings.S.stamina, 500f);
            SafeSetStat(weiYixing7.base_stats, strings.S.area_of_effect, 30f);
            SafeSetStat(weiYixing7.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(weiYixing7.base_stats, strings.S.targets, 24f);
            SafeSetStat(weiYixing7.base_stats, strings.S.accuracy, 64f);
            SafeSetStat(weiYixing7.base_stats, "Accuracy", 40f);
            SafeSetStat(weiYixing7.base_stats, "Dodge", 60f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing7.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing7.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing7);

            ActorTrait weiYixing8 = CreateTrait("WeiYixing8", "trait/WeiYixing8", "WeiYixing");
            weiYixing8.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing8.base_stats, strings.S.multiplier_health, 0.56f);
            SafeSetStat(weiYixing8.base_stats, strings.S.multiplier_damage, 0.5f);
            SafeSetStat(weiYixing8.base_stats, strings.S.intelligence, 120f);
            SafeSetStat(weiYixing8.base_stats, strings.S.lifespan, 200f);
            SafeSetStat(weiYixing8.base_stats, strings.S.stamina, 300f);
            SafeSetStat(weiYixing8.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(weiYixing8.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(weiYixing8.base_stats, strings.S.targets, 25f);
            SafeSetStat(weiYixing8.base_stats, strings.S.accuracy, 70f);
            SafeSetStat(weiYixing8.base_stats, "Accuracy", 30f);
            SafeSetStat(weiYixing8.base_stats, "Dodge", 70f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing8.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing8.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing8);

            ActorTrait weiYixing9 = CreateTrait("WeiYixing9", "trait/WeiYixing9", "WeiYixing");
            weiYixing9.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing9.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(weiYixing9.base_stats, strings.S.multiplier_damage, 0.36f);
            SafeSetStat(weiYixing9.base_stats, strings.S.intelligence, 108f);
            SafeSetStat(weiYixing9.base_stats, strings.S.lifespan, 125f);
            SafeSetStat(weiYixing9.base_stats, strings.S.stamina, 225f);
            SafeSetStat(weiYixing9.base_stats, strings.S.area_of_effect, 32f);
            SafeSetStat(weiYixing9.base_stats, strings.S.critical_chance, 0.36f);
            SafeSetStat(weiYixing9.base_stats, strings.S.targets, 72f);
            SafeSetStat(weiYixing9.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(weiYixing9.base_stats, "Accuracy", 20f);
            SafeSetStat(weiYixing9.base_stats, "Dodge", 80f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing9.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing9.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing9);

            ActorTrait weiYixing10 = CreateTrait("WeiYixing10", "trait/WeiYixing10", "WeiYixing");
            weiYixing10.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing10.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(weiYixing10.base_stats, strings.S.multiplier_health, 0.7f);
            SafeSetStat(weiYixing10.base_stats, strings.S.intelligence, 130f);
            SafeSetStat(weiYixing10.base_stats, strings.S.lifespan, 160f);
            SafeSetStat(weiYixing10.base_stats, strings.S.stamina, 500f);
            SafeSetStat(weiYixing10.base_stats, strings.S.area_of_effect, 38f);
            SafeSetStat(weiYixing10.base_stats, strings.S.critical_chance, 0.24f);
            SafeSetStat(weiYixing10.base_stats, strings.S.targets, 49f);
            SafeSetStat(weiYixing10.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(weiYixing10.base_stats, "Accuracy", 10f);
            SafeSetStat(weiYixing10.base_stats, "Dodge", 90f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing10.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing10.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing10);

            ActorTrait weiYixing11 = CreateTrait("WeiYixing11", "trait/WeiYixing11", "WeiYixing");
            weiYixing11.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing11.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing11.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(weiYixing11.base_stats, strings.S.intelligence, 90f);
            SafeSetStat(weiYixing11.base_stats, strings.S.lifespan, 180f);
            SafeSetStat(weiYixing11.base_stats, strings.S.stamina, 160f);
            SafeSetStat(weiYixing11.base_stats, strings.S.area_of_effect, 29f);
            SafeSetStat(weiYixing11.base_stats, strings.S.critical_chance, 0.64f);
            SafeSetStat(weiYixing11.base_stats, strings.S.targets, 20f);
            SafeSetStat(weiYixing11.base_stats, strings.S.accuracy, 99f);
            SafeSetStat(weiYixing11.base_stats, "Accuracy", 55f);
            SafeSetStat(weiYixing11.base_stats, "Dodge", 45f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing11.base_stats, strings.S.multiplier_attack_speed, 2.0f);
            weiYixing11.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing11);

            ActorTrait weiYixing01 = CreateTrait("WeiYixing1+", "trait/WeiYixing1+", "WeiYixing");
            weiYixing01.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing01.base_stats, strings.S.multiplier_damage, 0.64f);
            SafeSetStat(weiYixing01.base_stats, strings.S.multiplier_health, 0.64f);
            SafeSetStat(weiYixing01.base_stats, strings.S.intelligence, 121f);
            SafeSetStat(weiYixing01.base_stats, strings.S.lifespan, 199f);
            SafeSetStat(weiYixing01.base_stats, strings.S.stamina, 250f);
            SafeSetStat(weiYixing01.base_stats, strings.S.area_of_effect, 60f);
            SafeSetStat(weiYixing01.base_stats, strings.S.critical_chance, 0.11f);
            SafeSetStat(weiYixing01.base_stats, strings.S.targets, 100f);
            SafeSetStat(weiYixing01.base_stats, strings.S.accuracy, 99f);
            SafeSetStat(weiYixing01.base_stats, "Accuracy", 65f);
            SafeSetStat(weiYixing01.base_stats, "Dodge", 50f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing01.base_stats, strings.S.multiplier_attack_speed, 3.0f);
            weiYixing01.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing01);

            ActorTrait weiYixing02 = CreateTrait("WeiYixing2+", "trait/WeiYixing2+", "WeiYixing");
            weiYixing02.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing02.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing02.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(weiYixing02.base_stats, strings.S.intelligence, 81f);
            SafeSetStat(weiYixing02.base_stats, strings.S.lifespan, 125f);
            SafeSetStat(weiYixing02.base_stats, strings.S.stamina, 144f);
            SafeSetStat(weiYixing02.base_stats, strings.S.area_of_effect, 32f);
            SafeSetStat(weiYixing02.base_stats, strings.S.critical_chance, 0.49f);
            SafeSetStat(weiYixing02.base_stats, strings.S.targets, 14f);
            SafeSetStat(weiYixing02.base_stats, strings.S.accuracy, 49f);
            SafeSetStat(weiYixing02.base_stats, "Accuracy", 75f);
            SafeSetStat(weiYixing02.base_stats, "Dodge", 60f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing02.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing02.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing02);

            ActorTrait weiYixing03 = CreateTrait("WeiYixing3+", "trait/WeiYixing3+", "WeiYixing");
            weiYixing03.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing03.base_stats, strings.S.multiplier_damage, 0.88f);
            SafeSetStat(weiYixing03.base_stats, strings.S.multiplier_health, 0.88f);
            SafeSetStat(weiYixing03.base_stats, strings.S.intelligence, 188f);
            SafeSetStat(weiYixing03.base_stats, strings.S.lifespan, 188f);
            SafeSetStat(weiYixing03.base_stats, strings.S.stamina, 188f);
            SafeSetStat(weiYixing03.base_stats, strings.S.area_of_effect, 36f);
            SafeSetStat(weiYixing03.base_stats, strings.S.critical_chance, 0.18f);
            SafeSetStat(weiYixing03.base_stats, strings.S.targets, 18f);
            SafeSetStat(weiYixing03.base_stats, strings.S.accuracy, 88f);
            SafeSetStat(weiYixing03.base_stats, "Accuracy", 85f);
            SafeSetStat(weiYixing03.base_stats, "Dodge", 40f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing03.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing03.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing03);

            ActorTrait weiYixing04 = CreateTrait("WeiYixing4+", "trait/WeiYixing4+", "WeiYixing");
            weiYixing04.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing04.base_stats, strings.S.multiplier_damage, 1.1f);
            SafeSetStat(weiYixing04.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(weiYixing04.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(weiYixing04.base_stats, strings.S.lifespan, 99f);
            SafeSetStat(weiYixing04.base_stats, strings.S.stamina, 399f);
            SafeSetStat(weiYixing04.base_stats, strings.S.area_of_effect, 18f);
            SafeSetStat(weiYixing04.base_stats, strings.S.critical_chance, 0.9f);
            SafeSetStat(weiYixing04.base_stats, strings.S.targets, 19f);
            SafeSetStat(weiYixing04.base_stats, strings.S.accuracy, 99f);
            SafeSetStat(weiYixing04.base_stats, "Accuracy", 45f);
            SafeSetStat(weiYixing04.base_stats, "Dodge", 30f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing04.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing04.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing04);

            ActorTrait weiYixing05 = CreateTrait("WeiYixing5+", "trait/WeiYixing5+", "WeiYixing");
            weiYixing05.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing05.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing05.base_stats, strings.S.multiplier_health, 0.68f);
            SafeSetStat(weiYixing05.base_stats, strings.S.intelligence, 88f);
            SafeSetStat(weiYixing05.base_stats, strings.S.lifespan, 175f);
            SafeSetStat(weiYixing05.base_stats, strings.S.stamina, 550f);
            SafeSetStat(weiYixing05.base_stats, strings.S.area_of_effect, 96f);
            SafeSetStat(weiYixing05.base_stats, strings.S.critical_chance, 0.64f);
            SafeSetStat(weiYixing05.base_stats, strings.S.targets, 49f);
            SafeSetStat(weiYixing05.base_stats, strings.S.accuracy, 36f);
            SafeSetStat(weiYixing05.base_stats, "Accuracy", 35f);
            SafeSetStat(weiYixing05.base_stats, "Dodge", 20f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing05.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing05.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing05);

            ActorTrait weiYixing06 = CreateTrait("WeiYixing6+", "trait/WeiYixing6+", "WeiYixing");
            weiYixing06.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing06.base_stats, strings.S.multiplier_damage, 0.5f);
            SafeSetStat(weiYixing06.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(weiYixing06.base_stats, strings.S.intelligence, 150f);
            SafeSetStat(weiYixing06.base_stats, strings.S.lifespan, 170f);
            SafeSetStat(weiYixing06.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(weiYixing06.base_stats, strings.S.area_of_effect, 72f);
            SafeSetStat(weiYixing06.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(weiYixing06.base_stats, strings.S.targets, 20f);
            SafeSetStat(weiYixing06.base_stats, strings.S.accuracy, 64f);
            SafeSetStat(weiYixing06.base_stats, "Accuracy", 25f);
            SafeSetStat(weiYixing06.base_stats, "Dodge", 10f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing06.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing06.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing06);

            ActorTrait weiYixing07 = CreateTrait("WeiYixing7+", "trait/WeiYixing7+", "WeiYixing");
            weiYixing07.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing07.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing07.base_stats, strings.S.multiplier_health, 0.36f);
            SafeSetStat(weiYixing07.base_stats, strings.S.intelligence, 81f);
            SafeSetStat(weiYixing07.base_stats, strings.S.lifespan, 190f);
            SafeSetStat(weiYixing07.base_stats, strings.S.stamina, 1080f);
            SafeSetStat(weiYixing07.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(weiYixing07.base_stats, strings.S.critical_chance, 0.45f);
            SafeSetStat(weiYixing07.base_stats, strings.S.targets, 99f);
            SafeSetStat(weiYixing07.base_stats, strings.S.accuracy, 56f);
            SafeSetStat(weiYixing07.base_stats, "Accuracy", 15f);
            SafeSetStat(weiYixing07.base_stats, "Dodge", 60f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing07.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing07.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing07);

            // 添加WeiYixing8+到WeiYixing11+ (使用WeiYixing1.png作为临时图标)
            ActorTrait weiYixing08 = CreateTrait("WeiYixing8+", "trait/WeiYixing8+", "WeiYixing");
            weiYixing08.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing08.base_stats, strings.S.multiplier_damage, 0.72f);
            SafeSetStat(weiYixing08.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(weiYixing08.base_stats, strings.S.intelligence, 90f);
            SafeSetStat(weiYixing08.base_stats, strings.S.lifespan, 180f);
            SafeSetStat(weiYixing08.base_stats, strings.S.stamina, 800f);
            SafeSetStat(weiYixing08.base_stats, strings.S.area_of_effect, 30f);
            SafeSetStat(weiYixing08.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(weiYixing08.base_stats, strings.S.targets, 25f);
            SafeSetStat(weiYixing08.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(weiYixing08.base_stats, "Accuracy", 25f);
            SafeSetStat(weiYixing08.base_stats, "Dodge", 70f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing08.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing08.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing08);

            ActorTrait weiYixing09 = CreateTrait("WeiYixing9+", "trait/WeiYixing9+", "WeiYixing");
            weiYixing09.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing09.base_stats, strings.S.multiplier_damage, 0.64f);
            SafeSetStat(weiYixing09.base_stats, strings.S.multiplier_health, 0.64f);
            SafeSetStat(weiYixing09.base_stats, strings.S.intelligence, 120f);
            SafeSetStat(weiYixing09.base_stats, strings.S.lifespan, 200f);
            SafeSetStat(weiYixing09.base_stats, strings.S.stamina, 600f);
            SafeSetStat(weiYixing09.base_stats, strings.S.area_of_effect, 40f);
            SafeSetStat(weiYixing09.base_stats, strings.S.critical_chance, 0.4f);
            SafeSetStat(weiYixing09.base_stats, strings.S.targets, 30f);
            SafeSetStat(weiYixing09.base_stats, strings.S.accuracy, 70f);
            SafeSetStat(weiYixing09.base_stats, "Accuracy", 35f);
            SafeSetStat(weiYixing09.base_stats, "Dodge", 65f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing09.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing09.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing09);

            ActorTrait weiYixing091 = CreateTrait("WeiYixing10+", "trait/WeiYixing10+", "WeiYixing");
            weiYixing091.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing091.base_stats, strings.S.multiplier_damage, 0.56f);
            SafeSetStat(weiYixing091.base_stats, strings.S.multiplier_health, 0.56f);
            SafeSetStat(weiYixing091.base_stats, strings.S.intelligence, 140f);
            SafeSetStat(weiYixing091.base_stats, strings.S.lifespan, 190f);
            SafeSetStat(weiYixing091.base_stats, strings.S.stamina, 700f);
            SafeSetStat(weiYixing091.base_stats, strings.S.area_of_effect, 50f);
            SafeSetStat(weiYixing091.base_stats, strings.S.critical_chance, 0.45f);
            SafeSetStat(weiYixing091.base_stats, strings.S.targets, 35f);
            SafeSetStat(weiYixing091.base_stats, strings.S.accuracy, 65f);
            SafeSetStat(weiYixing091.base_stats, "Accuracy", 45f);
            SafeSetStat(weiYixing091.base_stats, "Dodge", 55f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing091.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing091.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing091);

            ActorTrait weiYixing092 = CreateTrait("WeiYixing11+", "trait/WeiYixing11+", "WeiYixing");
            weiYixing092.rarity = Rarity.R3_Legendary;
            SafeSetStat(weiYixing092.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(weiYixing092.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(weiYixing092.base_stats, strings.S.intelligence, 110f);
            SafeSetStat(weiYixing092.base_stats, strings.S.lifespan, 185f);
            SafeSetStat(weiYixing092.base_stats, strings.S.stamina, 750f);
            SafeSetStat(weiYixing092.base_stats, strings.S.area_of_effect, 36f);
            SafeSetStat(weiYixing092.base_stats, strings.S.critical_chance, 0.55f);
            SafeSetStat(weiYixing092.base_stats, strings.S.targets, 28f);
            SafeSetStat(weiYixing092.base_stats, strings.S.accuracy, 75f);
            SafeSetStat(weiYixing092.base_stats, "Accuracy", 30f);
            SafeSetStat(weiYixing092.base_stats, "Dodge", 70f);
            // 添加攻击速度加成，使攻击速度更快
            SafeSetStat(weiYixing092.base_stats, strings.S.multiplier_attack_speed, 2.5f);
            weiYixing092.action_attack_target += traitAction.TrueDamageByWeiYixing_AttackAction;
            AssetManager.traits.add(weiYixing092);
            
            // 添加TeXing系列特质（基础版）
            for (int i = 1; i <= 11; i++)
            {
                string id = i < 10 ? $"TeXing{i}" : $"TeXing{i}";
                string displayId = $"TeXing{i}";
                ActorTrait texing = CreateTrait(id, $"trait/{displayId}", "TeXing");
                SafeSetStat(texing.base_stats, strings.S.multiplier_damage, 0.1f);
                SafeSetStat(texing.base_stats, strings.S.multiplier_health, 0.1f);
                AssetManager.traits.add(texing);
            }
            
            // 添加TeXing系列特质（+版本）
            for (int i = 1; i <= 11; i++)
            {
                string id = i < 10 ? $"TeXing{i}+": $"TeXing{i}+";
                string displayId = $"TeXing{i}+";
                ActorTrait texingPlus = CreateTrait(id, $"trait/{displayId}", "TeXing");
                SafeSetStat(texingPlus.base_stats, strings.S.multiplier_damage, 0.1f);
                SafeSetStat(texingPlus.base_stats, strings.S.multiplier_health, 0.1f);
                AssetManager.traits.add(texingPlus);
            }

            // 添加魔药MoYao系列特质
            for (int i = 1; i <= 9; i++)
            {
                string id = $"MoYao{i}";
                string displayId = $"MoYao{i}";
                ActorTrait moyao = CreateTrait(id, $"trait/{displayId}", "MoYao");
                // 魔药本身没有属性加成
                // 序列四魔药开始是Rarity.R2_Epic品质
                if (i >= 6) // MoYao6到MoYao9对应序列四及以上
                {
                    moyao.rarity = Rarity.R2_Epic;
                }
                // 序列二魔药开始是Rarity.R3_Legendary品质
                if (i >= 8) // MoYao8到MoYao9对应序列二及以上
                {
                    moyao.rarity = Rarity.R3_Legendary;
                }
                // 添加对应的效果方法
                switch (i)
                {
                    case 1: moyao.action_special_effect += traitAction.MoYao1_effectAction; break;
                    case 2: moyao.action_special_effect += traitAction.MoYao2_effectAction; break;
                    case 3: moyao.action_special_effect += traitAction.MoYao3_effectAction; break;
                    case 4: moyao.action_special_effect += traitAction.MoYao4_effectAction; break;
                    case 5: moyao.action_special_effect += traitAction.MoYao5_effectAction; break;
                    case 6: moyao.action_special_effect += traitAction.MoYao6_effectAction; break;
                    case 7: moyao.action_special_effect += traitAction.MoYao7_effectAction; break;
                    case 8: moyao.action_special_effect += traitAction.MoYao8_effectAction; break;
                    case 9: moyao.action_special_effect += traitAction.MoYao9_effectAction; break;
                }
                AssetManager.traits.add(moyao);
            }
            
            // 添加MoYao91特质（序列零魔药）
            ActorTrait moyao91 = CreateTrait("MoYao91", "trait/MoYao91", "MoYao");
            // 序列零魔药是Rarity.R3_Legendary品质
            moyao91.rarity = Rarity.R3_Legendary;
            // 魔药本身没有属性加成
            // 添加对应的效果方法
            moyao91.action_special_effect += traitAction.MoYao91_effectAction;
            AssetManager.traits.add(moyao91);

            // 添加GuimiShenfen系列特质
            // 平民
            ActorTrait GuimiShenfen1 = CreateTrait("GuimiShenfen1", "trait/GuimiShenfen1", "GuimiShenfen");
            GuimiShenfen1.action_special_effect += traitAction.GuimiShenfen1_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen1);
            
            // 卷毛狒狒
            ActorTrait GuimiShenfen1Plus = CreateTrait("GuimiShenfen1+", "trait/GuimiShenfen1+", "GuimiShenfen");
            GuimiShenfen1Plus.rarity = Rarity.R2_Epic;
            GuimiShenfen1Plus.action_special_effect += traitAction.GuimiShenfenPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen1Plus);
            
            // zf高层
            ActorTrait GuimiShenfen1PlusPlus = CreateTrait("GuimiShenfen1++", "trait/GuimiShenfen1++", "GuimiShenfen");
            GuimiShenfen1PlusPlus.rarity = Rarity.R3_Legendary;
            GuimiShenfen1PlusPlus.action_special_effect += traitAction.GuimiShenfenPlusPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen1PlusPlus);
            
            // 神职人员
            ActorTrait GuimiShenfen2 = CreateTrait("GuimiShenfen2", "trait/GuimiShenfen2", "GuimiShenfen");
            GuimiShenfen2.action_special_effect += traitAction.GuimiShenfen2_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen2);
            
            // 特殊小队
            ActorTrait GuimiShenfen2Plus = CreateTrait("GuimiShenfen2+", "trait/GuimiShenfen2+", "GuimiShenfen");
            GuimiShenfen2Plus.rarity = Rarity.R2_Epic;
            GuimiShenfen2Plus.action_special_effect += traitAction.GuimiShenfenPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen2Plus);
            
            // jh高层
            ActorTrait GuimiShenfen2PlusPlus = CreateTrait("GuimiShenfen2++", "trait/GuimiShenfen2++", "GuimiShenfen");
            GuimiShenfen2PlusPlus.rarity = Rarity.R3_Legendary;
            GuimiShenfen2PlusPlus.action_special_effect += traitAction.GuimiShenfenPlusPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen2PlusPlus);
            
            // 海盗
            ActorTrait GuimiShenfen3 = CreateTrait("GuimiShenfen3", "trait/GuimiShenfen3", "GuimiShenfen");
            GuimiShenfen3.action_special_effect += traitAction.GuimiShenfen3_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen3);
            
            // 海盗将军
            ActorTrait GuimiShenfen3Plus = CreateTrait("GuimiShenfen3+", "trait/GuimiShenfen3+", "GuimiShenfen");
            GuimiShenfen3Plus.rarity = Rarity.R2_Epic;
            GuimiShenfen3Plus.action_special_effect += traitAction.GuimiShenfenPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen3Plus);
            
            // 海盗王者
            ActorTrait GuimiShenfen3PlusPlus = CreateTrait("GuimiShenfen3++", "trait/GuimiShenfen3++", "GuimiShenfen");
            GuimiShenfen3PlusPlus.rarity = Rarity.R3_Legendary;
            GuimiShenfen3PlusPlus.action_special_effect += traitAction.GuimiShenfenPlusPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen3PlusPlus);
            
            // 侦探
            ActorTrait GuimiShenfen4 = CreateTrait("GuimiShenfen4", "trait/GuimiShenfen4", "GuimiShenfen");
            GuimiShenfen4.action_special_effect += traitAction.GuimiShenfen4_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen4);
            
            // 赏金猎人
            ActorTrait GuimiShenfen4Plus = CreateTrait("GuimiShenfen4+", "trait/GuimiShenfen4+", "GuimiShenfen");
            GuimiShenfen4Plus.rarity = Rarity.R2_Epic;
            GuimiShenfen4Plus.action_special_effect += traitAction.GuimiShenfenPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen4Plus);
            
            // 富豪
            ActorTrait GuimiShenfen4PlusPlus = CreateTrait("GuimiShenfen4++", "trait/GuimiShenfen4++", "GuimiShenfen");
            GuimiShenfen4PlusPlus.rarity = Rarity.R3_Legendary;
            GuimiShenfen4PlusPlus.action_special_effect += traitAction.GuimiShenfenPlusPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen4PlusPlus);
            
            // 作家
            ActorTrait GuimiShenfen5 = CreateTrait("GuimiShenfen5", "trait/GuimiShenfen5", "GuimiShenfen");
            GuimiShenfen5.action_special_effect += traitAction.GuimiShenfen5_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen5);
            
            // 著名作家
            ActorTrait GuimiShenfen5Plus = CreateTrait("GuimiShenfen5+", "trait/GuimiShenfen5+", "GuimiShenfen");
            GuimiShenfen5Plus.rarity = Rarity.R2_Epic;
            GuimiShenfen5Plus.action_special_effect += traitAction.GuimiShenfenPlus_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen5Plus);
            
            // 商人
            ActorTrait GuimiShenfen6 = CreateTrait("GuimiShenfen6", "trait/GuimiShenfen6", "GuimiShenfen");
            GuimiShenfen6.rarity = Rarity.R2_Epic;
            GuimiShenfen6.action_special_effect += traitAction.GuimiShenfen6_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen6);
            
            // 贵族
            ActorTrait GuimiShenfen7 = CreateTrait("GuimiShenfen7", "trait/GuimiShenfen7", "GuimiShenfen");
            GuimiShenfen7.rarity = Rarity.R3_Legendary;
            GuimiShenfen7.action_special_effect += traitAction.GuimiShenfen7_JinBangBoost;
            AssetManager.traits.add(GuimiShenfen7);
            
            // XulieTexing系列特质 - 无属性加成
            ActorTrait XulieTexing1 = CreateTrait("XulieTexing1", "trait/XulieTexing1", "XulieTexing"); // 序列九
            AssetManager.traits.add(XulieTexing1);
            
            ActorTrait XulieTexing2 = CreateTrait("XulieTexing2", "trait/XulieTexing2", "XulieTexing"); // 序列八
            AssetManager.traits.add(XulieTexing2);
            
            ActorTrait XulieTexing3 = CreateTrait("XulieTexing3", "trait/XulieTexing3", "XulieTexing"); // 序列七
            AssetManager.traits.add(XulieTexing3);
            
            ActorTrait XulieTexing4 = CreateTrait("XulieTexing4", "trait/XulieTexing4", "XulieTexing"); // 序列六
            AssetManager.traits.add(XulieTexing4);
            
            ActorTrait XulieTexing5 = CreateTrait("XulieTexing5", "trait/XulieTexing5", "XulieTexing"); // 序列五
            AssetManager.traits.add(XulieTexing5);
            
            ActorTrait XulieTexing6 = CreateTrait("XulieTexing6", "trait/XulieTexing6", "XulieTexing"); // 序列四
            AssetManager.traits.add(XulieTexing6);
            
            ActorTrait XulieTexing7 = CreateTrait("XulieTexing7", "trait/XulieTexing7", "XulieTexing"); // 序列三
            AssetManager.traits.add(XulieTexing7);
            
            ActorTrait XulieTexing8 = CreateTrait("XulieTexing8", "trait/XulieTexing8", "XulieTexing"); // 序列二
            AssetManager.traits.add(XulieTexing8);
            
            ActorTrait XulieTexing9 = CreateTrait("XulieTexing9", "trait/XulieTexing9", "XulieTexing"); // 序列一
            AssetManager.traits.add(XulieTexing9);
            
            ActorTrait XulieTexing91 = CreateTrait("XulieTexing91", "trait/XulieTexing91", "XulieTexing"); // 序列一
            AssetManager.traits.add(XulieTexing91);
            
            ActorTrait XulieTexing92 = CreateTrait("XulieTexing92", "trait/XulieTexing92", "XulieTexing"); // 序列一
            AssetManager.traits.add(XulieTexing92);
            
            // FuzhuCailiao系列辅助材料 - 无属性
            ActorTrait FuzhuCailiao1 = CreateTrait("FuzhuCailiao1", "trait/FuzhuCailiao1", "FuzhuCailiao"); // 序列九辅助材料
            AssetManager.traits.add(FuzhuCailiao1);
            
            ActorTrait FuzhuCailiao2 = CreateTrait("FuzhuCailiao2", "trait/FuzhuCailiao2", "FuzhuCailiao"); // 序列八辅助材料
            AssetManager.traits.add(FuzhuCailiao2);
            
            ActorTrait FuzhuCailiao3 = CreateTrait("FuzhuCailiao3", "trait/FuzhuCailiao3", "FuzhuCailiao"); // 序列七辅助材料
            AssetManager.traits.add(FuzhuCailiao3);
            
            ActorTrait FuzhuCailiao4 = CreateTrait("FuzhuCailiao4", "trait/FuzhuCailiao4", "FuzhuCailiao"); // 序列六辅助材料
            AssetManager.traits.add(FuzhuCailiao4);
            
            ActorTrait FuzhuCailiao5 = CreateTrait("FuzhuCailiao5", "trait/FuzhuCailiao5", "FuzhuCailiao"); // 序列五辅助材料
            AssetManager.traits.add(FuzhuCailiao5);
            
            ActorTrait FuzhuCailiao6 = CreateTrait("FuzhuCailiao6", "trait/FuzhuCailiao6", "FuzhuCailiao"); // 序列四辅助材料
            AssetManager.traits.add(FuzhuCailiao6);
            
            ActorTrait FuzhuCailiao7 = CreateTrait("FuzhuCailiao7", "trait/FuzhuCailiao7", "FuzhuCailiao"); // 序列三辅助材料
            AssetManager.traits.add(FuzhuCailiao7);
            
            ActorTrait FuzhuCailiao8 = CreateTrait("FuzhuCailiao8", "trait/FuzhuCailiao8", "FuzhuCailiao"); // 序列二辅助材料
            AssetManager.traits.add(FuzhuCailiao8);
            
            ActorTrait FuzhuCailiao9 = CreateTrait("FuzhuCailiao9", "trait/FuzhuCailiao9", "FuzhuCailiao"); // 序列一辅助材料
            AssetManager.traits.add(FuzhuCailiao9);
            
            ActorTrait FuzhuCailiao91 = CreateTrait("FuzhuCailiao91", "trait/FuzhuCailiao91", "FuzhuCailiao"); // 序列零辅助材料
            AssetManager.traits.add(FuzhuCailiao91);
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}