using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;


namespace XuLie.code
{
    internal class traitAction
    {
        // 定义晋升途径字典
        private static readonly Dictionary<string, Dictionary<string, string>> _xuLiePathways = new Dictionary<string, Dictionary<string, string>>
        {
            // 占卜家途径
            {"占卜家", new Dictionary<string, string>
            {
                {"XuLie2", "占卜家"},
                {"XuLie3", "小丑"},
                {"XuLie4", "魔术师"},
                {"XuLie5", "无面人"},
                {"XuLie6", "秘偶大师"},
                {"XuLie7", "诡法师"},
                {"XuLie8", "古代学者"},
                {"XuLie9", "奇迹师"},
                {"XuLie91", "诡秘侍者"},
                {"XuLie93", "愚者"},
                {"XuLie94", "诡秘之主"}
            }},


            // 偷盗者途径
            {"偷盗者", new Dictionary<string, string>
            {
                {"XuLie2", "偷盗者"},
                {"XuLie3", "诈骗师"},
                {"XuLie4", "解密学者"},
                {"XuLie5", "盗火人"},
                {"XuLie6", "窃梦家"},
                {"XuLie7", "寄生者"},
                {"XuLie8", "欺瞒导师"},
                {"XuLie9", "命运木马"},
                {"XuLie91", "时之虫"},
                {"XuLie93", "错误"},
                {"XuLie94", "诡秘之主"}
            }},
            // 学徒途径
            {"学徒", new Dictionary<string, string>
            {
                {"XuLie2", "学徒"},
                {"XuLie3", "戏法大师"},
                {"XuLie4", "占星人"},
                {"XuLie5", "记录官"},
                {"XuLie6", "旅行家"},
                {"XuLie7", "秘法师"},
                {"XuLie8", "漫游者"},
                {"XuLie9", "旅法师"},
                {"XuLie91", "星之钥"},
                {"XuLie93", "门"},
                {"XuLie94", "诡秘之主"}
            }},
            // 观众途径
            {"观众", new Dictionary<string, string>
            {
                {"XuLie2", "观众"},
                {"XuLie3", "读心者"},
                {"XuLie4", "心理医生"},
                {"XuLie5", "催眠师"},
                {"XuLie6", "梦境行者"},
                {"XuLie7", "操纵师"},
                {"XuLie8", "织梦人"},
                {"XuLie9", "洞察者"},
                {"XuLie91", "作家"},
                {"XuLie93", "空想家"},
                {"XuLie94", "上帝"}
            }},
            // 歌颂者途径
            {"歌颂者", new Dictionary<string, string>
            {
                {"XuLie2", "歌颂者"},
                {"XuLie3", "祈光人"},
                {"XuLie4", "太阳神官"},
                {"XuLie5", "公证人"},
                {"XuLie6", "光之祭司"},
                {"XuLie7", "无暗者"},
                {"XuLie8", "正义导师"},
                {"XuLie9", "逐光者"},
                {"XuLie91", "纯白天使"},
                {"XuLie93", "太阳"},
                {"XuLie94", "上帝"}
            }},
            // 水手途径
            {"水手", new Dictionary<string, string>
            {
                {"XuLie2", "水手"},
                {"XuLie3", "暴怒之民"},
                {"XuLie4", "航海家"},
                {"XuLie5", "风眷者"},
                {"XuLie6", "海洋歌者"},
                {"XuLie7", "灾难主祭"},
                {"XuLie8", "海王"},
                {"XuLie9", "天灾"},
                {"XuLie91", "雷神"},
                {"XuLie93", "暴君"},
                {"XuLie94", "上帝"}
            }},
            // 阅读者途径
            {"阅读者", new Dictionary<string, string>
            {
                {"XuLie2", "阅读者"},
                {"XuLie3", "推理学员"},
                {"XuLie4", "侦探"},
                {"XuLie5", "博学者"},
                {"XuLie6", "秘术导师"},
                {"XuLie7", "预言家"},
                {"XuLie8", "洞悉者"},
                {"XuLie9", "智天使"},
                {"XuLie91", "全知之眼"},
                {"XuLie93", "白塔"},
                {"XuLie94", "上帝"}
            }},
            // 秘祈人途径
            {"秘祈人", new Dictionary<string, string>
            {
                {"XuLie2", "秘祈人"},
                {"XuLie3", "倾听者"},
                {"XuLie4", "隐修士"},
                {"XuLie5", "蔷薇主教"},
                {"XuLie6", "牧羊人"},
                {"XuLie7", "黑骑士"},
                {"XuLie8", "三首圣堂"},
                {"XuLie9", "秽语长老"},
                {"XuLie91", "暗天使"},
                {"XuLie93", "倒吊人"},
                {"XuLie94", "上帝"}
            }},
            // 收尸人途径
            {"收尸人", new Dictionary<string, string>
            {
                {"XuLie2", "收尸人"},
                {"XuLie3", "掘墓人"},
                {"XuLie4", "通灵者"},
                {"XuLie5", "死灵导师"},
                {"XuLie6", "看门人"},
                {"XuLie7", "不死者"},
                {"XuLie8", "摆渡人"},
                {"XuLie9", "死亡执政官"},
                {"XuLie91", "苍白皇帝"},
                {"XuLie93", "死神"},
                {"XuLie94", "时空归一者"}
            }},
            // 不眠者途径
            {"不眠者", new Dictionary<string, string>
            {
                {"XuLie2", "不眠者"},
                {"XuLie3", "午夜诗人"},
                {"XuLie4", "梦魇"},
                {"XuLie5", "安魂师"},
                {"XuLie6", "灵巫"},
                {"XuLie7", "守夜人"},
                {"XuLie8", "恐惧主教"},
                {"XuLie9", "隐秘之仆"},
                {"XuLie91", "厄难天使"},
                {"XuLie93", "黑暗"},
                {"XuLie94", "时空归一者"}
            }},
            // 战士途径
            {"战士", new Dictionary<string, string>
            {
                {"XuLie2", "战士"},
                {"XuLie3", "格斗家"},
                {"XuLie4", "武器大师"},
                {"XuLie5", "黎明骑士"},
                {"XuLie6", "守护者"},
                {"XuLie7", "猎魔者"},
                {"XuLie8", "银骑士"},
                {"XuLie9", "荣耀者"},
                {"XuLie91", "神明之手"},
                {"XuLie93", "黄昏巨人"},
                {"XuLie94", "时空归一者"}
            }},
            // 刺客途径
            {"刺客", new Dictionary<string, string>
            {
                {"XuLie2", "刺客"},
                {"XuLie3", "教唆者"},
                {"XuLie4", "女巫"},
                {"XuLie5", "欢愉魔女"},
                {"XuLie6", "痛苦魔女"},
                {"XuLie7", "绝望魔女"},
                {"XuLie8", "不老魔女"},
                {"XuLie9", "灾难魔女"},
                {"XuLie91", "末日魔女"},
                {"XuLie93", "原初魔女"},
                {"XuLie94", "毁灭天灾"}
            }},
            // 猎人途径
            {"猎人", new Dictionary<string, string>
            {
                {"XuLie2", "猎人"},
                {"XuLie3", "挑衅者"},
                {"XuLie4", "纵火家"},
                {"XuLie5", "阴谋家"},
                {"XuLie6", "收割者"},
                {"XuLie7", "铁血骑士"},
                {"XuLie8", "战争主教"},
                {"XuLie9", "天气术士"},
                {"XuLie91", "征服者"},
                {"XuLie93", "红祭司"},
                {"XuLie94", "毁灭天灾"}
            }},
            // 窥秘人途径
            {"窥秘人", new Dictionary<string, string>
            {
                {"XuLie2", "窥秘人"},
                {"XuLie3", "格斗学者"},
                {"XuLie4", "巫师"},
                {"XuLie5", "卷轴教授"},
                {"XuLie6", "星象师"},
                {"XuLie7", "神秘学家"},
                {"XuLie8", "预言大师"},
                {"XuLie9", "贤者"},
                {"XuLie91", "知识皇帝"},
                {"XuLie93", "隐者"},
                {"XuLie94", "知识之妖"}
            }},
            // 通识者途径
            {"通识者", new Dictionary<string, string>
            {
                {"XuLie2", "通识者"},
                {"XuLie3", "考古学家"},
                {"XuLie4", "鉴定师"},
                {"XuLie5", "机械专家"},
                {"XuLie6", "天文学家"},
                {"XuLie7", "炼金术士"},
                {"XuLie8", "奥秘学者"},
                {"XuLie9", "知识导师"},
                {"XuLie91", "启蒙者"},
                {"XuLie93", "完美者"},
                {"XuLie94", "知识之妖"}
            }},
            // 怪物途径
            {"怪物", new Dictionary<string, string>
            {
                {"XuLie2", "怪物"},
                {"XuLie3", "机器"},
                {"XuLie4", "幸运儿"},
                {"XuLie5", "灾祸教士"},
                {"XuLie6", "赢家"},
                {"XuLie7", "厄运法师"},
                {"XuLie8", "混乱行者"},
                {"XuLie9", "先知"},
                {"XuLie91", "水银之蛇"},
                {"XuLie93", "命运之轮"},
                {"XuLie94", "光之钥"}
            }},
            // 耕种者途径
            {"耕种者", new Dictionary<string, string>
            {
                {"XuLie2", "耕种者"},
                {"XuLie3", "医师"},
                {"XuLie4", "丰收祭司"},
                {"XuLie5", "生物学家"},
                {"XuLie6", "德鲁伊"},
                {"XuLie7", "古代炼金士"},
                {"XuLie8", "抬棺人"},
                {"XuLie9", "荒芜主母"},
                {"XuLie91", "自然行者"},
                {"XuLie93", "母亲"},
                {"XuLie94", "万物之母"}
            }},
            // 药师途径
            {"药师", new Dictionary<string, string>
            {
                {"XuLie2", "药师"},
                {"XuLie3", "驯兽师"},
                {"XuLie4", "吸血鬼"},
                {"XuLie5", "魔药教授"},
                {"XuLie6", "深红学者"},
                {"XuLie7", "巫王"},
                {"XuLie8", "召唤大师"},
                {"XuLie9", "创生者"},
                {"XuLie91", "美神"},
                {"XuLie93", "月亮"},
                {"XuLie94", "万物之母"}
            }},
            // 罪犯途径
            {"罪犯", new Dictionary<string, string>
            {
                {"XuLie2", "罪犯"},
                {"XuLie3", "冷血者"},
                {"XuLie4", "连环杀手"},
                {"XuLie5", "恶魔"},
                {"XuLie6", "欲望使徒"},
                {"XuLie7", "魔鬼"},
                {"XuLie8", "呓语者"},
                {"XuLie9", "鲜血大公"},
                {"XuLie91", "污秽君王"},
                {"XuLie93", "深渊"},
                {"XuLie94", "诅咒之源"}
            }},

            // 仲裁人途径
            {"仲裁人", new Dictionary<string, string>
            {
                {"XuLie2", "仲裁人"},
                {"XuLie3", "治安官"},
                {"XuLie4", "审讯者"},
                {"XuLie5", "法官"},
                {"XuLie6", "惩戒骑士"},
                {"XuLie7", "律令法师"},
                {"XuLie8", "混乱猎手"},
                {"XuLie9", "平衡者"},
                {"XuLie91", "秩序之手"},
                {"XuLie93", "审判者"},
                {"XuLie94", "混沌之子"}
            }},
            // 律师途径
            {"律师", new Dictionary<string, string>
            {
                {"XuLie2", "律师"},
                {"XuLie3", "野蛮人"},
                {"XuLie4", "贿赂者"},
                {"XuLie5", "腐化男爵"},
                {"XuLie6", "混乱导师"},
                {"XuLie7", "堕落伯爵"},
                {"XuLie8", "狂乱法师"},
                {"XuLie9", "熵之公爵"},
                {"XuLie91", "弑序亲王"},
                {"XuLie93", "黑皇帝"},
                {"XuLie94", "混沌之子"}
            }},
            // 囚犯途径
            {"囚犯", new Dictionary<string, string>
            {
                {"XuLie2", "囚犯"},
                {"XuLie3", "疯子"},
                {"XuLie4", "狼人"},
                {"XuLie5", "活尸"},
                {"XuLie6", "怨魂"},
                {"XuLie7", "木偶"},
                {"XuLie8", "沉默门徒"},
                {"XuLie9", "古代邪物"},
                {"XuLie91", "神孽"},
                {"XuLie93", "被缚者"},
                {"XuLie94", "诅咒之源"}
            }},
        };
        
        // 定义TeXing系列特质与途径的映射关系
        private static readonly Dictionary<string, string> _texingToPathway = new Dictionary<string, string>
        {
            {"TeXing1", "占卜家"},
            {"TeXing2", "学徒"},
            {"TeXing3", "偷盗者"},
            {"TeXing4", "歌颂者"},
            {"TeXing5", "观众"},
            {"TeXing6", "阅读者"},
            {"TeXing7", "水手"},
            {"TeXing8", "秘祈人"},
            {"TeXing9", "药师"},
            {"TeXing10", "不眠者"},
            {"TeXing11", "战士"},
            {"TeXing1+", "猎人"},
            {"TeXing2+", "刺客"},
            {"TeXing3+", "耕种者"},
            {"TeXing4+", "收尸人"},
            {"TeXing5+", "律师"},
            {"TeXing6+", "仲裁人"},
            {"TeXing7+", "罪犯"},
            {"TeXing8+", "囚犯"},
            {"TeXing9+", "窥秘人"},
            {"TeXing10+", "通识者"},
            {"TeXing11+", "怪物"}
        };
        
        // 定义途径与TeXing系列特质的反向映射关系
        private static readonly Dictionary<string, string> _pathwayToTexing = new Dictionary<string, string>
        {
            {"占卜家", "TeXing1"},
            {"学徒", "TeXing2"},
            {"偷盗者", "TeXing3"},
            {"歌颂者", "TeXing4"},
            {"观众", "TeXing5"},
            {"阅读者", "TeXing6"},
            {"水手", "TeXing7"},
            {"秘祈人", "TeXing8"},
            {"药师", "TeXing9"},
            {"不眠者", "TeXing10"},
            {"战士", "TeXing11"},
            {"猎人", "TeXing1+"},
            {"刺客", "TeXing2+"},
            {"耕种者", "TeXing3+"},
            {"收尸人", "TeXing4+"},
            {"律师", "TeXing5+"},
            {"仲裁人", "TeXing6+"},
            {"罪犯", "TeXing7+"},
            {"囚犯", "TeXing8+"},
            {"窥秘人", "TeXing9+"},
            {"通识者", "TeXing10+"},
            {"怪物", "TeXing11+"}
        };

        // 记录角色选择的途径
        private static readonly Dictionary<Actor, string> _actorPathways = new Dictionary<Actor, string>();

        // 定义相邻途径关系
        private static readonly Dictionary<string, List<string>> _adjacentPathways = new Dictionary<string, List<string>>
        {
            {"占卜家", new List<string> {"偷盗者", "学徒"}},
            {"偷盗者", new List<string> {"占卜家", "学徒"}},
            {"学徒", new List<string> {"占卜家", "偷盗者"}},
            {"观众", new List<string> {"歌颂者", "水手", "阅读者", "秘祈人"}},
            {"歌颂者", new List<string> {"观众", "水手", "阅读者", "秘祈人"}},
            {"水手", new List<string> {"观众", "歌颂者", "阅读者", "秘祈人"}},
            {"阅读者", new List<string> {"观众", "歌颂者", "水手", "秘祈人"}},
            {"秘祈人", new List<string> {"观众", "歌颂者", "水手", "阅读者"}},
            {"收尸人", new List<string> {"不眠者", "战士"}},
            {"不眠者", new List<string> {"收尸人", "战士"}},
            {"战士", new List<string> {"收尸人", "不眠者"}},
            {"刺客", new List<string> {"猎人"}},
            {"猎人", new List<string> {"刺客"}},
            {"窥秘人", new List<string> {"通识者"}},
            {"通识者", new List<string> {"窥秘人"}},
            {"耕种者", new List<string> {"药师"}},
            {"药师", new List<string> {"耕种者"}},
            {"罪犯", new List<string> {"囚犯"}},
            {"囚犯", new List<string> {"罪犯"}},
            {"仲裁人", new List<string> {"律师"}},
            {"律师", new List<string> {"仲裁人"}}
            // 怪物途径没有相邻途径，不需要添加
        };

        // 记录唯一性特质的持有者，实现全局唯一性
        private static readonly Dictionary<string, Actor> _uniquenessOwners = new Dictionary<string, Actor>();

        // 记录源质的持有者，实现全局唯一性
        private static readonly Dictionary<string, Actor> _sourceQualityOwners = new Dictionary<string, Actor>();

        // 定义途径与源质的对应关系
        private static readonly Dictionary<string, string> _pathwayToSourceQuality = new Dictionary<string, string>
        {
            // 混沌海 (NineYuanZhi1)
            {"观众", "NineYuanZhi1"},
            {"歌颂者", "NineYuanZhi1"},
            {"水手", "NineYuanZhi1"},
            {"阅读者", "NineYuanZhi1"},
            {"秘祈人", "NineYuanZhi1"},
            
            // 源堡 (NineYuanZhi2)
            {"占卜家", "NineYuanZhi2"},
            {"学徒", "NineYuanZhi2"},
            {"偷盗者", "NineYuanZhi2"},
            
            // 母巢 (NineYuanZhi3)
            {"耕种者", "NineYuanZhi3"},
            {"药师", "NineYuanZhi3"},
            
            // 永暗之河 (NineYuanZhi4)
            {"收尸人", "NineYuanZhi4"},
            {"不眠者", "NineYuanZhi4"},
            {"战士", "NineYuanZhi4"},
            
            // 灾祸之城 (NineYuanZhi5)
            {"刺客", "NineYuanZhi5"},
            {"猎人", "NineYuanZhi5"},
            
            // 失序之国 (NineYuanZhi6)
            {"律师", "NineYuanZhi6"},
            {"仲裁人", "NineYuanZhi6"},
            
            // 知识荒野 (NineYuanZhi7)
            {"窥秘人", "NineYuanZhi7"},
            {"通识者", "NineYuanZhi7"},
            
            // 光之钥 (NineYuanZhi8)
            {"怪物", "NineYuanZhi8"},
            
            // 暗影世界 (NineYuanZhi9)
            {"罪犯", "NineYuanZhi9"},
            {"囚犯", "NineYuanZhi9"}
        };
        
        // 定义各途径真神的独特复活播报
        private static readonly Dictionary<string, string> _pathwayResurrectionMessages = new Dictionary<string, string>
        {
            {"占卜家", "诡秘之力涌动，{0}从历史的迷雾中归来！"},
            {"偷盗者", "时之虫的低语响起，{0}窃取了死亡的权柄！"},
            {"学徒", "星界之门敞开，{0}跨越时空界限重返现世！"},
            {"观众", "空想的法则显现，{0}从梦境中苏醒！"},
            {"歌颂者", "神圣的赞美诗回荡，{0}沐浴着太阳的光辉重生！"},
            {"水手", "风暴与海浪为{0}奏响复活的赞歌！"},
            {"阅读者", "智慧的光芒闪烁，{0}从知识的海洋中浮现！"},
            {"秘祈人", "信徒的祈祷得到回应，{0}从混沌的注视中归来！"},
            {"收尸人", "死亡的帷幕被掀开，{0}带着死神的权柄重返！"},
            {"不眠者", "永夜的阴影消散，{0}在黑暗的护佑下复苏！"},
            {"战士", "黄昏的号角吹响，{0}以战神的姿态重生！"},
            {"刺客", "原初的魔女微笑，{0}在镜中再度现身！"},
            {"猎人", "战争的火焰重燃，{0}作为战争的祭司重新归来！"},
            {"窥秘人", "神秘的星辰指引，{0}在神秘的领域中复苏！"},
            {"通识者", "真理的齿轮转动，{0}以完美者的姿态重生！"},
            {"怪物", "命运的轮盘旋转，{0}打破命运的束缚归来！"},
            {"耕种者", "自然的生机绽放，{0}在母亲的怀抱中复苏！"},
            {"药师", "生命的魔药生效，{0}在月亮的祝福下重生！"},
            {"罪犯", "深渊的呼唤传来，{0}带着污秽的气息归来！"},
            {"仲裁人", "秩序的天平永恒，{0}以审判的名义重生！"},
            {"律师", "混乱的法则生效，{0}作为秩序的阴影中重生！"},
            {"囚犯", "诅咒的锁链断裂，{0}从被缚者的封印中挣脱！"}
        };
        
        // 定义各途径真神理智不足时的独特播报
        private static readonly Dictionary<string, string> _pathwayResurrectionFailMessages = new Dictionary<string, string>
        {
            {"占卜家", "历史的迷雾拒绝接纳，{0}因理智不足无法归来！"},
            {"偷盗者", "时间的法则抗拒，{0}因理智不足无法窃取生命！"},
            {"学徒", "星界之门紧闭，{0}因理智不足无法跨越时空！"},
            {"观众", "空想的力量枯竭，{0}因理智不足无法苏醒！"},
            {"歌颂者", "太阳的光辉黯淡，{0}因理智不足无法重生！"},
            {"水手", "风暴的力量耗尽，{0}因理智不足无法复苏！"},
            {"阅读者", "智慧的光芒微弱，{0}因理智不足无法浮现！"},
            {"秘祈人", "黑暗的回应沉默，{0}因理智不足无法归来！"},
            {"收尸人", "死亡的帷幕厚重，{0}因理智不足无法跨越！"},
            {"不眠者", "永夜的阴影深沉，{0}因理智不足无法苏醒！"},
            {"战士", "黄昏的力量衰减，{0}因理智不足无法重生！"},
            {"刺客", "原初的注视移开，{0}因理智不足无法复苏！"},
            {"猎人", "战争的火焰微弱，{0}因理智不足无法归来！"},
            {"窥秘人", "星辰的指引模糊，{0}因理智不足无法复苏！"},
            {"通识者", "真理的齿轮停滞，{0}因理智不足无法重生！"},
            {"怪物", "命运的轮盘停止，{0}因理智不足无法挣脱！"},
            {"耕种者", "自然的生机枯萎，{0}因理智不足无法复苏！"},
            {"药师", "生命的魔药失效，{0}因理智不足无法重生！"},
            {"罪犯", "深渊的呼唤遥远，{0}因理智不足无法归来！"},
            {"仲裁人", "秩序的天平失衡，{0}因理智不足无法复苏！"},
            {"律师", "混乱的法则平静，{0}因理智不足无法归来！"},
            {"囚犯", "诅咒的锁链紧固，{0}因理智不足无法挣脱！"}
        };

        // 记录各途径高序列角色数量
        private static readonly Dictionary<string, Dictionary<string, int>> _pathwayHighSequenceCounts = new Dictionary<string, Dictionary<string, int>>();
        
        // 根据唯一性特质获取对应的途径
        private static string GetUniquenessPathway(string uniquenessTrait)
        {
            // 唯一性特质命名格式为"WeiYixingX"或"WeiYixingX+"
            if (uniquenessTrait.StartsWith("WeiYixing"))
            {
                try
                {
                    string numStr;
                    if (uniquenessTrait.EndsWith("+"))
                    {
                        numStr = uniquenessTrait.Substring(8, uniquenessTrait.Length - 9);
                    }
                    else
                    {
                        numStr = uniquenessTrait.Substring(8);
                    }
                    
                    int pathwayNum = int.Parse(numStr);
                    
                    // 根据编号获取途径
                    switch (pathwayNum)
                    {
                        case 1: return uniquenessTrait.EndsWith("+") ? "猎人" : "占卜家";
                        case 2: return uniquenessTrait.EndsWith("+") ? "刺客" : "学徒";
                        case 3: return uniquenessTrait.EndsWith("+") ? "耕种者" : "偷盗者";
                        case 4: return uniquenessTrait.EndsWith("+") ? "收尸人" : "歌颂者";
                        case 5: return uniquenessTrait.EndsWith("+") ? "律师" : "观众";
                        case 6: return uniquenessTrait.EndsWith("+") ? "仲裁人" : "阅读者";
                        case 7: return uniquenessTrait.EndsWith("+") ? "罪犯" : "水手";
                        case 8: return uniquenessTrait.EndsWith("+") ? "囚犯" : "秘祈人";
                        case 9: return uniquenessTrait.EndsWith("+") ? "窥秘人" : "药师";
                        case 10: return uniquenessTrait.EndsWith("+") ? "通识者" : "不眠者";
                        case 11: return uniquenessTrait.EndsWith("+") ? "怪物" : "战士";
                        default: return null;
                    }
                }
                catch
                {
                    return null;
                }
            }
            return null;
        }
        
        // 移除角色持有的非本途径唯一性
        private static void RemoveNonPathwayUniqueness(Actor a, string pathway)
        {
            List<string> toRemove = new List<string>();
            
            // 检查所有唯一性
            foreach (var kvp in _uniquenessOwners)
            {
                if (kvp.Value == a)
                {
                    string uniquenessTrait = kvp.Key;
                    string uniquenessPathway = GetUniquenessPathway(uniquenessTrait);
                    
                    // 如果唯一性不属于当前途径，则标记为移除
                    if (uniquenessPathway != null && uniquenessPathway != pathway)
                    {
                        toRemove.Add(uniquenessTrait);
                    }
                }
            }
            
            // 移除标记的唯一性
            foreach (string trait in toRemove)
            {
                a.removeTrait(trait);
                a.data.set("uniqueness", null);
                _uniquenessOwners.Remove(trait);
                string uniquenessName = NotificationHelper.GetUniquenessName(trait);
                NotificationHelper.ShowNotification(a, $"移除非本途径唯一性: {uniquenessName}");
            }
        }
        // 计时器变量，用于控制实时检查频率
        private static float _realTimeCheckTimer = 0f;
        private const float CHECK_INTERVAL = 60f; // 每60秒检查一次

        // 初始化高序列计数字典
        static traitAction()
        {
            // 初始化所有途径的高序列计数
            foreach (string pathway in _xuLiePathways.Keys)
            {
                _pathwayHighSequenceCounts[pathway] = new Dictionary<string, int>
                {
                    { "XuLie9", 0 },  // 序列二
                    { "XuLie91", 0 }, // 序列一
                    { "XuLie92", 0 }, // 天使之王
                    { "XuLie93", 0 }, // 真神
                    { "XuLie94", 0 }  // 旧日
                };
            }
        }

        // 执行实时检查的方法
        public static void PerformRealTimeChecks()
        {
            _realTimeCheckTimer += UnityEngine.Time.deltaTime;
            
            if (_realTimeCheckTimer >= CHECK_INTERVAL)
            {
                _realTimeCheckTimer = 0f;
                
                // 检查高序列人数限制
                CheckHighSequenceLimits();
                
                // 检查序列一特性组合限制
                CheckTeXingSequenceOneCombinations();
                
                // 检查所有途径是否存在旧日，并降级相关真神
                CheckOldOnesAndDemoteTrueGods();
            }
        }
        
        // 检查所有途径是否存在旧日，并降级相关真神
        private static void CheckOldOnesAndDemoteTrueGods()
        {
            // 清除途径缓存，确保重新评估所有角色的途径
            _actorPathways.Clear();
            
            // 直接检查游戏中的角色，确保计数与实际一致
            RecalculateAllHighSequenceCounts();
            
            // 遍历所有途径
            foreach (string pathway in _pathwayHighSequenceCounts.Keys)
            {
                // 检查该途径是否存在旧日
                if (_pathwayHighSequenceCounts[pathway].ContainsKey("XuLie94") && _pathwayHighSequenceCounts[pathway]["XuLie94"] > 0)
                {
                    // 如果存在旧日，降级该途径及其相邻途径的所有真神
                    DemoteOldOnesAndTrueGodsInPathwayAndAdjacent(pathway);
                }
            }
            
            // 额外的安全检查1：直接搜索所有拥有XuLie94特质的角色
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (actor != null && actor.isAlive() && actor.hasTrait("XuLie94"))
                {
                    // 重新获取途径，确保准确性
                    string pathway = GetActorPathway(actor);
                    if (!string.IsNullOrEmpty(pathway))
                    {
                        // 确保该途径的真神被降级
                        DemoteOldOnesAndTrueGodsInPathwayAndAdjacent(pathway);
                    }
                }
            }
            
            // 额外的安全检查2：直接搜索所有拥有真神特质的角色，不管途径如何
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (actor != null && actor.isAlive() && actor.hasTrait("XuLie93"))
                {
                    // 检查该真神所在的途径或相邻途径是否存在旧日
                    string pathway = GetActorPathway(actor);
                    if (pathway != null && HasOldOneInPathwayOrAdjacent(pathway))
                    {
                        // 直接降级这个真神，不依赖途径降级方法
                        NotificationHelper.ShowNotification(actor, $"由于所在途径或相邻途径出现旧日，{actor.getName()}被降级为天使之王！");
                        
                        // 移除真神特质
                        if (pathway != null)
                        {
                            UpdateHighSequenceCount(pathway, "XuLie93", -1);
                        }
                        
                        // 降级为天使之王
                        upTrait(
                            "XuLie93",
                            "XuLie92",
                            actor,
                            new string[] { "XuLie93+" },
                            new string[] { "XuLie92+" }
                        );
                        
                        actor.ChangeLiZhi(-50);
                        UpdateNameSuffix(actor, "XuLie92");
                        ApplyXuLieTitle(actor, "XuLie92");
                        
                        // 更新高序列计数
                        if (pathway != null)
                        {
                            UpdateHighSequenceCount(pathway, "XuLie92", 1);
                        }
                    }
                }
            }
        }

        // 检查高序列人数限制 - 增强版：完整利用途径缓存机制和多重验证
        private static void CheckHighSequenceLimits()
        {
            // 1. 首先清理所有无效的缓存条目
            CleanupInvalidPathwayCaches();
            
            // 2. 初始化所有途径的计数，确保统计准确
            InitializeAllPathwaysCounts();
            
            // 3. 遍历所有角色，进行高序列限制检查
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (!actor.isAlive()) continue;
                
                // 强制更新角色的途径缓存，确保准确性
                UpdateActorPathwayCache(actor);
                
                // 获取途径
                string pathway = GetActorPathway(actor);
                if (string.IsNullOrEmpty(pathway)) continue;
                
                // 确保途径在计数字典中
                if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                {
                    // 如果途径不在计数字典中，初始化它
                    InitializePathwayCount(pathway);
                }
                
                // 获取角色的最高序列特质
                string highestTrait = GetHighestXuLieTrait(actor);
                if (string.IsNullOrEmpty(highestTrait)) continue;
                
                // 检查当前角色是否应该被降级
                if (!CanPromoteToHighSequence(actor, highestTrait))
                {
                    // 降级到符合限制的最高序列
                    DemoteActorToValidSequence(actor, pathway, highestTrait);
                    
                    // 降级后再次更新缓存
                    UpdateActorPathwayCache(actor);
                }
                
                // 检查并更新该角色在高序列计数中的存在状态
                UpdateActorInHighSequenceCount(actor, pathway, highestTrait);
            }
            
            // 4. 执行特殊规则检查
            CheckSpecialHighSequenceRules();
        }
        
        // 清理无效的途径缓存
        private static void CleanupInvalidPathwayCaches()
        {
            List<Actor> invalidActors = new List<Actor>();
            
            foreach (var kvp in _actorPathways)
            {
                Actor actor = kvp.Key;
                if (actor == null || !actor.isAlive())
                {
                    invalidActors.Add(actor);
                }
            }
            
            foreach (Actor actor in invalidActors)
            {
                _actorPathways.Remove(actor);
            }
        }
        
        // 初始化所有途径的计数
        private static void InitializeAllPathwaysCounts()
        {
            // 确保所有已知途径都在计数字典中
            foreach (var pathway in _texingToPathway.Values.Distinct())
            {
                InitializePathwayCount(pathway);
            }
        }
        
        // 初始化单个途径的计数
        private static void InitializePathwayCount(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
            {
                _pathwayHighSequenceCounts[pathway] = new Dictionary<string, int>
                {
                    { "XuLie9", 0 },  // 序列二
                    { "XuLie91", 0 }, // 序列一
                    { "XuLie92", 0 }, // 天使之王
                    { "XuLie93", 0 }, // 真神
                    { "XuLie94", 0 }  // 旧日
                };
            }
        }
        
        // 更新角色在高序列计数中的状态
        private static void UpdateActorInHighSequenceCount(Actor actor, string pathway, string highestTrait)
        {
            if (string.IsNullOrEmpty(pathway) || string.IsNullOrEmpty(highestTrait))
                return;
            
            // 确保途径计数已初始化
            InitializePathwayCount(pathway);
            
            // 移除角色在其他序列等级的计数
            foreach (var trait in new string[] { "XuLie9", "XuLie91", "XuLie92", "XuLie93", "XuLie94" })
            {
                if (trait != highestTrait && actor.hasTrait(trait))
                {
                    // 这里不直接修改计数，因为RecalculateAllHighSequenceCounts会处理准确的计数
                    // 我们只需要确保当前角色的最高序列特质被正确记录
                }
            }
        }
        
        // 执行特殊的高序列规则检查
        private static void CheckSpecialHighSequenceRules()
        {
            // 检查所有途径的特殊规则
            foreach (var pathway in _pathwayHighSequenceCounts.Keys)
            {
                // 当有2位天使之王时，降级序列一角色
                CheckAndDemoteSequenceOneWhenTwoArchangels(pathway);
                
                // 当有真神时，检查是否需要降级天使之王和序列一
                CheckAndDemoteWhenTrueGodExists(pathway);
            }
        }
        
        // 当有真神时，检查是否需要降级天使之王和序列一
        private static void CheckAndDemoteWhenTrueGodExists(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;
            
            var counts = _pathwayHighSequenceCounts[pathway];
            int existingXuLie93 = counts["XuLie93"];
            
            if (existingXuLie93 > 0)
            {
                // 有真神时，最多只能有1位天使之王
                if (counts["XuLie92"] > 1)
                {
                    // 获取该途径所有天使之王角色
                    List<Actor> archangelActors = new List<Actor>();
                    foreach (var kvp in _actorPathways)
                    {
                        Actor actor = kvp.Key;
                        string actorPathway = kvp.Value;
                        if (actorPathway == pathway && actor.hasTrait("XuLie92"))
                        {
                            archangelActors.Add(actor);
                        }
                    }
                    
                    // 只保留1位天使之王，降级其他
                    int keepCount = 0;
                    foreach (Actor actor in archangelActors)
                    {
                        if (keepCount >= 1)
                        {
                            // 降级为序列一
                            upTrait("XuLie92", "XuLie91", actor,
                                new string[] { "XuLie92+", "chaofanXuemai6" },
                                new string[] { "XuLie91+", "chaofanXuemai5" });
                            UpdateNameSuffix(actor, "XuLie91");
                            ApplyXuLieTitle(actor, "XuLie91");
                            NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有真神，降级为序列一！");
                            
                            // 更新计数
                            UpdateHighSequenceCount(pathway, "XuLie92", -1);
                            UpdateHighSequenceCount(pathway, "XuLie91", 1);
                            
                            // 更新缓存
                            UpdateActorPathwayCache(actor);
                        }
                        else
                        {
                            keepCount++;
                        }
                    }
                }
                
                // 有真神时，不应该有序列一
                if (counts["XuLie91"] > 0)
                {
                    // 获取该途径所有序列一角色
                    List<Actor> sequenceOneActors = new List<Actor>();
                    foreach (var kvp in _actorPathways)
                    {
                        Actor actor = kvp.Key;
                        string actorPathway = kvp.Value;
                        if (actorPathway == pathway && actor.hasTrait("XuLie91"))
                        {
                            sequenceOneActors.Add(actor);
                        }
                    }
                    
                    // 降级所有序列一角色到序列二
                    foreach (Actor actor in sequenceOneActors)
                    {
                        upTrait("XuLie91", "XuLie9", actor,
                            new string[] { "XuLie91+", "chaofanXuemai5" },
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有真神，降级为序列二！");
                        
                        // 更新计数
                        UpdateHighSequenceCount(pathway, "XuLie91", -1);
                        UpdateHighSequenceCount(pathway, "XuLie9", 1);
                        
                        // 更新缓存
                        UpdateActorPathwayCache(actor);
                    }
                }
            }
        }

        // 检查序列一特性组合限制
        private static void CheckTeXingSequenceOneCombinations()
        {
            // 清除途径缓存，确保正确识别所有角色的途径
            _actorPathways.Clear();
            
            // 存储所有有效的组合和它们的当前持有者
            Dictionary<string, Actor> validOwners = new Dictionary<string, Actor>();
            
            // 先遍历所有角色，收集有效的组合
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (!actor.isAlive()) continue;
                
                string texingTrait = GetActorTeXingTrait(actor);
                if (string.IsNullOrEmpty(texingTrait)) 
                {
                    // 尝试通过唯一性特质确定途径
                    string uniquenessPathway = GetUniquenessPathwayFromActor(actor);
                    if (!string.IsNullOrEmpty(uniquenessPathway))
                    {
                        // 为没有TeXing特质但有唯一性的角色临时分配途径
                        continue; // 我们稍后会处理这些角色
                    }
                    continue;
                }
                
                // 检查该角色持有的所有序列一特性组合
                string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
                
                foreach (string seqTrait in sequenceOneTraits)
                {
                    if (actor.hasTrait(seqTrait))
                    {
                        string key = $"{texingTrait}+{seqTrait}";
                        
                        // 添加到有效持有者字典
                        validOwners[key] = actor;
                    }
                }
            }
            
            // 再次遍历所有角色，检查并移除冲突的组合
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (!actor.isAlive()) continue;
                
                string texingTrait = GetActorTeXingTrait(actor);
                if (string.IsNullOrEmpty(texingTrait)) continue;
                
                // 检查该角色持有的所有序列一特性组合
                string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
                
                foreach (string seqTrait in sequenceOneTraits)
                {
                    if (actor.hasTrait(seqTrait))
                    {
                        string key = $"{texingTrait}+{seqTrait}";
                        
                        // 如果这个组合的有效持有者不是当前角色，则移除这个特性
                        if (validOwners.ContainsKey(key) && validOwners[key] != actor)
                        {
                            actor.removeTrait(seqTrait);
                            NotificationHelper.ShowNotification(actor, $"{actor.getName()}的{seqTrait}因为与{validOwners[key].getName()}的{texingTrait}冲突被移除！");
                        }
                    }
                }
            }
            
            // 针对拥有唯一性但没有TeXing特质的角色，直接检查并移除冲突的组合
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (!actor.isAlive()) continue;
                
                // 跳过已经有TeXing特质的角色
                if (!string.IsNullOrEmpty(GetActorTeXingTrait(actor))) continue;
                
                // 尝试通过唯一性特质确定途径
                string uniquenessPathway = GetUniquenessPathwayFromActor(actor);
                if (string.IsNullOrEmpty(uniquenessPathway)) continue;
                
                // 获取对应于该途径的TeXing特质
                string texingTraitForPathway = null;
                foreach (var kvp in _texingToPathway)
                {
                    if (kvp.Value == uniquenessPathway)
                    {
                        texingTraitForPathway = kvp.Key;
                        break;
                    }
                }
                
                if (string.IsNullOrEmpty(texingTraitForPathway)) continue;
                
                // 检查该角色持有的所有序列一特性组合
                string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
                
                foreach (string seqTrait in sequenceOneTraits)
                {
                    if (actor.hasTrait(seqTrait))
                    {
                        string key = $"{texingTraitForPathway}+{seqTrait}";
                        
                        // 如果这个组合已经有其他持有者，则当前角色需要移除这个特性
                        if (validOwners.ContainsKey(key) && validOwners[key] != actor)
                        {
                            actor.removeTrait(seqTrait);
                            NotificationHelper.ShowNotification(actor, $"{actor.getName()}的{seqTrait}因为与{validOwners[key].getName()}冲突被移除！");
                        }
                    }
                }
            }
            
            // 更新_texingSequenceOneOwners字典以反映最新状态
            _texingSequenceOneOwners.Clear();
            foreach (var kvp in validOwners)
            {
                _texingSequenceOneOwners[kvp.Key] = kvp.Value;
            }
        }
        
        // 从角色的唯一性特质中获取途径
        private static string GetUniquenessPathwayFromActor(Actor actor)
        {
            foreach (ActorTrait trait in actor.getTraits())
            {
                if (trait.id.StartsWith("WeiYixing"))
                {
                    string pathway = GetUniquenessPathway(trait.id);
                    if (!string.IsNullOrEmpty(pathway))
                    {
                        return pathway;
                    }
                }
            }
            return null;
        }

        // 将角色降级到符合限制的最高序列
        private static void DemoteActorToValidSequence(Actor actor, string pathway, string currentHighestTrait)
        {
            string[] sequenceHierarchy = { "XuLie94", "XuLie93", "XuLie92", "XuLie91", "XuLie9", "XuLie8" };
            bool demoted = false;
            
            // 查找应该降级到的序列
            for (int i = Array.IndexOf(sequenceHierarchy, currentHighestTrait) + 1; i < sequenceHierarchy.Length; i++)
            {
                string targetTrait = sequenceHierarchy[i];
                if (CanPromoteToHighSequence(actor, targetTrait))
                {
                    // 执行降级操作
                    if (currentHighestTrait == "XuLie94" && targetTrait == "XuLie93")
                    {
                        // 旧日降级为真神
                        upTrait("XuLie94", "XuLie93", actor, 
                            new string[] { "XuLie94+" }, 
                            new string[] { "XuLie93+", "MaintainFullNutrition" });
                    }
                    else if (currentHighestTrait == "XuLie93" && targetTrait == "XuLie92")
                    {
                        // 真神降级为天使之王
                        upTrait("XuLie93", "XuLie92", actor, 
                            new string[] { "XuLie93+" }, 
                            new string[] { "XuLie92+", "chaofanXuemai6" });
                    }
                    else if (currentHighestTrait == "XuLie92" && targetTrait == "XuLie91")
                    {
                        // 天使之王降级为序列一
                        upTrait("XuLie92", "XuLie91", actor, 
                            new string[] { "XuLie92+", "chaofanXuemai6" }, 
                            new string[] { "XuLie91+", "chaofanXuemai5" });
                    }
                    else if (currentHighestTrait == "XuLie91" && targetTrait == "XuLie9")
                    {
                        // 序列一降级为序列二
                        upTrait("XuLie91", "XuLie9", actor, 
                            new string[] { "XuLie91+", "chaofanXuemai5" }, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                    }
                    else if (currentHighestTrait == "XuLie9" && targetTrait == "XuLie8")
                    {
                        // 序列二降级为序列三
                        upTrait("XuLie9", "XuLie8", actor, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" }, 
                            new string[] { "XuLie8+", "chaofanXuemai3" });
                    }
                    
                    UpdateNameSuffix(actor, targetTrait);
                    ApplyXuLieTitle(actor, targetTrait);
                    
                    // 更新高序列计数
                    UpdateHighSequenceCount(pathway, currentHighestTrait, -1);
                    UpdateHighSequenceCount(pathway, targetTrait, 1);
                    
                    NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径高序列人数限制，被降级为{targetTrait}！");
                    demoted = true;
                    break;
                }
            }
            
            // 如果没有找到合适的降级目标，则降级到序列九
            if (!demoted)
            {
                // 移除所有高序列特质
                foreach (string trait in new string[] { "XuLie9", "XuLie91", "XuLie92", "XuLie93", "XuLie94" })
                {
                    if (actor.hasTrait(trait))
                    {
                        actor.removeTrait(trait);
                        UpdateHighSequenceCount(pathway, trait, -1);
                    }
                }
                
                // 添加序列九特质（假设角色已经有基本的序列九特质）
                UpdateNameSuffix(actor, "XuLie9"); // 使用序列九的后缀
                ApplyXuLieTitle(actor, "XuLie9");
                
                NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为严重违反途径高序列人数限制，被完全降级！");
            }
        }

        // 获取角色的途径 - 全面优化版：根据TeXing系列和XuLie系列特质的组合判断
        private static string GetActorPathway(Actor actor)
        {
            // 确保角色存活且有效
            if (actor == null || !actor.isAlive())
            {
                return null;
            }
            
            // 首先检查缓存
            if (_actorPathways.TryGetValue(actor, out string pathway))
            {
                // 缓存验证：检查缓存的途径是否与当前特质匹配
                string currentTexingTrait = GetActorTeXingTrait(actor);
                if (currentTexingTrait != null)
                {
                    string expectedPathway = _texingToPathway[currentTexingTrait];
                    if (expectedPathway != pathway)
                    {
                        // 缓存已过时，更新缓存
                        pathway = expectedPathway;
                        _actorPathways[actor] = pathway;
                    }
                }
                return pathway;
            }
            
            // 1. 优先检查是否同时拥有TeXing特质和XuLie高序列特质，这是最准确的途径判断方式
            string texingTrait = GetActorTeXingTrait(actor);
            string highestXuLie = GetHighestXuLieTrait(actor);
            
            if (texingTrait != null && highestXuLie != null)
            {
                // 如果同时拥有TeXing特质和高序列特质，以TeXing特质为准判断途径
                pathway = _texingToPathway[texingTrait];
                _actorPathways[actor] = pathway;
                return pathway;
            }
            
            // 2. 检查角色是否拥有TeXing特质
            if (texingTrait != null)
            {
                pathway = _texingToPathway[texingTrait];
                _actorPathways[actor] = pathway;
                return pathway;
            }
            
            // 3. 如果没有TeXing特质但有高序列特质，尝试通过尊号和序列特质推断途径
            if (highestXuLie != null)
            {
                ApplyXuLieTitle(actor, highestXuLie);
                if (_actorPathways.TryGetValue(actor, out pathway))
                {
                    return pathway;
                }
                
                // 如果通过尊号仍无法确定，尝试通过唯一性特质推断途径
                string uniquenessPathway = GetUniquenessPathwayFromActor(actor);
                if (!string.IsNullOrEmpty(uniquenessPathway))
                {
                    _actorPathways[actor] = uniquenessPathway;
                    return uniquenessPathway;
                }
            }
            
            return null;
        }
        
        // 清理单个角色的途径缓存
        private static void ClearActorPathwayCache(Actor actor)
        {
            if (actor != null && _actorPathways.ContainsKey(actor))
            {
                _actorPathways.Remove(actor);
            }
        }
        
        // 更新角色的途径缓存 - 用于特质变化后的缓存同步
        private static void UpdateActorPathwayCache(Actor actor)
        {
            if (actor != null && actor.isAlive())
            {
                ClearActorPathwayCache(actor);
                GetActorPathway(actor); // 重新计算并缓存途径
            }
        }
        
        // 获取角色的TeXing特质
        private static string GetActorTeXingTrait(Actor actor)
        {
            foreach (var kvp in _texingToPathway)
            {
                if (actor.hasTrait(kvp.Key))
                {
                    return kvp.Key;
                }
            }
            return null;
        }

        // 更新高序列计数 - 优化版：增强健壮性和错误处理
        private static void UpdateHighSequenceCount(string pathway, string traitId, int change)
        {
            // 参数有效性检查
            if (string.IsNullOrEmpty(pathway) || string.IsNullOrEmpty(traitId))
            {
                return;
            }
            
            // 如果途径不存在，创建一个新的字典条目
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
            {
                _pathwayHighSequenceCounts[pathway] = new Dictionary<string, int>
                {
                    { "XuLie9", 0 },  // 序列二
                    { "XuLie91", 0 }, // 序列一
                    { "XuLie92", 0 }, // 天使之王
                    { "XuLie93", 0 }, // 真神
                    { "XuLie94", 0 }  // 旧日
                };
            }
            
            // 如果特质不存在，初始化为0
            if (!_pathwayHighSequenceCounts[pathway].ContainsKey(traitId))
            {
                _pathwayHighSequenceCounts[pathway][traitId] = 0;
            }
            
            // 应用更改并确保计数不为负数
            _pathwayHighSequenceCounts[pathway][traitId] = Math.Max(0, _pathwayHighSequenceCounts[pathway][traitId] + change);
        }
        
        // 重新计算所有高序列角色的途径和计数 - 增强版：完整利用优化的缓存机制
        public static void RecalculateAllHighSequenceCounts()
        {
            // 1. 清空所有缓存和计数，从干净状态开始
            _actorPathways.Clear();
            _pathwayHighSequenceCounts.Clear();
            
            // 2. 初始化所有途径的计数结构
            InitializeAllPathwaysCounts();
            
            // 3. 遍历所有角色，精确计算高序列计数
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (!actor.isAlive()) continue;
                
                // 强制更新角色的途径缓存，确保准确性
                UpdateActorPathwayCache(actor);
                
                // 获取角色的最高序列特质
                string highestXuLie = GetHighestXuLieTrait(actor);
                if (highestXuLie != null)
                {
                    // 重新计算角色的途径
                    string pathway = GetActorPathway(actor);
                    if (!string.IsNullOrEmpty(pathway))
                    {
                        // 确保途径在计数字典中
                        if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                        {
                            InitializePathwayCount(pathway);
                        }
                        
                        // 更新高序列计数
                        UpdateHighSequenceCount(pathway, highestXuLie, 1);
                    }
                }
            }
            
            // 4. 执行高序列限制检查，确保所有计数符合规则
            CheckHighSequenceLimits();
        }

        // 检查是否可以晋升到指定高序列
        private static bool CanPromoteToHighSequence(Actor actor, string targetTraitId)
        {
            string pathway = GetActorPathway(actor);
            string originalPathway = pathway; // 保存原始途径

            // 检查是否是相邻途径晋升
            if (targetTraitId == "XuLie92" || targetTraitId == "XuLie93")
            {
                // 获取角色当前的最高序列特质
                string currentHighestTrait = GetHighestXuLieTrait(actor);
                if (currentHighestTrait == "XuLie91") // 从序列一晋升
                {
                    // 检查是否是晋升到相邻途径
                    if (_adjacentPathways.ContainsKey(originalPathway))
                    {
                        // 序列一可以晋升相邻途径的天使之王，但不能晋升真神
                        if (targetTraitId == "XuLie93")
                        {
                            NotificationHelper.ShowNotification(actor, $"{actor.getName()}作为序列一，无法晋升到相邻途径的真神！");
                            return false;
                        }
                    }
                }
            }

            if (pathway == null || !_pathwayHighSequenceCounts.ContainsKey(pathway))
            {
                return true; // 如果无法确定途径，默认允许晋升
            }

            var counts = _pathwayHighSequenceCounts[pathway];
            int existingXuLie9 = counts["XuLie9"];
            int existingXuLie91 = counts["XuLie91"];
            int existingXuLie92 = counts["XuLie92"];
            int existingXuLie93 = counts["XuLie93"];
            int existingXuLie94 = counts["XuLie94"];
            // 如果已有真神，不允许晋升天使之王和序列一
            if (existingXuLie93 > 0)
            {
                if (targetTraitId == "XuLie92" || targetTraitId == "XuLie91")
                {
                    if (targetTraitId == "XuLie91")
                    {
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有真神，无法晋升序列一！");
                    }
                    else
                    {
                        NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有真神，无法晋升为{targetTraitId}！");
                    }
                    return false;
                }
                // 允许晋升序列二，但最多3个
                if (targetTraitId == "XuLie9" && existingXuLie9 >= 3)
                {
                    NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有3个序列二，无法晋升！");
                    return false;
                }
            }
            else
            {
                // 没有真神的情况
                switch (targetTraitId)
                {
                    case "XuLie92":// 天使之王
                        if (existingXuLie92 >= 2) // 最多2个天使之王
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王，无法晋升！");
                            return false;
                        }
                        break;
                    case "XuLie91":// 序列一
                        if (existingXuLie92 >= 2) // 有2个天使之王时不能有序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王，无法晋升为序列一！");
                            return false;
                        }
                        if (existingXuLie92 == 1 && existingXuLie91 >= 2) // 有1个天使之王时最多2个序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王和2个序列一，无法晋升！");
                            return false;
                        }
                        if (existingXuLie92 == 0 && existingXuLie91 >= 3) // 没有天使之王时最多3个序列一
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有3个序列一，无法晋升！");
                            return false;
                        }
                        break;
                    case "XuLie9":// 序列二
                        if (existingXuLie92 >= 2 && existingXuLie9 >= 3) // 有2个天使之王时最多3个序列二
                        {
                            NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有2个天使之王和3个序列二，无法晋升！");
                            return false;
                        }
                        if (existingXuLie92 == 1)
                        {
                            if (existingXuLie91 > 0 && existingXuLie9 >= 3) // 有1个天使之王和序列一时最多3个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王、序列一和3个序列二，无法晋升！");
                                return false;
                            }
                            if (existingXuLie91 == 0 && existingXuLie9 >= 5) // 有1个天使之王但无序列一时最多5个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有1个天使之王和5个序列二，无法晋升！");
                                return false;
                            }
                        }
                        if (existingXuLie92 == 0)
                        {
                            if (existingXuLie91 > 0 && existingXuLie9 >= 3) // 没有天使之王但有序列一时最多3个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有序列一和3个序列二，无法晋升！");
                                return false;
                            }
                            if (existingXuLie91 == 0 && existingXuLie9 >= 6) // 没有天使之王和序列一时最多6个序列二
                            {
                                NotificationHelper.ShowNotification(actor, $"[{pathway}]途径已有6个序列二，无法晋升！");
                                return false;
                            }
                        }
                        break;
                }
            }

            
            return true;
        }

        // 当理智小于10点时添加疯狂特质
        private static void ApplyMadnessEffect(Actor a)
        {
            // 检查是否有坚忍特质
            if (a.hasTrait("strong_minded"))
            {
                // 有坚忍特质，去除坚忍特质
                a.removeTrait("strong_minded");
            }
            
            // 添加疯狂特质
            a.addTrait("madness");
        }

        // 当有2位天使之王时，降级序列一角色
        private static void CheckAndDemoteSequenceOneWhenTwoArchangels(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;

            var counts = _pathwayHighSequenceCounts[pathway];
            int existingXuLie92 = counts["XuLie92"];
            int existingXuLie91 = counts["XuLie91"];
            int existingXuLie9 = counts["XuLie9"];

            // 当有2位天使之王且有序列一时
            if (existingXuLie92 >= 2 && existingXuLie91 > 0)
            {
                // 获取该途径所有序列一角色
                List<Actor> sequenceOneActors = new List<Actor>();
                foreach (var kvp in _actorPathways)
                {
                    Actor actor = kvp.Key;
                    string actorPathway = kvp.Value;
                    if (actorPathway == pathway && actor.hasTrait("XuLie91"))
                    {
                        sequenceOneActors.Add(actor);
                    }
                }

                // 降级所有序列一角色
                foreach (Actor actor in sequenceOneActors)
                {
                    if (existingXuLie9 < 3)
                    {
                        // 降级到序列二
                        upTrait("XuLie91", "XuLie9", actor,
                            new string[] { "XuLie91+", "chaofanXuemai5" },
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有2位天使之王，降级为序列二！");
                        existingXuLie9++;
                    }
                    else
                    {
                        // 降级到序列三
                        upTrait("XuLie91", "XuLie8", actor,
                            new string[] { "XuLie91+", "chaofanXuemai5" },
                            new string[] { "XuLie8+", "fire_proof", "regeneration", "chaofanXuemai3" });
                        UpdateNameSuffix(actor, "XuLie8");
                        ApplyXuLieTitle(actor, "XuLie8");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为途径有2位天使之王且序列二已满，降级为序列三！");
                    }
                    // 更新计数
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                    if (existingXuLie9 < 3)
                    {
                        UpdateHighSequenceCount(pathway, "XuLie9", 1);
                    }
                    else
                    {
                        UpdateHighSequenceCount(pathway, "XuLie8", 1);
                    }
                }
            }
        }

        // 当出现真神时，降级现有高序列角色
        private static void DemoteHighSequenceActors(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;

            // 获取该途径所有天使之王和序列一角色
            List<Actor> actorsToDemote = new List<Actor>();
            foreach (var kvp in _actorPathways)
            {
                Actor actor = kvp.Key;
                string actorPathway = kvp.Value;
                if (actorPathway == pathway && (actor.hasTrait("XuLie92") || actor.hasTrait("XuLie91")))
                {
                    actorsToDemote.Add(actor);
                }
            }

            // 获取该途径序列二数量
            int xuLie9Count = _pathwayHighSequenceCounts[pathway]["XuLie9"];

            foreach (Actor actor in actorsToDemote)
            {
                if (actor.hasTrait("XuLie92"))
                {
                    // 天使之王降级
                    if (xuLie9Count < 3)
                    {
                        // 降级到序列二
                        upTrait("XuLie92", "XuLie9", actor, 
                            new string[] { "XuLie92+", "chaofanXuemai6" }, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                        xuLie9Count++;
                    }
                    else
                    {
                        // 降级到序列三
                        upTrait("XuLie92", "XuLie8", actor, 
                            new string[] { "XuLie92+", "chaofanXuemai6" }, 
                            new string[] { "XuLie8+", "fire_proof", "regeneration", "chaofanXuemai3" });
                        UpdateNameSuffix(actor, "XuLie8");
                        ApplyXuLieTitle(actor, "XuLie8");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                    }
                    // 更新计数
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                    if (xuLie9Count < 3)
                    {
                        UpdateHighSequenceCount(pathway, "XuLie9", 1);
                    }
                    else
                    {
                        UpdateHighSequenceCount(pathway, "XuLie8", 1);
                    }
                }
                else if (actor.hasTrait("XuLie91"))
                {
                    // 序列一降级
                    if (xuLie9Count < 3)
                    {
                        // 降级到序列二
                        upTrait("XuLie91", "XuLie9", actor, 
                            new string[] { "XuLie91+", "chaofanXuemai5" }, 
                            new string[] { "XuLie9+", "fire_proof", "regeneration", "chaofanXuemai4" });
                        UpdateNameSuffix(actor, "XuLie9");
                        ApplyXuLieTitle(actor, "XuLie9");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                        xuLie9Count++;
                    }
                    else
                    {
                        // 降级到序列三
                        upTrait("XuLie91", "XuLie8", actor, 
                            new string[] { "XuLie91+", "chaofanXuemai5" }, 
                            new string[] { "XuLie8+", "fire_proof", "regeneration", "chaofanXuemai3" });
                        UpdateNameSuffix(actor, "XuLie8");
                        ApplyXuLieTitle(actor, "XuLie8");
                        NotificationHelper.ShowNotification(actor, $"{actor.getName()}因为有真神所以掉落序列。");
                    }
                    // 更新计数
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                    if (xuLie9Count < 3)
                    {
                        UpdateHighSequenceCount(pathway, "XuLie9", 1);
                    }
                    else
                    {
                        UpdateHighSequenceCount(pathway, "XuLie8", 1);
                    }
                }
            }
        }

        public static bool IsXuLie1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"XuLie{i}") || a.hasTrait($"XuLie{i}+"))
                {
                    return true;
                }
            }
            return false;
        }

        private static readonly Dictionary<string, string> _xuLieSuffixMap = new Dictionary<string, string>
        {
            {"XuLie1", "半超凡"},
            {"XuLie2", "序列九"},
            {"XuLie3", "序列八"},
            {"XuLie4", "序列七"},
            {"XuLie5", "序列六"},
            {"XuLie6", "序列五"},
            {"XuLie7", "序列四_半神"},
            {"XuLie8", "序列三_半神"},
            {"XuLie9", "序列二_天使"},
            {"XuLie91", "序列一_天使"},
            {"XuLie92", "天使之王"},
            {"XuLie93", "真神"},
            {"XuLie94", "旧日"}
        };


        // 尊号字典
        private static readonly Dictionary<string, string[]> _xuLieTitlesMap = new Dictionary<string, string[]>
        {
            {"XuLie2", new string[] {
                "占卜家","学徒","偷盗者","观众","水手","歌颂者","阅读者","秘祈人","收尸人","不眠者","战士","刺客","猎人","窥秘人","通识者","怪物","耕种者","药师","仲裁人","律师","囚犯","罪犯"
            }},
            // 其他境界尊号保持不变
            {"XuLie3", new string[] {
                "小丑","戏法大师","诈骗师","读心者","暴怒之民","祈光人","推理学员","倾听者","掘墓人","午夜诗人","格斗家","教唆者","挑衅者","格斗学者","考古学家","机器","医师","驯兽师","治安官","野蛮人","疯子","冷血者"
            }},
            {"XuLie4", new string[] {
                "魔术师","解密学者","占星人","心理医生","太阳神官","航海家","侦探","隐修士","梦魇","通灵者","武器大师","女巫","纵火家","巫师","幸运儿","丰收祭司","吸血鬼","连环杀手","狼人","贿赂者","审讯者","鉴定师"
            }},
            {"XuLie5", new string[] {
                "无面人","盗火人","记录官","催眠师","公证人","风眷者","博学者","蔷薇主教","安魂师","死灵导师","黎明骑士","欢愉魔女","阴谋家","卷轴教授","机械专家","灾祸教士","生物学家","魔药教授","恶魔","活尸","腐化男爵","法官"
            }},
            {"XuLie6", new string[] {
                "秘偶大师","窃梦家","旅行家","梦境行者","光之祭司","秘术导师","海洋歌者","牧羊人","灵巫","看门人","守护者","痛苦魔女","收割者","星象师","天文学家","赢家","德鲁伊","深红学者","欲望使徒","怨魂","混乱导师","惩戒骑士"
            }},
            {"XuLie7", new string[] {
                "诡法师","寄生者","秘法师","操纵师","无暗者","灾难主祭","预言家","黑骑士","守夜人","不死者","猎魔者","绝望魔女","铁血骑士","神秘学家","炼金术士","厄运法师","古代炼金士","巫王","魔鬼","木偶","堕落伯爵","律令法师"
            }},
            {"XuLie8", new string[] {
                "古代学者","欺瞒导师","漫游者","织梦人","正义导师","海王","洞悉者","三首圣堂","恐惧主教","摆渡人","银骑士","不老魔女","战争主教","预言大师","奥秘学者","混乱行者","抬棺人","召唤大师","呓语者","沉默门徒","狂乱法师","混乱猎手"
            }},
            {"XuLie9", new string[] {
                "奇迹师","命运木马","旅法师","洞察者","逐光者","天灾","智天使","秽语长老","隐秘之仆","死亡执政官","荣耀者","灾难魔女","天气术士","贤者","知识导师","先知","荒芜主母","创生者","鲜血大公","古代邪物","熵之公爵","平衡者"
            }},
            {"XuLie91", new string[] {
                "诡秘侍者","星之钥","时之虫","作家","雷神","纯白天使","全知之眼","暗天使","苍白皇帝","厄难天使","神明之手","末日魔女","征服者","知识皇帝","启蒙者","水银之蛇","自然行者","美神","秩序之手","弑序亲王","神孽","污秽君王"
            }},
            // 天使之王尊号，与对应序列一尊号相同
            {"XuLie92", new string[] {
                "诡秘侍者","星之钥","时之虫","作家","雷神","纯白天使","全知之眼","暗天使","苍白皇帝","厄难天使","神明之手","末日魔女","征服者","知识皇帝","启蒙者","水银之蛇","自然行者","美神","秩序之手","弑序亲王","神孽","污秽君王"
            }},
            // 真神尊号
            {"XuLie93", new string[] {
                "愚者","门","错误","空想家","暴君","太阳","白塔","倒吊人","死神","黑暗","黄昏巨人","原初魔女","红祭司","隐者","完美者","命运之轮","母亲","月亮","审判者","黑皇帝","被缚者","深渊"
            }},
            // 旧日尊号
            {"XuLie94", new string[] {
                "诡秘之主","全知全能者","时空归一者","毁灭天灾","知识之妖","光之钥","万物之母","混沌之子","诅咒之源","宿命之环","命运女神","原初饥饿","超星主宰","衰败君王","高维俯视者","不熄的呓语","上帝"
            }}
        };

        // 更新TeXing特质的辅助方法
        private static void UpdateTexingTrait(Actor actor, string pathway)
        {
            // 移除所有已有的TeXing特质
            foreach (var kvp in _texingToPathway)
            {
                if (actor.hasTrait(kvp.Key))
                {
                    actor.removeTrait(kvp.Key);
                }
            }
            
            // 根据途径添加对应的TeXing特质
            if (_pathwayToTexing.TryGetValue(pathway, out string texingTrait))
            {
                actor.addTrait(texingTrait);
            }
        }

        private static void ApplyXuLieTitle(Actor actor, string newTrait)
        {
            // 每次晋升序列时，检查并更新TeXing特质
            if (_actorPathways.TryGetValue(actor, out string pathway))
            {
                UpdateTexingTrait(actor, pathway);
            }
            
            if (newTrait == "XuLie2")
            {
                string title = null;
                
                // 检查角色是否拥有TeXing系列特质
                List<string> availablePathways = new List<string>();
                foreach (var kvp in _texingToPathway)
                {
                    if (actor.hasTrait(kvp.Key))
                    {
                        availablePathways.Add(kvp.Value);
                    }
                }
                
                if (availablePathways.Count > 0)
                {
                    // 如果有2个以上的TeXing特质，随机选择一个
                    title = availablePathways[UnityEngine.Random.Range(0, availablePathways.Count)];
                }
                else
                {
                    // 如果没有TeXing特质，保持原有的随机选择逻辑
                    string[] titles = _xuLieTitlesMap["XuLie2"];
                    title = titles[UnityEngine.Random.Range(0, titles.Length)];
                }
                
                _actorPathways[actor] = title; // 记录角色选择的途径

                UpdateTexingTrait(actor, title);

                string currentName = actor.getName();
                int separatorIndex = currentName.IndexOfAny(new[] { '|' });
                string baseName = separatorIndex > 0 
                    ? currentName.Substring(separatorIndex + 1).Trim()
                    : currentName;

                actor.data.setName($"{title}|{baseName}");
        }
            else if (_actorPathways.ContainsKey(actor))
        {
            // 后续晋升时，根据记录的途径选择对应的前缀
            string currentPathway = _actorPathways[actor];
            
            // 检查是否可以晋升到相邻途径
            // 序列四(XuLie7/XuLie8)及以上有一个概率，序列二(XuLie9及以上)有更高概率
            float promotionChance = 0.0f;
            
            if (newTrait == "XuLie9")
            {
                // 序列二：40%概率
                promotionChance = 0.4f;
            }
            // 序列一(XuLie91)及以上不允许转换途径
            else if (newTrait == "XuLie91" || newTrait == "XuLie92" || newTrait == "XuLie93")
            {
                promotionChance = 0.0f;
            }
            else if (newTrait == "XuLie7" || newTrait == "XuLie8")
            {
                // 序列四：20%概率
                promotionChance = 0.2f;
            }
            
            bool hasConverted = false;
            if (promotionChance > 0 && UnityEngine.Random.Range(0.0f, 1.0f) <= promotionChance && _adjacentPathways.ContainsKey(currentPathway))
            {
                // 获取相邻途径
                List<string> adjacentPaths = _adjacentPathways[currentPathway];
                if (adjacentPaths != null && adjacentPaths.Count > 0)
                {
                    // 优先考虑相邻途径是否有空位（没有真神）
                    List<string> availablePaths = new List<string>();
                    foreach (string adjacentPath in adjacentPaths)
                    {
                        if (_pathwayHighSequenceCounts.ContainsKey(adjacentPath) && 
                            _pathwayHighSequenceCounts[adjacentPath]["XuLie93"] == 0)
                        {
                            availablePaths.Add(adjacentPath);
                        }
                    }
                    
                    if (availablePaths.Count > 0)
                        {
                            // 如果有可用的相邻途径，选择一个
                            string newPathway = availablePaths[UnityEngine.Random.Range(0, availablePaths.Count)];
                            // 更新角色的途径记录
                            string oldPathway = currentPathway;
                            _actorPathways[actor] = newPathway;
                            currentPathway = newPathway; // 更新当前途径为新途径
                            hasConverted = true;
                            
                            UpdateTexingTrait(actor, newPathway);
                            
                            // 更新高序列计数：减少原途径计数
                            if (_pathwayHighSequenceCounts.ContainsKey(oldPathway))
                            {
                                if (_pathwayHighSequenceCounts[oldPathway].ContainsKey(newTrait))
                                {
                                    _pathwayHighSequenceCounts[oldPathway][newTrait] = Math.Max(0, _pathwayHighSequenceCounts[oldPathway][newTrait] - 1);
                                }
                            }
                            
                            // 更新高序列计数：增加新途径计数
                            if (_pathwayHighSequenceCounts.ContainsKey(newPathway))
                            {
                                if (_pathwayHighSequenceCounts[newPathway].ContainsKey(newTrait))
                                {
                                    _pathwayHighSequenceCounts[newPathway][newTrait]++;
                                }
                            }
                            
                            string actorName = actor.getName();
                            int separatorIndex = actorName.IndexOfAny(new[] { '|' });
                            string baseName = separatorIndex > 0 
                                ? actorName.Substring(separatorIndex + 1).Trim()
                                : actorName;
                            NotificationHelper.ShowNotification(actor, $"{baseName}晋升到相邻途径[{newPathway}]！");
                    }
                }
            }
            
            // 无论是否转换途径，都使用当前途径更新尊号
            if (_xuLiePathways.ContainsKey(currentPathway) && _xuLiePathways[currentPathway].TryGetValue(newTrait, out string title))
            {
                string currentName = actor.getName();
                int separatorIndex = currentName.IndexOfAny(new[] { '|' });
                string baseName = separatorIndex > 0 
                    ? currentName.Substring(separatorIndex + 1).Trim()
                    : currentName;

                actor.data.setName($"{title}|{baseName}");
            }
        }
        else
        {
            // 无序列时，首先检查是否有TeXing特质
            string selectedPathway = null;
            
            // 检查是否有TeXing特质
            foreach (var kvp in _texingToPathway)
            {
                if (actor.hasTrait(kvp.Key))
                {
                    selectedPathway = kvp.Value;
                    break;
                }
            }
            
            // 如果没有TeXing特质，则随机选择一个完整序列途径
            if (selectedPathway == null)
            {
                var allPathways = _xuLiePathways.Keys.ToList();
                if (allPathways.Count > 0)
                {
                    selectedPathway = allPathways[UnityEngine.Random.Range(0, allPathways.Count)];
                }
            }
            
            if (selectedPathway != null)
            {
                // 记录该途径
                _actorPathways[actor] = selectedPathway;
                
                UpdateTexingTrait(actor, selectedPathway);
                
                // 检测角色是否有更高序列等级的特性
                string highestXuLieTrait = GetHighestXuLieTrait(actor);
                string title;
                
                // 限制最高等级判定，如果超过序列二(XuLie9)，降级为序列三(XuLie3)
                if (!string.IsNullOrEmpty(highestXuLieTrait) && 
                    (highestXuLieTrait == "XuLie9" || highestXuLieTrait == "XuLie91" || 
                     highestXuLieTrait == "XuLie92" || highestXuLieTrait == "XuLie93"))
                {
                    // 超过序列二，降级为序列三
                    highestXuLieTrait = "XuLie3";
                    // 移除所有序列二及以上的特质
                    foreach (string trait in new string[] { "XuLie9", "XuLie91", "XuLie92", "XuLie93" })
                    {
                        if (actor.hasTrait(trait))
                        {
                            actor.removeTrait(trait);
                        }
                    }
                }
                
                if (!string.IsNullOrEmpty(highestXuLieTrait))
                {
                    // 如果有更高序列等级，使用对应等级的尊号
                    if (_xuLiePathways[selectedPathway].TryGetValue(highestXuLieTrait, out title))
                    {
                        // 找到了对应等级的尊号
                    }
                    else
                    {
                        // 没有找到对应等级的尊号，使用序列九尊号
                        title = _xuLiePathways[selectedPathway]["XuLie2"];
                    }
                }
                else
                {
                    // 没有更高序列等级，使用序列九尊号
                    title = _xuLiePathways[selectedPathway]["XuLie2"];
                }
                
                string currentName = actor.getName();
                int separatorIndex = currentName.IndexOfAny(new[] { '|' });
                string baseName = separatorIndex > 0 
                    ? currentName.Substring(separatorIndex + 1).Trim()
                    : currentName;
                actor.data.setName($"{title}|{baseName}");
            }
        }
        }
            private static string GetHighestXuLieTrait(Actor actor)
        {
            // 定义序列等级的优先级顺序（从高到低）
            string[] xuLieTraits = { "XuLie94", "XuLie93", "XuLie92", "XuLie91", "XuLie9", "XuLie8", "XuLie7", "XuLie6", "XuLie5", "XuLie4", "XuLie3", "XuLie2" };
            
            foreach (string trait in xuLieTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return trait;
                }
            }
            
            return null;
        }
        
        /// <summary>
        /// 处理真神/旧日晋升，自动成为神明/支柱
        /// </summary>
        public static void HandlePromotionToGodOrOldOne(Actor actor, string promotionXuLieId)
        {
            if (actor == null || !actor.isAlive())
                return;
            
            // 获取角色途径
            string pathway = GetActorPathway(actor);
            if (string.IsNullOrEmpty(pathway))
                return;
            
            // 处理晋升真神(XuLie93)的情况
            if (promotionXuLieId == "XuLie93")
            {
                // 自动成为神明(GodsandBuddhas9)
                if (!actor.hasTrait("GodsandBuddhas91"))
                {
                    try
                    {
                        // 设置神位后缀
                        UpdateNameSuffix(actor, "XuLie93");
                    }
                    catch (Exception e)
                    {
                        Debug.LogError("晋升真神时添加神明特质失败: " + e.Message);
                    }
                }
            }
            // 处理晋升旧日(XuLie94)的情况
            else if (promotionXuLieId == "XuLie94")
            {
                // 自动成为支柱(GodsandBuddhas93)
                if (!actor.hasTrait("GodsandBuddhas92"))
                {
                    try
                    {
                        // 设置支柱后缀
                        UpdateNameSuffix(actor, "XuLie94");
                    }
                    catch (Exception e)
                    {
                        Debug.LogError("晋升旧日时添加支柱特质失败: " + e.Message);
                    }
                }
            }
        }
        


private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_xuLieSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        string baseName = currentName;
        string godsandBuddhasSuffix = "";
        
        // 提取基础名称和其他系统后缀
        // 先检查是否同时包含连字符(-)和空格，处理形如"张三-序列九 神职"的情况
        int dashIndex = currentName.IndexOf('-');
        if (dashIndex > 0)
        {
            int spaceIndex = currentName.IndexOf(' ', dashIndex);
            if (spaceIndex > 0)
            {
                // 存在其他系统后缀，如"张三-序列九 神职"
                baseName = currentName.Substring(0, dashIndex).Trim();
                // 保留其他系统后缀
            }
            else
            {
                // 只有序列后缀，如"张三-序列九"
                baseName = currentName.Substring(0, dashIndex).Trim();
            }
        }
        else if (currentName.Contains(' '))
        {
            // 只有其他系统后缀，如"张三 神职"
            int lastSpaceIndex = currentName.LastIndexOf(' ');
            baseName = currentName.Substring(0, lastSpaceIndex).Trim();
            // 保留其他系统后缀
        }
        
        // 根据序列等级和GodsandBuddhas特质设置神明体系后缀
        if (newTrait == "XuLie7" && actor.hasTrait("GodsandBuddhas6"))
        {
            // 序列四(半神)获得GodsandBuddhas6(枢机主教)
            godsandBuddhasSuffix = "红衣";
        }
        else if (newTrait == "XuLie8" && actor.hasTrait("GodsandBuddhas7"))
        {
            // 序列三(圣者)获得GodsandBuddhas7(教会圣者)
            godsandBuddhasSuffix = "圣者";
        }
        else if (newTrait == "XuLie9" && actor.hasTrait("GodsandBuddhas8"))
        {
            // 序列二(天使)获得GodsandBuddhas8(神圣教宗)
            godsandBuddhasSuffix = "教宗";
        }
        else if ((newTrait == "XuLie91" || newTrait == "XuLie92") && actor.hasTrait("GodsandBuddhas9"))
        {
            // 序列一(大天使)和XuLie92(天使之王)获得GodsandBuddhas9(从神)
            godsandBuddhasSuffix = "从神";
        }
        else if (newTrait == "XuLie93" && actor.hasTrait("GodsandBuddhas91"))
        {
            // 真神获得GodsandBuddhas91(神明)
            godsandBuddhasSuffix = "伟大";
        }
        else if (newTrait == "XuLie94" && actor.hasTrait("GodsandBuddhas92"))
        {
            // 旧日获得GodsandBuddhas92(支柱)
            godsandBuddhasSuffix = "支柱";
        }
        
        // 设置新名称：基础名 + 序列后缀 + 神明后缀
        if (!string.IsNullOrEmpty(godsandBuddhasSuffix))
        {
            actor.data.setName($"{baseName}-{suffix} {godsandBuddhasSuffix}");
        }
        else
        {
            // 没有匹配的神明后缀，只保留序列后缀
            actor.data.setName($"{baseName}-{suffix}");
        }
    }
}

        // 应用真实伤害并考虑位格免伤
        public static void ApplyTrueDamageWithRealmProtection(Actor attacker, Actor target, int originalDamage)
        {
            // 记录目标当前生命值，用于判断是否因本次攻击死亡
            float targetHealthBeforeDamage = target.data.health;
            
            // 计算基于位格的实际伤害
            float actualDamage = attacker.CalculateRealmBasedDamage(target, originalDamage);
            
            // 确保至少造成1点伤害（除非已达到伤害上限）
            actualDamage = Mathf.Max(0, actualDamage);
            
            // 应用实际伤害
            if (actualDamage > 0 && targetHealthBeforeDamage > 0)
            {
                int damageToApply = Mathf.Min(Mathf.RoundToInt(actualDamage), Mathf.RoundToInt(targetHealthBeforeDamage));
                target.restoreHealth(-damageToApply);
            }
            
            // 更新1秒内受到的伤害总量
            target.UpdateDamageInLastSecond(actualDamage);
            
            // 检查天使之王杀死本途径对手后获取被占据特质的逻辑
            // 条件1: 攻击者是天使之王（拥有XuLie92特质）
            // 条件2: 被攻击的目标与攻击者是同一途径
            // 条件3: 这次攻击导致目标死亡
            if (attacker.hasTrait("XuLie92") && 
                !string.IsNullOrEmpty(GetActorPathway(attacker)) && 
                GetActorPathway(attacker) == GetActorPathway(target) &&
                targetHealthBeforeDamage > 0 && target.data.health <= 0)
            {
                // 目标因本次攻击死亡，处理天使之王获取被占据特质的逻辑
                HandleArchangelTraitAcquisition(attacker, target);
            }
        }
        
        // 序列九XuLie2~序列五XuLie6：造成1倍灵性的真实伤害，没有特效
        public static bool TrueDamageByLingXing1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 获取攻击者的灵性值
                float lingXing = attacker.GetXuLie();
                
                // 计算1倍灵性的真实伤害
                int trueDamage = Mathf.RoundToInt(lingXing * 1f);
                
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                
                // 没有特效
            }
            return false;
        }
        
        // 序列四XuLie7~序列三XuLie8：造成10倍灵性的真实伤害，没有特效
        public static bool TrueDamageByLingXing10_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 获取攻击者的灵性值
                float lingXing = attacker.GetXuLie();
                
                // 计算10倍灵性的真实伤害
                int trueDamage = Mathf.RoundToInt(lingXing * 10f);
                
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                
                // 没有特效
            }
            return false;
        }
        
        // 序列二XuLie9~天使之王XuLie91：造成100倍灵性的真实伤害，没有特效
        public static bool TrueDamageByLingXing100_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 获取攻击者的灵性值
                float lingXing = attacker.GetXuLie();
                
                // 计算100倍灵性的真实伤害
                int trueDamage = Mathf.RoundToInt(lingXing * 100f);
                
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                
                // 没有特效
            }
            return false;
        }
        
        // 真神XuLie93：造成1000倍灵性的真实伤害，没有特效
        public static bool TrueDamageByLingXing1000_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 获取攻击者的灵性值
                float lingXing = attacker.GetXuLie();
                
                // 计算1000倍灵性的真实伤害
                int trueDamage = Mathf.RoundToInt(lingXing * 1000f);
                
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                
                // 没有特效
            }
            return false;
        }
        
        // 旧日XuLie94：造成3000倍灵性的真实伤害，没有特效
        public static bool TrueDamageByLingXing3000_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 获取攻击者的灵性值
                float lingXing = attacker.GetXuLie();
                
                // 计算3000倍灵性的真实伤害
                int trueDamage = Mathf.RoundToInt(lingXing * 3000f);
                
                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                
                // 没有特效
            }
            return false;
        }
        
        // 处理天使之王杀死本途径对手后获取被占据特质的逻辑
        private static void HandleArchangelTraitAcquisition(Actor archangel, Actor deceased)
        {
            if (archangel == null || deceased == null)
                return;
            
            // 检查并获取唯一性特质
            deceased.data.get("uniqueness", out string uniqueness, "");
            if (!string.IsNullOrEmpty(uniqueness) && !archangel.hasTrait(uniqueness))
            {
                // 为天使之王添加唯一性特质
                archangel.addTrait(uniqueness);
                archangel.data.set("uniqueness", uniqueness);
                
                // 更新唯一性持有者记录
                _uniquenessOwners[uniqueness] = archangel;
                
                // 显示获得唯一性的通知
                string uniquenessName = NotificationHelper.GetUniquenessName(uniqueness);
                NotificationHelper.ShowNotification(archangel, $"{archangel.getName()}杀死了{deceased.getName()}，获得了唯一性: {uniquenessName}！");
            }
            
            // 检查并获取序列一特性（XulieTexing9, XulieTexing91, XulieTexing92）
            string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            foreach (string trait in sequenceOneTraits)
            {
                if (deceased.hasTrait(trait) && !archangel.hasTrait(trait))
                {
                    archangel.addTrait(trait);
                    NotificationHelper.ShowNotification(archangel, $"{archangel.getName()}杀死了{deceased.getName()}，获得了特质: {trait}！");
                }
            }
        }
        
        // 原有真实伤害方法 - 保留但不再使用于序列等级的灵性伤害
        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 武域境(XuLie9)、合道境(XuLie91)、斩我境(XuLie92)、武极境(XuLie93)均无视此真伤
                if (targetActor.hasTrait("XuLie9") || targetActor.hasTrait("XuLie91") || 
                    targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.09f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 序列二_天使(XuLie9)、序列一_天使(XuLie91)、天使之王(XuLie92)、真神(XuLie93)均无视此真伤
                if (targetActor.hasTrait("XuLie9") || targetActor.hasTrait("XuLie91") || 
                    targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.1f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.06f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (targetActor.hasTrait("XuLie91") || targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.11f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.07f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 天使之王(XuLie92)、真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie92") || targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.12f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.08f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.13f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 真神(XuLie93)无视此真伤
                if (targetActor.hasTrait("XuLie93") || targetActor.hasTrait("XuLie94"))
                {
                    return false;
                }
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.14f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }

        
        // 唯一性真实伤害方法：拥有WeiYixing特质的角色造成10倍攻击的真实伤害，单次攻击一个目标，雷电特效，攻击速度快
        public static bool TrueDamageByWeiYixing_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf.isActor() && pTarget != null && pTarget.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 检查攻击者是否拥有WeiYixing系列特质之一
                bool hasWeiYixing = false;
                for (int i = 1; i <= 11; i++)
                {
                    if (attacker.hasTrait("WeiYixing" + i))
                    {
                        hasWeiYixing = true;
                        break;
                    }
                }
                
                // 检查带+的WeiYixing系列特质
                for (int i = 1; i <= 11; i++)
                {
                    if (attacker.hasTrait("WeiYixing" + i + "+"))
                    {
                        hasWeiYixing = true;
                        break;
                    }
                }
                
                if (hasWeiYixing && pTile != null)
                {
                    // 获取攻击者的攻击力
                    float attackDamage = attacker.stats["damage"];
                    
                    // 计算真实伤害：10倍攻击
                    int baseTrueDamage = Mathf.RoundToInt(attackDamage * 10f);
                    
                    // 计算最终伤害，添加±10%的随机波动
                    float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
                    int finalTrueDamage = Mathf.RoundToInt(baseTrueDamage * randomFactor);
                    
                    // 确保至少造成1点伤害
                    if (finalTrueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(finalTrueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                    
                    // 添加增强的雷电特效
                    // 已禁用雷电特效
                    // AssetManager.terraform.get("lightning_normal").apply_force = false;
                    // MapBox.spawnLightningMedium(pTile, 0.8f);
                    // 已禁用目标闪电特效
                }
            }
            return false;
        }
        
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.15f); 

                // 确保至少造成1点伤害
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                // 已禁用雷电特效
                // AssetManager.terraform.get("lightning_normal").apply_force = false;
                // MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }

        public static bool fire1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_bomb_flash", pTile,"Bomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool fire2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile,"NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool TrueDamageByXuLie1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的20%作为基础伤害）
            float baseDamage = xuLieValue * 0.2f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("XuLie93")) // 真神减免90%伤害
                trueDamage = (int)(trueDamage * 0.1f);
            else if (targetActor.hasTrait("XuLie92")) // 天使之王减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
            else if (targetActor.hasTrait("XuLie94")) // 天使之王减免50%伤害
                trueDamage = (int)(trueDamage * 0.1f);
    
            // 6. 施加真实伤害（无视防御）
            if (targetActor.data.health > trueDamage)
            {
                targetActor.restoreHealth(-trueDamage);
            }

            // 已禁用雷电特效
            // AssetManager.terraform.get("lightning_normal").apply_force = false;
            // MapBox.spawnLightningMedium(pTile, 0.16f);
    
            return true;
        }

        public static bool TrueDamageByXuLie2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的30%作为基础伤害）
            float baseDamage = xuLieValue * 0.3f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 特殊规则：根据敌人境界减免伤害
            if (targetActor.hasTrait("XuLie93")) // 真神减免50%伤害
                trueDamage = (int)(trueDamage * 0.5f);
            else if (targetActor.hasTrait("XuLie94")) // 旧日减免90%伤害
                trueDamage = (int)(trueDamage * 0.1f);
    
            // 6. 施加真实伤害（无视防御）并应用位格免伤
            if (trueDamage > 0 && targetActor.data.health > 0)
            {
                ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
            }

            // 已禁用雷电特效
            // AssetManager.terraform.get("lightning_normal").apply_force = false;
            // MapBox.spawnLightningMedium(pTile, 0.32f);
    
            return true;
        }

        public static bool TrueDamageByXuLie3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 1. 检查目标是否有效（存在且是生物单位）
            if (pTarget == null || !pTarget.isActor() || pSelf == null || !pSelf.isActor()) 
                return false;
    
            Actor attacker = pSelf.a;
            Actor targetActor = pTarget.a;
    
            // 2. 获取攻击者的序列值
            float xuLieValue = attacker.GetXuLie();
    
            // 3. 计算真实伤害（示例：序列值的50%作为基础伤害）
            float baseDamage = xuLieValue * 0.5f;
    
            // 4. 添加伤害波动（±10%随机波动）
            float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
            int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
            // 5. 施加真实伤害（无视防御）并应用位格免伤
            if (trueDamage > 0 && targetActor.data.health > 0)
            {
                ApplyTrueDamageWithRealmProtection(attacker, targetActor, trueDamage);
            }

            // 已禁用雷电特效
            // AssetManager.terraform.get("lightning_normal").apply_force = false;
            // MapBox.spawnLightningMedium(pTile, 0.64f);
    
            return true;
        }

        public static bool MartialGodTrueDamage_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 2. 获取攻击者的序列值
                float xuLieValue = attacker.GetXuLie();
    
                // 3. 计算真实伤害（示例：序列值的500%作为基础伤害）
                float baseDamage = xuLieValue * 5f;
    
                // 4. 添加伤害波动（±10%随机波动）
                float randomFactor = UnityEngine.Random.Range(0.9f, 1.1f);
                int trueDamage = Mathf.RoundToInt(baseDamage * randomFactor);
    
                // 5. 施加真实伤害（无视防御）
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                else
               {
                    // 如果伤害超过目标血量，直接击杀
                    targetActor.restoreHealth(-targetActor.data.health);
                }
            }

            return false;
        }

        public static bool MaintainFullNutrition(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor actor = pTarget.a;
                if (actor.hasTrait("XuLie91") || 
                    actor.hasTrait("XuLie92") ||
                    actor.hasTrait("XuLie93") ||
                    actor.hasTrait("XuLie94"))
                {
                    // 保持饱食度100%
                    actor.data.nutrition = 100;
                }
            }
            return true;
        }      

        public static bool XuLie1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "XuLie2", "XuLie3", "XuLie4", "XuLie5", "XuLie6", "XuLie7", "XuLie8", "XuLie9", "XuLie91", "XuLie92", "XuLie93", "XuLie94" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }
            
            upTrait(
                "", // 没有旧特质需要移除
                "XuLie1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "XuLie1+" }
            );
            // 先增加理智，确保有足够的理智
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie1");

            return true;
        }

        public static bool XuLie2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetXuLie() <= 9.99)
            {
                return false;
            }
            
            // 添加拥有XuLie1和MoYao1的条件
            if (!a.hasTrait("XuLie1") || !a.hasTrait("MoYao1"))
            {
                // 检测序列九魔药失败，尝试合成序列九魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie2");
                return false;
            }

            a.ChangeXuLie(-2);
            double successRate = 0.8;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao1"))
                {
                    a.removeTrait("MoYao1");
                }
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "XuLie1",
                "XuLie2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "XuLie2+" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie2");
            ApplyXuLieTitle(a, "XuLie2");

            // 移除序列九魔药
            if (a.hasTrait("MoYao1"))
            {
                a.removeTrait("MoYao1");
            }
            
            // 添加序列九特性
            a.addTrait("XulieTexing1");
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            return true;
        }

        public static bool XuLie3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查序列值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 8)
            {
                // 添加XuLie1特质
                upTrait("特质", "XuLie1", a, new string[] { "XuLie2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 19.99)
            {
                return false;
            }
            
            // 添加拥有XuLie2和MoYao2的条件
            if (!a.hasTrait("XuLie2") || !a.hasTrait("MoYao2"))
            {
                // 检测序列八魔药失败，尝试合成序列八魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie3");
                return false;
            }

            a.ChangeXuLie(-2);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao2"))
                {
                    a.removeTrait("MoYao2");
                }
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "XuLie2",
                "XuLie3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie2+"
                },
                new string[] { "XuLie3+", selectedTrait }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie3");
            ApplyXuLieTitle(a, "XuLie3");

            // 移除序列八魔药
            if (a.hasTrait("MoYao2"))
            {
                a.removeTrait("MoYao2");
            }
            
            // 添加序列八特性
            a.addTrait("XulieTexing2");
            // 移除序列九特性
            if (a.hasTrait("XulieTexing1"))
            {
                a.removeTrait("XulieTexing1");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            return true;
        }

        public static bool XuLie4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 18)
            {
                upTrait("特质", "XuLie2", a, new string[] { "XuLie3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 39.99)
            {
                return false;
            }
            
            // 添加拥有XuLie3和MoYao3的条件
            if (!a.hasTrait("XuLie3") || !a.hasTrait("MoYao3"))
            {
                // 检测序列七魔药失败，尝试合成序列七魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie4");
                return false;
            }

            a.ChangeXuLie(-3);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao3"))
                {
                    a.removeTrait("MoYao3");
                }
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "XuLie3",
                "XuLie4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie3+"
                },
                new string[] { "XuLie4+" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie4");
            ApplyXuLieTitle(a, "XuLie4");

            // 移除序列七魔药
            if (a.hasTrait("MoYao3"))
            {
                a.removeTrait("MoYao3");
            }
            
            // 添加序列七特性
            a.addTrait("XulieTexing3");
            // 移除序列八特性
            if (a.hasTrait("XulieTexing2"))
            {
                a.removeTrait("XulieTexing2");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }
            return true;
        }

        public static bool XuLie5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 37)
            {
                upTrait("特质", "XuLie3", a, new string[] { "XuLie4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 79.99)
            {
                return false;
            }
            
            // 添加拥有XuLie4和MoYao4的条件
            if (!a.hasTrait("XuLie4") || !a.hasTrait("MoYao4"))
            {
                // 检测序列六魔药失败，尝试合成序列六魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie5");
                return false;
            }

            a.ChangeXuLie(-4);
            double successRate = 0.6;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 1.0;
            }


            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao4"))
                {
                    a.removeTrait("MoYao4");
                }
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "XuLie4",
                "XuLie5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie4+"
                },
                (selectedTrait != null) ?
                new string[] { "XuLie5+", selectedTrait } :
                new string[] { "XuLie5+" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie5");
            ApplyXuLieTitle(a, "XuLie5");

            // 移除序列六魔药
            if (a.hasTrait("MoYao4"))
            {
                a.removeTrait("MoYao4");
            }
            
            // 添加序列六特性
            a.addTrait("XulieTexing4");
            // 移除序列七特性
            if (a.hasTrait("XulieTexing3"))
            {
                a.removeTrait("XulieTexing3");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }
            return true;
        }

        public static bool XuLie6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetXuLie() < 76)
            {
                upTrait("特质", "XuLie4", a, new string[] { "XuLie5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetXuLie() <= 159.99)
            {
                return false;
            }
            
            // 添加拥有XuLie5和MoYao5的条件
            if (!a.hasTrait("XuLie5") || !a.hasTrait("MoYao5"))
            {
                // 检测序列五魔药失败，尝试合成序列五魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie6");
                return false;
            }

            a.ChangeXuLie(-5);
            double successRate = 0.1;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao5"))
                {
                    a.removeTrait("MoYao5");
                }
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "XuLie5",
                "XuLie6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "XuLie5+"
                },
                (selectedTrait != null) ?
                new string[] { "XuLie6+", "freeze_proof", "fire_proof", "chaofanXuemai1", selectedTrait } :
                new string[] { "XuLie6+", "freeze_proof", "fire_proof" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            UpdateNameSuffix(a, "XuLie6");
            ApplyXuLieTitle(a, "XuLie6");

            // 移除序列五魔药
            if (a.hasTrait("MoYao5"))
            {
                a.removeTrait("MoYao5");
            }
            
            // 添加序列五特性
            a.addTrait("XulieTexing5");
            // 移除序列六特性
            if (a.hasTrait("XulieTexing4"))
            {
                a.removeTrait("XulieTexing4");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }
            return true;
        }

        public static bool XuLie7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界

            if (a.GetXuLie() <= 299.99)
            {
                return false;
            }
            
            // 添加拥有XuLie6和MoYao6的条件
            if (!a.hasTrait("XuLie6") || !a.hasTrait("MoYao6"))
            {
                // 检测序列四魔药失败，尝试合成序列四魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie7");
                return false;
            }

            a.ChangeXuLie(-50);
            double successRate = 0.1;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao6"))
                {
                    a.removeTrait("MoYao6");
                }
                return false;
            }

            upTrait(
                "XuLie6",
                "XuLie7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie6+", "chaofanXuemai1" },
                new string[] { "XuLie7+", "chaofanXuemai2", "tough" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            // 先进行相邻途径判定
            ApplyXuLieTitle(a, "XuLie7");
            // 再更新名称后缀
            UpdateNameSuffix(a, "XuLie7");

            // 移除序列四魔药
            if (a.hasTrait("MoYao6"))
            {
                a.removeTrait("MoYao6");
            }
            
            // 添加序列四特性
            a.addTrait("XulieTexing6");
            // 移除序列五特性
            if (a.hasTrait("XulieTexing5"))
            {
                a.removeTrait("XulieTexing5");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }

            // 如果拥有魔女序列TeXing1+特质，并且是女性，则变成男性
            if (a.hasTrait("TeXing1+"))
            {
                if (a.data.sex == ActorSex.Female)
                {
                    a.data.sex = ActorSex.Male;
                }
            }
            
            
            return true;
        }

        public static bool XuLie8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 499.99)
            {
                return false;
            }
            
            // 添加拥有XuLie7和MoYao7的条件
            if (!a.hasTrait("XuLie7") || !a.hasTrait("MoYao7"))
            {
                // 检测序列三魔药失败，尝试合成序列三魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie8");
                return false;
            }

            a.ChangeXuLie(-100);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao7"))
                {
                    a.removeTrait("MoYao7");
                }
                return false;
            }

            upTrait(
                "XuLie7",
                "XuLie8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie7+", "chaofanXuemai2" },
                new string[] { "XuLie8+", "strong_minded", "immune", "chaofanXuemai3" }
            );
            a.ChangeLiZhi(100); // 晋升增加100点理智
            // 先进行相邻途径判定
            ApplyXuLieTitle(a, "XuLie8");
            // 再更新名称后缀
            UpdateNameSuffix(a, "XuLie8");

            // 移除序列三魔药
            if (a.hasTrait("MoYao7"))
            {
                a.removeTrait("MoYao7");
            }
            
            // 添加序列三特性
            a.addTrait("XulieTexing7");
            // 移除序列四特性
            if (a.hasTrait("XulieTexing6"))
            {
                a.removeTrait("XulieTexing6");
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }

            // 如果拥有魔女序列TeXing1+特质，并且是女性，则变成男性
            if (a.hasTrait("TeXing1+"))
            {
                if (a.data.sex == ActorSex.Female)
                {
                    a.data.sex = ActorSex.Male;
                }
            }
            
            
            return true;
        }

        public static bool XuLie9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 799.99)
            {
                return false;
            }
            
            // 添加拥有XuLie8和MoYao8的条件
            if (!a.hasTrait("XuLie8") || !a.hasTrait("MoYao8"))
            {
                // 检测序列二魔药失败，尝试合成序列二魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie9");
                return false;
            }

            a.ChangeXuLie(-200);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.05; 
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.8;
            }


            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao8"))
                {
                    a.removeTrait("MoYao8");
                }
                return false;
            }

            // 检查是否可以晋升到序列二
            if (!CanPromoteToHighSequence(a, "XuLie9"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie91"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                }
            }
            if (a.hasTrait("XuLie92"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie8",
                "XuLie9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie8+", "chaofanXuemai3" },
                new string[] { "XuLie9+" ,"fire_proof", "regeneration", "chaofanXuemai4"}
            );
            a.ChangeLiZhi(100);
            // 先进行相邻途径判定
            ApplyXuLieTitle(a, "XuLie9");
            // 再更新名称后缀
            UpdateNameSuffix(a, "XuLie9");
            
            // 移除序列二魔药
            if (a.hasTrait("MoYao8"))
            {
                a.removeTrait("MoYao8");
            }
            
            // 添加序列二特性
            a.addTrait("XulieTexing8");
            // 移除序列三特性
            if (a.hasTrait("XulieTexing7"))
            {
                a.removeTrait("XulieTexing7");
            }
            
            a.data.favorite = true;

            // 更新高序列计数
            string actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie9", 1);
            }
            
            // 删除灵性衰败
            if (a.hasTrait("jinSheng10"))
            {
                a.removeTrait("jinSheng10");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }

            // 如果拥有魔女序列TeXing1+特质，并且是女性，则变成男性
            if (a.hasTrait("TeXing1+"))
            {
                if (a.data.sex == ActorSex.Female)
                {
                    a.data.sex = ActorSex.Male;
                }
            }
            
            
            return true;
        }

        public static bool XuLie91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 1199.99)
            {
                return false;
            }
            
            // 添加拥有XuLie9和MoYao9的条件
            if (!a.hasTrait("XuLie9") || !a.hasTrait("MoYao9"))
            {
                // 检测序列一魔药失败，尝试合成序列一魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie91");
                return false;
            }

            a.ChangeXuLie(-300);
            double successRate = 0.08;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.3;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao9"))
                {
                    a.removeTrait("MoYao9");
                }
                return false;
            }

            // 获取角色途径并检查本途径是否已有真神
            string pathway = GetActorPathway(a);
            if (pathway != null && _pathwayHighSequenceCounts.ContainsKey(pathway) && _pathwayHighSequenceCounts[pathway]["XuLie93"] > 0)
            {
                NotificationHelper.ShowNotification(a, $"{a.getName()}因为途径已有真神，无法晋升序列一！");
                return false;
            }

            // 检查是否可以晋升到序列一
            if (!CanPromoteToHighSequence(a, "XuLie91"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie9", -1);
                }
            }
            if (a.hasTrait("XuLie92"))
            {
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie92", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie9",
                "XuLie91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie9+", "chaofanXuemai4" },
                new string[] { "XuLie91+", "chaofanXuemai5" }
            );
            a.ChangeLiZhi(100);
            // XuLie91及以上无法进行相邻途径转换
            ApplyXuLieTitle(a, "XuLie91");
            // 再更新名称后缀
            UpdateNameSuffix(a, "XuLie91");
            
            // 移除序列一魔药
            if (a.hasTrait("MoYao9"))
            {
                a.removeTrait("MoYao9");
            }

            // 如果拥有魔女序列TeXing2+特质，并且是男性，则变成女性
            if (a.hasTrait("TeXing2+"))
            {
                if (a.data.sex == ActorSex.Male)
                {
                    a.data.sex = ActorSex.Female;
                }
            }

            // 如果拥有魔女序列TeXing1+特质，并且是女性，则变成男性
            if (a.hasTrait("TeXing1+"))
            {
                if (a.data.sex == ActorSex.Female)
                {
                    a.data.sex = ActorSex.Male;
                }
            }
            // 获取角色的TeXing特质
            string texingTrait = GetActorTeXingTrait(a);
            if (string.IsNullOrEmpty(texingTrait))
            {
                // 如果角色没有TeXing特质，使用默认的随机选择逻辑
                string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
                string randomTrait = sequenceOneTraits[UnityEngine.Random.Range(0, sequenceOneTraits.Length)];
                a.addTrait(randomTrait);
            }
            else
            {
                // 检查可用的序列一特性（未被其他角色与相同TeXing特质组合持有的特性）
                List<string> availableTraits = new List<string>();
                string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
                
                foreach (string trait in sequenceOneTraits)
                {
                    string key = texingTrait + trait;
                    if (!_texingSequenceOneOwners.ContainsKey(key) || _texingSequenceOneOwners[key] == a)
                    {
                        availableTraits.Add(trait);
                    }
                }
                
                if (availableTraits.Count > 0)
                {
                    // 从可用特性中随机选择一个
                    string selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
                    a.addTrait(selectedTrait);
                    
                    // 更新组合持有者记录
                    string key = texingTrait + selectedTrait;
                    _texingSequenceOneOwners[key] = a;
                }
                else
                {
                    // 如果没有可用特性，显示通知
                    NotificationHelper.ShowNotification(a, $"{a.getName()}无法获得序列一特性，所有{texingTrait}途径的序列一特性组合已被持有！");
                }
            }
            
            // 移除序列二特性
            if (a.hasTrait("XulieTexing8"))
            {
                a.removeTrait("XulieTexing8");
            }

            // 显示突破通知，参数为角色对象、当前特质(XuLie9)和突破后特质(XuLie91)
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie9", "XuLie91"); // 参数名已更新为 oldTraitId 和 newTraitId，但调用时参数位置不变
            // 将角色标记为收藏状态
            a.data.favorite = true;

            // 更新高序列计数
            string actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie91", 1);
                
                // 检查晋升后途径是否存在真神
                if (_pathwayHighSequenceCounts.ContainsKey(actorPathway) && 
                    _pathwayHighSequenceCounts[actorPathway].ContainsKey("XuLie93") && 
                    _pathwayHighSequenceCounts[actorPathway]["XuLie93"] > 0)
                {
                    // 如果存在真神，执行降级操作
                    DemoteHighSequenceActors(actorPathway);
                }
            }

            
            return true;
        }

        public static bool XuLie92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetXuLie() <= 3599.99)
            {
                return false;
            }
            
            // 添加拥有XuLie91的条件，并且添加天使之王晋升的多条件检查
            if (!a.hasTrait("XuLie91"))
            {
                return false;
            }
            
            // 天使之王晋升多条件检查
            bool hasRequiredTraits = false;
            // 获取角色拥有的序列一特性数量
            int sequenceOneTraitsCount = 0;
            if (a.hasTrait("XulieTexing9")) sequenceOneTraitsCount++;
            if (a.hasTrait("XulieTexing91")) sequenceOneTraitsCount++;
            if (a.hasTrait("XulieTexing92")) sequenceOneTraitsCount++;
            
            // 获取角色是否拥有本途径唯一性
            string actorPathway = GetActorPathway(a);
            bool hasPathwayUniqueness = false;
            if (!string.IsNullOrEmpty(actorPathway))
            {
                // 检查是否拥有WeiYixing系列的本途径唯一性特质
                for (int i = 1; i <= 11; i++)
                {
                    if (a.hasTrait($"WeiYixing{i}") || a.hasTrait($"WeiYixing{i}+"))
                    {
                        hasPathwayUniqueness = true;
                        break;
                    }
                }
            }
            
            // 条件1：三个序列一特性
            if (sequenceOneTraitsCount >= 3)
            {
                hasRequiredTraits = true;
            }
            // 条件2：任意2个序列一特性
            else if (sequenceOneTraitsCount >= 2)
            {
                hasRequiredTraits = true;
            }
            // 条件3：任意1个序列一特性+本途径唯一性
            else if (sequenceOneTraitsCount >= 1 && hasPathwayUniqueness)
            {
                hasRequiredTraits = true;
            }
            
            if (!hasRequiredTraits)
            {
                return false;
            }
            

            a.ChangeXuLie(-500);
            double successRate = 1.0;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.002;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.2;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            // 检查是否可以晋升到天使之王
            if (!CanPromoteToHighSequence(a, "XuLie92"))
            {
                return false;
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie9", -1);
                }
            }
            if (a.hasTrait("XuLie91"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie91", -1);
                }
            }
            if (a.hasTrait("XuLie93"))
            {
                string pathway = GetActorPathway(a);
                if (pathway != null)
                {
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                }
            }

            upTrait(
                "XuLie91",
                "XuLie92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie91+", "chaofanXuemai5" },
                new string[] { "XuLie92+", "chaofanXuemai6" }
            );
            a.ChangeLiZhi(100);
            List<string> grottoTraitIds = new List<string>
            {
                "WeiYixing1", "WeiYixing2", "WeiYixing3", "WeiYixing4",
                "WeiYixing5", "WeiYixing6", "WeiYixing7", "WeiYixing8",
                "WeiYixing9", "WeiYixing10", "WeiYixing11", "WeiYixing1+",
                "WeiYixing2+", "WeiYixing3+", "WeiYixing4+", "WeiYixing5+",
                "WeiYixing6+", "WeiYixing7+", "WeiYixing8+", "WeiYixing9+",
                "WeiYixing10+", "WeiYixing11+"
            };

            // 根据前缀获得对应唯一性 - XuLie92晋升不再自动获取唯一性
            string currentName = a.getName();
            int separatorIndex = currentName.IndexOf('|');
            if (separatorIndex > 0)
            {
                string prefix = currentName.Substring(0, separatorIndex).Trim();
            }
            
            // XuLie92及以上无法进行相邻途径转换
            ApplyXuLieTitle(a, "XuLie92");
            // 再更新名称后缀
            UpdateNameSuffix(a, "XuLie92");
            
            // 显示突破通知，参数为角色对象、当前特质(XuLie91)和突破后特质(XuLie92)
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie91", "XuLie92"); // 参数名已更新为 oldTraitId 和 newTraitId，但调用时参数位置不变
            // 将角色标记为收藏状态
            a.data.favorite = true;
            
            // 更新高序列计数
            actorPathway = GetActorPathway(a);
            if (actorPathway != null)
            {
                UpdateHighSequenceCount(actorPathway, "XuLie92", 1);
                
                // 检查是否有2位天使之王，如果有则降级序列一
                CheckAndDemoteSequenceOneWhenTwoArchangels(actorPathway);
                
                // 检查晋升后途径是否存在真神
                if (_pathwayHighSequenceCounts.ContainsKey(actorPathway) && 
                    _pathwayHighSequenceCounts[actorPathway].ContainsKey("XuLie93") && 
                    _pathwayHighSequenceCounts[actorPathway]["XuLie93"] > 0)
                {
                    // 如果存在真神，执行降级操作
                    DemoteHighSequenceActors(actorPathway);
                }
            }

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie91", "XuLie92"); // 参数名已更新为 oldTraitId 和 newTraitId，但调用时参数位置不变

            return true;
        }

        // 定义XuLie92晋升时的唯一性特质映射字典 - WeiYixing系列
        private static readonly Dictionary<string, string> _uniquenessMap = new Dictionary<string, string>
        {
            {"诡秘侍者", "WeiYixing1"},
            {"星之钥", "WeiYixing2"},
            {"时之虫", "WeiYixing3"},
            {"作家", "WeiYixing5"},
            {"雷神", "WeiYixing7"},
            {"纯白天使", "WeiYixing4"},
            {"全知之眼", "WeiYixing6"},
            {"暗天使", "WeiYixing8"},
            {"苍白皇帝", "WeiYixing4+"},
            {"厄难天使", "WeiYixing10"},
            {"神明之手", "WeiYixing11"},
            {"末日魔女", "WeiYixing2+"},
            {"征服者", "WeiYixing1+"},
            {"知识皇帝", "WeiYixing9+"},
            {"启蒙者", "WeiYixing10+"},
            {"水银之蛇", "WeiYixing11+"},
            {"自然行者", "WeiYixing3+"},
            {"美神", "WeiYixing9"},
            {"秩序之手", "WeiYixing6+"},
            {"弑序亲王", "WeiYixing5+"},
            {"神孽", "WeiYixing8+"},
            {"污秽君王", "WeiYixing7+"},
        };

        // 定义TeXing特质+序列一特性组合的持有者字典
        private static readonly Dictionary<string, Actor> _texingSequenceOneOwners = new Dictionary<string, Actor>();
        
        // 为旧日添加其持有的TeXing特质与XulieTexing9的唯一性限制
        private static void AddOldOneTexingSequenceOneCombinations(Actor a)
        {
            // 仅限制XulieTexing9的组合唯一性
            string sequenceOneTrait = "XulieTexing9";
            
            // 获取角色持有的所有TeXing特质
            List<string> texingTraits = new List<string>();
            foreach (var trait in a.getTraits())
            {
                // 检查是否是TeXing特质（名称以"TeXing"开头）
                if (trait.type.ToString().StartsWith("TeXing"))
                {
                    texingTraits.Add(trait.type.ToString());
                }
            }
            
            // 只为角色持有的TeXing特质与XulieTexing9添加唯一性限制
            foreach (string texingTrait in texingTraits)
            {
                string combinationKey = texingTrait + sequenceOneTrait;
                
                // 如果该组合已被其他角色持有，则强制夺取
                if (_texingSequenceOneOwners.ContainsKey(combinationKey))
                {
                    Actor oldOwner = _texingSequenceOneOwners[combinationKey];
                    if (oldOwner != null && oldOwner != a)
                    {
                        // 从旧持有者移除序列一特性
                        if (oldOwner.hasTrait(sequenceOneTrait))
                        {
                            oldOwner.removeTrait(sequenceOneTrait);
                            NotificationHelper.ShowNotification(oldOwner, $"由于{a.getName()}晋升为旧日，{oldOwner.getName()}失去了{sequenceOneTrait}特性！");
                        }
                    }
                }
                
                // 设置该组合的持有者为当前旧日
                _texingSequenceOneOwners[combinationKey] = a;
            }
        }

        // 清理角色持有的TeXing特质+序列一特性组合
        private static void CleanupTeXingSequenceOneOwnership(Actor actor)
        {
            List<string> keysToRemove = new List<string>();
            
            // 查找所有由该角色持有的组合
            foreach (var kvp in _texingSequenceOneOwners)
            {
                if (kvp.Value == actor)
                {
                    keysToRemove.Add(kvp.Key);
                }
            }
            
            // 从字典中移除这些组合
            foreach (string key in keysToRemove)
            {
                _texingSequenceOneOwners.Remove(key);
            }
        }

        // 处理角色降级后的特质清理和冲突检查
        public static void HandleActorDegradation(Actor a, string oldHighestTrait, string newHighestTrait)
        {
            if (a == null)
                return;

            string pathway = GetActorPathway(a);
            if (pathway == null)
                return;

            // 1. 更新高序列计数
            if (!string.IsNullOrEmpty(oldHighestTrait))
            {
                UpdateHighSequenceCount(pathway, oldHighestTrait, -1);
            }
            if (!string.IsNullOrEmpty(newHighestTrait))
            {
                UpdateHighSequenceCount(pathway, newHighestTrait, 1);
            }

            // 2. 移除不适合当前序列的特质
            // 对于从真神(XuLie93)降级的情况(无论是降级到序列二还是天使之王)
            if (oldHighestTrait == "XuLie93")
            {
                // 移除唯一性特质
                string[] uniquenessTraits = {
                    "WeiYixing1", "WeiYixing2", "WeiYixing3", "WeiYixing4", "WeiYixing5",
                    "WeiYixing6", "WeiYixing7", "WeiYixing8", "WeiYixing9", "WeiYixing10", "WeiYixing11",
                    "WeiYixing1+", "WeiYixing2+", "WeiYixing3+", "WeiYixing4+", "WeiYixing5+",
                    "WeiYixing6+", "WeiYixing7+", "WeiYixing8+", "WeiYixing9+", "WeiYixing10+", "WeiYixing11+"
                };

                // 先检查是否有其他高序列角色持有相同的唯一性特质
                string texingTrait = GetActorTeXingTrait(a);
                foreach (string trait in uniquenessTraits)
                {
                    if (a.hasTrait(trait))
                    {
                        // 检查是否有更高序列的角色持有相同的唯一性
                        if (HasHigherSequenceActorWithTrait(trait, a))
                        {
                            a.removeTrait(trait);
                            string uniquenessName = NotificationHelper.GetUniquenessName(trait);
                            NotificationHelper.ShowNotification(a, $"{a.getName()}因降级失去唯一性特质：{uniquenessName}");
                        }
                    }
                }

                // 3. 检查并处理TeXing+序列一特性组合冲突
                CheckAndHandleTexingSequenceOneConflicts(a, texingTrait);
            }
        }

        // 检查是否有更高序列的角色持有指定特质
        private static bool HasHigherSequenceActorWithTrait(string trait, Actor currentActor)
        {
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (actor == currentActor || !actor.isAlive())
                    continue;

                // 检查角色是否持有指定特质
                if (actor.hasTrait(trait))
                {
                    // 比较序列层级，高序列优先
                    int currentActorLevel = GetActorHighestSequenceLevel(currentActor);
                    int otherActorLevel = GetActorHighestSequenceLevel(actor);

                    if (otherActorLevel > currentActorLevel)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        // 获取角色的最高序列层级
        private static int GetActorHighestSequenceLevel(Actor actor)
        {
            if (actor.hasTrait("XuLie94")) return 5; // 旧日
            if (actor.hasTrait("XuLie93")) return 4; // 真神
            if (actor.hasTrait("XuLie92")) return 3; // 天使之王
            if (actor.hasTrait("XuLie91")) return 2; // 序列一
            if (actor.hasTrait("XuLie9")) return 1;  // 序列二
            return 0; // 低序列
        }

        // 检查并处理TeXing+序列一特性组合冲突
        private static void CheckAndHandleTexingSequenceOneConflicts(Actor a, string texingTrait)
        {
            if (string.IsNullOrEmpty(texingTrait))
                return;

            // 清理当前角色的所有TeXing+序列一特性组合记录
            CleanupTeXingSequenceOneOwnership(a);

            // 检查当前角色持有的序列一特性
            string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            foreach (string trait in sequenceOneTraits)
            {
                if (a.hasTrait(trait))
                {
                    string key = texingTrait + trait;
                    // 检查是否有更高序列的角色持有相同的组合
                    if (HasHigherSequenceActorWithTexingSequenceOneCombination(texingTrait, trait, a))
                    {
                        a.removeTrait(trait);
                        NotificationHelper.ShowNotification(a, $"{a.getName()}因降级失去序列一特性：{trait}");
                    }
                    else
                    {
                        // 如果没有冲突，重新注册组合
                        _texingSequenceOneOwners[key] = a;
                    }
                }
            }
        }

        // 检查是否有更高序列的角色持有相同的TeXing+序列一特性组合
        private static bool HasHigherSequenceActorWithTexingSequenceOneCombination(string texingTrait, string sequenceOneTrait, Actor currentActor)
        {
            // 检查所有角色，而不仅仅是字典中注册的角色
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (actor == currentActor || !actor.isAlive())
                    continue;

                // 检查角色是否同时持有相同的TeXing特质和序列一特性
                if (actor.hasTrait(texingTrait) && actor.hasTrait(sequenceOneTrait))
                {
                    int currentActorLevel = GetActorHighestSequenceLevel(currentActor);
                    int otherActorLevel = GetActorHighestSequenceLevel(actor);

                    if (otherActorLevel > currentActorLevel)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        // 处理高序列角色死亡的方法
        public static void HandleHighSequenceDeath(Actor a)
        {
            if (a == null)
                return;

            string pathway = GetActorPathway(a);
            if (pathway == null)
                return;

            // 真神以上复活机制：消耗5理智复活
            // 添加检查确保角色确实处于死亡状态
            if ((a.hasTrait("XuLie93") || a.hasTrait("XuLie94")) && !a.hasHealth())
            {
                if (a.GetLiZhi() >= 5)
                {
                    // 消耗5理智
                    a.ChangeLiZhi(-5);
                    
                    // 恢复生命值
                    float maxHealth = a.stats[strings.S.health];
                    a.restoreHealth((int)maxHealth);
                    
                    // 根据途径显示独特的复活通知
                    string resurrectionPathway = pathway; // 直接使用方法级别的pathway变量
                    string resurrectionMessage = "{0}消耗5理智成功复活！";
                    if (resurrectionPathway != null && _pathwayResurrectionMessages.ContainsKey(resurrectionPathway))
                    {
                        resurrectionMessage = _pathwayResurrectionMessages[resurrectionPathway];
                    }
                    NotificationHelper.ShowNotification(a, string.Format(resurrectionMessage, a.getName()));
                    
                    // 不执行后续的死亡处理逻辑
                    return;
                }
                else
                {
                    // 根据途径显示独特的无法复活通知
                    string failPathway = GetActorPathway(a);
                    string failMessage = "{0}理智不足5，无法复活！";
                    if (failPathway != null && _pathwayResurrectionFailMessages.ContainsKey(failPathway))
                    {
                        failMessage = _pathwayResurrectionFailMessages[failPathway];
                    }
                    NotificationHelper.ShowNotification(a, string.Format(failMessage, a.getName()));
                    // 继续执行正常的死亡处理
                }
            } 
            
            // 清理角色持有的TeXing特质+序列一特性组合
            CleanupTeXingSequenceOneOwnership(a);

            // 检查角色类型并执行相应的死亡处理
            if (a.hasTrait("XuLie94"))
            {
                // 释放所有唯一性
                List<string> ownedUniqueness = new List<string>();
                foreach (var kvp in _uniquenessOwners)
                {
                    if (kvp.Value == a)
                    {
                        ownedUniqueness.Add(kvp.Key);
                    }
                }
                
                foreach (string uniqueness in ownedUniqueness)
                {
                    a.removeTrait(uniqueness);
                    a.data.set("uniqueness", null);
                    _uniquenessOwners.Remove(uniqueness);
                    string uniquenessName = NotificationHelper.GetUniquenessName(uniqueness);
                    NotificationHelper.ShowNotification(null, $"{a.getName()}死亡，唯一性 {uniquenessName} 已释放");
                }
                
                // 释放所有源质
                List<string> ownedSourceQualities = new List<string>();
                foreach (var kvp in _sourceQualityOwners)
                {
                    if (kvp.Value == a)
                    {
                        ownedSourceQualities.Add(kvp.Key);
                    }
                }
                
                foreach (string sourceQuality in ownedSourceQualities)
                {
                    a.removeTrait(sourceQuality);
                    a.data.set("sourceQuality", null);
                    _sourceQualityOwners.Remove(sourceQuality);
                    // 源质名称映射
                    Dictionary<string, string> sourceQualityNames = new Dictionary<string, string>
                    {
                        {"NineYuanZhi1", "混沌海"},
                        {"NineYuanZhi2", "源堡"},
                        {"NineYuanZhi3", "母巢"},
                        {"NineYuanZhi4", "永暗之河"},
                        {"NineYuanZhi5", "灾祸之城"},
                        {"NineYuanZhi6", "失序之国"},
                        {"NineYuanZhi7", "知识荒野"},
                        {"NineYuanZhi8", "光之钥"},
                        {"NineYuanZhi9", "暗影世界"}
                    };
                    string sourceQualityName = sourceQualityNames.TryGetValue(sourceQuality, out string name) ? name : sourceQuality;
                    NotificationHelper.ShowNotification(null, $"{a.getName()}死亡，源质 {sourceQualityName} 已释放");
                }
                
                // 彻底死亡之后，更新旧日计数
                UpdateHighSequenceCount(pathway, "XuLie94", -1);
                
                // 提前返回，避免重复处理
                return;
            }
            else if (a.hasTrait("XuLie93"))
            {
                // 释放源质
                a.data.get("sourceQuality", out string sourceQuality, null);
                if (!string.IsNullOrEmpty(sourceQuality) && _sourceQualityOwners.ContainsKey(sourceQuality) && _sourceQualityOwners[sourceQuality] == a)
                {
                    a.removeTrait(sourceQuality);
                    a.data.set("sourceQuality", null);
                    _sourceQualityOwners.Remove(sourceQuality);
                    NotificationHelper.ShowNotification(null, $"{a.getName()}死亡，源质已释放");
                }
                
                // 彻底死亡之后，更新真神计数
                UpdateHighSequenceCount(pathway, "XuLie93", -1);
            }
            else if (a.hasTrait("XuLie92"))
            {
                // 天使之王死亡，更新计数
                UpdateHighSequenceCount(pathway, "XuLie92", -1);
            }
            else if (a.hasTrait("XuLie91"))
            {
                // 序列一死亡，更新计数
                UpdateHighSequenceCount(pathway, "XuLie91", -1);
            }
            else if (a.hasTrait("XuLie9"))
            {
                // 序列二死亡，更新计数
                UpdateHighSequenceCount(pathway, "XuLie9", -1);
            }

            // 释放唯一性特质
            a.data.get("uniqueness", out string singleUniqueness, null);
            if (!string.IsNullOrEmpty(singleUniqueness) && _uniquenessOwners.ContainsKey(singleUniqueness) && _uniquenessOwners[singleUniqueness] == a)
            {
                a.removeTrait(singleUniqueness);
                a.data.set("uniqueness", null);
                _uniquenessOwners.Remove(singleUniqueness);
                string uniquenessName = NotificationHelper.GetUniquenessName(singleUniqueness);
                NotificationHelper.ShowNotification(null, $"{a.getName()}死亡，唯一性 {uniquenessName} 已释放");
            }
        }

        public static bool XuLie93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetXuLie() <= 9999.99)
            {
                return false;
            }
            
            // 添加拥有MoYao91的条件
            if (!a.hasTrait("MoYao91"))
            {
                // 检测序列零魔药失败，尝试合成序列零魔药
                MoYaoCrafting.CheckMoYaoOnPromotion(a, "XuLie93");
                return false;
            }

            a.ChangeXuLie(-1000);
            double successRate = 0.01;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.5;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                // 突破失败，移除魔药
                if (a.hasTrait("MoYao91"))
                {
                    a.removeTrait("MoYao91");
                    
                    
                    // 返还3种序列一特效
                    if (!a.hasTrait("XulieTexing9"))
                    {
                        a.addTrait("XulieTexing9", false);
                    }
                    if (!a.hasTrait("XulieTexing91"))
                    {
                        a.addTrait("XulieTexing91", false);
                    }
                    if (!a.hasTrait("XulieTexing92"))
                    {
                        a.addTrait("XulieTexing92", false);
                    }
                }
                return false;
            }

            // 检查角色的途径
            string originalPathway = GetActorPathway(a);
            string pathway = originalPathway;
            if (pathway == null)
            {
                ApplyXuLieTitle(a, "XuLie92"); // 尝试获取途径
                pathway = GetActorPathway(a);
                if (pathway == null)
                {
                    NotificationHelper.ShowNotification(a, "无法确定晋升途径，晋升失败！");
                    return false;
                }
            }

            // 检查是否从相邻途径晋升而来且当前是天使之王
            string currentHighestTrait = GetHighestXuLieTrait(a);
            if (currentHighestTrait == "XuLie92") // 当前是天使之王
            {
                // 检查原始途径与目标途径是否为相邻途径
                if (originalPathway != null && originalPathway != pathway && 
                    _adjacentPathways.ContainsKey(originalPathway) && 
                    _adjacentPathways[originalPathway].Contains(pathway))
                {
                    // 天使之王无法晋升相邻途径真神
                    NotificationHelper.ShowNotification(a, $"{a.getName()}作为天使之王，无法晋升到相邻途径的真神！");
                    return false;
                }
                else if (originalPathway == pathway)
                {
                    // 允许天使之王晋升本途径真神
                    NotificationHelper.ShowNotification(a, $"{a.getName()}作为天使之王，开始晋升本途径真神！");
                }
            }

            // 检查该途径是否已有真神
            if (_pathwayHighSequenceCounts.ContainsKey(pathway) && _pathwayHighSequenceCounts[pathway]["XuLie93"] >= 1)
            {
                NotificationHelper.ShowNotification(a, $"[{pathway}]途径已有真神，无法晋升！");
                return false;
            }

            // 检查本途径和相邻途径是否已有旧日存在
            if (HasOldOneInPathwayOrAdjacent(pathway))
            {
                NotificationHelper.ShowNotification(a, "本途径或相邻途径已有旧日存在，无法晋升真神！");
                return false;
            }

            // 对于天使之王晋升本途径真神，添加额外的确认日志
            if (currentHighestTrait == "XuLie92" && originalPathway == pathway)
            {
                NotificationHelper.ShowNotification(a, $"{a.getName()}作为天使之王，成功通过本途径真神晋升检查！");
            }

            // 移除之前可能的高序列特质
            if (a.hasTrait("XuLie9"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie9", -1);
            }
            if (a.hasTrait("XuLie91"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie91", -1);
            }
            if (a.hasTrait("XuLie92"))
            {
                UpdateHighSequenceCount(originalPathway, "XuLie92", -1);
            }

            upTrait(
                "XuLie92",
                "XuLie93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "XuLie92+", "chaofanXuemai6" },
                new string[] { "XuLie93+", "immunity", "chaofanXuemai7" }
            );
            a.ChangeLiZhi(100);
            UpdateNameSuffix(a, "XuLie93");
            // 移除MoYao91魔药
            if (a.hasTrait("MoYao91"))
            {
                a.removeTrait("MoYao91");
            }
            // 添加序列一特性，确保组合唯一性
            string texingTrait = GetActorTeXingTrait(a);
            if (!string.IsNullOrEmpty(texingTrait))
            {
                // 安全添加XulieTexing9，确保组合唯一性
                string key9 = $"{texingTrait}+XulieTexing9";
                if (!a.hasTrait("XulieTexing9") && (!_texingSequenceOneOwners.ContainsKey(key9) || _texingSequenceOneOwners[key9] == a))
                {
                    a.addTrait("XulieTexing9");
                    _texingSequenceOneOwners[key9] = a;
                }
                
                // 安全添加XulieTexing91，确保组合唯一性
                string key91 = $"{texingTrait}+XulieTexing91";
                if (!a.hasTrait("XulieTexing91") && (!_texingSequenceOneOwners.ContainsKey(key91) || _texingSequenceOneOwners[key91] == a))
                {
                    a.addTrait("XulieTexing91");
                    _texingSequenceOneOwners[key91] = a;
                }
                
                // 安全添加XulieTexing92，确保组合唯一性
                string key92 = $"{texingTrait}+XulieTexing92";
                if (!a.hasTrait("XulieTexing92") && (!_texingSequenceOneOwners.ContainsKey(key92) || _texingSequenceOneOwners[key92] == a))
                {
                    a.addTrait("XulieTexing92");
                    _texingSequenceOneOwners[key92] = a;
                }
            }
            ApplyXuLieTitle(a, "XuLie93");


            NotificationHelper.ShowBreakthroughNotification(a, "XuLie92", "XuLie93");

            // 更新高序列计数
            UpdateHighSequenceCount(pathway, "XuLie93", 1);

            // 检查是否晋升到了相邻途径，如果是则失去原途径的唯一性
            if (originalPathway != null && originalPathway != pathway && _adjacentPathways.ContainsKey(originalPathway) && _adjacentPathways[originalPathway].Contains(pathway))
            {
                // 检查角色是否持有原途径的唯一性
                string originalUniqueness = null;
                foreach (var kvp in _uniquenessOwners)
                {
                    if (kvp.Value == a)
                    {
                        originalUniqueness = kvp.Key;
                        break;
                    }
                }

                if (originalUniqueness != null && a.hasTrait(originalUniqueness))
                {
                    // 让角色失去原途径的唯一性
                    a.removeTrait(originalUniqueness);
                    a.data.set("uniqueness", null);
                    _uniquenessOwners.Remove(originalUniqueness);
                    string uniquenessName = NotificationHelper.GetUniquenessName(originalUniqueness);
                    NotificationHelper.ShowNotification(a, $"晋升相邻途径，失去唯一性: {uniquenessName}");
                }
            }

            // 自动获得本途径唯一性，原持有者失去唯一性
            string currentName = a.getName();
            int separatorIndex = currentName.IndexOf('|');
            if (separatorIndex > 0)
            {
                string prefix = currentName.Substring(0, separatorIndex).Trim();
                if (_uniquenessMap.TryGetValue(prefix, out string uniquenessTrait))
                {
                    string uniquenessName = NotificationHelper.GetUniquenessName(uniquenessTrait);
                    // 检查当前唯一性持有者
                    if (_uniquenessOwners.ContainsKey(uniquenessTrait))
                    {
                        Actor oldOwner = _uniquenessOwners[uniquenessTrait];
                        if (oldOwner != null && oldOwner != a)
                        {
                            // 让原持有者失去唯一性
                            oldOwner.removeTrait(uniquenessTrait);
                            oldOwner.data.set("uniqueness", null);
                            NotificationHelper.ShowNotification(oldOwner, $"唯一性 {uniquenessName} 被夺走！");
                        }
                    }
                    
                    // 检查唯一性是否属于当前途径
                    string uniquenessPathway = GetUniquenessPathway(uniquenessTrait);
                    if (uniquenessPathway == pathway)
                    {
                        // 授予真神唯一性
                        a.addTrait(uniquenessTrait);
                        a.data.set("uniqueness", uniquenessTrait);
                        _uniquenessOwners[uniquenessTrait] = a;
                        NotificationHelper.ShowNotification(a, $"获得唯一性: {uniquenessName}");
                         
                        // 移除非本途径的唯一性
                        RemoveNonPathwayUniqueness(a, pathway);
                    }
                    else
                    {
                        NotificationHelper.ShowNotification(a, $"无法获得不属于本途径的唯一性: {uniquenessName}");
                    }
                }

                // 处理源质获取
                if (_pathwayToSourceQuality.TryGetValue(pathway, out string sourceQuality))
                {
                    // 源质名称映射
                    Dictionary<string, string> sourceQualityNames = new Dictionary<string, string>
                    {
                        {"NineYuanZhi1", "混沌海"},
                        {"NineYuanZhi2", "源堡"},
                        {"NineYuanZhi3", "母巢"},
                        {"NineYuanZhi4", "永暗之河"},
                        {"NineYuanZhi5", "灾祸之城"},
                        {"NineYuanZhi6", "失序之国"},
                        {"NineYuanZhi7", "知识荒野"},
                        {"NineYuanZhi8", "光之钥"},
                        {"NineYuanZhi9", "暗影世界"}
                    };

                    string sourceQualityName = sourceQualityNames.TryGetValue(sourceQuality, out string name) ? name : sourceQuality;

                    // 检查源质是否已被持有
                    if (!_sourceQualityOwners.ContainsKey(sourceQuality))
                    {
                        // 授予源质
                        a.addTrait(sourceQuality);
                        a.data.set("sourceQuality", sourceQuality);
                        _sourceQualityOwners[sourceQuality] = a;
                        NotificationHelper.ShowNotification(a, $"{a.getName()}获得源质: {sourceQualityName}");
                    }
                    else
                    {
                        Actor owner = _sourceQualityOwners[sourceQuality];
                        if (owner != a)
                        {
                            NotificationHelper.ShowNotification(a, $"源质 {sourceQualityName} 已被 {owner.getName()} 持有，无法获取！");
                        }
                    }
                }
            }

            // 只有当存在旧日时才降级真神
            if (HasOldOneInPathwayOrAdjacent(pathway))
            {
                DemoteTrueGods(pathway);
            }



            return true;
        }

        
        // 旧日晋升机制 - 唯一性规则实现
        public static bool XuLie94_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查是否已经是旧日，如果是则不允许继续晋升
            if (a.hasTrait("XuLie94"))
            {
                return false;
            }
            // 最高境界不会趺落

            if (a.GetXuLie() <= 99999.99)
            {
                return false;
            }
            
            // 添加拥有XulieTexing9和唯一性特质的条件
            if (!a.hasTrait("XulieTexing9") || !HasUniquenessTrait(a))
            {
                return false;
            }

            a.ChangeXuLie(-10000);
            double successRate = 0.01;
            if (a.hasTrait("jinSheng1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("jinSheng2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("jinSheng3"))
            {
                successRate = 0.03;
            }
            else if (a.hasTrait("jinSheng4"))
            {
                successRate = 0.04;
            }
            else if (a.hasTrait("jinSheng7"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("jinSheng8"))
            {
                successRate = 0.1;
            }

            // 检查理智是否足够进行突破尝试
            if (a.GetLiZhi() < 10)
            {
                // 理智不足，应用疯狂效果
                ApplyMadnessEffect(a);
                return false;
            }
            
            // 消耗10点理智尝试突破
            if (!a.hasTrait("yizhiYoncun"))
            {
                a.ChangeLiZhi(-10);
            }
            
            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                NotificationHelper.ShowNotification(a, $"{a.getName()}突破失败！");
                return false;
            }
            
            // 检查是否已经是真神
            if (!a.hasTrait("XuLie93"))
            {
                NotificationHelper.ShowNotification(a, "必须先成为真神才能晋升旧日！");
                return false;
            }
            
            // 获取当前途径
            string pathway = GetActorPathway(a);
            if (pathway == null)
            {
                NotificationHelper.ShowNotification(a, "无法确定晋升途径，晋升失败！");
                return false;
            }
            
            // 检查本途径和相邻途径是否已有旧日存在
            if (HasOldOneInPathwayOrAdjacent(pathway))
            {
                NotificationHelper.ShowNotification(a, "本途径或相邻途径已有旧日存在，无法晋升！");
                return false;
            }
            
            // 移除真神特质
            UpdateHighSequenceCount(pathway, "XuLie93", -1);
            
            // 晋升旧日
            upTrait(
                "XuLie93",
                "XuLie94",
                a,
                new string[] { "XuLie93+" },
                new string[] { "XuLie94+" }
            );
            
            a.ChangeLiZhi(200);
            UpdateNameSuffix(a, "XuLie94");
            ApplyXuLieTitle(a, "XuLie94");
            
            NotificationHelper.ShowBreakthroughNotification(a, "XuLie93", "XuLie94");
            NotificationHelper.ShowNotification(a, $"{a.getName()}成功晋升为旧日！");
            
            // 突破成功后释放XulieTexing91和XulieTexing92特质
            if (a.hasTrait("XulieTexing91"))
            {
                a.removeTrait("XulieTexing91");
            }
            if (a.hasTrait("XulieTexing92"))
            {
                a.removeTrait("XulieTexing92");
            }
            
            // 更新高序列计数
            UpdateHighSequenceCount(pathway, "XuLie94", 1);
            
            // 自动获得本途径和相邻途径的相关TeXing特质和唯一性
            GainPathwayAndAdjacentTraitsAndUniqueness(a, pathway);
            
            // 为旧日添加所有TeXing特质与XulieTexing特性组合的唯一性限制
            AddOldOneTexingSequenceOneCombinations(a);
            
            // 降级本途径和相邻途径的所有真神
            DemoteOldOnesAndTrueGodsInPathwayAndAdjacent(pathway);
            
            // 调整高序列角色数量配置
            AdjustHighSequenceCounts(pathway);
            AdjustHighSequenceCountsForAdjacentPaths(pathway);
            

            
            return true;
        }
        
        // 检查本途径或相邻途径是否已有旧日存在
        private static bool HasOldOneInPathwayOrAdjacent(string pathway)
        {
            // 检查本途径
            if (_pathwayHighSequenceCounts.ContainsKey(pathway) && _pathwayHighSequenceCounts[pathway].ContainsKey("XuLie94") && _pathwayHighSequenceCounts[pathway]["XuLie94"] > 0)
            {
                return true;
            }
            
            // 检查相邻途径
            if (_adjacentPathways.ContainsKey(pathway))
            {
                foreach (string adjacentPath in _adjacentPathways[pathway])
                {
                    if (_pathwayHighSequenceCounts.ContainsKey(adjacentPath) && _pathwayHighSequenceCounts[adjacentPath].ContainsKey("XuLie94") && _pathwayHighSequenceCounts[adjacentPath]["XuLie94"] > 0)
                    {
                        return true;
                    }
                }
            }
            
            return false;
        }
        
        // 降级本途径和相邻途径的所有真神
        private static void DemoteOldOnesAndTrueGodsInPathwayAndAdjacent(string pathway)
        {
            // 降级本途径的真神
            DemoteTrueGods(pathway);
            
            // 降级相邻途径的真神
            if (_adjacentPathways.ContainsKey(pathway))
            {
                foreach (string adjacentPath in _adjacentPathways[pathway])
                {
                    DemoteTrueGods(adjacentPath);
                }
            }
        }
        
        // 降级指定途径的所有真神
        private static void DemoteTrueGods(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;
            
            var counts = _pathwayHighSequenceCounts[pathway];
            
            // 检查是否有真神存在
            if (counts.ContainsKey("XuLie93") && counts["XuLie93"] > 0)
            {
                // 查找该途径的所有真神角色
                List<Actor> trueGods = new List<Actor>();
                foreach (Actor actor in World.world.units.getSimpleList())
                {
                    if (actor != null && actor.isAlive() && GetActorPathway(actor) == pathway && actor.hasTrait("XuLie93"))
                    {
                        trueGods.Add(actor);
                    }
                }
                
                // 降级所有真神
                foreach (Actor trueGod in trueGods)
                {
                    NotificationHelper.ShowNotification(trueGod, $"由于{pathway}途径出现旧日，{trueGod.getName()}被降级为天使之王！");
                    
                    // 移除真神特质
                    UpdateHighSequenceCount(pathway, "XuLie93", -1);
                    
                    // 降级为天使之王
                    upTrait(
                        "XuLie93",
                        "XuLie92",
                        trueGod,
                        new string[] { "XuLie93+" },
                        new string[] { "XuLie92+" }
                    );
                    
                    trueGod.ChangeLiZhi(-50);
                    UpdateNameSuffix(trueGod, "XuLie92");
                    ApplyXuLieTitle(trueGod, "XuLie92");
                    
                    // 更新高序列计数
                    UpdateHighSequenceCount(pathway, "XuLie92", 1);
                }
            }
        }
        
        // 调整指定途径的高序列角色数量配置
        private static void AdjustHighSequenceCounts(string pathway)
        {
            if (!_pathwayHighSequenceCounts.ContainsKey(pathway))
                return;
            
            var counts = _pathwayHighSequenceCounts[pathway];
            int trueGod = counts.ContainsKey("XuLie93") ? counts["XuLie93"] : 0;
            int angelKing = counts.ContainsKey("XuLie92") ? counts["XuLie92"] : 0;
            int sequenceOne = counts.ContainsKey("XuLie91") ? counts["XuLie91"] : 0;
            int sequenceTwo = counts.ContainsKey("XuLie9") ? counts["XuLie9"] : 0;
            
            // 检查是否存在旧日
            bool hasOldOne = HasOldOneInPathwayOrAdjacent(pathway);
            
            // 存在旧日时的配置逻辑
            if (hasOldOne)
            {
                // 存在旧日时，0真神
                if (trueGod > 0)
                {
                    // 降级所有真神
                    while (trueGod > 0)
                    {
                        // 查找并降级一名真神
                        DemoteRandomHighSequenceActor(pathway, "XuLie93", "XuLie91");
                        trueGod--;
                    }
                }
                
                // 存在旧日时的配置选项
                // 选项1: 1天使之王 + 0序列一 + 3序列二
                if (angelKing == 1)
                {
                    // 降级所有序列一
                    while (sequenceOne > 0)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie91", "XuLie9");
                        sequenceOne--;
                    }
                    
                    // 调整序列二数量到3
                    while (sequenceTwo > 3)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                        sequenceTwo--;
                    }
                }
                // 选项2: 0天使之王 + 2序列一 + 3序列二
                else if (sequenceOne == 2)
                {
                    // 调整序列二数量到3
                    while (sequenceTwo > 3)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                        sequenceTwo--;
                    }
                }
                // 选项3: 0天使之王 + 1序列一 + 4序列二
                else if (sequenceOne == 1)
                {
                    // 调整序列二数量到4
                    while (sequenceTwo > 4)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                        sequenceTwo--;
                    }
                }
                // 选项4: 0天使之王 + 0序列一 + 5序列二
                else
                {
                    // 调整序列二数量到5
                    while (sequenceTwo > 5)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                        sequenceTwo--;
                    }
                }
            }
            // 有真神时的配置逻辑
            else if (trueGod > 0)
            {
                // 有真神时，0天使之王，0序列一，3序列二
                // 降级所有天使之王
                while (angelKing > 0)
                {
                    DemoteRandomHighSequenceActor(pathway, "XuLie92", "XuLie91");
                    angelKing--;
                }
                
                // 降级所有序列一
                while (sequenceOne > 0)
                {
                    DemoteRandomHighSequenceActor(pathway, "XuLie91", "XuLie9");
                    sequenceOne--;
                }
                
                // 调整序列二数量到3
                while (sequenceTwo > 3)
                {
                    DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                    sequenceTwo--;
                }
            }
            // 既没有旧日也没有真神时的默认配置
            else
            {
                // 配置规则1: 1天使之王 + 0序列一 + 3序列二
                if (angelKing > 1)
                {
                    // 超过1个天使之王，降级多余的
                    int toDemote = angelKing - 1;
                    for (int i = 0; i < toDemote; i++)
                    {
                        DemoteRandomHighSequenceActor(pathway, "XuLie92", "XuLie91");
                    }
                }
                
                // 确保配置符合规则
                if (angelKing == 1)
                {
                    // 规则1: 1天使之王 + 0序列一 + 3序列二
                    if (sequenceOne > 0)
                    {
                        // 降级所有序列一
                        while (sequenceOne > 0)
                        {
                            DemoteRandomHighSequenceActor(pathway, "XuLie91", "XuLie9");
                            sequenceOne--;
                        }
                    }
                    
                    if (sequenceTwo != 3)
                    {
                        // 调整序列二数量到3
                        while (sequenceTwo > 3)
                        {
                            DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                            sequenceTwo--;
                        }
                    }
                }
                else if (sequenceOne == 1)
                {
                    // 规则2: 0天使之王 + 1序列一 + 4序列二
                    if (sequenceTwo != 4)
                    {
                        while (sequenceTwo > 4)
                        {
                            DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                            sequenceTwo--;
                        }
                    }
                }
                else
                {
                    // 规则3: 0天使之王 + 0序列一 + 5序列二
                    if (sequenceTwo != 5)
                    {
                        while (sequenceTwo > 5)
                        {
                            DemoteRandomHighSequenceActor(pathway, "XuLie9", "XuLie8");
                            sequenceTwo--;
                        }
                    }
                }
            }
        }
        
        // 为相邻途径调整高序列角色数量配置
        private static void AdjustHighSequenceCountsForAdjacentPaths(string pathway)
        {
            if (_adjacentPathways.ContainsKey(pathway))
            {
                foreach (string adjacentPath in _adjacentPathways[pathway])
                {
                    AdjustHighSequenceCounts(adjacentPath);
                }
            }
        }
        
        // 随机降级一名高序列角色
        private static void DemoteRandomHighSequenceActor(string pathway, string fromTrait, string toTrait)
        {
            // 查找拥有指定特质的所有角色
            List<Actor> candidates = new List<Actor>();
            foreach (Actor actor in World.world.units.getSimpleList())
            {
                if (actor != null && actor.isAlive() && GetActorPathway(actor) == pathway && actor.hasTrait(fromTrait))
                {
                    candidates.Add(actor);
                }
            }
            
            if (candidates.Count == 0)
            {
                return;
            }
            
            // 随机选择一名角色
            int randomIndex = UnityEngine.Random.Range(0, candidates.Count);
            Actor target = candidates[randomIndex];
            
            // 显示降级通知
            NotificationHelper.ShowNotification(target, $"由于{pathway}途径旧日规则限制，{target.getName()}被从{fromTrait}降级为{toTrait}！");
            
            // 移除旧特质
            UpdateHighSequenceCount(pathway, fromTrait, -1);
            
            // 应用新特质
            string[] fromSuffixes = new string[] { fromTrait + "+" };
            string[] toSuffixes = new string[] { toTrait + "+" };
            
            upTrait(
                fromTrait,
                toTrait,
                target,
                fromSuffixes,
                toSuffixes
            );
            
            // 调整理智值
            target.ChangeLiZhi(-20);
            
            // 更新名称后缀和尊号
            UpdateNameSuffix(target, toTrait);
            ApplyXuLieTitle(target, toTrait);
            
            // 更新高序列计数
            UpdateHighSequenceCount(pathway, toTrait, 1);
            
            // 处理降级后的特质清理和冲突检查
            HandleActorDegradation(target, fromTrait, toTrait);
        }
        
        // 自动获得本途径和相邻途径的相关TeXing特质、唯一性和源质
        private static void GainPathwayAndAdjacentTraitsAndUniqueness(Actor a, string pathway)
        {
            // 获取本途径和相邻途径
            List<string> pathwaysToGain = new List<string> { pathway };
            
            if (_adjacentPathways.ContainsKey(pathway))
            {
                pathwaysToGain.AddRange(_adjacentPathways[pathway]);
            }
            
            // 为每个途径获取对应的TeXing特质
            foreach (string targetPathway in pathwaysToGain)
            {
                if (_pathwayToTexing.TryGetValue(targetPathway, out string texingTrait))
                {
                    // 添加TeXing特质
                    if (!a.hasTrait(texingTrait))
                    {
                        a.addTrait(texingTrait);
                        NotificationHelper.ShowNotification(a, $"{a.getName()}获得了{targetPathway}途径的{texingTrait}特质！");
                    }
                    
                    // 获取该途径的唯一性特质
                    string uniquenessTrait = GetUniquenessForPathway(targetPathway);
                    if (!string.IsNullOrEmpty(uniquenessTrait))
                    {
                        // 尝试获取唯一性
                        TryGainUniqueness(a, uniquenessTrait, targetPathway);
                    }
                }
                
                // 尝试获取该途径对应的源质（仅用于旧日晋升）
                if (_pathwayToSourceQuality.TryGetValue(targetPathway, out string sourceQuality))
                {
                    // 源质名称映射
                    Dictionary<string, string> sourceQualityNames = new Dictionary<string, string>
                    {
                        {"NineYuanZhi1", "混沌海"},
                        {"NineYuanZhi2", "源堡"},
                        {"NineYuanZhi3", "母巢"},
                        {"NineYuanZhi4", "永暗之河"},
                        {"NineYuanZhi5", "灾祸之城"},
                        {"NineYuanZhi6", "失序之国"},
                        {"NineYuanZhi7", "知识荒野"},
                        {"NineYuanZhi8", "光之钥"},
                        {"NineYuanZhi9", "暗影世界"}
                    };

                    string sourceQualityName = sourceQualityNames.TryGetValue(sourceQuality, out string name) ? name : sourceQuality;

                    // 强制夺取源质（如果已被持有）
                    if (_sourceQualityOwners.ContainsKey(sourceQuality))
                    {
                        Actor oldOwner = _sourceQualityOwners[sourceQuality];
                        if (oldOwner != null && oldOwner != a)
                        {
                            // 让原持有者失去源质
                            oldOwner.removeTrait(sourceQuality);
                            oldOwner.data.set("sourceQuality", null);
                            NotificationHelper.ShowNotification(oldOwner, $"源质 {sourceQualityName} 被{pathway}途径的旧日夺走！");
                        }
                    }
                    
                    // 授予源质
                    if (!a.hasTrait(sourceQuality))
                    {
                        a.addTrait(sourceQuality);
                        a.data.set("sourceQuality", sourceQuality);
                        _sourceQualityOwners[sourceQuality] = a;
                        NotificationHelper.ShowNotification(a, $"{a.getName()}获得源质: {sourceQualityName}");
                    }
                }
            }
        }
        
        // 根据途径获取对应的唯一性特质
        private static string GetUniquenessForPathway(string pathway)
        {
            // 根据途径获取对应的唯一性特质
            switch (pathway)
            {
                case "占卜家": return "WeiYixing1";
                case "学徒": return "WeiYixing2";
                case "偷盗者": return "WeiYixing3";
                case "歌颂者": return "WeiYixing4";
                case "观众": return "WeiYixing5";
                case "阅读者": return "WeiYixing6";
                case "水手": return "WeiYixing7";
                case "秘祈人": return "WeiYixing8";
                case "药师": return "WeiYixing9";
                case "不眠者": return "WeiYixing10";
                case "战士": return "WeiYixing11";
                case "猎人": return "WeiYixing1+";
                case "刺客": return "WeiYixing2+";
                case "耕种者": return "WeiYixing3+";
                case "收尸人": return "WeiYixing4+";
                case "律师": return "WeiYixing5+";
                case "仲裁人": return "WeiYixing6+";
                case "罪犯": return "WeiYixing7+";
                case "囚犯": return "WeiYixing8+";
                case "窥秘人": return "WeiYixing9+";
                case "通识者": return "WeiYixing10+";
                case "怪物": return "WeiYixing11+";
                default: return null;
            }
        }
        
        // 尝试获取唯一性特质
        private static void TryGainUniqueness(Actor a, string uniquenessTrait, string pathway)
        {
            string uniquenessName = NotificationHelper.GetUniquenessName(uniquenessTrait);
            
            // 检查当前唯一性持有者
            if (_uniquenessOwners.ContainsKey(uniquenessTrait))
            {
                Actor oldOwner = _uniquenessOwners[uniquenessTrait];
                if (oldOwner != null && oldOwner != a)
                {
                    // 让原持有者失去唯一性
                    oldOwner.removeTrait(uniquenessTrait);
                    oldOwner.data.set("uniqueness", null);
                    NotificationHelper.ShowNotification(oldOwner, $"唯一性 {uniquenessName} 被{pathway}途径的旧日夺走！");
                }
            }
            
            // 授予旧日唯一性
            if (!a.hasTrait(uniquenessTrait))
            {
                a.addTrait(uniquenessTrait);
                a.data.set("uniqueness", uniquenessTrait);
                _uniquenessOwners[uniquenessTrait] = a;
                NotificationHelper.ShowNotification(a, $"{a.getName()}获得了{pathway}途径的唯一性: {uniquenessName}！");
            }
        }

        //序列的恢复生命值效果
        public static bool XuLie1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的10%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的20%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的30%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.3f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的40%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.4f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的50%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.5f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的60%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.6f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的70%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.7f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的80%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.8f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的90%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 0.9f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的100%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的110%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1.1f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        public static bool XuLie93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor actor = pTarget.a;
            if (actor.data.health < actor.getMaxHealth())
            {
                // 获取当前序列值
                float xuLieValue = actor.GetXuLie();
                // 计算回血量：序列值的120%（可根据平衡性调整比例）
                int healAmount = Mathf.RoundToInt(xuLieValue * 1.2f);
                // 至少回复1点生命
                if (healAmount < 1) healAmount = 1; 
        
                actor.restoreHealth(healAmount);
                actor.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }
        
        // 半神及以上境界每年增加心情效果
        public static bool XuLie7_HappinessBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }
            
            if (!pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 增加50点心情
            actor.data.happiness += 50;
            // 确保心情不超过最大值
            if (actor.data.happiness > 100)
            {
                actor.data.happiness = 100;
            }
            // 生成心情提升的粒子效果
            actor.spawnParticle(Toolbox.color_heal);
            return true;
        }
        
        // 诡秘身份系列特质年度金磅增加效果
        public static bool GuimiShenfen1_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加1~10金磅
            int randomJinBang = UnityEngine.Random.Range(1, 11);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen2_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加1~10金磅
            int randomJinBang = UnityEngine.Random.Range(1, 11);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen3_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加1~10金磅
            int randomJinBang = UnityEngine.Random.Range(1, 11);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen4_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加1~10金磅
            int randomJinBang = UnityEngine.Random.Range(1, 11);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen5_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加1~10金磅
            int randomJinBang = UnityEngine.Random.Range(1, 11);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen6_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加10~100金磅
            int randomJinBang = UnityEngine.Random.Range(10, 151);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen6Plus_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加10~100金磅
            int randomJinBang = UnityEngine.Random.Range(10, 151);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfen7_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加100~1000金磅
            int randomJinBang = UnityEngine.Random.Range(100, 1001);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfenPlus_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加10~100金磅
            int randomJinBang = UnityEngine.Random.Range(10, 151);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }
        
        public static bool GuimiShenfenPlusPlus_JinBangBoost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor actor = pTarget.a;
            // 随机增加100~1000金磅
            int randomJinBang = UnityEngine.Random.Range(100, 1001);
            actor.ChangeJinBang((float)randomJinBang);
            return true;
        }

        // 购买辅助材料和特性的方法
        public static bool BuyFuzhuCailiao1(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为半超凡XuLie1
            if (!a.hasTrait("XuLie1"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 10)
            {
                return false;
            }
            
            // 如果已经拥有序列九辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao1"))
            {
                return false;
            }
            
            // 如果已经拥有序列九魔药，就不用重复购买序列九辅助材料了
            if (a.hasTrait("MoYao1"))
            {
                return false;
            }
            
            // 如果已经到了序列九XuLie2及以上，就不用重复购买序列九辅助材料了
            if (a.hasTrait("XuLie2") || a.hasTrait("XuLie3") || a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || 
                a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || 
                a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-10);
            a.addTrait("FuzhuCailiao1");
            return true;
        }
        
        public static bool BuyXulieTexing1(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为半超凡XuLie1
            if (!a.hasTrait("XuLie1"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 100)
            {
                return false;
            }
            
            // 如果已经拥有序列九特性，就不用重复购买
            if (a.hasTrait("XulieTexing1"))
            {
                return false;
            }
            
            // 如果已经拥有序列九魔药，就不用重复购买序列九特性了
            if (a.hasTrait("MoYao1"))
            {
                return false;
            }
            
            // 如果已经到了序列九XuLie2及以上，就不用重复购买序列九特性了
            if (a.hasTrait("XuLie2") || a.hasTrait("XuLie3") || a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || 
                a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || 
                a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-100);
            a.addTrait("XulieTexing1");
            return true;
        }
        
        public static bool BuyFuzhuCailiao2(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列九XuLie2
            if (!a.hasTrait("XuLie2"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 50)
            {
                return false;
            }
            
            // 如果已经拥有序列八辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao2"))
            {
                return false;
            }
            
            // 如果已经拥有序列八魔药，就不用重复购买序列八辅助材料了
            if (a.hasTrait("MoYao2"))
            {
                return false;
            }
            
            // 如果已经到了序列八XuLie3及以上，就不用重复购买序列八辅助材料了
            if (a.hasTrait("XuLie3") || a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || 
                a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || 
                a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-50);
            a.addTrait("FuzhuCailiao2");
            return true;
        }
        
        public static bool BuyXulieTexing2(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列九XuLie2
            if (!a.hasTrait("XuLie2"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 300)
            {
                return false;
            }
            
            // 如果已经拥有序列八特性，就不用重复购买
            if (a.hasTrait("XulieTexing2"))
            {
                return false;
            }
            
            // 如果已经拥有序列八魔药，就不用重复购买序列八特性了
            if (a.hasTrait("MoYao2"))
            {
                return false;
            }
            
            // 如果已经到了序列八XuLie3及以上，就不用重复购买序列八特性了
            if (a.hasTrait("XuLie3") || a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || 
                a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || 
                a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-300);
            a.addTrait("XulieTexing2");
            return true;
        }
        
        public static bool BuyFuzhuCailiao3(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列八XuLie3
            if (!a.hasTrait("XuLie3"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 100)
            {
                return false;
            }
            
            // 如果已经拥有序列七辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao3"))
            {
                return false;
            }
            
            // 如果已经拥有序列七魔药，就不用重复购买序列七辅助材料了
            if (a.hasTrait("MoYao3"))
            {
                return false;
            }
            
            // 如果已经到了序列七XuLie4及以上，就不用重复购买序列七辅助材料了
            if (a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || 
                a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || 
                a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-100);
            a.addTrait("FuzhuCailiao3");
            return true;
        }
        
        public static bool BuyXulieTexing3(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列八XuLie3
            if (!a.hasTrait("XuLie3"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000)
            {
                return false;
            }
            
            // 如果已经拥有序列七特性，就不用重复购买
            if (a.hasTrait("XulieTexing3"))
            {
                return false;
            }
            
            // 如果已经拥有序列七魔药，就不用重复购买序列七特性了
            if (a.hasTrait("MoYao3"))
            {
                return false;
            }
            
            // 如果已经到了序列七XuLie4及以上，就不用重复购买序列七特性了
            if (a.hasTrait("XuLie4") || a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || 
                a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || 
                a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-1000);
            a.addTrait("XulieTexing3");
            return true;
        }
        
        public static bool BuyFuzhuCailiao4(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列七XuLie4
            if (!a.hasTrait("XuLie4"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 300)
            {
                return false;
            }
            
            // 如果已经拥有序列六辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao4"))
            {
                return false;
            }
            
            // 如果已经拥有序列六魔药，就不用重复购买序列六辅助材料了
            if (a.hasTrait("MoYao4"))
            {
                return false;
            }
            
            // 如果已经到了序列六XuLie5及以上，就不用重复购买序列六辅助材料了
            if (a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || 
                a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-300);
            a.addTrait("FuzhuCailiao4");
            return true;
        }
        
        public static bool BuyXulieTexing4(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列七XuLie4
            if (!a.hasTrait("XuLie4"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 3000)
            {
                return false;
            }
            
            // 如果已经拥有序列六特性，就不用重复购买
            if (a.hasTrait("XulieTexing4"))
            {
                return false;
            }
            
            // 如果已经拥有序列六魔药，就不用重复购买序列六特性了
            if (a.hasTrait("MoYao4"))
            {
                return false;
            }
            
            // 如果已经到了序列六XuLie5及以上，就不用重复购买序列六特性了
            if (a.hasTrait("XuLie5") || a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || 
                a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-3000);
            a.addTrait("XulieTexing4");
            return true;
        }
        
        public static bool BuyFuzhuCailiao5(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列六XuLie5
            if (!a.hasTrait("XuLie5"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000)
            {
                return false;
            }
            
            // 如果已经拥有序列五辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao5"))
            {
                return false;
            }
            
            // 如果已经拥有序列五魔药，就不用重复购买序列五辅助材料了
            if (a.hasTrait("MoYao5"))
            {
                return false;
            }
            
            // 如果已经到了序列五XuLie6及以上，就不用重复购买序列五辅助材料了
            if (a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || 
                a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-1000);
            a.addTrait("FuzhuCailiao5");
            return true;
        }
        
        public static bool BuyXulieTexing5(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列六XuLie5
            if (!a.hasTrait("XuLie5"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 10000)
            {
                return false;
            }
            
            // 如果已经拥有序列五特性，就不用重复购买
            if (a.hasTrait("XulieTexing5"))
            {
                return false;
            }
            
            // 如果已经拥有序列五魔药，就不用重复购买序列五特性了
            if (a.hasTrait("MoYao5"))
            {
                return false;
            }
            
            // 如果已经到了序列五XuLie6及以上，就不用重复购买序列五特性了
            if (a.hasTrait("XuLie6") || a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || 
                a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-10000);
            a.addTrait("XulieTexing5");
            return true;
        }
        
        public static bool BuyFuzhuCailiao6(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列五XuLie6
            if (!a.hasTrait("XuLie6"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 3000)
            {
                return false;
            }
            
            // 如果已经拥有序列四辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao6"))
            {
                return false;
            }
            
            // 如果已经拥有序列四魔药，就不用重复购买序列四辅助材料了
            if (a.hasTrait("MoYao6"))
            {
                return false;
            }
            
            // 如果已经到了序列四XuLie7及以上，就不用重复购买序列四辅助材料了
            if (a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || 
                a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-3000);
            a.addTrait("FuzhuCailiao6");
            return true;
        }
        
        public static bool BuyXulieTexing6(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列五XuLie6
            if (!a.hasTrait("XuLie6"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 30000)
            {
                return false;
            }
            
            // 如果已经拥有序列四特性，就不用重复购买
            if (a.hasTrait("XulieTexing6"))
            {
                return false;
            }
            
            // 如果已经拥有序列四魔药，就不用重复购买序列四特性了
            if (a.hasTrait("MoYao6"))
            {
                return false;
            }
            
            // 如果已经到了序列四XuLie7及以上，就不用重复购买序列四特性了
            if (a.hasTrait("XuLie7") || a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || 
                a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-30000);
            a.addTrait("XulieTexing6");
            return true;
        }
        
        public static bool BuyFuzhuCailiao7(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列四XuLie7
            if (!a.hasTrait("XuLie7"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 10000)
            {
                return false;
            }
            
            // 如果已经拥有序列三辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao7"))
            {
                return false;
            }
            
            // 如果已经拥有序列三魔药，就不用重复购买序列三辅助材料了
            if (a.hasTrait("MoYao7"))
            {
                return false;
            }
            
            // 如果已经到了序列三XuLie8及以上，就不用重复购买序列三辅助材料了
            if (a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || 
                a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-10000);
            a.addTrait("FuzhuCailiao7");
            return true;
        }
        
        public static bool BuyXulieTexing7(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列四XuLie7
            if (!a.hasTrait("XuLie7"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 100000)
            {
                return false;
            }
            
            // 如果已经拥有序列三特性，就不用重复购买
            if (a.hasTrait("XulieTexing7"))
            {
                return false;
            }
            
            // 如果已经拥有序列三魔药，就不用重复购买序列三特性了
            if (a.hasTrait("MoYao7"))
            {
                return false;
            }
            
            // 如果已经到了序列三XuLie8及以上，就不用重复购买序列三特性了
            if (a.hasTrait("XuLie8") || a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || 
                a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-100000);
            a.addTrait("XulieTexing7");
            return true;
        }
        
        public static bool BuyFuzhuCailiao8(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列三XuLie8
            if (!a.hasTrait("XuLie8"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 100000)
            {
                return false;
            }
            
            // 如果已经拥有序列二辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao8"))
            {
                return false;
            }
            
            // 如果已经拥有序列二魔药，就不用重复购买序列二辅助材料了
            if (a.hasTrait("MoYao8"))
            {
                return false;
            }
            
            // 如果已经到了序列二XuLie9及以上，就不用重复购买序列二辅助材料了
            if (a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-100000);
            a.addTrait("FuzhuCailiao8");
            return true;
        }
        
        public static bool BuyXulieTexing8(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列三XuLie8
            if (!a.hasTrait("XuLie8"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 300000)
            {
                return false;
            }
            
            // 如果已经拥有序列二特性，就不用重复购买
            if (a.hasTrait("XulieTexing8"))
            {
                return false;
            }
            
            // 如果已经拥有序列二魔药，就不用重复购买序列二特性了
            if (a.hasTrait("MoYao8"))
            {
                return false;
            }
            
            // 如果已经到了序列二XuLie9及以上，就不用重复购买序列二特性了
            if (a.hasTrait("XuLie9") || a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加特性
            a.ChangeJinBang(-300000);
            a.addTrait("XulieTexing8");
            return true;
        }
        
        public static bool BuyFuzhuCailiao9(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列二XuLie9
            if (!a.hasTrait("XuLie9"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 100000)
            {
                return false;
            }
            
            // 如果已经拥有序列一辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao9"))
            {
                return false;
            }
            
            // 如果已经拥有序列一魔药，就不用重复购买序列一辅助材料了
            if (a.hasTrait("MoYao9"))
            {
                return false;
            }
            
            // 如果已经到了序列一XuLie91及以上，就不用重复购买序列一辅助材料了
            if (a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加辅助材料
            a.ChangeJinBang(-100000);
            a.addTrait("FuzhuCailiao9");
            return true;
        }
        
        public static bool BuyXulieTexing9(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否已经是序列一或更高等级，如果是，则不执行购买序列一特性的代码
            if (a.hasTrait("XuLie91") || a.hasTrait("XuLie92") || a.hasTrait("XuLie93") || a.hasTrait("XuLie94"))
            {
                return false;
            }
            
            // 检查是否为序列二XuLie9
            if (!a.hasTrait("XuLie9"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000000)
            {
                return false;
            }
            
            // 如果已经拥有序列一魔药，就不用重复购买序列一特性了
            if (a.hasTrait("MoYao9"))
            {
                return false;
            }
            
            // 检查是否已有序列一特性（序列二时拥有XulieTexing9就不用重复购买）
            if (a.hasTrait("XulieTexing9") || a.hasTrait("XulieTexing91") || a.hasTrait("XulieTexing92"))
            {
                return false;
            }
            
            // 扣除金磅
            a.ChangeJinBang(-1000000);
            
            // 收集所有可用的序列一特性
            List<string> availableTraits = new List<string>();
            string[] sequenceOneTraits = { "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            
            // 获取角色的TeXing特质
            string texingTrait = GetActorTeXingTrait(a);
            if (!string.IsNullOrEmpty(texingTrait))
            {
                foreach (string trait in sequenceOneTraits)
                {
                    string key = $"{texingTrait}+{trait}";
                    if (!_texingSequenceOneOwners.ContainsKey(key) || _texingSequenceOneOwners[key] == a)
                    {
                        availableTraits.Add(trait);
                    }
                }
            }
            
            // 从可用特性中随机选择一个
            if (availableTraits.Count > 0)
            {
                System.Random random = new System.Random();
                int index = random.Next(availableTraits.Count);
                a.addTrait(availableTraits[index]);
                return true;
            }
            
            // 没有可用特性
            return false;
        }
        
        public static bool BuyUniqueness(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列一XuLie91或天使之王XuLie92
            if (!a.hasTrait("XuLie91") && !a.hasTrait("XuLie92"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000000)
            {
                return false;
            }
            
            // 获取角色所属途径
            string pathway = GetActorPathway(a);
            if (string.IsNullOrEmpty(pathway))
            {
                return false;
            }
            
            // 获取对应途径的唯一性特质
            string uniquenessTrait = GetUniquenessForPathway(pathway);
            if (string.IsNullOrEmpty(uniquenessTrait))
            {
                return false;
            }
            
            // 检查唯一性是否已被占据
            if (_uniquenessOwners.ContainsKey(uniquenessTrait) && _uniquenessOwners[uniquenessTrait] != a)
            {
                // 不再显示唯一性已被占据的通知
                return false;
            }
            
            // 扣除金磅
            a.ChangeJinBang(-1000000);
            
            // 获取并添加唯一性
            TryGainUniqueness(a, uniquenessTrait, pathway);
            
            return true;
        }
        
        public static bool BuyOtherSequenceOneTrait(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为序列一XuLie91或天使之王XuLie92
            if (!a.hasTrait("XuLie91") && !a.hasTrait("XuLie92"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000000)
            {
                return false;
            }
            
            // 检查是否已有序列一特性（序列一必须至少拥有一个序列一特性才能购买另一个，但天使之王可以直接购买）
            if (!a.hasTrait("XuLie92") && !a.hasTrait("XulieTexing9") && !a.hasTrait("XulieTexing91") && !a.hasTrait("XulieTexing92"))
            {
                return false;
            }
            
            // 扣除金磅
            a.ChangeJinBang(-1000000);
            
            // 查找与自身不同的序列一特性
            string texingTrait = GetActorTeXingTrait(a);
            if (!string.IsNullOrEmpty(texingTrait))
            {
                // 计算当前拥有的序列一特性数量
                int currentCount = 0;
                bool hasXulieTexing9 = a.hasTrait("XulieTexing9");
                bool hasXulieTexing91 = a.hasTrait("XulieTexing91");
                bool hasXulieTexing92 = a.hasTrait("XulieTexing92");
                
                if (hasXulieTexing9) currentCount++;
                if (hasXulieTexing91) currentCount++;
                if (hasXulieTexing92) currentCount++;
                
                // 检查是否已经拥有全部三个序列一特性
                if (currentCount >= 3)
                {
                    NotificationHelper.ShowNotification(a, $"{a.getName()}已经拥有全部三个序列一特性，无法继续购买");
                    return false;
                }
                
                // 尝试添加缺少的序列一特性
                if (!hasXulieTexing9)
                {
                    string key9 = $"{texingTrait}+XulieTexing9";
                    if (!_texingSequenceOneOwners.ContainsKey(key9) || _texingSequenceOneOwners[key9] == a)
                    {
                        a.addTrait("XulieTexing9");
                        _texingSequenceOneOwners[key9] = a;
                        return true;
                    }
                }
                
                if (!hasXulieTexing91)
                {
                    string key91 = $"{texingTrait}+XulieTexing91";
                    if (!_texingSequenceOneOwners.ContainsKey(key91) || _texingSequenceOneOwners[key91] == a)
                    {
                        a.addTrait("XulieTexing91");
                        _texingSequenceOneOwners[key91] = a;
                        return true;
                    }
                }
                
                if (!hasXulieTexing92)
                {
                    string key92 = $"{texingTrait}+XulieTexing92";
                    if (!_texingSequenceOneOwners.ContainsKey(key92) || _texingSequenceOneOwners[key92] == a)
                    {
                        a.addTrait("XulieTexing92");
                        _texingSequenceOneOwners[key92] = a;
                        return true;
                    }
                }
                
                // 如果所有可用的序列一特性都被其他角色持有
                NotificationHelper.ShowNotification(a, $"没有可用的序列一特性组合，可能已被其他角色持有");
                return false;
            }
            
            return false;
        }
        
        public static bool BuyFuzhuCailiao91(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            
            Actor a = pTarget.a;
            
            // 检查是否为天使之王XuLie92
            if (!a.hasTrait("XuLie92"))
            {
                return false;
            }
            
            // 检查金磅是否足够
            if (a.GetJinBang() < 1000000)
            {
                return false;
            }
            
            // 如果已经拥有序列零辅助材料，就不用重复购买
            if (a.hasTrait("FuzhuCailiao91"))
            {
                return false;
            }
            
            // 如果已经到了序列零XuLie93，就不用重复购买序列零辅助材料了
            if (a.hasTrait("XuLie93"))
            {
                return false;
            }
            
            // 扣除金磅并添加序列零辅助材料
            a.ChangeJinBang(-1000000);
            a.addTrait("FuzhuCailiao91");
            return true;
        }


        
        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }

        // 魔药系列特质效果 - 增加灵性XuLie，魔药不再消失但灵性只加一次
        public static bool MoYao1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao1_used"))
            {
                // 增加1点灵性XuLie (原为10点，减少10倍)
                actor.ChangeXuLie(0.5f);
                // 添加已使用标记
                actor.addTrait("MoYao1_used");
            }
            return true;
        }

        public static bool MoYao2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao2_used"))
            {
                // 增加2点灵性XuLie (原为20点，减少10倍)
                actor.ChangeXuLie(1f);
                // 添加已使用标记
                actor.addTrait("MoYao2_used");
            }
            return true;
        }

        public static bool MoYao3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao3_used"))
            {
                // 增加4点灵性XuLie (原为40点，减少10倍)
                actor.ChangeXuLie(2f);
                // 添加已使用标记
                actor.addTrait("MoYao3_used");
            }
            return true;
        }

        public static bool MoYao4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao4_used"))
            {
                // 增加8点灵性XuLie (原为80点，减少10倍)
                actor.ChangeXuLie(4f);
                // 添加已使用标记
                actor.addTrait("MoYao4_used");
            }
            return true;
        }

        public static bool MoYao5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao5_used"))
            {
                // 增加16点灵性XuLie (原为160点，减少10倍)
                actor.ChangeXuLie(8f);
                // 添加已使用标记
                actor.addTrait("MoYao5_used");
            }
            return true;
        }

        public static bool MoYao6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao6_used"))
            {
                // 增加30点灵性XuLie (原为300点，减少10倍)
                actor.ChangeXuLie(15f);
                // 添加已使用标记
                actor.addTrait("MoYao6_used");
            }
            return true;
        }

        public static bool MoYao7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao7_used"))
            {
                // 增加50点灵性XuLie (原为500点，减少10倍)
                actor.ChangeXuLie(25f);
                // 添加已使用标记
                actor.addTrait("MoYao7_used");
            }
            return true;
        }

        public static bool MoYao8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao8_used"))
            {
                // 增加80点灵性XuLie (原为800点，减少10倍)
                actor.ChangeXuLie(40f);
                // 添加已使用标记
                actor.addTrait("MoYao8_used");
            }
            return true;
        }

        public static bool MoYao9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao9_used"))
            {
                // 增加240点灵性XuLie (原为2400点，减少10倍)
                actor.ChangeXuLie(120f);
                // 添加已使用标记
                actor.addTrait("MoYao9_used");
            }
            return true;
        }

        public static bool MoYao91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor actor = pTarget.a;
            // 检查是否已经获得过该魔药的灵性加成
            if (!actor.hasTrait("MoYao91_used"))
            {
                // 增加1000点灵性XuLie (原为10000点，减少10倍)
                actor.ChangeXuLie(500f);
                // 添加已使用标记
                actor.addTrait("MoYao91_used");
            }
            return true;
        }
        
        // 检查角色是否拥有唯一性特质
        private static bool HasUniquenessTrait(Actor actor)
        {
            try
            {
                // 唯一性特质通常与高序列相关
                return actor.hasTrait("jinSheng9") || // 假设jinSheng9代表唯一性
                       actor.hasTrait("XuLie93") || // 序列零（真神）可能拥有唯一性
                       // WeiYixing系列特质也是唯一性
                       actor.hasTrait("WeiYixing1") ||
                       actor.hasTrait("WeiYixing2") ||
                       actor.hasTrait("WeiYixing3") ||
                       actor.hasTrait("WeiYixing4") ||
                       actor.hasTrait("WeiYixing5") ||
                       actor.hasTrait("WeiYixing6") ||
                       actor.hasTrait("WeiYixing7") ||
                       actor.hasTrait("WeiYixing8") ||
                       actor.hasTrait("WeiYixing9") ||
                       actor.hasTrait("WeiYixing10") ||
                       actor.hasTrait("WeiYixing11") ||
                       actor.hasTrait("WeiYixing1+") ||
                       actor.hasTrait("WeiYixing2+") ||
                       actor.hasTrait("WeiYixing3+") ||
                       actor.hasTrait("WeiYixing4+") ||
                       actor.hasTrait("WeiYixing5+") ||
                       actor.hasTrait("WeiYixing6+") ||
                       actor.hasTrait("WeiYixing7+") ||
                       actor.hasTrait("WeiYixing8+") ||
                       actor.hasTrait("WeiYixing9+") ||
                       actor.hasTrait("WeiYixing10+") ||
                       actor.hasTrait("WeiYixing11+");
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        // 检查角色是否拥有指定数量的唯一性特质
        private static bool HasMultipleUniquenessTraits(Actor actor, int requiredCount)
        {
            try
            {
                int count = 0;
                string[] uniquenessTraits = {
                    "jinSheng9", "XuLie93",
                    "WeiYixing1", "WeiYixing2", "WeiYixing3", "WeiYixing4", "WeiYixing5",
                    "WeiYixing6", "WeiYixing7", "WeiYixing8", "WeiYixing9", "WeiYixing10", "WeiYixing11",
                    "WeiYixing1+", "WeiYixing2+", "WeiYixing3+", "WeiYixing4+", "WeiYixing5+",
                    "WeiYixing6+", "WeiYixing7+", "WeiYixing8+", "WeiYixing9+", "WeiYixing10+", "WeiYixing11+"
                };
                
                foreach (string trait in uniquenessTraits)
                {
                    if (actor.hasTrait(trait))
                    {
                        count++;
                        if (count >= requiredCount)
                        {
                            return true;
                        }
                    }
                }
                
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        // 检查角色是否拥有指定数量的序列特性
        private static bool HasMultipleXulieTexingTraits(Actor actor, int requiredCount)
        {
            try
            {
                int count = 0;
                string[] xulieTexingTraits = {
                    "XulieTexing9", "XulieTexing91", "XulieTexing92",
                    "XulieTexing1", "XulieTexing2", "XulieTexing3", "XulieTexing4",
                    "XulieTexing5", "XulieTexing6", "XulieTexing7", "XulieTexing8"
                };
                
                foreach (string trait in xulieTexingTraits)
                {
                    if (actor.hasTrait(trait))
                    {
                        count++;
                        if (count >= requiredCount)
                        {
                            return true;
                        }
                    }
                }
                
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        // 九大源质真实伤害方法：拥有NineYuanZhi特质的角色造成10倍自身生命的真实伤害，无特效
        public static bool TrueDamageByNineYuanZhi_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf.isActor() && pTarget != null && pTarget.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                // 检查攻击者是否拥有NineYuanZhi系列特质之一
                bool hasNineYuanZhi = false;
                for (int i = 1; i <= 9; i++)
                {
                    if (attacker.hasTrait("NineYuanZhi" + i))
                    {
                        hasNineYuanZhi = true;
                        break;
                    }
                }
                
                if (hasNineYuanZhi && pTile != null)
                {
                    // 获取攻击者的当前生命值
                    float health = attacker.data.health;
                    
                    // 计算真实伤害：10倍当前生命值
                    int baseTrueDamage = Mathf.RoundToInt(health * 10f);
                    
                    // 计算最终伤害，添加±5%的随机波动
                    float randomFactor = UnityEngine.Random.Range(0.95f, 1.05f);
                    int finalTrueDamage = Mathf.RoundToInt(baseTrueDamage * randomFactor);
                    
                    // 确保至少造成1点伤害
                    if (finalTrueDamage > 0 && targetActor.data.health > 0)
                    {
                        int actualDamage = Mathf.Min(finalTrueDamage, targetActor.data.health);
                        targetActor.restoreHealth(-Mathf.Max(1, actualDamage));
                    }
                    
                    // 无特效
                }
            }
            return false;
        }
    }
}