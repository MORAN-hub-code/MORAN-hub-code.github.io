using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;

namespace XuLie.code
{
    public static class NotificationHelper
    {
        // 境界名称映射表：特质ID -> 中文境界名称
        private static readonly Dictionary<string, string> RealmNameMap = new Dictionary<string, string>
        {
            { "XuLie1", "半超凡" },
            { "XuLie2", "序列九" },
            { "XuLie3", "序列八" },
            { "XuLie4", "序列七" },
            { "XuLie5", "序列六" },
            { "XuLie6", "序列五" },
            { "XuLie7", "半神" },
            { "XuLie8", "圣者" },
            { "XuLie9", "天使" },
            { "XuLie91", "大天使" },
            { "XuLie92", "天使之王" },
            { "XuLie93", "真神" },
            { "XuLie94", "旧日" },
        };

        // 通知队列
        private static readonly Queue<NotificationData> notificationQueue = new Queue<NotificationData>();
        // 当前是否有通知正在显示
        private static bool isNotificationShowing = false;

        // 通知数据结构
        private class NotificationData
        {
            public string message;
            public bool isBreakthrough;
            public Actor actor;
            public string oldTraitId;
            public string newTraitId;

            public NotificationData(string message, bool isBreakthrough = false, Actor actor = null, string oldTraitId = null, string newTraitId = null)
            {
                this.message = message;
                this.isBreakthrough = isBreakthrough;
                this.actor = actor;
                this.oldTraitId = oldTraitId;
                this.newTraitId = newTraitId;
            }
        }
        
        // 唯一性名称映射表：唯一性代码 -> 中文名称
        private static readonly Dictionary<string, string> UniquenessNameMap = new Dictionary<string, string>
        {
            { "WeiYixing1", "'愚者'唯一性" },
            { "WeiYixing2", "'门'唯一性" },
            { "WeiYixing3", "'错误'唯一性" },
            { "WeiYixing4", "'太阳'唯一性" },
            { "WeiYixing5", "'空想家'唯一性" },
            { "WeiYixing6", "'白塔'唯一性" },
            { "WeiYixing7", "'暴君'唯一性" },
            { "WeiYixing8", "'倒吊人'唯一性" },
            { "WeiYixing9", "'月亮'唯一性" },
            { "WeiYixing10", "'黑暗'唯一性" },
            { "WeiYixing11", "'黄昏巨人'唯一性" },
            { "WeiYixing1+", "'红祭司'唯一性" },
            { "WeiYixing2+", "'魔女'唯一性" },
            { "WeiYixing3+", "'母亲'唯一性" },
            { "WeiYixing4+", "'死神'唯一性" },
            { "WeiYixing5+", "'黑皇帝'唯一性" },
            { "WeiYixing6+", "'审判者'唯一性" },
            { "WeiYixing7+", "'深渊'唯一性" },
            { "WeiYixing8+", "'被缚者'唯一性" },
            { "WeiYixing9+", "'隐者'唯一性" },
            { "WeiYixing10+", "'完美者'唯一性" },
            { "WeiYixing11+", "'命运之轮'唯一性" }
        };


        // 金色颜色定义
        private static readonly Color GoldColor = new Color(1f, 0.843f, 0f, 1f);

        public static void ShowNotification(Actor actor, string notificationMessage)
        {
            Debug.Log(notificationMessage);
            
            // 将通知添加到队列
            notificationQueue.Enqueue(new NotificationData(notificationMessage, false, actor));
            
            // 如果当前没有通知正在显示，则显示下一条通知
            if (!isNotificationShowing)
            {
                ShowNextNotification();
            }
        }

        public static void ShowBreakthroughNotification(Actor actor, string oldTraitId, string newTraitId)
        {
            string oldRealmName = GetRealmName(oldTraitId);
            string newRealmName = GetRealmName(newTraitId);
            
            string message = $"{actor.getName()} 已从 {oldRealmName} 突破到 {newRealmName}！";
            Debug.Log(message);
            
            // 将突破通知添加到队列
            notificationQueue.Enqueue(new NotificationData(message, true, actor, oldTraitId, newTraitId));
            
            // 如果当前没有通知正在显示，则显示下一条通知
            if (!isNotificationShowing)
            {
                ShowNextNotification();
            }
        }

        // 显示队列中的下一条通知
        private static void ShowNextNotification()
        {
            if (notificationQueue.Count == 0)
            {
                isNotificationShowing = false;
                return;
            }
            
            isNotificationShowing = true;
            NotificationData data = notificationQueue.Dequeue();
            
            // 创建提示UI
            GameObject notificationObj = new GameObject(data.isBreakthrough ? "BreakthroughNotification" : "Notification");
            notificationObj.transform.SetParent(GetCanvas().transform, false);
            
            // 设置全局缩放
            CanvasScaler scaler = notificationObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            
            // 文本组件
            GameObject textObj = new GameObject("Text");
            textObj.transform.SetParent(notificationObj.transform, false);
            Text text = textObj.AddComponent<Text>();
            
            // 尝试加载Arial字体
            Font font = TryLoadFont("Arial.ttf") ?? TryLoadFont("Arial") ?? CreateDefaultFont();
            
            text.font = font;
            text.text = data.message;
            text.alignment = TextAnchor.MiddleCenter;
            text.fontSize = 12;
            text.color = GoldColor;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.resizeTextForBestFit = true;
            text.resizeTextMaxSize = 16;
            text.resizeTextMinSize = 8;
            
            // 添加外发光效果
            Shadow shadow = textObj.AddComponent<Shadow>();
            shadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
            shadow.effectDistance = new Vector2(2f, -2f);
            
            Outline outline = textObj.AddComponent<Outline>();
            outline.effectColor = new Color(0f, 0f, 0f, 0.8f);
            outline.effectDistance = new Vector2(1.5f, 1.5f);
            
            RectTransform textRect = textObj.GetComponent<RectTransform>();
            // 设置通知位置为屏幕上方正中间
            // 使用锚点系统确保在不同分辨率下都能正确显示
            textRect.anchorMin = new Vector2(0.5f, 0.9f);
            textRect.anchorMax = new Vector2(0.5f, 0.9f);
            textRect.pivot = new Vector2(0.5f, 0.5f);
            textRect.sizeDelta = new Vector2(1800, 60);
            
            // 添加淡入淡出效果
            BreakthroughNotification component = notificationObj.AddComponent<BreakthroughNotification>();
            component.Init(text, OnNotificationComplete);
        }



        private static Font TryLoadFont(string fontName)
        {
            try
            {
                Font font = Resources.GetBuiltinResource<Font>(fontName);
                if (font != null)
                {
                    Debug.Log($"成功加载字体: {fontName}");
                    return font;
                }
                Debug.LogWarning($"无法加载字体: {fontName}");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"加载字体时出错: {fontName}, 错误: {e.Message}");
            }
            return null;
        }
        
        private static Font CreateDefaultFont()
        {
            Debug.LogWarning("使用空字体作为后备方案，文本可能不会显示");
            return new Font("Arial");
        }
        
        private static string GetRealmName(string traitId)
        {
            if (RealmNameMap.TryGetValue(traitId, out string realmName))
            {
                return realmName;
            }
            return traitId;
        }
        
        public static string GetUniquenessName(string uniquenessCode)
        {
            if (UniquenessNameMap.TryGetValue(uniquenessCode, out string uniquenessName))
            {
                return uniquenessName;
            }
            return uniquenessCode;
        }
        
        private static Canvas GetCanvas()
        {
            Canvas canvas = GameObject.FindObjectOfType<Canvas>();
            if (canvas == null)
            {
                GameObject canvasObj = new GameObject("Canvas");
                canvas = canvasObj.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = 1000;
                canvasObj.AddComponent<CanvasScaler>();
                canvasObj.AddComponent<GraphicRaycaster>();
            }
            return canvas;
        }
        
        // 通知完成回调
        private static void OnNotificationComplete()
        {
            // 当前通知显示完毕，显示下一条通知
            ShowNextNotification();
        }
    }
    
    public class BreakthroughNotification : MonoBehaviour
    {
        private Text textComponent;
        private float showDuration = 3f;
        private float fadeDuration = 0.5f;
        private System.Action onCompleteCallback;
        
        public void Init(Text text, System.Action onComplete = null)
        {
            textComponent = text;
            onCompleteCallback = onComplete;
            
            // 初始透明度为0
            textComponent.color = new Color(textComponent.color.r, textComponent.color.g, textComponent.color.b, 0);
            
            // 强制更新布局
            Canvas.ForceUpdateCanvases();
            
            // 启动淡入动画
            StartCoroutine(FadeIn());
        }
        
        IEnumerator FadeIn()
        {
            float elapsed = 0;
            while (elapsed < fadeDuration)
            {
                float alpha = Mathf.Lerp(0, 1, elapsed / fadeDuration);
                textComponent.color = new Color(textComponent.color.r, textComponent.color.g, textComponent.color.b, alpha);
                
                // 同时淡入阴影和描边
                foreach (var effect in textComponent.GetComponents<BaseMeshEffect>())
                {
                    if (effect is Shadow shadow)
                    {
                        shadow.effectColor = new Color(shadow.effectColor.r, shadow.effectColor.g, shadow.effectColor.b, alpha * 0.7f);
                    }
                    else if (effect is Outline outline)
                    {
                        outline.effectColor = new Color(outline.effectColor.r, outline.effectColor.g, outline.effectColor.b, alpha * 0.8f);
                    }
                }
                
                elapsed += Time.deltaTime;
                yield return null;
            }
            
            // 保持显示
            yield return new WaitForSeconds(showDuration);
            
            // 启动淡出动画
            StartCoroutine(FadeOut());
        }
        
        IEnumerator FadeOut()
        {
            float elapsed = 0;
            while (elapsed < fadeDuration)
            {
                float alpha = Mathf.Lerp(1, 0, elapsed / fadeDuration);
                textComponent.color = new Color(textComponent.color.r, textComponent.color.g, textComponent.color.b, alpha);
                
                // 同时淡出阴影和描边
                foreach (var effect in textComponent.GetComponents<BaseMeshEffect>())
                {
                    if (effect is Shadow shadow)
                    {
                        shadow.effectColor = new Color(shadow.effectColor.r, shadow.effectColor.g, shadow.effectColor.b, alpha * 0.7f);
                    }
                    else if (effect is Outline outline)
                    {
                        outline.effectColor = new Color(outline.effectColor.r, outline.effectColor.g, outline.effectColor.b, alpha * 0.8f);
                    }
                }
                
                elapsed += Time.deltaTime;
                yield return null;
            }
            
            // 销毁对象
            Destroy(gameObject);
            
            // 通知显示完毕，调用回调函数
            if (onCompleteCallback != null)
            {
                onCompleteCallback();
            }
        }
    }
}