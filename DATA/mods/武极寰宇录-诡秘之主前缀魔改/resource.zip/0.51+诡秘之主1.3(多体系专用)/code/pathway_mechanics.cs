using System.Collections.Generic;
using System.Linq;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;
using static XuLie.code.traitAction;

namespace XuLie.code
{
    internal class pathway_mechanics
    {
        // 存储每个角色每种机制的最后触发年份
        // 格式: 角色ID_机制名称 -> 最后触发年份
        private static Dictionary<string, int> lastTriggeredYear = new Dictionary<string, int>();
        
        // 存储途径与唯一性特质的映射关系
        private static Dictionary<string, List<string>> _pathwayToUniquenessTraits = new Dictionary<string, List<string>>();
        
        public static void Init()
        {
            // 初始化途径与唯一性特质的映射关系
            InitializePathwayUniquenessMap();
        }
        
        // 初始化途径与唯一性特质的映射关系
        private static void InitializePathwayUniquenessMap()
        {
            // 每个途径对应的唯一性特质列表
            _pathwayToUniquenessTraits["占卜家"] = new List<string> { "WeiYixing1", "WeiYixing1+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["学徒"] = new List<string> { "WeiYixing2", "WeiYixing2+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["偷盗者"] = new List<string> { "WeiYixing3", "WeiYixing3+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["歌颂者"] = new List<string> { "WeiYixing4", "WeiYixing4+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["观众"] = new List<string> { "WeiYixing5", "WeiYixing5+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["阅读者"] = new List<string> { "WeiYixing6", "WeiYixing6+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["水手"] = new List<string> { "WeiYixing7", "WeiYixing7+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["秘祈人"] = new List<string> { "WeiYixing8", "WeiYixing8+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["药师"] = new List<string> { "WeiYixing9", "WeiYixing9+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["不眠者"] = new List<string> { "WeiYixing10", "WeiYixing10+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["战士"] = new List<string> { "WeiYixing11", "WeiYixing11+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["猎人"] = new List<string> { "WeiYixing1+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["刺客"] = new List<string> { "WeiYixing2+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["耕种者"] = new List<string> { "WeiYixing3+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["收尸人"] = new List<string> { "WeiYixing4+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["律师"] = new List<string> { "WeiYixing5+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["仲裁人"] = new List<string> { "WeiYixing6+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["罪犯"] = new List<string> { "WeiYixing7+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["囚犯"] = new List<string> { "WeiYixing8+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["窥秘人"] = new List<string> { "WeiYixing9+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["通识者"] = new List<string> { "WeiYixing10+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
            _pathwayToUniquenessTraits["怪物"] = new List<string> { "WeiYixing11+", "XulieTexing9", "XulieTexing91", "XulieTexing92" };
        }
        
        /// <summary>
        /// 检查机制是否可以在当前时间触发（1分钟内只能触发一次）
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <param name="mechanicsName">机制名称</param>
        /// <returns>是否可以触发</returns>
        private static bool IsMechanicsAvailable(Actor actor, string mechanicsName)
        {
            if (actor == null)
                return false;
            
            // 使用字典存储Actor实例与机制名称的组合
            string key = $"{actor.GetHashCode()}_{mechanicsName}";
            
            // 获取当前游戏时间（秒）
            float currentTime = UnityEngine.Time.time;
            
            // 检查是否存在记录
            if (lastTriggeredYear.TryGetValue(key, out int lastTimeFloat))
            {
                float lastTime = (float)lastTimeFloat;
                // 如果距离上次触发不足60秒，不能再次触发
                if (currentTime - lastTime < 20f)
                    return false;
            }
            
            // 更新最后触发时间
            lastTriggeredYear[key] = (int)currentTime;
            return true;
        }

        /// <summary>
        /// 检查并处理占卜家途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleDivinerMechanics(Actor actor)
        {
            // 检查是否满足占卜家途径特殊机制触发条件
            // 条件：同时拥有TeXing1和XuLie7或者以上特质，且生命值低于一半
            if (IsEligibleForDivinerFullHeal(actor) && IsMechanicsAvailable(actor, "Diviner"))
            {
                // 尝试消耗理智恢复满血
                return TryDivinerFullHeal(actor);
            }
            return false;
        }
        

        
        /// <summary>
        /// 获取角色的途径
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>途径名称</returns>
        public static string GetActorPathway(Actor actor)
        {
            // 直接检查角色的TeXing特质来确定途径
            if (actor.hasTrait("TeXing1")) return "占卜家";
            if (actor.hasTrait("TeXing2")) return "学徒";
            if (actor.hasTrait("TeXing3")) return "偷盗者";
            if (actor.hasTrait("TeXing4")) return "歌颂者";
            if (actor.hasTrait("TeXing5")) return "观众";
            if (actor.hasTrait("TeXing6")) return "阅读者";
            if (actor.hasTrait("TeXing7")) return "水手";
            if (actor.hasTrait("TeXing8")) return "秘祈人";
            if (actor.hasTrait("TeXing9")) return "药师";
            if (actor.hasTrait("TeXing10")) return "不眠者";
            if (actor.hasTrait("TeXing11")) return "战士";
            if (actor.hasTrait("TeXing1+")) return "猎人";
            if (actor.hasTrait("TeXing2+")) return "刺客";
            if (actor.hasTrait("TeXing3+")) return "耕种者";
            if (actor.hasTrait("TeXing4+")) return "收尸人";
            if (actor.hasTrait("TeXing5+")) return "律师";
            if (actor.hasTrait("TeXing6+")) return "仲裁人";
            if (actor.hasTrait("TeXing7+")) return "罪犯";
            if (actor.hasTrait("TeXing8+")) return "囚犯";
            if (actor.hasTrait("TeXing9+")) return "窥秘人";
            if (actor.hasTrait("TeXing10+")) return "通识者";
            if (actor.hasTrait("TeXing11+")) return "怪物";
            
            // 检查高序列特质
            if (actor.hasTrait("XuLie9")) return "序列二";
            if (actor.hasTrait("XuLie91")) return "序列一";
            if (actor.hasTrait("XuLie92")) return "天使之王";
            if (actor.hasTrait("XuLie93")) return "真神";
            if (actor.hasTrait("XuLie94")) return "旧日";
            
            return null;
        }
        
        /// <summary>
        /// 检查角色是否拥有唯一性特质
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否拥有唯一性特质</returns>
        private static bool HasUniquenessTrait(Actor actor)
        {
            // 检查常见的唯一性特质
            string[] uniquenessTraits = {
                "WeiYixing1", "WeiYixing2", "WeiYixing3", "WeiYixing4", "WeiYixing5",
                "WeiYixing6", "WeiYixing7", "WeiYixing8", "WeiYixing9", "WeiYixing10", "WeiYixing11",
                "WeiYixing1+", "WeiYixing2+", "WeiYixing3+", "WeiYixing4+", "WeiYixing5+",
                "WeiYixing6+", "WeiYixing7+", "WeiYixing8+", "WeiYixing9+", "WeiYixing10+", "WeiYixing11+"
            };
            
            foreach (string trait in uniquenessTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            
            return false;
        }
        
        /// <summary>
        /// 获取相同途径的其他高序列角色
        /// </summary>
        /// <param name="actor">当前角色</param>
        /// <param name="pathway">途径名称</param>
        /// <returns>相同途径的其他高序列角色列表</returns>
        private static List<Actor> GetSamePathwayHighSequenceActors(Actor actor, string pathway)
        {
            List<Actor> result = new List<Actor>();
            
            // 获取所有存活的角色
            foreach (Actor otherActor in World.world.units.getSimpleList())
            {
                // 跳过自己
                if (otherActor == actor || !otherActor.isAlive())
                    continue;
                
                // 检查是否拥有高序列特质
                bool hasHighXuLie = otherActor.hasTrait("XuLie9") || 
                                   otherActor.hasTrait("XuLie91") || 
                                   otherActor.hasTrait("XuLie92") || 
                                   otherActor.hasTrait("XuLie93") || 
                                   otherActor.hasTrait("XuLie94");
                
                if (!hasHighXuLie)
                    continue;
                
                // 检查是否是相同途径
                string otherPathway = GetActorPathway(otherActor);
                if (otherPathway == pathway)
                {
                    // 检查是否持有相同途径的唯一性特质
                    if (HasSamePathwayUniquenessTrait(otherActor, pathway))
                    {
                        result.Add(otherActor);
                    }
                }
            }
            
            return result;
        }
        
        /// <summary>
        /// 检查角色是否持有相同途径的唯一性特质
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <param name="pathway">途径名称</param>
        /// <returns>是否持有相同途径的唯一性特质</returns>
        private static bool HasSamePathwayUniquenessTrait(Actor actor, string pathway)
        {
            // 检查角色是否拥有XulieTexing9、XulieTexing91或XulieTexing92特质
            bool hasKeyTraits = actor.hasTrait("XulieTexing9") || 
                              actor.hasTrait("XulieTexing91") || 
                              actor.hasTrait("XulieTexing92");
            
            if (!hasKeyTraits)
                return false;
            
            // 检查角色是否拥有途径对应的WeiYixing系列特质
            if (_pathwayToUniquenessTraits.ContainsKey(pathway))
            {
                foreach (string uniquenessTrait in _pathwayToUniquenessTraits[pathway])
                {
                    if (actor.hasTrait(uniquenessTrait))
                    {
                        return true;
                    }
                }
            }
            
            return false;
        }
        
        /// <summary>
        /// 强制角色攻击目标
        /// </summary>
        /// <param name="attacker">攻击者</param>
        /// <param name="target">目标</param>
        private static void ForceAttackTarget(Actor attacker, Actor target)
        {
            if (attacker == null || target == null || !attacker.isAlive() || !target.isAlive())
                return;
            
            // 取消攻击者当前所有行为
            attacker.cancelAllBeh();
            
            // 尝试直接发起攻击
            try
            {
                // 使用反射调用攻击方法
                System.Reflection.MethodInfo attackMethod = attacker.GetType().GetMethod("Attack", 
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic,
                    null, new System.Type[] { typeof(BaseSimObject) }, null);
                
                if (attackMethod != null)
                {
                    attackMethod.Invoke(attacker, new object[] { target });
                }
                else
                {
                    // 如果找不到Attack方法，尝试直接造成伤害
                    Debug.LogWarning("找不到Attack方法，直接造成伤害");
                    
                    // 直接对目标造成伤害
                    float damage = attacker.stats["damage"] * 1.5f; // 1.5倍攻击力
                    target.getHit(damage, true, AttackType.Other, attacker, false, false, false);
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError("强制攻击失败: " + e.Message);
            }
            
            // 显示战斗通知
            try
            {
                string attackerName = attacker.getName();
                string targetName = target.getName();
                NotificationHelper.ShowNotification(null, $"{attackerName}向{targetName}发起了攻击！争夺途径唯一性！");
            }
            catch {}
        }
        
        /// <summary>
        /// 检查并处理偷盗者途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleThiefMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足偷盗者途径特殊机制触发条件
            // 条件：同时拥有TeXing3和XuLie7或者以上特质
            if (IsEligibleForThiefLifespanSteal(attacker) && IsMechanicsAvailable(attacker, "Thief"))
            {
                // 尝试偷取敌人寿命
                return TryStealLifespan(attacker, target);
            }
            return false;
        }
        
        /// <summary>
        /// 检查并处理祈光人途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleLightbearerMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足祈光人途径特殊机制触发条件
            // 条件：同时拥有TeXing4和XuLie7或者以上特质
            if (IsEligibleForLightbearerFireAttack(attacker) && IsMechanicsAvailable(attacker, "Lightbearer"))
            {
                // 尝试对敌人造成火焰攻击
                return TryLightbearerFireAttack(attacker, target);
            }
            return false;
        }

        /// <summary>
        /// 检查角色是否有资格触发占卜家途径的满血恢复机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForDivinerFullHeal(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing1特质
            bool hasTeXing1 = actor.hasTrait("TeXing1");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 检查生命值是否低于一半
            float currentHealth = actor.getHealth();
            float maxHealth = actor.stats[strings.S.health];
            bool isHealthLow = currentHealth < maxHealth * 0.5f;

            // 同时满足所有条件才返回true
            return hasTeXing1 && hasHighXuLie && isHealthLow;
        }
        
        /// <summary>
        /// 检查角色是否有资格触发偷盗者途径的寿命偷取机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForThiefLifespanSteal(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing3特质
            bool hasTeXing3 = actor.hasTrait("TeXing3");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing3 && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用偷盗者途径的寿命偷取机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否偷取成功</returns>
        private static bool TryStealLifespan(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;

            // 每次攻击偷取敌人50年永久寿命
            const float stealLifespanAmount = 100f;
            
            // 减少目标寿命
            target.ChangeLifespan(-stealLifespanAmount);
            
            // 增加攻击者寿命
            attacker.ChangeLifespan(stealLifespanAmount);
            
            return true;
        }
        
        /// <summary>
        /// 检查角色是否有资格触发祈光人途径的火焰攻击机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForLightbearerFireAttack(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing4特质
            bool hasTeXing4 = actor.hasTrait("TeXing4");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing4 && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用祈光人途径的火焰攻击机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否攻击成功</returns>
        private static bool TryLightbearerFireAttack(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;

            // 计算火焰伤害（基于攻击者攻击力的10%作为额外火焰伤害）
            float fireDamage = attacker.stats["damage"] * 0.1f;
            
            // 应用火焰伤害
            target.getHit(fireDamage, true, AttackType.Fire, attacker, false, false, false);
            
            return true;
        }

        /// <summary>
        /// 尝试使用占卜家途径的满血恢复机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否恢复成功</returns>
        private static bool TryDivinerFullHeal(Actor actor)
        {
            // 检查当前理智值
            float currentLiZhi = actor.GetLiZhi();

            // 恢复需要消耗10点理智
            const float requiredLiZhi = 10f;

            if (currentLiZhi >= requiredLiZhi)
            {
                // 消耗理智
                actor.ChangeLiZhi(-requiredLiZhi);

                // 执行满血恢复逻辑
                FullHealActor(actor);

                return true;
            }
            else
            {
                // 当理智小于10点时添加疯狂效果
                if (currentLiZhi < 10)
                {
                    ApplyMadnessEffect(actor);
                }
                
                return false;
            }
        }

        /// <summary>
        /// 当理智小于10点时添加疯狂特质
        /// </summary>
        /// <param name="actor">角色实例</param>
        private static void ApplyMadnessEffect(Actor actor)
        {
            // 检查是否有坚忍特质
            if (actor.hasTrait("strong_minded"))
            {
                // 有坚忍特质，去除坚忍特质
                actor.removeTrait("strong_minded");
            }
            
            // 添加疯狂特质
            actor.addTrait("madness");
        }
        
        /// <summary>
        /// 使角色恢复全部生命值
        /// </summary>
        /// <param name="actor">需要恢复的角色</param>
        private static void FullHealActor(Actor actor)
        {
            // 恢复全部生命值
            float maxHealth = actor.stats[strings.S.health];
            actor.restoreHealth(Mathf.CeilToInt(maxHealth));
        }
        
        /// <summary>
        /// 检查并处理学徒途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleApprenticeMechanics(Actor actor)
        {
            // 检查是否满足学徒途径特殊机制触发条件并且在时间限制内
            // 条件：同时拥有TeXing2和XuLie7或者以上特质，且生命值低于一半
            if (IsEligibleForApprenticeTeleportation(actor) && IsMechanicsAvailable(actor, "Apprentice"))
            {
                // 尝试随机传送
                return TryApprenticeTeleportation(actor);
            }
            return false;
        }
        
        /// <summary>
        /// 检查角色是否有资格触发学徒途径的随机传送机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForApprenticeTeleportation(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing2特质
            bool hasTeXing2 = actor.hasTrait("TeXing2");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 检查生命值是否低于一半
            float currentHealth = actor.data.health;
            float maxHealth = actor.stats[strings.S.health];
            bool isHealthLow = currentHealth < maxHealth * 0.5f;

            // 同时满足所有条件才返回true
            // 移除了冷却检查，根据用户要求，传送不需要冷却
            return hasTeXing2 && hasHighXuLie && isHealthLow;
        }
        
        /// <summary>
        /// 尝试使用学徒途径的随机传送机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否传送成功</returns>
        private static bool TryApprenticeTeleportation(Actor actor)
        {
            // 执行随机传送
            TeleportActorRandomly(actor);

            // 根据用户要求，移除了冷却设置
            // 现在每次满足条件都可以立即触发传送

            return true;
        }
        
        /// <summary>
        /// 随机传送角色到100x100范围内的位置
        /// </summary>
        /// <param name="actor">需要传送的角色</param>
        // 传送范围常量
        private const int TELEPORT_RANGE_MIN = -100; // 最小传送范围（100x100）
        private const int TELEPORT_RANGE_MAX = 101;  // 最大传送范围（不含）
        // 移除冷却：确保每次满足条件时都能立即触发传送
        
        private static void TeleportActorRandomly(Actor actor)
        {
            try
            {
                // 获取角色当前所在的瓦片位置
                WorldTile currentTile = actor.current_tile;
                if (currentTile == null)
                {
                    Debug.LogError("学徒途径传送失败：无法获取角色当前位置");
                    return;
                }
                
                Vector2Int originalPos = currentTile.pos;
                Vector2Int newPos = originalPos;
                WorldTile newTile = null;
                int maxAttempts = 50; // 最大尝试次数（扩大范围后增加尝试次数）
                int attempts = 0;
                
                // 尝试找到一个不同的、有效的传送位置
                while ((newPos == originalPos || newTile == null) && attempts < maxAttempts)
                {
                    attempts++;
                    // 生成100x100范围内的随机偏移量，确保不会传送到原位置
                    int randomX, randomY;
                    do 
                    {
                        randomX = UnityEngine.Random.Range(TELEPORT_RANGE_MIN, TELEPORT_RANGE_MAX);
                        randomY = UnityEngine.Random.Range(TELEPORT_RANGE_MIN, TELEPORT_RANGE_MAX);
                    } while (randomX == 0 && randomY == 0); // 确保不会传送到原位置
                    
                    // 计算新的位置坐标
                    newPos = new Vector2Int(
                        originalPos.x + randomX,
                        originalPos.y + randomY
                    );
                    
                    // 尝试获取新位置的瓦片
                    newTile = World.world.GetTile(newPos.x, newPos.y);
                }
                
                if (newTile != null)
                {
                    try
                    {
                        // 执行实际的传送操作
                        actor.cancelAllBeh(); // 取消角色当前所有行为
                        
                        // 添加传送前的视觉效果
                        for (int i = 0; i < 3; i++)
                        {
                            actor.spawnParticle(Toolbox.color_blue);
                            UnityEngine.Debug.Log(string.Format("学徒途径传送前特效：{0} 在位置 ({1},{2})", actor.getName(), originalPos.x, originalPos.y));
                        }
                        
                        // 执行传送
                        bool spawnSuccess = false;
                        try
                        {
                            // 确认spawnOn方法存在并调用
                            actor.spawnOn(newTile, 0f);
                            spawnSuccess = true;
                        }
                        catch (System.Exception innerEx)
                        {
                            Debug.LogError("学徒途径传送spawnOn方法失败: " + innerEx.Message);
                            // 尝试使用直接设置位置的方式作为备用方案
                            if (typeof(Actor).GetProperty("current_tile") != null)
                            {
                                Debug.Log("尝试直接设置角色位置");
                                typeof(Actor).GetProperty("current_tile").SetValue(actor, newTile);
                                spawnSuccess = true;
                            }
                        }
                        
                        if (spawnSuccess)
                        {
                            // 添加传送后的视觉效果
                            for (int i = 0; i < 3; i++)
                            {
                                actor.spawnParticle(Toolbox.color_purple);
                            }
                            
                            Debug.Log(string.Format("学徒途径传送机制成功：{0} 从 ({1},{2}) 传送到 ({3},{4})", 
                                actor.getName(), originalPos.x, originalPos.y, newPos.x, newPos.y));
                        }
                        else
                        {
                            Debug.LogError("学徒途径传送失败：所有传送方法均失败");
                        }
                    }
                    catch (System.Exception spawnEx)
                    {
                        // 如果传送过程中出错（可能是位置不可通行），捕获异常并记录
                        Debug.LogError("学徒途径传送失败：目标位置可能不可通行或发生其他错误 - " + spawnEx.Message);
                        // 尝试使用备用传送方法
                        if (currentTile != null && actor != null && actor.isAlive())
                        {
                            // 回退方案：使用原位置重新尝试传送
                            actor.cancelAllBeh();
                            actor.spawnOn(currentTile, 0f);
                            Debug.Log("学徒途径传送使用备用方案：重置角色位置");
                        }
                    }
                }
                else
                {
                    Debug.LogError("学徒途径传送失败：目标位置不存在");
                    // 如果目标位置不存在，使用当前位置作为备用
                    if (currentTile != null)
                    {
                        actor.cancelAllBeh();
                        actor.spawnOn(currentTile, 0f);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError("学徒途径传送机制异常：" + ex.Message + "\n" + ex.StackTrace);
            }
        }
        
        /// <summary>
        /// 检查角色是否有资格触发观众途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForAudienceMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing5特质
            bool hasTeXing5 = actor.hasTrait("TeXing5");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing5 && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用观众途径的特殊机制（拦截敌人攻击）
        /// </summary>
        /// <param name="actor">角色实例（被攻击者）</param>
        /// <returns>攻击是否被拦截</returns>
        private static bool TryAudienceMechanics(Actor actor)
        {
            // 80%概率拦截攻击
            const float interceptChance = 0.8f;
            
            // 生成随机数，判断是否拦截攻击
            if (UnityEngine.Random.value <= interceptChance)
            {
                // 已禁用视觉效果 - 观众途径机制
                // actor.startColorEffect(ActorColorEffect.Red);
                return true; // 攻击被拦截
            }
            
            return false; // 攻击未被拦截
        }
        
        /// <summary>
        /// 检查并处理观众途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例（被攻击者）</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleAudienceMechanics(Actor actor)
        {
            // 检查是否满足观众途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForAudienceMechanics(actor) && IsMechanicsAvailable(actor, "Audience"))
            {
                // 尝试拦截攻击
                return TryAudienceMechanics(actor);
            }
            return false;
        }

        /// <summary>
        /// 检查角色是否有资格触发水手途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForSailorMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing7特质
            bool hasTeXing7 = actor.hasTrait("TeXing7");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing7 && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用水手途径的特殊机制（造成基于XuLie值的100倍真实伤害）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发</returns>
        private static bool TrySailorMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;

            // 获取攻击者的XuLie值
            float xuLieValue = GetActorXuLieValue(attacker);
            
            // 计算真实伤害（XuLie值的100倍）
            float trueDamage = xuLieValue * 100f;
            
            // 应用真实伤害（忽略防御）
            target.getHit(trueDamage, true, AttackType.Other, attacker, false, false, false);
            
            // 已禁用视觉效果 - 水手途径机制
            // attacker.startColorEffect(ActorColorEffect.White);
            
            // 已禁用闪电特效 - 水手途径机制
            
            return true;
        }

        /// <summary>
        /// 获取角色的XuLie值
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>XuLie值</returns>
        private static float GetActorXuLieValue(Actor actor)
        {
            // 检查角色是否拥有各种XuLie特质并返回对应的值
            if (actor.hasTrait("XuLie9") || actor.hasTrait("XuLie9+"))
                return 7f;
            if (actor.hasTrait("XuLie91") || actor.hasTrait("XuLie91+"))
                return 91f;
            if (actor.hasTrait("XuLie92") || actor.hasTrait("XuLie92+"))
                return 92f;
            if (actor.hasTrait("XuLie93") || actor.hasTrait("XuLie93+"))
                return 93f;
            if (actor.hasTrait("XuLie94") || actor.hasTrait("XuLie94+"))
                return 94f;
            
            // 默认返回0
            return 0f;
        }
        
        /// <summary>
        /// 统一获取角色当前生命值的方法
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>当前生命值</returns>
        private static float GetActorCurrentHealth(Actor actor)
        {
            if (actor == null || !actor.isAlive())
            {
                return 0f;
            }
            
            try
            {
                // 优先使用data.health属性
                return actor.data.health;
            }
            catch (System.Exception)
            {
                // 如果data.health不可用，返回0
                return 0f;
            }
        }
        
        /// <summary>
        /// 统一获取角色最大生命值的方法
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>最大生命值</returns>
        private static float GetActorMaxHealth(Actor actor)
        {
            if (actor == null || !actor.isAlive())
            {
                return 0f;
            }
            
            try
            {
                // 优先使用stats[strings.S.health]属性
                return actor.stats[strings.S.health];
            }
            catch (System.Exception)
            {
                // 如果stats不可用，返回0
                return 0f;
            }
        }

        /// <summary>
        /// 检查并处理水手途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleSailorMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足水手途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForSailorMechanics(attacker) && IsMechanicsAvailable(attacker, "Sailor"))
            {
                // 尝试造成基于XuLie值的100倍真实伤害
                return TrySailorMechanics(attacker, target);
            }
            return false;
        }
        
        /// <summary>
        /// 检查角色是否有资格触发战士途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForWarriorMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing11特质
            bool hasTeXing11 = actor.hasTrait("TeXing11") || actor.hasTrait("TeXing11+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing11 && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用战士途径的特殊机制（添加Shield效果）
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否成功触发</returns>
        private static bool TryWarriorMechanics(Actor actor)
        {
            // 添加Shield效果，持续5秒
            const float shieldDuration = 5f;
            
            // 尝试添加Shield状态效果给自己
            if (actor.addStatusEffect("shield", shieldDuration, true))
            {
                // 已禁用视觉效果 - 战士途径机制
                // actor.startColorEffect(ActorColorEffect.White);
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// 检查并处理战士途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleWarriorMechanics(Actor actor)
        {
            // 检查是否满足战士途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForWarriorMechanics(actor) && IsMechanicsAvailable(actor, "Warrior"))
            {
                // 尝试添加Shield效果
                return TryWarriorMechanics(actor);
            }
            return false;
        }

        /// <summary>
        /// 检查角色是否有资格触发刺客途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForAssassinMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing2特质
            bool hasTeXing2 = actor.hasTrait("TeXing2") || actor.hasTrait("TeXing2+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing2 && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用刺客途径的特殊机制（30%概率让敌人陷入晕眩）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发</returns>
        private static bool TryAssassinMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;

            // 30%概率让敌人陷入晕眩
            const float stunChance = 0.3f;
            const float stunDuration = 5f; // 晕眩持续时间（秒）

            if (UnityEngine.Random.value <= stunChance)
            {
                // 尝试添加Stunned状态效果
                if (target.addStatusEffect("stunned", stunDuration, true))
                {
                    // 取消敌人当前所有行为
                    target.cancelAllBeh();
                    
                    // 设置等待时间
                    target.makeWait(stunDuration);
                    
                    // 已禁用视觉效果 - 刺客途径机制
                    // attacker.startColorEffect(ActorColorEffect.White);
                    // target.startColorEffect(ActorColorEffect.White);
                    
                    return true;
                }
            }
            
            return false;
        }

        /// <summary>
        /// 检查并处理刺客途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleAssassinMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足刺客途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForAssassinMechanics(attacker) && IsMechanicsAvailable(attacker, "Assassin"))
            {
                // 尝试让敌人陷入晕眩
                return TryAssassinMechanics(attacker, target);
            }
            return false;
        }

        /// <summary>
        /// 检查角色是否有资格触发猎人途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForHunterMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing1特质
            bool hasTeXing1 = actor.hasTrait("TeXing1") || actor.hasTrait("TeXing1+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing1 && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用猎人途径的特殊机制（当敌人血量降到30%时直接斩杀）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发</returns>
        private static bool TryHunterMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;

            // 获取目标当前生命值和最大生命值
            float currentHealth = target.data.health;
            float maxHealth = target.stats[strings.S.health];

            // 检查目标生命值是否低于30%
            if (currentHealth < maxHealth * 0.3f)
            {
                // 直接斩杀敌人
                target.die();
                
                // 已禁用视觉效果 - 猎人途径机制
                // attacker.startColorEffect(ActorColorEffect.White);
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// 检查并处理猎人途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleHunterMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足猎人途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForHunterMechanics(attacker) && IsMechanicsAvailable(attacker, "Hunter"))
            {
                // 尝试触发斩杀机制
                return TryHunterMechanics(attacker, target);
            }
            return false;
        }

        /// <summary>
        /// 检查角色是否有资格触发倒吊人途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForHangedManMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing8特质
            bool hasTeXing8 = actor.hasTrait("TeXing8");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing8 && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用倒吊人途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否触发成功</returns>
        private static bool TryHangedManMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (target.isAlive())
                return false;

            // 收集目标的所有TeXing特质
            List<string> targetTexingTraits = new List<string>();
            for (int i = 1; i <= 11; i++)
            {
                string traitId = "TeXing" + i;
                if (target.hasTrait(traitId))
                {
                    targetTexingTraits.Add(traitId);
                }
                
                // 检查带+号的TeXing特质
                string traitIdWithPlus = traitId + "+";
                if (target.hasTrait(traitIdWithPlus))
                {
                    targetTexingTraits.Add(traitIdWithPlus);
                }
            }
            
            // 如果目标有TeXing特质且攻击者没有这些特质，则添加给攻击者
            bool addedAnyTrait = false;
            foreach (string texingTrait in targetTexingTraits)
            {
                // 排除倒吊人途径自己的特性（TeXing8和TeXing8+）
                if (texingTrait == "TeXing8" || texingTrait == "TeXing8+")
                    continue;
                
                if (!attacker.hasTrait(texingTrait))
                {
                    attacker.addTrait(texingTrait, true);
                    addedAnyTrait = true;
                }
            }
            
            // 显示视觉效果
            if (addedAnyTrait)
            {
                // attacker.startColorEffect(ActorColorEffect.White);
            }
            
            return addedAnyTrait;
        }
        

        
        /// <summary>
        /// 检查并处理倒吊人途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleHangedManMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足倒吊人途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForHangedManMechanics(attacker) && IsMechanicsAvailable(attacker, "HangedMan"))
            {
                // 尝试获得敌人的灵性和途径特性
                return TryHangedManMechanics(attacker, target);
            }
            return false;
        }
        
        #region 耕种者途径机制
        
        /// <summary>
        /// 检查角色是否有资格触发耕种者途径的特殊机制
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否有资格</returns>
        private static bool IsEligibleForFarmerMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing3或TeXing3+特质
            bool hasTeXing3 = actor.hasTrait("TeXing3") || actor.hasTrait("TeXing3+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing3 && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用耕种者途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否触发成功</returns>
        private static bool TryFarmerMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (target == null || !target.isAlive())
            {
                return false;
            }

            // 给对手添加pregnant效果，持续一定时间
            float pregnantDuration = 60f; // 持续60秒
            if (target.addStatusEffect("pregnant", pregnantDuration, true))
            {
                // 添加视觉效果，表示触发了耕种者途径机制
                // attacker.startColorEffect(ActorColorEffect.White);
                // target.startColorEffect(ActorColorEffect.White);
                return true;
            }
            
            return false;
        }
        
        /// <summary>
        /// 检查并处理耕种者途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleFarmerMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足耕种者途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForFarmerMechanics(attacker) && IsMechanicsAvailable(attacker, "Farmer"))
            {
                // 尝试触发生命值恢复机制
                return TryFarmerMechanics(attacker, target);
            }
            return false;
        }
        
        #endregion
        
        #region 不眠者途径机制
        
        /// <summary>
        /// 检查是否满足不眠者途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForSleeplessMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing10特质
            bool hasTeXing10 = actor.hasTrait("TeXing10");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing10 && hasHighXuLie;
        }
        
        private const float DAZZLE_DURATION = 5f; // 昏眩持续时间（秒）

        /// <summary>
        /// 尝试使用不眠者途径的特殊机制（让敌人陷入昏眩）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发</returns>
        private static bool TrySleeplessMechanics(Actor attacker, Actor target)
        {
            // 检查目标是否存活
            if (!target.isAlive())
                return false;
            
            // 检查目标是否是真神或旧日，他们对昏眩效果免疫
            if (target.hasTrait("XuLie93") || target.hasTrait("XuLie94"))
                return false;
            
            // 50%概率让敌人陷入昏眩
            const float dazzleChance = 0.5f;
            
            if (UnityEngine.Random.value <= dazzleChance)
            {
                // 使用睡眠效果替代昏眩效果
                if (target.addStatusEffect("sleeping", DAZZLE_DURATION, true))
                {
                    // 取消敌人当前所有行为
                    target.cancelAllBeh();
                    
                    // 设置等待时间
                    target.makeWait(DAZZLE_DURATION);
                    
                    // 显示视觉效果，表示触发了不眠者途径机制
                    // attacker.startColorEffect(ActorColorEffect.White);
                    // target.startColorEffect(ActorColorEffect.White);
                    
                    return true;
                }
            }
            
            return false;
        }
        
        /// <summary>
        /// 检查并处理不眠者途径的特殊机制
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleSleeplessMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足不眠者途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForSleeplessMechanics(attacker) && IsMechanicsAvailable(attacker, "Sleepless"))
            {
                // 尝试让敌人陷入昏眩
                return TrySleeplessMechanics(attacker, target);
            }
            return false;
        }
        
        /// <summary>
        /// 更新所有角色的睡眠状态（使用游戏内置机制，此方法保持向后兼容）
        /// </summary>
        public static void UpdateDazzleStates()
        {
            // 由于现在使用游戏内置的sleeping状态效果，此方法可以简化
            // 保留此方法以保持向后兼容性
        }
        
        #endregion
        
        #region 药师途径机制
        
        private const string PHARMACIST_DAMAGE_COOLDOWN_KEY = "pharmacist_damage_cooldown";
        private const float PHARMACIST_DAMAGE_INTERVAL = 3f; // 真实伤害间隔时间（秒）
        
        /// <summary>
        /// 检查是否满足药师途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForPharmacistMechanics(Actor actor)
        {
            // 检查是否拥有TeXing9特质
            bool hasTeXing9 = actor.hasTrait("TeXing9");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing9 && hasHighXuLie;
        }
        
        /// <summary>
        /// 检查并处理药师途径的特殊机制（对敌人造成基于血量0.1倍的真实伤害）
        /// </summary>
        /// <param name="actor">药师角色实例</param>
        public static void HandlePharmacistMechanics(Actor actor)
        {
            // 空实现，避免编译错误
        }
        
        /// <summary>
        /// 检查并处理药师途径的特殊机制（对敌人造成基于血量0.1倍的真实伤害）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        public static void HandlePharmacistMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足药师途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForPharmacistMechanics(attacker) && IsMechanicsAvailable(attacker, "Pharmacist"))
            {
                // 检查目标是否存活
                if (!target.isAlive() || target.data.health <= 0)
                    return;
                
                // 造成基于当前血量0.1倍的真实伤害
                float currentHealth = GetActorCurrentHealth(attacker);
                int trueDamage = Mathf.RoundToInt(currentHealth * 0.1f);
                
                // 确保至少造成1点伤害
                int damageToApply = Mathf.Max(1, trueDamage);
                
                // 应用真实伤害
                target.restoreHealth(-damageToApply);
                
                // 显示视觉效果
                // attacker.startColorEffect(ActorColorEffect.White);
            }
        }
        
        #endregion
        
        #region 收尸人途径机制
        
        /// <summary>
        /// 检查是否满足收尸人途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForCorpseCollectorMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing4+特质
            bool hasTeXing4Plus = actor.hasTrait("TeXing4+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing4Plus && hasHighXuLie;
        }
        
        /// <summary>
        /// 检查并处理收尸人途径的特殊机制（10%概率直接让敌人死亡）
        /// </summary>
        /// <param name="actor">收尸人角色实例</param>
        public static void HandleCorpseCollectorMechanics(Actor actor)
        {
            // 空实现，避免编译错误
        }
        
        /// <summary>
        /// 检查并处理收尸人途径的特殊机制（10%概率直接让敌人死亡）
        /// </summary>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="target">被攻击者角色实例</param>
        public static void HandleCorpseCollectorMechanics(Actor attacker, Actor target)
        {
            // 检查是否满足收尸人途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForCorpseCollectorMechanics(attacker) && IsMechanicsAvailable(attacker, "CorpseCollector"))
            {
                // 检查目标是否存活
                if (!target.isAlive() || target.data.health <= 0)
                    return;
                
                // 检查目标是否是真神或旧日，他们对收尸人途径机制免疫
                if (target.hasTrait("XuLie93") || target.hasTrait("XuLie94"))
                    return;
                
                // 10%概率触发直接死亡效果
                const float deathChance = 0.1f;
                
                if (UnityEngine.Random.value <= deathChance)
                {
                    // 直接让敌人死亡
                    target.restoreHealth(-target.data.health);
                    
                    // 显示视觉效果，表示触发了收尸人途径机制
                    // attacker.startColorEffect(ActorColorEffect.White);
                    // target.startColorEffect(ActorColorEffect.Red);
                }
            }
        }
        
        #endregion
        
        #region 律师途径机制
        
        /// <summary>
        /// 检查是否满足律师途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForLawyerMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing5+特质
            bool hasTeXing5Plus = actor.hasTrait("TeXing5+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing5Plus && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用律师途径的特殊机制（扭曲敌人攻击，让攻击不对自己生效，而是对敌人生效）
        /// </summary>
        /// <param name="defender">防御者角色实例</param>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="damage">原始伤害值</param>
        /// <returns>是否成功扭曲攻击（成功则返回true，表示攻击不应对防御者生效）</returns>
        public static bool TryLawyerMechanics(Actor defender, Actor attacker, ref float damage)
        {
            // 检查是否满足律师途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForLawyerMechanics(defender) && IsMechanicsAvailable(defender, "Lawyer"))
            {
                // 检查攻击者是否存活
                if (!attacker.isAlive() || attacker.data.health <= 0)
                    return false;
                
                // 检查攻击者是否是真神或旧日，他们对律师途径机制免疫
                if (attacker.hasTrait("XuLie93") || attacker.hasTrait("XuLie94"))
                    return false;
                
                // 50%概率触发攻击扭曲效果
                const float twistChance = 0.5f;
                
                if (UnityEngine.Random.value <= twistChance)
                {
                    // 扭曲攻击，让攻击伤害转移给攻击者自己
                    attacker.restoreHealth(-Mathf.CeilToInt(damage));
                    
                    // 将原始伤害设置为0，表示攻击不应对防御者生效
                    damage = 0f;
                    
                    // 显示视觉效果，表示触发了律师途径机制
                    // defender.startColorEffect(ActorColorEffect.White);
                    // attacker.startColorEffect(ActorColorEffect.Red);
                    
                    return true;
                }
            }
            
            return false;
        }
        
        #endregion
        
        #region 仲裁人途径机制
        
        /// <summary>
        /// 检查是否满足仲裁人途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForJudgeMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing6+特质
            bool hasTeXing6Plus = actor.hasTrait("TeXing6+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing6Plus && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用仲裁人途径的特殊机制（敌人对自己造成的伤害2倍返还敌人，自己也扣血）
        /// </summary>
        /// <param name="defender">防御者角色实例</param>
        /// <param name="attacker">攻击者角色实例</param>
        /// <param name="damage">原始伤害值</param>
        public static void TryJudgeMechanics(Actor defender, Actor attacker, float damage)
        {
            // 检查是否满足仲裁人途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForJudgeMechanics(defender) && IsMechanicsAvailable(defender, "Judge") && attacker != null && attacker.isAlive())
            {
                // 计算2倍返还的伤害
                int reflectedDamage = Mathf.CeilToInt(damage * 1f);
                
                // 对攻击者造成2倍伤害
                attacker.restoreHealth(-reflectedDamage);
                
                // 显示视觉效果，表示触发了仲裁人途径机制
                // defender.startColorEffect(ActorColorEffect.White);
                // attacker.startColorEffect(ActorColorEffect.Red);
            }
        }
        
        #endregion
        
        #region 罪犯途径机制
        
        /// <summary>
        /// 检查是否满足罪犯途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForCriminalMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing7+特质
            bool hasTeXing7Plus = actor.hasTrait("TeXing7+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing7Plus && hasHighXuLie;
        }
        
        /// <summary>
        /// 尝试使用罪犯途径的特殊机制（50%概率对敌人造成基于100倍自己击败数的伤害）
        /// </summary>
        /// <param name="defender">防御者角色实例（罪犯途径角色）</param>
        /// <param name="attacker">攻击者角色实例</param>
        public static void TryCriminalMechanics(Actor defender, Actor attacker)
        {
            // 检查是否满足罪犯途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForCriminalMechanics(defender) && IsMechanicsAvailable(defender, "Criminal") && attacker != null && attacker.isAlive())
            {
                // 50%概率触发
                if (UnityEngine.Random.value <= 0.5f)
                {
                    // 获取角色的击败数
                    float killCount = defender.data.kills;
                    int kills = Mathf.CeilToInt(killCount);
                    
                    // 计算基于100倍击败数的伤害
                    int criminalDamage = kills * 100;
                    
                    // 对攻击者造成伤害
                    attacker.restoreHealth(-criminalDamage);
                    
                    // 显示视觉效果，表示触发了罪犯途径机制
                    // defender.startColorEffect(ActorColorEffect.White);
                    // attacker.startColorEffect(ActorColorEffect.Red);
                }
            }
        }
        
        #endregion

        #region 囚犯途径机制
        public static bool IsEligibleForPrisonerMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing8+特质
            bool hasTeXing8Plus = actor.hasTrait("TeXing8+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing8Plus && hasHighXuLie;
        }

        public static void TryPrisonerMechanics(Actor attacker, Actor defender)
        {
            // 检查攻击者是否符合囚犯途径机制的条件并且在时间限制内
            if (!IsEligibleForPrisonerMechanics(attacker) || !IsMechanicsAvailable(attacker, "Prisoner"))
            {
                return;
            }

            // 为敌人添加100秒Cursed效果
            float cursedDuration = 100f; // 持续时间100秒
            if (defender.addStatusEffect("cursed", cursedDuration, true))
            {
                // 可以添加视觉效果或其他反馈
                // defender.startColorEffect(ActorColorEffect.Red);
            }
        }
        #endregion

        #region 窥秘人途径机制
        public static bool IsEligibleForSeerMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing9+特质
            bool hasTeXing9Plus = actor.hasTrait("TeXing9+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing9Plus && hasHighXuLie;
        }

        public static void TrySeerMechanics(Actor attacker, Actor defender)
        {
            // 检查攻击者是否符合窥秘人途径机制的条件并且在时间限制内
            if (!IsEligibleForSeerMechanics(attacker) || !IsMechanicsAvailable(attacker, "Seer"))
            {
                return;
            }

            // 每次攻击扣除对手5点理智
            defender.ChangeLiZhi(-5f);
            
            // 添加视觉效果，表示触发了窥秘人途径机制
            // defender.startColorEffect(ActorColorEffect.White);
            
            // 检查对手理智是否归零，如果是则直接死亡
            if (defender.GetLiZhi() <= 0 && defender.isAlive())
            {
                defender.die();
            }
        }
        #endregion
        
        #region 通识者途径机制
        public static bool IsEligibleForSageMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing10+特质
            bool hasTeXing10Plus = actor.hasTrait("TeXing10+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing10Plus && hasHighXuLie;
        }

        public static void TrySageMechanics(Actor attacker, Actor defender)
        {
            // 检查攻击者是否符合通识者途径机制的条件并且在时间限制内
            if (!IsEligibleForSageMechanics(attacker) || !IsMechanicsAvailable(attacker, "Sage"))
            {
                return;
            }

            // 检查防御者是否存活
            if (defender == null || !defender.isAlive())
            {
                return;
            }

            // 获取攻击者当前生命值和最大生命值
            float currentHealth = GetActorCurrentHealth(attacker);
            float maxHealth = GetActorMaxHealth(attacker);

            // 检查生命值是否低于50%
            if (currentHealth < maxHealth * 0.5f)
            {
                // 获取攻击者的攻击力
                float attackPower = attacker.stats["damage"];
                
                // 计算1.5倍攻击力的伤害
                int bonusDamage = Mathf.RoundToInt(attackPower * 1.5f);
                
                // 对防御者造成额外伤害
                defender.restoreHealth(-bonusDamage);
                
                // 添加视觉效果，表示触发了通识者途径机制
                // attacker.startColorEffect(ActorColorEffect.White);
                // defender.startColorEffect(ActorColorEffect.Red);
            }
        }
        #endregion
        
        #region 阅读者途径机制
        /// <summary>
        /// 检查是否满足阅读者途径特殊机制触发条件
        /// </summary>
        /// <param name="actor">角色实例</param>
        /// <returns>是否满足条件</returns>
        private static bool IsEligibleForReaderMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing6特质
            bool hasTeXing6 = actor.hasTrait("TeXing6");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing6 && hasHighXuLie;
        }

        /// <summary>
        /// 尝试使用阅读者途径的特殊机制（对敌人造成Intelligence*100的伤害）
        /// </summary>
        /// <param name="reader">阅读者角色实例</param>
        /// <param name="target">目标角色实例</param>
        /// <returns>是否成功触发机制</returns>
        private static bool TryReaderMechanics(Actor reader, Actor target)
        {
            // 检查目标是否存活
            if (target == null || !target.isAlive())
            {
                return false;
            }

            // 获取阅读者的Intelligence属性值
            float intelligence = reader.stats[strings.S.intelligence];
            
            // 计算伤害：Intelligence*100
            int damage = Mathf.RoundToInt(intelligence * 1000f);
            
            // 对目标造成伤害
            target.restoreHealth(-damage);
            
            // 已禁用视觉效果 - 阅读者途径机制
            // reader.startColorEffect(ActorColorEffect.White);
            // target.startColorEffect(ActorColorEffect.White);
            
            return true;
        }
        
        /// <summary>
        /// 检查并处理阅读者途径的特殊机制
        /// </summary>
        /// <param name="reader">阅读者角色实例</param>
        /// <param name="target">目标角色实例</param>
        /// <returns>是否成功触发机制</returns>
        public static bool HandleReaderMechanics(Actor reader, Actor target)
        {
            // 检查是否满足阅读者途径特殊机制触发条件并且在时间限制内
            if (IsEligibleForReaderMechanics(reader) && IsMechanicsAvailable(reader, "Reader"))
            {
                // 尝试根据对手特质使用对应途径的特殊机制
                return TryReaderMechanics(reader, target);
            }
            return false;
        }
        #endregion
        
        #region 怪物途径机制
        public static bool IsEligibleForMonsterMechanics(Actor actor)
        {
            // 检查角色是否存活
            if (!actor.isAlive())
                return false;

            // 检查是否拥有TeXing11+特质
            bool hasTeXing11Plus = actor.hasTrait("TeXing11+");

            // 检查是否拥有XuLie7或以上特质
            bool hasHighXuLie = actor.hasTrait("XuLie9") || 
                               actor.hasTrait("XuLie91") || 
                               actor.hasTrait("XuLie92") || 
                               actor.hasTrait("XuLie93") || 
                               actor.hasTrait("XuLie94");

            // 同时满足所有条件才返回true
            return hasTeXing11Plus && hasHighXuLie;
        }
        
        public static bool TryMonsterMechanics(Actor actor)
        {
            // 检查是否符合怪物途径机制的条件并且在时间限制内
            if (!IsEligibleForMonsterMechanics(actor) || !IsMechanicsAvailable(actor, "Monster"))
            {
                return false;
            }

            // 每次普攻必定暴击
            // 增加暴击率到100%
            float originalCriticalChance = actor.stats[strings.S.critical_chance];
            actor.stats[strings.S.critical_chance] = 1.0f; // 设置为100%暴击率
            
            // 显示视觉效果，表示触发了怪物途径机制
            // 已禁用视觉效果 - 怪物途径机制
            // actor.startColorEffect(ActorColorEffect.White);
            
            // 临时增加一个行为完成后的回调，确保在攻击完成后恢复原始暴击率
            // 使用计时器确保即使没有立即攻击也能恢复原始暴击率
            UnityEngine.MonoBehaviour.print("怪物途径机制触发: 100%暴击率已激活");
            
            // 创建一个临时的MonoBehaviour来处理计时器
            UnityEngine.GameObject tempObject = new UnityEngine.GameObject("MonsterMechanicsTimer");
            UnityEngine.MonoBehaviour.DontDestroyOnLoad(tempObject);
            MonsterMechanicsTimer timer = tempObject.AddComponent<MonsterMechanicsTimer>();
            timer.Initialize(actor, originalCriticalChance);
            
            return true;
        }
        
        // 用于怪物途径机制的计时器组件
        private class MonsterMechanicsTimer : UnityEngine.MonoBehaviour
        {
            private Actor targetActor;
            private float originalCriticalChance;
            private float timer = 0f;
            private const float MAX_DURATION = 1f; // 最大持续时间，确保暴击率一定会被恢复
            
            public void Initialize(Actor actor, float originalChance)
            {
                targetActor = actor;
                originalCriticalChance = originalChance;
            }
            
            private void Update()
            {
                timer += UnityEngine.Time.deltaTime;
                
                // 如果角色死亡或者计时器超过最大值，恢复原始暴击率
                if (targetActor == null || !targetActor.isAlive() || timer >= MAX_DURATION)
                {
                    if (targetActor != null && targetActor.isAlive())
                    {
                        targetActor.stats[strings.S.critical_chance] = originalCriticalChance;
                        UnityEngine.MonoBehaviour.print("怪物途径机制结束: 暴击率已恢复到原值");
                    }
                    
                    // 销毁计时器对象
                    UnityEngine.Object.Destroy(gameObject);
                }
            }
        }
        
        #endregion
    }
}