namespace XuLie.code
{
    internal class stats
    {
        public static BaseStatAsset Resist;

        public static BaseStatAsset LiZhi;
        
        public static BaseStatAsset JinBang;

        public static void Init()
        {
            BaseStatAsset XuLie = new BaseStatAsset();
            XuLie.id = "XuLie";
            XuLie.normalize = true;
            XuLie.normalize_min = -999999;
            XuLie.normalize_max = 999999;
            //XuLie.multiplier = true;
            XuLie.used_only_for_civs = false;
            AssetManager.base_stats_library.add(XuLie);

            // 定义 LiZhi 属性
            LiZhi = new BaseStatAsset();
            LiZhi.id = "LiZhi";
            LiZhi.normalize = true;
            LiZhi.normalize_min = 0;
            LiZhi.normalize_max = 999999;
            LiZhi.used_only_for_civs = false;
            AssetManager.base_stats_library.add(LiZhi);
            
            // 定义 JinBang 属性
            JinBang = new BaseStatAsset();
            JinBang.id = "JinBang";
            JinBang.normalize = true;
            JinBang.normalize_min = 0;
            JinBang.normalize_max = 99999999;
            JinBang.used_only_for_civs = false;
            AssetManager.base_stats_library.add(JinBang);

            // 定义 Resist 属性
            Resist = new BaseStatAsset();
            Resist.id = "Resist";
            Resist.normalize = true;
            Resist.normalize_min = 0;
            Resist.normalize_max = 999999;
            Resist.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Resist);

            BaseStatAsset Dodge = new BaseStatAsset();
            Dodge.id = "Dodge";// 闪避率
            Dodge.normalize = true;
            Dodge.normalize_min = 0;
            Dodge.normalize_max = 99999;
            Dodge.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Dodge);

            BaseStatAsset Accuracy = new BaseStatAsset();
            Accuracy.id = "Accuracy";// 命中率
            Accuracy.normalize = true;
            Accuracy.normalize_min = 0;
            Accuracy.normalize_max = 99999;
            Accuracy.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Accuracy);
        }
    }
}