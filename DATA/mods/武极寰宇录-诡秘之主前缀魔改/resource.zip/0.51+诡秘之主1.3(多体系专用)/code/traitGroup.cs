using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XuLie
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset XuLie = new ActorTraitGroupAsset();
            XuLie.id = "XuLie";
            XuLie.name = "trait_group_XuLie";
            XuLie.color = "#FFFF00";
            AssetManager.trait_groups.add(XuLie);
            

            ActorTraitGroupAsset JinSheng = new ActorTraitGroupAsset();
            JinSheng.id = "JinSheng";
            JinSheng.name = "trait_group_JinSheng";
            JinSheng.color = "#00FF00";
            AssetManager.trait_groups.add(JinSheng);


            ActorTraitGroupAsset NineYuanZhi = new ActorTraitGroupAsset();
            NineYuanZhi.id = "NineYuanZhi";
            NineYuanZhi.name = "trait_group_NineYuanZhi";
            NineYuanZhi.color = "#FFA500";
            AssetManager.trait_groups.add(NineYuanZhi);

            ActorTraitGroupAsset ChaofanXuemai = new ActorTraitGroupAsset();
            ChaofanXuemai.id = "ChaofanXuemai";
            ChaofanXuemai.name = "trait_group_ChaofanXuemai";
            ChaofanXuemai.color = "#FF4500"; // 橙红色
            AssetManager.trait_groups.add(ChaofanXuemai);

            ActorTraitGroupAsset weiYixingGroup = new ActorTraitGroupAsset
            {
                id = "WeiYixing",
                name = "trait_group_WeiYixing",
                color = "#8A2BE2" // 紫罗兰色
            };
            AssetManager.trait_groups.add(weiYixingGroup);

            ActorTraitGroupAsset TeXing = new ActorTraitGroupAsset();
            TeXing.id = "TeXing";
            TeXing.name = "trait_group_TeXing";
            TeXing.color = "#0000FF"; // 蓝色
            AssetManager.trait_groups.add(TeXing);

            // 魔药分组
            ActorTraitGroupAsset MoYao = new ActorTraitGroupAsset();
            MoYao.id = "MoYao";
            MoYao.name = "trait_group_MoYao";
            MoYao.color = "#800080"; // 紫色
            AssetManager.trait_groups.add(MoYao);
            
            ActorTraitGroupAsset XulieTexing = new ActorTraitGroupAsset();
            XulieTexing.id = "XulieTexing";
            XulieTexing.name = "trait_group_XulieTexing";
            XulieTexing.color = "#00FFFF"; // 青色
            AssetManager.trait_groups.add(XulieTexing);

            // 辅助材料分组
            ActorTraitGroupAsset FuzhuCailiao = new ActorTraitGroupAsset();
            FuzhuCailiao.id = "FuzhuCailiao";
            FuzhuCailiao.name = "trait_group_FuzhuCailiao";
            FuzhuCailiao.color = "#FFFFCC"; // 淡黄色
            AssetManager.trait_groups.add(FuzhuCailiao);

            // 诡秘身份分组
            ActorTraitGroupAsset GuimiShenfen = new ActorTraitGroupAsset();
            GuimiShenfen.id = "GuimiShenfen";
            GuimiShenfen.name = "trait_group_GuimiShenfen";
            GuimiShenfen.color = "#FF00FF"; // 紫红色
            AssetManager.trait_groups.add(GuimiShenfen);
        }
    }
}