using UnityEngine;
using System.Reflection;
using System;

namespace VideoCopilot.code.utils
{
    public static class ActorExtensions
    {
        private const string xuLie_key = "xulie.xuLieNum";
        private const string liZhi_key = "xulie.liZhiNum";
        private const string jinBang_key = "xulie.jinBangNum";
        private const string lifespan_key = "strings.S.lifespan";
        private const string last_damage_time_key = "damage.last_damage_time";
        private const string damage_in_last_second_key = "damage.damage_in_last_second";
        private const string kills_key = "stats.kills";

        // 序列值相关方法
        public static float GetXuLie(this Actor actor)
        {
            actor.data.get(xuLie_key, out float val, 0);
            return val;
        }

        public static void SetXuLie(this Actor actor, float val)
        {
            actor.data.set(xuLie_key, val);
        }

        public static void ChangeXuLie(this Actor actor, float delta)
        {
            actor.data.get(xuLie_key, out float val, 0);
            val += delta;
            actor.data.set(xuLie_key, Mathf.Max(0, val));
        }

        public static int GetKills(this Actor actor)
        {
            actor.data.get(kills_key, out int val, 0);
            return val;
        }
        
        public static void SetKills(this Actor actor, int val)
        {
            actor.data.set(kills_key, val);
        }
        
        public static void IncrementKills(this Actor actor)
        {
            int currentKills = actor.GetKills();
            actor.SetKills(currentKills + 1);
        }

        // 获取基于境界的理智上限
        public static float GetLiZhiMax(this Actor actor)
        {
            // 根据不同序列等级设置不同的理智上限
            if (actor.hasTrait("XuLie94")) // 旧日
                return 3000;
            else if (actor.hasTrait("XuLie93")) // 真神
                return 1000;
            else if (actor.hasTrait("XuLie9") || actor.hasTrait("XuLie91") || actor.hasTrait("XuLie92")) // 序列二天使以上
                return 500;
            else if (actor.hasTrait("XuLie7") || actor.hasTrait("XuLie8")) // 序列四半神以上
                return 200;
            
            // 其他情况固定理智上限为100点
            return 100;
        }
        
        // 理智值相关方法
        public static float GetLiZhi(this Actor actor)
        {
            actor.data.get(liZhi_key, out float val, 100); // 基础100点
            return val;
        }

        public static void SetLiZhi(this Actor actor, float val)
        {
            float maxLiZhi = actor.GetLiZhiMax();
            actor.data.set(liZhi_key, Mathf.Clamp(val, 0, maxLiZhi));
        }

        public static void ChangeLiZhi(this Actor actor, float delta)
        {
            actor.data.get(liZhi_key, out float val, 0);
            val += delta;
            float maxLiZhi = actor.GetLiZhiMax();
            actor.data.set(liZhi_key, Mathf.Clamp(val, 0, maxLiZhi));
        }
        
        // 金磅值相关方法
        public static float GetJinBang(this Actor actor)
        {
            actor.data.get(jinBang_key, out float val, 0); // 基础0点
            return val;
        }

        public static void SetJinBang(this Actor actor, float val)
        {
            // 暂时不设置上限，允许通过各种方式增加金磅
            actor.data.set(jinBang_key, Mathf.Max(0, val));
        }

        public static void ChangeJinBang(this Actor actor, float delta)
        {
            actor.data.get(jinBang_key, out float val, 0);
            val += delta;
            actor.data.set(jinBang_key, Mathf.Max(0, val));
        }

        // 获取角色位格等级
        public static int GetRealmLevel(this Actor actor)
        {
            // 旧日: XuLie94
            if (actor.hasTrait("XuLie94"))
            {
                return 5; // 旧日
            }
            // 真神: XuLie93
            else if (actor.hasTrait("XuLie93"))
            {
                return 4; // 真神
            }
            // 天使: XuLie9~XuLie92
            else if (actor.hasTrait("XuLie9") || actor.hasTrait("XuLie91") || actor.hasTrait("XuLie92"))
            {
                return 3; // 天使
            }
            // 半神: XuLie7~XuLie8
            else if (actor.hasTrait("XuLie7") || actor.hasTrait("XuLie8"))
            {
                return 2; // 半神
            }
            // 非凡者: XuLie2~XuLie6
            else if (actor.hasTrait("XuLie2") || actor.hasTrait("XuLie3") || 
                     actor.hasTrait("XuLie4") || actor.hasTrait("XuLie5") || 
                     actor.hasTrait("XuLie6"))
            {
                return 1; // 非凡者
            }
            // 凡人: 无特殊特质
            else
            {
                return 0; // 凡人
            }
        }

        // 获取最后一次受到伤害的时间
        public static float GetLastDamageTime(this Actor actor)
        {
            actor.data.get(last_damage_time_key, out float val, 0);
            return val;
        }

        // 设置最后一次受到伤害的时间
        public static void SetLastDamageTime(this Actor actor, float time)
        {
            actor.data.set(last_damage_time_key, time);
        }

        // 获取1秒内受到的伤害总量
        public static float GetDamageInLastSecond(this Actor actor)
        {
            // 检查是否需要重置伤害计数
            float currentTime = Time.time;
            float lastDamageTime = actor.GetLastDamageTime();
            
            if (currentTime - lastDamageTime > 1f)
            {
                // 超过1秒，重置伤害计数
                actor.data.set(damage_in_last_second_key, 0f);
                return 0f;
            }
            
            actor.data.get(damage_in_last_second_key, out float val, 0);
            return val;
        }

        // 更新1秒内受到的伤害总量
        public static void UpdateDamageInLastSecond(this Actor actor, float damage)
        {
            float currentTime = Time.time;
            float lastDamageTime = actor.GetLastDamageTime();
            
            // 如果超过1秒，重置伤害计数
            if (currentTime - lastDamageTime > 1f)
            {
                actor.data.set(damage_in_last_second_key, damage);
            }
            else
            {
                // 累加伤害
                float currentDamage = actor.GetDamageInLastSecond();
                actor.data.set(damage_in_last_second_key, currentDamage + damage);
            }
            
            // 更新最后伤害时间
            actor.SetLastDamageTime(currentTime);
        }

        // 获取基于境界位格的基础寿命
        public static float GetBaseLifespanByRealm(this Actor actor)
        {
            int realmLevel = actor.GetRealmLevel();
            
            switch (realmLevel)
            {
                case 0: // 凡人
                    return 100f;
                case 1: // 非凡者
                    return 200f;
                case 2: // 半神
                    return 500f;
                case 3: // 天使
                    return 1000f;
                case 4: // 真神
                    return 10000f;
                case 5: // 旧日
                    return float.MaxValue; // 旧日拥有近乎无限寿命
                default:
                    return 100f;
            }
        }
        
        // 寿命相关方法
        public static float GetLifespan(this Actor actor)
        {
            actor.data.get(lifespan_key, out float val, 0f);
            
            // 如果没有设置过寿命或者寿命小于基础寿命，则返回基础寿命
            float baseLifespan = actor.GetBaseLifespanByRealm();
            return val > 0 ? val : baseLifespan;
        }
        
        public static void SetLifespan(this Actor actor, float val)
        {
            actor.data.set(lifespan_key, Mathf.Max(0, val)); // 确保寿命不小于0，不设置上限以允许通过境界提升增加寿命
        }
        
        public static void ChangeLifespan(this Actor actor, float delta)
        {
            float currentLifespan = actor.GetLifespan();
            float newLifespan = currentLifespan + delta;
            
            // 设置新的寿命值
            actor.SetLifespan(newLifespan);
            
            // 如果寿命被偷取完（小于等于0），立即死亡
            if (newLifespan <= 0 && actor.isAlive())
            {
                actor.die();
            }
        }
        
        // 计算基于位格的实际伤害
        public static float CalculateRealmBasedDamage(this Actor attacker, Actor target, float originalDamage)
        {
            int attackerRealm = attacker.GetRealmLevel();
            int targetRealm = target.GetRealmLevel();
            float actualDamage = originalDamage;
            
            // 检查攻击者和目标的位格关系，实现位格减伤机制
            // 凡人(0)攻击规则
            if (attackerRealm == 0)
            {
                if (targetRealm == 1) // 凡人对非凡者
                {
                    // 1秒内最多造成10%非凡者当前灵性的伤害
                    float maxDamage = target.GetXuLie() * 0.1f;
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    float remainingDamage = maxDamage - damageInLastSecond;
                    actualDamage = Mathf.Min(actualDamage, remainingDamage);
                }
                else if (targetRealm == 2) // 凡人对半神
                {
                    // 1秒内最多只能造成1点伤害
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    actualDamage = damageInLastSecond >= 1 ? 0 : Mathf.Min(actualDamage, 1);
                }
                else if (targetRealm >= 3) // 凡人对天使、真神、旧日
                {
                    if (targetRealm >= 4) // 凡人对真神和旧日
                    {
                        // 攻击时自己死亡
                        attacker.die();
                    }
                    // 对天使无法造成伤害
                    actualDamage = 0;
                }
            }
            // 非凡者(1)攻击规则
            else if (attackerRealm == 1)
            {
                if (targetRealm == 2) // 非凡者对半神
                {
                    // 1秒内最多造成10%半神当前灵性的伤害
                    float maxDamage = target.GetXuLie() * 0.1f;
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    float remainingDamage = maxDamage - damageInLastSecond;
                    actualDamage = Mathf.Min(actualDamage, remainingDamage);
                }
                else if (targetRealm == 3) // 非凡者对天使
                {
                    // 1秒内最多只能造成1点伤害
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    actualDamage = damageInLastSecond >= 1 ? 0 : Mathf.Min(actualDamage, 1);
                }
                else if (targetRealm >= 4) // 非凡者对真神和旧日
                {
                    if (targetRealm == 5) // 非凡者对旧日
                    {
                        // 攻击时自己死亡
                        attacker.die();
                    }
                    // 对真神无法造成伤害
                    actualDamage = 0;
                }
            }
            // 半神(2)攻击规则
            else if (attackerRealm == 2)
            {
                if (targetRealm == 3) // 半神对天使
                {
                    // 1秒内最多造成10%天使当前灵性的伤害
                    float maxDamage = target.GetXuLie() * 0.1f;
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    float remainingDamage = maxDamage - damageInLastSecond;
                    actualDamage = Mathf.Min(actualDamage, remainingDamage);
                }
                else if (targetRealm == 4) // 半神对真神
                {
                    // 1秒内最多只能造成1点伤害
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    actualDamage = damageInLastSecond >= 1 ? 0 : Mathf.Min(actualDamage, 1);
                }
                else if (targetRealm == 5) // 半神对旧日
                {
                    // 无法造成伤害
                    actualDamage = 0;
                }
            }
            // 天使(3)攻击规则
            else if (attackerRealm == 3)
            {
                if (targetRealm == 4) // 天使对真神
                {
                    // 1秒内最多造成10%真神当前灵性的伤害
                    float maxDamage = target.GetXuLie() * 0.1f;
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    float remainingDamage = maxDamage - damageInLastSecond;
                    actualDamage = Mathf.Min(actualDamage, remainingDamage);
                }
                else if (targetRealm == 5) // 天使对旧日
                {
                    // 1秒内最多只能造成1点伤害
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    actualDamage = damageInLastSecond >= 1 ? 0 : Mathf.Min(actualDamage, 1);
                }
            }
            // 真神(4)攻击规则
            else if (attackerRealm == 4)
            {
                if (targetRealm == 5) // 真神对旧日
                {
                    // 1秒内最多造成10%旧日当前灵性的伤害
                    float maxDamage = target.GetXuLie() * 0.1f;
                    float damageInLastSecond = target.GetDamageInLastSecond();
                    float remainingDamage = maxDamage - damageInLastSecond;
                    actualDamage = Mathf.Min(actualDamage, remainingDamage);
                }
            }
            
            // 确保伤害不小于0
            actualDamage = Mathf.Max(0, actualDamage);
            
            return actualDamage;
        }
        
        // 设置Actor的名称（为ActorData添加扩展方法）
        public static void setName(this ActorData actorData, string newName)
        {
            if (actorData != null)
            {
                // 尝试通过反射获取Actor对象
                try
                {
                    // 尝试查找ActorData中的actor字段
                    FieldInfo actorField = typeof(ActorData).GetField("actor", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    
                    if (actorField != null)
                    {
                        object actorObj = actorField.GetValue(actorData);
                        if (actorObj is Actor actor)
                        {
                            // 尝试通过反射设置Actor的名称
                            try
                            {
                                // 查找name字段
                                FieldInfo nameField = typeof(Actor).GetField("name", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                if (nameField != null)
                                {
                                    nameField.SetValue(actor, newName);
                                    return;
                                }
                                
                                // 查找name属性
                                PropertyInfo nameProperty = typeof(Actor).GetProperty("name", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                if (nameProperty != null && nameProperty.CanWrite)
                                {
                                    nameProperty.SetValue(actor, newName);
                                    return;
                                }
                                
                                // 如果以上方法都失败，尝试使用setName方法
                                MethodInfo setNameMethod = typeof(Actor).GetMethod("setName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                if (setNameMethod != null)
                                {
                                    setNameMethod.Invoke(actor, new object[] { newName });
                                    return;
                                }
                                
                                // 如果所有方法都失败，尝试使用名称相关的其他字段
                                FieldInfo displayNameField = typeof(Actor).GetField("display_name", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                                if (displayNameField != null)
                                {
                                    displayNameField.SetValue(actor, newName);
                                    return;
                                }
                                
                                Debug.LogWarning("Failed to set actor name: Could not find appropriate field or method");
                            }
                            catch (Exception e)
                            {
                                Debug.LogError("Error setting actor name: " + e.Message);
                            }
                        }
                    }
                    else
                    {
                        Debug.LogWarning("Failed to get actor from ActorData: Could not find 'actor' field");
                    }
                }
                catch (Exception e)
                {
                    Debug.LogError("Error accessing actor from ActorData: " + e.Message);
                }
            }
        }
    }
}