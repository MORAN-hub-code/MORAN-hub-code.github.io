using System.Collections; 
using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using VideoCopilot.code.utils;

namespace XuLie.code
{
    internal class patch
    {
        // 标记窗口初始化状态的静态变量
        public static bool window_creature_info_initialized;

        // 为UnitWindow的OnEnable方法添加后缀补丁
        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            // 如果实例的actor为空或已死亡，则直接返回
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            
            // 添加延迟初始化
            __instance.StartCoroutine(DelayedInit(__instance));
        }

        // 延迟初始化方法，确保原生UI完成初始化后再执行自定义UI初始化
        private static IEnumerator DelayedInit(UnitWindow window) 
        {
            // 等待一帧确保原生UI完成初始化
            yield return null; 
    
            // 如果窗口信息未初始化，则进行初始化
            if (!window_creature_info_initialized) {
                UnitWindowStatsIcon.Initialize(window);
                window_creature_info_initialized = true;
            }
    
            // 启用窗口统计图标
            UnitWindowStatsIcon.OnEnable(window, window.actor);
        }

        // 为MapAction的checkLightningAction方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            // 获取世界中所有单位的列表
            List<Actor> simpleList = World.world.units.getSimpleList();
            
            // 遍历所有单位，检查是否在闪电范围内
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    // 如果是神之手指，则执行相应动作
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        // 如果不是不朽且随机概率为20%，设置标志位
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        // 注释掉成就检查信号（SignalLibrary.check_achievement_may_i_interrupt不存在）
                        // SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        // BehaviourTaskActor task = actor.ai.task;
                        // SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }

        // 为Actor的makeStunned方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            // 随机增加眩晕时间的10%
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            // 取消所有行为
            __instance.cancelAllBeh();
            // 设置等待时间
            __instance.makeWait(pTime);
            
            // 如果没有防火特质，则添加眩晕状态效果，否则不添加眩晕状态效果
            if (!__instance.hasTrait("fire_proof"))
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }

        // 为ActionLibrary的addStunnedEffectOnTarget20方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "addStunnedEffectOnTarget20")]
        // 添加眩晕效果到目标（20%概率）
        public static bool addStunnedEffectOnTarget20_Patch(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 检查目标是否有效（未死亡、非建筑）
            if (pTarget.isRekt() || pTarget.isBuilding()) 
            {
                return false;
            }

            // 检查随机概率（20%）
            if (!Randy.randomChance(0.2f))
            {
                return false;
            }

            // 检查目标是否具有防火特质
            if (pTarget.isActor() && pTarget.a.hasTrait("fire_proof"))
            {
                return false;
            }

            // 调用眩晕方法
            return ActionLibrary.addStunnedEffectOnTarget(pSelf, pTarget, pTile);
        }

        // 为Actor的getHit方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            // 记录最后一次攻击类型
            __instance._last_attack_type = pAttackType;
            
            // 闪避机制
            if (pAttacker is Actor attackerActor && __instance.isAlive())
            {
                // 获取攻击者的准确率和目标的闪避率
                float attackerAccuracy = attackerActor.stats["Accuracy"];
                float targetDodge = __instance.stats["Dodge"];
                // 计算有效闪避率，确保在0-100之间
                float effectiveDodge = Mathf.Clamp(targetDodge - attackerAccuracy, 0f, 100f);

                // 如果随机概率超过有效闪避率，则闪避成功
                if (Randy.randomChance(effectiveDodge / 100f))
                {
                    // 已禁用视觉效果
                    // __instance.startColorEffect(ActorColorEffect.White);
                    return false;
                }
            }
        
            // 死亡处理
            if (!__instance.hasHealth())
            {
                // 处理高序列角色死亡
                if (__instance.isActor())
                {
                    traitAction.HandleHighSequenceDeath(__instance.a);
                }
                __instance.batch.c_check_deaths.Add(__instance);
                
                // 处理击杀金磅奖励
                if (pAttacker is Actor attacker && attacker != null && attacker != __instance)
                {
                    HandleKillReward(attacker, __instance);
                }
            }
            
            // 返回true继续执行原方法
            return true;
        }
        
        // 处理击杀奖励
        private static void HandleKillReward(Actor attacker, Actor target)
        {
            if (attacker == null || target == null || attacker == target)
                return;
            
            // 根据目标的XuLie特质给予不同的金磅奖励
            float reward = 0;
            string targetName = target.name ?? "未知目标";
            string realmName = "未知境界";
            
            if (target.hasTrait("XuLie1"))
            {
                reward = 1;
                realmName = "半超凡";
            }
            else if (target.hasTrait("XuLie2"))
            {
                reward = 10;
                realmName = "序列九";
            }
            else if (target.hasTrait("XuLie3"))
            {
                reward = 50;
                realmName = "序列八";
            }
            else if (target.hasTrait("XuLie4"))
            {
                reward = 100;
                realmName = "序列七";
            }
            else if (target.hasTrait("XuLie5"))
            {
                reward = 1000;
                realmName = "序列六";
            }
            else if (target.hasTrait("XuLie6"))
            {
                reward = 10000;
                realmName = "序列五";
            }
            else if (target.hasTrait("XuLie7"))
            {
                reward = 100000;
                realmName = "半神";
            }
            else if (target.hasTrait("XuLie8"))
            {
                reward = 500000;
                realmName = "圣者";
            }
            else if (target.hasTrait("XuLie9"))
            {
                reward = 1000000;
                realmName = "天使";
            }
            else if (target.hasTrait("XuLie91"))
            {
                reward = 5000000;
                realmName = "大天使";
            }
            else if (target.hasTrait("XuLie92"))
            {
                reward = 10000000;
                realmName = "天使之王";
            }
            // XuLie93和XuLie94没有奖励
            
            // 如果有奖励，添加金磅
            if (reward > 0)
            {
                attacker.ChangeJinBang(reward);
            }
        }
        
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "getHit")]
        public static void actorGetHit_postfix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            // 只处理有伤害且有攻击者的情况
            if (pDamage <= 0 || pAttacker == null || !(pAttacker is Actor))
            {
                return;
            }
            
            Actor attacker = pAttacker as Actor;
            
            // 计算基于位格的实际伤害
            float actualDamage = attacker.CalculateRealmBasedDamage(__instance, pDamage);
            
            // 如果计算后的实际伤害小于原始伤害，应用位格免伤
            if (actualDamage < pDamage)
            {
                // 更新1秒内受到的伤害总量
                __instance.UpdateDamageInLastSecond(actualDamage);
                
                // 显示伤害减免信息
                string attackerName = attacker.name ?? "Unknown";
                string targetName = __instance.name ?? "Unknown";
                int attackerRealm = attacker.GetRealmLevel();
                int targetRealm = __instance.GetRealmLevel();
                
                string[] realmNames = { "凡人", "非凡者", "半神", "天使", "真神", "旧日" };
                string attackerRealmName = attackerRealm < realmNames.Length ? realmNames[attackerRealm] : "未知";
                string targetRealmName = targetRealm < realmNames.Length ? realmNames[targetRealm] : "未知";
                
                // 更新最终伤害结果
                pDamage = actualDamage;
            }
            else
            {
                // 伤害没有被减免，也需要更新伤害计数
                __instance.UpdateDamageInLastSecond(pDamage);
            }
            // 调用观众途径机制，在所有扣血判定时都有80%概率不进行扣血判定
            if (pathway_mechanics.HandleAudienceMechanics(__instance))
            {
                // 观众途径机制触发，不进行扣血判定
                return;
            }
                // 调用律师途径机制，扭曲敌人攻击，让攻击不对自己生效，而是对敌人生效
            if (pathway_mechanics.TryLawyerMechanics(__instance, attacker, ref pDamage))
            {
                // 律师途径机制触发，攻击已被扭曲，不进行扣血判定
                return;
            }
                // 调用战士途径机制，在战斗时为符合条件的角色添加Shielded效果
            pathway_mechanics.HandleWarriorMechanics(__instance);
                
                // 调用水手途径机制，检查是否触发基于XuLie值的100倍真实伤害
            pathway_mechanics.HandleSailorMechanics(attacker, __instance);
                
                // 调用怪物途径机制，每次普攻必定暴击
            pathway_mechanics.TryMonsterMechanics(attacker);
                
                // 调用猎人途径机制，当敌人血量降到30%时直接斩杀
            if (pathway_mechanics.HandleHunterMechanics(attacker, __instance))
            {
                    // 猎人途径机制触发，敌人已被斩杀，不进行后续扣血判定
                return;
            }

                // 调用刺客途径机制，30%概率让敌人陷入晕眩
            pathway_mechanics.HandleAssassinMechanics(attacker, __instance);
                            // 定期更新所有角色的昏眩状态
            pathway_mechanics.UpdateDazzleStates();
                // 调用耕种者途径机制，当血量低于80%时恢复生命值
            pathway_mechanics.HandleFarmerMechanics(attacker, __instance);

            // 检查并触发学徒途径的传送机制
            pathway_mechanics.HandleApprenticeMechanics(__instance);
            
            // 检查并触发占卜家途径的半血以下恢复机制
            pathway_mechanics.HandleDivinerMechanics(__instance);
            
            // 检查并触发偷盗者途径的寿命偷取机制
            pathway_mechanics.HandleThiefMechanics(attacker, __instance);
            
            // 检查并触发祈光人途径的火焰攻击机制
            pathway_mechanics.HandleLightbearerMechanics(attacker, __instance);
            
            // 检查并触发倒吊人途径的特殊机制
            pathway_mechanics.HandleHangedManMechanics(attacker, __instance);
            
            // 检查并触发药师途径的特殊机制（对敌人造成基于血量0.1倍的真实伤害）
            pathway_mechanics.HandlePharmacistMechanics(attacker, __instance);
            
            // 检查并触发不眠者途径的特殊机制
            pathway_mechanics.HandleSleeplessMechanics(attacker, __instance);
            
            // 检查并触发收尸人途径的特殊机制（10%概率直接让敌人死亡）
            pathway_mechanics.HandleCorpseCollectorMechanics(attacker, __instance);
            
            // 检查并触发仲裁人途径的特殊机制（敌人对自己造成的伤害2倍返还敌人）
            pathway_mechanics.TryJudgeMechanics(__instance, attacker, pDamage);
            
            // 检查并触发罪犯途径的特殊机制（50%概率对敌人造成基于100倍自己击败数的伤害）
            pathway_mechanics.TryCriminalMechanics(__instance, attacker);
            
            // 调用囚犯途径机制
            pathway_mechanics.TryPrisonerMechanics(attacker, __instance);
            
            // 调用窥秘人途径机制
            pathway_mechanics.TrySeerMechanics(attacker, __instance);
            
            // 调用通识者途径机制
            pathway_mechanics.TrySageMechanics(attacker, __instance);
            
            // 调用阅读者途径机制，根据对手拥有的TeXing特质使用对应途径的特殊机制
            pathway_mechanics.HandleReaderMechanics(attacker, __instance);
        }
        
        // 为ActorTool的applyForceToUnit方法添加前缀补丁
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
        public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            // 计算力量值
            float tForce = pData.knockback * pMod;

            // 如果力量大于0且目标是Actor
            if (tForce > 0f && pTargetToCheck.isActor())
            {
                // 获取目标的抵抗值
                float resistValue = pTargetToCheck.a.stats["Resist"];
                // 计算实际力量，确保不小于0
                tForce = Mathf.Max(tForce - resistValue, 0);

                // 如果力量仍大于0，则应用力量
                if (tForce > 0f)
                {
                    Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                    Vector2 tAttackVec = pData.hit_position;
                    pTargetToCheck.a.calculateForce(
                        tPosStart.x, tPosStart.y,
                        tAttackVec.x, tAttackVec.y,
                        tForce,
                        0f,
                        pCheckCancelJobOnLand
                    );
                }
            }
            
            // 返回false跳过原方法执行
            return false;
        }
    
        // 静态标志，用于控制实时检查的调用频率
        private static float _globalRealTimeCheckTimer = 0f;
        private const float GLOBAL_CHECK_INTERVAL = 60f; // 每60秒全局检查一次
        private static bool _checkPerformedThisInterval = false;
        private static int _checkCounter = 0; // 用于追踪检查次数，控制高序列计数重新计算频率

        // 为Actor的updateAge方法添加后缀补丁
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_XuLiePostfix(Actor __instance)
        {
            // 如果实例为空，直接返回
            if (__instance == null)
            {
                return;
            }

            // 增加全局计时器
            _globalRealTimeCheckTimer += UnityEngine.Time.deltaTime;
            
            // 每30秒执行一次实时检查（通过第一个处理的角色）
            if (_globalRealTimeCheckTimer >= GLOBAL_CHECK_INTERVAL && !_checkPerformedThisInterval)
            {
                _globalRealTimeCheckTimer = 0f;
                _checkPerformedThisInterval = true;
                _checkCounter++;
                
                try
                {
                    traitAction.PerformRealTimeChecks();
                    // 每5分钟（5个检查周期，每个周期60秒）重新计算一次所有高序列计数，确保数据准确性
                    if (_checkCounter % 5 == 0)
                    {
                        traitAction.RecalculateAllHighSequenceCounts();
                    }
                }
                catch (System.Exception ex)
                {
                    UnityEngine.MonoBehaviour.print("执行实时检查时出错: " + ex.Message);
                    UnityEngine.MonoBehaviour.print(ex.StackTrace);
                }
            }
            
            // 在一帧结束后重置检查标志（通过最后处理的角色）
            if (_globalRealTimeCheckTimer < GLOBAL_CHECK_INTERVAL && _checkPerformedThisInterval)
            {
                _checkPerformedThisInterval = false;
            }

            // 获取实例的年龄
            float age = (float)__instance.getAge();
            // 检查是否具有各种特质
            bool hasjinSheng10 = __instance.hasTrait("jinSheng10");// 检查是否具有特质
            bool hasjinSheng9 = __instance.hasTrait("jinSheng9");
            bool hasYizhiYoncun = __instance.hasTrait("yizhiYoncun"); // 检查是否拥有“意志永存”特质

            // 检查是否拥有“赐福”特质
            bool hasjinSheng8 = __instance.hasTrait("jinSheng8");
            if (hasjinSheng8)
            {
                __instance.data.favorite = true;
            }

            // 检查是否拥有混沌帝血特质
            bool haschaofanXuemai7 = __instance.hasTrait("chaofanXuemai7");
            if (haschaofanXuemai7)
            {
                // 直接觉醒扮演法
                string jinSheng4Trait = "jinSheng4";
                // 定义晋升特质数组
                string[] jinShengTraits = {
                    "jinSheng1",
                    "jinSheng2",
                    "jinSheng3",
                    "jinSheng4",
                    "jinSheng7",
                    "jinSheng8",
                    "jinSheng9",
                    "jinSheng10",
                    "martialAptitude1",
                    "martialAptitude2",
                    "martialAptitude3",
                    "martialAptitude4",
                    "martialAptitude7",
                    "martialAptitude8"
                };

                // 检查是否已拥有任何晋升特质
                bool hasAnyjinSheng = false;
                foreach (string trait in jinShengTraits)
                {
                    if (__instance.hasTrait(trait))
                    {
                        hasAnyjinSheng = true;
                        break;
                    }
                }

                // 只有在未拥有任何晋升特质时才觉醒扮演法
                if (!hasAnyjinSheng && !__instance.hasTrait("jinSheng4"))
                {
                    __instance.addTrait("jinSheng4");
                }
            }

            // 出生时（年龄为1）有一定概率获得“意志永存”特质
            if (Mathf.FloorToInt(age) == 1 && !hasYizhiYoncun && Randy.randomChance(0.03f)) // 3% 的概率
            {
                __instance.addTrait("yizhiYoncun", false);
            }
            
            // 检查角色是否已有任何GuimiShenfen特质
            bool hasAnyGuimiShenfen = false;
            string[] guimiShenfenTraits = {
                "GuimiShenfen1", "GuimiShenfen1+", "GuimiShenfen1++",
                "GuimiShenfen2", "GuimiShenfen2+", "GuimiShenfen2++",
                "GuimiShenfen3", "GuimiShenfen3+", "GuimiShenfen3++",
                "GuimiShenfen4", "GuimiShenfen4+", "GuimiShenfen4++",
                "GuimiShenfen5", "GuimiShenfen5+",
                "GuimiShenfen6",
                "GuimiShenfen7"
            };
            
            foreach (string trait in guimiShenfenTraits)
            {
                if (__instance.hasTrait(trait))
                {
                    hasAnyGuimiShenfen = true;
                    break;
                }
            }
            
            // 定义特定种族数组
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };

            // 1岁时，确保每个角色都有一个GuimiShenfen身份特质
            if (Mathf.FloorToInt(age) == 1 && !hasAnyGuimiShenfen && (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {
                // 定义基础身份特质及其概率权重
                string[] baseShenfenTraits = {
                    "GuimiShenfen1", // 平民
                    "GuimiShenfen2", // 神职人员
                    "GuimiShenfen3", // 海盗
                    "GuimiShenfen4", // 侦探
                    "GuimiShenfen5", // 作家
                    "GuimiShenfen6", // 商人
                    "GuimiShenfen7"  // 贵族
                };
                
                // 概率权重，平民概率最高，贵族概率最低
                float[] weights = { 0.445f, 0.21f, 0.16f, 0.105f, 0.055f, 0.02f, 0.005f };
                
                // 根据概率选择一个身份特质
                float randomValue = UnityEngine.Random.value;
                float cumulativeProbability = 0f;
                string selectedTrait = baseShenfenTraits[0]; // 默认选择第一个
                
                for (int i = 0; i < baseShenfenTraits.Length; i++)
                {
                    cumulativeProbability += weights[i];
                    if (randomValue <= cumulativeProbability)
                    {
                        selectedTrait = baseShenfenTraits[i];
                        break;
                    }
                }
                
                // 为角色添加选择的身份特质
                __instance.addTrait(selectedTrait, false);
            }

            // 4岁时获得jinSheng1 - jinSheng10的随机特质
            if (Mathf.FloorToInt(age) == 5 && !hasjinSheng9 && !hasjinSheng10 &&
                !HasAnyFlairTalen(__instance) &&
                (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {

                // 如果已经拥有扮演法（因混沌帝血获得），则跳过此次随机晋升特质觉醒
                if (__instance.hasTrait("jinSheng4"))
                {
                    return;
                }

                // 根据血脉等级计算额外概率
                float bloodlineBonus = 0f;
                if (__instance.hasTrait("chaofanXuemai1"))
                {
                    bloodlineBonus = 0.2f; // 一级血脉提高20%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai2"))
                {
                    bloodlineBonus = 0.3f; // 二级血脉提高30%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai3"))
                {
                    bloodlineBonus = 0.4f; // 三级血脉提高40%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai4"))
                {
                    bloodlineBonus = 0.5f; // 四级血脉提高50%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai5"))
                {
                    bloodlineBonus = 0.6f; // 五级血脉提高60%的概率
                }
                else if (__instance.hasTrait("chaofanXuemai6"))
                {
                    bloodlineBonus = 0.7f; // 六级血脉提高70%的概率
                }

                // 随机概率是否触发特质获得
                if (Randy.randomChance(0.4f + bloodlineBonus))
                {
                    // 定义各晋升特质的权重
                var jinShengWeights = new (string traitId, float weight)[]
                {
                    ("jinSheng1", 14f),
                    ("jinSheng2", 51f),
                    ("jinSheng3", 19.58f),
                    ("jinSheng4", 4.33f),
                    ("jinSheng7", 1.076f),
                    ("jinSheng8", 0.014f),
                };

                // 计算总权重
                float totalWeight = jinShengWeights.Sum(t => t.weight);

                // 生成随机浮点数
                float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                // 遍历权重选择特质
                string selectedjinSheng = "jinSheng1"; // 默认值
                foreach (var jinSheng in jinShengWeights)
                {
                    if (randomValue < jinSheng.weight)
                    {
                        selectedjinSheng = jinSheng.traitId;
                        break;
                    }
                    randomValue -= jinSheng.weight;
                }

                // 添加选中的特质
                __instance.addTrait(selectedjinSheng, false);
                }
            }


            // 定义闱异星特质对序列值的影响字典
            var weiYixingXuLieChanges = new Dictionary<string, float>
            {
                {"WeiYixing1", 100.0f},
                {"WeiYixing2", 100.0f},
                {"WeiYixing3", 100.0f},
                {"WeiYixing4", 100.0f},
                {"WeiYixing5", 100.0f},
                {"WeiYixing6", 100.5f},
                {"WeiYixing7", 100.0f},
                {"WeiYixing8", 100.0f},
                {"WeiYixing9", 100.0f},
                {"WeiYixing10", 100.0f},
                {"WeiYixing11", 100.0f},
                {"WeiYixing1+", 10.0f},
                {"WeiYixing2+", 100.0f},
                {"WeiYixing3+", 100.0f},
                {"WeiYixing4+", 100.0f},
                {"WeiYixing5+", 100.0f},
                {"WeiYixing6+", 100.0f},
                {"WeiYixing7+", 100.0f},
                {"WeiYixing8+", 100.0f},
                {"WeiYixing9+", 100.0f},
                {"WeiYixing10+", 100.0f},
                {"WeiYixing11+", 100.0f},
            };

            // 应用闱异星特质对序列值的影响
            foreach (var weiYixing in weiYixingXuLieChanges)
            {
                if (__instance.hasTrait(weiYixing.Key))
                {
                    float weiYixingBonus = weiYixing.Value;
                    __instance.ChangeXuLie(weiYixingBonus);
                }
            }

            // 特质增加序列值的处理
            var jinShengXuLieChanges = new Dictionary<string, (float, float)>
            {
                { "jinSheng1", (1.0f, 2.0f) },//魔药主材
                { "jinSheng2", (2.0f, 4.0f) },//完整魔药
                { "jinSheng3", (4.0f, 6.0f) },//消化法
                { "jinSheng4", (6.0f, 8.0f) },//扮演法
                { "jinSheng10", (-1.0f, -2.0f) },//灵性衰败
                { "jinSheng7", (8.0f, 12.0f) },//晋升仪式
                { "jinSheng8", (12.0f, 18.0f) },//旧日赐福
            };

            // 应用晋升特质对序列值的影响
            foreach (var change in jinShengXuLieChanges)
            {
                // 如果具有jinSheng10特质，并且当前特质是jinSheng1到jinSheng4，则跳过
                if ((hasjinSheng10 || hasjinSheng9) && (change.Key == "jinSheng1" || change.Key == "jinSheng2" || change.Key == "jinSheng3" || change.Key == "jinSheng4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    // 在指定范围内随机增加序列值
                    float randomXuLieIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeXuLie(randomXuLieIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var XuLieTraitThresholds = new Dictionary<string, float>
            {
                { "XuLie1", 40f },
                { "XuLie2", 50f },
                { "XuLie3", 50f },
                { "XuLie4", 65f },
                { "XuLie5", 70f },
                { "XuLie6", 100f },
                { "XuLie7", 150f },
                { "XuLie8", 220f },
                { "XuLie9", 400f },
                { "XuLie91", 600f },
                { "XuLie92", 1000f },
                { "XuLie93", 2000f }
            };
            
            // 灵性衰败特质的触发概率
            const float jinSheng10Chance = 0.1f;
            foreach (var threshold in XuLieTraitThresholds)
            {
                // 检查是否满足触发灵性衰败特质的条件
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(jinSheng10Chance) && !hasYizhiYoncun)
                {
                    __instance.addTrait("jinSheng10", false);
                }
            }

            // 定义各境界的最大序列值
            var grades = new Dictionary<string, float>
            {
                { "XuLie1", 10.01f }, // 修改为10.01f，确保Mathf.FloorToInt后能正确获取序列九的理智上限
                { "XuLie2", 20.01f },
                { "XuLie3", 40.01f },
                { "XuLie4", 80.01f },
                { "XuLie5", 160.01f },
                { "XuLie6", 300.01f },
                { "XuLie7", 500.01f },
                { "XuLie8", 800.01f },
                { "XuLie9", 1200.01f },
                { "XuLie91", 3600.01f },
                { "XuLie92", 10000.01f },
                { "XuLie93", 100000.01f },
                { "XuLie94", 999999.01f },
            };
            
            // 根据境界更新序列值上限
            foreach (var grade in grades)
            {
                UpdateXuLieBasedOnGrade(__instance, grade.Key, grade.Value);
            }
            
            // GuimiShenfen系列特质晋升逻辑
            // 1. 序列七时（拥有XuLie4特质），GuimiShenfen1~5晋升到+版本
            if (__instance.hasTrait("XuLie4")) // 序列七
            {
                // 晋升GuimiShenfen1到GuimiShenfen1+
                if (__instance.hasTrait("GuimiShenfen1") && !__instance.hasTrait("GuimiShenfen1+"))
                {
                    __instance.removeTrait("GuimiShenfen1");
                    __instance.addTrait("GuimiShenfen1+", false);
                }
                // 晋升GuimiShenfen2到GuimiShenfen2+
                if (__instance.hasTrait("GuimiShenfen2") && !__instance.hasTrait("GuimiShenfen2+"))
                {
                    __instance.removeTrait("GuimiShenfen2");
                    __instance.addTrait("GuimiShenfen2+", false);
                }
                // 晋升GuimiShenfen3到GuimiShenfen3+
                if (__instance.hasTrait("GuimiShenfen3") && !__instance.hasTrait("GuimiShenfen3+"))
                {
                    __instance.removeTrait("GuimiShenfen3");
                    __instance.addTrait("GuimiShenfen3+", false);
                }
                // 晋升GuimiShenfen4到GuimiShenfen4+
                if (__instance.hasTrait("GuimiShenfen4") && !__instance.hasTrait("GuimiShenfen4+"))
                {
                    __instance.removeTrait("GuimiShenfen4");
                    __instance.addTrait("GuimiShenfen4+", false);
                }
                // 晋升GuimiShenfen5到GuimiShenfen5+
                if (__instance.hasTrait("GuimiShenfen5") && !__instance.hasTrait("GuimiShenfen5+"))
                {
                    __instance.removeTrait("GuimiShenfen5");
                    __instance.addTrait("GuimiShenfen5+", false);
                }
            }
            
            // 2. 半神之后（拥有XuLie7特质），GuimiShenfen1+~4+晋升为++版本，GuimiShenfen5+和6晋升为GuimiShenfen4++
            if (__instance.hasTrait("XuLie7")) // 半神
            {
                // 晋升GuimiShenfen1+到GuimiShenfen1++
                if (__instance.hasTrait("GuimiShenfen1+") && !__instance.hasTrait("GuimiShenfen1++"))
                {
                    __instance.removeTrait("GuimiShenfen1+");
                    __instance.addTrait("GuimiShenfen1++", false);
                }
                // 晋升GuimiShenfen2+到GuimiShenfen2++
                if (__instance.hasTrait("GuimiShenfen2+") && !__instance.hasTrait("GuimiShenfen2++"))
                {
                    __instance.removeTrait("GuimiShenfen2+");
                    __instance.addTrait("GuimiShenfen2++", false);
                }
                // 晋升GuimiShenfen3+到GuimiShenfen3++
                if (__instance.hasTrait("GuimiShenfen3+") && !__instance.hasTrait("GuimiShenfen3++"))
                {
                    __instance.removeTrait("GuimiShenfen3+");
                    __instance.addTrait("GuimiShenfen3++", false);
                }
                // 晋升GuimiShenfen4+到GuimiShenfen4++
                if (__instance.hasTrait("GuimiShenfen4+") && !__instance.hasTrait("GuimiShenfen4++"))
                {
                    __instance.removeTrait("GuimiShenfen4+");
                    __instance.addTrait("GuimiShenfen4++", false);
                }
                // 晋升GuimiShenfen5+到GuimiShenfen4++
                if (__instance.hasTrait("GuimiShenfen5+") && !__instance.hasTrait("GuimiShenfen4++"))
                {
                    __instance.removeTrait("GuimiShenfen5+");
                    __instance.addTrait("GuimiShenfen4++", false);
                }
                // 晋升GuimiShenfen6到GuimiShenfen4++
                if (__instance.hasTrait("GuimiShenfen6") && !__instance.hasTrait("GuimiShenfen4++"))
                {
                    __instance.removeTrait("GuimiShenfen6");
                    __instance.addTrait("GuimiShenfen4++", false);
                }
            }
            
            // 检查并处理天使之王灵性达到10000的情况
            CheckAndHandleArchangelXuLieReach10000(__instance);
        }
        
        // 根据境界更新序列值上限的方法
        private static void UpdateXuLieBasedOnGrade(Actor actor, string traitName, float maxXuLie)
        {
            if (actor.hasTrait(traitName))
            {
                float currentXuLie = actor.GetXuLie();
                // 设置序列值为当前值和最大值中的较小值
                float newValue = Mathf.Min(maxXuLie, currentXuLie);
                actor.SetXuLie(newValue);
            }
        }
        
        // 定义包含晋升和天赋特质的数组
        private static readonly string[] FlairjinShengTraits = new[] { "jinSheng1", "jinSheng2", "jinSheng3", "jinSheng4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7", "martialAptitude1", "martialAptitude2", "martialAptitude3", "martialAptitude4", "martialAptitude7", "martialAptitude8" };
        
        // 检查是否具有任何晋升或天赋特质的方法
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairjinShengTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
        
        // 检查并处理同途径天使之王灵性达到10000的情况
        private static void CheckAndHandleArchangelXuLieReach10000(Actor actor)
        {
            // 检查是否是天使之王且灵性达到10000
            if (actor.hasTrait("XuLie92") && actor.GetXuLie() >= 10000)
            {
                // 获取角色途径
                string pathway = GetActorPathway(actor);
                if (!string.IsNullOrEmpty(pathway))
                {
                    // 检查相同途径的其他天使之王和序列一角色
                    foreach (Actor otherActor in World.world.units.getSimpleList())
                    {
                        // 跳过自己和已死亡的角色
                        if (otherActor == actor || !otherActor.isAlive())
                            continue;
                        
                        // 检查是否是天使之王
                        if (otherActor.hasTrait("XuLie92"))
                        {
                            // 检查是否是相同途径
                            string otherPathway = GetActorPathway(otherActor);
                            if (otherPathway == pathway)
                            {
                                // 让另一个天使之王直接死亡
                                otherActor.die();
                            }
                        }
                        // 检查是否是序列一角色
                        else if (otherActor.hasTrait("XuLie91"))
                        {
                            // 检查是否是相同途径
                            string otherPathway = GetActorPathway(otherActor);
                            if (otherPathway == pathway)
                            {
                                // 让同途径的序列一角色直接死亡
                                otherActor.die();
                            }
                        }
                    }
                }
            }
        }
        
        // 获取角色的途径
        private static string GetActorPathway(Actor actor)
        {
            // 直接检查角色的TeXing特质来确定途径
            if (actor.hasTrait("TeXing1")) return "占卜家";
            if (actor.hasTrait("TeXing2")) return "学徒";
            if (actor.hasTrait("TeXing3")) return "偷盗者";
            if (actor.hasTrait("TeXing4")) return "歌颂者";
            if (actor.hasTrait("TeXing5")) return "观众";
            if (actor.hasTrait("TeXing6")) return "阅读者";
            if (actor.hasTrait("TeXing7")) return "水手";
            if (actor.hasTrait("TeXing8")) return "秘祈人";
            if (actor.hasTrait("TeXing9")) return "药师";
            if (actor.hasTrait("TeXing10")) return "不眠者";
            if (actor.hasTrait("TeXing11")) return "战士";
            if (actor.hasTrait("TeXing1+")) return "猎人";
            if (actor.hasTrait("TeXing2+")) return "刺客";
            if (actor.hasTrait("TeXing3+")) return "耕种者";
            if (actor.hasTrait("TeXing4+")) return "收尸人";
            if (actor.hasTrait("TeXing5+")) return "律师";
            if (actor.hasTrait("TeXing6+")) return "仲裁人";
            if (actor.hasTrait("TeXing7+")) return "罪犯";
            if (actor.hasTrait("TeXing8+")) return "囚犯";
            if (actor.hasTrait("TeXing9+")) return "窥秘人";
            if (actor.hasTrait("TeXing10+")) return "通识者";
            if (actor.hasTrait("TeXing11+")) return "怪物";
            
            return null;
        }
    }
}