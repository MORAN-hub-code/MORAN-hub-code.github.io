# Credits 
 Vack - 😉
 Moose - artist
 Trike - artist
 Politano - artist
 keymasterer - helped with some stuff
 stormfire - concept art
 zeyl - supporter/motivation
 alex - supporter/motivation
 core.skull - art
 pioughd - supporter/motivation





                                           Lead dev/coder - ahoyos
 