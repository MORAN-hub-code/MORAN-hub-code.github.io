using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

namespace Isekai
{
    public class GIFPlayer : MonoBehaviour
    {
        private List<Sprite> frames = new List<Sprite>();
        private UnityEngine.UI.Image imageComponent;
        private float frameDelay = 0.1f;
        private int currentFrame = 0;
        private float timer = 0f;
        private bool isPlaying = false;

        public void LoadGIF(string path)
        {
            if (!File.Exists(path))
            {
                Debug.LogError($"[Isekai Mod] GIF file {path} not found.");
                return;
            }

            try
            {
                using (System.Drawing.Image gifImage = System.Drawing.Image.FromFile(path))
                {
                    FrameDimension dimension = new FrameDimension(gifImage.FrameDimensionsList[0]);
                    int frameCount = gifImage.GetFrameCount(dimension);
                    PropertyItem frameDelayItem = gifImage.GetPropertyItem(0x5100);
                    byte[] delays = frameDelayItem.Value;

                    frames.Clear();
                    for (int i = 0; i < frameCount; i++)
                    {
                        gifImage.SelectActiveFrame(dimension, i);
                        using (Bitmap bitmap = new Bitmap(gifImage))
                        {
                            Texture2D texture = new Texture2D(bitmap.Width, bitmap.Height);
                            for (int x = 0; x < bitmap.Width; x++)
                            {
                                for (int y = 0; y < bitmap.Height; y++)
                                {
                                    System.Drawing.Color pixel = bitmap.GetPixel(x, y);
                                    texture.SetPixel(x, bitmap.Height - y - 1, new UnityEngine.Color32(pixel.R, pixel.G, pixel.B, pixel.A));
                                }
                            }
                            texture.Apply();
                            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));
                            frames.Add(sprite);
                        }
                        int delay = (int)(BitConverter.ToInt32(delays, i * 4) * 0.01f);
                        frameDelay = delay > 0 ? delay : 0.1f;
                    }
                }
                imageComponent = gameObject.GetComponent<UnityEngine.UI.Image>();
                if (imageComponent == null)
                {
                    imageComponent = gameObject.AddComponent<UnityEngine.UI.Image>();
                }
                if (frames.Count > 0)
                {
                    imageComponent.sprite = frames[0];
                    isPlaying = true;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[Isekai Mod] Failed to load GIF {path}: {e.Message}");
                imageComponent = gameObject.GetComponent<UnityEngine.UI.Image>();
                if (imageComponent == null)
                {
                    imageComponent = gameObject.AddComponent<UnityEngine.UI.Image>();
                }
                imageComponent.color = new UnityEngine.Color(0.1f, 0.1f, 0.1f, 1f);
            }
        }

        void Update()
        {
            if (!isPlaying || frames.Count <= 1) return;

            timer += Time.deltaTime;
            if (timer >= frameDelay)
            {
                currentFrame = (currentFrame + 1) % frames.Count;
                imageComponent.sprite = frames[currentFrame];
                timer = 0f;
            }
        }
    }
}