using NCMS.Utils;
using ReflectionUtility;
using UnityEngine;

namespace Isekai
{
    class Units
    {
        public static void init()
        {
            try
            {
                KingdomAsset IsekaiKingdom = new KingdomAsset();
                IsekaiKingdom.id = "IsekaiKingdom";
                IsekaiKingdom.mobs = true;
                IsekaiKingdom.default_kingdom_color = new ColorAsset("#555555");
                IsekaiKingdom.addTag("IsekaiKingdom");
                IsekaiKingdom.addFriendlyTag("IsekaiKingdom");
                AssetManager.kingdoms.add(IsekaiKingdom);
                World.world.kingdoms_wild.newWildKingdom(IsekaiKingdom);
                loadAssets();
            }
            catch (System.Exception e)
            {
                Debug.LogError("Failed to initialize Isekai kingdom or assets: " + e.Message);
            }
        }

        public static void loadAssets()
        {
            try
            {
                var trolls = AssetManager.actor_library.clone("trolls", "$mob$");
                trolls.name_locale = "trolls";
                trolls.use_phenotypes = false;
                trolls.unit_other = true;
                trolls.has_advanced_textures = false;
                trolls.check_flip = delegate { return true; };
                trolls.name_template_sets = new string[] { "alien_set" };
                trolls.job = new string[] { "random_move" };
                trolls.kingdom_id_wild = "IsekaiKingdom";
                trolls.animation_walk = new string[] { "walk_0" };
                trolls.texture_asset = new ActorTextureSubAsset("actors/trolls/", trolls.has_advanced_textures);
                trolls.run_to_water_when_on_fire = true;
                trolls.can_be_killed_by_stuff = true;
                trolls.can_be_killed_by_life_eraser = true;
                trolls.can_attack_buildings = true;
                trolls.can_be_moved_by_powers = true;
                trolls.can_be_hurt_by_powers = true;
                trolls.can_turn_into_zombie = false;
                trolls.can_be_inspected = true;
                trolls.visible_on_minimap = true;
                trolls.use_items = true;
                trolls.take_items = false;
                trolls.can_evolve_into_new_species = false;
                trolls.can_have_subspecies = false;
                trolls.can_talk_with = false;
                trolls.control_can_talk = false;
                trolls.inspect_home = false;
                trolls.disable_jump_animation = true;
                trolls.has_soul = true;
                trolls.force_ocean_creature = true;
                trolls.force_land_creature = true;
                trolls.can_turn_into_demon_in_age_of_chaos = false;
                trolls.can_turn_into_ice_one = false;
                trolls.can_turn_into_tumor = false;
                trolls.can_turn_into_mush = false;
                trolls.die_in_lava = false;
                trolls.die_on_blocks = true;
                trolls.die_by_lightning = true;
                trolls.damaged_by_ocean = false;
                trolls.flying = false;
                  // ahoyos was here💋
                trolls.very_high_flyer = false;
                trolls.hide_favorite_icon = false;
                trolls.can_edit_traits = true;
                trolls.can_be_killed_by_divine_light = true;
                trolls._cached_sprite = Resources.Load<Sprite>("GameResources/actors/trolls/walk_0");
                trolls.ignored_by_infinity_coin = false;
                trolls.actor_size = ActorSize.S13_Human;
                trolls.base_stats["lifespan"] = 10000f;
                trolls.base_stats["health"] = 200f;
                trolls.base_stats["mana"] = 200f;
                trolls.base_stats["stamina"] = 532f;
                trolls.base_stats["damage"] = 35f;
                trolls.base_stats["speed"] = 75f;
                trolls.base_stats["attack_speed"] = 55f;
                trolls.base_stats["mass"] = 10f;
                trolls.base_stats["critical_chance"] = 0.25f;
                trolls.base_stats["knockback"] = 0.1f;
                trolls.base_stats["accuracy"] = 8f;
                trolls.base_stats["range"] = 1f;
                trolls.base_stats["targets"] = 1f;
                AssetManager.actor_library.loadShadow(trolls);
                AssetManager.actor_library.loadTexturesAndSprites(trolls);
                trolls.addTrait("immortal");
                trolls.addTrait("trolls");
                trolls.addResource("troll_blood", 1, true);
                trolls.addResource("stone_club", 1, true);
                Localization.Add(trolls.name_locale, trolls.name_locale);

                var griffins = AssetManager.actor_library.clone("griffins", "$mob$");
                griffins.name_locale = "griffins";
                griffins.use_phenotypes = false;
                griffins.unit_other = true;
                griffins.has_advanced_textures = false;
                griffins.check_flip = delegate { return true; };
                griffins.name_template_sets = new string[] { "alien_set" };
                griffins.job = new string[] { "random_move" };
                griffins.kingdom_id_wild = "IsekaiKingdom";
                griffins.animation_walk = new string[] { "walk_0" };
                griffins.texture_asset = new ActorTextureSubAsset("actors/griffins/", griffins.has_advanced_textures);
                griffins.run_to_water_when_on_fire = true;
                griffins.can_be_killed_by_stuff = true;
                griffins.can_be_killed_by_life_eraser = true;
                griffins.can_attack_buildings = true;
                griffins.can_be_moved_by_powers = true;
                griffins.can_be_hurt_by_powers = true;
                griffins.can_turn_into_zombie = false;
                griffins.can_be_inspected = true;
                griffins.visible_on_minimap = true;
                griffins.use_items = true;
                griffins.take_items = false;
                griffins.can_evolve_into_new_species = false;
                griffins.can_have_subspecies = false;
                griffins.can_talk_with = false;
                griffins.control_can_talk = false;
                griffins.inspect_home = false;
                griffins.disable_jump_animation = true;
                griffins.has_soul = true;
                griffins.force_ocean_creature = true;
                griffins.force_land_creature = true;
                griffins.can_turn_into_demon_in_age_of_chaos = false;
                griffins.can_turn_into_ice_one = false;
                griffins.can_turn_into_tumor = false;
                griffins.can_turn_into_mush = false;
                griffins.die_in_lava = false;
                griffins.die_on_blocks = true;
                griffins.die_by_lightning = true;
                griffins.damaged_by_ocean = false;
                griffins.flying = true;
                griffins.very_high_flyer = false;
                griffins.hide_favorite_icon = false;
                griffins.can_edit_traits = true;
                griffins.can_be_killed_by_divine_light = true;
                griffins._cached_sprite = Resources.Load<Sprite>("GameResources/actors/griffins/walk_0");
                griffins.ignored_by_infinity_coin = false;
                griffins.actor_size = ActorSize.S13_Human;
                griffins.base_stats["lifespan"] = 10000f;
                griffins.base_stats["health"] = 200f;
                griffins.base_stats["mana"] = 1000f;
                griffins.base_stats["damage"] = 35f;
                griffins.base_stats["speed"] = 75f;
                griffins.base_stats["attack_speed"] = 55f;
                griffins.base_stats["stamina"] = 55f;
                griffins.base_stats["mass"] = 10f;
                griffins.base_stats["critical_chance"] = 0.25f;
                griffins.base_stats["knockback"] = 0.1f;
                griffins.base_stats["accuracy"] = 8f;
                griffins.base_stats["range"] = 1f;
                griffins.base_stats["targets"] = 1f;
                AssetManager.actor_library.loadShadow(griffins);
                AssetManager.actor_library.loadTexturesAndSprites(griffins);
                griffins.addTrait("immortal");
                griffins.addTrait("griffins");
                griffins.addResource("griffin_feather", 2, true);
                griffins.addResource("beak", 1, true);
                Localization.Add(griffins.name_locale, griffins.name_locale);

                var darkknight = AssetManager.actor_library.clone("darkknight", "$mob$");
                darkknight.name_locale = "darkknight";
                darkknight.use_phenotypes = false;
                darkknight.unit_other = true;
                darkknight.has_advanced_textures = false;
                darkknight.check_flip = delegate { return true; };
                darkknight.name_template_sets = new string[] { "alien_set" };
                darkknight.job = new string[] { "random_move" };
                darkknight.kingdom_id_wild = "IsekaiKingdom";
                darkknight.animation_walk = new string[] { "walk_0" };
                darkknight.texture_asset = new ActorTextureSubAsset("actors/darkknight/", darkknight.has_advanced_textures);
                darkknight.run_to_water_when_on_fire = true;
                darkknight.can_be_killed_by_stuff = true;
                darkknight.can_be_killed_by_life_eraser = true;
                darkknight.can_attack_buildings = true;
                darkknight.can_be_moved_by_powers = true;
                darkknight.can_be_hurt_by_powers = true;
                darkknight.can_turn_into_zombie = false;
                darkknight.can_be_inspected = true;
                darkknight.visible_on_minimap = true;
                darkknight.use_items = true;
                darkknight.take_items = true;
                darkknight.can_evolve_into_new_species = true;
                darkknight.can_have_subspecies = true;
                darkknight.can_talk_with = false;
                darkknight.control_can_talk = false;
                darkknight.inspect_home = false;
                darkknight.disable_jump_animation = true;
                darkknight.has_soul = true;
                darkknight.force_ocean_creature = true;
                darkknight.force_land_creature = true;
                darkknight.can_turn_into_demon_in_age_of_chaos = false;
                darkknight.can_turn_into_ice_one = false;
                darkknight.can_turn_into_tumor = false;
                darkknight.can_turn_into_mush = false;
                darkknight.die_in_lava = false;
                darkknight.die_on_blocks = true;
                darkknight.die_by_lightning = true;
                darkknight.damaged_by_ocean = false;
                darkknight.flying = false;
                darkknight.very_high_flyer = false;
                darkknight.hide_favorite_icon = false;
                darkknight.can_edit_traits = true;
                darkknight.can_be_killed_by_divine_light = true;
                darkknight._cached_sprite = Resources.Load<Sprite>("GameResources/actors/darkknight/walk_0");
                darkknight.ignored_by_infinity_coin = false;
                darkknight.actor_size = ActorSize.S13_Human;
                darkknight.base_stats["lifespan"] = 10000f;
                darkknight.base_stats["health"] = 200f;
                darkknight.base_stats["mana"] = 1030f;
                darkknight.base_stats["damage"] = 35f;
                darkknight.base_stats["speed"] = 75f;
                darkknight.base_stats["attack_speed"] = 55f;
                darkknight.base_stats["stamina"] = 100f;
                darkknight.base_stats["mass"] = 10f;
                darkknight.base_stats["critical_chance"] = 0.25f;
                darkknight.base_stats["knockback"] = 0.1f;
                darkknight.base_stats["accuracy"] = 8f;
                darkknight.base_stats["range"] = 1f;
                darkknight.base_stats["targets"] = 1f;
                AssetManager.actor_library.loadShadow(darkknight);
                AssetManager.actor_library.loadTexturesAndSprites(darkknight);
                darkknight.addTrait("immortal");
                darkknight.addTrait("darkknight");
                darkknight.addResource("dark_sword", 1, true);
                darkknight.addResource("dark_shield", 1, true);
                Localization.Add(darkknight.name_locale, darkknight.name_locale);
            }
            catch (System.Exception e)
            {
                Debug.LogError("Failed to load assets: " + e.Message);
            }
        }
    }
}