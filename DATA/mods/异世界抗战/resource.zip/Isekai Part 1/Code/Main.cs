using System;
using NCMS;
using UnityEngine;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine.UI;
using HarmonyLib;
using System.Reflection;

namespace Isekai
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        public static Main instance;
        public static string mainPath;
        private static bool initialized = false;

        void Awake()
        {
            if (initialized)
            {
                Debug.LogWarning("[Isekai Mod] Main.Awake() already called, skipping initialization.");
                return;
            }

            instance = this;
            mainPath = Application.dataPath;
            GameObject go = new GameObject("Isekai");
            DontDestroyOnLoad(go);
            WindowManager.init();
            IsekaiTraits.Initialize();
            Units.init();
            Units2.init();
            Units3.init();
            Units4.init();
            PatchWorldLawCursed.init();
            IsekaiAges.Init();
            IsekaiButtons.Init();
            FantasyBoxTab.Init();
            ModsBoxUI.Init();
            InvokeRepeating("level", 2.0f, 0.7f);
            ChangeLoadingScreen();

            var harmony = new Harmony("com.isekai.mod");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
            Debug.Log("[Isekai Mod] Harmony patching applied.");

            initialized = true;
            Debug.Log("[Isekai Mod] Main.Awake() completed successfully.");
        }

        void Start()
        {
            StartCoroutine(DelayedInit());
        }

        private IEnumerator DelayedInit()
        {
            yield return new WaitForSeconds(4f);
            if (!WindowManager.windows.ContainsKey("FuseWindow") || WindowManager.windows["FuseWindow"] == null)
            {
                WindowManager.init();
                Debug.Log("[Isekai Mod] WindowManager reinitialized in DelayedInit.");
            }
            yield return new WaitUntil(() =>
                WindowManager.windows.ContainsKey("FuseWindow") &&
                WindowManager.windows["FuseWindow"] != null &&
                WindowManager.windows["FuseWindow"].gameObject != null &&
                AssetManager.status != null &&
                LocalizedTextManager.instance != null &&
                LocalizedTextManager.instance._localized_text != null
            );
            Debug.Log("[Isekai Mod] DelayedInit completed.");
        }

        void level()
        {
            CreatureCheck();
        }

        void CreatureCheck()
        {
            var units = World.world.units;
            foreach (var unit in units)
            {
                if (unit != null && unit.hasTrait("T_T"))
                {
                    unit.addExperience(10);
                }
            }
        }

        public static void ChangeLoadingScreen()
        {
            string path = Path.Combine(Application.dataPath.Replace("worldbox_Data", "Mods/Isekai Part 1"), "GameResources/ui/LoadingScreen");
            string imageName = "loadingUwU.png";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            string imagePath = Path.Combine(path, imageName);
            if (!File.Exists(imagePath))
            {
                Debug.LogError($"[Isekai Mod] Loading screen image {imageName} not found at {imagePath}!");
                return;
            }

            LoadingScreen transitionScreen = World.world.transition_screen;
            transitionScreen.enabled = false;
            Image backgroundImage = transitionScreen.background;
            backgroundImage.type = Image.Type.Simple;
            RectTransform backgroundRect = backgroundImage.GetComponent<RectTransform>();
            backgroundRect.anchoredPosition = new Vector2(0, 0);

            Sprite sprite = Toolbox.LoadSprite(imagePath);
            backgroundImage.sprite = sprite;

            Canvas canvas = transitionScreen.canvas;
            float scaleX = 1290f / sprite.texture.width;
            float scaleY = 980f / sprite.texture.height;
            backgroundRect.localScale = new Vector3(scaleX, scaleY, 1f);

            transitionScreen.enabled = true;
            Debug.Log("[Isekai Mod] Loading screen changed successfully.");
        }

        public static class PatchWorldLawCursed
        {
            public static void init()
            {
                var cursedworld = AssetManager.world_laws_library.get("world_law_cursed_world");
                cursedworld.default_state = true;
                Debug.Log("[Isekai Mod] PatchWorldLawCursed initialized.");
            }
        }
    }
}