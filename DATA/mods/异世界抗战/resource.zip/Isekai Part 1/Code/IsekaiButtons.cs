using System;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ReflectionUtility;
using NeoModLoader.General.UI.Tab;

namespace Isekai
{
    public static class IsekaiButtons
    {
        private static PowersTab tab;

        public static void Init()
        {
            Sprite tabIcon = SpriteTextureLoader.getSprite("ui/Icons/tabIconIsekai");
            if (tabIcon == null)
            {
                return;
            }

            Localization.AddOrSet("Button_Tab_Isekai", "Isekai");
            Localization.AddOrSet("Button_Tab_Isekai Description", "Access Isekai stuff UwU :3");
            Localization.AddOrSet("ahoyosisekai_mod_creator", "ahoyos");

            tab = TabManager.CreateTab(
                "Isekai",
                "Button_Tab_Isekai",
                "Button_Tab_Isekai Description",
                tabIcon,
                "ahoyosisekai_mod_creator"
            );

            if (tab == null)
            {
                return;
            }

            LoadButtons();
            AddLogo();
            AddSectionLabel();
        }

        private static void AddLogo()
        {
            Sprite logoSprite = SpriteTextureLoader.getSprite("ui/Icons/iconIsekaiLogo");
            if (logoSprite == null)
            {
                return;
            }

            GameObject logoObject = new GameObject("IsekaiLogo");
            logoObject.transform.SetParent(tab.transform, false);
            Image logoImage = logoObject.AddComponent<Image>();
            logoImage.sprite = logoSprite;
            logoImage.rectTransform.sizeDelta = new Vector2(83f, 88f);
            logoImage.rectTransform.anchoredPosition = new Vector2(760f, 0f);

            logoObject.AddComponent<LogoSpinner>();

            EventTrigger trigger = logoObject.AddComponent<EventTrigger>();
            EventTrigger.Entry pointerEnter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
            pointerEnter.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = true; });
            trigger.triggers.Add(pointerEnter);

            EventTrigger.Entry pointerExit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            pointerExit.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = false; });
            trigger.triggers.Add(pointerExit);
        }

        private static void AddSectionLabel()
        {
            GameObject labelObject = new GameObject("CoreRacesLabel");
            labelObject.transform.SetParent(tab.transform, false);
            Text labelText = labelObject.AddComponent<Text>();
            labelText.text = "Hail ahoyos....";
            labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            labelText.fontSize = 16;
            labelText.color = Color.white;
            labelText.alignment = TextAnchor.MiddleLeft;
            labelText.rectTransform.sizeDelta = new Vector2(100f, 20f);
            labelText.rectTransform.anchoredPosition = new Vector2(72f, 54f);
        }

        private static void LoadButtons()
        {
            if (tab == null)
            {
                return;
            }

            Localization.AddOrSet("OpenDiscord", "Discord");
            Localization.AddOrSet("OpenDiscord_description", "Join the Isekai mod Discord server");

            var trollSpawn = new GodPower();
            trollSpawn.id = "spawntroll";
            trollSpawn.show_spawn_effect = true;
            trollSpawn.multiple_spawn_tip = true;
            trollSpawn.actor_spawn_height = 3f;
            trollSpawn.name = "spawntroll";
            trollSpawn.sound_event = "spawn";
            trollSpawn.actor_asset_id = "trolls";
            trollSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(trollSpawn);
            Localization.AddOrSet("spawntroll", "Troll");
            Localization.AddOrSet("spawntroll_description", "Spawn Trolls");

            var griffinSpawn = new GodPower();
            griffinSpawn.id = "spawngriffin";
            griffinSpawn.show_spawn_effect = true;
            griffinSpawn.multiple_spawn_tip = true;
            griffinSpawn.actor_spawn_height = 3f;
            griffinSpawn.name = "spawngriffin";
            griffinSpawn.sound_event = "spawn";
            griffinSpawn.actor_asset_id = "griffins";
            griffinSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(griffinSpawn);
            Localization.AddOrSet("spawngriffin", "Griffin");
            Localization.AddOrSet("spawngriffin_description", "Spawn Griffins");

            var darkKnightSpawn = new GodPower();
            darkKnightSpawn.id = "spawndarkknight";
            darkKnightSpawn.show_spawn_effect = true;
            darkKnightSpawn.multiple_spawn_tip = true;
            darkKnightSpawn.actor_spawn_height = 3f;
            darkKnightSpawn.name = "spawndarkknight";
            darkKnightSpawn.sound_event = "spawn";
            darkKnightSpawn.actor_asset_id = "darkknight";
            darkKnightSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(darkKnightSpawn);
            Localization.AddOrSet("spawndarkknight", "Dark Knight");
            Localization.AddOrSet("spawndarkknight_description", "Spawn Dark Knights");

            var phoenixSpawn = new GodPower();
            phoenixSpawn.id = "spawnphoenix";
            phoenixSpawn.show_spawn_effect = true;
            phoenixSpawn.multiple_spawn_tip = true;
            phoenixSpawn.actor_spawn_height = 3f;
            phoenixSpawn.name = "spawnphoenix";
            phoenixSpawn.sound_event = "spawn";
            phoenixSpawn.actor_asset_id = "phoenix";
            phoenixSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(phoenixSpawn);
            Localization.AddOrSet("spawnphoenix", "Phoenix");
            Localization.AddOrSet("spawnphoenix_description", "Spawn Phoenixes");

            var witchSpawn = new GodPower();
            witchSpawn.id = "spawnwitch";
            witchSpawn.show_spawn_effect = true;
            witchSpawn.multiple_spawn_tip = true;
            witchSpawn.actor_spawn_height = 3f;
            witchSpawn.name = "spawnwitch";
            witchSpawn.sound_event = "spawn";
            witchSpawn.actor_asset_id = "witch";
            witchSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(witchSpawn);
            Localization.AddOrSet("spawnwitch", "Witch");
            Localization.AddOrSet("spawnwitch_description", "Spawn Witches");

            var demonKingSpawn = new GodPower();
            demonKingSpawn.id = "spawndemonking";
            demonKingSpawn.show_spawn_effect = true;
            demonKingSpawn.multiple_spawn_tip = true;
            demonKingSpawn.actor_spawn_height = 3f;
            demonKingSpawn.name = "spawndemonking";
            demonKingSpawn.sound_event = "spawn";
            demonKingSpawn.actor_asset_id = "demonking";
            demonKingSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(demonKingSpawn);
            Localization.AddOrSet("spawndemonking", "Demon King");
            Localization.AddOrSet("spawndemonking_description", "Spawn Demon Kings");

            var japanSoldierSpawn = new GodPower();
            japanSoldierSpawn.id = "spawnjapan";
            japanSoldierSpawn.show_spawn_effect = true;
            japanSoldierSpawn.multiple_spawn_tip = true;
            japanSoldierSpawn.actor_spawn_height = 3f;
            japanSoldierSpawn.name = "spawnjapan";
            japanSoldierSpawn.sound_event = "spawn";
            japanSoldierSpawn.actor_asset_id = "japansoldier";
            japanSoldierSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(japanSoldierSpawn);
            Localization.AddOrSet("spawnjapan", "Japanese Soldier");
            Localization.AddOrSet("spawnjapan_description", "Spawn Japanese Soldiers");

            var japanTankSpawn = new GodPower();
            japanTankSpawn.id = "spawnjapan2";
            japanTankSpawn.show_spawn_effect = true;
            japanTankSpawn.multiple_spawn_tip = true;
            japanTankSpawn.actor_spawn_height = 3f;
            japanTankSpawn.name = "spawnjapan2";
            japanTankSpawn.sound_event = "spawn";
            japanTankSpawn.actor_asset_id = "japantank";
            japanTankSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(japanTankSpawn);
            Localization.AddOrSet("spawnjapan2", "Japanese Tank");
            Localization.AddOrSet("spawnjapan2_description", "Spawn Japanese Tanks");

            var japanHelicopterSpawn = new GodPower();
            japanHelicopterSpawn.id = "spawnjapan3";
            japanHelicopterSpawn.show_spawn_effect = true;
            japanHelicopterSpawn.multiple_spawn_tip = true;
            japanHelicopterSpawn.actor_spawn_height = 3f;
            japanHelicopterSpawn.name = "spawnjapan3";
            japanHelicopterSpawn.sound_event = "spawn";
            japanHelicopterSpawn.actor_asset_id = "japanhelicopter";
            japanHelicopterSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(japanHelicopterSpawn);
            Localization.AddOrSet("spawnjapan3", "Japanese Helicopter");
            Localization.AddOrSet("spawnjapan3_description", "Spawn Japanese Helicopters");

            var gateSpawn = new GodPower();
            gateSpawn.id = "spawnGate";
            gateSpawn.show_spawn_effect = true;
            gateSpawn.multiple_spawn_tip = true;
            gateSpawn.actor_spawn_height = 3f;
            gateSpawn.name = "spawnGate";
            gateSpawn.sound_event = "spawn";
            gateSpawn.actor_asset_id = "unit_japaneses";
            gateSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(gateSpawn);
            Localization.AddOrSet("spawnGate", "Gate");
            Localization.AddOrSet("spawnGate_description", "Spawn a Gate to Japan");

            var kronosSpawn = new GodPower();
            kronosSpawn.id = "spawnKronos";
            kronosSpawn.show_spawn_effect = true;
            kronosSpawn.multiple_spawn_tip = true;
            kronosSpawn.actor_spawn_height = 3f;
            kronosSpawn.name = "spawnKronos";
            kronosSpawn.sound_event = "spawndragon";
            kronosSpawn.actor_asset_id = "kronos";
            kronosSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(kronosSpawn);
            Localization.AddOrSet("spawn_kronos", "Kronos");
            Localization.AddOrSet("spawn_kronos_description", "Spawn Kronos");

            var dragonSlayerSpawn = new GodPower();
            dragonSlayerSpawn.id = "spawnDragonSlayer";
            dragonSlayerSpawn.show_spawn_effect = true;
            dragonSlayerSpawn.multiple_spawn_tip = true;
            dragonSlayerSpawn.actor_spawn_height = 3f;
            dragonSlayerSpawn.name = "spawnDragonSlayer";
            dragonSlayerSpawn.sound_event = "spawndragon";
            dragonSlayerSpawn.actor_asset_id = "DragonSlayer";
            dragonSlayerSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(dragonSlayerSpawn);
            Localization.AddOrSet("spawn_dragon_slayer", "Dragon Slayer");
            Localization.AddOrSet("spawn_dragon_slayer_description", "Spawn Dragon Slayers");

            var hadesSpawn = new GodPower();
            hadesSpawn.id = "spawnhades";
            hadesSpawn.show_spawn_effect = true;
            hadesSpawn.multiple_spawn_tip = true;
            hadesSpawn.actor_spawn_height = 3f;
            hadesSpawn.name = "spawnhades";
            hadesSpawn.sound_event = "spawndragon";
            hadesSpawn.actor_asset_id = "hades";
            hadesSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hadesSpawn);
            Localization.AddOrSet("spawnhades", "Hades");
            Localization.AddOrSet("spawnhades_description", "Spawn Hades");

            var iceTitanSpawn = new GodPower();
            iceTitanSpawn.id = "spawnIceTitan";
            iceTitanSpawn.show_spawn_effect = true;
            iceTitanSpawn.multiple_spawn_tip = true;
            iceTitanSpawn.actor_spawn_height = 3f;
            iceTitanSpawn.name = "spawnIceTitan";
            iceTitanSpawn.sound_event = "spawndragon";
            iceTitanSpawn.actor_asset_id = "IceTitan";
            iceTitanSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(iceTitanSpawn);
            Localization.AddOrSet("spawn_ice_titan", "Ice Titan");
            Localization.AddOrSet("spawn_ice_titan_description", "Spawn Ice Titans");

            var fireTitanSpawn = new GodPower();
            fireTitanSpawn.id = "spawnFireTitan";
            fireTitanSpawn.show_spawn_effect = true;
            fireTitanSpawn.multiple_spawn_tip = true;
            fireTitanSpawn.actor_spawn_height = 3f;
            fireTitanSpawn.name = "spawnFireTitan";
            fireTitanSpawn.sound_event = "spawndragon";
            fireTitanSpawn.actor_asset_id = "FireTitan";
            fireTitanSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(fireTitanSpawn);
            Localization.AddOrSet("spawn_fire_titan", "Fire Titan");
            Localization.AddOrSet("spawn_fire_titan_description", "Spawn Fire Titans");

            Sprite trollSprite = SpriteTextureLoader.getSprite("ui/Icons/iconTrolls");
            PowerButtons.CreateButton(
                "spawntroll",
                trollSprite,
                "Troll",
                "A Mythological Being",
                new Vector2(254f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite griffinSprite = SpriteTextureLoader.getSprite("ui/Icons/iconGriffins");
            PowerButtons.CreateButton(
                "spawngriffin",
                griffinSprite,
                "Griffin",
                "A Mighty Mythological Creature",
                new Vector2(254f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite darkKnightSprite = SpriteTextureLoader.getSprite("ui/Icons/iconDarkKnight");
            PowerButtons.CreateButton(
                "spawndarkknight",
                darkKnightSprite,
                "Dark Knight",
                "A Legendary Dark Knight",
                new Vector2(290f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite phoenixSprite = SpriteTextureLoader.getSprite("ui/Icons/iconPhoenix");
            PowerButtons.CreateButton(
                "spawnphoenix",
                phoenixSprite,
                "Phoenix",
                "A Mighty Phoenix",
                new Vector2(290f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite witchSprite = SpriteTextureLoader.getSprite("ui/Icons/iconWitch");
            PowerButtons.CreateButton(
                "spawnwitch",
                witchSprite,
                "Witch",
                "A Wicked Witch",
                new Vector2(326f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite demonKingSprite = SpriteTextureLoader.getSprite("ui/Icons/iconDemonKing");
            PowerButtons.CreateButton(
                "spawndemonking",
                demonKingSprite,
                "Demon King",
                "The Mighty Demon King",
                new Vector2(326f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite japanSoldierSprite = SpriteTextureLoader.getSprite("ui/Icons/iconJapanSoldier");
            PowerButtons.CreateButton(
                "spawnjapan",
                japanSoldierSprite,
                "Japanese Soldier",
                "Member of the Japan Self Defense Forces",
                new Vector2(362f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite japanTankSprite = SpriteTextureLoader.getSprite("ui/Icons/iconJapanTank");
            PowerButtons.CreateButton(
                "spawnjapan2",
                japanTankSprite,
                "Japanese Tank",
                "A Japan Self Defense Forces Tank",
                new Vector2(362f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite japanHelicopterSprite = SpriteTextureLoader.getSprite("ui/Icons/iconJapanHelicopter");
            PowerButtons.CreateButton(
                "spawnjapan3",
                japanHelicopterSprite,
                "Japanese Helicopter",
                "A Japan Self Defense Forces Helicopter",
                new Vector2(398f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite gateSprite = SpriteTextureLoader.getSprite("ui/Icons/iconGate");
            PowerButtons.CreateButton(
                "spawnGate",
                gateSprite,
                "Gate",
                "A Great Gate to Japan\n~Temporarily unavailable~",
                new Vector2(398f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite kronosSprite = SpriteTextureLoader.getSprite("ui/Icons/iconKronos");
            PowerButtons.CreateButton(
                "spawnKronos",
                kronosSprite,
                "Kronos",
                "The Kronos",
                new Vector2(434f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite dragonSlayerSprite = SpriteTextureLoader.getSprite("ui/Icons/iconDragonSlayer");
            PowerButtons.CreateButton(
                "spawnDragonSlayer",
                dragonSlayerSprite,
                "DragonSlayer",
                "DragonSlayer",
                new Vector2(434f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hadesSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHades");
            PowerButtons.CreateButton(
                "spawnhades",
                hadesSprite,
                "Hades",
                "The God of the Underworld",
                new Vector2(470f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite iceTitanSprite = SpriteTextureLoader.getSprite("ui/Icons/iconIceTitan");
            PowerButtons.CreateButton(
                "spawnIceTitan",
                iceTitanSprite,
                "Ice Titan",
                "A Mighty Ice Titan",
                new Vector2(470f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite fireTitanSprite = SpriteTextureLoader.getSprite("ui/Icons/iconFireTitan");
            PowerButtons.CreateButton(
                "spawnFireTitan",
                fireTitanSprite,
                "Fire Titan",
                "A Mighty Fire Titan",
                new Vector2(506f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite discordSprite = SpriteTextureLoader.getSprite("ui/Icons/iconDiscord");
            PowerButtons.CreateButton(
                "OpenDiscord",
                discordSprite,
                "Discord",
                "Join the Isekai mod Discord server PLEASEEEE",
                new Vector2(506f, -18f),
                ButtonType.Click,
                tab.transform,
                () => Application.OpenURL("https://discord.gg/Yq4jUzuExM")
            );
        }

        public static bool CallSpawnUnit(WorldTile pTile, string pPowerID)
        {
            AssetManager.powers.spawnUnit(pTile, pPowerID);
            return true;
        }
    }
}