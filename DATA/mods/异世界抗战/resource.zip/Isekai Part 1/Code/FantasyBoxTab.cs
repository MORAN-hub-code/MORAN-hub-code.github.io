using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using NeoModLoader.General.UI.Tab;

namespace Isekai
{
    public static class FantasyBoxTab
    {
        public static PowersTab tab;

        public static void Init()
        {
            Sprite tabIcon = SpriteTextureLoader.getSprite("ui/Icons/tabIconFantasyBox");
            if (tabIcon == null)
            {
                tabIcon = SpriteTextureLoader.getSprite("ui/icons/iconFantasyUI");
                if (tabIcon == null)
                {
                    Texture2D defaultTexture = new Texture2D(2, 2);
                    defaultTexture.SetPixel(0, 0, Color.white);
                    defaultTexture.Apply();
                    tabIcon = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }
            }

            Localization.AddOrSet("Button_Tab_FantasyBox", "FantasyBox");
            Localization.AddOrSet("Button_Tab_FantasyBox Description", "Explore FantasyBox...");
            Localization.AddOrSet("fantasybox_mod_creator", "ahoyos");
            Localization.AddOrSet("mods_ui", "Mods UI");
            Localization.AddOrSet("mods_ui_description", "Browse available mods");

            try
            {
                tab = TabManager.CreateTab(
                    "FantasyBox",
                    "Button_Tab_FantasyBox",
                    "Button_Tab_FantasyBox Description",
                    tabIcon,
                    "fantasybox_mod_creator"
                );

                if (tab == null)
                {
                    return;
                }
            }
            catch (Exception)
            {
                return;
            }

            LoadButtons();
            AddLogo();
            AddSectionLabel();
        }

        private static void AddLogo()
        {
            Sprite logoSprite = SpriteTextureLoader.getSprite("ui/Icons/iconFantasyBoxLogo");
            if (logoSprite == null)
            {
                return;
            }

            GameObject logoObject = new GameObject("FantasyBoxLogo");
            logoObject.transform.SetParent(tab.transform, false);
            Image logoImage = logoObject.AddComponent<Image>();
            logoImage.sprite = logoSprite;
            logoImage.rectTransform.sizeDelta = new Vector2(81f, 91f);
            logoImage.rectTransform.anchoredPosition = new Vector2(760f, 0f);

            logoObject.AddComponent<LogoSpinner>();

            EventTrigger trigger = logoObject.AddComponent<EventTrigger>();
            EventTrigger.Entry pointerEnter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
            pointerEnter.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = true; });
            trigger.triggers.Add(pointerEnter);

            EventTrigger.Entry pointerExit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            pointerExit.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = false; });
            trigger.triggers.Add(pointerExit);
        }

        private static void AddSectionLabel()
        {
            GameObject labelObject = new GameObject("FantasyBoxLabel");
            labelObject.transform.SetParent(tab.transform, false);
            Text labelText = labelObject.AddComponent<Text>();
            labelText.text = "Hail Zeyl👼";
            labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            labelText.fontSize = 16;
            labelText.color = Color.white;
            labelText.alignment = TextAnchor.MiddleLeft;
            labelText.rectTransform.sizeDelta = new Vector2(100f, 20f);
            labelText.rectTransform.anchoredPosition = new Vector2(72f, 54f);
        }

        private static void LoadButtons()
        {
            if (tab == null)
            {
                return;
            }

            Sprite modsSprite = SpriteTextureLoader.getSprite("ui/icons/iconModsUI");
            if (modsSprite == null)
            {
                Texture2D defaultTexture = new Texture2D(2, 2);
                defaultTexture.SetPixel(0, 0, Color.white);
                defaultTexture.Apply();
                modsSprite = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }

            try
            {
                PowerButtons.CreateButton(
                    "ModsUI",
                    modsSprite,
                    "Mods UI",
                    "Browse available mods",
                    new Vector2(108f, 48f),
                    ButtonType.Click,
                    tab.transform,
                    ModsBoxUI.ShowModsUI
                );
            }
            catch (Exception)
            {
            }

            var hollowWarriorSpawn = new GodPower();
            hollowWarriorSpawn.id = "spawnhollowwarrior";
            hollowWarriorSpawn.show_spawn_effect = true;
            hollowWarriorSpawn.multiple_spawn_tip = true;
            hollowWarriorSpawn.actor_spawn_height = 3f;
            hollowWarriorSpawn.name = "spawnhollowwarrior";
            hollowWarriorSpawn.sound_event = "spawn";
            hollowWarriorSpawn.actor_asset_id = "hollowwarrior";
            hollowWarriorSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowWarriorSpawn);
            Localization.AddOrSet("spawnhollowwarrior", "Hollow Warrior");
            Localization.AddOrSet("spawnhollowwarrior_description", "Spawn Hollow Warriors");

            var hollowPusSpawn = new GodPower();
            hollowPusSpawn.id = "spawnhollowpus";
            hollowPusSpawn.show_spawn_effect = true;
            hollowPusSpawn.multiple_spawn_tip = true;
            hollowPusSpawn.actor_spawn_height = 3f;
            hollowPusSpawn.name = "spawnhollowpus";
            hollowPusSpawn.sound_event = "spawn";
            hollowPusSpawn.actor_asset_id = "hollowpus";
            hollowPusSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowPusSpawn);
            Localization.AddOrSet("spawnhollowpus", "Hollow Pus");
            Localization.AddOrSet("spawnhollowpus_description", "Spawn Hollow Pus");

            var hollowCrabSpawn = new GodPower();
            hollowCrabSpawn.id = "spawnhollowcrab";
            hollowCrabSpawn.show_spawn_effect = true;
            hollowCrabSpawn.multiple_spawn_tip = true;
            hollowCrabSpawn.actor_spawn_height = 3f;
            hollowCrabSpawn.name = "spawnhollowcrab";
            hollowCrabSpawn.sound_event = "spawn";
            hollowCrabSpawn.actor_asset_id = "hollowcrab";
            hollowCrabSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowCrabSpawn);
            Localization.AddOrSet("spawnhollowcrab", "Hollow Crab");
            Localization.AddOrSet("spawnhollowcrab_description", "Spawn Hollow Crabs");

            var hollowPedeSpawn = new GodPower();
            hollowPedeSpawn.id = "spawnhollowpede";
            hollowPedeSpawn.show_spawn_effect = true;
            hollowPedeSpawn.multiple_spawn_tip = true;
            hollowPedeSpawn.actor_spawn_height = 3f;
            hollowPedeSpawn.name = "spawnhollowpede";
            hollowPedeSpawn.sound_event = "spawn";
            hollowPedeSpawn.actor_asset_id = "hollowpede";
            hollowPedeSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowPedeSpawn);
            Localization.AddOrSet("spawnhollowpede", "Hollow Pede");
            Localization.AddOrSet("spawnhollowpede_description", "Spawn Hollow Pedes");

            var hollowKrakenSpawn = new GodPower();
            hollowKrakenSpawn.id = "spawnhollowkraken";
            hollowKrakenSpawn.show_spawn_effect = true;
            hollowKrakenSpawn.multiple_spawn_tip = true;
            hollowKrakenSpawn.actor_spawn_height = 3f;
            hollowKrakenSpawn.name = "spawnhollowkraken";
            hollowKrakenSpawn.sound_event = "spawn";
            hollowKrakenSpawn.actor_asset_id = "hollowkraken";
            hollowKrakenSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowKrakenSpawn);
            Localization.AddOrSet("spawnhollowkraken", "Hollow Kraken");
            Localization.AddOrSet("spawnhollowkraken_description", "Spawn Hollow Krakens");

            var hollowDrenSpawn = new GodPower();
            hollowDrenSpawn.id = "spawnhollowdren";
            hollowDrenSpawn.show_spawn_effect = true;
            hollowDrenSpawn.multiple_spawn_tip = true;
            hollowDrenSpawn.actor_spawn_height = 3f;
            hollowDrenSpawn.name = "spawnhollowdren";
            hollowDrenSpawn.sound_event = "spawn";
            hollowDrenSpawn.actor_asset_id = "hollowdren";
            hollowDrenSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowDrenSpawn);
            Localization.AddOrSet("spawnhollowdren", "Hollow Dren");
            Localization.AddOrSet("spawnhollowdren_description", "Spawn Hollow Drens");

            var hollowGodSpawn = new GodPower();
            hollowGodSpawn.id = "spawnhollowgod";
            hollowGodSpawn.show_spawn_effect = true;
            hollowGodSpawn.multiple_spawn_tip = true;
            hollowGodSpawn.actor_spawn_height = 3f;
            hollowGodSpawn.name = "spawnhollowgod";
            hollowGodSpawn.sound_event = "spawn";
            hollowGodSpawn.actor_asset_id = "hollowgod";
            hollowGodSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(hollowGodSpawn);
            Localization.AddOrSet("spawnhollowgod", "Hollow God");
            Localization.AddOrSet("spawnhollowgod_description", "Spawn Hollow Gods");

            var quorgSpawn = new GodPower();
            quorgSpawn.id = "spawnquorg";
            quorgSpawn.show_spawn_effect = true;
            quorgSpawn.multiple_spawn_tip = true;
            quorgSpawn.actor_spawn_height = 3f;
            quorgSpawn.name = "spawnquorg";
            quorgSpawn.sound_event = "quorch";
            quorgSpawn.actor_asset_id = "quorg";
            quorgSpawn.click_action = new PowerActionWithID(CallSpawnUnit);
            AssetManager.powers.add(quorgSpawn);
            Localization.AddOrSet("spawnhollowquorg", "Quorg");
            Localization.AddOrSet("spawnhollowquorg_description", "Spawn Quorgs");

            Sprite hollowWarriorSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowWarrior");
            PowerButtons.CreateButton(
                "spawnhollowwarrior",
                hollowWarriorSprite,
                "Hollow Warrior",
                "???",
                new Vector2(108f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowPusSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowPus");
            PowerButtons.CreateButton(
                "spawnhollowpus",
                hollowPusSprite,
                "Hollow Pus",
                "???",
                new Vector2(108f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowCrabSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowCrab");
            PowerButtons.CreateButton(
                "spawnhollowcrab",
                hollowCrabSprite,
                "Hollow Crab",
                "???",
                new Vector2(144f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowPedeSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowPede");
            PowerButtons.CreateButton(
                "spawnhollowpede",
                hollowPedeSprite,
                "Hollow Pede",
                "???",
                new Vector2(144f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowKrakenSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowKraken");
            PowerButtons.CreateButton(
                "spawnhollowkraken",
                hollowKrakenSprite,
                "Hollow Kraken",
                "???",
                new Vector2(180f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowDrenSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowDren");
            PowerButtons.CreateButton(
                "spawnhollowdren",
                hollowDrenSprite,
                "Hollow Dren",
                "???",
                new Vector2(180f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite hollowGodSprite = SpriteTextureLoader.getSprite("ui/Icons/iconHollowGod");
            PowerButtons.CreateButton(
                "spawnhollowgod",
                hollowGodSprite,
                "Hollow God",
                "The Hollow Deity",
                new Vector2(216f, 18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );

            Sprite quorgSprite = SpriteTextureLoader.getSprite("ui/Icons/iconQuorg");
            PowerButtons.CreateButton(
                "spawnquorg",
                quorgSprite,
                "Quorg",
                "A Mysterious Quorg Entity",
                new Vector2(216f, -18f),
                ButtonType.GodPower,
                tab.transform,
                null
            );
        }

        public static bool CallSpawnUnit(WorldTile pTile, string pPowerID)
        {
            try
            {
                AssetManager.powers.spawnUnit(pTile, pPowerID);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}

// I just found out women can fart and poop (I'm 16 btw)