using UnityEngine;

public class LogoSpinner : MonoBehaviour
{
    public bool isSpinning = false;
    private float spinSpeed = 360f;

    void Update()
    {
        if (isSpinning)
        {
            transform.Rotate(0, 0, spinSpeed * Time.deltaTime);
        }
    }
}

//feel free to take this file it's very simple and easy...