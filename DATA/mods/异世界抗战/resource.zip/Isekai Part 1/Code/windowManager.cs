using System;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace Isekai
{
    class WindowManager
    {



            //ahoyos was here mf
        public static Dictionary<string, GameObject> windows = new Dictionary<string, GameObject>();

        public static void init()
        {
            if (GameObjects.FindEvenInactive("NameInputElement") == null)
            {
                UnityEngine.Object.Instantiate(Resources.Load<GameObject>("windows/unit").transform.GetChild(2).GetChild(4));
            }

            if (!windows.ContainsKey("FuseWindow") || windows["FuseWindow"] == null)
            {
                newWindow("FuseWindow", "Fuse Units");
            }
        }

        private static void newWindow(string id, string title)
        {
            try
            {
                var window = Windows.CreateNewWindow(id, title);
                if (window == null)
                {
                    Debug.LogError($"Failed to create window {id}");
                    return;
                }

                var windowGameObject = window.gameObject;
                var scrollView = GameObject.Find($"/Canvas Container Main/Canvas - Windows/windows/{window.name}/Background/Scroll View");
                if (scrollView == null)
                {
                    Debug.LogError($"Scroll view not found for window {id}");
                    return;
                }

                var content = GameObject.Find($"/Canvas Container Main/Canvas - Windows/windows/{window.name}/Background/Scroll View/Viewport/Content");
                if (content == null)
                {
                    Debug.LogError($"Content not found for window {id}");
                    return;
                }

                windows[id] = windowGameObject;

                if (id == "FuseWindow")
                {
                    GameObject customCanvasObj = new GameObject("FuseCustomCanvas");
                    customCanvasObj.transform.SetParent(windowGameObject.transform, false);

                    Canvas customCanvas = customCanvasObj.AddComponent<Canvas>();
                    customCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    customCanvas.sortingOrder = 20;

                    CanvasScaler scaler = customCanvasObj.AddComponent<CanvasScaler>();
                    scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                    scaler.referenceResolution = new Vector2(1920, 1088);
                    scaler.matchWidthOrHeight = 0.5f;

                    customCanvasObj.AddComponent<GraphicRaycaster>();

                    GameObject customImageObj = new GameObject("FuseCustomImage");
                    customImageObj.transform.SetParent(customCanvasObj.transform, false);
                    Image customImage = customImageObj.AddComponent<Image>();
                    Sprite customSprite = Resources.Load<Sprite>("ui/Icons/fusecustom");
                    if (customSprite != null)
                    {
                        customImage.sprite = customSprite;
                    }
                    else
                    {
                        Debug.LogError("Custom sprite ui/Icons/fusecustom not found.");
                    }

                    RectTransform imageRect = customImageObj.GetComponent<RectTransform>();
                    imageRect.anchorMin = Vector2.zero;
                    imageRect.anchorMax = new Vector2(1f, 0.9f);
                    imageRect.offsetMin = Vector2.zero;
                    imageRect.offsetMax = Vector2.zero;
                    imageRect.localScale = new Vector3(2.4f, 3.2f, 4f);

                    customCanvasObj.SetActive(true);
                }

                scrollView.SetActive(true);
            }
            catch (Exception ex)
            {
                Debug.LogError($"Error creating window {id}: {ex.Message}");
            }
        }
    }
}