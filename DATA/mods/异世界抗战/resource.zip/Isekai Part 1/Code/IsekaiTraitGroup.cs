using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReflectionUtility;
using UnityEngine;
using NCMS;

namespace Isekai
{
    class TraitGroup
    {
        public static string isekaitg = "Realms";
        public static string isekaitg2 = "MartialArts"; 
        public static string isekaitg3 = "talismans";
        public static string isekaitg4 = "Seals";

        public static void init()
        {
            ActorTraitGroupAsset realms = new ActorTraitGroupAsset();
            realms.id = "isekaitg";
            realms.name = "trait_group_Realms";
            realms.color = Toolbox.colorToHex(Toolbox.makeColor("#FFA500", -1f));
            AssetManager.trait_groups.add(realms);
            LocalizedTextManager.add("trait_group_Realms", "Realms");

            ActorTraitGroupAsset martialArts = new ActorTraitGroupAsset(); 
            martialArts.id = "isekaitg2";
            martialArts.name = "trait_group_MartialArts";
            martialArts.color = Toolbox.colorToHex(Toolbox.makeColor("#FFA500", -1f));
            AssetManager.trait_groups.add(martialArts);
            LocalizedTextManager.add("trait_group_MartialArts", "MartialArts");

            ActorTraitGroupAsset talismans = new ActorTraitGroupAsset();
            talismans.id = "isekaitg3";
            talismans.name = "trait_group_talismans";
            talismans.color = Toolbox.colorToHex(Toolbox.makeColor("#FFA500", -1f));
            AssetManager.trait_groups.add(talismans);
            LocalizedTextManager.add("trait_group_talismans", "talismans");

            ActorTraitGroupAsset seals = new ActorTraitGroupAsset();
            seals.id = "isekaitg4";
            seals.name = "trait_group_Seals";
            seals.color = Toolbox.colorToHex(Toolbox.makeColor("#FFA500", -1f));
            AssetManager.trait_groups.add(seals);
            LocalizedTextManager.add("trait_group_Seals", "Seals");
        }

        private static void addTraitGroupToLocalizedLibrary(string id, string name)
        {
            string language = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
            Dictionary<string, string> localizedText = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "localizedText") as Dictionary<string, string>;
            localizedText.Add("trait_group_" + id, name);
        }
    }
}


  //Fuck you