using System;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace Isekai
{
    public static class ModsBoxUI
    {
        private static GameObject modsUI;
        private static bool isUIActive;

        public static void Init()
        {
            Localization.AddOrSet("mods_ui", "Mods UI");
            Localization.AddOrSet("mods_ui_description", "Browse recommended mods");

            CreateModsUI();
        }

        private static void CreateModsUI()
        {
            modsUI = new GameObject("ModsUI");
            Canvas canvas = modsUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1000;
            modsUI.AddComponent<CanvasScaler>();
            modsUI.AddComponent<GraphicRaycaster>();
            modsUI.SetActive(false);

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(modsUI.transform, false);
            GIFPlayer gifPlayer = backgroundObject.AddComponent<GIFPlayer>();
            string backgroundPath = System.IO.Path.Combine(Application.dataPath.Replace("worldbox_Data", "Mods/Isekai Part 1"), "GameResources/ui/backgroun1806.gif");
            if (System.IO.File.Exists(backgroundPath))
            {
                gifPlayer.LoadGIF(backgroundPath);
            }
            else
            {
                Debug.LogWarning($"[Isekai Mod] GIF file {backgroundPath} not found, using fallback image.");
            }
            Image backgroundImage = backgroundObject.GetComponent<Image>();
            if (backgroundImage == null)
            {
                backgroundImage = backgroundObject.AddComponent<Image>();
                backgroundImage.type = Image.Type.Sliced;
                backgroundImage.color = Color.black;
            }
            backgroundImage.rectTransform.anchorMin = new Vector2(0, 0);
            backgroundImage.rectTransform.anchorMax = new Vector2(1, 1);
            backgroundImage.rectTransform.offsetMin = new Vector2(0, 0);
            backgroundImage.rectTransform.offsetMax = new Vector2(0, 0);

            var mods = new List<(string spritePath, string url, string name)>
            {
                ("ui/mods/modernbox.png", "https://gamebanana.com/mods/462076", "ModernBox"),
                ("ui/mods/Berserk.png", "https://gamebanana.com/mods/384256", "Berserk"),
                ("ui/mods/natural_traits.png", "https://gamebanana.com/mods/498334", "Natural Traits"),
                ("ui/mods/EmpireCraft.png", "https://gamebanana.com/mods/602979", "EmpireCraft"),
                ("ui/mods/shonenBox.png", "https://gamebanana.com/mods/391003", "One piecemod"),
                ("ui/mods/termite_traits.png", "https://gamebanana.com/mods/595311", "Termite Traits")
            };

            float spacing = 300f;
            float startX = 0.1f;
            float startY = 0.75f;
            int modsPerRow = 3;
            for (int i = 0; i < mods.Count; i++)
            {
                var mod = mods[i];
                Sprite modSprite = SpriteTextureLoader.getSprite(mod.spritePath);
                if (modSprite == null)
                {
                    Debug.LogWarning($"[Isekai Mod] Mod sprite {mod.spritePath} not found. Using default sprite.");
                    Texture2D defaultTexture = new Texture2D(2, 2);
                    defaultTexture.SetPixel(0, 0, Color.white);
                    defaultTexture.Apply();
                    modSprite = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }

                GameObject modObject = new GameObject($"Mod_{mod.name}");
                modObject.transform.SetParent(modsUI.transform, false);
                Image modImage = modObject.AddComponent<Image>();
                modImage.sprite = modSprite;
                modImage.rectTransform.sizeDelta = new Vector2(200f, 150f);
                float x = startX + (i % modsPerRow) * spacing / Screen.width;
                float y = startY - (i / modsPerRow) * spacing / Screen.height;
                modImage.rectTransform.anchorMin = new Vector2(x, y);
                modImage.rectTransform.anchorMax = new Vector2(x, y);
                modImage.rectTransform.anchoredPosition = Vector2.zero;

                Button modButton = modObject.AddComponent<Button>();
                modButton.onClick.AddListener(() => Application.OpenURL(mod.url));

                GameObject labelObject = new GameObject($"Label_{mod.name}");
                labelObject.transform.SetParent(modObject.transform, false);
                Text labelText = labelObject.AddComponent<Text>();
                labelText.text = mod.name;
                labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                labelText.fontSize = 14;
                labelText.color = Color.white;
                labelText.alignment = TextAnchor.UpperCenter;
                labelText.rectTransform.sizeDelta = new Vector2(200f, 20f);
                labelText.rectTransform.anchoredPosition = new Vector2(0, -80f);
            }

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(modsUI.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            Sprite exitSprite = SpriteTextureLoader.getSprite("ui/exit.png");
            if (exitSprite == null)
            {
                Debug.LogError("[Isekai Mod] Exit button sprite ui/exit.png not found. Using red color thing.");
                exitButtonImage.color = new Color(0.5f, 0.0f, 0.0f, 1f);
            }
            else
            {
                exitButtonImage.sprite = exitSprite;
                exitButtonImage.type = Image.Type.Sliced;
            }
            exitButtonImage.rectTransform.sizeDelta = new Vector2(100f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(1f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(1f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(-10f, -10f);
            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(HideeModsUI);

            GameObject madeByObject = new GameObject("MadeBy");
            madeByObject.transform.SetParent(modsUI.transform, false);
            Text madeByText = madeByObject.AddComponent<Text>();
            madeByText.text = "recommended mods :3";
            madeByText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            madeByText.fontSize = 20;
            madeByText.color = Color.yellow;
            madeByText.alignment = TextAnchor.LowerCenter;
            madeByText.rectTransform.sizeDelta = new Vector2(250f, 40f);
            madeByText.rectTransform.anchorMin = new Vector2(0.5f, 0);
            madeByText.rectTransform.anchorMax = new Vector2(0.5f, 0);
            madeByText.rectTransform.anchoredPosition = new Vector2(0, 50f);
        }

        public static void ShowModsUI()
        {
            if (!isUIActive)
            {
                modsUI.SetActive(true);
                isUIActive = true;
                Debug.Log("[Isekai Mod] Mods UI shown.");
            }
        }

        private static void HideeModsUI()
        {
            if (isUIActive)
            {
                modsUI.SetActive(false);
                isUIActive = false;
                Debug.Log("[Isekai Mod] Mods UI hidden.");
            }
        }
    }
}