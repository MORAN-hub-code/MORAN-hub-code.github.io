using NCMS;
using UnityEngine;
using NeoModLoader.General;
using System.Linq;
using ReflectionUtility;
using System.Collections.Generic;

namespace Isekai
{
    public static class IsekaiAges
    {
        private static bool initialized = false;

        public static void Init()
        {
            initialized = true;
            LM.AddToCurrentLocale("age_magical_outbreak_description", "Magic surges through the world, transforming everything it touches");
            LM.AddToCurrentLocale("age_demonic_despair_description", "The gates of hell have opened, unleashing unspeakable horrors");
            LM.AddToCurrentLocale("age_hollow_description", "A barren wasteland where only the hollow remain");

            WorldAgeAsset magicalOutbreak = new WorldAgeAsset
            {
                id = "age_magical_outbreak",
                path_icon = "ui/Icons/ages/iconAgeMagicalOutbreak",
                rate = 5,
                overlay_ash = false,
                era_effect_overlay_alpha = 0.5f,
                biomes = AssetLibrary<WorldAgeAsset>.h<string>(new string[] { "biome_enchanted", "biome_forest" })
            };
            AssetManager.era_library.add(magicalOutbreak);
            LM.AddToCurrentLocale("age_magical_outbreak_title", "Age of Magical Outbreak");

            WorldAgeAsset demonicDespair = new WorldAgeAsset
            {
                id = "age_demonic_despair",
                path_icon = "ui/Icons/ages/iconAgeDemonicDespair",
                rate = 5,
                overlay_ash = true,
                era_effect_overlay_alpha = 0.7f,
                biomes = AssetLibrary<WorldAgeAsset>.h<string>(new string[] { "biome_infernal", "biome_corrupted" })
            };
            AssetManager.era_library.add(demonicDespair);
            LM.AddToCurrentLocale("age_demonic_despair_title", "Age of Demonic Despair");

            WorldAgeAsset hollowAge = new WorldAgeAsset
            {
                id = "age_hollow",
                path_icon = "ui/Icons/ages/iconAgeHollow",
                rate = 5,
                overlay_ash = false,
                era_effect_overlay_alpha = 0.4f,
                biomes = AssetLibrary<WorldAgeAsset>.h<string>(new string[] { "biome_wasteland", "biome_desert" })
            };
            AssetManager.era_library.add(hollowAge);
            LM.AddToCurrentLocale("age_hollow_title", "Age of Hollow");

            DelayedActionsManager.addAction(CheckCurrentAge, 60f, true);
        }

        private static string lastAge = "";
        private static void CheckCurrentAge()
        {
            var currentAge = World.world.era_manager.getCurrentAge();
            if (currentAge.id != lastAge)
            {
                lastAge = currentAge.id;
                OnAgeChanged(currentAge);
            }
        }

        private static void OnAgeChanged(WorldAgeAsset age)
        {
            if (age.id == "age_hollow")
            {
                SpawnHollowUnits();
            }
            else if (age.id == "age_demonic_despair")
            {
                SpawnDemonicUnits();
            }
        }

        private static void SpawnHollowUnits()
        {
            List<string> hollowUnits = new List<string>
            {
                "hollowwarrior",
                "hollowpus",
                "hollowcrab",
                "hollowpede",
                "hollowkraken",
                "hollowdren"
            };

            string[] hollowGods = { "hollowgod", "quorg" };
            string selectedGod = hollowGods[UnityEngine.Random.Range(0, hollowGods.Length)];
            int totalToSpawn = 100;
            int unitsPerType = Mathf.Max(1, totalToSpawn / (hollowUnits.Count + 1));

            foreach (string unitId in hollowUnits)
            {
                SpawnUnitRandomly(unitId, "IsekaiKingdom");
            }

            SpawnUnitRandomly(selectedGod, "IsekaiKingdom");
        }

        private static void SpawnDemonicUnits()
        {
            for (int i = 0; i < 200; i++)
            {
                SpawnUnitRandomly("demonking", "IsekaiKingdom");
            }
        }
        // Yes, stop asking, tuxxego is indeed gay...
        private static void SpawnUnitRandomly(string unitId, string kingdomId)
        {
            Vector2 randomPosition = new Vector2(
                UnityEngine.Random.Range(0, MapBox.width),
                UnityEngine.Random.Range(0, MapBox.height)
            );

            ActorAsset unitData = AssetManager.actor_library.get(unitId);
            MapBox.instance.units.spawnNewUnit(unitId, MapBox.instance.GetTile((int)randomPosition.x, (int)randomPosition.y));
        }
    }
}