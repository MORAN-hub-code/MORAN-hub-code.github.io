using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using ReflectionUtility;
using NCMS;
using NCMS.Utils;

namespace Isekai
{
    [Serializable]
    public class IsekaiTraits : MonoBehaviour
    {
        private static ProjectileAsset TrinityBeam;
        private static EffectAsset SealLockEffect;

        public static void Initialize()
        {
            RegisterTraitGroups();
            LocalizedTextManager.add("trait_group_Realms", "Realms");
            LocalizedTextManager.add("trait_group_MartialArts", "Martial Arts");
            LocalizedTextManager.add("trait_group_Seals", "Seals");
            LocalizedTextManager.add("trait_group_talismans", "Talismans");
            SetupTrinityBeam();
            SetupSealEffect();
            AddTraits();
        }

        private static void RegisterTraitGroups()
        {
            string[] groupIds = { "Realms", "MartialArts", "Seals", "talismans" };
            foreach (string groupId in groupIds)
            {
                if (!AssetManager.trait_groups.dict.ContainsKey(groupId))
                {
                    ActorTraitGroupAsset group = new ActorTraitGroupAsset();
                    group.id = groupId;
                    group.name = groupId;
                    AssetManager.trait_groups.add(group);
                }
            }
        }

        private static void SetupTrinityBeam()
        {
            if (TrinityBeam == null)
            {
                TrinityBeam = new ProjectileAsset();
                TrinityBeam.id = "TrinityBeam";
                TrinityBeam.speed = 50f;
                TrinityBeam.texture = "TrinityBeam";
                TrinityBeam.trail_effect_enabled = false;
                TrinityBeam.texture_shadow = "shadows/projectiles/shadow_ball";
                TrinityBeam.terraform_option = "fireball";
                TrinityBeam.terraform_range = 8;
                TrinityBeam.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
                TrinityBeam.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
                TrinityBeam.end_effect = "TrinityBoom";
                TrinityBeam.scale_start = 0.5f;
                TrinityBeam.scale_target = 0.5f;
                TrinityBeam.look_at_target = true;
                TrinityBeam.can_be_left_on_ground = false;
                TrinityBeam.can_be_blocked = false;
                TrinityBeam.world_actions = (AttackAction)Delegate.Combine(TrinityBeam.world_actions, new AttackAction(ActionLibrary.burnTile));
            }
        }

        private static void SetupSealEffect()
        {
            if (SealLockEffect == null)
            {
                SealLockEffect = new EffectAsset();
                SealLockEffect.id = "SealLockEffect";
                SealLockEffect.use_basic_prefab = true;
                SealLockEffect.sorting_layer_id = "EffectsTop";
                string spritePath = Path.Combine("Mods", "Isekai", "GameResources", "effects", "seals", "seal.png");
                Sprite sprite = Toolbox.LoadSprite(spritePath);
                if (sprite != null)
                {
                    SealLockEffect.sprite_path = spritePath;
                }
                else
                {
                    string fullPath = Path.Combine(Application.dataPath.Replace("worldbox_Data", "Mods/Isekai"), "GameResources/effects/seals/seal.png");
                    if (!File.Exists(fullPath))
                    {
                        return;
                    }
                    return;
                }
                SealLockEffect.draw_light_area = true;
                AssetManager.effects_library.add(SealLockEffect);
            }
        }

        private static void AddTraits()
        {
            EffectAsset TrinityBoom = new EffectAsset();
            TrinityBoom.id = "TrinityBoom";
            TrinityBoom.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionFireball";
            TrinityBoom.use_basic_prefab = true;
            TrinityBoom.sorting_layer_id = "EffectsTop";
            TrinityBoom.sprite_path = "effects/TrinityBoom";
            TrinityBoom.draw_light_area = true;
            AssetManager.effects_library.add(TrinityBoom);
            if (TrinityBeam != null && !AssetManager.projectiles.dict.ContainsKey("TrinityBeam"))
            {
                AssetManager.projectiles.add(TrinityBeam);
            }
            ActorTrait soul = new ActorTrait();
            soul.id = "soul";
            soul.rarity = Rarity.R0_Normal;
            soul.path_icon = "ui/ws3icons/soul";
            soul.rate_inherit = 5;
            soul.group_id = "Realms";
            soul.unlocked_with_achievement = false;
            soul.action_special_effect = new WorldAction(SoulSnatch);
            AssetManager.traits.add(soul);
            LocalizedTextManager.add("trait_soul", "Soul Realm");
            ActorTrait trinity = new ActorTrait();
            trinity.id = "trinity";
            trinity.rarity = Rarity.R0_Normal;
            trinity.path_icon = "ui/ws3icons/trinity";
            trinity.rate_inherit = 5;
            trinity.group_id = "Realms";
            trinity.unlocked_with_achievement = false;
            trinity.action_special_effect = new WorldAction(FeelMyAura);
            AssetManager.traits.add(trinity);
            LocalizedTextManager.add("trait_trinity", "Trinity Realm");
            LocalizedTextManager.add("trait_trinity_info", "Fires a radiant Trinity Beam that explodes with divine wrath");
            ActorTrait primordialRealm = new ActorTrait();
            primordialRealm.id = "primordial_realm";
            primordialRealm.rarity = Rarity.R0_Normal;
            primordialRealm.path_icon = "ui/ws3icons/primordial_realm";
            primordialRealm.rate_inherit = 4;
            primordialRealm.group_id = "Realms";
            primordialRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(primordialRealm);
            LocalizedTextManager.add("trait_primordial_realm", "Primordial Realm");
            ActorTrait temperedBodyRealm = new ActorTrait();
            temperedBodyRealm.id = "tempered_body_realm";
            temperedBodyRealm.rarity = Rarity.R0_Normal;
            temperedBodyRealm.path_icon = "ui/ws3icons/tempered_body_realm";
            temperedBodyRealm.rate_inherit = 4;
            temperedBodyRealm.group_id = "Realms";
            temperedBodyRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(temperedBodyRealm);
            LocalizedTextManager.add("trait_tempered_body_realm", "Tempered Body Realm");
            ActorTrait earthRealm = new ActorTrait();
            earthRealm.id = "earth_realm";
            earthRealm.rarity = Rarity.R0_Normal;
            earthRealm.path_icon = "ui/ws3icons/Earth";
            earthRealm.rate_inherit = 3;
            earthRealm.group_id = "Realms";
            earthRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(earthRealm);
            LocalizedTextManager.add("trait_earth_realm", "Earth Realm");
            ActorTrait lordRealm = new ActorTrait();
            lordRealm.id = "lord_realm";
            lordRealm.rarity = Rarity.R0_Normal;
            lordRealm.path_icon = "ui/ws3icons/Lord";
            lordRealm.rate_inherit = 3;
            lordRealm.group_id = "Realms";
            lordRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(lordRealm);
            LocalizedTextManager.add("trait_lord_realm", "Lord Realm");
            ActorTrait kingRealm = new ActorTrait();
            kingRealm.id = "king_realm";
            kingRealm.rarity = Rarity.R0_Normal;
            kingRealm.path_icon = "ui/ws3icons/King";
            kingRealm.rate_inherit = 2;
            kingRealm.group_id = "Realms";
            kingRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(kingRealm);
            LocalizedTextManager.add("trait_king_realm", "King Realm");
            ActorTrait emperorRealm = new ActorTrait();
            emperorRealm.id = "emperor_realm";
            emperorRealm.rarity = Rarity.R0_Normal;
            emperorRealm.path_icon = "ui/ws3icons/Emperor";
            emperorRealm.rate_inherit = 2;
            emperorRealm.group_id = "Realms";
            emperorRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(emperorRealm);
            LocalizedTextManager.add("trait_emperor_realm", "Emperor Realm");
            ActorTrait heavenRealm = new ActorTrait();
            heavenRealm.id = "heaven_realm";
            heavenRealm.rarity = Rarity.R0_Normal;
            heavenRealm.path_icon = "ui/ws3icons/heaven_realm";
            heavenRealm.rate_inherit = 1;
            heavenRealm.group_id = "Realms";
            heavenRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(heavenRealm);
            LocalizedTextManager.add("trait_heaven_realm", "Heaven Realm");
            ActorTrait demiGodRealm = new ActorTrait();
            demiGodRealm.id = "demi_god_realm";
            demiGodRealm.rarity = Rarity.R0_Normal;
            demiGodRealm.path_icon = "ui/ws3icons/DemiGod";
            demiGodRealm.rate_inherit = 1;
            demiGodRealm.group_id = "Realms";
            demiGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(demiGodRealm);
            LocalizedTextManager.add("trait_demi_god_realm", "Demi God Realm");
            ActorTrait trueGodRealm = new ActorTrait();
            trueGodRealm.id = "true_god_realm";
            trueGodRealm.rarity = Rarity.R0_Normal;
            trueGodRealm.path_icon = "ui/ws3icons/TrueGod";
            trueGodRealm.rate_inherit = 1;
            trueGodRealm.group_id = "Realms";
            trueGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(trueGodRealm);
            LocalizedTextManager.add("trait_true_god_realm", "True God Realm");
            ActorTrait godKingRealm = new ActorTrait();
            godKingRealm.id = "god_king_realm";
            godKingRealm.rarity = Rarity.R0_Normal;
            godKingRealm.path_icon = "ui/ws3icons/GodKing";
            godKingRealm.rate_inherit = 1;
            godKingRealm.group_id = "Realms";
            godKingRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(godKingRealm);
            LocalizedTextManager.add("trait_god_king_realm", "God King Realm");
            ActorTrait godEmperorRealm = new ActorTrait();
            godEmperorRealm.id = "god_emperor_realm";
            godEmperorRealm.rarity = Rarity.R0_Normal;
            godEmperorRealm.path_icon = "ui/ws3icons/GodEmperor";
            godEmperorRealm.rate_inherit = 1;
            godEmperorRealm.group_id = "Realms";
            godEmperorRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(godEmperorRealm);
            LocalizedTextManager.add("trait_god_emperor_realm", "God Emperor Realm");
            ActorTrait supremeGodRealm = new ActorTrait();
            supremeGodRealm.id = "supreme_god_realm";
            supremeGodRealm.rarity = Rarity.R0_Normal;
            supremeGodRealm.path_icon = "ui/ws3icons/SupremeGod";
            supremeGodRealm.rate_inherit = 1;
            supremeGodRealm.group_id = "Realms";
            supremeGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(supremeGodRealm);
            LocalizedTextManager.add("trait_supreme_god_realm", "Supreme God Realm");
            ActorTrait spaceTeleport = new ActorTrait();
            spaceTeleport.id = "space_teleport";
            spaceTeleport.rarity = Rarity.R0_Normal;
            spaceTeleport.path_icon = "ui/ws3icons/spaceTeleport.png";
            spaceTeleport.rate_inherit = 5;
            spaceTeleport.group_id = "MartialArts";
            spaceTeleport.unlocked_with_achievement = false;
            spaceTeleport.action_special_effect = new WorldAction(SpaceTeleportEffect);
            AssetManager.traits.add(spaceTeleport);
            LocalizedTextManager.add("trait_space_teleport", "Space Teleport");
            ActorTrait spaceCollapse = new ActorTrait();
            spaceCollapse.id = "space_collapse";
            spaceCollapse.rarity = Rarity.R0_Normal;
            spaceCollapse.path_icon = "ui/ws3icons/spaceCollapse.png";
            spaceCollapse.rate_inherit = 5;
            spaceCollapse.group_id = "MartialArts";
            spaceCollapse.unlocked_with_achievement = false;
            spaceCollapse.action_special_effect = new WorldAction(SpaceCollapseEffect);
            AssetManager.traits.add(spaceCollapse);
            LocalizedTextManager.add("trait_space_collapse", "Space Collapse");
            ActorTrait voidShield = new ActorTrait();
            voidShield.id = "void_shield";
            voidShield.rarity = Rarity.R0_Normal;
            voidShield.path_icon = "ui/ws3icons/voidShield.png";
            voidShield.rate_inherit = 4;
            voidShield.group_id = "MartialArts";
            voidShield.unlocked_with_achievement = false;
            AssetManager.traits.add(voidShield);
            LocalizedTextManager.add("trait_void_shield", "Void Shield");
            ActorTrait voidSlash = new ActorTrait();
            voidSlash.id = "void_slash";
            voidSlash.rarity = Rarity.R0_Normal;
            voidSlash.path_icon = "ui/ws3icons/voidSlash.png";
            voidSlash.rate_inherit = 4;
            voidSlash.group_id = "MartialArts";
            voidSlash.unlocked_with_achievement = false;
            AssetManager.traits.add(voidSlash);
            LocalizedTextManager.add("trait_void_slash", "Void Slash");
            ActorTrait timeSlash = new ActorTrait();
            timeSlash.id = "time_slash";
            timeSlash.rarity = Rarity.R0_Normal;
            timeSlash.path_icon = "ui/ws3icons/timeSlash.png";
            timeSlash.rate_inherit = 3;
            timeSlash.group_id = "MartialArts";
            timeSlash.unlocked_with_achievement = false;
            AssetManager.traits.add(timeSlash);
            LocalizedTextManager.add("trait_time_slash", "Time Slash");
            ActorTrait timeStop = new ActorTrait();
            timeStop.id = "time_stop";
            timeStop.rarity = Rarity.R0_Normal;
            timeStop.path_icon = "ui/ws3icons/timeStop.png";
            timeStop.rate_inherit = 3;
            timeStop.group_id = "MartialArts";
            timeStop.unlocked_with_achievement = false;
            AssetManager.traits.add(timeStop);
            LocalizedTextManager.add("trait_time_stop", "Time Stop");
            ActorTrait fire = new ActorTrait();
            fire.id = "fire";
            fire.rarity = Rarity.R0_Normal;
            fire.path_icon = "ui/ws3icons/fire.png";
            fire.rate_inherit = 3;
            fire.group_id = "MartialArts";
            fire.unlocked_with_achievement = false;
            AssetManager.traits.add(fire);
            LocalizedTextManager.add("trait_fire", "Fire");
            ActorTrait ice = new ActorTrait();
            ice.id = "ice";
            ice.rarity = Rarity.R0_Normal;
            ice.path_icon = "ui/ws3icons/ice.png";
            ice.rate_inherit = 3;
            ice.group_id = "MartialArts";
            ice.unlocked_with_achievement = false;
            AssetManager.traits.add(ice);
            LocalizedTextManager.add("trait_ice", "Ice");
            ActorTrait poison = new ActorTrait();
            poison.id = "poison";
            poison.rarity = Rarity.R0_Normal;
            poison.path_icon = "ui/ws3icons/poison.png";
            poison.rate_inherit = 2;
            poison.group_id = "MartialArts";
            poison.unlocked_with_achievement = false;
            AssetManager.traits.add(poison);
            LocalizedTextManager.add("trait_poison", "Poison");
            ActorTrait speed = new ActorTrait();
            speed.id = "speed";
            speed.rarity = Rarity.R0_Normal;
            speed.path_icon = "ui/ws3icons/speed.png";
            speed.rate_inherit = 2;
            speed.group_id = "MartialArts";
            speed.unlocked_with_achievement = false;
            AssetManager.traits.add(speed);
            LocalizedTextManager.add("trait_speed", "Speed");
            ActorTrait goldenSkeleton = new ActorTrait();
            goldenSkeleton.id = "golden_skeleton";
            goldenSkeleton.rarity = Rarity.R0_Normal;
            goldenSkeleton.path_icon = "ui/ws3icons/goldenSkeleton.png";
            goldenSkeleton.rate_inherit = 2;
            goldenSkeleton.group_id = "MartialArts";
            goldenSkeleton.unlocked_with_achievement = false;
            AssetManager.traits.add(goldenSkeleton);
            LocalizedTextManager.add("trait_golden_skeleton", "Golden Skeleton");
            ActorTrait eyeOfHeaven = new ActorTrait();
            eyeOfHeaven.id = "eye_of_heaven";
            eyeOfHeaven.rarity = Rarity.R0_Normal;
            eyeOfHeaven.path_icon = "ui/ws3icons/heavenEye.png";
            eyeOfHeaven.rate_inherit = 1;
            eyeOfHeaven.group_id = "MartialArts";
            eyeOfHeaven.unlocked_with_achievement = false;
            AssetManager.traits.add(eyeOfHeaven);
            LocalizedTextManager.add("trait_eye_of_heaven", "Eye of Heaven");
            ActorTrait immortalTree = new ActorTrait();
            immortalTree.id = "immortal_tree";
            immortalTree.rarity = Rarity.R0_Normal;
            immortalTree.path_icon = "ui/ws3icons/immortalTree.png";
            immortalTree.rate_inherit = 1;
            immortalTree.group_id = "MartialArts";
            immortalTree.unlocked_with_achievement = false;
            AssetManager.traits.add(immortalTree);
            LocalizedTextManager.add("trait_immortal_tree", "Immortal Tree");
            ActorTrait windAndThunderWings = new ActorTrait();
            windAndThunderWings.id = "wind_and_thunder_wings";
            windAndThunderWings.rarity = Rarity.R0_Normal;
            windAndThunderWings.path_icon = "ui/ws3icons/windAndThunderWings.png";
            windAndThunderWings.rate_inherit = 1;
            windAndThunderWings.group_id = "MartialArts";
            windAndThunderWings.unlocked_with_achievement = false;
            AssetManager.traits.add(windAndThunderWings);
            LocalizedTextManager.add("trait_wind_and_thunder_wings", "Wind and Thunder Wings");
            ActorTrait voidRupt = new ActorTrait();
            voidRupt.id = "void_rupt";
            voidRupt.rarity = Rarity.R0_Normal;
            voidRupt.path_icon = "ui/ws3icons/voidRupt.png";
            voidRupt.rate_inherit = 1;
            voidRupt.group_id = "MartialArts";
            voidRupt.unlocked_with_achievement = false;
            AssetManager.traits.add(voidRupt);
            LocalizedTextManager.add("trait_void_rupt", "Void Rupt");
            ActorTrait whisperingMoonstone = new ActorTrait();
            whisperingMoonstone.id = "whispering_moonstone";
            whisperingMoonstone.rarity = Rarity.R0_Normal;
            whisperingMoonstone.path_icon = "ui/ws3icons/whispering_moonstone";
            whisperingMoonstone.rate_inherit = 5;
            whisperingMoonstone.group_id = "talismans";
            whisperingMoonstone.unlocked_with_achievement = false;
            whisperingMoonstone.action_special_effect = new WorldAction(WhisperingMoonstoneEffect);
            AssetManager.traits.add(whisperingMoonstone);
            LocalizedTextManager.add("trait_whispering_moonstone", "Whispering Moonstone");
            ActorTrait emberheartSigil = new ActorTrait();
            emberheartSigil.id = "emberheart_sigil";
            emberheartSigil.rarity = Rarity.R0_Normal;
            emberheartSigil.path_icon = "ui/ws3icons/emberheart_sigil";
            emberheartSigil.rate_inherit = 5;
            emberheartSigil.group_id = "talismans";
            emberheartSigil.unlocked_with_achievement = false;
            emberheartSigil.action_special_effect = new WorldAction(EmberheartSigilEffect);
            AssetManager.traits.add(emberheartSigil);
            LocalizedTextManager.add("trait_emberheart_sigil", "Emberheart Sigil");
            ActorTrait starwovenCharm = new ActorTrait();
            starwovenCharm.id = "starwoven_charm";
            starwovenCharm.rarity = Rarity.R0_Normal;
            starwovenCharm.path_icon = "ui/ws3icons/starwoven_charm";
            starwovenCharm.rate_inherit = 4;
            starwovenCharm.group_id = "talismans";
            starwovenCharm.unlocked_with_achievement = false;
            AssetManager.traits.add(starwovenCharm);
            LocalizedTextManager.add("trait_starwoven_charm", "Starwoven Charm");
            ActorTrait shadowveilRelic = new ActorTrait();
            shadowveilRelic.id = "shadowveil_relic";
            shadowveilRelic.rarity = Rarity.R0_Normal;
            shadowveilRelic.path_icon = "ui/ws3icons/shadowveil_relic";
            shadowveilRelic.rate_inherit = 4;
            shadowveilRelic.group_id = "talismans";
            shadowveilRelic.unlocked_with_achievement = false;
            AssetManager.traits.add(shadowveilRelic);
            LocalizedTextManager.add("trait_shadowveil_relic", "Shadowveil Relic");
            ActorTrait dawnbreakerAmulet = new ActorTrait();
            dawnbreakerAmulet.id = "dawnbreaker_amulet";
            dawnbreakerAmulet.rarity = Rarity.R0_Normal;
            dawnbreakerAmulet.path_icon = "ui/ws3icons/dawnbreaker_amulet";
            dawnbreakerAmulet.rate_inherit = 3;
            dawnbreakerAmulet.group_id = "talismans";
            dawnbreakerAmulet.unlocked_with_achievement = false;
            AssetManager.traits.add(dawnbreakerAmulet);
            LocalizedTextManager.add("trait_dawnbreaker_amulet", "Dawnbreaker Amulet");
            ActorTrait frostspireWard = new ActorTrait();
            frostspireWard.id = "frostspire_ward";
            frostspireWard.rarity = Rarity.R0_Normal;
            frostspireWard.path_icon = "ui/ws3icons/frostspire_ward";
            frostspireWard.rate_inherit = 3;
            frostspireWard.group_id = "talismans";
            frostspireWard.unlocked_with_achievement = false;
            AssetManager.traits.add(frostspireWard);
            LocalizedTextManager.add("trait_frostspire_ward", "Frostspire Ward");
            ActorTrait sunkenOracle = new ActorTrait();
            sunkenOracle.id = "sunken_oracle";
            sunkenOracle.rarity = Rarity.R0_Normal;
            sunkenOracle.path_icon = "ui/ws3icons/sunken_oracle";
            sunkenOracle.rate_inherit = 2;
            sunkenOracle.group_id = "talismans";
            sunkenOracle.unlocked_with_achievement = false;
            AssetManager.traits.add(sunkenOracle);
            LocalizedTextManager.add("trait_sunken_oracle", "Sunken Oracle");
            ActorTrait voidtouchedCrest = new ActorTrait();
            voidtouchedCrest.id = "voidtouched_crest";
            voidtouchedCrest.rarity = Rarity.R0_Normal;
            voidtouchedCrest.path_icon = "ui/ws3icons/voidtouched_crest";
            voidtouchedCrest.rate_inherit = 2;
            voidtouchedCrest.group_id = "talismans";
            voidtouchedCrest.unlocked_with_achievement = false;
            AssetManager.traits.add(voidtouchedCrest);
            LocalizedTextManager.add("trait_voidtouched_crest", "Voidtouched Crest");
            ActorTrait talismans = new ActorTrait();
            talismans.id = "talismans";
            talismans.rarity = Rarity.R0_Normal;
            talismans.path_icon = "ui/ws3icons/talismans";
            talismans.rate_inherit = 5;
            talismans.group_id = "talismans";
            talismans.unlocked_with_achievement = false;
            AssetManager.traits.add(talismans);
            LocalizedTextManager.add("trait_talismans", "Talismans");
            ActorTrait mysticBarrierSeal = new ActorTrait();
            mysticBarrierSeal.id = "mystic_barrier_seal";
            mysticBarrierSeal.rarity = Rarity.R0_Normal;
            mysticBarrierSeal.path_icon = "ui/ws3icons/mysticBarrierSeal";
            mysticBarrierSeal.rate_inherit = 5;
            mysticBarrierSeal.group_id = "Seals";
            mysticBarrierSeal.unlocked_with_achievement = false;
            mysticBarrierSeal.action_special_effect = new WorldAction(MysticBarrierSealEffect);
            AssetManager.traits.add(mysticBarrierSeal);
            LocalizedTextManager.add("trait_mystic_barrier_seal", "Mystic Barrier Seal");
            ActorTrait celestialBindingSeal = new ActorTrait();
            celestialBindingSeal.id = "celestial_binding_seal";
            celestialBindingSeal.rarity = Rarity.R0_Normal;
            celestialBindingSeal.path_icon = "ui/ws3icons/celestialPyramidSeal";
            celestialBindingSeal.rate_inherit = 5;
            celestialBindingSeal.group_id = "Seals";
            celestialBindingSeal.unlocked_with_achievement = false;
            celestialBindingSeal.action_special_effect = new WorldAction(CelestialBindingSealEffect);
            AssetManager.traits.add(celestialBindingSeal);
            LocalizedTextManager.add("trait_celestial_binding_seal", "Celestial Binding Seal");
            ActorTrait abyssalLockSeal = new ActorTrait();
            abyssalLockSeal.id = "abyssal_lock_seal";
            abyssalLockSeal.rarity = Rarity.R0_Normal;
            abyssalLockSeal.path_icon = "ui/ws3icons/abyssalLockSeal";
            abyssalLockSeal.rate_inherit = 4;
            abyssalLockSeal.group_id = "Seals";
            abyssalLockSeal.unlocked_with_achievement = false;
            abyssalLockSeal.action_special_effect = new WorldAction(AbyssalLockSealEffect);
            AssetManager.traits.add(abyssalLockSeal);
            LocalizedTextManager.add("trait_abyssal_lock_seal", "Abyssal Lock Seal");
            Dictionary<string, Dictionary<string, float>> traitStats = new Dictionary<string, Dictionary<string, float>>
            {
                {"soul", new Dictionary<string, float>(){
                    {"damage", 20f},
                    {"mana", 300f},
                    {"health", 500f},
                    {"accuracy", 30f},
                    {"attack_speed", 100f},
                    {"critical_chance", 0.05f},
                    {"range", 5f},
                    {"speed", 90f},
                    {"max_nutrition", 30f},
                    {"offspring", 80f},
                }},
                {"trinity", new Dictionary<string, float>(){
                    {"damage", 25f},
                    {"mana", 350f},
                    {"health", 550f},
                    {"accuracy", 35f},
                    {"attack_speed", 110f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 95f},
                    {"max_nutrition", 35f},
                    {"offspring", 85f},
                }},
                {"primordial_realm", new Dictionary<string, float>(){
                    {"damage", 30f},
                    {"mana", 400f},
                    {"health", 600f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.07f},
                    {"range", 7f},
                    {"speed", 100f},
                    {"max_nutrition", 40f},
                    {"offspring", 90f},
                }},
                {"tempered_body_realm", new Dictionary<string, float>(){
                    {"damage", 35f},
                    {"mana", 350f},
                    {"health", 700f},
                    {"accuracy", 35f},
                    {"attack_speed", 115f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 90f},
                    {"max_nutrition", 45f},
                    {"offspring", 80f},
                }},
                {"earth_realm", new Dictionary<string, float>(){
                    {"damage", 40f},
                    {"mana", 400f},
                    {"health", 800f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.08f},
                    {"range", 8f},
                    {"speed", 95f},
                    {"max_nutrition", 50f},
                    {"offspring", 85f},
                }},
                {"lord_realm", new Dictionary<string, float>(){
                    {"damage", 50f},
                    {"mana", 450f},
                    {"health", 900f},
                    {"accuracy", 45f},
                    {"attack_speed", 130f},
                    {"critical_chance", 0.09f},
                    {"range", 9f},
                    {"speed", 100f},
                    {"max_nutrition", 55f},
                    {"offspring", 90f},
                }},
                {"king_realm", new Dictionary<string, float>(){
                    {"damage", 60f},
                    {"mana", 500f},
                    {"health", 1000f},
                    {"accuracy", 50f},
                    {"attack_speed", 140f},
                    {"critical_chance", 0.10f},
                    {"range", 10f},
                    {"speed", 105f},
                    {"max_nutrition", 60f},
                    {"offspring", 95f},
                }},
                {"emperor_realm", new Dictionary<string, float>(){
                    {"damage", 70f},
                    {"mana", 550f},
                    {"health", 1100f},
                    {"accuracy", 55f},
                    {"attack_speed", 150f},
                    {"critical_chance", 0.11f},
                    {"range", 11f},
                    {"speed", 110f},
                    {"max_nutrition", 65f},
                    {"offspring", 100f},
                }},
                {"heaven_realm", new Dictionary<string, float>(){
                    {"damage", 80f},
                    {"mana", 600f},
                    {"health", 1200f},
                    {"accuracy", 60f},
                    {"attack_speed", 160f},
                    {"critical_chance", 0.12f},
                    {"range", 12f},
                    {"speed", 115f},
                    {"max_nutrition", 70f},
                    {"offspring", 105f},
                }},
                {"demi_god_realm", new Dictionary<string, float>(){
                    {"damage", 90f},
                    {"mana", 650f},
                    {"health", 1300f},
                    {"accuracy", 65f},
                    {"attack_speed", 170f},
                    {"critical_chance", 0.13f},
                    {"range", 13f},
                    {"speed", 120f},
                    {"max_nutrition", 75f},
                    {"offspring", 110f},
                }},
                {"true_god_realm", new Dictionary<string, float>(){
                    {"damage", 100f},
                    {"mana", 700f},
                    {"health", 1400f},
                    {"accuracy", 70f},
                    {"attack_speed", 180f},
                    {"critical_chance", 0.14f},
                    {"range", 14f},
                    {"speed", 125f},
                    {"max_nutrition", 80f},
                    {"offspring", 115f},
                }},
                {"god_king_realm", new Dictionary<string, float>(){
                    {"damage", 110f},
                    {"mana", 750f},
                    {"health", 1500f},
                    {"accuracy", 75f},
                    {"attack_speed", 190f},
                    {"critical_chance", 0.15f},
                    {"range", 15f},
                    {"speed", 130f},
                    {"max_nutrition", 85f},
                    {"offspring", 120f},
                }},
                {"god_emperor_realm", new Dictionary<string, float>(){
                    {"damage", 120f},
                    {"mana", 800f},
                    {"health", 1600f},
                    {"accuracy", 80f},
                    {"attack_speed", 200f},
                    {"critical_chance", 0.16f},
                    {"range", 16f},
                    {"speed", 135f},
                    {"max_nutrition", 90f},
                    {"offspring", 125f},
                }},
                {"supreme_god_realm", new Dictionary<string, float>(){
                    {"damage", 150f},
                    {"mana", 1000f},
                    {"health", 2000f},
                    {"accuracy", 100f},
                    {"attack_speed", 250f},
                    {"critical_chance", 0.20f},
                    {"range", 20f},
                    {"speed", 150f},
                    {"max_nutrition", 100f},
                    {"offspring", 150f},
                }},
                {"space_teleport", new Dictionary<string, float>(){
                    {"damage", 20f},
                    {"mana", 300f},
                    {"health", 500f},
                    {"accuracy", 30f},
                    {"attack_speed", 100f},
                    {"critical_chance", 0.05f},
                    {"range", 5f},
                    {"speed", 90f},
                    {"max_nutrition", 30f},
                    {"offspring", 80f},
                }},
                {"space_collapse", new Dictionary<string, float>(){
                    {"damage", 25f},
                    {"mana", 350f},
                    {"health", 550f},
                    {"accuracy", 35f},
                    {"attack_speed", 110f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 95f},
                    {"max_nutrition", 35f},
                    {"offspring", 85f},
                }},
                {"void_shield", new Dictionary<string, float>(){
                    {"damage", 30f},
                    {"mana", 400f},
                    {"health", 600f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.07f},
                    {"range", 7f},
                    {"speed", 100f},
                    {"max_nutrition", 40f},
                    {"offspring", 90f},
                }},
                {"void_slash", new Dictionary<string, float>(){
                    {"damage", 35f},
                    {"mana", 350f},
                    {"health", 700f},
                    {"accuracy", 35f},
                    {"attack_speed", 115f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 90f},
                    {"max_nutrition", 45f},
                    {"offspring", 80f},
                }},
                {"time_slash", new Dictionary<string, float>(){
                    {"damage", 40f},
                    {"mana", 400f},
                    {"health", 800f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.08f},
                    {"range", 8f},
                    {"speed", 95f},
                    {"max_nutrition", 50f},
                    {"offspring", 85f},
                }},
                {"time_stop", new Dictionary<string, float>(){
                    {"damage", 50f},
                    {"mana", 450f},
                    {"health", 900f},
                    {"accuracy", 45f},
                    {"attack_speed", 130f},
                    {"critical_chance", 0.09f},
                    {"range", 9f},
                    {"speed", 100f},
                    {"max_nutrition", 55f},
                    {"offspring", 90f},
                }},
                {"fire", new Dictionary<string, float>(){
                    {"damage", 60f},
                    {"mana", 500f},
                    {"health", 1000f},
                    {"accuracy", 50f},
                    {"attack_speed", 140f},
                    {"critical_chance", 0.10f},
                    {"range", 10f},
                    {"speed", 105f},
                    {"max_nutrition", 60f},
                    {"offspring", 95f},
                }},
                {"ice", new Dictionary<string, float>(){
                    {"damage", 70f},
                    {"mana", 550f},
                    {"health", 1100f},
                    {"accuracy", 55f},
                    {"attack_speed", 150f},
                    {"critical_chance", 0.11f},
                    {"range", 11f},
                    {"speed", 110f},
                    {"max_nutrition", 65f},
                    {"offspring", 100f},
                }},
                {"poison", new Dictionary<string, float>(){
                    {"damage", 80f},
                    {"mana", 600f},
                    {"health", 1200f},
                    {"accuracy", 60f},
                    {"attack_speed", 160f},
                    {"critical_chance", 0.12f},
                    {"range", 12f},
                    {"speed", 115f},
                    {"max_nutrition", 70f},
                    {"offspring", 105f},
                }},
                {"speed", new Dictionary<string, float>(){
                    {"damage", 90f},
                    {"mana", 650f},
                    {"health", 1300f},
                    {"accuracy", 65f},
                    {"attack_speed", 170f},
                    {"critical_chance", 0.13f},
                    {"range", 13f},
                    {"speed", 120f},
                    {"max_nutrition", 75f},
                    {"offspring", 110f},
                }},
                {"golden_skeleton", new Dictionary<string, float>(){
                    {"damage", 100f},
                    {"mana", 700f},
                    {"health", 1400f},
                    {"accuracy", 70f},
                    {"attack_speed", 180f},
                    {"critical_chance", 0.14f},
                    {"range", 14f},
                    {"speed", 125f},
                    {"max_nutrition", 80f},
                    {"offspring", 115f},
                }},
                {"eye_of_heaven", new Dictionary<string, float>(){
                    {"damage", 110f},
                    {"mana", 750f},
                    {"health", 1500f},
                    {"accuracy", 75f},
                    {"attack_speed", 190f},
                    {"critical_chance", 0.15f},
                    {"range", 15f},
                    {"speed", 130f},
                    {"max_nutrition", 85f},
                    {"offspring", 120f},
                }},
                {"immortal_tree", new Dictionary<string, float>(){
                    {"damage", 120f},
                    {"mana", 800f},
                    {"health", 1600f},
                    {"accuracy", 80f},
                    {"attack_speed", 200f},
                    {"critical_chance", 0.16f},
                    {"range", 16f},
                    {"speed", 135f},
                    {"max_nutrition", 90f},
                    {"offspring", 125f},
                }},
                {"wind_and_thunder_wings", new Dictionary<string, float>(){
                    {"damage", 130f},
                    {"mana", 850f},
                    {"health", 1700f},
                    {"accuracy", 85f},
                    {"attack_speed", 210f},
                    {"critical_chance", 0.17f},
                    {"range", 17f},
                    {"speed", 140f},
                    {"max_nutrition", 95f},
                    {"offspring", 130f},
                }},
                {"void_rupt", new Dictionary<string, float>(){
                    {"damage", 150f},
                    {"mana", 1000f},
                    {"health", 2000f},
                    {"accuracy", 100f},
                    {"attack_speed", 250f},
                    {"critical_chance", 0.20f},
                    {"range", 20f},
                    {"speed", 150f},
                    {"max_nutrition", 100f},
                    {"offspring", 150f},
                }},
                {"whispering_moonstone", new Dictionary<string, float>(){
                    {"damage", 20f},
                    {"mana", 300f},
                    {"health", 500f},
                    {"accuracy", 30f},
                    {"attack_speed", 100f},
                    {"critical_chance", 0.05f},
                    {"range", 5f},
                    {"speed", 90f},
                    {"max_nutrition", 30f},
                    {"offspring", 80f},
                }},
                {"emberheart_sigil", new Dictionary<string, float>(){
                    {"damage", 25f},
                    {"mana", 350f},
                    {"health", 550f},
                    {"accuracy", 35f},
                    {"attack_speed", 110f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 95f},
                    {"max_nutrition", 35f},
                    {"offspring", 85f},
                }},
                {"starwoven_charm", new Dictionary<string, float>(){
                    {"damage", 30f},
                    {"mana", 400f},
                    {"health", 600f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.07f},
                    {"range", 7f},
                    {"speed", 100f},
                    {"max_nutrition", 40f},
                    {"offspring", 90f},
                }},
                {"shadowveil_relic", new Dictionary<string, float>(){
                    {"damage", 35f},
                    {"mana", 350f},
                    {"health", 700f},
                    {"accuracy", 35f},
                    {"attack_speed", 115f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 90f},
                    {"max_nutrition", 45f},
                    {"offspring", 80f},
                }},
                {"dawnbreaker_amulet", new Dictionary<string, float>(){
                    {"damage", 40f},
                    {"mana", 400f},
                    {"health", 800f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.08f},
                    {"range", 8f},
                    {"speed", 95f},
                    {"max_nutrition", 50f},
                    {"offspring", 85f},
                }},
                {"frostspire_ward", new Dictionary<string, float>(){
                    {"damage", 50f},
                    {"mana", 450f},
                    {"health", 900f},
                    {"accuracy", 45f},
                    {"attack_speed", 130f},
                    {"critical_chance", 0.09f},
                    {"range", 9f},
                    {"speed", 100f},
                    {"max_nutrition", 55f},
                    {"offspring", 90f},
                }},
                {"sunken_oracle", new Dictionary<string, float>(){
                    {"damage", 60f},
                    {"mana", 500f},
                    {"health", 1000f},
                    {"accuracy", 50f},
                    {"attack_speed", 140f},
                    {"critical_chance", 0.10f},
                    {"range", 10f},
                    {"speed", 105f},
                    {"max_nutrition", 60f},
                    {"offspring", 95f},
                }},
                {"voidtouched_crest", new Dictionary<string, float>(){
                    {"damage", 70f},
                    {"mana", 550f},
                    {"health", 1100f},
                    {"accuracy", 55f},
                    {"attack_speed", 150f},
                    {"critical_chance", 0.11f},
                    {"range", 11f},
                    {"speed", 110f},
                    {"max_nutrition", 65f},
                    {"offspring", 100f},
                }},
                {"talismans", new Dictionary<string, float>(){
                    {"damage", 20f},
                    {"mana", 300f},
                    {"health", 500f},
                    {"accuracy", 30f},
                    {"attack_speed", 100f},
                    {"critical_chance", 0.05f},
                    {"range", 5f},
                    {"speed", 90f},
                    {"max_nutrition", 30f},
                    {"offspring", 80f},
                }},
                {"mystic_barrier_seal", new Dictionary<string, float>(){
                    {"damage", 20f},
                    {"mana", 300f},
                    {"health", 500f},
                    {"accuracy", 30f},
                    {"attack_speed", 100f},
                    {"critical_chance", 0.05f},
                    {"range", 5f},
                    {"speed", 90f},
                    {"max_nutrition", 30f},
                    {"offspring", 80f},
                }},
                {"celestial_binding_seal", new Dictionary<string, float>(){
                    {"damage", 25f},
                    {"mana", 350f},
                    {"health", 550f},
                    {"accuracy", 35f},
                    {"attack_speed", 110f},
                    {"critical_chance", 0.06f},
                    {"range", 6f},
                    {"speed", 95f},
                    {"max_nutrition", 35f},
                    {"offspring", 85f},
                }},
                {"abyssal_lock_seal", new Dictionary<string, float>(){
                    {"damage", 30f},
                    {"mana", 400f},
                    {"health", 600f},
                    {"accuracy", 40f},
                    {"attack_speed", 120f},
                    {"critical_chance", 0.07f},
                    {"range", 7f},
                    {"speed", 100f},
                    {"max_nutrition", 40f},
                    {"offspring", 90f},
                }}
            };
            foreach (string traitId in traitStats.Keys)
            {
                ActorTrait trait = AssetManager.traits.get(traitId);
                if (trait != null)
                {
                    foreach (KeyValuePair<string, float> stat in traitStats[traitId])
                    {
                        trait.base_stats[stat.Key] = stat.Value;
                    }
                }
            }
        }

        private static bool SoulSnatch(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget == null || !pTarget.isActor())
                return false;
            Actor soulUser = pTarget.a;
            Vector3 effectPosition = soulUser.current_position;
            return true;
        }

        private static bool FeelMyAura(BaseSimObject pSelf, WorldTile pTile = null)
        {
            if (pSelf == null || !pSelf.isActor())
                return false;
            if (!Randy.randomChance(0.3f))
                return false;
            Actor trinityUser = pSelf.a;
            float maxRange = 60f;
            Actor target = null;
            float closestDist = float.MaxValue;
            foreach (var other in World.world.units)
            {
                if (other == null || other == trinityUser)
                    continue;
                if (other.kingdom == null || trinityUser.kingdom == null || !trinityUser.kingdom.isEnemy(other.kingdom))
                    continue;
                float dist = Vector2.Distance(trinityUser.current_position, other.current_position);
                if (dist < maxRange && dist < closestDist)
                {
                    closestDist = dist;
                    target = other;
                }
            }
            if (target == null)
                return false;
            Vector3 start = trinityUser.current_position;
            Vector3 end = target.current_position;
            float distToTarget = Vector3.Distance(start, end);
            Vector3 attackVector = Toolbox.getNewPoint(start.x, start.y, end.x, end.y, distToTarget);
            Vector3 startProjectile = Toolbox.getNewPoint(start.x, start.y, end.x, end.y, trinityUser.stats["size"]);
            startProjectile.y += 0.5f;
            float travelTime = distToTarget / TrinityBeam.speed;
            float totalDuration = travelTime + 0.5f;
            World.world.projectiles.spawn(trinityUser, null, "TrinityBeam", startProjectile, attackVector);
            trinityUser.punchTargetAnimation(attackVector, true, false, 50f);
            return true;
        }

        private static bool SpaceTeleportEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }

        private static bool SpaceCollapseEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }

        private static bool WhisperingMoonstoneEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }

        private static bool EmberheartSigilEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }

        private static bool MysticBarrierSealEffect(BaseSimObject pSelf, WorldTile pTile = null)
        {
            return SealEffect(pSelf, pTile, "MysticBarrierSealEffect");
        }

        private static bool CelestialBindingSealEffect(BaseSimObject pSelf, WorldTile pTile = null)
        {
            return SealEffect(pSelf, pTile, "CelestialBindingSealEffect");
        }

        private static bool AbyssalLockSealEffect(BaseSimObject pSelf, WorldTile pTile = null)
        {
            return SealEffect(pSelf, pTile, "AbyssalLockSealEffect");
        }

        private static bool SealEffect(BaseSimObject pSelf, WorldTile pTile, string effectName)
        {
            if (pSelf == null || !pSelf.isActor())
                return false;
            if (!Randy.randomChance(0.3f))
                return false;
            Actor sealUser = pSelf.a;
            float maxRange = 60f;
            Actor target = null;
            float closestDist = float.MaxValue;
            foreach (var other in World.world.units)
            {
                if (other == null || other == sealUser)
                    continue;
                if (other.kingdom == null || sealUser.kingdom == null || !sealUser.kingdom.isEnemy(other.kingdom))
                    continue;
                float dist = Vector2.Distance(sealUser.current_position, other.current_position);
                if (dist < maxRange && dist < closestDist)
                {
                    closestDist = dist;
                    target = other;
                }
            }
            if (target == null)
                return false;
            Vector3 targetPos = target.current_position;
            WorldTile targetTile = World.world.GetTile((int)targetPos.x, (int)targetPos.y);
            if (targetTile == null)
                return false;
            Vector3 effectPosition = targetTile.posV3;
            effectPosition.y += 0.5f;
            EffectsLibrary.spawn("SealLockEffect", targetTile, null, null, 0f, -1f, -1f, null);
            double sealDurationYears = Randy.randomInt(1, 101);
            double currentTime = World.world.getCurWorldTime();
            double reviveTime = currentTime + (sealDurationYears * 360);
            World.world.units.destroyObject(target);
            targetTile._units.Remove(target);
            return true;
        }
    }
}

