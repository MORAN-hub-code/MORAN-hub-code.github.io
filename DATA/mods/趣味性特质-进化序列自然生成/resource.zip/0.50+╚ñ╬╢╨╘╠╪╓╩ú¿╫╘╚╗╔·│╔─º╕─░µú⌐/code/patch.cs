﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using ReflectionUtility;
using UnityEngine;

namespace InterestingTrait.code;
internal class patch
{
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "updateStats"), HarmonyPriority(Priority.First)]
    static void Prefix(Actor __instance, ref bool __state)
    {
        __state = __instance.stats_dirty;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateStats"), HarmonyPriority(Priority.Last)]
    static void Postfix(Actor __instance, bool __state)
    {
        if (!__state)
        {
            return;
        }
        float damageMultiplier = 0.03f;
        float attackSpeedMultiplier = 0.02f;
        float bonus = __instance.data.level * damageMultiplier * __instance.stats["damage"];
        float bonus2 = __instance.data.level * attackSpeedMultiplier;
        __instance.stats["damage"] = __instance.stats["damage"] + bonus;
        __instance.stats["attack_speed"] = __instance.stats["attack_speed"] + bonus2;
    }
    [HarmonyPostfix]
    [HarmonyPatch(typeof(Actor), "updateAge")]
    private static void Postfix_UpdateAge(Actor __instance)
    {
        // 修正：通过 Actor 的公共方法获取年龄（兼容 0.50.4 版本）
        float age = __instance.getAge();
        if (Mathf.FloorToInt(age) != 24) return;

        if (UnityEngine.Random.Range(0, 10) != 0) return;

        if (!__instance.hasTrait("extraordinary1"))
        {
            __instance.addTrait("extraordinary1", false);
            float rand = UnityEngine.Random.value;  // 生成 0~1 的随机数

            if (rand < 0.3f)    // 30% 概率获得 xxx1
            {
                __instance.addTrait("xxx1", false);
            }
            else if (rand < 0.4f)  // 10% 概率获得 xxx2（因为 0.3 ≤ rand < 0.4）
            {
                __instance.addTrait("xxx2", false);
            }
            else if (rand < 0.41f)  // 1% 概率获得 xxx3（因为 0.4 ≤ rand < 0.41）
            {
                __instance.addTrait("xxx3", false);
            }
            else if (rand < 0.411f)  // 0.1% 概率获得 xxx4（因为 0.41 ≤ rand < 0.411）
            {
                __instance.addTrait("xxx4", false);
            }
        }
    }
}