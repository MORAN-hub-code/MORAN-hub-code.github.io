﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterestingTrait.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset interesting = new ActorTraitGroupAsset();
            interesting.id = "interesting";
            interesting.name = "trait_group_interesting";
            interesting.color = "#FFE4C4";
            AssetManager.trait_groups.add(interesting);
        }
    }
}
