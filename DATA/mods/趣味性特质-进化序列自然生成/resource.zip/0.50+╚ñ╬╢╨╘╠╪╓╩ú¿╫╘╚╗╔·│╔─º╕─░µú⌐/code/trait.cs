﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using System.Diagnostics;

namespace InterestingTrait.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = CreateBaseStats();
            
            return trait;
        }

        private static BaseStats CreateBaseStats()
        {
            try 
            {
                BaseStats baseStats = new BaseStats();
                Type baseStatsType = typeof(BaseStats);
                var fields = baseStatsType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                
                foreach (var field in fields)
                {
                    if (field.Name.Contains("dict") || field.Name.Contains("_stats"))
                    {
                        if (field.GetValue(baseStats) == null)
                        {
                            var dictType = typeof(Dictionary<string, float>);
                            var dict = Activator.CreateInstance(dictType);
                            field.SetValue(baseStats, dict);
                        }
                    }
                }
                
                return baseStats;
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Failed to create BaseStats: {ex.Message}");
                return null;
            }
        }

        public static void Init()
        {
            try 
            {
                ActorTrait interesting7 = CreateTrait("interesting7", "trait/interesting7", "interesting"); //狙击镜
                interesting7.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting7.base_stats, S.range, 99f);
                SafeSetStat(interesting7.base_stats, S.area_of_effect, 99f);
                AssetManager.traits.add(interesting7);

                ActorTrait interesting8 = CreateTrait("interesting8", "trait/interesting8", "interesting"); //全知之眼
                interesting8.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting8.base_stats, S.intelligence, 99f);
                SafeSetStat(interesting8.base_stats, S.warfare, 99f);
                SafeSetStat(interesting8.base_stats, S.stewardship, 99f);
                AssetManager.traits.add(interesting8);

                ActorTrait interesting4 = CreateTrait("interesting4", "trait/interesting4", "interesting"); //致命一击
                interesting4.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting4.base_stats, S.damage, 999f);
                SafeSetStat(interesting4.base_stats, S.critical_chance, 0.99f);
                AssetManager.traits.add(interesting4);

                ActorTrait interesting6 = CreateTrait("interesting6", "trait/interesting6", "interesting"); //超速
                interesting6.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting6.base_stats, S.speed, 666f);
                AssetManager.traits.add(interesting6);

                ActorTrait interesting5 = CreateTrait("interesting5", "trait/interesting5", "interesting"); //守护者
                interesting5.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting5.base_stats, S.armor, 99f);
                AssetManager.traits.add(interesting5);

                ActorTrait interesting3_1 = CreateTrait("interesting3_1", "trait/interesting3_1", "interesting");
                interesting3_1.rarity = Rarity.R0_Normal;
                SafeSetStat(interesting3_1.base_stats, S.health, 200f);
                SafeSetStat(interesting3_1.base_stats, S.damage, 20f);
                SafeSetStat(interesting3_1.base_stats, S.stamina, 10f);
                SafeSetStat(interesting3_1.base_stats, S.lifespan, 25f);
                interesting3_1.action_special_effect += (WorldAction)Delegate.Combine(interesting3_1.action_special_effect,
                    new WorldAction(traitAction.interesting3_10_effectAction));
                AssetManager.traits.add(interesting3_1);

                ActorTrait interesting3_2 = CreateTrait("interesting3_2", "trait/interesting3_2", "interesting");
                interesting3_2.rarity = Rarity.R0_Normal;
                SafeSetStat(interesting3_2.base_stats, S.health, 1000f);
                SafeSetStat(interesting3_2.base_stats, S.damage, 40f);
                SafeSetStat(interesting3_2.base_stats, S.stamina, 20f);
                SafeSetStat(interesting3_2.base_stats, S.lifespan, 50f);
                interesting3_2.action_special_effect += (WorldAction)Delegate.Combine(interesting3_2.action_special_effect,
                    new WorldAction(traitAction.interesting3_20_effectAction));
                AssetManager.traits.add(interesting3_2);

                ActorTrait interesting3_3 = CreateTrait("interesting3_3", "trait/interesting3_3", "interesting");
                SafeSetStat(interesting3_3.base_stats, S.health, 2000f);
                SafeSetStat(interesting3_3.base_stats, S.damage, 60f);
                SafeSetStat(interesting3_3.base_stats, S.stamina, 30f);
                SafeSetStat(interesting3_3.base_stats, S.speed, 20f);
                SafeSetStat(interesting3_3.base_stats, S.mass, 60f);
                SafeSetStat(interesting3_3.base_stats, S.armor, 10f);
                SafeSetStat(interesting3_3.base_stats, S.lifespan, 120f);
                interesting3_3.action_special_effect += (WorldAction)Delegate.Combine(interesting3_3.action_special_effect,
                    new WorldAction(traitAction.interesting3_30_effectAction));
                AssetManager.traits.add(interesting3_3);

                ActorTrait interesting3_4 = CreateTrait("interesting3_4", "trait/interesting3_4", "interesting");
                SafeSetStat(interesting3_4.base_stats, S.health, 4000f);
                SafeSetStat(interesting3_4.base_stats, S.damage, 100f);
                SafeSetStat(interesting3_4.base_stats, S.stamina, 50f);
                SafeSetStat(interesting3_4.base_stats, S.speed, 25f);
                SafeSetStat(interesting3_4.base_stats, S.mass, 100f);
                SafeSetStat(interesting3_4.base_stats, S.armor, 20f);
                SafeSetStat(interesting3_4.base_stats, S.lifespan, 220f);
                interesting3_4.action_special_effect += (WorldAction)Delegate.Combine(interesting3_4.action_special_effect,
                    new WorldAction(traitAction.interesting3_50_effectAction));
                AssetManager.traits.add(interesting3_4);

                ActorTrait interesting3_5 = CreateTrait("interesting3_5", "trait/interesting3_5", "interesting");
                SafeSetStat(interesting3_5.base_stats, S.health, 10000f);
                SafeSetStat(interesting3_5.base_stats, S.damage, 160f);
                SafeSetStat(interesting3_5.base_stats, S.stamina, 80f);
                SafeSetStat(interesting3_5.base_stats, S.speed, 30f);
                SafeSetStat(interesting3_5.base_stats, S.mass, 160f);
                SafeSetStat(interesting3_5.base_stats, S.armor, 30f);
                SafeSetStat(interesting3_5.base_stats, S.lifespan, 500f);
                interesting3_5.action_special_effect += (WorldAction)Delegate.Combine(interesting3_5.action_special_effect,
                    new WorldAction(traitAction.interesting3_80_effectAction));
                AssetManager.traits.add(interesting3_5);

                ActorTrait interesting3_6 = CreateTrait("interesting3_6", "trait/interesting3_6", "interesting");
                interesting3_6.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting3_6.base_stats, S.health, 30000f);
                SafeSetStat(interesting3_6.base_stats, S.damage, 300f);
                SafeSetStat(interesting3_6.base_stats, S.stamina, 100f);
                SafeSetStat(interesting3_6.base_stats, S.speed, 35f);
                SafeSetStat(interesting3_6.base_stats, S.mass, 250f);
                SafeSetStat(interesting3_6.base_stats, S.armor, 40f);
                SafeSetStat(interesting3_6.base_stats, S.lifespan, 900f);
                interesting3_6.action_special_effect += (WorldAction)Delegate.Combine(interesting3_6.action_special_effect,
                    new WorldAction(traitAction.interesting3_100_effectAction));
                AssetManager.traits.add(interesting3_6);

                ActorTrait interesting3_7 = CreateTrait("interesting3_7", "trait/interesting3_7", "interesting");
                interesting3_7.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting3_7.base_stats, S.health, 100000f);
                SafeSetStat(interesting3_7.base_stats, S.damage, 1000f);
                SafeSetStat(interesting3_7.base_stats, S.stamina, 200f);
                SafeSetStat(interesting3_7.base_stats, S.speed, 40f);
                SafeSetStat(interesting3_7.base_stats, S.mass, 300f);
                SafeSetStat(interesting3_7.base_stats, S.armor, 50f);
                SafeSetStat(interesting3_7.base_stats, S.lifespan, 1250f);
                interesting3_7.action_special_effect += (WorldAction)Delegate.Combine(interesting3_7.action_special_effect,
                    new WorldAction(traitAction.interesting3_200_effectAction));
                AssetManager.traits.add(interesting3_7);

                ActorTrait interesting3_8 = CreateTrait("interesting3_8", "trait/interesting3_8", "interesting");
                interesting3_8.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting3_8.base_stats, S.health, 200000f);
                SafeSetStat(interesting3_8.base_stats, S.damage, 2000f);
                SafeSetStat(interesting3_8.base_stats, S.stamina, 300f);
                SafeSetStat(interesting3_8.base_stats, S.speed, 45f);
                SafeSetStat(interesting3_8.base_stats, S.mass, 500f);
                SafeSetStat(interesting3_8.base_stats, S.armor, 60f);
                SafeSetStat(interesting3_8.base_stats, S.lifespan, 1600f);
                interesting3_8.action_special_effect += (WorldAction)Delegate.Combine(interesting3_8.action_special_effect,
                    new WorldAction(traitAction.interesting3_300_effectAction));
                AssetManager.traits.add(interesting3_8);

                ActorTrait interesting3_9 = CreateTrait("interesting3_9", "trait/interesting3_9", "interesting");
                interesting3_9.rarity = Rarity.R3_Legendary;
                SafeSetStat(interesting3_9.base_stats, S.health, 777777f);
                SafeSetStat(interesting3_9.base_stats, S.damage, 7777f);
                SafeSetStat(interesting3_9.base_stats, S.stamina, 388f);
                SafeSetStat(interesting3_9.base_stats, S.speed, 50f);
                SafeSetStat(interesting3_9.base_stats, S.mass, 777f);
                SafeSetStat(interesting3_9.base_stats, S.armor, 70f);
                SafeSetStat(interesting3_9.base_stats, S.lifespan, 2000f);
                interesting3_9.action_special_effect += (WorldAction)Delegate.Combine(interesting3_9.action_special_effect,
                    new WorldAction(traitAction.interesting3_777_effectAction));
                AssetManager.traits.add(interesting3_9);

                ActorTrait interesting3_91 = CreateTrait("interesting3_91", "trait/interesting3_91", "interesting");
                interesting3_91.rarity = Rarity.R3_Legendary;
                SafeSetStat(interesting3_91.base_stats, S.health, 1000000f);
                SafeSetStat(interesting3_91.base_stats, S.damage, 10000f);
                SafeSetStat(interesting3_91.base_stats, S.stamina, 1000f);
                SafeSetStat(interesting3_91.base_stats, S.speed, 60f);
                SafeSetStat(interesting3_91.base_stats, S.mass, 1000f);
                SafeSetStat(interesting3_91.base_stats, S.armor, 80f);
                SafeSetStat(interesting3_91.base_stats, S.lifespan, 8888888f);
                interesting3_91.action_special_effect += (WorldAction)Delegate.Combine(interesting3_91.action_special_effect,
                    new WorldAction(traitAction.interesting3_1000_effectAction));
                AssetManager.traits.add(interesting3_91);

                ActorTrait interesting9 = CreateTrait("interesting9", "trait/interesting9", "interesting"); //稻草人
                SafeSetStat(interesting9.base_stats, S.lifespan, 999f);
                SafeSetStat(interesting9.base_stats, S.health, 9999f);
                SafeSetStat(interesting9.base_stats, S.speed, -999f);
                SafeSetStat(interesting9.base_stats, S.attack_speed, -999f);
                SafeSetStat(interesting9.base_stats, S.damage, -999f);
                SafeSetStat(interesting9.base_stats, S.armor, 999f);
                interesting9.action_special_effect += traitAction.brokenProof; //防火与防冻
                AssetManager.traits.add(interesting9);

                ActorTrait interesting1 = CreateTrait("interesting1", "trait/interesting1", "interesting"); //天命之王
                interesting1.rarity = Rarity.R2_Epic;
                SafeSetStat(interesting1.base_stats, S.diplomacy, 10f);
                SafeSetStat(interesting1.base_stats, S.warfare, 20f);
                SafeSetStat(interesting1.base_stats, S.stewardship, 20f);
                SafeSetStat(interesting1.base_stats, S.cities, 20f);
                AssetManager.traits.add(interesting1);

                ActorTrait interesting2 = CreateTrait("interesting2", "trait/interesting2", "interesting"); //我要打十个！
                SafeSetStat(interesting2.base_stats, S.targets, 10f);
                AssetManager.traits.add(interesting2);

                ActorTrait Lifeleaves1 = CreateTrait("Lifeleaves1", "trait/Lifeleaves1", "interesting"); //生命之叶-十寿叶
                SafeSetStat(Lifeleaves1.base_stats, S.lifespan, 50f);
                AssetManager.traits.add(Lifeleaves1);

                ActorTrait Lifeleaves2 = CreateTrait("Lifeleaves2", "trait/Lifeleaves2", "interesting"); //生命之叶-百寿叶
                Lifeleaves2.rarity = Rarity.R2_Epic;
                SafeSetStat(Lifeleaves2.base_stats, S.lifespan, 150f);
                AssetManager.traits.add(Lifeleaves2);

                ActorTrait Lifeleaves3 = CreateTrait("Lifeleaves3", "trait/Lifeleaves3", "interesting"); //生命之叶-千寿叶
                Lifeleaves3.rarity = Rarity.R3_Legendary;
                SafeSetStat(Lifeleaves3.base_stats, S.lifespan, 888f);
                AssetManager.traits.add(Lifeleaves3);

                ActorTrait bomb3 = CreateTrait("bomb3", "trait/bomb3", "interesting"); //湮灭之力
                bomb3.rarity = Rarity.R3_Legendary;
                SafeSetStat(bomb3.base_stats, S.damage, 100f);
                SafeSetStat(bomb3.base_stats, S.critical_chance, 0.3f);
                bomb3.action_attack_target += traitAction.bomb3_attackAction; //湮灭之力的攻击效果
                AssetManager.traits.add(bomb3);

                ActorTrait bomb2 = CreateTrait("bomb2", "trait/bomb2", "interesting"); //大蘑菇云!
                bomb2.rarity = Rarity.R3_Legendary;
                SafeSetStat(bomb2.base_stats, S.damage, 100f);
                SafeSetStat(bomb2.base_stats, S.critical_chance, 0.3f);
                bomb2.action_attack_target += traitAction.bomb2_attackAction; //大蘑菇云的攻击效果
                AssetManager.traits.add(bomb2);

                ActorTrait bomb1 = CreateTrait("bomb1", "trait/bomb1", "interesting"); //流星坠落
                bomb1.rarity = Rarity.R3_Legendary;
                SafeSetStat(bomb1.base_stats, S.damage, 100f);
                SafeSetStat(bomb1.base_stats, S.critical_chance, 0.3f);
                bomb1.action_attack_target += traitAction.bomb1_attackAction; //流星坠落的攻击效果
                AssetManager.traits.add(bomb1);

                ActorTrait bomb4 = CreateTrait("bomb4", "trait/bomb4", "interesting"); //烈燚冲击
                bomb4.rarity = Rarity.R3_Legendary;
                SafeSetStat(bomb4.base_stats, S.damage, 100f);
                SafeSetStat(bomb4.base_stats, S.critical_chance, 0.3f);
                bomb4.action_attack_target += traitAction.bomb4_attackAction; //烈燚冲击的攻击效果
                AssetManager.traits.add(bomb4);

                ActorTrait element0 = CreateTrait("element0", "trait/element0", "interesting");//炽焰旅者
                element0.rarity = Rarity.R2_Epic;
                SafeSetStat(element0.base_stats, S.damage, 80f);
                SafeSetStat(element0.base_stats, S.range, 5f);
                SafeSetStat(element0.base_stats, S.area_of_effect, 20f);
                SafeSetStat(element0.base_stats, S.targets, 10f);
                element0.action_special_effect += traitAction.brokenProof; //防火与防冻
                element0.action_attack_target += traitAction.element0_attackAction; //炽焰旅者的攻击效果
                AssetManager.traits.add(element0);

                ActorTrait element1 = CreateTrait("element1", "trait/element1", "interesting"); //霜月行者
                element1.rarity = Rarity.R2_Epic;
                SafeSetStat(element1.base_stats, S.damage, 40f);
                SafeSetStat(element1.base_stats, S.range, 5f);
                SafeSetStat(element1.base_stats, S.area_of_effect, 20f);
                SafeSetStat(element1.base_stats, S.targets, 10f);
                element1.action_special_effect += traitAction.brokenProof; //防火与防冻
                element1.action_attack_target += traitAction.element1_attackAction; //霜月行者的攻击效果
                AssetManager.traits.add(element1);

                ActorTrait element3 = CreateTrait("element3", "trait/element3", "interesting"); //天罡雷使
                element3.rarity = Rarity.R2_Epic;
                SafeSetStat(element3.base_stats, S.damage, 40f);
                SafeSetStat(element3.base_stats, S.range, 5f);
                SafeSetStat(element3.base_stats, S.area_of_effect, 20f);
                SafeSetStat(element3.base_stats, S.targets, 10f);
                element3.action_special_effect += traitAction.brokenProof; //防火与防冻
                element3.action_attack_target += traitAction.element3_attackAction; //天罡雷使的攻击效果
                AssetManager.traits.add(element3);

                ActorTrait element4 = CreateTrait("element4", "trait/element4", "interesting"); //原力者
                element4.rarity = Rarity.R2_Epic;
                SafeSetStat(element4.base_stats, S.damage, 40f);
                SafeSetStat(element4.base_stats, S.range, 5f);
                SafeSetStat(element4.base_stats, S.area_of_effect, 20f);
                SafeSetStat(element4.base_stats, S.targets, 10f);
                element4.action_special_effect += traitAction.brokenProof; //防火与防冻
                element4.action_attack_target += (AttackAction)Delegate.Combine(element4.action_attack_target,
                new AttackAction(traitAction.superforce)); //原力者的攻击效果
                AssetManager.traits.add(element4);

                ActorTrait extraordinary1 = CreateTrait("extraordinary1", "trait/extraordinary1", "interesting"); //进化序列
                extraordinary1.rarity = Rarity.R3_Legendary;
                SafeSetStat(extraordinary1.base_stats, S.multiplier_speed, 0.5f);
                extraordinary1.action_special_effect = traitAction.extraordinary1_effectAction;
                AssetManager.traits.add(extraordinary1);

                ActorTrait xxx1 = CreateTrait("xxx1", "trait/xxx1", "interesting"); //进化序列
                xxx1.rarity = Rarity.R3_Legendary;
                xxx1.action_special_effect = traitAction.x1_effectAction;
                AssetManager.traits.add(xxx1);

                ActorTrait xxx2 = CreateTrait("xxx2", "trait/xxx2", "interesting"); //进化序列
                xxx2.rarity = Rarity.R3_Legendary;
                xxx2.action_special_effect = traitAction.x2_effectAction;
                AssetManager.traits.add(xxx2);

                ActorTrait xxx3 = CreateTrait("xxx3", "trait/xxx3", "interesting"); //进化序列
                xxx3.rarity = Rarity.R3_Legendary;
                xxx3.action_special_effect = traitAction.x3_effectAction;
                AssetManager.traits.add(xxx3);

                ActorTrait xxx4 = CreateTrait("xxx4", "trait/xxx4", "interesting"); //进化序列
                xxx4.rarity = Rarity.R3_Legendary;
                xxx4.action_special_effect = traitAction.x4_effectAction;
                AssetManager.traits.add(xxx4);

                ActorTrait extraordinary2 = CreateTrait("extraordinary2", "trait/extraordinary2", "interesting"); //时问就是金钱
                extraordinary2.rarity = Rarity.R3_Legendary;
                extraordinary2.action_special_effect = traitAction.extraordinary2_effectAction;
                AssetManager.traits.add(extraordinary2);

                ActorTrait extraordinary5 = CreateTrait("extraordinary5", "trait/extraordinary5", "interesting"); //不朽不灭
                extraordinary5.rarity = Rarity.R3_Legendary;
                SafeSetStat(extraordinary5.base_stats, S.lifespan, float.PositiveInfinity);
                extraordinary5.action_death += traitAction.extraordinary5_deathAction; //不朽不灭的无限重生效果
                AssetManager.traits.add(extraordinary5);

                ActorTrait extraordinary6 = CreateTrait("extraordinary6", "trait/extraordinary6", "interesting"); //不灭之心
                extraordinary6.rarity = Rarity.R3_Legendary;
                extraordinary6.action_death += traitAction.extraordinary6_deathAction; //不灭之心的无限重生效果
                AssetManager.traits.add(extraordinary6);

                ActorTrait extraordinary7 = CreateTrait("extraordinary7", "trait/extraordinary7", "interesting"); //一条命
                extraordinary7.rarity = Rarity.R2_Epic;
                extraordinary7.action_death += traitAction.extraordinary7_deathAction; //一条命的重生效果
                AssetManager.traits.add(extraordinary7);

                ActorTrait Lifeleaves4 = CreateTrait("Lifeleaves4", "trait/Lifeleaves4", "interesting"); //以身化众（一级）
                Lifeleaves4.action_death += traitAction.Lifeleaves4; //以身化众（一级）的重生效果
                AssetManager.traits.add(Lifeleaves4);

                ActorTrait Lifeleaves5 = CreateTrait("Lifeleaves5", "trait/Lifeleaves5", "interesting"); //以身化众（二级）
                Lifeleaves5.rarity = Rarity.R2_Epic;
                Lifeleaves5.action_death += traitAction.Lifeleaves5; //以身化众（二级）的重生效果
                AssetManager.traits.add(Lifeleaves5);

                ActorTrait Lifeleaves6 = CreateTrait("Lifeleaves6", "trait/Lifeleaves6", "interesting"); //以身化众（三级）
                Lifeleaves6.rarity = Rarity.R3_Legendary;
                Lifeleaves6.action_death += traitAction.Lifeleaves6; //以身化众（三级）的重生效果
                AssetManager.traits.add(Lifeleaves6);

                ActorTrait extraordinary9 = CreateTrait("extraordinary9", "trait/extraordinary9", "special"); //众身之一
                AssetManager.traits.add(extraordinary9);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Error in traits initialization: {ex.Message}");
            }
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            try 
            {
                if (baseStats == null)
                {
                    UnityEngine.Debug.LogError($"BaseStats is null when trying to set {statKey}");
                    return;
                }
                Type baseStatsType = baseStats.GetType();
                var method = baseStatsType.GetMethod("set_Item", 
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);
                
                if (method != null)
                {
                    method.Invoke(baseStats, new object[] { statKey, value });
                }
                else 
                {
                    var field = baseStatsType.GetField("_stats", BindingFlags.NonPublic | BindingFlags.Instance);
                    if (field != null)
                    {
                        var dict = field.GetValue(baseStats) as Dictionary<string, float>;
                        if (dict != null)
                        {
                            dict[statKey] = value;
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError($"Could not find method or field to set {statKey}");
                    }
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Error setting stat {statKey}: {ex.Message}");
            }
        }
    }
}