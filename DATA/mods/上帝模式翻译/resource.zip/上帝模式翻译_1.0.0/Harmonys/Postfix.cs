using UnityEngine;

namespace Translation.Harmonys;

public class Postfix
{
    public static void UiDebugButton_Start(UiDebugButton __instance)
    {
        __instance.text.text = LocalizedTextManager.instance._localized_text[__instance.text.text];
    }
}