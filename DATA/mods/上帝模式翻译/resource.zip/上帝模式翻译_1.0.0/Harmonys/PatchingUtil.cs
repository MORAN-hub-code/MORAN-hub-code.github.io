using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Translation.Harmonys;


public class PatchingUtil
{
    /// <summary>
    /// 这是一个用于打补丁的函数
    /// </summary>
    /// <param name="harmony"></param>
    /// <param name="type"></param>
    /// <param name="original"></param>
    /// <param name="patch"></param>
    private static void HarmonyPatching(Harmony harmony, string type, MethodInfo original, MethodInfo patch)
    {
        switch (type)
        {
            case "prefix":
                harmony.Patch(original: original, prefix: new HarmonyMethod(patch));
                break;
            case "postfix":
                harmony.Patch(original: original, postfix: new HarmonyMethod(patch));
                break;
        }
    }

    public static void PostfixPatching(Harmony harmony){
        HarmonyPatching(harmony, "postfix", AccessTools.Method(typeof(UiDebugButton), "Start"),
                AccessTools.Method(typeof(Postfix), "UiDebugButton_Start"));
    }
}