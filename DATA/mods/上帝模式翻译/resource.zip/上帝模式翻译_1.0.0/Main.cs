using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.api;
using NeoModLoader.utils;
using UnityEngine;
using Object = UnityEngine.Object;
using Translation.Harmonys;

namespace Translation;

internal class Main : BasicMod<Main>
{

    public Harmony harmony;

    protected override void OnModLoad()
    {
        harmony = new Harmony("cz");
        PatchingUtil.PostfixPatching(harmony);
    }
}