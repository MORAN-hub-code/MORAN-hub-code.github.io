using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using HarmonyLib;
using NeoModLoader;
using NeoModLoader.api;
using NeoModLoader.utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using NCMS;

namespace 上帝模式翻译
{
    internal class Main : BasicMod<Main>
    {
        public static 上帝模式翻译.Main instance;
        public static List<string> DebugName = new List<string>();
        public static List<UiDebugButton> DebugButton = new List<UiDebugButton>();
        public static Dictionary<string, List<Text>> TitleTexts = new Dictionary<string, List<Text>>();
        public static bool inDebug = false;
        public static bool langDirty = true;
        public static Tooltip toolTip = null;
        protected override void OnModLoad()
        {
          TitleTexts.Add("General\nfor general things", new List<Text>());
          TitleTexts.Add("Overlay Debug Text\nUseful info for finding what's wrong with AI", new List<Text>());
          TitleTexts.Add("Arrows\nShows what civs and units are up to\nSome options can be laggy if many units are visible", new List<Text>());
          TitleTexts.Add("Civ Cheats for debug/testing\ngame mechanics/balance breaking stuff. Some City+ stuff will\n seriously break civ logic for unexpected weird behaviour", new List<Text>());
          TitleTexts.Add("Cursor Highlight\nHighlight zones/regions/chunks", new List<Text>());
          TitleTexts.Add("Paths\nVisualize pathfinding. Very laggy", new List<Text>());
          TitleTexts.Add("Display Map Overlay\nLaggy", new List<Text>());
          TitleTexts.Add("Dirty\nvisualize what just updated", new List<Text>());
          TitleTexts.Add("other stuff\nand things", new List<Text>());
          TitleTexts.Add("Greg\nDon't press this ever. Greg", new List<Text>());
          TitleTexts.Add("Highlight Unit Professions\nWITH PIXELS", new List<Text>());
          TitleTexts.Add("Draw Unit Citizen Jobs\nWITH ICONS", new List<Text>());
          TitleTexts.Add("Highlight Other Stuff\nand things", new List<Text>());
          TitleTexts.Add("Mobile - it won't remove your purchase\nRestart the game to get it back", new List<Text>());
          TitleTexts.Add("System - AKA SUStem\ncould mess your game and crash it. We use it for finding bugs. \nBetter move along", new List<Text>());
          instance = this;
          Harmony.CreateAndPatchAll(typeof(Main));
        }
        void Update()
        {
          if (Config.game_loaded)
          {
            if (inDebug)
            {
              ScrollWindow pWindow = ScrollWindow._current_window;
              if (pWindow != null && pWindow.name == "debug")
              {
                PointerEventData eventData = new PointerEventData(EventSystem.current);
                eventData.position = Input.mousePosition;
                List<RaycastResult> raycastResults = new List<RaycastResult>();
                EventSystem.current.RaycastAll(eventData, raycastResults);
                if (raycastResults.Any())
                {
                  GameObject obj = raycastResults[0].gameObject;
                  if (obj != null && DebugName.Contains(obj.name))
                  {
		                Tooltip.hideTooltip(null, false, "normal");
                    toolTip = Tooltip.getTooltip("normal");
		                toolTip.clear();
		                toolTip.data = new TooltipData{tip_name = obj.name, tip_description =  $"{obj.name} Description", tip_description_2 = $"{obj.name} Description2"};
		                toolTip.showTooltip(obj, "normal");
                  }
                  else if (toolTip != null)
                  {
                    toolTip.hide();
                    toolTip = null;
                  }
                }
                else if (toolTip != null)
                {
                  toolTip.hide();
                  toolTip = null;
                }
              }
              else
              {
                inDebug = false;
              }
            }
            if (langDirty)
            {
              loadLocalizedText();
              langDirty = false;
            }
          }
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(UiDebugButton), "Start")]
        public static void UiDebugButton_Start(UiDebugButton __instance)
        {
          string name = __instance.gameObject.name;
          __instance.text.supportRichText = true;
          string text;
          if (!LocalizedTextManager.instance._localized_text.TryGetValue(name, out text))
          {
            langDirty = true;
            text = name;
          }
          __instance.text.text = text;
          DebugName.Add(name);
          DebugButton.Add(__instance);
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(ScrollWindow), "showWindow", new Type[]{typeof(string), typeof(bool), typeof(bool)})]
		    public static void showWindow(string pWindowID)
		    {
          if (pWindowID == "debug")
          {
            Text[] all = null;
            foreach (string name in TitleTexts.Keys)
            {
              List<Text> texts = TitleTexts[name];
              string text2;
              if (!LocalizedTextManager.instance._localized_text.TryGetValue(name, out text2))
              {
                text2 = name;
              }
              if (texts.Any())
              {
                foreach (Text text in texts)
                {
                  text.text = text2;
                }
              }
              else
              {
                if (all == null)
                {
                  all = Resources.FindObjectsOfTypeAll<Text>();
                }
                foreach (Text text in all)
                {
                  if (text.text == name)
                  {
                    text.supportRichText = true;
                    text.text = text2;
                    texts.Add(text);
                  }
                }
              }
            }
            inDebug = true;
          }
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(LocalizedTextManager), "loadLocalizedText")]
        public static void loadLocalizedText()
        {
          string pLanguage = LocalizedTextManager.instance.language;
          string path = instance.GetLocaleFilesDirectory(instance.GetDeclaration());
          string json = Path.Combine(path, $"{pLanguage}.json");
          if (File.Exists(json))
          {
            Dictionary<string, string> dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(File.ReadAllText(json));
			      foreach (string key in dict.Keys)
			      {
				      LM.Add(pLanguage, key, dict[key]);
			      }
          }
          else foreach (string name in DebugName)
          {
				    LM.Add(pLanguage, name, name);
				    LM.Add(pLanguage, $"{name} Description", "");
				    LM.Add(pLanguage, $"{name} Description2", "");
          }
					LM.ApplyLocale(true);
          foreach (UiDebugButton button in DebugButton)
          {
            button.text.text = LocalizedTextManager.instance._localized_text[button.gameObject.name];
          }
        }
    }
}