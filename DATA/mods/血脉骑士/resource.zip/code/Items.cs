/* 
AUTHOR: MASON SCARBRO
VERSION: 1.0.0
*/
using System;
using UnityEngine;
using ReflectionUtility;
using System.Collections.Generic;
using HarmonyLib;
using NCMS.Utils;

namespace ChivalryWizardingWorld.code
{
    class Items
    {
        public static void Init()
        {
            ItemAsset Heavyhammer = AssetManager.items.clone("Heavyhammer", "$melee");
            Heavyhammer.id = "Heavyhammer";
            Heavyhammer.translation_key = "轰击大地的重锤";
            Heavyhammer.name_templates = List.Of<string>(new string[] { "sword_name" });
            Heavyhammer.base_stats[S.lifespan] += 100f;
            Heavyhammer.base_stats[S.attack_speed] = 15f;
            Heavyhammer.base_stats[S.damage] += 1000f;//伤害
            Heavyhammer.base_stats[S.speed] += 10f;//速度
            Heavyhammer.base_stats[S.health] += 1000;//生命
            Heavyhammer.base_stats[S.accuracy] += 10f;//准确度
            Heavyhammer.base_stats[S.range] = 10;//范围
            Heavyhammer.base_stats[S.armor] = 0f;//护甲
            Heavyhammer.base_stats[S.scale] = 0.0f;//比例尺
            Heavyhammer.base_stats[S.targets] = 10f;//目标
            Heavyhammer.base_stats[S.critical_chance] = 1f;//暴击几率
            Heavyhammer.base_stats[S.critical_damage_multiplier] = 1f;//暴击伤害倍率
            Heavyhammer.base_stats[S.knockback] = 0.5f;//击退
            Heavyhammer.base_stats[S.mass] = 0.0f;//质量
            Heavyhammer.base_stats[S.intelligence] = 0;//智力
            Heavyhammer.base_stats[S.warfare] = 0;//战争
            Heavyhammer.base_stats[S.diplomacy] = 0;//外交
            Heavyhammer.base_stats[S.stewardship] = 10;//管理
            Heavyhammer.base_stats[S.opinion] = 0f;//意见
            Heavyhammer.base_stats[S.loyalty_traits] = 0f;//忠诚度
            Heavyhammer.base_stats[S.cities] = 0;//城市
            Heavyhammer.equipment_value = 3000;
            Heavyhammer.special_effect_interval = 0.1f;
            Heavyhammer.path_slash_animation = "effects/slashes/slash_spear";
            Heavyhammer.quality = Rarity.R3_Legendary;
            Heavyhammer.equipment_type = EquipmentType.Weapon;
            Heavyhammer.name_class = "item_class_weapon";
            Heavyhammer.path_icon = "ui/Icons/icon_Heavyhammer";
            Heavyhammer.action_attack_target += attack_Heavyhammer;
            AssetManager.items.list.AddItem(Heavyhammer);
            Localization.Add("The heavy hammer that bombards the earth", "轰击大地的重锤");
            Localization.Add("The heavy hammer that bombards the earth", "轰击大地的重锤");
            addWeaponsSprite(Heavyhammer.id);


            ItemAsset BurstingMagicSword = AssetManager.items.clone("BurstingMagicSword", "$melee");
            BurstingMagicSword.id = "BurstingMagicSword";
            BurstingMagicSword.translation_key = "爆裂魔剑";
            BurstingMagicSword.name_templates = List.Of<string>(new string[] { "sword_name" });
            BurstingMagicSword.base_stats[S.lifespan] += 100f;
            BurstingMagicSword.base_stats[S.attack_speed] = 1f;
            BurstingMagicSword.base_stats[S.damage] += 1000f;
            BurstingMagicSword.base_stats[S.speed] = 10f;
            BurstingMagicSword.base_stats[S.health] += 1000f;
            BurstingMagicSword.base_stats[S.accuracy] = 10f;
            BurstingMagicSword.base_stats[S.range] = 10;
            BurstingMagicSword.base_stats[S.armor] = 0;
            BurstingMagicSword.base_stats[S.scale] = 0.0f;
            BurstingMagicSword.base_stats[S.targets] = 10f;
            BurstingMagicSword.base_stats[S.critical_chance] = 1f;
            BurstingMagicSword.base_stats[S.critical_damage_multiplier] = 1f;
            BurstingMagicSword.base_stats[S.knockback] = 0.5f;
            BurstingMagicSword.base_stats[S.mass] = 0.0f;
            BurstingMagicSword.base_stats[S.intelligence] = 0;
            BurstingMagicSword.base_stats[S.warfare] = 10;
            BurstingMagicSword.base_stats[S.diplomacy] = 0;
            BurstingMagicSword.base_stats[S.stewardship] = 0;
            BurstingMagicSword.base_stats[S.opinion] = 0f;
            BurstingMagicSword.base_stats[S.loyalty_traits] = 0f;
            BurstingMagicSword.base_stats[S.cities] = 0;
            BurstingMagicSword.equipment_value = 3000;
            BurstingMagicSword.path_slash_animation = "effects/slashes/slash_spear";
            BurstingMagicSword.quality = Rarity.R3_Legendary;
            BurstingMagicSword.equipment_type = EquipmentType.Weapon;
            BurstingMagicSword.name_class = "item_class_weapon";
            BurstingMagicSword.path_icon = "ui/Icons/icon_BurstingMagicSword";
            BurstingMagicSword.action_attack_target += attack_BurstingMagicSword;
            Localization.Add("Bursting Magic Sword", "爆裂魔剑");
            Localization.Add("Bursting Magic Sword", "爆裂魔剑"); ///idk
            addWeaponsSprite(BurstingMagicSword.id);

            ItemAsset FlameBattleAxe = AssetManager.items.clone("FlameBattleAxe", "$melee");
            FlameBattleAxe.id = "FlameBattleAxe";
            FlameBattleAxe.translation_key = "烈焰战斧";
            FlameBattleAxe.name_templates = List.Of<string>(new string[] { "sword_name" });
            FlameBattleAxe.base_stats[S.lifespan] += 100f;
            FlameBattleAxe.base_stats[S.attack_speed] = 15f;
            FlameBattleAxe.base_stats[S.damage] += 1000f;//伤害
            FlameBattleAxe.base_stats[S.speed] += 10f;//速度
            FlameBattleAxe.base_stats[S.health] += 1000;//生命
            FlameBattleAxe.base_stats[S.accuracy] += 10f;//准确度
            FlameBattleAxe.base_stats[S.range] = 10;//范围
            FlameBattleAxe.base_stats[S.armor] = 0f;//护甲
            FlameBattleAxe.base_stats[S.scale] = 0.0f;//比例尺
            FlameBattleAxe.base_stats[S.targets] = 10f;//目标
            FlameBattleAxe.base_stats[S.critical_chance] = 1f;//暴击几率
            FlameBattleAxe.base_stats[S.critical_damage_multiplier] = 1f;//暴击伤害倍率
            FlameBattleAxe.base_stats[S.knockback] = 0.5f;//击退
            FlameBattleAxe.base_stats[S.mass] = 0.0f;//质量
            FlameBattleAxe.base_stats[S.intelligence] = 0;//智力
            FlameBattleAxe.base_stats[S.warfare] = 0;//战争
            FlameBattleAxe.base_stats[S.diplomacy] = 0;//外交
            FlameBattleAxe.base_stats[S.stewardship] = 10;//管理
            FlameBattleAxe.base_stats[S.opinion] = 0f;//意见
            FlameBattleAxe.base_stats[S.loyalty_traits] = 0f;//忠诚度
            FlameBattleAxe.base_stats[S.cities] = 0;//城市
            FlameBattleAxe.equipment_value = 3000;
            FlameBattleAxe.path_slash_animation = "effects/slashes/darkSlash";
            FlameBattleAxe.quality = Rarity.R3_Legendary;
            FlameBattleAxe.equipment_type = EquipmentType.Weapon;
            FlameBattleAxe.name_class = "item_class_weapon";
            FlameBattleAxe.path_icon = "ui/Icons/icon_FlameBattleAxe";
            FlameBattleAxe.action_attack_target += attack_FlameBattleAxe;
            Localization.Add("Flame Battle Axe", "烈焰战斧");
            Localization.Add("Flame Battle Axe", "烈焰战斧");
            addWeaponsSprite(FlameBattleAxe.id);

            ItemAsset Thunderouslongbow = AssetManager.items.clone("Thunderouslongbow", "$range");
            Thunderouslongbow.id = "Thunderouslongbow";
            Thunderouslongbow.translation_key = "雷鸣长弓";
            Thunderouslongbow.name_templates = List.Of<string>(new string[] { "sword_name" });
            Thunderouslongbow.base_stats[S.lifespan] += 100f;
            Thunderouslongbow.base_stats[S.attack_speed] = 15f;
            Thunderouslongbow.base_stats[S.damage] += 1000f;//伤害
            Thunderouslongbow.base_stats[S.speed] += 10f;//速度
            Thunderouslongbow.base_stats[S.health] += 1000;//生命
            Thunderouslongbow.base_stats[S.accuracy] += 100f;//准确度
            Thunderouslongbow.base_stats[S.range] = 100;//范围
            Thunderouslongbow.base_stats[S.armor] = 0f;//护甲
            Thunderouslongbow.base_stats[S.scale] = 0.0f;//比例尺
            Thunderouslongbow.base_stats[S.targets] = 10f;//目标
            Thunderouslongbow.base_stats[S.critical_chance] = 1f;//暴击几率
            Thunderouslongbow.base_stats[S.critical_damage_multiplier] = 1f;//暴击伤害倍率
            Thunderouslongbow.base_stats[S.knockback] = 0.5f;//击退
            Thunderouslongbow.base_stats[S.mass] = 0.0f;//质量
            Thunderouslongbow.base_stats[S.intelligence] = 0;//智力
            Thunderouslongbow.base_stats[S.warfare] = 0;//战争
            Thunderouslongbow.base_stats[S.diplomacy] = 0;//外交
            Thunderouslongbow.base_stats[S.stewardship] = 10;//管理
            Thunderouslongbow.base_stats[S.opinion] = 0f;//意见
            Thunderouslongbow.base_stats[S.loyalty_traits] = 0f;//忠诚度
            Thunderouslongbow.base_stats[S.cities] = 0;//城市
            Thunderouslongbow.equipment_value = 3000;
            Thunderouslongbow.path_slash_animation = "effects/slashes/slash_bow";
            Thunderouslongbow.quality = Rarity.R3_Legendary;
            Thunderouslongbow.equipment_type = EquipmentType.Weapon;
            Thunderouslongbow.attack_type = WeaponType.Range;
            Thunderouslongbow.base_stats[S.projectiles] = 1;
            Thunderouslongbow.base_stats[S.damage_range] = 1f;
            Thunderouslongbow.projectile = "arrow";
            Thunderouslongbow.name_class = "item_class_weapon";
            Thunderouslongbow.path_icon = "ui/Icons/icon_Thunderouslongbow";
            Thunderouslongbow.action_attack_target += attack_Thunderouslongbow;
            Localization.Add("Thunderous longbow", "雷鸣长弓");
            Localization.Add("Thunderous longbow", "雷鸣长弓");
            addWeaponsSprite(Thunderouslongbow.id);
            
            ItemAsset Thelegendarylongbow = AssetManager.items.clone("Thelegendarylongbow", "$range");
            Thelegendarylongbow.id = "Thelegendarylongbow";
            Thelegendarylongbow.translation_key = "传说中的长弓";
            Thelegendarylongbow.name_templates = List.Of<string>(new string[] { "sword_name" });
            Thelegendarylongbow.base_stats[S.lifespan] += 100f;
            Thelegendarylongbow.base_stats[S.attack_speed] = 15f;
            Thelegendarylongbow.base_stats[S.damage] += 10000f;//伤害
            Thelegendarylongbow.base_stats[S.speed] += 100f;//速度
            Thelegendarylongbow.base_stats[S.health] += 10000;//生命
            Thelegendarylongbow.base_stats[S.multiplier_damage] = 50f;//伤害倍率
            Thelegendarylongbow.base_stats[S.multiplier_health] = 50f;//生命值倍率
            Thelegendarylongbow.base_stats[S.accuracy] += 100f;//准确度
            Thelegendarylongbow.base_stats[S.range] = 1000;//范围
            Thelegendarylongbow.base_stats[S.armor] = 100f;//护甲
            Thelegendarylongbow.base_stats[S.scale] = 0.0f;//比例尺
            Thelegendarylongbow.base_stats[S.targets] = 100f;//目标
            Thelegendarylongbow.base_stats[S.critical_chance] = 10f;//暴击几率
            Thelegendarylongbow.base_stats[S.critical_damage_multiplier] = 10f;//暴击伤害倍率
            Thelegendarylongbow.base_stats[S.knockback] = 5f;//击退
            Thelegendarylongbow.base_stats[S.mass] = 0.0f;//质量
            Thelegendarylongbow.base_stats[S.intelligence] = 0;//智力
            Thelegendarylongbow.base_stats[S.warfare] = 0;//战争
            Thelegendarylongbow.base_stats[S.diplomacy] = 0;//外交
            Thelegendarylongbow.base_stats[S.stewardship] = 10;//管理
            Thelegendarylongbow.base_stats[S.opinion] = 0f;//意见
            Thelegendarylongbow.base_stats[S.loyalty_traits] = 0f;//忠诚度
            Thelegendarylongbow.base_stats[S.cities] = 0;//城市
            Thelegendarylongbow.equipment_value = 10000;
            Thelegendarylongbow.path_slash_animation = "effects/slashes/darkSlash";
            Thelegendarylongbow.quality = Rarity.R3_Legendary;
            Thelegendarylongbow.equipment_type = EquipmentType.Weapon;
            Thelegendarylongbow.attack_type = WeaponType.Range;
            Thelegendarylongbow.name_class = "item_class_weapon";
            Thelegendarylongbow.path_icon = "ui/Icons/icon_Thelegendarylongbow";
            Thelegendarylongbow.base_stats[S.projectiles] = 1f;
            Thelegendarylongbow.base_stats[S.damage_range] = 1f;
            Thelegendarylongbow.projectile = "arrow";
            Thelegendarylongbow.action_attack_target += attack_Thelegendarylongbow;
            Localization.Add("The legendary longbow", "传说中的长弓");
            Localization.Add("The legendary longbow", "传说中的长弓");
            addWeaponsSprite(Thelegendarylongbow.id);
            
            ItemAsset TheKnightsOath = AssetManager.items.clone("TheKnightsOath", "$amulet");
            TheKnightsOath.id = "TheKnightsOath";
            TheKnightsOath.translation_key = "骑士之誓";
            TheKnightsOath.name_templates = List.Of<string>(new string[] { "amulet_name" });
            TheKnightsOath.base_stats[S.lifespan] += 100f;
            TheKnightsOath.base_stats[S.attack_speed] = 0f;
            TheKnightsOath.base_stats[S.damage] += 0f;//伤害
            TheKnightsOath.base_stats[S.speed] += 0f;//速度
            TheKnightsOath.base_stats[S.health] += 0;//生命
            TheKnightsOath.base_stats[S.accuracy] += 0f;//准确度
            TheKnightsOath.base_stats[S.range] = 0;//范围
            TheKnightsOath.base_stats[S.armor] = 0f;//护甲
            TheKnightsOath.base_stats[S.scale] = 0.0f;//比例尺
            TheKnightsOath.base_stats[S.targets] = 0f;//目标
            TheKnightsOath.base_stats[S.critical_chance] = 40f;//暴击几率
            TheKnightsOath.base_stats[S.critical_damage_multiplier] = 40f;//暴击伤害倍率
            TheKnightsOath.base_stats[S.knockback] = 0f;//击退
            TheKnightsOath.base_stats[S.mass] = 0.0f;//质量
            TheKnightsOath.base_stats[S.intelligence] = 0;//智力
            TheKnightsOath.base_stats[S.warfare] = 0;//战争
            TheKnightsOath.base_stats[S.diplomacy] = 0;//外交
            TheKnightsOath.base_stats[S.stewardship] = 10;//管理
            TheKnightsOath.base_stats[S.opinion] = 0f;//意见
            TheKnightsOath.base_stats[S.loyalty_traits] = 0f;//忠诚度
            TheKnightsOath.base_stats[S.cities] = 0;//城市
            TheKnightsOath.equipment_value = 3000;
            TheKnightsOath.quality = Rarity.R3_Legendary;
            TheKnightsOath.equipment_type = EquipmentType.Amulet;
            TheKnightsOath.name_class = "item_class_amulet";
            TheKnightsOath.path_icon = "ui/Icons/icon_TheKnightsOath";
            Localization.Add("TheKnightsOath_description", "骑士之誓");
            Localization.Add("TheKnightsOath", "骑士之誓");

            ItemAsset Theknightshelmet = AssetManager.items.clone("Theknightshelmet", "$helmet");
            Theknightshelmet.id = "Theknightshelmet";
            Theknightshelmet.translation_key = "骑士之盔";
            Theknightshelmet.name_templates = List.Of<string>(new string[] { "helmet_name" });
            Theknightshelmet.equipment_value = 3300;
            Theknightshelmet.base_stats[S.damage] += 0f;//伤害
            Theknightshelmet.base_stats[S.speed] += 0f;//速度
            Theknightshelmet.base_stats[S.health] += 4000;//生命
            Theknightshelmet.base_stats[S.accuracy] += 0f;//准确度
            Theknightshelmet.base_stats[S.range] = 0;//范围
            Theknightshelmet.base_stats[S.armor] = 40f;//护甲
            Theknightshelmet.base_stats[S.scale] = 0.0f;//比例尺
            Theknightshelmet.base_stats[S.targets] = 0f;//目标
            Theknightshelmet.base_stats[S.critical_chance] = 0f;//暴击几率
            Theknightshelmet.base_stats[S.critical_damage_multiplier] = 0f;//暴击伤害倍率
            Theknightshelmet.base_stats[S.knockback] = 0f;//击退
            Theknightshelmet.base_stats[S.mass] = 0.0f;//质量
            Theknightshelmet.base_stats[S.intelligence] = 0;//智力
            Theknightshelmet.base_stats[S.warfare] = 0;//战争
            Theknightshelmet.base_stats[S.diplomacy] = 0;//外交
            Theknightshelmet.base_stats[S.stewardship] = 10;//管理
            Theknightshelmet.base_stats[S.opinion] = 0f;//意见
            Theknightshelmet.base_stats[S.loyalty_traits] = 0f;//忠诚度
            Theknightshelmet.base_stats[S.cities] = 0;//城市
            Theknightshelmet.quality = Rarity.R3_Legendary;
            Theknightshelmet.equipment_type = EquipmentType.Helmet;
            Theknightshelmet.name_class = "item_class_helmet";
            Theknightshelmet.path_icon = "ui/Icons/icon_Theknightshelmet";
            AssetManager.items.list.AddItem(Theknightshelmet);
            Localization.Add("Theknightshelmet", "骑士之盔");
            Localization.Add("Theknightshelmet", "骑士之盔");

            ItemAsset ThearmorofaKnight = AssetManager.items.clone("ThearmorofaKnight", "$armor");
            ThearmorofaKnight.id = "ThearmorofaKnight";
            ThearmorofaKnight.translation_key = "骑士之铠";
            ThearmorofaKnight.name_templates = List.Of(new string[] { "armor_name" });
            ThearmorofaKnight.base_stats[S.damage] += 0f;//伤害
            ThearmorofaKnight.base_stats[S.speed] += 0f;//速度
            ThearmorofaKnight.base_stats[S.health] += 4000;//生命
            ThearmorofaKnight.base_stats[S.accuracy] += 0f;//准确度
            ThearmorofaKnight.base_stats[S.range] = 0;//范围
            ThearmorofaKnight.base_stats[S.armor] = 40f;//护甲
            ThearmorofaKnight.base_stats[S.scale] = 0.0f;//比例尺
            ThearmorofaKnight.base_stats[S.targets] = 0f;//目标
            ThearmorofaKnight.base_stats[S.critical_chance] = 0f;//暴击几率
            ThearmorofaKnight.base_stats[S.critical_damage_multiplier] = 0f;//暴击伤害倍率
            ThearmorofaKnight.base_stats[S.knockback] = 0f;//击退
            ThearmorofaKnight.base_stats[S.mass] = 0.0f;//质量
            ThearmorofaKnight.base_stats[S.intelligence] = 0;//智力
            ThearmorofaKnight.base_stats[S.warfare] = 0;//战争
            ThearmorofaKnight.base_stats[S.diplomacy] = 0;//外交
            ThearmorofaKnight.base_stats[S.stewardship] = 10;//管理
            ThearmorofaKnight.base_stats[S.opinion] = 0f;//意见
            ThearmorofaKnight.base_stats[S.loyalty_traits] = 0f;//忠诚度
            ThearmorofaKnight.base_stats[S.cities] = 0;//城市
            ThearmorofaKnight.equipment_value = 3000;
            ThearmorofaKnight.quality = Rarity.R3_Legendary;
            ThearmorofaKnight.equipment_type = EquipmentType.Armor;
            ThearmorofaKnight.name_class = "item_class_armor";
            ThearmorofaKnight.path_icon = "ui/Icons/icon_ThearmorofaKnight";
            AssetManager.items.list.AddItem(ThearmorofaKnight);
            Localization.Add("ThearmorofaKnight_description", "骑士之铠");
            Localization.Add("ThearmorofaKnight", "骑士之铠");
            addWeaponsSprite(ThearmorofaKnight.id);

            ItemAsset Goodandevil = AssetManager.items.clone("Goodandevil", "$melee");
            Goodandevil.id = "Goodandevil";
            Goodandevil.translation_key = "划分善恶的长枪";
            Goodandevil.name_templates = List.Of<string>(new string[] { "sword_name" });
            Goodandevil.base_stats[S.lifespan] += 100f;
            Goodandevil.base_stats[S.attack_speed] = 15f;
            Goodandevil.base_stats[S.damage] += 1000f;//伤害
            Goodandevil.base_stats[S.speed] += 10f;//速度
            Goodandevil.base_stats[S.health] += 1000;//生命
            Goodandevil.base_stats[S.accuracy] += 100f;//准确度
            Goodandevil.base_stats[S.range] = 100;//范围
            Goodandevil.base_stats[S.armor] = 0f;//护甲
            Goodandevil.base_stats[S.scale] = 0.0f;//比例尺
            Goodandevil.base_stats[S.targets] = 10f;//目标
            Goodandevil.base_stats[S.critical_chance] = 1f;//暴击几率
            Goodandevil.base_stats[S.critical_damage_multiplier] = 1f;//暴击伤害倍率
            Goodandevil.base_stats[S.knockback] = 0.5f;//击退
            Goodandevil.base_stats[S.mass] = 0.0f;//质量
            Goodandevil.base_stats[S.intelligence] = 0;//智力
            Goodandevil.base_stats[S.warfare] = 0;//战争
            Goodandevil.base_stats[S.diplomacy] = 0;//外交
            Goodandevil.base_stats[S.stewardship] = 10;//管理
            Goodandevil.base_stats[S.opinion] = 0f;//意见
            Goodandevil.base_stats[S.loyalty_traits] = 0f;//忠诚度
            Goodandevil.base_stats[S.cities] = 0;//城市
            Goodandevil.equipment_value = 3000;
            Goodandevil.path_slash_animation = "effects/slashes/slash_axe";
            Goodandevil.quality = Rarity.R3_Legendary;
            Goodandevil.equipment_type = EquipmentType.Weapon;
            Goodandevil.name_class = "item_class_weapon";
            Goodandevil.path_icon = "ui/Icons/icon_Goodandevil";
            Goodandevil.action_special_effect += (WorldAction)Delegate.Combine(Goodandevil.action_special_effect,
                new WorldAction(Goodandevil_Regen));
            AssetManager.items.list.AddItem(Goodandevil);
            Localization.Add("The long spear for distinguishing good from evil", "划分善恶的长枪");
            Localization.Add("The long spear for distinguishing good from evil", "划分善恶的长枪");
            addWeaponsSprite(Goodandevil.id);
        }

        public static bool attack_Heavyhammer(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null) 
            {
                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                }
            }

            return false;
        }

        public static bool attack_BurstingMagicSword(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawnAtTileRandomScale("fx_explosion_small", pTile, 0.1f, 0.15f);
                }
            }

            return false;
        }

        public static bool attack_FlameBattleAxe(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castFire(null, pTarget, null);
                }
            }

            return false;
        }
        public static bool attack_Thunderouslongbow(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(0.1f))
                {
                    MapBox.spawnLightningMedium(pTile, 1f);
                }
            }

            return false;
        }

        public static bool attack_Thelegendarylongbow(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(0.1f))
                {
                    MapBox.spawnLightningMedium(pTile, 5f);
                }
            }

            return false;
        }
        
        public static bool Goodandevil_Regen(BaseSimObject pTarget, WorldTile pTile = null)
	    {
		    if (Randy.randomChance(1f))
		    {
			    foreach (Actor tActor in Finder.getUnitsFromChunk(pTile, 4, 4f, false))
			    {
                    if (tActor.kingdom == pTarget.kingdom)
                    {
				        if (!tActor.hasMaxHealth())
				        {
					        tActor.restoreHealth(50);
					        tActor.spawnParticle(Toolbox.color_heal);
				        }
                    }

                    if (tActor.kingdom != pTarget.kingdom)
                    {
				        if (!tActor.hasMaxHealth())
				        {
					        ActionLibrary.castCurses(null, pTarget, null);
				        }
                    }
			    }
		    }
		    return true;
	    }

        static void addWeaponsSprite(string id)
        {
            var dictItems = ActorAnimationLoader._dict_items;
            var sprite = Resources.Load<Sprite>("weapons/"+id);
            dictItems.Add("w_"+id, new List<Sprite>() { sprite });
        }
    }
}
