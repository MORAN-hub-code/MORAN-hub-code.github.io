﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool ascetic1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.侍从
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            
            if (a.GetKnight() <= 9.99)
            {
                return false;
            }
            string[] forbiddenTraits =
            {
                 "ascetic2", "ascetic3", "ascetic4", "ascetic5", "ascetic6", "ascetic7","ascetic8", "ascetic9"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait("特质", "ascetic1", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
                new string[] { "dash", "block", "dodge", "backstep", "deflect_projectile" });


            return true;
        }

        public static bool ascetic2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.侍从
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            
            if (a.GetKnight() <= 19.99)
            {
                return false;
            }
            string[] forbiddenTraits =
            {
                 "ascetic2", "ascetic3", "ascetic4", "ascetic5", "ascetic6", "ascetic7","ascetic8", "ascetic9"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait("特质", "ascetic2", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "ascetic1" },
                new string[] { "特质" });


            return true;
        }

        public static bool ascetic3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            if (a.GetKnight() <= 49.99)
            {
                return false;
            }

            a.ChangeKnight(-12);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.9;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.6;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }


            upTrait("特质", "ascetic3", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic2" },
                new string[] {  });

            return true;
        }
        public static bool ascetic4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            
            if (a.GetKnight() <= 99.99)
            {
                return false;
            }

            a.ChangeKnight(-25);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.9;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.5;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            string[] additionalTraits =
                { "skill1", "skill2", "skill3", "skill4" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic4", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic3" },
                new string[] { randomTrait });

            return true;
        }
        public static bool ascetic5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.高级骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;

            if (a.GetKnight() <= 199.99)
            {
                return false;
            }

            a.ChangeKnight(-50);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.4;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            string[] additionalTraits =
                { "arms1", "arms2", "arms3", "arms4", "arms5", "arms6", "arms7", "arms8" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic5", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic4" },
                new string[] { randomTrait });

            return true;
        }
        public static bool ascetic6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;

            if (a.GetKnight() <= 499.99)
            {
                return false;
            }

            a.ChangeKnight(-125);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.3;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }

            string[] additionalTraits =
                { "inherit1", "inherit2", "inherit3", "inherit4", "inherit5", "inherit6", "inherit7", "inherit8", "training9", "training10" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic6", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic5" },
                new string[] { randomTrait });

            return true;
        }
        public static bool ascetic7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.传说骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;

            if (a.GetKnight() <= 999.99)
            {
                return false;
            }
            a.ChangeKnight(-250);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.2;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            string[] additionalTraits =
                { "bloodline1", "bloodline2", "bloodline3", "bloodline4", "bloodline5", "bloodline6", "bloodline7", "bloodline8", "bloodline9", "bloodline10", "bloodline11" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic7", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic6" },
                new string[] { "ascetic6+", randomTrait });

            return true;
        }

        public static bool ascetic8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.传说骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;

            if (a.GetKnight() <= 1999.99)
            {
                return false;
            }
            a.ChangeKnight(-500);
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.1;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            string actorName = a.getName();
            if (!actorName.Contains("一转神性") && !actorName.Contains("二转神性") && !actorName.Contains("三转神性") && !actorName.Contains("四转神性") && !actorName.Contains("五转神性") && !actorName.Contains("六转神性") && !actorName.Contains("七转神性") && !actorName.Contains("八转神性") && !actorName.Contains("九转神性"))
            {
                a.data.setName("传说中的骑士 " + pTarget.a.getName());
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            a.data.favorite = true;

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade91Tips.Count);
            string tip = grade91Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            string[] additionalTraits =
                { "Legend1" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic8", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic7", "arms1", "arms2", "arms3", "arms4", "arms5" },
                new string[] { randomTrait });

            return true;
        }

        public static bool ascetic9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)//升.神性骑士
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 126)
            {
                upTrait("特质", "ascetic1", a, new string[] { "ascetic7" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 4999.99)
            {
                return false;
            }
            double successRate = 0.1;
            if (a.hasTrait("ascetic9"))
            {
                successRate = 1;
            }
            else if (a.hasTrait("training9"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("training4"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("training3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("training2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("training1"))
            {
                successRate = 0.05;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            a.ChangeKnight(-10000);
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            a.data.favorite = true;

            // 检查名称中是否包含“传说中的骑士”，如果包含则替换为“神性”
            if (currentName.Contains("传说中的骑士 "))
            {
                newName = currentName.Replace("传说中的骑士 ", "一转神性 ");
                a.data.setName(newName);
            } 

            if (currentName.Contains("一转神性 "))
            {
                newName = currentName.Replace("一转神性 ", "二转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("二转神性 "))
            {
                newName = currentName.Replace("二转神性 ", "三转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("三转神性 "))
            {
                newName = currentName.Replace("三转神性 ", "四转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("四转神性 "))
            {
                newName = currentName.Replace("四转神性 ", "五转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("五转神性 "))
            {
                newName = currentName.Replace("五转神性 ", "六转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("六转神性 "))
            {
                newName = currentName.Replace("六转神性 ", "七转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("七转神性 "))
            {
                newName = currentName.Replace("七转神性 ", "八转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("八转神性 "))
            {
                newName = currentName.Replace("八转神性 ", "九转神性 ");
                a.data.setName(newName);
            }

            if (currentName.Contains("九转神性 "))
            {
                newName = currentName.Replace("九转神性 ", "九转神性 ");
                a.data.setName(newName);
            }
            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade92Tips.Count);
            string tip = grade92Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            string[] additionalTraits =
                { "godhead1", "godhead2", "godhead3", "godhead4", "godhead5", "godhead6", "godhead7", "godhead8", "godhead9" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "ascetic9", a, new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "ascetic7", "training1", "training2", "training3", "training8" },
                new string[] { "training8", randomTrait });

            return true;
        }

        private static string GetNewRandomTrait(string[] additionalTraits)
        {
            // 逻辑从 additionalTraits 中随机选择一个特质
            int randomIndex = UnityEngine.Random.Range(0, additionalTraits.Length);
            return additionalTraits[randomIndex];
        }

        // 定义一组升级提示信息
        private static readonly List<string> grade91Tips = new List<string>
        {
            "「自此刻始         汝之呼吸即为风暴         汝之足迹即为雷霆         凡尘战阶至此湮灭        唯余[{0}]的名字悬于法则之壁          ——此非加冕 乃是天地为纯粹力量烙下的刻痕」"
        };

        // 定义一组升级提示信息
        private static readonly List<string> grade92Tips = new List<string>
        {
            "「以烙刻于星穹的永恒誓约为证——        汝等当聆听！第七纪元的暮钟已为悖逆者鸣响         今有承冠者穿越火湖试炼，其魂灵经圣骸沙漏九度淬炼，右臂铭刻受祝者烙印，左瞳倒映湮灭圣所之真貌——         以三重神谕之名宣告         自此刻始，汝即为行走的断罪圣约，是淬火长剑亦是慈悲圣幔，当以铁血践行湮灭之仁慈，以神性重塑尘世法则——         神性骑士[{0}]，于此承接权柄！         凡汝剑锋所指之处，即是新约降世之地！」"
        };

        public static bool ascetic1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)50);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ascetic8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor targetActor = pTarget.a;
            int maxHealth = targetActor.getMaxHealth();
            float healPercent = 0.01f; // 可修改此数值调整回血比例 
            if (targetActor.data.health < maxHealth)
            {
                int healAmount = Mathf.Max(1, Mathf.FloorToInt(maxHealth * healPercent));
                targetActor.data.health = Mathf.Min(maxHealth, targetActor.data.health + healAmount);
                targetActor.spawnParticle(Toolbox.color_heal);
            }
    
            return true;
        }

        public static bool ascetic9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor targetActor = pTarget.a;
            int maxHealth = targetActor.getMaxHealth();
            float healPercent = 0.05f; // 可修改此数值调整回血比例 
            if (targetActor.data.health < maxHealth)
            {
                int healAmount = Mathf.Max(1, Mathf.FloorToInt(maxHealth * healPercent));
                targetActor.data.health = Mathf.Min(maxHealth, targetActor.data.health + healAmount);
                targetActor.spawnParticle(Toolbox.color_heal);
            }
    
            return true;
        }

        public static bool warfare_attack_ascetic8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 每次攻击计算自身指挥值的随机倍数，再减少目标血量
            if (pTarget != null && pTarget.a != null && pTarget.a.data != null && pSelf != null && pSelf.a != null &&
                pSelf.a.stats != null)
            {
                // 指挥值的随机倍数，范围在x到x之间
                float warfareMultiplierMin = 0.5f;
                float warfareMultiplierMax = 0.5f;
                float warfareMultiplier =
                    UnityEngine.Random.Range(warfareMultiplierMin, warfareMultiplierMax);

                float damageBasedOnWarfare = pSelf.a.stats[S.damage] * warfareMultiplier; // 根据指挥计算伤害
                int damageToDeal = Mathf.FloorToInt(damageBasedOnWarfare);                // 将浮点数伤害转换为整数

                pTarget.a.data.health -= damageToDeal; // 减去基于指挥的伤害值
            }

            return true;
        }

        public static bool warfare_attack_ascetic9(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 每次攻击计算自身指挥值的随机倍数，再减少目标血量
            if (pTarget != null && pTarget.a != null && pTarget.a.data != null && pSelf != null && pSelf.a != null &&
                pSelf.a.stats != null)
            {
                // 指挥值的随机倍数，范围在x到x之间
                float warfareMultiplierMin = 1f;
                float warfareMultiplierMax = 1f;
                float warfareMultiplier =
                    UnityEngine.Random.Range(warfareMultiplierMin, warfareMultiplierMax);

                float damageBasedOnWarfare = pSelf.a.stats[S.damage] * warfareMultiplier; // 根据指挥计算伤害
                int damageToDeal = Mathf.FloorToInt(damageBasedOnWarfare);                // 将浮点数伤害转换为整数

                pTarget.a.data.health -= damageToDeal; // 减去基于指挥的伤害值
            }

            return true;
        }

        //战技
        public static bool attack_skill1(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(1f))
                {
                    ActionLibrary.addFrozenEffectOnTarget(null, pTarget, null);
                }
            }

            return false;
        }

        public static bool attack_skill2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(1f))
                {
                    ActionLibrary.castFire(null, pTarget, null);
                }
            }

            return false;
        }

        public static bool attack_skill3(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(1f))
                {
                    MapBox.spawnLightningMedium(pTile, 0.25f);
                }
            }

            return false;
        }

        public static bool attack_skill4(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(800); //二环•生命涌泉
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        //血脉
        public static bool brokenProof0(BaseSimObject pTarget, WorldTile pTile = null)//治愈光环
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("freeze_proof");//防冰
            a.addTrait("immune");//免疫
            a.addTrait("healing_aura");//治愈光环
            a.addTrait("training3");
            return false;
        }

        public static bool brokenProof1(BaseSimObject pTarget, WorldTile pTile = null)//防火
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("training3");
            return false;
        }

        public static bool brokenProof2(BaseSimObject pTarget, WorldTile pTile = null)//防冰
        {
            Actor a = pTarget.a;
            a.addTrait("freeze_proof");//防冰
            a.addTrait("training3");
            return false;
        }

        public static bool brokenProof3(BaseSimObject pTarget, WorldTile pTile = null)//防火，防冰
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("freeze_proof");//防冰
            a.addTrait("immune");//免疫
            a.addTrait("training3");
            return false;
        }

        public static bool brokenProof4(BaseSimObject pTarget, WorldTile pTile = null)//防火，防冰
        {
            Actor a = pTarget.a;
            a.addTrait("immune");//免疫
            a.addTrait("evil");//邪恶
            a.addTrait("training3");
            return false;
        }

        public static bool brokenProof5(BaseSimObject pTarget, WorldTile pTile = null)//治愈光环
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("freeze_proof");//防冰
            a.addTrait("immune");//免疫
            a.addTrait("healing_aura");//治愈光环
            a.addTrait("ascetic9");//神性骑士
            a.addTrait("training4");
            return false;
        }

        public static bool brokenProof6(BaseSimObject pTarget, WorldTile pTile = null)//治愈光环
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("freeze_proof");//防冰
            a.addTrait("immune");//免疫
            a.addTrait("healing_aura");//治愈光环
            a.addTrait("training4");
            a.addTrait("bloodline12");
            a.addTrait("inherit11");
            a.addTrait("function4");
            return false;
        }

        public static bool brokenProof7(BaseSimObject pTarget, WorldTile pTile = null)//治愈光环
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");//防火
            a.addTrait("freeze_proof");//防冰
            a.addTrait("immune");//免疫
            return false;
        }
        
        public static bool attack_bloodline1(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                    ActionLibrary.castShieldOnHimself(null, pSelf, null);
                }
            }

            return false;
        }

        public static bool attack_bloodline2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                     EffectsLibrary.spawn("fx_napalm_flash", pTile, "napalm", null, 0f, -1f, -1f);
                }
            }

            return false;
        }

        public static bool attack_bloodline3(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                    EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
                }
            }

            return false;
        }

        public static bool attack_bloodline4(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                    ActionLibrary.addFrozenEffectOnTarget(null, pTarget, null);
                }

                if (Randy.randomChance(0.01f))
                {
                    ActionLibrary.teleportRandom(null, pTarget, null);
                }
            }

            return false;
        }

        public static bool attack_bloodline5(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            const int drainAmount = 700; // 定义要汲取的血量
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false; // 如果施法者无效，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health > 0)
            {
                int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health); // 实际汲取的血量，不超过目标的当前血量
                pSelf.a.data.health =
                    Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量
            }

            return true;
        }

        public static bool attack_bloodline6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                    MapBox.spawnLightningMedium(pTile, 1f);
                }
            }

            return false;
        }

        public static bool attack_bloodline7(BaseSimObject pTarget, WorldTile pTile = null)//不灭血脉
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)Math.Round(pTarget.a.stats[S.health] / 20f));
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_bloodline8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castTornado(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    MapBox.spawnLightningMedium(pTile, 0.25f);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castFire(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    World.world.drop_manager.spawnParabolicDrop(pTarget.a.current_tile, "acid", 0f, 0.1f, 5f, 0.5f, 4f, 0.15f);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.addFrozenEffectOnTarget(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castShieldOnHimself(null, pSelf, null);
                }

                if (Randy.randomChance(0.01f))
                {
                    EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
                    pSelf.a.addStatusEffect("invincible", 5f);
                }
            }

            return false;
        }

        public static bool attack_bloodline9(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(1f))
                {
                    MapBox.spawnLightningMedium(pTile, 0.25f);
                }

                if (Randy.randomChance(1f))
                {
                    EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
                }

                if (Randy.randomChance(1f))
                {
                    EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castTornado(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    Earthquake.startQuake(pTile, EarthquakeType.RandomPower);
                }
            }

            return false;
        }

        public static bool attack_bloodline11(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castCurses(null, pTarget, null);//诅咒
                }
            }

            return false;
        }

        //传承法
        public static bool attack_inherit6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(0.1f))
                {
                    MapBox.spawnLightningMedium(pTile, 0.25f);
                }
            }

            return false;
        }

        public static bool attack_inherit8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //
            {
                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                }
            }

            return false;
        }

        //神性
       public static bool attack_godhead1(BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)Math.Round(pTarget.a.stats[S.health] / 10f));
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool warfare_attack_godhead2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 每次攻击计算自身指挥值的随机倍数，再减少目标血量
            if (pTarget != null && pTarget.a != null && pTarget.a.data != null && pSelf != null && pSelf.a != null &&
                pSelf.a.stats != null)
            {
                // 指挥值的随机倍数，范围在x到x之间
                float warfareMultiplierMin = 1f;
                float warfareMultiplierMax = 1f;
                float warfareMultiplier =
                    UnityEngine.Random.Range(warfareMultiplierMin, warfareMultiplierMax);

                float damageBasedOnWarfare = pSelf.a.stats[S.damage] * warfareMultiplier; // 根据指挥计算伤害
                int damageToDeal = Mathf.FloorToInt(damageBasedOnWarfare);                // 将浮点数伤害转换为整数

                pTarget.a.data.health -= damageToDeal; // 减去基于指挥的伤害值
            }

            return true;
        }

        public static bool godhead3_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) 
                return false;

            Actor originalActor = pTarget.a;

            // 创建新单位（继承原始模板数据）
            var newUnit = World.world.units.createNewUnit(
                originalActor.asset.id,
                pTile, 
                true
            );

            // 深度复制基础属性（等级/装备/特质）
            ActorTool.copyUnitToOtherUnit(originalActor, newUnit, true);
    
            newUnit.SetKnight(originalActor.GetKnight());
    
            // 3. 创建时间继承（保持年龄计算一致性）
            newUnit.data.created_time = originalActor.data.created_time; 

            /****************** 视觉效果 ******************/
            new PowerLibrary().divineLightFX(originalActor.current_tile, null);

            return true;
        }

        public static bool attack_godhead4(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)//
        {
            if (pTarget != null) 
            {
                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castTornado(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    MapBox.spawnLightningMedium(pTile, 2.5f);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castFire(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                     World.world.drop_manager.spawnParabolicDrop(pTarget.a.current_tile, "acid", 0f, 0.1f, 5f, 0.5f, 4f, 0.15f);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.addFrozenEffectOnTarget(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castShieldOnHimself(null, pSelf, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
                    pSelf.a.addStatusEffect("invincible", 5f);
                }

                if (Randy.randomChance(0.1f))
                {
                    Earthquake.startQuake(pTile, EarthquakeType.RandomPower);
                }

                if (Randy.randomChance(0.1f))
                {
                    ActionLibrary.castCurses(null, pTarget, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                }

                if (Randy.randomChance(0.1f))
                {
                    MapAction.damageWorld(pTile, 70, TerraformLibrary.czar_bomba, null);
                }

                if (Randy.randomChance(0.1f))
                {
                    EffectsLibrary.spawn("fx_napalm_flash", pTile, "napalm", null, 0f, -1f, -1f);//大型火雨
                }
            }

            return false;
        }

        public static bool attack_godhead5(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null) return false;

            if (Randy.randomChance(1f))
            {
                // 统计现有镜像数量
                int mirrorCount = 0;
                foreach (var unit in World.world.units)
                {
                    if (unit.hasTrait("function3"))
                    {
                        mirrorCount++;
                    }
                }

                // 最多生成8个镜像
                if (mirrorCount < 8)
                {
                    // 计算需要生成的数量
                    int maxAttempts = Mathf.Min(8 - mirrorCount, 8);
                    for (int i = 0; i < maxAttempts; i++)
                    {
                        if (Randy.randomChance(1f))
                        {
                            // 创建镜像单位
                            var mirror = World.world.units.createNewUnit(pSelf.a.asset.id, pTile);
                            
                            // 复制本体属性
                            ActorTool.copyUnitToOtherUnit(pSelf.a, mirror);
                            
                            // 设置镜像属性
                            mirror.kingdom = pSelf.kingdom;
                            mirror.addTrait("function3");
                            
                            // 添加镜像特殊属性
                            mirror.addStatusEffect("Ring93", 60f); // 60秒后自动消失
                            
                            mirrorCount++;
                            if (mirrorCount >= 8) break;
                        }
                    }
                }
            }
            return true;
        }
        
        public static bool attack_godhead7(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(1f))
                {
                    MapBox.spawnLightningMedium(pTile, 7f);
                }
            }

            return false;
        }

        public static bool attack_godhead8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null) return false;

            if (Randy.randomChance(1f))
            {
                // 统计现有镜像数量
                int mirrorCount = 0;
                foreach (var unit in World.world.units)
                {
                    if (unit.hasTrait("function3"))
                    {
                        mirrorCount++;
                    }
                }

                // 最多生成3个镜像
                if (mirrorCount < 8)
                {
                    // 计算需要生成的数量
                    int maxAttempts = Mathf.Min(3 - mirrorCount, 3);
                    for (int i = 0; i < maxAttempts; i++)
                    {
                        if (Randy.randomChance(1f))
                        {
                            // 创建镜像单位
                            var mirror = World.world.units.createNewUnit(pSelf.a.asset.id, pTile, false);
                            
                            // 复制本体属性
                            ActorTool.copyUnitToOtherUnit(pSelf.a, mirror);
                            
                            // 设置镜像属性
                            mirror.kingdom = pSelf.kingdom;
                            mirror.addTrait("function3");
                            
                            // 添加镜像特殊属性
                            mirror.addStatusEffect("Ring93", 60f); // 60秒后自动消失
                            
                            // 设置镜像的生命值为本体的
                            mirror.data.health = Mathf.FloorToInt(pSelf.a.data.health * 1f);
                            
                            // 设置镜像的伤害为本体的
                            if (mirror.stats != null && pSelf.a.stats != null)
                            {
                                mirror.stats[S.damage] = pSelf.a.stats[S.damage] * 1f;
                            }
                            
                            mirrorCount++;
                            if (mirrorCount >= 3) break;
                        }
                    }
                }
            }
            return true;
        }

        public static bool attack_godhead9(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                if (Randy.randomChance(1f))
                {
                    MapAction.damageWorld(pTile, 140, TerraformLibrary.czar_bomba, null);//沙皇炸弹
                }
            }

            return false;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
