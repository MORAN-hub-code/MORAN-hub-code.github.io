﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;


namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_KnightPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasTraining6 = __instance.hasTrait("training6");// 检查是否具有特质
            bool hasTraining5 = __instance.hasTrait("training5");
            // 检查种族是否在限定范围内
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };
            if (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_"))
            {
                // 9岁时获得training1-training4的随机特质
                if (Mathf.FloorToInt(age) == 9 && !hasTraining5 && !hasTraining6 &&
                !HasAnyFlairTalen(__instance) &&
                Randy.randomChance(0.3f))
                {
                    var trainingWeights = new (string traitId, int weight)[]
                    {
                        ("training1", 604),
                        ("training2", 300),
                        ("training3", 90),
                        ("training4", 6),
                    };

                    // 计算总权重
                    int totalWeight = trainingWeights.Sum(t => t.weight);

                    // 生成随机数
                    int randomValue = UnityEngine.Random.Range(0, totalWeight);

                    // 遍历权重选择特质
                    string selectedTraining = "training1"; // 默认值
                    foreach (var training in trainingWeights)
                    {
                        if (randomValue < training.weight)
                        {
                            selectedTraining = training.traitId;
                            break;
                        }
                        randomValue -= training.weight;
                    }

                    __instance.addTrait(selectedTraining, false);
                }
            }

            // 特质增加生命之力的处理
                var trainingKnightChanges = new Dictionary<string, (float, float)>
            {
                { "training1", (0.5f, 1.5f) },//下
                { "training2", (1.0f, 2.0f) },//中
                { "training3", (1.5f, 2.5f) },//上
                { "training4", (2.0f, 5.0f) },//完美
                { "inherit9", (5.0f, 7.0f) },//速成术
                { "inherit10", (3.0f, 5.0f) },//贵族修炼法
                { "function4", (66.0f, 77.0f) },//
                { "training6", (-1.0f, -2.0f) }//安享晚年
            };

            foreach (var change in trainingKnightChanges)
            {
                // 如果具有training6特质，并且当前特质是training1到training4，则跳过
                if ((hasTraining6 || hasTraining5) && (change.Key == "training1" || change.Key == "training2" || change.Key == "training3" || change.Key == "training4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomKnightIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeKnight(randomKnightIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var knightTraitThresholds = new Dictionary<string, float>
            {
                { "ascetic1", 40f },//骑士学徒
                { "ascetic2", 50f },//预备骑士+10
                { "ascetic3", 50f },//初级骑士+20
                { "ascetic4", 65f },//中级骑士+25
                { "ascetic5", 70f },//高级骑士+30
                { "ascetic6", 100f }//大骑士+60
            };
            const float training6Chance = 0f;
            foreach (var threshold in knightTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(training6Chance))
                {
                    __instance.addTrait("training6", false);
                }
            }

            var ascetics = new Dictionary<string, float>
            {
                { "ascetic1", 20f },
                { "ascetic2", 50f },
                { "ascetic3", 100f },
                { "ascetic4", 200f },
                { "ascetic5", 500f },
                { "ascetic6", 1000f },
                { "ascetic7", 2000f },
                { "ascetic8", 5000f },
            };
            foreach (var ascetic in ascetics)
            {
                UpdateKnightBasedOnascetic(__instance, ascetic.Key, ascetic.Value);
            }
        }
        private static void UpdateKnightBasedOnascetic(Actor actor, string traitName, float maxKnight)
        {
            if (actor.hasTrait(traitName))
            {
                float currentKnight = actor.GetKnight();
                float newValue = Mathf.Min(maxKnight, currentKnight);
                actor.SetKnight(newValue);
            }
        }
        private static readonly string[] FlairTrainingTraits = new[] { "training1", "training2", "training3", "training4", "inherit9", "inherit10", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairTrainingTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool IsActorDead(Actor actor)
        {
            return !actor.hasHealth();
        }

    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
    public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon)
    {
        __instance.attackedBy = null;
        if (__instance._cache_check_has_status_removed_on_damage)
        {
            foreach (Status tStatusData in __instance.getStatuses())
            {
                if (tStatusData.asset.removed_on_damage && !tStatusData.is_finished)
                {
                    __instance.finishStatusEffect(tStatusData.asset.id);
                }
            }
        }
        if (DebugConfig.isOn(DebugOption.IgnoreDamage)) return true;
        if (pSkipIfShake && __instance.shake_active) return true;
        if (IsActorDead(__instance)) return true;
        if (__instance.hasStatus("invincible")) return true;
        Actor tAttackerUnit = (pAttacker != null) ? pAttacker.a : null;
        if (pAttackType == AttackType.Weapon)
        {
            bool flag = false;
            if (pMetallicWeapon && __instance.haveMetallicWeapon())
            {
                flag = true;
            }
            if (flag)
            {
                MusicBox.playSound("event:/SFX/HIT/HitSwordSword", __instance.current_tile, false, true);
            }
            else if (__instance.asset.sound_hit != string.Empty)
            {
                MusicBox.playSound(__instance.asset.sound_hit, __instance.current_tile, false, true);
            }
            if (!__instance.hasStatus("shield") && tAttackerUnit != null)
            {
                __instance.damageEquipmentOnGetHit(tAttackerUnit);
            }
        }
        if (pDamage >= 0f)
        {
        // 定义所有减伤组（按优先级从高到低排序）
        var damageReductionGroups = new List<Tuple<string[], float>>()
        {
            // 格式: (特质数组, 伤害乘数)
            new Tuple<string[], float>(new string[] { "ascetic9" }, 0f),
            new Tuple<string[], float>(new string[] { "ascetic8" }, 0),
            new Tuple<string[], float>(new string[] { "ascetic7" }, 0.01f),
            new Tuple<string[], float>(new string[] { "ascetic6" }, 0.4f),
            new Tuple<string[], float>(new string[] { "ascetic5" }, 0.5f),
            new Tuple<string[], float>(new string[] { "ascetic4" }, 0.6f),
            new Tuple<string[], float>(new string[] { "ascetic3" }, 0.7f),
            new Tuple<string[], float>(new string[] { "ascetic2" }, 0.8f),           
            new Tuple<string[], float>(new string[] { "ascetic1" }, 0.9f)       // 最低优先级
        };

        // 按优先级检查减伤
        foreach (var group in damageReductionGroups)
        {
            foreach (string trait in group.Item1)
            {
                if (__instance.hasTrait(trait))
                {
                    pDamage *= group.Item2; // 应用减伤
                    goto AfterDamageReduction; // 跳出所有循环
                }
            }
        }
          AfterDamageReduction:; // 优先级检查结束标记
        }
        if (pAttackType == AttackType.Other || pAttackType == AttackType.Weapon)
        {
            float tArmorPercent = 1f - Mathf.Max(0, __instance.stats["armor"] - (pAttacker as Actor)?.stats["Break"] ?? 0) / 100f;
            pDamage *= tArmorPercent;
        }
        if (pDamage < 1f)
        {
            pDamage = 1f;
        }
        if (pAttacker != null && pAttacker.isActor())
        {
            float tFinalDamage;
            __instance.checkSpecialAttackLogic(pAttacker.a, pAttackType, pDamage, out tFinalDamage);
            pDamage = tFinalDamage;
        }
        if (tAttackerUnit != null)
        {
            SignalManager.add(SignalLibrary.check_achievement_clone_wars, new ValueTuple<Actor, Actor>(__instance, tAttackerUnit));
        }
        __instance.changeHealth((int)(-(int)pDamage));
        __instance.timer_action = 0.002f;
        if (pAttacker != __instance)
        {
            __instance.attackedBy = pAttacker;
        }
        GetHitAction getHitAction = __instance.s_get_hit_action;
        if (getHitAction != null)
        {
            getHitAction(__instance, pAttacker, __instance.current_tile);
        }
        if (pFlash)
        {
            __instance.startColorEffect(ActorColorEffect.Red);
        }
        if (!__instance.hasHealth())
        {
            Kingdom tPrevKingdom = __instance.kingdom;
            if (pAttacker != null && pAttacker != __instance && pAttacker.isActor() && pAttacker.isAlive())
            {
                BattleKeeperManager.unitKilled(__instance);
                pAttacker.a.newKillAction(__instance, tPrevKingdom, pAttackType);
                __instance.pickupResourcesFromKill(pAttacker.a);
            }
            __instance.die(false, pAttackType, true, true, true);
            return true;
        }
        bool hasasceticTrait = false;
        if (pAttackType == AttackType.Weapon && !__instance.asset.immune_to_injuries && !__instance.hasStatus("shield"))
        {
            // 检查目标是否具有 ascetic1 到 ascetic9 的特质
            for (int i = 1; i <= 9; i++)
            {
                string asceticTrait = "ascetic" + i;
                if (__instance.hasTrait(asceticTrait))
                {
                    hasasceticTrait = true;
                    break;
                }
            }
            // 如果目标没有 ascetic 特质，则添加受伤
            if (!hasasceticTrait)
            {
                if (Randy.randomChance(0.02f))
                {
                    __instance.addInjuryTrait("crippled");
                }
                if (Randy.randomChance(0.02f))
                {
                    __instance.addInjuryTrait("eyepatch");
                }
            }
        }
        __instance.startShake(0.3f, 0.1f, true, true);
        if (!__instance.has_attack_target)
        {
            if (__instance.attackedBy != null && !__instance.shouldIgnoreTarget(__instance.attackedBy) && __instance.canAttackTarget(__instance.attackedBy, false))
            {
                __instance.setAttackTarget(__instance.attackedBy);
            }
        }
        else if (__instance.hasMeleeAttack() && __instance.attackedBy != null && __instance.canAttackTarget(__instance.attackedBy, false))
        {
            float tDistToCurrentTarget = Toolbox.DistVec2Float(__instance.current_position, __instance.attack_target.current_position);
            float tDistToAttacker = Toolbox.DistVec2Float(__instance.current_position, pAttacker.current_position);
            if (tDistToCurrentTarget > __instance.getAttackRange() && tDistToAttacker < tDistToCurrentTarget)
            {
                __instance.setAttackTarget(pAttacker);
            }
        }
        if (__instance.hasAnyStatusEffect())
        {
            foreach (Status status in __instance.getStatuses())
            {
                GetHitAction action_get_hit = status.asset.action_get_hit;
                if (action_get_hit != null)
                {
                    action_get_hit(__instance, pAttacker, __instance.current_tile);
                }
            }
        }
        GetHitAction action_get_hit2 = __instance.asset.action_get_hit;
        if (action_get_hit2 == null)
        {
            return true;
        }
        action_get_hit2(__instance, pAttacker, __instance.current_tile);
        return true;
    }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            __instance.cancelAllBeh();
            __instance.makeWait(pTime);
            // 检查是否具有 ascetic1 到 ascetic91 的特质
            bool hasasceticTrait = false;
            for (int i = 1; i <= 9; i++)
            {
                string asceticTrait = "ascetic" + i;
                if (__instance.hasTrait(asceticTrait))
                {
                    hasasceticTrait = true;
                    break;
                }
            }
            // 如果没有 ascetic 特质，则添加眩晕状态
            if (!hasasceticTrait)
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            return false;
        }
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
        public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            float tForce = pData.knockback * pMod;

            if (tForce > 0f && pTargetToCheck.isActor())
            {
                float resistValue = pTargetToCheck.a.stats["Resist"];
                tForce = Mathf.Max(tForce - resistValue, 0);

                if (tForce > 0f)
                {
                    Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                    Vector2 tAttackVec = pData.hit_position;
                    pTargetToCheck.a.calculateForce(
                    tPosStart.x, tPosStart.y,
                    tAttackVec.x, tAttackVec.y,
                    tForce,
                    0f,
                    pCheckCancelJobOnLand
                    );
                }
            }
            return false;
        }
        //禁止雷电劈出永生
        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            List<Actor> simpleList = World.world.units.getSimpleList();
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        BehaviourTaskActor task = actor.ai.task;
                        SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            return false;
        }
    }
}