﻿namespace ChivalryWizardingWorld.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset Knight = new BaseStatAsset();
            Knight.id = "Knight";
            Knight.normalize = true;
            Knight.normalize_min = -999999;
            Knight.normalize_max = 999999;
            //Knight.multiplier = true;
            Knight.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Knight);

            BaseStatAsset Resist = new BaseStatAsset();
            Resist.id = "Resist";
            Resist.normalize = true;
            Resist.normalize_min = 0;
            Resist.normalize_max = 99999;
            Resist.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Resist);
        }
    }
}