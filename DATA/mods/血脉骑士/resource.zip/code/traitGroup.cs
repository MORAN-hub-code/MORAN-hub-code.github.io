﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChivalryWizardingWorld.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset ascetic = new ActorTraitGroupAsset();
            ascetic.id = "ascetic";
            ascetic.name = "trait_group_ascetic";
            ascetic.color = "#00FF00";
            AssetManager.trait_groups.add(ascetic);

            ActorTraitGroupAsset training = new ActorTraitGroupAsset();
            training.id = "training";
            training.name = "trait_group_training";
            training.color = "#00FF00";
            AssetManager.trait_groups.add(training);

            ActorTraitGroupAsset skill = new ActorTraitGroupAsset();
            skill.id = "skill";
            skill.name = "trait_group_skill";
            skill.color = "#00FF00";
            AssetManager.trait_groups.add(skill);

            ActorTraitGroupAsset arms = new ActorTraitGroupAsset();
            arms.id = "arms";
            arms.name = "trait_group_arms";
            arms.color = "#00FF00";
            AssetManager.trait_groups.add(arms);             

            ActorTraitGroupAsset inherit = new ActorTraitGroupAsset();
            inherit.id = "inherit";
            inherit.name = "trait_group_inherit";
            inherit.color = "#00FF00";
            AssetManager.trait_groups.add(inherit);

            ActorTraitGroupAsset bloodline = new ActorTraitGroupAsset();
            bloodline.id = "bloodline";
            bloodline.name = "trait_group_bloodline";
            bloodline.color = "#00FF00";
            AssetManager.trait_groups.add(bloodline);

            ActorTraitGroupAsset Legend = new ActorTraitGroupAsset();
            Legend.id = "Legend";
            Legend.name = "trait_group_Legend";
            Legend.color = "#00FF00";
            AssetManager.trait_groups.add(Legend);

            ActorTraitGroupAsset godhead = new ActorTraitGroupAsset();
            godhead.id = "godhead";
            godhead.name = "trait_group_godhead";
            godhead.color = "#00FF00";
            AssetManager.trait_groups.add(godhead);

            ActorTraitGroupAsset function = new ActorTraitGroupAsset();
            function.id = "function";
            function.name = "trait_group_function";
            function.color = "#00FF00";
            AssetManager.trait_groups.add(function);
        }
    }
}
