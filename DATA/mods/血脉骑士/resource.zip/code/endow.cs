using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ai;
using HarmonyLib;
using NCMS.Utils;

namespace ChivalryWizardingWorld.code
{
    internal class endow
    {   
        public static bool godGiveWeapon(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget == null || pTarget.a == null) return false;

            bool hasGivenAny = false;

            if (pTarget.a.hasTrait("arms1"))
            {
                ItemAsset wandAsset = AssetManager.items.get("Thunderouslongbow");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms2"))
            {
                ItemAsset wandAsset = AssetManager.items.get("Heavyhammer");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms3"))
            {
                ItemAsset wandAsset = AssetManager.items.get("BurstingMagicSword");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms4"))
            {
                ItemAsset wandAsset = AssetManager.items.get("FlameBattleAxe");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms5"))
            {
                ItemAsset wandAsset = AssetManager.items.get("Goodandevil");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms6"))
            {
                ItemAsset ringAsset = AssetManager.items.get("TheKnightsOath");
                if (ringAsset != null)
                {
                    Item ring = World.world.items.newItem(ringAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Ring).setItem(ring, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms7"))
            {
                ItemAsset ringAsset = AssetManager.items.get("Theknightshelmet");
                if (ringAsset != null)
                {
                    Item ring = World.world.items.newItem(ringAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Helmet).setItem(ring, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("arms8"))
            {
                ItemAsset ringAsset = AssetManager.items.get("ThearmorofaKnight");
                if (ringAsset != null)
                {
                    Item ring = World.world.items.newItem(ringAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Helmet).setItem(ring, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            if (pTarget.a.hasTrait("Legend1"))
            {
                ItemAsset wandAsset = AssetManager.items.get("Thelegendarylongbow");
                if (wandAsset != null)
                {
                    Item wand = World.world.items.newItem(wandAsset);
                    pTarget.a.equipment.getSlot(EquipmentType.Weapon).setItem(wand, pTarget.a);
                    pTarget.a.setStatsDirty();
                    hasGivenAny = true;
                }
            }

            pTarget.a.updateStats();
            return hasGivenAny;
        }
    }
}
