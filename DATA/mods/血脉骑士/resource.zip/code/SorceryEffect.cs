using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace ChivalryWizardingWorld.code
{
    internal class SorceryEffect
    {
        public static void Init()
        {
            StatusAsset Ring93 = new StatusAsset();
            Ring93.id = "Ring93";
            Ring93.locale_id = "status_title_Ring93";
            Ring93.locale_description = "status_desc_Ring93";
            Ring93.path_icon = "Ring/Ring93";
            AssetManager.status.add(pAsset:Ring93);
        }
    }
}