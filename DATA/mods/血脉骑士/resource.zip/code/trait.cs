﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();
            
            return trait;
        }
        public static ActorTrait training_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait training = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "training",
                needs_to_be_explored = false
            };
            training.action_special_effect += traitAction.ascetic1_effectAction;
            AssetManager.traits.add(training);
            return training;
        }
        public static void Init()
        {
            _=training_AddActorTrait("training1", "trait/training1");//骑士天赋•下
            _=training_AddActorTrait("training2", "trait/training2");//骑士天赋•中
            _=training_AddActorTrait("training3", "trait/training3");//骑士天赋•上
            _=training_AddActorTrait("training4", "trait/training4");//骑士天赋•完美

            ActorTrait training5 = CreateTrait("training5", "trait/training5", "SeedsofLife");
            training5.rate_inherit = 100;
            AssetManager.traits.add(training5);
            
            ActorTrait training6 = CreateTrait("training6", "trait/training6", "SeedsofLife");
            AssetManager.traits.add(training6);

            ActorTrait ascetic1 = new ActorTrait();
            ascetic1.id = "ascetic1";//晨星骑士
            ascetic1.path_icon = "trait/ascetic1";
            ascetic1.needs_to_be_explored = false;
            ascetic1.group_id = "ascetic";
            ascetic1.base_stats = new BaseStats();
            ascetic1.base_stats[S.lifespan] = 1f;//寿命
            ascetic1.base_stats[S.warfare] = 1f;//战争
            ascetic1.base_stats[S.damage] = 10f;//伤害
            ascetic1.base_stats[S.health] = 100f;//生命值
            ascetic1.base_stats[S.armor] = 10f;//护甲
            ascetic1.base_stats[S.speed] = 10f;//速度
            ascetic1.base_stats[S.range] = 1f;//范围
            ascetic1.base_stats[S.area_of_effect] = 1f;//影响范围
            ascetic1.base_stats[S.targets] = 1f;//目标
            ascetic1.base_stats[S.accuracy] = 1f;//准确度
            ascetic1.base_stats[S.critical_chance] = 10f;//暴击几率
            ascetic1.base_stats[S.critical_damage_multiplier] = 10f;//暴击伤害倍率
            ascetic1.base_stats[S.knockback] = 0.1f;//击退
            ascetic1.base_stats[S.recoil] = -100f;//后坐力
            ascetic1.base_stats[S.skill_combat] = 1f;//战斗技能
            ascetic1.base_stats[S.mass_2] = 1f;//质量
            ascetic1.base_stats[S.attack_speed] = 1f;//攻击速度
            ascetic1.base_stats[S.stamina] = 100f;//耐力
            ascetic1.base_stats["Resist"] = 1f;//抗性
            ascetic1.action_special_effect += traitAction.ascetic2_effectAction;
            ascetic1.action_special_effect += (WorldAction)Delegate.Combine(ascetic1.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果
            AssetManager.traits.add(ascetic1);

            ActorTrait ascetic2 = new ActorTrait();
            ascetic2.id = "ascetic2";//黎明骑士
            ascetic2.path_icon = "trait/ascetic2";
            ascetic2.needs_to_be_explored = false;
            ascetic2.group_id = "ascetic";
            ascetic2.base_stats = new BaseStats();
            ascetic2.base_stats[S.lifespan] = 2f;//寿命
            ascetic2.base_stats[S.warfare] = 2f;//战争
            ascetic2.base_stats[S.damage] = 20f;//伤害
            ascetic2.base_stats[S.health] = 200f;//生命值
            ascetic2.base_stats[S.armor] = 20f;//护甲
            ascetic2.base_stats[S.speed] = 20f;//速度
            ascetic2.base_stats[S.range] = 2f;//范围
            ascetic2.base_stats[S.area_of_effect] = 2f;//影响范围
            ascetic2.base_stats[S.targets] = 2f;//目标
            ascetic2.base_stats[S.accuracy] = 2f;//准确度
            ascetic2.base_stats[S.critical_chance] = 20f;//暴击几率
            ascetic2.base_stats[S.critical_damage_multiplier] = 20f;//暴击伤害倍率
            ascetic2.base_stats[S.knockback] = 0.2f;//击退
            ascetic2.base_stats[S.recoil] = -100f;//后坐力
            ascetic2.base_stats[S.skill_combat] = 2f;//战斗技能
            ascetic2.base_stats[S.mass_2] = 200f;//质量
            ascetic2.base_stats[S.attack_speed] = 2f;//攻击速度
            ascetic2.base_stats[S.stamina] = 200f;//耐力
            ascetic2.base_stats["Resist"] = 2f;//抗性
            ascetic2.action_special_effect += traitAction.ascetic3_effectAction;
            ascetic2.action_special_effect += (WorldAction)Delegate.Combine(ascetic2.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果
            AssetManager.traits.add(ascetic2);

            ActorTrait ascetic3 = new ActorTrait();
            ascetic3.id = "ascetic3";//拂晓骑士
            ascetic3.path_icon = "trait/ascetic3";
            ascetic3.needs_to_be_explored = false;
            ascetic3.group_id = "ascetic";
            ascetic3.base_stats = new BaseStats();
            ascetic3.base_stats[S.lifespan] = 5f;//寿命
            ascetic3.base_stats[S.warfare] = 5f;//战争
            ascetic3.base_stats[S.damage] = 50f;//伤害
            ascetic3.base_stats[S.health] = 500f;//生命值
            ascetic3.base_stats[S.armor] = 50f;//护甲
            ascetic3.base_stats[S.speed] = 50f;//速度
            ascetic3.base_stats[S.range] = 5f;//范围
            ascetic3.base_stats[S.area_of_effect] = 5f;//影响范围
            ascetic3.base_stats[S.targets] = 5f;//目标
            ascetic3.base_stats[S.accuracy] = 5f;//准确度
            ascetic3.base_stats[S.critical_chance] = 50f;//暴击几率
            ascetic3.base_stats[S.critical_damage_multiplier] = 50f;//暴击伤害倍率
            ascetic3.base_stats[S.knockback] = 0.5f;//击退
            ascetic3.base_stats[S.recoil] = -100f;//后坐力
            ascetic3.base_stats[S.skill_combat] = 5f;//战斗技能
            ascetic3.base_stats[S.mass_2] = 500f;//质量
            ascetic3.base_stats[S.attack_speed] = 5f;//攻击速度
            ascetic3.base_stats[S.stamina] = 500f;//耐力
            ascetic3.base_stats["Resist"] = 5f;//抗性
            ascetic3.action_special_effect += traitAction.ascetic4_effectAction;
            ascetic3.action_special_effect += (WorldAction)Delegate.Combine(ascetic3.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果
            AssetManager.traits.add(ascetic3);

            ActorTrait ascetic4 = new ActorTrait();
            ascetic4.id = "ascetic4";//烈阳骑士
            ascetic4.path_icon = "trait/ascetic4";
            ascetic4.needs_to_be_explored = false;
            ascetic4.group_id = "ascetic";
            ascetic4.base_stats = new BaseStats();
            ascetic4.base_stats[S.lifespan] = 10f;//寿命
            ascetic4.base_stats[S.warfare] = 10f;//战争
            ascetic4.base_stats[S.damage] = 100f;//伤害
            ascetic4.base_stats[S.health] = 1000f;//生命值
            ascetic4.base_stats[S.armor] = 100f;//护甲
            ascetic4.base_stats[S.speed] = 100f;//速度
            ascetic4.base_stats[S.range] = 10f;//范围
            ascetic4.base_stats[S.area_of_effect] = 10f;//影响范围
            ascetic4.base_stats[S.targets] = 10f;//目标
            ascetic4.base_stats[S.accuracy] = 10f;//准确度
            ascetic4.base_stats[S.critical_chance] = 100f;//暴击几率
            ascetic4.base_stats[S.critical_damage_multiplier] = 100f;//暴击伤害倍率
            ascetic4.base_stats[S.knockback] = 1f;//击退
            ascetic4.base_stats[S.recoil] = -100f;//后坐力
            ascetic4.base_stats[S.skill_combat] = 10f;//战斗技能
            ascetic4.base_stats[S.mass_2] = 1000f;//质量
            ascetic4.base_stats[S.attack_speed] = 10f;//攻击速度
            ascetic4.base_stats[S.stamina] = 1000f;//耐力
            ascetic4.base_stats["Resist"] = 10f;//抗性
            ascetic4.action_special_effect += traitAction.ascetic5_effectAction;
            ascetic4.action_special_effect += (WorldAction)Delegate.Combine(ascetic4.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果
            AssetManager.traits.add(ascetic4);

            ActorTrait ascetic5 = new ActorTrait();
            ascetic5.id = "ascetic5";//黄昏骑士
            ascetic5.path_icon = "trait/ascetic5";
            ascetic5.needs_to_be_explored = false;
            ascetic5.group_id = "ascetic";
            ascetic5.base_stats = new BaseStats();
            ascetic5.base_stats[S.lifespan] = 20f;//寿命
            ascetic5.base_stats[S.warfare] = 20f;//战争
            ascetic5.base_stats[S.damage] = 200f;//伤害
            ascetic5.base_stats[S.health] = 2000f;//生命值
            ascetic5.base_stats[S.armor] = 200f;//护甲
            ascetic5.base_stats[S.speed] = 200f;//速度
            ascetic5.base_stats[S.range] = 20f;//范围
            ascetic5.base_stats[S.area_of_effect] = 20f;//影响范围
            ascetic5.base_stats[S.targets] = 20f;//目标
            ascetic5.base_stats[S.accuracy] = 20f;//准确度
            ascetic5.base_stats[S.critical_chance] = 200f;//暴击几率
            ascetic5.base_stats[S.critical_damage_multiplier] = 200f;//暴击伤害倍率
            ascetic5.base_stats[S.knockback] = 2f;//击退
            ascetic5.base_stats[S.recoil] = -100f;//后坐力
            ascetic5.base_stats[S.skill_combat] = 20f;//战斗技能
            ascetic5.base_stats[S.mass_2] = 2000f;//质量
            ascetic5.base_stats[S.attack_speed] = 20f;//攻击速度
            ascetic5.base_stats[S.stamina] = 2000f;//耐力
            ascetic5.base_stats["Resist"] = 20f;//抗性
            ascetic5.action_special_effect += (WorldAction)Delegate.Combine(ascetic5.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果
            ascetic5.action_special_effect += traitAction.ascetic6_effectAction;
            AssetManager.traits.add(ascetic5);

            ActorTrait ascetic6 = new ActorTrait();
            ascetic6.id = "ascetic6";//繁星骑士
            ascetic6.path_icon = "trait/ascetic6";
            ascetic6.needs_to_be_explored = false;
            ascetic6.group_id = "ascetic";
            ascetic6.base_stats = new BaseStats();
            ascetic6.base_stats[S.lifespan] = 50f;//寿命
            ascetic6.base_stats[S.warfare] = 50f;//战争
            ascetic6.base_stats[S.damage] = 500f;//伤害
            ascetic6.base_stats[S.health] = 5000f;//生命值
            ascetic6.base_stats[S.armor] = 500f;//护甲
            ascetic6.base_stats[S.speed] = 500f;//速度
            ascetic6.base_stats[S.range] = 50f;//范围
            ascetic6.base_stats[S.area_of_effect] = 50f;//影响范围
            ascetic6.base_stats[S.targets] = 50f;//目标
            ascetic6.base_stats[S.accuracy] = 50f;//准确度
            ascetic6.base_stats[S.critical_chance] = 500f;//暴击几率
            ascetic6.base_stats[S.critical_damage_multiplier] = 500f;//暴击伤害倍率
            ascetic6.base_stats[S.knockback] = 5f;//击退
            ascetic6.base_stats[S.recoil] = -100f;//后坐力
            ascetic6.base_stats[S.skill_combat] = 50f;//战斗技能
            ascetic6.base_stats[S.mass_2] = 5000f;//质量
            ascetic6.base_stats[S.attack_speed] = 50f;//攻击速度
            ascetic6.base_stats[S.stamina] = 5000f;//耐力
            ascetic6.base_stats["Resist"] = 50f;//抗性
            ascetic6.action_special_effect += traitAction.ascetic7_effectAction;
            ascetic6.action_special_effect += (WorldAction)Delegate.Combine(ascetic6.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果 
            AssetManager.traits.add(ascetic6);
            
            ActorTrait ascetic7 = new ActorTrait();
            ascetic7.id = "ascetic7";//血脉骑士
            ascetic7.path_icon = "trait/ascetic7";
            ascetic7.needs_to_be_explored = false;
            ascetic7.group_id = "ascetic";
            ascetic7.base_stats = new BaseStats();
            ascetic7.base_stats[S.lifespan] = 100f;//寿命
            ascetic7.base_stats[S.warfare] = 100f;//战争
            ascetic7.base_stats[S.damage] = 1000f;//伤害
            ascetic7.base_stats[S.health] = 10000f;//生命值
            ascetic7.base_stats[S.armor] = 1000f;//护甲
            ascetic7.base_stats[S.speed] = 1000f;//速度
            ascetic7.base_stats[S.multiplier_damage] = 1f;//伤害倍率
            ascetic7.base_stats[S.multiplier_health] = 1f;//生命值倍率
            ascetic7.base_stats[S.range] = 100f;//范围
            ascetic7.base_stats[S.area_of_effect] = 100f;//影响范围
            ascetic7.base_stats[S.targets] = 100f;//目标
            ascetic7.base_stats[S.accuracy] = 100f;//准确度
            ascetic7.base_stats[S.critical_chance] = 1000f;//暴击几率
            ascetic7.base_stats[S.critical_damage_multiplier] = 1000f;//暴击伤害倍率
            ascetic7.base_stats[S.knockback] = 10f;//击退
            ascetic7.base_stats[S.recoil] = -100f;//后坐力
            ascetic7.base_stats[S.skill_combat] = 100f;//战斗技能
            ascetic7.base_stats[S.mass_2] = 10000f;//质量
            ascetic7.base_stats[S.attack_speed] = 100f;//攻击速度
            ascetic7.base_stats[S.stamina] = 10000f;//耐力
            ascetic7.base_stats["Resist"] = 100f;//抗性
            ascetic7.action_special_effect += traitAction.ascetic8_effectAction;
            ascetic7.action_special_effect += (WorldAction)Delegate.Combine(ascetic7.action_special_effect,
                new WorldAction(traitAction.ascetic1_Regen)); //再生效果 
            AssetManager.traits.add(ascetic7);

            ActorTrait ascetic8 = new ActorTrait();
            ascetic8.id = "ascetic8";//传说中的骑士
            ascetic8.path_icon = "trait/ascetic8";
            ascetic8.needs_to_be_explored = false;
            ascetic8.group_id = "ascetic";
            ascetic8.base_stats = new BaseStats();
            ascetic8.base_stats[S.lifespan] = 200f;//寿命
            ascetic8.base_stats[S.warfare] = 200f;//战争
            ascetic8.base_stats[S.damage] = 2000f;//伤害
            ascetic8.base_stats[S.health] = 20000f;//生命值
            ascetic8.base_stats[S.armor] = 2000f;//护甲
            ascetic8.base_stats[S.speed] = 2000f;//速度
            ascetic8.base_stats[S.multiplier_damage] = 2f;//伤害倍率
            ascetic8.base_stats[S.multiplier_health] = 2f;//生命值倍率
            ascetic8.base_stats[S.range] = 200f;//范围
            ascetic8.base_stats[S.area_of_effect] = 200f;//影响范围
            ascetic8.base_stats[S.targets] = 200f;//目标
            ascetic8.base_stats[S.accuracy] = 200f;//准确度
            ascetic8.base_stats[S.critical_chance] = 2000f;//暴击几率
            ascetic8.base_stats[S.critical_damage_multiplier] = 2000f;//暴击伤害倍率
            ascetic8.base_stats[S.knockback] = 20f;//击退
            ascetic8.base_stats[S.recoil] = -100f;//后坐力
            ascetic8.base_stats[S.skill_combat] = 200f;//战斗技能
            ascetic8.base_stats[S.mass_2] = 20000f;//质量
            ascetic8.base_stats[S.attack_speed] = 200f;//攻击速度
            ascetic8.base_stats[S.stamina] = 20000f;//耐力
            ascetic8.base_stats["Resist"] = 200f;
            ascetic8.action_special_effect += traitAction.ascetic9_effectAction;
            ascetic8.action_attack_target += traitAction.warfare_attack_ascetic8;
            ascetic8.action_special_effect += (WorldAction)Delegate.Combine(ascetic8.action_special_effect,
                new WorldAction(traitAction.ascetic8_Regen)); //再生效果
            AssetManager.traits.add(ascetic8);

            ActorTrait ascetic9 = new ActorTrait();
            ascetic9.id = "ascetic9";//神性骑士
            ascetic9.path_icon = "trait/ascetic9";
            ascetic9.needs_to_be_explored = false;
            ascetic9.group_id = "ascetic";
            ascetic9.base_stats = new BaseStats();
            ascetic9.base_stats[S.lifespan] = 500f;//寿命
            ascetic9.base_stats[S.warfare] = 500f;//战争
            ascetic9.base_stats[S.damage] = 5000f;//伤害
            ascetic9.base_stats[S.health] = 50000f;//生命值
            ascetic9.base_stats[S.armor] = 5000f;//护甲
            ascetic9.base_stats[S.speed] = 5000f;//速度
            ascetic9.base_stats[S.multiplier_damage] = 5f;//伤害倍率
            ascetic9.base_stats[S.multiplier_health] = 5f;//生命值倍率
            ascetic9.base_stats[S.range] = 500f;//范围
            ascetic9.base_stats[S.area_of_effect] = 500f;//影响范围
            ascetic9.base_stats[S.targets] = 500f;//目标
            ascetic9.base_stats[S.accuracy] = 500f;//准确度
            ascetic9.base_stats[S.critical_chance] = 5000f;//暴击几率
            ascetic9.base_stats[S.critical_damage_multiplier] = 50f;//暴击伤害倍率
            ascetic9.base_stats[S.knockback] = 500f;//击退
            ascetic9.base_stats[S.recoil] = -100f;//后坐力
            ascetic9.base_stats[S.skill_combat] = 500f;//战斗技能
            ascetic9.base_stats[S.mass_2] = 50000f;//质量
            ascetic9.base_stats[S.attack_speed] = 500f;//攻击速度
            ascetic9.base_stats[S.stamina] = 50000f;//耐力
            ascetic9.base_stats["Resist"] = 500f;//抗性
            ascetic9.action_special_effect += traitAction.brokenProof7;
            ascetic9.action_attack_target += traitAction.warfare_attack_ascetic9;
            ascetic9.action_special_effect += (WorldAction)Delegate.Combine(ascetic9.action_special_effect,
                new WorldAction(traitAction.ascetic9_Regen)); //再生效果
            AssetManager.traits.add(ascetic9);

            //战技
            ActorTrait skill1 = new ActorTrait();
            skill1.id = "skill1";//冰封千里
            skill1.path_icon = "trait/skill1";
            skill1.needs_to_be_explored = false;
            skill1.group_id = "skill";
            skill1.base_stats = new BaseStats();
            skill1.base_stats[S.multiplier_damage] = 1f;//血量%
            skill1.base_stats[S.multiplier_damage] = 0.5f;//伤害%
            skill1.base_stats[S.critical_chance] = 0.5f;//暴击%
            skill1.action_special_effect += traitAction.brokenProof2;
            skill1.action_attack_target += new AttackAction((traitAction.attack_skill1));
            AssetManager.traits.add(skill1);

            ActorTrait skill2 = new ActorTrait();
            skill2.id = "skill2";//焚域之焰
            skill2.path_icon = "trait/skill2";
            skill2.needs_to_be_explored = false;
            skill2.group_id = "skill";
            skill2.base_stats = new BaseStats();
            skill2.base_stats[S.multiplier_health] = 0.5f;//血量%
            skill2.base_stats[S.multiplier_damage] = 1f;//伤害%
            skill2.base_stats[S.critical_chance] = 0.5f;//暴击%
            skill2.action_special_effect += traitAction.brokenProof1;
            skill2.action_attack_target += new AttackAction((traitAction.attack_skill2));
            AssetManager.traits.add(skill2);

            ActorTrait skill3 = new ActorTrait();
            skill3.id = "skill3";//雷霆万钧
            skill3.path_icon = "trait/skill3";
            skill3.needs_to_be_explored = false;
            skill3.group_id = "skill";
            skill3.base_stats = new BaseStats();
            skill3.base_stats[S.multiplier_health] = 0.2f;//血量%
            skill3.base_stats[S.multiplier_damage] = 0.8f;//伤害%
            skill3.base_stats[S.critical_chance] = 1f;//暴击%
            skill3.action_special_effect += traitAction.brokenProof1;
            skill3.action_attack_target += new AttackAction((traitAction.attack_skill3));
            AssetManager.traits.add(skill3);

            ActorTrait skill4 = new ActorTrait();
            skill4.id = "skill4";//复苏之光
            skill4.path_icon = "trait/skill4";
            skill4.needs_to_be_explored = false;
            skill4.group_id = "skill";
            skill4.base_stats = new BaseStats();
            skill4.base_stats[S.multiplier_health] = 2f;//血量%
            skill4.action_special_effect += (WorldAction)Delegate.Combine(skill4.action_special_effect,
                new WorldAction(traitAction.attack_skill4)); //再生效
            AssetManager.traits.add(skill4);

            //血脉
            ActorTrait bloodline1 = new ActorTrait();
            bloodline1.id = "bloodline1";//圣辉血脉
            bloodline1.path_icon = "trait/bloodline1";
            bloodline1.needs_to_be_explored = false;
            bloodline1.rate_inherit = 50;
            bloodline1.group_id = "bloodline";
            bloodline1.base_stats = new BaseStats();
            bloodline1.base_stats[S.lifespan] = 100f;//寿命
            bloodline1.base_stats[S.multiplier_damage] = 3f;//伤害
            bloodline1.base_stats[S.multiplier_health] = 10f;//血量
            bloodline1.base_stats[S.attack_speed] = 50f;//攻速
            bloodline1.base_stats[S.speed] = 30f;//速度
            bloodline1.base_stats[S.armor] = 50f;//防御
            bloodline1.base_stats[S.critical_chance] = 0.50f;//暴击%
            bloodline1.base_stats[S.range] = 3f;//射程
            bloodline1.base_stats[S.area_of_effect] = 3f;//近战范围
            bloodline1.base_stats[S.targets] = 3f;//可攻击目标
            bloodline1.base_stats[S.knockback] = 0.50f;//击退
            bloodline1.action_special_effect += traitAction.brokenProof0;
            bloodline1.action_attack_target += new AttackAction((traitAction.attack_bloodline1));
            AssetManager.traits.add(bloodline1);

            ActorTrait bloodline2 = new ActorTrait();
            bloodline2.id = "bloodline2";//龙焰血脉
            bloodline2.path_icon = "trait/bloodline2";
            bloodline2.needs_to_be_explored = false;
            bloodline2.rate_inherit = 50;
            bloodline2.group_id = "bloodline";
            bloodline2.base_stats = new BaseStats();
            bloodline2.base_stats[S.lifespan] = 150f;//寿命
            bloodline2.base_stats[S.multiplier_damage] = 1f;//伤害
            bloodline2.base_stats[S.multiplier_health] = 10f;//血量
            bloodline2.base_stats[S.attack_speed] = 20f;//攻速
            bloodline2.base_stats[S.speed] = 40f;//速度
            bloodline2.base_stats[S.armor] = 40f;//防御
            bloodline2.base_stats[S.critical_chance] = 0.50f;//暴击%
            bloodline2.base_stats[S.range] = 5f;//射程
            bloodline2.base_stats[S.area_of_effect] = 2f;//近战范围
            bloodline2.base_stats[S.targets] = 3f;//可攻击目标
            bloodline2.base_stats[S.knockback] = 0.50f;//击退
            bloodline2.action_attack_target += new AttackAction((traitAction.attack_bloodline2));
            bloodline2.action_special_effect += traitAction.brokenProof1;
            AssetManager.traits.add(bloodline2);

            ActorTrait bloodline3 = new ActorTrait();
            bloodline3.id = "bloodline3";//星陨血脉
            bloodline3.path_icon = "trait/bloodline3";
            bloodline3.needs_to_be_explored = false;
            bloodline3.rate_inherit = 50;
            bloodline3.group_id = "bloodline";
            bloodline3.base_stats = new BaseStats();
            bloodline3.base_stats[S.lifespan] = 50f;//寿命
            bloodline3.base_stats[S.multiplier_damage] = 3f;//伤害
            bloodline3.base_stats[S.multiplier_health] = 5f;//血量
            bloodline3.base_stats[S.attack_speed] = 50f;//攻速
            bloodline3.base_stats[S.speed] = 50f;//速度
            bloodline3.base_stats[S.armor] = 50f;//防御
            bloodline3.base_stats[S.critical_chance] = 1f;//暴击%
            bloodline3.base_stats[S.range] = 10f;//射程
            bloodline3.base_stats[S.area_of_effect] = 3f;//近战范围
            bloodline3.base_stats[S.targets] = 5f;//可攻击目标
            bloodline3.base_stats[S.knockback] = 1f;//击退
            bloodline3.action_attack_target += new AttackAction((traitAction.attack_bloodline3));
            bloodline3.action_special_effect += traitAction.brokenProof1;
            AssetManager.traits.add(bloodline3);

            ActorTrait bloodline4 = new ActorTrait();
            bloodline4.id = "bloodline4";//冥夜血脉
            bloodline4.path_icon = "trait/bloodline4";
            bloodline4.needs_to_be_explored = false;
            bloodline4.rate_inherit = 50;
            bloodline4.group_id = "bloodline";
            bloodline4.base_stats = new BaseStats();
            bloodline4.base_stats[S.lifespan] = 30f;//寿命
            bloodline4.base_stats[S.multiplier_damage] = 5f;//伤害
            bloodline4.base_stats[S.multiplier_health] = 7f;//血量
            bloodline4.base_stats[S.attack_speed] = 100f;//攻速
            bloodline4.base_stats[S.speed] = 100f;//速度
            bloodline4.base_stats[S.armor] = 10f;//防御
            bloodline4.base_stats[S.critical_chance] = 2f;//暴击%
            bloodline4.base_stats[S.range] = 1f;//射程
            bloodline4.base_stats[S.area_of_effect] = 2f;//近战范围
            bloodline4.base_stats[S.targets] = 1f;//可攻击目标
            bloodline4.base_stats[S.knockback] = 0.10f;//击退
            bloodline4.action_attack_target += new AttackAction((traitAction.attack_bloodline4));
            bloodline4.action_special_effect += traitAction.brokenProof2;
            AssetManager.traits.add(bloodline4);

            ActorTrait bloodline5 = new ActorTrait();
            bloodline5.id = "bloodline5";//战狂血脉
            bloodline5.path_icon = "trait/bloodline5";
            bloodline5.needs_to_be_explored = false;
            bloodline5.rate_inherit = 50;
            bloodline5.group_id = "bloodline";
            bloodline5.base_stats = new BaseStats();
            bloodline5.base_stats[S.lifespan] = 20f;//寿命
            bloodline5.base_stats[S.multiplier_damage] = 5f;//伤害
            bloodline5.base_stats[S.multiplier_health] = 7f;//血量
            bloodline5.base_stats[S.attack_speed] = 20f;//攻速
            bloodline5.base_stats[S.speed] = 20f;//速度
            bloodline5.base_stats[S.armor] = 20f;//防御
            bloodline5.base_stats[S.critical_chance] = 0.50f;//暴击%
            bloodline5.base_stats[S.range] = 1f;//射程
            bloodline5.base_stats[S.area_of_effect] = 3f;//近战范围
            bloodline5.base_stats[S.targets] = 3f;//可攻击目标
            bloodline5.base_stats[S.knockback] = 0.20f;//击退
            bloodline5.action_attack_target += new AttackAction((traitAction.attack_bloodline5));
            AssetManager.traits.add(bloodline5);

            ActorTrait bloodline6 = new ActorTrait();
            bloodline6.id = "bloodline6";//雷霆血脉
            bloodline6.path_icon = "trait/bloodline6";
            bloodline6.needs_to_be_explored = false;
            bloodline6.rate_inherit = 50;
            bloodline6.group_id = "bloodline";
            bloodline6.base_stats = new BaseStats();
            bloodline6.base_stats[S.lifespan] = 50f;//寿命
            bloodline6.base_stats[S.multiplier_damage] = 7f;//伤害
            bloodline6.base_stats[S.multiplier_health] = 3f;//血量
            bloodline6.base_stats[S.attack_speed] = 150f;//攻速
            bloodline6.base_stats[S.speed] = 150f;//速度
            bloodline6.base_stats[S.armor] = 10f;//防御
            bloodline6.base_stats[S.critical_chance] = 1f;//暴击%
            bloodline6.base_stats[S.range] = 20f;//射程
            bloodline6.base_stats[S.area_of_effect] = 10f;//近战范围
            bloodline6.base_stats[S.targets] = 10f;//可攻击目标
            bloodline6.base_stats[S.knockback] = 0.10f;//击退
            bloodline6.action_attack_target += new AttackAction((traitAction.attack_bloodline6));
            bloodline6.action_special_effect += traitAction.brokenProof1;
            AssetManager.traits.add(bloodline6);

            ActorTrait bloodline7 = new ActorTrait();
            bloodline7.id = "bloodline7";//不灭血脉
            bloodline7.path_icon = "trait/bloodline7";
            bloodline7.needs_to_be_explored = false;
            bloodline7.rate_inherit = 50;
            bloodline7.group_id = "bloodline";
            bloodline7.base_stats = new BaseStats();
            bloodline7.base_stats[S.lifespan] = 200f;//寿命
            bloodline7.base_stats[S.multiplier_damage] = 1f;//伤害
            bloodline7.base_stats[S.multiplier_health] = 20f;//血量
            bloodline7.base_stats[S.attack_speed] = 10f;//攻速
            bloodline7.base_stats[S.speed] = 10f;//速度
            bloodline7.base_stats[S.armor] = 80f;//防御
            bloodline7.base_stats[S.critical_chance] = 0.10f;//暴击%
            bloodline7.base_stats[S.range] = 1f;//射程
            bloodline7.base_stats[S.area_of_effect] = 2f;//近战范围
            bloodline7.base_stats[S.targets] = 2f;//可攻击目标
            bloodline7.base_stats[S.knockback] = 0.50f;//击退
            bloodline7.action_special_effect += (WorldAction)Delegate.Combine(bloodline7.action_special_effect,
                new WorldAction(traitAction.attack_bloodline7)); //再生效果
            AssetManager.traits.add(bloodline7);

            ActorTrait bloodline8 = new ActorTrait();
            bloodline8.id = "bloodline8";//中枢血脉
            bloodline8.path_icon = "trait/bloodline8";
            bloodline8.needs_to_be_explored = false;
            bloodline8.rate_inherit = 50;
            bloodline8.group_id = "bloodline";
            bloodline8.base_stats = new BaseStats();
            bloodline8.base_stats[S.lifespan] = 200f;//寿命
            bloodline8.base_stats[S.multiplier_damage] = 1f;//伤害
            bloodline8.base_stats[S.multiplier_health] = 1f;//血量
            bloodline8.base_stats[S.attack_speed] = 10f;//攻速
            bloodline8.base_stats[S.speed] = 10f;//速度
            bloodline8.base_stats[S.armor] = 10f;//防御
            bloodline8.base_stats[S.critical_chance] = 0.10f;//暴击%
            bloodline8.base_stats[S.range] = 1f;//射程
            bloodline8.base_stats[S.area_of_effect] = 1f;//近战范围
            bloodline8.base_stats[S.targets] = 1f;//可攻击目标
            bloodline8.base_stats[S.knockback] = 0.10f;//击退
            bloodline8.base_stats[S.intelligence] = 200f;//智力
            bloodline8.base_stats[S.warfare] = 200f;//管理
            bloodline8.base_stats[S.stewardship] = 200f;//军事
            bloodline8.base_stats[S.cities] = 200f;//管理城市
            bloodline8.action_attack_target += new AttackAction((traitAction.attack_bloodline8));
            bloodline8.action_special_effect += traitAction.brokenProof1;
            AssetManager.traits.add(bloodline8);

            ActorTrait bloodline9 = new ActorTrait();
            bloodline9.id = "bloodline9";//审判血脉
            bloodline9.path_icon = "trait/bloodline9";
            bloodline9.needs_to_be_explored = false;
            bloodline9.rate_inherit = 50;
            bloodline9.group_id = "bloodline";
            bloodline9.base_stats = new BaseStats();
            bloodline9.base_stats[S.lifespan] = 50f;//寿命
            bloodline9.base_stats[S.multiplier_damage] = 10f;//伤害
            bloodline9.base_stats[S.multiplier_health] = 1f;//血量
            bloodline9.base_stats[S.attack_speed] = 100f;//攻速
            bloodline9.base_stats[S.speed] = 10f;//速度
            bloodline9.base_stats[S.armor] = 20f;//防御
            bloodline9.base_stats[S.critical_chance] = 3f;//暴击%
            bloodline9.base_stats[S.range] = 30f;//射程
            bloodline9.base_stats[S.area_of_effect] = 1f;//近战范围
            bloodline9.base_stats[S.targets] = 1f;//可攻击目标
            bloodline9.base_stats[S.knockback] = 1f;//击退
            bloodline9.action_attack_target += new AttackAction((traitAction.attack_bloodline9));
            bloodline9.action_special_effect += traitAction.brokenProof1;
            AssetManager.traits.add(bloodline9);

            ActorTrait bloodline10 = new ActorTrait();
            bloodline10.id = "bloodline10";//长生血脉
            bloodline10.path_icon = "trait/bloodline10";
            bloodline10.needs_to_be_explored = false;
            bloodline10.rate_inherit = 50;
            bloodline10.group_id = "bloodline";
            bloodline10.base_stats = new BaseStats();
            bloodline10.base_stats[S.lifespan] = 1000f;//寿命
            bloodline10.base_stats[S.multiplier_damage] = 1f;//伤害
            bloodline10.base_stats[S.multiplier_health] = 1f;//血量
            bloodline10.base_stats[S.attack_speed] = 10f;//攻速
            bloodline10.base_stats[S.speed] = 40f;//速度
            bloodline10.base_stats[S.armor] = 40f;//防御
            bloodline10.base_stats[S.critical_chance] = 0.1f;//暴击%
            bloodline10.base_stats[S.range] = 1f;//射程
            bloodline10.base_stats[S.area_of_effect] = 1f;//近战范围
            bloodline10.base_stats[S.targets] = 1f;//可攻击目标
            bloodline10.base_stats[S.knockback] = 1f;//击退
            bloodline10.action_special_effect += traitAction.brokenProof3;
            AssetManager.traits.add(bloodline10);

            ActorTrait bloodline11 = new ActorTrait();
            bloodline11.id = "bloodline11";//诅咒血脉
            bloodline11.path_icon = "trait/bloodline11";
            bloodline11.needs_to_be_explored = false;
            bloodline11.rate_inherit = 50;
            bloodline11.group_id = "bloodline";
            bloodline11.base_stats = new BaseStats();
            bloodline11.base_stats[S.lifespan] = 50f;//寿命
            bloodline11.base_stats[S.multiplier_damage] = 3f;//伤害
            bloodline11.base_stats[S.multiplier_health] = 4f;//血量
            bloodline11.base_stats[S.attack_speed] = 10f;//攻速
            bloodline11.base_stats[S.speed] = 10f;//速度
            bloodline11.base_stats[S.armor] = 50f;//防御
            bloodline11.base_stats[S.critical_chance] = 0.4f;//暴击%
            bloodline11.base_stats[S.range] = 3f;//射程
            bloodline11.base_stats[S.area_of_effect] = 1f;//近战范围
            bloodline11.base_stats[S.targets] = 1f;//可攻击目标
            bloodline11.base_stats[S.knockback] = 1f;//击退
            bloodline11.action_attack_target += new AttackAction((traitAction.attack_bloodline11));
            bloodline11.action_special_effect += traitAction.brokenProof4;
            AssetManager.traits.add(bloodline11);

            ActorTrait bloodline12 = new ActorTrait();
            bloodline12.id = "bloodline12";//神性血脉
            bloodline12.path_icon = "trait/bloodline12";
            bloodline12.needs_to_be_explored = false;
            bloodline12.rate_inherit = 1;
            bloodline12.group_id = "bloodline";
            bloodline12.base_stats = new BaseStats();
            bloodline12.base_stats[S.lifespan] = 2400f;//寿命
            bloodline12.base_stats[S.multiplier_damage] = 30f;//伤害
            bloodline12.base_stats[S.multiplier_health] = 40f;//血量
            bloodline12.base_stats[S.attack_speed] = 100f;//攻速
            bloodline12.base_stats[S.speed] = 100f;//速度
            bloodline12.base_stats[S.armor] = 500f;//防御
            bloodline12.base_stats[S.critical_chance] = 4f;//暴击%
            bloodline12.base_stats[S.range] = 100f;//射程
            bloodline12.base_stats[S.area_of_effect] = 100f;//近战范围
            bloodline12.base_stats[S.targets] = 100f;//可攻击目标
            bloodline12.base_stats[S.knockback] = 1f;//击退
            bloodline12.action_special_effect += traitAction.brokenProof3; 
            AssetManager.traits.add(bloodline12);

            //传承法
            ActorTrait inherit1 = new ActorTrait();
            inherit1.id = "inherit1";//锻骨术
            inherit1.path_icon = "trait/inherit1";
            inherit1.needs_to_be_explored = false;
            inherit1.rate_inherit = 100;
            inherit1.group_id = "inherit";
            inherit1.base_stats = new BaseStats();
            inherit1.base_stats[S.armor] = 10f;//防御
            inherit1.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit1.base_stats[S.multiplier_health] = 0.50f;//生命值%
            AssetManager.traits.add(inherit1);

            ActorTrait inherit2 = new ActorTrait();
            inherit2.id = "inherit2";//炼皮术
            inherit2.path_icon = "trait/inherit2";
            inherit2.needs_to_be_explored = false;
            inherit2.rate_inherit = 100;
            inherit2.group_id = "inherit";
            inherit2.base_stats = new BaseStats();
            inherit2.base_stats[S.armor] = 20f;//防御
            inherit2.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit2.base_stats[S.multiplier_health] = 1f;//生命值%
            AssetManager.traits.add(inherit2);

            ActorTrait inherit3 = new ActorTrait();
            inherit3.id = "inherit3";//体术
            inherit3.path_icon = "trait/inherit3";
            inherit3.needs_to_be_explored = false;
            inherit3.rate_inherit = 100;
            inherit3.group_id = "inherit";
            inherit3.base_stats = new BaseStats();
            inherit3.base_stats[S.armor] = 10f;//防御
            inherit3.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit3.base_stats[S.multiplier_health] = 0.30f;//生命值%
            inherit3.base_stats[S.attack_speed] = 20f;//攻速
            inherit3.base_stats[S.critical_chance] = 0.30f;//暴击%
            AssetManager.traits.add(inherit3);

            ActorTrait inherit4 = new ActorTrait();
            inherit4.id = "inherit4";//疾风剑法
            inherit4.path_icon = "trait/inherit4";
            inherit4.needs_to_be_explored = false;
            inherit4.rate_inherit = 100;
            inherit4.group_id = "inherit";
            inherit4.base_stats = new BaseStats();
            inherit4.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit4.base_stats[S.attack_speed] = 50f;//攻速
            inherit4.base_stats[S.critical_chance] = 1f;//暴击%
            AssetManager.traits.add(inherit4);

            ActorTrait inherit5 = new ActorTrait();
            inherit5.id = "inherit5";//骑士之力
            inherit5.path_icon = "trait/inherit5";
            inherit5.needs_to_be_explored = false;
            inherit5.rate_inherit = 100;
            inherit5.group_id = "inherit";
            inherit5.base_stats = new BaseStats();
            inherit5.base_stats[S.armor] = 10f;//防御
            inherit5.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit5.base_stats[S.multiplier_health] = 1.5f;//生命值%
            AssetManager.traits.add(inherit5); 

            ActorTrait inherit6 = new ActorTrait();
            inherit6.id = "inherit6";//引雷剑法
            inherit6.path_icon = "trait/inherit6";
            inherit6.needs_to_be_explored = false;
            inherit6.rate_inherit = 100;
            inherit6.group_id = "inherit";
            inherit6.base_stats = new BaseStats();
            inherit6.base_stats[S.multiplier_damage] = 1f;//伤害%
            inherit6.base_stats[S.attack_speed] = 20f;//攻速
            inherit6.base_stats[S.critical_chance] = 1f;//暴击%
            inherit6.action_attack_target += new AttackAction((traitAction.attack_inherit6));
            AssetManager.traits.add(inherit6);

            ActorTrait inherit7 = new ActorTrait();
            inherit7.id = "inherit7";//霸道剑法
            inherit7.path_icon = "trait/inherit7";
            inherit7.needs_to_be_explored = false;
            inherit7.rate_inherit = 100;
            inherit7.group_id = "inherit";
            inherit7.base_stats = new BaseStats();
            inherit7.base_stats[S.multiplier_damage] = 2f;//伤害%
            inherit7.base_stats[S.critical_chance] = 1f;//暴击%
            AssetManager.traits.add(inherit7);

            ActorTrait inherit8 = new ActorTrait();
            inherit8.id = "inherit8";//剑气
            inherit8.path_icon = "trait/inherit8";
            inherit8.needs_to_be_explored = false;
            inherit8.rate_inherit = 100;
            inherit8.group_id = "inherit";
            inherit8.base_stats = new BaseStats();
            inherit8.base_stats[S.multiplier_damage] = 2f;//伤害%
            inherit8.base_stats[S.critical_chance] = 1f;//暴击%
            inherit8.action_attack_target += new AttackAction((traitAction.attack_inherit8));
            AssetManager.traits.add(inherit8);

            ActorTrait inherit9 = new ActorTrait();
            inherit9.id = "inherit9";
            inherit9.path_icon = "trait/inherit9";
            inherit9.needs_to_be_explored = false;
            inherit9.rate_inherit = 100;
            inherit9.group_id = "inherit";
            inherit9.base_stats = new BaseStats();
            inherit9.base_stats[S.multiplier_lifespan] = -0.2f;//寿命
            AssetManager.traits.add(inherit9);

            ActorTrait inherit10 = new ActorTrait();
            inherit10.id = "inherit10";
            inherit10.path_icon = "trait/inherit10";
            inherit10.needs_to_be_explored = false;
            inherit10.rate_inherit = 100;
            inherit10.group_id = "inherit";
            inherit10.base_stats = new BaseStats();
            AssetManager.traits.add(inherit10);

            ActorTrait inherit11 = new ActorTrait();
            inherit11.id = "inherit11";//神性气息
            inherit11.path_icon = "trait/inherit11";
            inherit11.needs_to_be_explored = false;
            inherit11.rate_inherit = 100;
            inherit11.group_id = "inherit";
            inherit11.base_stats = new BaseStats();
            inherit11.base_stats[S.multiplier_damage] = 20f;//伤害%
            inherit11.base_stats[S.critical_chance] = 10f;//暴击%
            inherit11.base_stats[S.attack_speed] = 200f;//攻速
            AssetManager.traits.add(inherit11);

            //神性
            ActorTrait godhead1 = new ActorTrait();
            godhead1.id = "godhead1";//神性•原初
            godhead1.path_icon = "trait/godhead1";
            godhead1.needs_to_be_explored = false;
            godhead1.group_id = "godhead";
            godhead1.base_stats = new BaseStats();
            godhead1.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead1.base_stats[S.multiplier_health] = 100f;//血量%
            godhead1.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead1.base_stats[S.critical_chance] = 5000f;//暴击% 
            godhead1.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead1.base_stats[S.accuracy] = 100f;
            godhead1.action_special_effect += traitAction.brokenProof6;
            godhead1.action_special_effect += (WorldAction)Delegate.Combine(godhead1.action_special_effect,
                new WorldAction(traitAction.attack_godhead1)); //再生效果
            AssetManager.traits.add(godhead1);

            ActorTrait godhead2 = new ActorTrait();
            godhead2.id = "godhead2";//神性•终焉
            godhead2.path_icon = "trait/godhead2";
            godhead2.needs_to_be_explored = false;
            godhead2.group_id = "godhead";
            godhead2.base_stats = new BaseStats();
            godhead2.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead2.base_stats[S.multiplier_health] = 100f;//血量%
            godhead2.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead2.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead2.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead2.base_stats[S.accuracy] = 100f;
            godhead2.action_special_effect += traitAction.brokenProof6;
            godhead2.action_attack_target += traitAction.warfare_attack_godhead2;
            AssetManager.traits.add(godhead2);

            ActorTrait godhead3 = new ActorTrait();
            godhead3.id = "godhead3";//神性•永劫轮回
            godhead3.path_icon = "trait/godhead3";
            godhead3.needs_to_be_explored = false;
            godhead3.group_id = "godhead";
            godhead3.base_stats = new BaseStats();
            godhead3.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead3.base_stats[S.multiplier_health] = 100f;//血量%
            godhead3.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead3.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead3.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率
            godhead3.base_stats[S.accuracy] = 100f;
            godhead3.action_special_effect += traitAction.brokenProof6;
            godhead3.action_death = traitAction.godhead3_death;
            AssetManager.traits.add(godhead3);

            ActorTrait godhead4 = new ActorTrait();
            godhead4.id = "godhead4";//神性•权柄
            godhead4.path_icon = "trait/godhead4";
            godhead4.needs_to_be_explored = false;
            godhead4.group_id = "godhead";
            godhead4.base_stats = new BaseStats();
            godhead4.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead4.base_stats[S.multiplier_health] = 100f;//血量%
            godhead4.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead4.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead4.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率
            godhead4.base_stats[S.accuracy] = 100f;
            godhead4.action_special_effect += traitAction.brokenProof6;
            godhead4.action_attack_target += new AttackAction((traitAction.attack_godhead4));
            AssetManager.traits.add(godhead4);

            ActorTrait godhead5 = new ActorTrait();
            godhead5.id = "godhead5";//神性•太极
            godhead5.path_icon = "trait/godhead5";
            godhead5.needs_to_be_explored = false;
            godhead5.group_id = "godhead";
            godhead5.base_stats = new BaseStats();
            godhead5.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead5.base_stats[S.multiplier_health] = 100f;//血量%
            godhead5.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead5.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead5.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead5.base_stats[S.accuracy] = 100f;
            godhead5.action_special_effect += traitAction.brokenProof6;
            godhead5.action_attack_target += new AttackAction((traitAction.attack_godhead5));
            AssetManager.traits.add(godhead5);  

            ActorTrait godhead6 = new ActorTrait();
            godhead6.id = "godhead6";//神性•全知
            godhead6.path_icon = "trait/godhead6";
            godhead6.needs_to_be_explored = false;
            godhead6.group_id = "godhead";
            godhead6.base_stats = new BaseStats();
            godhead6.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead6.base_stats[S.multiplier_health] = 100f;//血量%
            godhead6.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead6.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead6.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead6.base_stats[S.range] = float.PositiveInfinity;//射程
            godhead6.base_stats[S.area_of_effect] = float.PositiveInfinity;//近战范围
            godhead6.base_stats[S.targets] = float.PositiveInfinity;//可攻击目标
            godhead6.base_stats[S.intelligence] = float.PositiveInfinity;//智力
            godhead6.base_stats[S.warfare] = float.PositiveInfinity;//管理
            godhead6.base_stats[S.stewardship] = float.PositiveInfinity;//军事
            godhead6.base_stats[S.cities] = float.PositiveInfinity;//管理城市
            godhead6.base_stats[S.accuracy] = 100f;
            godhead6.action_special_effect += traitAction.brokenProof6;
            AssetManager.traits.add(godhead6);

            ActorTrait godhead7 = new ActorTrait();
            godhead7.id = "godhead7";//神性•伟力
            godhead7.path_icon = "trait/godhead7";
            godhead7.needs_to_be_explored = false;
            godhead7.group_id = "godhead";
            godhead7.base_stats = new BaseStats();
            godhead7.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead7.base_stats[S.multiplier_health] = 100f;//血量%
            godhead7.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead7.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead7.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead7.base_stats[S.accuracy] = 100f;
            godhead7.action_special_effect += traitAction.brokenProof6;
            godhead7.action_attack_target += new AttackAction((traitAction.attack_godhead7));
            AssetManager.traits.add(godhead7);

            ActorTrait godhead8 = new ActorTrait();
            godhead8.id = "godhead8";//神性•三相
            godhead8.path_icon = "trait/godhead8";
            godhead8.needs_to_be_explored = false;
            godhead8.group_id = "godhead";
            godhead8.base_stats = new BaseStats();
            godhead8.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead8.base_stats[S.multiplier_health] = 100f;//血量%
            godhead8.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead8.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead8.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead8.base_stats[S.accuracy] = 100f;
            godhead8.action_special_effect += traitAction.brokenProof6;
            godhead8.action_attack_target += new AttackAction((traitAction.attack_godhead8));
            AssetManager.traits.add(godhead8);

            ActorTrait godhead9 = new ActorTrait();
            godhead9.id = "godhead9";//神性•重启
            godhead9.path_icon = "trait/godhead9";
            godhead9.needs_to_be_explored = false;
            godhead9.group_id = "godhead";
            godhead9.base_stats = new BaseStats();
            godhead9.base_stats[S.lifespan] = float.PositiveInfinity;//无限寿命
            godhead9.base_stats[S.multiplier_health] = 100f;//血量%
            godhead9.base_stats[S.multiplier_damage] = 100f;//伤害%
            godhead9.base_stats[S.critical_chance] = 5000f;//暴击%
            godhead9.base_stats[S.critical_damage_multiplier] = 5000f;//暴击伤害倍率 
            godhead9.base_stats[S.accuracy] = 100f;
            godhead9.action_special_effect += traitAction.brokenProof6;
            godhead9.action_attack_target += new AttackAction((traitAction.attack_godhead9));
            AssetManager.traits.add(godhead9);

            //传承兵器
            ActorTrait arms1 = new ActorTrait();
            arms1.id = "arms1";//雷鸣长弓
            arms1.path_icon = "trait/arms1";
            arms1.needs_to_be_explored = false;
            arms1.group_id = "arms";
            arms1.base_stats = new BaseStats();
            arms1.rate_inherit = 100;//遗传率
            arms1.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms1);

            ActorTrait arms2 = new ActorTrait();
            arms2.id = "arms2";//轰击大地的重锤
            arms2.path_icon = "trait/arms2";
            arms2.needs_to_be_explored = false;
            arms2.group_id = "arms";
            arms2.base_stats = new BaseStats();
            arms2.rate_inherit = 100;//遗传率
            arms2.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms2);

            ActorTrait arms3 = new ActorTrait();
            arms3.id = "arms3";//超重力剑
            arms3.path_icon = "trait/arms3";
            arms3.needs_to_be_explored = false;
            arms3.group_id = "arms";
            arms3.base_stats = new BaseStats();
            arms3.rate_inherit = 100;//遗传率
            arms3.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms3);

            ActorTrait arms4 = new ActorTrait();
            arms4.id = "arms4";//风暴战斧
            arms4.path_icon = "trait/arms4";
            arms4.needs_to_be_explored = false;
            arms4.group_id = "arms";
            arms4.base_stats = new BaseStats();
            arms4.rate_inherit = 100;//遗传率
            arms4.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms4);

            ActorTrait arms5 = new ActorTrait();
            arms5.id = "arms5";//划分善恶的长枪
            arms5.path_icon = "trait/arms5";
            arms5.needs_to_be_explored = false;
            arms5.group_id = "arms";
            arms5.base_stats = new BaseStats();
            arms5.rate_inherit = 100;//遗传率
            arms5.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms5);  

            ActorTrait arms6 = new ActorTrait();
            arms6.id = "arms6";//骑士之誓
            arms6.path_icon = "trait/arms6";
            arms6.needs_to_be_explored = false;
            arms6.group_id = "arms";
            arms6.base_stats = new BaseStats();
            arms6.rate_inherit = 100;//遗传率 
            arms6.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms6);

            ActorTrait arms7 = new ActorTrait();
            arms7.id = "arms7";//骑士之盔
            arms7.path_icon = "trait/arms7";
            arms7.needs_to_be_explored = false;
            arms7.group_id = "arms";
            arms7.base_stats = new BaseStats();
            arms7.rate_inherit = 100;//遗传率 
            arms7.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms7);

            ActorTrait arms8 = new ActorTrait();
            arms8.id = "arms8";//骑士之铠甲
            arms8.path_icon = "trait/arms8";
            arms8.needs_to_be_explored = false;
            arms8.group_id = "arms";
            arms8.base_stats = new BaseStats();
            arms8.rate_inherit = 100;//遗传率
            arms8.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(arms8);

            //传说
            ActorTrait Legend1 = new ActorTrait();
            Legend1.id = "Legend1";//传说中的长弓
            Legend1.path_icon = "trait/Legend1";
            Legend1.needs_to_be_explored = false;
            Legend1.group_id = "Legend";
            Legend1.base_stats = new BaseStats();
            Legend1.action_special_effect = new WorldAction(endow.godGiveWeapon);
            AssetManager.traits.add(Legend1);

            //功能性特质
            ActorTrait function1 = new ActorTrait();
            function1.id = "function1";//嗜血观众制造机
            function1.path_icon = "trait/function1";
            function1.needs_to_be_explored = false;
            function1.group_id = "function";
            function1.base_stats = new BaseStats();
            function1.base_stats[S.birth_rate] = 1000000000f;//出生率
            function1.base_stats[S.offspring] = 1000000000f;//后代
            AssetManager.traits.add(function1);

            ActorTrait function2 = new ActorTrait();
            function2.id = "function2";//嗜血观众制造机(可遗传版)
            function2.path_icon = "trait/function2";
            function2.needs_to_be_explored = false;
            function2.rate_inherit = 100;
            function2.group_id = "function";
            function2.base_stats = new BaseStats();
            function2.base_stats[S.birth_rate] = 1000000000f;//出生率
            function2.base_stats[S.offspring] = 1000000000f;//后代
            AssetManager.traits.add(function2);

            ActorTrait function3 = new ActorTrait();
            function3.id = "function3";
            function3.path_icon = "trait/function3";
            function3.needs_to_be_explored = false;
            function3.group_id = "function";
            function3.base_stats = new BaseStats();
            AssetManager.traits.add(function3);

            ActorTrait function4 = new ActorTrait();
            function4.id = "function4";
            function4.path_icon = "trait/function4";
            function4.needs_to_be_explored = false;
            function4.group_id = "function";
            function4.base_stats = new BaseStats();
            AssetManager.traits.add(function4);
        }
    }
}