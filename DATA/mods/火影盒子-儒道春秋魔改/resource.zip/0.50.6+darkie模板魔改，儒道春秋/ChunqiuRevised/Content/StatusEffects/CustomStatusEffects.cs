﻿using Chunqiu;
using Chunqiu.Content;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace ChunqiuRevised.Content.StatusEffects
{
    public class CustomStatusEffects
    {
        public const string Identifier = ChunqiuMain.Identifier; //Ensure mod compatibility

        [Hotfixable]
        public static void Init()
        {
            loadCustomStatusEffects();
        }

        private static void loadCustomStatusEffects()
        {
            //Needed this material for status effects
            Material material = LibraryMaterials.instance.dict["mat_world_object_lit"];

            #region xuanwo1_effect
            var lingqixuanEffect = new StatusAsset()
            {
                id = $"{Identifier}_xuanwo1_effect",
                render_priority = 5,
                duration = 7f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_xuanwo1", // Make sure this folder exists in effects/
                path_icon = "ui/Icons/iconLingqi",
            };

            lingqixuanEffect.locale_id = $"status_title_{lingqixuanEffect.id}";
            lingqixuanEffect.locale_description = $"status_description_{lingqixuanEffect.id}";

            lingqixuanEffect.base_stats = new();
            lingqixuanEffect.base_stats.set(CustomBaseStatsConstant.AttackSpeed, -1000f);
            lingqixuanEffect.base_stats.set(CustomBaseStatsConstant.Speed, -1000f);

            lingqixuanEffect.action_on_receive = (WorldAction)Delegate.Combine(lingqixuanEffect.action_on_receive, new WorldAction(CustomStatusEffectAction.stopMovingAndMakeWait));


            lingqixuanEffect.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{lingqixuanEffect.texture}", false);

            AssetManager.status.add(lingqixuanEffect);
            addToLocale(lingqixuanEffect.id, "灵力漩涡", "被灵气的风暴撕碎吧!");
            #endregion

            #region xuwuyehuo_effect
            var xuwuyehuoEffect = new StatusAsset()
            {
                id = $"{Identifier}_xuwuyehuo_effect",
                render_priority = 5,
                duration = 999f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_xuwuyehuo_effect", // Make sure this folder exists in effects/
                path_icon = "ui/Icons/iconXuwuyehuo",
            };

            xuwuyehuoEffect.locale_id = $"status_title_{xuwuyehuoEffect.id}";
            xuwuyehuoEffect.locale_description = $"status_description_{xuwuyehuoEffect.id}";

            xuwuyehuoEffect.base_stats = new();
            xuwuyehuoEffect.base_stats.set(CustomBaseStatsConstant.AttackSpeed, -1000f);
            xuwuyehuoEffect.base_stats.set(CustomBaseStatsConstant.Speed, -1000f);

            xuwuyehuoEffect.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{xuwuyehuoEffect.texture}", false);

            xuwuyehuoEffect.action_on_receive = (WorldAction)Delegate.Combine(xuwuyehuoEffect.action_on_receive, new WorldAction(CustomStatusEffectAction.xuwuyehuoSpecialEffect));

            AssetManager.status.add(xuwuyehuoEffect);
            addToLocale(xuwuyehuoEffect.id, "Xuwuyehuo", "虚无业火, 焚尽一切!");
            #endregion

            #region jxsq_effect
            var jxsqEffect = new StatusAsset()
            {
                id = $"{Identifier}_jxsq_effect",
                render_priority = 5,
                duration = 999f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = false,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_jxsq_effect", // Make sure this folder exists in effects/
                path_icon = "ui/Icons/iconJxsq",
            };

            jxsqEffect.locale_id = $"status_title_{jxsqEffect.id}";
            jxsqEffect.locale_description = $"status_description_{jxsqEffect.id}";

            jxsqEffect.base_stats = new();
            jxsqEffect.base_stats.set(CustomBaseStatsConstant.Armor, 100f);

            jxsqEffect.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{jxsqEffect.texture}", false);


            AssetManager.status.add(jxsqEffect);
            addToLocale(jxsqEffect.id, "聚形散气", "化身元气!");
            #endregion


            #region yunqi_effect
            var yunqiEffect = new StatusAsset()
            {
                id = $"{Identifier}_yunqi_effect",
                render_priority = 5,
                duration = 999f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = false,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_yunqi_effect", // Make sure this folder exists in effects/
                path_icon = "ui/Icons/iconYunqi",
            };

            yunqiEffect.locale_id = $"status_title_{yunqiEffect.id}";
            yunqiEffect.locale_description = $"status_description_{yunqiEffect.id}";

            yunqiEffect.base_stats = new();
            yunqiEffect.base_stats.set(CustomBaseStatsConstant.Armor, 100f);

            yunqiEffect.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{yunqiEffect.texture}", false);


            AssetManager.status.add(yunqiEffect);
            addToLocale(yunqiEffect.id, "气运", "气运护体!");
            #endregion

            #region yinyangdao_effect
            var yinyang = new StatusAsset()
            {
                id = $"{Identifier}_yinyang_effect",
                render_priority = 5,
                duration = 1f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = false,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_yinyangdao_effect",
                path_icon = "ui/Icons/iconYinyang",
            };

            yinyang.locale_id = $"status_title_{yinyang.id}";
            yinyang.locale_description = $"status_description_{yinyang.id}";

            yinyang.base_stats = new();
            yinyang.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
            yinyang.base_stats.set(CustomBaseStatsConstant.Mass, 100f);
            yinyang.base_stats.set(CustomBaseStatsConstant.Damage, 25f);
            yinyang.opposite_status = new[] { xuwuyehuoEffect.id };


            yinyang.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{yinyang.texture}", false);

            AssetManager.status.add(yinyang);
            addToLocale(yinyang.id, "阴阳道", "二气演造化");
            #endregion

            #region wuxingdao_effect
            var wuxing = new StatusAsset()
            {
                id = $"{Identifier}_wuxingdao_effect",
                render_priority = 5,
                duration = 1f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_wuxing_effect",
                path_icon = "ui/Icons/iconWuxing",
            };

            wuxing.locale_id = $"status_title_{wuxing.id}";
            wuxing.locale_description = $"status_description_{wuxing.id}";

            wuxing.base_stats = new();
            wuxing.base_stats.set(CustomBaseStatsConstant.Scale, 0.01f);
            wuxing.base_stats.set(CustomBaseStatsConstant.Knockback, 10f);
            wuxing.opposite_status = new[] { xuwuyehuoEffect.id };

            wuxing.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{wuxing.texture}", false);

            AssetManager.status.add(wuxing);
            addToLocale(wuxing.id, "五行道", "阴阳衍五行");
            #endregion

            #region wuse_shield_effect
            var wuseShield = new StatusAsset()
            {
                id = $"{Identifier}_wuse_shield_effect",
                render_priority = 5,
                duration = 1f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_wuse_shield_effect",
                path_icon = "ui/Icons/iconWuseShield",
            };

            wuseShield.locale_id = $"status_title_{wuseShield.id}";
            wuseShield.locale_description = $"status_description_{wuseShield.id}";

            wuseShield.base_stats = new();
            wuseShield.base_stats.set(CustomBaseStatsConstant.Armor, 25f);
            wuseShield.base_stats.set(CustomBaseStatsConstant.Scale, 0.01f);
            wuseShield.opposite_status = new[] { xuwuyehuoEffect.id };

            wuseShield.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{wuseShield.texture}", false);

            AssetManager.status.add(wuseShield);
            addToLocale(wuseShield.id, "五色盾阵", "五行护盾之阵");
            #endregion

            #region god_pill_effect
            var godpill = new StatusAsset()
            {
                id = $"{Identifier}_god_pill_effect",
                render_priority = 5,
                duration = 1f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_god_pill_effect",
                path_icon = "ui/Icons/iconGodpill",
            };

            godpill.locale_id = $"status_title_{godpill.id}";
            godpill.locale_description = $"status_description_{godpill.id}";

            godpill.base_stats = new();
            godpill.base_stats.set(CustomBaseStatsConstant.Armor, 25f);
            godpill.base_stats.set(CustomBaseStatsConstant.Mass, 100f);
            godpill.opposite_status = new[] { xuwuyehuoEffect.id };

            godpill.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{godpill.texture}", false);

            AssetManager.status.add(godpill);
            addToLocale(godpill.id, "湛蓝仙丸", "仙人在上");
            #endregion

            #region wuyue1_effect
            var qilinshanEffect = new StatusAsset()
            {
                id = $"{Identifier}_qilinshan_effect",
                render_priority = 5,
                duration = 15f,
                animated = true,
                is_animated_in_pause = true,
                can_be_flipped = true,
                use_parent_rotation = false,
                removed_on_damage = false,
                cancel_actor_job = true,
                need_visual_render = true,
                scale = 1.0f,
                tier = StatusTier.Advanced,
                material_id = "mat_world_object_lit",
                material = material,
                texture = "fx_wuyue_1_effect",
                path_icon = "ui/Icons/iconWuyue",
            };

            qilinshanEffect.locale_id = $"status_title_{qilinshanEffect.id}";
            qilinshanEffect.locale_description = $"status_description_{qilinshanEffect.id}";

            qilinshanEffect.base_stats = new();
            qilinshanEffect.base_stats.set(CustomBaseStatsConstant.Health, -100f);
            qilinshanEffect.base_stats.set(CustomBaseStatsConstant.Speed, -999f);
            qilinshanEffect.base_stats.set(CustomBaseStatsConstant.AttackSpeed, -999f);
            qilinshanEffect.base_stats.set(CustomBaseStatsConstant.Damage, -300f);

            qilinshanEffect.action_on_receive = (WorldAction)Delegate.Combine(qilinshanEffect.action_on_receive, new WorldAction(StatusLibrary.poisonedEffect));

            qilinshanEffect.sprite_list = SpriteTextureLoader.getSpriteList($"effects/{qilinshanEffect.texture}", false);

            AssetManager.status.add(qilinshanEffect);
            addToLocale(qilinshanEffect.id, "麒麟镇岳", "勾陈敕命，五岳同镇");
            #endregion

        }

        private static void addToLocale(string id, string name, string description)
        {
            LM.AddToCurrentLocale($"status_title_{id}", name);
            LM.AddToCurrentLocale($"status_description_{id}", description);
        }
    }
}
