using ai;
using HarmonyLib.Tools;
using Chunqiu;
using Chunqiu.Content;
using ChunqiuRevised.Content.Config;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using UnityEngine;
using static UnityEngine.EventSystems.EventTrigger;
using static UnityEngine.GraphicsBuffer;
using static UnityEngine.UI.CanvasScaler;

namespace ChunqiuRevised.Content.Traits;

internal static class CustomTraitActions
{
    #region special effects
    public static bool leoinClanAwakeningSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        if (pTarget.a.hasTrait($"{ChunqiuMain.Identifier}_lionstyle") || pTarget.a.hasTrait($"{ChunqiuMain.Identifier}_ranksigma"))
            return false;
        //Awaken age range
        if (pTarget.a.data.getAge() > 15 && pTarget.a.data.getAge() <= 40)
        {
            if (Randy.randomChance(0.005f) || pTarget.a.data.health < pTarget.a.getMaxHealth() / 10 || pTarget.a.data.kills > 15)
            {
                pTarget.a.addTrait($"{ChunqiuMain.Identifier}_lionstyle");
                pTarget.a.data.health += 1200;
                return true;
            }
        }

        //Healing
        if (Randy.randomChance(0.1f) && pTarget.a.data.health < pTarget.a.getMaxHealth() / 5)
        {
            pTarget.a.restoreHealth(10);
            pTarget.a.spawnParticle(Toolbox.color_heal);
            pTarget.a.spawnParticle(Toolbox.color_heal);
            pTarget.a.spawnParticle(Toolbox.color_heal);
        }

        if (ChunqiuConfig.EnableClanFamilyName && !pTarget.a.getName().Contains("leoin", StringComparison.OrdinalIgnoreCase))
        {
            //Add prefix clan name: leoin
            renameToClanName(LM.Get("leoin"), pTarget);
        }
        return false;
    }

    internal static bool xinruEvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill two enemies
        if (actor.data.kills >= 2 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru2"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3"); // Safety: if somehow higher already
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");


            actor.addTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool xinru2EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 8 enemies
        if (actor.data.kills >= 8 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru3"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool xinru3EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 20 enemies
        // Promote to Jonin
        if (actor.data.kills >= 20 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru4"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");

            actor.addTrait($"{ChunqiuMain.Identifier}_xinru4");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool xinru4EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 50 enemies and level 5 above
        if (actor.data.kills >= 50 && actor.data.level >=5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru5"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_xinru5");
            actor.data.health += 300;
        }
        return true;
    }

    internal static bool xinru5SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 80 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru6"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru5");
            actor.addTrait($"{ChunqiuMain.Identifier}_xinru6");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool xinru6SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 100 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru7"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru6");
            actor.addTrait($"{ChunqiuMain.Identifier}_xinru7");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool xinru7SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 150 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru8"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru7");
            actor.addTrait($"{ChunqiuMain.Identifier}_xinru8");
            actor.data.health += 900;
        }
        return true;
    }


    internal static bool xinru8SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 200 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_xinru9"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru7");
            actor.removeTrait($"{ChunqiuMain.Identifier}_xinru8");
            actor.addTrait($"{ChunqiuMain.Identifier}_xinru9");
            actor.data.health += 900;
        }
        return true;
    }

    internal static bool xinru9SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        return true;
    }
    internal static bool liruEvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill two enemies
        if (actor.data.kills >= 2 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru2"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3"); // Safety: if somehow higher already
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");


            actor.addTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool liru2EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 8 enemies
        if (actor.data.kills >= 8 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru3"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool liru3EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 20 enemies
        // Promote to Jonin
        if (actor.data.kills >= 20 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru4"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");

            actor.addTrait($"{ChunqiuMain.Identifier}_liru4");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool liru4EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 50 enemies and level 5 above
        if (actor.data.kills >= 50 && actor.data.level >=5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru5"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_liru5");
            actor.data.health += 300;
        }
        return true;
    }

    internal static bool liru5SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 80 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru6"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru5");
            actor.addTrait($"{ChunqiuMain.Identifier}_liru6");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool liru6SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 100 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru7"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru6");
            actor.addTrait($"{ChunqiuMain.Identifier}_liru7");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool liru7SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 150 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru8"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru7");
            actor.addTrait($"{ChunqiuMain.Identifier}_liru8");
            actor.data.health += 900;
        }
        return true;
    }


    internal static bool liru8SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 200 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_liru9"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru7");
            actor.removeTrait($"{ChunqiuMain.Identifier}_liru8");
            actor.addTrait($"{ChunqiuMain.Identifier}_liru9");
            actor.data.health += 900;
        }
        return true;
    }

    internal static bool liru9SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        return true;
    }

    internal static bool zhiruEvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill two enemies
        if (actor.data.kills >= 2 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru2"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3"); // Safety: if somehow higher already
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");


            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool zhiru2EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 8 enemies
        if (actor.data.kills >= 8 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru3"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool zhiru3EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 20 enemies
        // Promote to Jonin
        if (actor.data.kills >= 20 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru4"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");

            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru4");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool zhiru4EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 50 enemies and level 5 above
        if (actor.data.kills >= 50 && actor.data.level >=5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru5"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru5");
            actor.data.health += 300;
        }
        return true;
    }

    internal static bool zhiru5SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 80 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru6"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru5");
            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru6");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool zhiru6SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 100 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru7"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru6");
            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru7");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool zhiru7SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 150 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru8"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru7");
            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru8");
            actor.data.health += 900;
        }
        return true;
    }


    internal static bool zhiru8SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 200 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_zhiru9"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru7");
            actor.removeTrait($"{ChunqiuMain.Identifier}_zhiru8");
            actor.addTrait($"{ChunqiuMain.Identifier}_zhiru9");
            actor.data.health += 900;
        }
        return true;
    }

    internal static bool zhiru9SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        return true;
    }
    #endregion

    #region Attack Effect
    internal static bool yiruEvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill two enemies
        if (actor.data.kills >= 2 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru2"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3"); // Safety: if somehow higher already
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");


            actor.addTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool yiru2EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 8 enemies
        if (actor.data.kills >= 8 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru3"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool yiru3EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 20 enemies
        // Promote to Jonin
        if (actor.data.kills >= 20 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru4"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");

            actor.addTrait($"{ChunqiuMain.Identifier}_yiru4");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool yiru4EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 50 enemies and level 5 above
        if (actor.data.kills >= 50 && actor.data.level >=5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru5"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_yiru5");
            actor.data.health += 300;
        }
        return true;
    }

    internal static bool yiru5SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 80 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru6"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru5");
            actor.addTrait($"{ChunqiuMain.Identifier}_yiru6");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool yiru6SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 100 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru7"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru6");
            actor.addTrait($"{ChunqiuMain.Identifier}_yiru7");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool yiru7SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 150 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru8"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru7");
            actor.addTrait($"{ChunqiuMain.Identifier}_yiru8");
            actor.data.health += 900;
        }
        return true;
    }


    internal static bool yiru8SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 200 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_yiru9"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru7");
            actor.removeTrait($"{ChunqiuMain.Identifier}_yiru8");
            actor.addTrait($"{ChunqiuMain.Identifier}_yiru9");
            actor.data.health += 900;
        }
        return true;
    }

    internal static bool yiru9SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        return true;
    }
    internal static bool eliteNinjaAttackEffect(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Random attack
        if (Randy.randomChance(0.05f))
        {
            teleportToSpecificLocation(pSelf, pTarget, pTarget.current_tile);
        }
        else if (Randy.randomChance(0.05f))
        {
            MapBox.instance.drop_manager.spawn(pTarget.current_tile, "fire");
            MapBox.instance.drop_manager.spawn(pTarget.current_tile, "fire");
            MapBox.instance.drop_manager.spawn(pTarget.current_tile, "acid");
        }
        return true;
    }
    internal static bool renruEvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill two enemies
        if (actor.data.kills >= 2 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru2"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3"); // Safety: if somehow higher already
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");


            actor.addTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool renru2EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 8 enemies
        if (actor.data.kills >= 8 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru3"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool renru3EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        Actor actor = pTarget.a;
        //Kill more than 20 enemies
        // Promote to Jonin
        if (actor.data.kills >= 20 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru4"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");

            actor.addTrait($"{ChunqiuMain.Identifier}_renru4");
            actor.data.health += 100;
        }
        return true;
    }

    internal static bool renru4EvolutionSpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 50 enemies and level 5 above
        if (actor.data.kills >= 50 && actor.data.level >=5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru5"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");

            actor.addTrait($"{ChunqiuMain.Identifier}_renru5");
            actor.data.health += 300;
        }
        return true;
    }

    internal static bool renru5SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 80 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru6"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru5");
            actor.addTrait($"{ChunqiuMain.Identifier}_renru6");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool renru6SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 8)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 100 && actor.data.level >= 5 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru7"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru6");
            actor.addTrait($"{ChunqiuMain.Identifier}_renru7");
            actor.data.health += 700;
        }
        return true;
    }

    internal static bool renru7SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 80 enemies and level 5 above
        if (actor.data.kills >= 150 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru8"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru7");
            actor.addTrait($"{ChunqiuMain.Identifier}_renru8");
            actor.data.health += 900;
        }
        return true;
    }


    internal static bool renru8SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        Actor actor = pTarget.a;
        //Kill more than 100 enemies and level 5 above
        if (actor.data.kills >= 200 && actor.data.level >= 9 && !actor.hasTrait($"{ChunqiuMain.Identifier}_renru9"))
        {
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru1");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru2");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru3");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru4");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru5");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru6");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru7");
            actor.removeTrait($"{ChunqiuMain.Identifier}_renru8");
            actor.addTrait($"{ChunqiuMain.Identifier}_renru9");
            actor.data.health += 900;
        }
        return true;
    }

    internal static bool renru9SpecialEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return false;
        //Always warrior
        if (pTarget.a.getProfession() != UnitProfession.Warrior)
            pTarget.a.setProfession(UnitProfession.Warrior);

        //Should be army captain
        if (pTarget.a.hasArmy() && !pTarget.a.is_army_captain)
            pTarget.a.army.setCaptain(pTarget.a);

        if (pTarget.a.getHealth() < pTarget.a.getMaxHealth() / 2)
        {
            //Teleport away
            ActionLibrary.teleportRandom(pTarget, pTarget, pTile);
        }

        return true;
    }   
     #endregion



    #region Custom Function
    private static void renameToClanName(string clanName, BaseSimObject pTarget)
    {
        if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive()) return;
        string actorName = pTarget.a.getName();
        if (!actorName.Contains(clanName, StringComparison.OrdinalIgnoreCase))
        {
            pTarget.a.data.setName($"{clanName} {actorName}");
        }
    }

    internal static bool rankomegaDeathEffect(BaseSimObject pTarget, WorldTile pTile)
    {
        Actor a = pTarget.a;
        var act = World.world.units.createNewUnit(a.asset.id, pTile);
        if (pTarget.kingdom != null)
            act.kingdom = pTarget.kingdom;
        ActorTool.copyUnitToOtherUnit(a, act);
        act.removeTrait($"{ChunqiuMain.Identifier}_rankomega");
        act.addTrait($"{ChunqiuMain.Identifier}_rankX", true);
        act.data.health += 1300;
        ActionLibrary.castLightning(pTarget, act, null);
        EffectsLibrary.spawn("fx_spawn", act.current_tile);
        return true;
    }

    public static bool teleportToSpecificLocation(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile, string text = "fx_teleport_blue")
    {
        EffectsLibrary.spawnAt(text, pTile.pos, 0.1f);
        pTarget.a.cancelAllBeh();
        pTarget.a.spawnOn(pTile, 0f);
        return true;
    }




    #endregion
}