﻿using Chunqiu;
using Chunqiu.Content;
using ChunqiuRevised.Content.Config;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using System;
using System.Collections.Generic;
using UnityEngine;


namespace ChunqiuRevised.Content.Traits;

internal static class CustomTraits
{
    private static string Identifier = ChunqiuMain.Identifier;

    private static string TraitGroupId = $"{Identifier}_chunqiu_revised";//仁之道，安民之道
    private static string TraitGroupIdManner = $"{Identifier}_chunqiu_revised_manner";//礼之道，百姓之道
    private static string TraitGroupIdTruth = $"{Identifier}_chunqiu_revised_truth";//信之道，干员之道
    private static string TraitGroupIdJustice = $"{Identifier}_chunqiu_revised_justice";//义之道，军兵之道
    private static string TraitGroupIdExam = $"{Identifier}_chunqiu_revised_exam";//智之道，科举之道

    private static string PathToTraitIcon = "ui/Icons/actor_traits/chunqiu_revised_traits";


    private static int NoChance = 0;
    private static int Rare = 3;
    private static int LowChance = 15;
    private static int MediumChance = 30;
    private static int ExtraChance = 45;
    private static int HighChance = 75;
    private static int AlwaysChance = 100;

    [Hotfixable]
    public static void Init()
    {
        loadCustomTraitGroup();
        loadCustomTrait();
        loadCustomTraitTruth();
        loadCustomTraitExam();
        loadCustomMannerTraits();
        loadCustomTraitJustice();
    }


    private static void loadCustomTraitGroup()
    {
        ActorTraitGroupAsset group = new ActorTraitGroupAsset()
        {
            id = TraitGroupId,
            name = $"trait_group_{TraitGroupId}",
            color = "#0aed41",
        };
        // Add trait group to trait group library
        AssetManager.trait_groups.add(group);

        ActorTraitGroupAsset group2 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdManner,
            name = $"trait_group_{TraitGroupIdManner}",
            color = "#f83e1d",
        };
        AssetManager.trait_groups.add(group2);

        ActorTraitGroupAsset group3 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdTruth,
            name = $"trait_group_{TraitGroupIdTruth}",
            color = "#785f1b",
        };
        AssetManager.trait_groups.add(group3);
        ActorTraitGroupAsset group4 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdJustice,
            name = $"trait_group_{TraitGroupIdJustice}",
            color = "#fafa18",
        };
        AssetManager.trait_groups.add(group4);

        ActorTraitGroupAsset group5 = new ActorTraitGroupAsset()
        {
            id = TraitGroupIdExam,
            name = $"trait_group_{TraitGroupIdExam}",
            color = "#1ac0e3",
        };
        AssetManager.trait_groups.add(group5);
    }

    private static void loadCustomTrait()
    {
        #region renru1
        ActorTrait renru1 = new ActorTrait()
        {
            id = $"{Identifier}_renru1",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Student",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        renru1.base_stats = new BaseStats();
        renru1.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        renru1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        renru1.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        renru1.type = TraitType.Positive;
        renru1.unlock(true);

        renru1.action_special_effect = (WorldAction)Delegate.Combine(renru1.action_special_effect, new WorldAction(CustomTraitActions.renruEvolutionSpecialEffect));
        AssetManager.traits.add(renru1);
        addToLocale(renru1.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region renru2
        ActorTrait renru2 = new ActorTrait()
        {
            id = $"{Identifier}_renru2",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Genin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        renru2.base_stats = new BaseStats();
        renru2.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        renru2.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        renru2.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        renru2.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        renru2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        renru2.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        renru2.type = TraitType.Positive;
        renru2.unlock(true);

        renru2.action_special_effect = (WorldAction)Delegate.Combine(renru2.action_special_effect, new WorldAction(CustomTraitActions.renru2EvolutionSpecialEffect));

        AssetManager.traits.add(renru2);
        addToLocale(renru2.id, "Genin", "A low-renru shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region renru3
        ActorTrait renru3 = new ActorTrait()
        {
            id = $"{Identifier}_renru3",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Chunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        renru3.base_stats = new BaseStats();
        renru3.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        renru3.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        renru3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        renru3.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        renru3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        renru3.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        renru3.type = TraitType.Positive;
        renru3.unlock(true);

        renru3.action_special_effect = (WorldAction)Delegate.Combine(renru3.action_special_effect, new WorldAction(CustomTraitActions.renru3EvolutionSpecialEffect));

        AssetManager.traits.add(renru3);
        addToLocale(renru3.id, "Chunin", "A mid-renru shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region renru4
        ActorTrait renru4 = new ActorTrait()
        {
            id = $"{Identifier}_renru4",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Jonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        renru4.base_stats = new BaseStats();
        renru4.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        renru4.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        renru4.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        renru4.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        renru4.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        renru4.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        renru4.type = TraitType.Positive;
        renru4.unlock(true);

        renru4.action_special_effect = (WorldAction)Delegate.Combine(renru4.action_special_effect, new WorldAction(CustomTraitActions.renru4EvolutionSpecialEffect));
        renru4.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(renru4);
        addToLocale(renru4.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region renru5
        ActorTrait renru5 = new ActorTrait()
        {
            id = $"{Identifier}_renru5",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Ninja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        renru5.base_stats = new BaseStats();
        renru5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        renru5.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        renru5.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        renru5.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        renru5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        renru5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        renru5.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        renru5.type = TraitType.Positive;
        renru5.unlock(true);

        renru5.addOpposites(new List<string> {
            $"{Identifier}_renru1",
            $"{Identifier}_renru2",
            $"{Identifier}_renru3",
            $"{Identifier}_renru4"
        });

        renru5.action_special_effect = (WorldAction)Delegate.Combine(renru5.action_special_effect, new WorldAction(CustomTraitActions.renru5SpecialEffect));
        renru5.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(renru5);
        addToLocale(renru5.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region renru6
        ActorTrait renru6 = new ActorTrait()
        {
            id = $"{Identifier}_renru6",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/Aaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        renru6.base_stats = new BaseStats();
        renru6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        renru6.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        renru6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        renru6.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        renru6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        renru6.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        renru6.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        renru6.type = TraitType.Positive;
        renru6.unlock(true);

        renru6.addOpposites(new List<string> {
            $"{Identifier}_renru1",
            $"{Identifier}_renru2",
            $"{Identifier}_renru3",
            $"{Identifier}_renru4",
            $"{Identifier}_renru5",
        });

        renru6.action_special_effect = (WorldAction)Delegate.Combine(renru6.action_special_effect, new WorldAction(CustomTraitActions.renru6SpecialEffect));
        renru6.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(renru6);
        addToLocale(renru6.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region renru7
        ActorTrait renru7 = new ActorTrait()
        {
            id = $"{Identifier}_renru7",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/aubuS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        renru7.base_stats = new BaseStats();
        renru7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        renru7.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        renru7.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        renru7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        renru7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        renru7.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        renru7.type = TraitType.Positive;
        renru7.unlock(true);

        renru7.action_special_effect = (WorldAction)Delegate.Combine(renru7.action_special_effect, new WorldAction(CustomTraitActions.renru7SpecialEffect));
        renru7.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(renru7);
        addToLocale(renru7.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region renru8
        ActorTrait renru8 = new ActorTrait()
        {
            id = $"{Identifier}_renru8",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/aubuSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        renru8.base_stats = new BaseStats();
        renru8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        renru8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        renru8.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        renru8.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        renru8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        renru8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        renru8.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        renru8.type = TraitType.Positive;
        renru8.unlock(true);

        renru8.addOpposites(new List<string> {
            $"{Identifier}_renru1",
            $"{Identifier}_renru2",
            $"{Identifier}_renru3",
            $"{Identifier}_renru4",
            $"{Identifier}_renru5",
            $"{Identifier}_renru6",
            $"{Identifier}_renru7"
        });

        renru8.action_special_effect = (WorldAction)Delegate.Combine(renru8.action_special_effect, new WorldAction(CustomTraitActions.renru8SpecialEffect));
        renru8.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(renru8);
        addToLocale(renru8.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region renru9
        ActorTrait renru9 = new ActorTrait()
        {
            id = $"{Identifier}_renru9",
            group_id = TraitGroupId,
            path_icon = $"{PathToTraitIcon}/aubuSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        renru9.base_stats = new BaseStats();
        renru9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        renru9.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        renru9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        renru9.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        renru9.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        renru9.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        renru9.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        renru9.type = TraitType.Positive;
        renru9.unlock(true);

        renru9.addOpposites(new List<string> {
            $"{Identifier}_renru1",
            $"{Identifier}_renru2",
            $"{Identifier}_renru3",
            $"{Identifier}_renru4",
            $"{Identifier}_renru5",
            $"{Identifier}_renru6",
            $"{Identifier}_renru7",            
            $"{Identifier}_renru8",
        });

        renru9.action_special_effect = (WorldAction)Delegate.Combine(renru9.action_special_effect, new WorldAction(CustomTraitActions.renru9SpecialEffect));
        renru9.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(renru9);
        addToLocale(renru9.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion

    }
    private static void loadCustomMannerTraits()
    {
        #region liru1
        ActorTrait liru1 = new ActorTrait()
        {
            id = $"{Identifier}_liru1",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Student",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        liru1.base_stats = new BaseStats();
        liru1.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        liru1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        liru1.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        liru1.type = TraitType.Positive;
        liru1.unlock(true);

        liru1.action_special_effect = (WorldAction)Delegate.Combine(liru1.action_special_effect, new WorldAction(CustomTraitActions.liruEvolutionSpecialEffect));
        AssetManager.traits.add(liru1);
        addToLocale(liru1.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region liru2
        ActorTrait liru2 = new ActorTrait()
        {
            id = $"{Identifier}_liru2",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Genin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        liru2.base_stats = new BaseStats();
        liru2.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        liru2.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        liru2.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        liru2.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        liru2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        liru2.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        liru2.type = TraitType.Positive;
        liru2.unlock(true);

        liru2.action_special_effect = (WorldAction)Delegate.Combine(liru2.action_special_effect, new WorldAction(CustomTraitActions.liru2EvolutionSpecialEffect));

        AssetManager.traits.add(liru2);
        addToLocale(liru2.id, "Genin", "A low-liru shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region liru3
        ActorTrait liru3 = new ActorTrait()
        {
            id = $"{Identifier}_liru3",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Chunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        liru3.base_stats = new BaseStats();
        liru3.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        liru3.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        liru3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        liru3.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        liru3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        liru3.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        liru3.type = TraitType.Positive;
        liru3.unlock(true);

        liru3.action_special_effect = (WorldAction)Delegate.Combine(liru3.action_special_effect, new WorldAction(CustomTraitActions.liru3EvolutionSpecialEffect));

        AssetManager.traits.add(liru3);
        addToLocale(liru3.id, "Chunin", "A mid-liru shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region liru4
        ActorTrait liru4 = new ActorTrait()
        {
            id = $"{Identifier}_liru4",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Jonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        liru4.base_stats = new BaseStats();
        liru4.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        liru4.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        liru4.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        liru4.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        liru4.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        liru4.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        liru4.type = TraitType.Positive;
        liru4.unlock(true);

        liru4.action_special_effect = (WorldAction)Delegate.Combine(liru4.action_special_effect, new WorldAction(CustomTraitActions.liru4EvolutionSpecialEffect));
        liru4.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(liru4);
        addToLocale(liru4.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region liru5
        ActorTrait liru5 = new ActorTrait()
        {
            id = $"{Identifier}_liru5",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Ninja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        liru5.base_stats = new BaseStats();
        liru5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        liru5.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        liru5.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        liru5.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        liru5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        liru5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        liru5.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        liru5.type = TraitType.Positive;
        liru5.unlock(true);

        liru5.addOpposites(new List<string> {
            $"{Identifier}_liru1",
            $"{Identifier}_liru2",
            $"{Identifier}_liru3",
            $"{Identifier}_liru4"
        });

        liru5.action_special_effect = (WorldAction)Delegate.Combine(liru5.action_special_effect, new WorldAction(CustomTraitActions.liru5SpecialEffect));
        liru5.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(liru5);
        addToLocale(liru5.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region liru6
        ActorTrait liru6 = new ActorTrait()
        {
            id = $"{Identifier}_liru6",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/Aaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        liru6.base_stats = new BaseStats();
        liru6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        liru6.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        liru6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        liru6.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        liru6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        liru6.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        liru6.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        liru6.type = TraitType.Positive;
        liru6.unlock(true);

        liru6.addOpposites(new List<string> {
            $"{Identifier}_liru1",
            $"{Identifier}_liru2",
            $"{Identifier}_liru3",
            $"{Identifier}_liru4",
            $"{Identifier}_liru5",
        });

        liru6.action_special_effect = (WorldAction)Delegate.Combine(liru6.action_special_effect, new WorldAction(CustomTraitActions.liru6SpecialEffect));
        liru6.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(liru6);
        addToLocale(liru6.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region liru7
        ActorTrait liru7 = new ActorTrait()
        {
            id = $"{Identifier}_liru7",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/aubuS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        liru7.base_stats = new BaseStats();
        liru7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        liru7.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        liru7.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        liru7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        liru7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        liru7.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        liru7.type = TraitType.Positive;
        liru7.unlock(true);

        liru7.action_special_effect = (WorldAction)Delegate.Combine(liru7.action_special_effect, new WorldAction(CustomTraitActions.liru7SpecialEffect));
        liru7.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(liru7);
        addToLocale(liru7.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region liru8
        ActorTrait liru8 = new ActorTrait()
        {
            id = $"{Identifier}_liru8",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/aubuSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        liru8.base_stats = new BaseStats();
        liru8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        liru8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        liru8.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        liru8.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        liru8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        liru8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        liru8.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        liru8.type = TraitType.Positive;
        liru8.unlock(true);

        liru8.addOpposites(new List<string> {
            $"{Identifier}_liru1",
            $"{Identifier}_liru2",
            $"{Identifier}_liru3",
            $"{Identifier}_liru4",
            $"{Identifier}_liru5",
            $"{Identifier}_liru6",            
            $"{Identifier}_liru7"
        });

        liru8.action_special_effect = (WorldAction)Delegate.Combine(liru8.action_special_effect, new WorldAction(CustomTraitActions.liru8SpecialEffect));
        liru8.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(liru8);
        addToLocale(liru8.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region liru9
        ActorTrait liru9 = new ActorTrait()
        {
            id = $"{Identifier}_liru9",
            group_id = TraitGroupIdManner,
            path_icon = $"{PathToTraitIcon}/aubuSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        liru9.base_stats = new BaseStats();
        liru9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        liru9.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        liru9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        liru9.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        liru9.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        liru9.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        liru9.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        liru9.type = TraitType.Positive;
        liru9.unlock(true);

        liru9.addOpposites(new List<string> {
            $"{Identifier}_liru1",
            $"{Identifier}_liru2",
            $"{Identifier}_liru3",
            $"{Identifier}_liru4",
            $"{Identifier}_liru5",
            $"{Identifier}_liru6",
            $"{Identifier}_liru7",            
            $"{Identifier}_liru8",
        });

        liru9.action_special_effect = (WorldAction)Delegate.Combine(liru9.action_special_effect, new WorldAction(CustomTraitActions.liru9SpecialEffect));
        liru9.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(liru9);
        addToLocale(liru9.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
    }


    private static void loadCustomTraitTruth()
    {
        #region xinru1
        ActorTrait xinru1 = new ActorTrait()
        {
            id = $"{Identifier}_xinru1",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Student",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        xinru1.base_stats = new BaseStats();
        xinru1.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        xinru1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        xinru1.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        xinru1.type = TraitType.Positive;
        xinru1.unlock(true);

        xinru1.action_special_effect = (WorldAction)Delegate.Combine(xinru1.action_special_effect, new WorldAction(CustomTraitActions.xinruEvolutionSpecialEffect));
        AssetManager.traits.add(xinru1);
        addToLocale(xinru1.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region xinru2
        ActorTrait xinru2 = new ActorTrait()
        {
            id = $"{Identifier}_xinru2",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Genin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        xinru2.base_stats = new BaseStats();
        xinru2.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        xinru2.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        xinru2.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        xinru2.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        xinru2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        xinru2.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        xinru2.type = TraitType.Positive;
        xinru2.unlock(true);

        xinru2.action_special_effect = (WorldAction)Delegate.Combine(xinru2.action_special_effect, new WorldAction(CustomTraitActions.xinru2EvolutionSpecialEffect));

        AssetManager.traits.add(xinru2);
        addToLocale(xinru2.id, "Genin", "A low-xinru shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region xinru3
        ActorTrait xinru3 = new ActorTrait()
        {
            id = $"{Identifier}_xinru3",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Chunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        xinru3.base_stats = new BaseStats();
        xinru3.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        xinru3.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        xinru3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        xinru3.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        xinru3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        xinru3.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        xinru3.type = TraitType.Positive;
        xinru3.unlock(true);

        xinru3.action_special_effect = (WorldAction)Delegate.Combine(xinru3.action_special_effect, new WorldAction(CustomTraitActions.xinru3EvolutionSpecialEffect));

        AssetManager.traits.add(xinru3);
        addToLocale(xinru3.id, "Chunin", "A mid-xinru shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region xinru4
        ActorTrait xinru4 = new ActorTrait()
        {
            id = $"{Identifier}_xinru4",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Jonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        xinru4.base_stats = new BaseStats();
        xinru4.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        xinru4.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        xinru4.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        xinru4.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        xinru4.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        xinru4.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        xinru4.type = TraitType.Positive;
        xinru4.unlock(true);

        xinru4.action_special_effect = (WorldAction)Delegate.Combine(xinru4.action_special_effect, new WorldAction(CustomTraitActions.xinru4EvolutionSpecialEffect));
        xinru4.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(xinru4);
        addToLocale(xinru4.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region xinru5
        ActorTrait xinru5 = new ActorTrait()
        {
            id = $"{Identifier}_xinru5",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Ninja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        xinru5.base_stats = new BaseStats();
        xinru5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        xinru5.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        xinru5.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        xinru5.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        xinru5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        xinru5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        xinru5.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        xinru5.type = TraitType.Positive;
        xinru5.unlock(true);

        xinru5.addOpposites(new List<string> {
            $"{Identifier}_xinru1",
            $"{Identifier}_xinru2",
            $"{Identifier}_xinru3",
            $"{Identifier}_xinru4"
        });

        xinru5.action_special_effect = (WorldAction)Delegate.Combine(xinru5.action_special_effect, new WorldAction(CustomTraitActions.xinru5SpecialEffect));
        xinru5.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(xinru5);
        addToLocale(xinru5.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region xinru6
        ActorTrait xinru6 = new ActorTrait()
        {
            id = $"{Identifier}_xinru6",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/Aaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        xinru6.base_stats = new BaseStats();
        xinru6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        xinru6.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        xinru6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        xinru6.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        xinru6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        xinru6.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        xinru6.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        xinru6.type = TraitType.Positive;
        xinru6.unlock(true);

        xinru6.addOpposites(new List<string> {
            $"{Identifier}_xinru1",
            $"{Identifier}_xinru2",
            $"{Identifier}_xinru3",
            $"{Identifier}_xinru4",
            $"{Identifier}_xinru5",
        });

        xinru6.action_special_effect = (WorldAction)Delegate.Combine(xinru6.action_special_effect, new WorldAction(CustomTraitActions.xinru6SpecialEffect));
        xinru6.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(xinru6);
        addToLocale(xinru6.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region xinru7
        ActorTrait xinru7 = new ActorTrait()
        {
            id = $"{Identifier}_xinru7",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/aubuS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        xinru7.base_stats = new BaseStats();
        xinru7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        xinru7.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        xinru7.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        xinru7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        xinru7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        xinru7.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        xinru7.type = TraitType.Positive;
        xinru7.unlock(true);

        xinru7.action_special_effect = (WorldAction)Delegate.Combine(xinru7.action_special_effect, new WorldAction(CustomTraitActions.xinru7SpecialEffect));
        xinru7.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(xinru7);
        addToLocale(xinru7.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region xinru8
        ActorTrait xinru8 = new ActorTrait()
        {
            id = $"{Identifier}_xinru8",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/aubuSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        xinru8.base_stats = new BaseStats();
        xinru8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        xinru8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        xinru8.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        xinru8.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        xinru8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        xinru8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        xinru8.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        xinru8.type = TraitType.Positive;
        xinru8.unlock(true);

        xinru8.addOpposites(new List<string> {
            $"{Identifier}_xinru1",
            $"{Identifier}_xinru2",
            $"{Identifier}_xinru3",
            $"{Identifier}_xinru4",
            $"{Identifier}_xinru5",
            $"{Identifier}_xinru6",            
            $"{Identifier}_xinru7"
        });

        xinru8.action_special_effect = (WorldAction)Delegate.Combine(xinru8.action_special_effect, new WorldAction(CustomTraitActions.xinru8SpecialEffect));
        xinru8.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(xinru8);
        addToLocale(xinru8.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region xinru9
        ActorTrait xinru9 = new ActorTrait()
        {
            id = $"{Identifier}_xinru9",
            group_id = TraitGroupIdTruth,
            path_icon = $"{PathToTraitIcon}/aubuSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        xinru9.base_stats = new BaseStats();
        xinru9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        xinru9.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        xinru9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        xinru9.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        xinru9.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        xinru9.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        xinru9.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        xinru9.type = TraitType.Positive;
        xinru9.unlock(true);

        xinru9.addOpposites(new List<string> {
            $"{Identifier}_xinru1",
            $"{Identifier}_xinru2",
            $"{Identifier}_xinru3",
            $"{Identifier}_xinru4",
            $"{Identifier}_xinru5",
            $"{Identifier}_xinru6",
            $"{Identifier}_xinru7",            
            $"{Identifier}_xinru8",
        });

        xinru9.action_special_effect = (WorldAction)Delegate.Combine(xinru9.action_special_effect, new WorldAction(CustomTraitActions.xinru9SpecialEffect));
        xinru9.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(xinru9);
        addToLocale(xinru9.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        

    }

    private static void loadCustomTraitExam()
    {
        #region zhiru1
        ActorTrait zhiru1 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru1",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Student",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        zhiru1.base_stats = new BaseStats();
        zhiru1.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        zhiru1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        zhiru1.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        zhiru1.type = TraitType.Positive;
        zhiru1.unlock(true);

        zhiru1.action_special_effect = (WorldAction)Delegate.Combine(zhiru1.action_special_effect, new WorldAction(CustomTraitActions.zhiruEvolutionSpecialEffect));
        AssetManager.traits.add(zhiru1);
        addToLocale(zhiru1.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region zhiru2
        ActorTrait zhiru2 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru2",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Genin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        zhiru2.base_stats = new BaseStats();
        zhiru2.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        zhiru2.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        zhiru2.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        zhiru2.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        zhiru2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        zhiru2.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        zhiru2.type = TraitType.Positive;
        zhiru2.unlock(true);

        zhiru2.action_special_effect = (WorldAction)Delegate.Combine(zhiru2.action_special_effect, new WorldAction(CustomTraitActions.zhiru2EvolutionSpecialEffect));

        AssetManager.traits.add(zhiru2);
        addToLocale(zhiru2.id, "Genin", "A low-zhiru shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region zhiru3
        ActorTrait zhiru3 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru3",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Chunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        zhiru3.base_stats = new BaseStats();
        zhiru3.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        zhiru3.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        zhiru3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        zhiru3.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        zhiru3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        zhiru3.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        zhiru3.type = TraitType.Positive;
        zhiru3.unlock(true);

        zhiru3.action_special_effect = (WorldAction)Delegate.Combine(zhiru3.action_special_effect, new WorldAction(CustomTraitActions.zhiru3EvolutionSpecialEffect));

        AssetManager.traits.add(zhiru3);
        addToLocale(zhiru3.id, "Chunin", "A mid-zhiru shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region zhiru4
        ActorTrait zhiru4 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru4",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Jonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        zhiru4.base_stats = new BaseStats();
        zhiru4.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        zhiru4.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        zhiru4.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        zhiru4.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        zhiru4.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        zhiru4.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        zhiru4.type = TraitType.Positive;
        zhiru4.unlock(true);

        zhiru4.action_special_effect = (WorldAction)Delegate.Combine(zhiru4.action_special_effect, new WorldAction(CustomTraitActions.zhiru4EvolutionSpecialEffect));
        zhiru4.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(zhiru4);
        addToLocale(zhiru4.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region zhiru5
        ActorTrait zhiru5 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru5",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Ninja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        zhiru5.base_stats = new BaseStats();
        zhiru5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        zhiru5.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        zhiru5.type = TraitType.Positive;
        zhiru5.unlock(true);

        zhiru5.addOpposites(new List<string> {
            $"{Identifier}_zhiru1",
            $"{Identifier}_zhiru2",
            $"{Identifier}_zhiru3",
            $"{Identifier}_zhiru4"
        });

        zhiru5.action_special_effect = (WorldAction)Delegate.Combine(zhiru5.action_special_effect, new WorldAction(CustomTraitActions.zhiru5SpecialEffect));
        zhiru5.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(zhiru5);
        addToLocale(zhiru5.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region zhiru6
        ActorTrait zhiru6 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru6",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/Aaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        zhiru6.base_stats = new BaseStats();
        zhiru6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        zhiru6.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        zhiru6.type = TraitType.Positive;
        zhiru6.unlock(true);

        zhiru6.addOpposites(new List<string> {
            $"{Identifier}_zhiru1",
            $"{Identifier}_zhiru2",
            $"{Identifier}_zhiru3",
            $"{Identifier}_zhiru4",
            $"{Identifier}_zhiru5",
        });

        zhiru6.action_special_effect = (WorldAction)Delegate.Combine(zhiru6.action_special_effect, new WorldAction(CustomTraitActions.zhiru6SpecialEffect));
        zhiru6.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(zhiru6);
        addToLocale(zhiru6.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region zhiru7
        ActorTrait zhiru7 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru7",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/aubuS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        zhiru7.base_stats = new BaseStats();
        zhiru7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        zhiru7.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        zhiru7.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        zhiru7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        zhiru7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        zhiru7.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        zhiru7.type = TraitType.Positive;
        zhiru7.unlock(true);

        zhiru7.action_special_effect = (WorldAction)Delegate.Combine(zhiru7.action_special_effect, new WorldAction(CustomTraitActions.zhiru7SpecialEffect));
        zhiru7.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(zhiru7);
        addToLocale(zhiru7.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region zhiru8
        ActorTrait zhiru8 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru8",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/aubuSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        zhiru8.base_stats = new BaseStats();
        zhiru8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        zhiru8.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        zhiru8.type = TraitType.Positive;
        zhiru8.unlock(true);

        zhiru8.addOpposites(new List<string> {
            $"{Identifier}_zhiru1",
            $"{Identifier}_zhiru2",
            $"{Identifier}_zhiru3",
            $"{Identifier}_zhiru4",
            $"{Identifier}_zhiru5",
            $"{Identifier}_zhiru6",            
            $"{Identifier}_zhiru7"
        });

        zhiru8.action_special_effect = (WorldAction)Delegate.Combine(zhiru8.action_special_effect, new WorldAction(CustomTraitActions.zhiru8SpecialEffect));
        zhiru8.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(zhiru8);
        addToLocale(zhiru8.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region zhiru9
        ActorTrait zhiru9 = new ActorTrait()
        {
            id = $"{Identifier}_zhiru9",
            group_id = TraitGroupIdExam,
            path_icon = $"{PathToTraitIcon}/aubuSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        zhiru9.base_stats = new BaseStats();
        zhiru9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        zhiru9.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        zhiru9.type = TraitType.Positive;
        zhiru9.unlock(true);

        zhiru9.addOpposites(new List<string> {
            $"{Identifier}_zhiru1",
            $"{Identifier}_zhiru2",
            $"{Identifier}_zhiru3",
            $"{Identifier}_zhiru4",
            $"{Identifier}_zhiru5",
            $"{Identifier}_zhiru6",
            $"{Identifier}_zhiru7",
            $"{Identifier}_zhiru8",            
        });

        zhiru9.action_special_effect = (WorldAction)Delegate.Combine(zhiru9.action_special_effect, new WorldAction(CustomTraitActions.zhiru9SpecialEffect));
        zhiru9.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(zhiru9);
        addToLocale(zhiru9.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion

    }


    /// <summary>
    /// W.I.P.
    /// Not yet finished
    /// </summary>
    private static void loadCustomTraitJustice()
    {
        #region yiru1
        ActorTrait yiru1 = new ActorTrait()
        {
            id = $"{Identifier}_yiru1",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Student",
            rate_birth = Rare,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        yiru1.base_stats = new BaseStats();
        yiru1.base_stats.set(CustomBaseStatsConstant.Health, 10f);
        yiru1.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.05f);
        yiru1.base_stats.set(CustomBaseStatsConstant.Intelligence, 2f);

        yiru1.type = TraitType.Positive;
        yiru1.unlock(true);

        yiru1.action_special_effect = (WorldAction)Delegate.Combine(yiru1.action_special_effect, new WorldAction(CustomTraitActions.yiruEvolutionSpecialEffect));
        AssetManager.traits.add(yiru1);
        addToLocale(yiru1.id, "Academy Student", "A trainee at the ninja academy.", "Begin your ninja journey. Can evolve to Genin after kill two enemies!");
        #endregion

        #region yiru2
        ActorTrait yiru2 = new ActorTrait()
        {
            id = $"{Identifier}_yiru2",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Genin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        yiru2.base_stats = new BaseStats();
        yiru2.base_stats.set(CustomBaseStatsConstant.Damage, 10f);
        yiru2.base_stats.set(CustomBaseStatsConstant.Health, 70f);
        yiru2.base_stats.set(CustomBaseStatsConstant.Armor, 7f);
        yiru2.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.3f);
        yiru2.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.2f);
        yiru2.base_stats.set(CustomBaseStatsConstant.Intelligence, 5f);

        yiru2.type = TraitType.Positive;
        yiru2.unlock(true);

        yiru2.action_special_effect = (WorldAction)Delegate.Combine(yiru2.action_special_effect, new WorldAction(CustomTraitActions.yiru2EvolutionSpecialEffect));

        AssetManager.traits.add(yiru2);
        addToLocale(yiru2.id, "Genin", "A low-yiru shinobi.", "Graduated from the academy! Can evolve to Chunin after kill eight enemies!");
        #endregion

        #region yiru3
        ActorTrait yiru3 = new ActorTrait()
        {
            id = $"{Identifier}_yiru3",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Chunin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R0_Normal,
            can_be_given = true,
        };

        yiru3.base_stats = new BaseStats();
        yiru3.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
        yiru3.base_stats.set(CustomBaseStatsConstant.Health, 100f);
        yiru3.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        yiru3.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 0.5f);
        yiru3.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 0.7f);
        yiru3.base_stats.set(CustomBaseStatsConstant.Intelligence, 15f);

        yiru3.type = TraitType.Positive;
        yiru3.unlock(true);

        yiru3.action_special_effect = (WorldAction)Delegate.Combine(yiru3.action_special_effect, new WorldAction(CustomTraitActions.yiru3EvolutionSpecialEffect));

        AssetManager.traits.add(yiru3);
        addToLocale(yiru3.id, "Chunin", "A mid-yiru shinobi.", "Proven capable in leadership and combat! Can evolve to Jonin after kill 20 enemies!");
        #endregion

        #region yiru4
        ActorTrait yiru4 = new ActorTrait()
        {
            id = $"{Identifier}_yiru4",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Jonin",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        yiru4.base_stats = new BaseStats();
        yiru4.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        yiru4.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.0f);
        yiru4.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        yiru4.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
        yiru4.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f);
        yiru4.base_stats.set(CustomBaseStatsConstant.Intelligence, 25f);

        yiru4.type = TraitType.Positive;
        yiru4.unlock(true);

        yiru4.action_special_effect = (WorldAction)Delegate.Combine(yiru4.action_special_effect, new WorldAction(CustomTraitActions.yiru4EvolutionSpecialEffect));
        yiru4.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(yiru4);
        addToLocale(yiru4.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region yiru5
        ActorTrait yiru5 = new ActorTrait()
        {
            id = $"{Identifier}_yiru5",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Ninja",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        yiru5.base_stats = new BaseStats();
        yiru5.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.0f);
        yiru5.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.6f);
        yiru5.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 1.6f);
        yiru5.base_stats.set(CustomBaseStatsConstant.Armor, 15f);
        yiru5.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.7f);
        yiru5.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.7f);
        yiru5.base_stats.set(CustomBaseStatsConstant.Intelligence, 22f);

        yiru5.type = TraitType.Positive;
        yiru5.unlock(true);

        yiru5.addOpposites(new List<string> {
            $"{Identifier}_yiru1",
            $"{Identifier}_yiru2",
            $"{Identifier}_yiru3",
            $"{Identifier}_yiru4"
        });

        yiru5.action_special_effect = (WorldAction)Delegate.Combine(yiru5.action_special_effect, new WorldAction(CustomTraitActions.yiru5SpecialEffect));
        yiru5.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(yiru5);
        addToLocale(yiru5.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region yiru6
        ActorTrait yiru6 = new ActorTrait()
        {
            id = $"{Identifier}_yiru6",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/Aaptain",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R1_Rare,
            can_be_given = true,
        };

        yiru6.base_stats = new BaseStats();
        yiru6.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 1.2f);
        yiru6.base_stats.set(CustomBaseStatsConstant.CriticalChance, 0.8f);
        yiru6.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        yiru6.base_stats.set(CustomBaseStatsConstant.Armor, 20f);
        yiru6.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.85f);
        yiru6.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.85f);
        yiru6.base_stats.set(CustomBaseStatsConstant.Intelligence, 60f);

        yiru6.type = TraitType.Positive;
        yiru6.unlock(true);

        yiru6.addOpposites(new List<string> {
            $"{Identifier}_yiru1",
            $"{Identifier}_yiru2",
            $"{Identifier}_yiru3",
            $"{Identifier}_yiru4",
            $"{Identifier}_yiru5",
        });

        yiru6.action_special_effect = (WorldAction)Delegate.Combine(yiru6.action_special_effect, new WorldAction(CustomTraitActions.yiru6SpecialEffect));
        yiru6.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(yiru6);
        addToLocale(yiru6.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion
        
        #region yiru7
        ActorTrait yiru7 = new ActorTrait()
        {
            id = $"{Identifier}_yiru7",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/aubuS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        yiru7.base_stats = new BaseStats();
        yiru7.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 2.0f);
        yiru7.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 2.0f);
        yiru7.base_stats.set(CustomBaseStatsConstant.Armor, 40f);
        yiru7.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 2.0f);
        yiru7.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 2.0f);
        yiru7.base_stats.set(CustomBaseStatsConstant.Intelligence, 75);

        yiru7.type = TraitType.Positive;
        yiru7.unlock(true);

        yiru7.action_special_effect = (WorldAction)Delegate.Combine(yiru7.action_special_effect, new WorldAction(CustomTraitActions.yiru7SpecialEffect));
        yiru7.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);


        AssetManager.traits.add(yiru7);
        addToLocale(yiru7.id, "Jonin", "An elite shinobi. Veteran of many battles and missions!", "Can use a bit of teleport and burn enemies! Only become Anbu if kill over 50 enemies and over level 5!");
        #endregion

        #region yiru8
        ActorTrait yiru8 = new ActorTrait()
        {
            id = $"{Identifier}_yiru8",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/aubuSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        yiru8.base_stats = new BaseStats();
        yiru8.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 4.0f);
        yiru8.base_stats.set(CustomBaseStatsConstant.CriticalChance, 4.0f);
        yiru8.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 4.0f);
        yiru8.base_stats.set(CustomBaseStatsConstant.Armor, 60f);
        yiru8.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 4.0f);
        yiru8.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 4.0f);
        yiru8.base_stats.set(CustomBaseStatsConstant.Intelligence, 90f);

        yiru8.type = TraitType.Positive;
        yiru8.unlock(true);

        yiru8.addOpposites(new List<string> {
            $"{Identifier}_yiru1",
            $"{Identifier}_yiru2",
            $"{Identifier}_yiru3",
            $"{Identifier}_yiru4",
            $"{Identifier}_yiru5",
            $"{Identifier}_yiru6",            
            $"{Identifier}_yiru7"
        });

        yiru8.action_special_effect = (WorldAction)Delegate.Combine(yiru8.action_special_effect, new WorldAction(CustomTraitActions.yiru8SpecialEffect));
        yiru8.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(yiru8);
        addToLocale(yiru8.id, "Anbu", "Member of the Anbu Black Ops.", "Elite shinobi operating in secret. Can use special attack!");
        #endregion

        #region yiru9
        ActorTrait yiru9 = new ActorTrait()
        {
            id = $"{Identifier}_yiru9",
            group_id = TraitGroupIdJustice,
            path_icon = $"{PathToTraitIcon}/aubuSSS",
            rate_birth = NoChance,
            rate_inherit = NoChance,
            rarity = Rarity.R2_Epic,
            can_be_given = true,
        };

        yiru9.base_stats = new BaseStats();
        yiru9.base_stats.set(CustomBaseStatsConstant.MultiplierDamage, 5.0f);
        yiru9.base_stats.set(CustomBaseStatsConstant.CriticalChance, 5.0f);
        yiru9.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 5.0f);
        yiru9.base_stats.set(CustomBaseStatsConstant.Armor, 80f);
        yiru9.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 5.0f);
        yiru9.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 5.0f);
        yiru9.base_stats.set(CustomBaseStatsConstant.Intelligence, 100f);

        yiru9.type = TraitType.Positive;
        yiru9.unlock(true);

        yiru9.addOpposites(new List<string> {
            $"{Identifier}_yiru1",
            $"{Identifier}_yiru2",
            $"{Identifier}_yiru3",
            $"{Identifier}_yiru4",
            $"{Identifier}_yiru5",
            $"{Identifier}_yiru6",
            $"{Identifier}_yiru7",            
            $"{Identifier}_yiru8",
        });

        yiru9.action_special_effect = (WorldAction)Delegate.Combine(yiru9.action_special_effect, new WorldAction(CustomTraitActions.yiru9SpecialEffect));
        yiru9.action_attack_target = new AttackAction(CustomTraitActions.eliteNinjaAttackEffect);

        AssetManager.traits.add(yiru9);
        addToLocale(yiru9.id, "Anbu Captain", "Captain of the Anbu Black Ops.", "Commanding leader of elite covert missions. Can use special attack!");
        #endregion

    }


    private static void addToLocale(string id, string name, string description, string description_2 = "")
    {
    }
}