﻿using HarmonyLib;
using Chunqiu;
using Chunqiu.Content;
using NCMS.Utils;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace ChunqiuRevised.Content.Items
{
    public class CustomItems
    {
        private const string PathIcon = "ui/Icons/items";
        private const string PathSlash = "ui/effects/slashes";

        [Hotfixable]
        public static void Init()
        {
            loadCustomItems();
        }

        private static void loadCustomItems()
        {

            #region junzi jian
            ItemAsset junzi = AssetManager.items.clone("junzi", "$weapon");
            junzi.id = "junzi";
            junzi.material = "adamantine"; //Since they are special weapon, I think this is suitable, and I don't have time to use other materials
            junzi.translation_key = "Junzi";
            junzi.equipment_subtype = "junzi";
            junzi.group_id = "sword";
            junzi.animated = false;
            junzi.is_pool_weapon = false;
            junzi.unlock(true);

            junzi.base_stats = new();
            junzi.base_stats.set(CustomBaseStatsConstant.Damage, 50f);
            junzi.base_stats.set(CustomBaseStatsConstant.MultiplierSpeed, 1.0f);
            junzi.base_stats.set(CustomBaseStatsConstant.MultiplierAttackSpeed, 1.0f); //Percentage
            junzi.base_stats.set(CustomBaseStatsConstant.MultiplierHealth, 0.2f);
            junzi.base_stats.set(CustomBaseStatsConstant.ConstructionSpeed, 50f);
            junzi.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.5f);

            junzi.name_templates = AssetLibrary<EquipmentAsset>.l<string>("flame_sword_name");
            junzi.equipment_value = 150;
            junzi.special_effect_interval = 0.4f;
            junzi.quality = Rarity.R2_Epic;
            junzi.equipment_type = EquipmentType.Weapon;
            junzi.name_class = "item_class_weapon";

            junzi.item_modifier_ids = AssetLibrary<EquipmentAsset>.a(new string[]
             {
                   "stunned"
             });

            junzi.path_slash_animation = "effects/slashes/chunSwordEffect";
            junzi.path_icon = $"{PathIcon}/icon_junzi";
            junzi.path_gameplay_sprite = $"weapons/{junzi.id}"; //Make sure image share same name as id
            junzi.gameplay_sprites = getWeaponSprites(junzi.id); //Make sure this path is also valid

            junzi.action_attack_target = new AttackAction(CustomItemActions.junziAttackEffect);        //special attack action
            AssetManager.items.list.AddItem(junzi);
            addToLocale(junzi.id, junzi.translation_key, "有匪君子，如切如磋!");
            #endregion



            #region qiankun gun
            ItemAsset qiankun = AssetManager.items.clone("qiankun", "$weapon");
            qiankun.id = "qiankun";
            qiankun.material = "adamantine";
            qiankun.translation_key = "Qiankun";
            qiankun.equipment_subtype = "qiankun";
            qiankun.group_id = "sword";
            qiankun.animated = false;
            qiankun.is_pool_weapon = false;
            qiankun.unlock(true);
            qiankun.name_templates = AssetLibrary<EquipmentAsset>.l<string>("flame_sword_name");
            qiankun.base_stats = new();
            qiankun.base_stats.set(CustomBaseStatsConstant.Damage, 70f);
            qiankun.base_stats.set(CustomBaseStatsConstant.AttackSpeed, 15f);
            qiankun.base_stats.set(CustomBaseStatsConstant.Speed, 10f);
            qiankun.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.5f);
            qiankun.base_stats.set(CustomBaseStatsConstant.Knockback, 0.5f);
            qiankun.equipment_value = 140;
            qiankun.special_effect_interval = 0.4f;
            qiankun.quality = Rarity.R2_Epic;
            qiankun.equipment_type = EquipmentType.Weapon;
            qiankun.name_class = "item_class_weapon";

            qiankun.path_slash_animation = "effects/slashes/sheSpearEffect";
            qiankun.path_icon = $"{PathIcon}/icon_qiankun";
            qiankun.path_gameplay_sprite = $"weapons/{qiankun.id}"; //Make sure image share same name as id
            qiankun.gameplay_sprites = getWeaponSprites(qiankun.id); //Make sure this path is also valid

            qiankun.action_attack_target = new AttackAction(CustomItemActions.qiankunAttackEffect);        //special attack action
            AssetManager.items.list.AddItem(qiankun);
            addToLocale(qiankun.id, qiankun.translation_key, "天地有正气，杂然复流形!");
            #endregion

            #region ruyi
            ItemAsset ruyi = AssetManager.items.clone("ruyi", "$weapon");
            ruyi.id = "ruyi";
            ruyi.material = "adamantine";
            ruyi.translation_key = "Ruyi";
            ruyi.equipment_subtype = "ruyi";
            ruyi.group_id = "sword";
            ruyi.animated = false;
            ruyi.is_pool_weapon = false;
            ruyi.unlock(true);
            ruyi.name_templates = AssetLibrary<EquipmentAsset>.l<string>("flame_sword_name");
            ruyi.base_stats = new();
            ruyi.base_stats.set(CustomBaseStatsConstant.Damage, 50f);
            ruyi.base_stats.set(CustomBaseStatsConstant.AttackSpeed, 10f);
            ruyi.base_stats.set(CustomBaseStatsConstant.Speed, 5f);
            ruyi.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.7f);
            ruyi.base_stats.set(CustomBaseStatsConstant.Knockback, 0.5f);
            ruyi.equipment_value = 130;
            ruyi.quality = Rarity.R2_Epic;
            ruyi.equipment_type = EquipmentType.Weapon;
            ruyi.name_class = "item_class_weapon";

            ruyi.path_slash_animation = "effects/slashes/sheSpearEffect";
            ruyi.path_icon = $"{PathIcon}/icon_ruyi";
            ruyi.path_gameplay_sprite = $"weapons/{ruyi.id}"; //Make sure image share same name as id
            ruyi.gameplay_sprites = getWeaponSprites(ruyi.id); //Make sure this path is also valid

            ruyi.action_attack_target = new AttackAction(CustomItemActions.ruyiAttackEffect);        //special attack action
            AssetManager.items.list.AddItem(ruyi);
            addToLocale(ruyi.id, ruyi.translation_key, "七十而随心所欲!");
            #endregion

            #region qingming
            ItemAsset qingming = AssetManager.items.clone("qingming", "$weapon");
            qingming.id = "qingming";
            qingming.material = "adamantine";
            qingming.translation_key = "Qingming";
            qingming.equipment_subtype = "qingming";
            qingming.group_id = "sword";
            qingming.animated = false;
            qingming.is_pool_weapon = false;
            qingming.unlock(true);
            qingming.name_templates = AssetLibrary<EquipmentAsset>.l<string>("flame_sword_name");
            qingming.base_stats = new();
            qingming.base_stats.set(CustomBaseStatsConstant.Damage, 30f);
            qingming.base_stats.set(CustomBaseStatsConstant.AttackSpeed, 50f);
            qingming.base_stats.set(CustomBaseStatsConstant.MultiplierMana, 0.7f);
            qingming.equipment_value = 150;
            qingming.quality = Rarity.R2_Epic;
            qingming.equipment_type = EquipmentType.Weapon;
            qingming.name_class = "item_class_weapon";

            qingming.path_slash_animation = "effects/slashes/sheSpearEffect";
            qingming.path_icon = $"{PathIcon}/icon_qingming";
            qingming.path_gameplay_sprite = $"weapons/{qingming.id}"; //Make sure image share same name as id
            qingming.gameplay_sprites = getWeaponSprites(qingming.id); //Make sure this path is also valid

            qingming.action_attack_target = new AttackAction(CustomItemActions.qingmingAttackEffect);        //special attack action
            AssetManager.items.list.AddItem(qingming);
            addToLocale(qingming.id, qingming.translation_key, "上穷碧落下黄泉，两处茫茫皆不见!");
            #endregion
        }

        private static void addToLocale(string id, string translation_key, string description)
        {
        }

        public static Sprite[] getWeaponSprites(string id)
        {
            var sprite = Resources.Load<Sprite>("weapons/" + id);
            if (sprite != null)
                return new Sprite[] { sprite };
            else
            {
                ChunqiuMain.LogError("Can not find weapon sprite for weapon with this id: " + id);
                return Array.Empty<Sprite>();
            }
        }
    }
}
