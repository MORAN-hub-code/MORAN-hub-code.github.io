using System;
using System.Collections.Generic;
using System.Reflection;

namespace traitExampleMod.code.Config
{
    public class BloodlineConfig
    {
        /// <summary>
        /// 是否允许随机生成血脉特质
        /// </summary>
        public static bool SpawnRandomTraitAllowed { get; set; } = true;
        
        /// <summary>
        /// 随机生成血脉特质开关回调
        /// </summary>
        /// <param name="pCurrentValue">当前值</param>
        public static void SpawnRandomTraitAllowedSwitchConfigCallBack(bool pCurrentValue)
        {
            SpawnRandomTraitAllowed = pCurrentValue;
            // 重新初始化氏族特质库的随机生成列表
            ReinitializeClanTraitLibrary();
        }
        
        /// <summary>
        /// 重新初始化氏族特质库的随机生成列表
        /// </summary>
        private static void ReinitializeClanTraitLibrary()
        {
            try
            {
                // 获取ClanTraitLibrary实例
                var clanTraitsLibrary = AssetManager.clan_traits;
                
                // 使用反射获取_pot_allowed_to_be_given_randomly字段
                FieldInfo potField = typeof(BaseTraitLibrary<ClanTrait>).GetField("_pot_allowed_to_be_given_randomly", BindingFlags.NonPublic | BindingFlags.Instance);
                if (potField != null)
                {
                    // 获取现有的随机生成列表
                    List<ClanTrait> potList = (List<ClanTrait>)potField.GetValue(clanTraitsLibrary);
                    
                    // 定义血脉特质ID列表
                    string[] bloodlineTraitIds = {
                        "ancestry0", "ancestry01", "ancestry02", "ancestry1", "ancestry2",
                        "ancestry3", "ancestry4", "ancestry5", "ancestry6", "ancestry7",
                        "ancestry8", "ancestry9", "ancestry99"
                    };
                    
                    // 从_pot_allowed_to_be_given_randomly列表中移除所有血脉特质
                    potList.RemoveAll(trait => Array.IndexOf(bloodlineTraitIds, trait.id) >= 0);
                    
                    // 如果允许随机生成血脉特质，则将血脉特质添加回_pot_allowed_to_be_given_randomly列表
                    if (SpawnRandomTraitAllowed)
                    {
                        foreach (string traitId in bloodlineTraitIds)
                        {
                            ClanTrait trait = clanTraitsLibrary.get(traitId);
                            if (trait != null && trait.spawn_random_trait_allowed)
                            {
                                clanTraitsLibrary._pot_allowed_to_be_given_randomly.AddTimes(trait.spawn_random_rate, trait);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 如果出现异常，至少更新所有血脉特质的spawn_random_trait_allowed属性
                UpdateAllBloodlineTraits();
            }
        }
        
        /// <summary>
        /// 更新所有血脉特质的spawn_random_trait_allowed属性
        /// </summary>
        private static void UpdateAllBloodlineTraits()
        {
            try
            {
                var clanTraitsLibrary = AssetManager.clan_traits;
                // 定义血脉特质ID列表
                string[] bloodlineTraitIds = {
                    "ancestry0", "ancestry01", "ancestry02", "ancestry1", "ancestry2", 
                    "ancestry3", "ancestry4", "ancestry5", "ancestry6", "ancestry7", 
                    "ancestry8", "ancestry9", "ancestry99"
                };
                
                foreach (string traitId in bloodlineTraitIds)
                {
                    ClanTrait trait = clanTraitsLibrary.get(traitId);
                    if (trait != null)
                    {
                        trait.spawn_random_trait_allowed = SpawnRandomTraitAllowed;
                    }
                }
            }
            catch
            {
                // 静默处理异常
            }
        }
    }
}