using ai;
using UnityEngine;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace traitExampleMod.code
{
    public static class ActorExtensions
    {
        private const string title_guid_key = "attribute.title_guid";
        // 头衔管理扩展方法
        public static string GetTitle(this Actor actor, string title_guid)
        {
            actor.data.get(title_guid, out string title, "头衔");
            return title;
        }

        public static List<string> GetTitleGuids(this Actor actor)
        {
            actor.data.get(title_guid_key, out string title_guids_str);
            if (string.IsNullOrEmpty(title_guids_str))
            {
                return new List<string>();
            }
            return new List<string>(title_guids_str.Split(','));
        }

        public static void AddTitleGuid(this Actor actor, string title_guid)
        {
            var title_guids = actor.GetTitleGuids();
            if (!title_guids.Contains(title_guid))
            {
                title_guids.Add(title_guid);
                actor.data.set(title_guid_key, string.Join(",", title_guids));
            }
        }

        public static void RemoveTitleGuid(this Actor actor, string title_guid)
        {
            var title_guids = actor.GetTitleGuids();
            if (title_guids.Contains(title_guid))
            {
                title_guids.Remove(title_guid);
                actor.data.set(title_guid_key, string.Join(",", title_guids));
            }
        }
        
        // 血脉头衔管理方法
        private const string ancestry_title_key = "attribute.ancestry_title";
        
        public static void SetAncestryTitle(this Actor actor, string ancestryId)
        {
            // 根据血脉ID添加对应的头衔
            switch (ancestryId)
            {
                case "ancestry0": // 焚炎之族
                    SetTitle(actor, "ancestry0_title", "焚炎之族", new Color(1f, 0.15f, 0f, 1f));//#ff2700
                    break;
                case "ancestry01": // 凛冬之脉
                    SetTitle(actor, "ancestry01_title", "凛冬之脉", new Color(0.44f, 0.93f, 1f, 1f));//#70edff
                    break;
                case "ancestry02": // 天罚之裔
                    SetTitle(actor, "ancestry02_title", "天罚之裔", new Color(0.98f, 0.95f, 0.21f, 1f));//#fbf236
                    break;
                case "ancestry1": // 光明圣血
                    SetTitle(actor, "ancestry1_title", "光明圣血", new Color(1f, 0.99f, 0f, 1f));//#fffc00
                    break;
                case "ancestry2": // 古槐之血
                    SetTitle(actor, "ancestry2_title", "古槐之血", new Color(0.28f, 0.49f, 0.04f, 1f));//#487d0a
                    break;
                case "ancestry3": // 夜月血脉
                    SetTitle(actor, "ancestry3_title", "夜月血脉", new Color(0f, 0.22f, 1f, 1f));//#0038ff
                    break;
                case "ancestry4": // 天璇守族
                    SetTitle(actor, "ancestry4_title", "天璇守族", new Color(0f, 0f, 0f, 1f));//#000000
                    break;
                case "ancestry5": // 智灵之族
                    SetTitle(actor, "ancestry5_title", "智灵之族", new Color(0f, 0f, 0f, 1f));//#000000
                    break;
                case "ancestry6": // 风语之脉
                    SetTitle(actor, "ancestry6_title", "风语之脉", new Color(0f, 0.96f, 1f, 1f));//#00f5ff
                    break;
                case "ancestry7": // 血族
                    SetTitle(actor, "ancestry7_title", "血族", new Color(1f, 0f, 0f, 1f));//#ff0000
                    break;
                case "ancestry8": // 狂战之族
                    SetTitle(actor, "ancestry8_title", "狂战之族", new Color(1f, 0.33f, 0.04f, 1f));//#ff530a
                    break;
                case "ancestry9": // 铸币者权柄
                    SetTitle(actor, "ancestry9_title", "铸币者权柄", new Color(0.98f, 0.95f, 0.21f, 1f));//#fbf236
                    break;
                case "ancestry91": // 烬环之契
                    SetTitle(actor, "ancestry91_title", "烬环之契", new Color(1f, 0f, 0f, 1f));//#ff0000
                    break;
                case "ancestry99": // 归寂之裔
                    SetTitle(actor, "ancestry99_title", "归寂之裔", new Color(0f, 0f, 0f, 1f));//#000000
                    break;
            }
        }
        
        // 设置头衔的方法
        public static void SetTitle(this Actor actor, string title_guid, string title_text, Color title_color)
        {
            actor.data.set(title_guid, title_text);
            actor.AddTitleGuid(title_guid);
            string colorHex = ColorUtility.ToHtmlStringRGBA(title_color);
            actor.data.set("attribute.title_color_" + title_guid, colorHex);
        }
        
        // 移除头衔的方法
        public static void RemoveTitle(this Actor actor, string title_guid)
        {
            actor.RemoveTitleGuid(title_guid);
        }
    }
}