using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;

namespace traitExampleMod.code
{
	internal class traits
	{
		private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
		{
			ActorTrait trait = new ActorTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		public static void Init()
		{
			ClanTrait ancestry0 = CclanTrait("ancestry0", "trait/ancestry0", "ClantempGroup");
			ancestry0.rarity = Rarity.R3_Legendary;
			SafeSetStat(ancestry0.base_stats, strings.S.lifespan, 20f);//寿命
			SafeSetStat(ancestry0.base_stats, strings.S.stamina, 60f);//耐力
			SafeSetStat(ancestry0.base_stats, strings.S.damage, 90f);//伤害
			SafeSetStat(ancestry0.base_stats, strings.S.speed, 1f);//速度
			SafeSetStat(ancestry0.base_stats, strings.S.health, 500f);//生命值
			SafeSetStat(ancestry0.base_stats, strings.S.armor, 10f);//护甲
			SafeSetStat(ancestry0.base_stats, strings.S.intelligence, 5f);//智力
			SafeSetStat(ancestry0.base_stats, strings.S.critical_chance, 0.2f);//暴击几率
			SafeSetStat(ancestry0.base_stats, strings.S.multiplier_damage, 0.2f);//伤害倍率
			SafeSetStat(ancestry0.base_stats, strings.S.range, 3f);//范围
			SafeSetStat(ancestry0.base_stats, strings.S.targets, 5f);//目标
			SafeSetStat(ancestry0.base_stats, strings.S.knockback, 1f);//击退
			SafeSetStat(ancestry0.base_stats, "Resist", 1f);//抗性
			SafeSetStat(ancestry0.base_stats, "ArmorPenPercent", 15f);//护甲穿透百分比
			ancestry0.action_attack_target += new AttackAction(attack_ancestry0);//攻击时触发
			ancestry0.action_special_effect += new WorldAction(ancestry0Regen);
			ancestry0.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry0);

			ClanTrait ancestry01 = CclanTrait("ancestry01", "trait/ancestry01", "ClantempGroup");
			ancestry01.rarity = Rarity.R3_Legendary;
			SafeSetStat(ancestry01.base_stats, strings.S.lifespan, 20f);//寿命
			SafeSetStat(ancestry01.base_stats, strings.S.stamina, 60f);//耐力
			SafeSetStat(ancestry01.base_stats, strings.S.damage, 70f);//伤害
			SafeSetStat(ancestry01.base_stats, strings.S.speed, 1f);//速度
			SafeSetStat(ancestry01.base_stats, strings.S.health, 888f);//生命值
			SafeSetStat(ancestry01.base_stats, strings.S.armor, 20f);//护甲
			SafeSetStat(ancestry01.base_stats, strings.S.intelligence, 5f);//智力
			SafeSetStat(ancestry01.base_stats, strings.S.critical_chance, 0.1f);//暴击几率
			SafeSetStat(ancestry01.base_stats, strings.S.multiplier_damage, 0.2f);//伤害倍率
			SafeSetStat(ancestry01.base_stats, strings.S.range, 3f);//范围
			SafeSetStat(ancestry01.base_stats, strings.S.targets, 5f);//目标
			SafeSetStat(ancestry01.base_stats, strings.S.knockback, 1f);//击退
			SafeSetStat(ancestry01.base_stats, "Resist", 2f);//抗性
			SafeSetStat(ancestry01.base_stats, "ArmorPenPercent", 15f);//护甲穿透百分比
			ancestry01.action_attack_target += new AttackAction(attack_ancestry01);//攻击时触发
			ancestry01.action_special_effect += new WorldAction(ancestry01Regen);
			ancestry01.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry01);

			ClanTrait ancestry02 = CclanTrait("ancestry02", "trait/ancestry02", "ClantempGroup");
			ancestry02.rarity = Rarity.R3_Legendary;//天罚之裔
			SafeSetStat(ancestry02.base_stats, strings.S.lifespan, 20f);//寿命
			SafeSetStat(ancestry02.base_stats, strings.S.stamina, 60f);//耐力
			SafeSetStat(ancestry02.base_stats, strings.S.damage, 80f);//伤害
			SafeSetStat(ancestry02.base_stats, strings.S.speed, 1f);//速度
			SafeSetStat(ancestry02.base_stats, strings.S.health, 500f);//生命值
			SafeSetStat(ancestry02.base_stats, strings.S.armor, 10f);//护甲
			SafeSetStat(ancestry02.base_stats, strings.S.intelligence, 5f);//智力
			SafeSetStat(ancestry02.base_stats, strings.S.critical_chance, 0.3f);//暴击几率
			SafeSetStat(ancestry02.base_stats, strings.S.multiplier_damage, 0.3f);//伤害倍率
			SafeSetStat(ancestry02.base_stats, strings.S.range, 3f);//范围
			SafeSetStat(ancestry02.base_stats, strings.S.targets, 5f);//目标
			SafeSetStat(ancestry02.base_stats, strings.S.knockback, 2f);//击退
			SafeSetStat(ancestry02.base_stats, "Resist", 1f);//抗性
			SafeSetStat(ancestry02.base_stats, "ArmorPenPercent", 28f);//护甲穿透百分比
			ancestry02.action_attack_target += new AttackAction(attack_ancestry02);//攻击时触发
			ancestry02.action_special_effect += new WorldAction(ancestry02Regen);
			ancestry02.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry02);

			ClanTrait sunU = CclanTrait("ancestry1", "trait/sunU", "ClantempGroup");
			sunU.rarity = Rarity.R3_Legendary;//光明圣血
			SafeSetStat(sunU.base_stats, strings.S.lifespan, 60f);
			SafeSetStat(sunU.base_stats, strings.S.stamina, 60f);
			SafeSetStat(sunU.base_stats, strings.S.damage, 70f);
			SafeSetStat(sunU.base_stats, strings.S.speed, 1f);
			SafeSetStat(sunU.base_stats, strings.S.health, 688f);
			SafeSetStat(sunU.base_stats, strings.S.armor, 20f);
			SafeSetStat(sunU.base_stats, strings.S.intelligence, 5f);
			SafeSetStat(sunU.base_stats, strings.S.attack_speed, 3f);
			SafeSetStat(sunU.base_stats, strings.S.critical_chance, 0.2f);
			SafeSetStat(sunU.base_stats, strings.S.stewardship, 20f);
			SafeSetStat(sunU.base_stats, strings.S.multiplier_damage, 0.2f);
			SafeSetStat(sunU.base_stats, strings.S.cities, 5f);
			SafeSetStat(sunU.base_stats, strings.S.range, 3f);
			SafeSetStat(sunU.base_stats, strings.S.targets, 5f);
			SafeSetStat(sunU.base_stats, strings.S.knockback, 3f);
			SafeSetStat(sunU.base_stats, "Resist", 2f);
			SafeSetStat(sunU.base_stats, "ArmorPenPercent", 8f);
			SafeSetStat(sunU.base_stats, strings.S.mass_2, 20f);
			sunU.action_special_effect += new WorldAction(sunUMethod);
			sunU.action_special_effect += new WorldAction(ancestry1Regen);
			AssetManager.clan_traits.add(sunU);

			ClanTrait tree = CclanTrait("ancestry2", "trait/tree", "ClantempGroup");
			tree.rarity = Rarity.R3_Legendary;//古槐之血
			SafeSetStat(tree.base_stats, strings.S.lifespan, 120f);
			SafeSetStat(tree.base_stats, strings.S.stamina, 90f);
			SafeSetStat(tree.base_stats, strings.S.damage, 50f);
			SafeSetStat(tree.base_stats, strings.S.health, 888f);
			SafeSetStat(tree.base_stats, strings.S.armor, 20f);
			SafeSetStat(tree.base_stats, strings.S.intelligence, 5f);
			SafeSetStat(tree.base_stats, strings.S.attack_speed, 2f);
			SafeSetStat(tree.base_stats, strings.S.stewardship, 20f);
			SafeSetStat(tree.base_stats, strings.S.multiplier_health, 0.3f);
			SafeSetStat(tree.base_stats, strings.S.range, 2f);
			SafeSetStat(tree.base_stats, strings.S.targets, 5f);
			SafeSetStat(tree.base_stats, strings.S.knockback, 1f);
			SafeSetStat(tree.base_stats, "Resist", 1f);
			SafeSetStat(tree.base_stats, strings.S.mass_2, 20f);
			tree.action_special_effect += new WorldAction(ancestry2Regen);
			tree.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(tree);

			ClanTrait moonM = CclanTrait("ancestry3", "trait/moonM", "ClantempGroup");
			moonM.rarity = Rarity.R2_Epic;//夜月血脉
			SafeSetStat(moonM.base_stats, strings.S.diplomacy, 5f);
			SafeSetStat(moonM.base_stats, strings.S.lifespan, 50f);
			SafeSetStat(moonM.base_stats, strings.S.stamina, 40f);
			SafeSetStat(moonM.base_stats, strings.S.damage, 60f);
			SafeSetStat(moonM.base_stats, strings.S.speed, 0.5f);
			SafeSetStat(moonM.base_stats, strings.S.health, 588f);
			SafeSetStat(moonM.base_stats, strings.S.armor, 20f);
			SafeSetStat(moonM.base_stats, strings.S.intelligence, 5f);
			SafeSetStat(moonM.base_stats, strings.S.attack_speed, 2f);
			SafeSetStat(moonM.base_stats, strings.S.multiplier_damage, 0.3f);
			SafeSetStat(moonM.base_stats, strings.S.multiplier_health, 0.10f);
			SafeSetStat(moonM.base_stats, strings.S.critical_chance, 0.1f);
			SafeSetStat(moonM.base_stats, strings.S.cities, 3f);
			SafeSetStat(moonM.base_stats, strings.S.range, 3f);
			SafeSetStat(moonM.base_stats, strings.S.targets, 3f);
			SafeSetStat(moonM.base_stats, strings.S.knockback, 1f);
			SafeSetStat(moonM.base_stats, "Resist", 1f);
			SafeSetStat(moonM.base_stats, strings.S.mass_2, 10f);
			moonM.action_special_effect += new WorldAction(ancestry3Regen);
			moonM.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(moonM);

			ClanTrait guard = CclanTrait("ancestry4", "trait/guard", "ClantempGroup");
			guard.rarity = Rarity.R2_Epic;//天璇守族
			SafeSetStat(guard.base_stats, strings.S.lifespan, 40f);
			SafeSetStat(guard.base_stats, strings.S.stamina, 50f);
			SafeSetStat(guard.base_stats, strings.S.damage, 50f);
			SafeSetStat(guard.base_stats, strings.S.health, 700f);
			SafeSetStat(guard.base_stats, strings.S.armor, 30f);//+5
			SafeSetStat(guard.base_stats, strings.S.intelligence, 5f);//删除攻速 2f
			SafeSetStat(guard.base_stats, strings.S.multiplier_health, 0.2f);
			SafeSetStat(guard.base_stats, strings.S.targets, 2f);
			SafeSetStat(guard.base_stats, strings.S.knockback, 1f);
			SafeSetStat(guard.base_stats, "Resist", 2f);
			SafeSetStat(guard.base_stats, strings.S.mass_2, 20f);
			guard.action_special_effect += new WorldAction(ancestry4Regen);
			guard.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(guard);

			ClanTrait wisdom = CclanTrait("ancestry5", "trait/wisdom", "ClantempGroup");
			wisdom.rarity = Rarity.R2_Epic;//智灵之族
			SafeSetStat(wisdom.base_stats, strings.S.lifespan, 45f);
			SafeSetStat(wisdom.base_stats, strings.S.stamina, 30f);
			SafeSetStat(wisdom.base_stats, strings.S.damage, 50f);
			SafeSetStat(wisdom.base_stats, strings.S.health, 400f);
			SafeSetStat(wisdom.base_stats, strings.S.armor, 10f);
			SafeSetStat(wisdom.base_stats, strings.S.intelligence, 12f);//删除攻速 2f
			SafeSetStat(wisdom.base_stats, strings.S.critical_chance, 0.2f);
			SafeSetStat(wisdom.base_stats, strings.S.warfare, 15f);
			SafeSetStat(wisdom.base_stats, strings.S.stewardship, 10f);
			SafeSetStat(wisdom.base_stats, strings.S.multiplier_health, 0.1f);
			SafeSetStat(wisdom.base_stats, strings.S.cities, 6f);
			SafeSetStat(wisdom.base_stats, strings.S.range, 5f);
			SafeSetStat(wisdom.base_stats, strings.S.area_of_effect, 2f);
			SafeSetStat(wisdom.base_stats, strings.S.mana, 200f);
			SafeSetStat(wisdom.base_stats, strings.S.targets, 3f);//+1
			SafeSetStat(wisdom.base_stats, strings.S.knockback, 1f);
			SafeSetStat(wisdom.base_stats, "Resist", 1f);
			SafeSetStat(wisdom.base_stats, "ArmorPenPercent", 12f);
			SafeSetStat(wisdom.base_stats, "Accuracy", 20f);
			wisdom.action_special_effect += new WorldAction(ancestry5Regen);
			wisdom.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(wisdom);

			ClanTrait wind = CclanTrait("ancestry6", "trait/wind", "ClantempGroup");
			wind.rarity = Rarity.R2_Epic;//风语之脉
			SafeSetStat(wind.base_stats, strings.S.diplomacy, 5f);
			SafeSetStat(wind.base_stats, strings.S.lifespan, 35f);
			SafeSetStat(wind.base_stats, strings.S.stamina, 40f);
			SafeSetStat(wind.base_stats, strings.S.damage, 60f);
			SafeSetStat(wind.base_stats, strings.S.speed, 6f);
			SafeSetStat(wind.base_stats, strings.S.health, 555f);
			SafeSetStat(wind.base_stats, strings.S.armor, 20f);
			SafeSetStat(wind.base_stats, strings.S.intelligence, 3f);
			SafeSetStat(wind.base_stats, strings.S.attack_speed, 5f);//6f削为5f
			SafeSetStat(wind.base_stats, strings.S.critical_chance, 0.1f);
			SafeSetStat(wind.base_stats, strings.S.range, 2f);
			SafeSetStat(wind.base_stats, strings.S.targets, 2f);
			SafeSetStat(wind.base_stats, strings.S.knockback, 1f);
			SafeSetStat(wind.base_stats, "Resist", 1f);
			SafeSetStat(wind.base_stats, "Dodge", 20f);
			wind.action_special_effect += new WorldAction(ancestry6Regen);
			wind.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(wind);

			ClanTrait ancestry7 = CclanTrait("ancestry7", "trait/ancestry7", "ClantempGroup");
			ancestry7.rarity = Rarity.R2_Epic;//血族
			SafeSetStat(ancestry7.base_stats, strings.S.lifespan, 50f);
			SafeSetStat(ancestry7.base_stats, strings.S.stamina, 60f);
			SafeSetStat(ancestry7.base_stats, strings.S.damage, 70f);
			SafeSetStat(ancestry7.base_stats, strings.S.health, 300f);
			SafeSetStat(ancestry7.base_stats, strings.S.armor, 20f);
			SafeSetStat(ancestry7.base_stats, strings.S.range, 2f);
			SafeSetStat(ancestry7.base_stats, strings.S.area_of_effect, 2f);
			SafeSetStat(ancestry7.base_stats, strings.S.targets, 1f);
			SafeSetStat(ancestry7.base_stats, strings.S.knockback, 1f);
			SafeSetStat(ancestry7.base_stats, "Vampire", 300f);
			ancestry7.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry7);

			ClanTrait ancestry8 = CclanTrait("ancestry8", "trait/ancestry8", "ClantempGroup");
			ancestry8.rarity = Rarity.R3_Legendary;//狂战之族
			SafeSetStat(ancestry8.base_stats, strings.S.lifespan, 20f);
			SafeSetStat(ancestry8.base_stats, strings.S.stamina, 60f);
			SafeSetStat(ancestry8.base_stats, strings.S.damage, 100f);
			SafeSetStat(ancestry8.base_stats, strings.S.speed, 1f);
			SafeSetStat(ancestry8.base_stats, strings.S.health, 200f);
			SafeSetStat(ancestry8.base_stats, strings.S.armor, 10f);
			SafeSetStat(ancestry8.base_stats, strings.S.critical_chance, 0.3f);
			SafeSetStat(ancestry8.base_stats, strings.S.critical_damage_multiplier, 0.3f);
			SafeSetStat(ancestry8.base_stats, strings.S.mass_2, 20f);
			SafeSetStat(ancestry8.base_stats, strings.S.range, 2f);
			SafeSetStat(ancestry8.base_stats, strings.S.area_of_effect, 2f);
			SafeSetStat(ancestry8.base_stats, strings.S.scale, 0.02f);
			SafeSetStat(ancestry8.base_stats, strings.S.targets, 3f);
			SafeSetStat(ancestry8.base_stats, strings.S.knockback, 2f);
			SafeSetStat(ancestry8.base_stats, "Resist", 3f);
			ancestry8.action_attack_target += new AttackAction(attack_ancestry8);
			ancestry8.action_get_hit += new GetHitAction(ancestry8_Attack);
			ancestry8.action_special_effect += new WorldAction(ancestry8Regen);
			ancestry8.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry8);

			ClanTrait money = CclanTrait("ancestry9", "trait/money", "ClantempGroup");
			money.rarity = Rarity.R3_Legendary;//铸币者权柄
			money.action_special_effect = Money;
			SafeSetStat(money.base_stats, strings.S.knockback, 1f);
			SafeSetStat(money.base_stats, "Resist", 1f);
			money.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(money);

			ActorTrait hasten = CreateTrait("hasten", "trait/hasten", "acquired");
			hasten.rarity = Rarity.R3_Legendary;//加速进化
			SafeSetStat(hasten.base_stats, strings.S.armor, -5f);
			SafeSetStat(hasten.base_stats, strings.S.cities, -5f);
			AssetManager.traits.add(hasten);

			ClanTrait resurrection = CclanTrait("ancestry91", "trait/resurrection", "ClantempGroup");
			resurrection.rarity = Rarity.R3_Legendary;//烬环之契
			resurrection.action_death = Resurrection;
			SafeSetStat(resurrection.base_stats, strings.S.knockback, 1f);
			SafeSetStat(resurrection.base_stats, "Resist", 1f);
			resurrection.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(resurrection);
			
			ClanTrait ancestry99 = CclanTrait("ancestry99", "trait/ancestry99", "ClantempGroup");
			ancestry99.rarity = Rarity.R3_Legendary;//归寂之裔
			ancestry99.action_death = Resurrection;
			SafeSetStat(ancestry99.base_stats, strings.S.knockback, 1f);
			SafeSetStat(ancestry99.base_stats, "Resist", 1f);
			ancestry99.action_attack_target += new AttackAction(attack_ancestry99);//攻击时触发
			ancestry99.action_special_effect += new WorldAction(sunUMethod);
			AssetManager.clan_traits.add(ancestry99);
		}
		public static bool attack_ancestry8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pSelf == null || !pSelf.isActor())
			{
				return false;
			}
			Actor actor = pSelf.a;
			if (actor == null)
			{
				return false;
			}
			int randomExp = UnityEngine.Random.Range(80, 160);
			pSelf.a.addExperience(randomExp);
			BaseObjectData data = actor.getData();
			if (data == null)
			{
				return false;
			}
			int currentHealth = data.health;
			int maxHealth = actor.getMaxHealth();
			if (currentHealth < maxHealth * 0.8f)
			{
				randomExp = UnityEngine.Random.Range(90, 180);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.5f)
			{
				randomExp = UnityEngine.Random.Range(120, 240);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.3f)
			{
				randomExp = UnityEngine.Random.Range(150, 300);
				pSelf.a.addExperience(randomExp);
			}
			return true;
		}
		public static bool attack_ancestry0(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (Randy.randomChance(0.5f))
			{
				if (!pTarget.isAlive())
				{
					return false;
				}
				if (pTarget.isBuilding() && pTarget.b.isBurnable())
				{
					pTarget.addStatusEffect("burning", 0f, true);
					return true;
				}
				if (pTarget.isActor())
				{
					pTarget.addStatusEffect("burning", 0f, true);
					return true;
				}
				return false;
			}
			return false;
		}
		public static bool attack_ancestry01(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (Randy.randomChance(0.5f))
			{
				if (pTarget.isBuilding())
				{
					return false;
				}
				if (pTarget.current_tile.Type.lava)
				{
					return false;
				}
				if (pTarget.current_tile.isOnFire())
				{
					return false;
				}
				pTarget.addStatusEffect("frozen", 0f, true);
				return true;
			}
			return false;
		}
		public static bool attack_ancestry02(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (Randy.randomChance(0.5f))
			{
				if (pTarget != null)
				{
					Actor a = pTarget.a;
					MapBox.spawnLightningMedium(pTile, 0.10f);
				}
			}
			return false;
		}
		public static bool ancestry8_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pSelf == null || !pSelf.isActor())
			{
				return false;
			}
			Actor actor = pSelf.a;
			if (actor == null)
			{
				return false;
			}
			int randomExp = UnityEngine.Random.Range(80, 160);
			pSelf.a.addExperience(randomExp);
			BaseObjectData data = actor.getData();
			if (data == null)
			{
				return false;
			}
			int currentHealth = data.health;
			int maxHealth = actor.getMaxHealth();
			if (currentHealth < maxHealth * 0.8f)
			{
				randomExp = UnityEngine.Random.Range(90, 180);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.5f)
			{
				randomExp = UnityEngine.Random.Range(120, 240);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.3f)
			{
				randomExp = UnityEngine.Random.Range(150, 300);
				pSelf.a.addExperience(randomExp);
			}

			return true;
		}
		public static bool Money(BaseSimObject pTarget, WorldTile pTile = null)
		{
			int randomExp = UnityEngine.Random.Range(1, 10);
			pTarget.a.addMoney(randomExp);
			return true;
		}
		public static bool sunUMethod(BaseSimObject pTarget, WorldTile pTile = null)
		{
			Actor a = pTarget.a;
			a.addTrait("fire_proof");
			return false;
		}
		public static bool ancestry0Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(5);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry01Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(8);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry02Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(6);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry2Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(30);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry1Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(10);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry3Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(3);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry4Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(7);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry5Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(5);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry6Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(6);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry8Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                int tHealthToRegen = pTarget.a.getMaxHealthPercent(0.02f);
                pTarget.a.restoreHealth(tHealthToRegen);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
			return true;
		}
		public static bool Resurrection(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget == null || !pTarget.isActor())
			{
				return false;
			}
			if (!(pTarget is Actor actor))
			{
				return false;
			}
			IReadOnlyCollection<ActorTrait> traits = actor.getTraits();
			List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
			foreach (string traitId in allTraitIds)
			{
				actor.removeTrait(traitId);
			}
			actor.addTrait("arcane_reflexes");
			actor.addTrait("battle_reflexes");
			// 定义可随机的元素特质列表
			string[] elementTraits = { "blessed", "chosen_one", "heart_of_wizard" };
			string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
			int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
			string selectedCombatTrait = combatActionTraits[randomCombatIndex];
			actor.addTrait(selectedCombatTrait);
			int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
			string selectedElementTrait = elementTraits[randomIndex];
			// 添加随机特质到原Actor
			actor.addTrait(selectedElementTrait);
			// 创建新单位并复制数据
			var act = World.world.units.createNewUnit(actor.asset.id, pTile, true);
			if (pTarget.kingdom.isAlive())
				act.kingdom = pTarget.kingdom;
			if (actor.hasClan() && actor.clan.isAlive())
				act.clan = actor.clan;
			ActorTool.copyUnitToOtherUnit(actor, act);
			act.data.setName(actor.getName());
			act.data.health = 999;
			act.data.created_time = World.world.getCurWorldTime();
			act.data.age_overgrowth = 1;
			act.data.level = 5;
			act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
			// 执行传送和特效
			teleportRandom(act);
			PowerLibrary pb = new PowerLibrary();
			pb.divineLightFX(actor.current_tile, null);
			return true;
		}
		public static bool teleportRandom(Actor a)
		{
			MapBox mapBox = World.world as MapBox;
			if (mapBox == null)
			{
				return false;
			}

			CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
			if (citiesManager == null)
			{
				return false;
			}
			// 优先传送至首都
			City originalCity = citiesManager.list.FirstOrDefault(city => 
				city.kingdom == a.kingdom && 
				city.isCapitalCity() && 
				city.isAlive()
			);
			WorldTile targetTile = null;
			// 优先传送至首都
			if (originalCity != null)
			{
				targetTile = originalCity.getTile();
			}
			else // 次选随机王国存活城市
			{
				List<City> kingdomCities = citiesManager.list
					.Where(city => 
						city.kingdom == a.kingdom && 
						city.isAlive())
					.ToList();

				if (kingdomCities.Count == 0)
				{
					return false;
				}

				int randomIndex = UnityEngine.Random.Range(0, kingdomCities.Count);
				targetTile = kingdomCities[randomIndex].getTile();
			}

			if (targetTile == null || targetTile.Type.block || !targetTile.Type.ground)
			{
				return false;
			}

			a.cancelAllBeh();
			a.spawnOn(targetTile, 0f);
			return true;
		}
		private static bool attack_ancestry99(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			// 10% 触发几率
			if (!Randy.randomChance(0.1f))
			{
				return false;
			}
			// 检查目标有效性
			if (pTarget == null || !pTarget.isActor() || !pTarget.isAlive())
			{
				return false;
			}
			Actor targetActor = pTarget.a;
			if (targetActor == null)
			{
				return false;
			}
			// 获取目标所有特质
			IReadOnlyCollection<ActorTrait> traits = targetActor.getTraits();
			if (traits == null || traits.Count == 0)
			{
				return false;
			}
			// 创建可移除特质列表
			List<ActorTrait> removableTraits = new List<ActorTrait>();
			foreach (ActorTrait trait in traits)
			{
				string traitId = trait.getId();
				
				// 排除基础特质和血统特质
				if (//traitId.StartsWith("base_") ||
					traitId == "Grade9" || traitId == "Grade91" || traitId == "flair91" || traitId == "flair92" || traitId == "flair8"
					|| traitId == "extraordinary5" || traitId == "extraordinary6" || traitId == "extraordinary7" || traitId == "talent3" || traitId == "talent4")
				{
					continue;
				}
				
				removableTraits.Add(trait);
			}
			if (removableTraits.Count == 0)
			{
				return false;
			}
			// 随机选择一个特质移除
			int randomIndex = UnityEngine.Random.Range(0, removableTraits.Count);
			ActorTrait traitToRemove = removableTraits[randomIndex];
			string removeTraitId = traitToRemove.getId();
			// 执行移除
			targetActor.removeTrait(removeTraitId);
			// 添加视觉反馈
			pTarget.a.spawnParticle(Toolbox.color_black);
			
			return true;
		}
		private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
		{
			baseStats[statKey] = value;
		}
    }
}
