﻿using NeoModLoader.api;

using traitExampleMod.code;

namespace traitExampleMod
{
    internal class traitExampleMod : BasicMod<traitExampleMod>
    {
        protected override void OnModLoad()
        {
            traitGroup.Init();
            traits.Init();
        }
    }
}
