using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;

namespace traitExampleMod.code
{
	internal class traits
	{
		private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
		{
			ActorTrait trait = new ActorTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		public static void Init()
		{
			ClanTrait Sorcerer = CclanTrait("SorcererClan", "trait/Sorcerer", "spirit");
			Sorcerer.action_special_effect = new WorldAction(SorcererMethod);
			AssetManager.clan_traits.add(Sorcerer);

			ClanTrait Knight = CclanTrait("KnightClan", "trait/Knight", "spirit");
			Knight.action_special_effect = new WorldAction(KnightMethod);
			AssetManager.clan_traits.add(Knight);

			ClanTrait sunU = CclanTrait("ancestry1", "trait/sunU", "ClantempGroup");
			sunU.rarity = Rarity.R3_Legendary;
			SafeSetStat(sunU.base_stats, S.lifespan, 60f);
			SafeSetStat(sunU.base_stats, S.stamina, 60f);
			SafeSetStat(sunU.base_stats, S.damage, 70f);
			SafeSetStat(sunU.base_stats, S.speed, 1f);
			SafeSetStat(sunU.base_stats, S.health, 688f);
			SafeSetStat(sunU.base_stats, S.armor, 20f);
			SafeSetStat(sunU.base_stats, S.intelligence, 5f);
			SafeSetStat(sunU.base_stats, S.attack_speed, 3f);
			SafeSetStat(sunU.base_stats, S.critical_chance, 0.2f);
			SafeSetStat(sunU.base_stats, S.stewardship, 20f);
			SafeSetStat(sunU.base_stats, S.multiplier_damage, 0.2f);
			SafeSetStat(sunU.base_stats, S.cities, 5f);
			SafeSetStat(sunU.base_stats, S.range, 3f);
			SafeSetStat(sunU.base_stats, S.targets, 5f);
			sunU.action_special_effect += new WorldAction(sunUMethod);
			sunU.action_special_effect += new WorldAction(ancestry1Regen);
			AssetManager.clan_traits.add(sunU);

			ClanTrait tree = CclanTrait("ancestry2", "trait/tree", "ClantempGroup");
			tree.rarity = Rarity.R3_Legendary;
			SafeSetStat(tree.base_stats, S.lifespan, 120f);
			SafeSetStat(tree.base_stats, S.stamina, 90f);
			SafeSetStat(tree.base_stats, S.damage, 50f);
			SafeSetStat(tree.base_stats, S.health, 888f);
			SafeSetStat(tree.base_stats, S.armor, 20f);
			SafeSetStat(tree.base_stats, S.intelligence, 5f);
			SafeSetStat(tree.base_stats, S.attack_speed, 2f);
			SafeSetStat(tree.base_stats, S.stewardship, 20f);
			SafeSetStat(tree.base_stats, S.multiplier_health, 0.3f);
			SafeSetStat(tree.base_stats, S.range, 2f);
			SafeSetStat(tree.base_stats, S.targets, 5f);
			tree.action_special_effect = new WorldAction(ancestry2Regen);
			AssetManager.clan_traits.add(tree);

			ClanTrait moonM = CclanTrait("ancestry3", "trait/moonM", "ClantempGroup");
			moonM.rarity = Rarity.R2_Epic;
			SafeSetStat(moonM.base_stats, S.diplomacy, 5f);
			SafeSetStat(moonM.base_stats, S.lifespan, 50f);
			SafeSetStat(moonM.base_stats, S.stamina, 40f);
			SafeSetStat(moonM.base_stats, S.damage, 60f);
			SafeSetStat(moonM.base_stats, S.speed, 0.5f);
			SafeSetStat(moonM.base_stats, S.health, 588f);
			SafeSetStat(moonM.base_stats, S.armor, 20f);
			SafeSetStat(moonM.base_stats, S.intelligence, 5f);
			SafeSetStat(moonM.base_stats, S.attack_speed, 2f);
			SafeSetStat(moonM.base_stats, S.multiplier_damage, 0.3f);
			SafeSetStat(moonM.base_stats, S.multiplier_health, 0.10f);
			SafeSetStat(moonM.base_stats, S.critical_chance, 0.1f);
			SafeSetStat(moonM.base_stats, S.cities, 3f);
			SafeSetStat(moonM.base_stats, S.range, 3f);
			SafeSetStat(moonM.base_stats, S.targets, 3f);
			moonM.action_special_effect = new WorldAction(ancestry3Regen);
			AssetManager.clan_traits.add(moonM);

			ClanTrait guard = CclanTrait("ancestry4", "trait/guard", "ClantempGroup");
			guard.rarity = Rarity.R2_Epic;
			SafeSetStat(guard.base_stats, S.lifespan, 40f);
			SafeSetStat(guard.base_stats, S.stamina, 50f);
			SafeSetStat(guard.base_stats, S.damage, 50f);
			SafeSetStat(guard.base_stats, S.health, 700f);
			SafeSetStat(guard.base_stats, S.armor, 25f);
			SafeSetStat(guard.base_stats, S.intelligence, 5f);
			SafeSetStat(guard.base_stats, S.attack_speed, 2f);
			SafeSetStat(guard.base_stats, S.multiplier_health, 0.2f);
			SafeSetStat(guard.base_stats, S.targets, 2f);
			guard.action_special_effect = new WorldAction(ancestry4Regen);
			AssetManager.clan_traits.add(guard);

			ClanTrait wisdom = CclanTrait("ancestry5", "trait/wisdom", "ClantempGroup");
			wisdom.rarity = Rarity.R2_Epic;
			SafeSetStat(wisdom.base_stats, S.lifespan, 45f);
			SafeSetStat(wisdom.base_stats, S.stamina, 30f);
			SafeSetStat(wisdom.base_stats, S.damage, 50f);
			SafeSetStat(wisdom.base_stats, S.health, 400f);
			SafeSetStat(wisdom.base_stats, S.armor, 10f);
			SafeSetStat(wisdom.base_stats, S.intelligence, 12f);
			SafeSetStat(wisdom.base_stats, S.attack_speed, 2f);
			SafeSetStat(wisdom.base_stats, S.critical_chance, 0.2f);
			SafeSetStat(wisdom.base_stats, S.warfare, 15f);
			SafeSetStat(wisdom.base_stats, S.stewardship, 10f);
			SafeSetStat(wisdom.base_stats, S.multiplier_health, 0.1f);
			SafeSetStat(wisdom.base_stats, S.cities, 6f);
			SafeSetStat(wisdom.base_stats, S.range, 5f);
			SafeSetStat(wisdom.base_stats, S.area_of_effect, 2f);
			SafeSetStat(wisdom.base_stats, S.mana, 200f);
			SafeSetStat(wisdom.base_stats, S.targets, 2f);
			wisdom.action_special_effect = new WorldAction(ancestry5Regen);
			AssetManager.clan_traits.add(wisdom);

			ClanTrait wind = CclanTrait("ancestry6", "trait/wind", "ClantempGroup");
			wind.rarity = Rarity.R2_Epic;
			SafeSetStat(wind.base_stats, S.diplomacy, 5f);
			SafeSetStat(wind.base_stats, S.lifespan, 35f);
			SafeSetStat(wind.base_stats, S.stamina, 40f);
			SafeSetStat(wind.base_stats, S.damage, 60f);
			SafeSetStat(wind.base_stats, S.speed, 6f);
			SafeSetStat(wind.base_stats, S.health, 555f);
			SafeSetStat(wind.base_stats, S.armor, 20f);
			SafeSetStat(wind.base_stats, S.intelligence, 3f);
			SafeSetStat(wind.base_stats, S.attack_speed, 6f);
			SafeSetStat(wind.base_stats, S.critical_chance, 0.1f);
			SafeSetStat(wind.base_stats, S.range, 2f);
			SafeSetStat(wind.base_stats, S.targets, 2f);
			wind.action_special_effect = new WorldAction(ancestry6Regen);
			AssetManager.clan_traits.add(wind);

			ClanTrait ancestry7 = CclanTrait("ancestry7", "trait/ancestry7", "ClantempGroup");
			ancestry7.rarity = Rarity.R2_Epic;
			SafeSetStat(ancestry7.base_stats, S.lifespan, 50f);
			SafeSetStat(ancestry7.base_stats, S.stamina, 60f);
			SafeSetStat(ancestry7.base_stats, S.damage, 70f);
			SafeSetStat(ancestry7.base_stats, S.health, 300f);
			SafeSetStat(ancestry7.base_stats, S.armor, 20f);
			SafeSetStat(ancestry7.base_stats, S.range, 2f);
			SafeSetStat(ancestry7.base_stats, S.area_of_effect, 2f);
			SafeSetStat(ancestry7.base_stats, S.targets, 1f);
			ancestry7.action_attack_target += new AttackAction(attack_ancestry7);
			AssetManager.clan_traits.add(ancestry7);

			ClanTrait ancestry8 = CclanTrait("ancestry8", "trait/ancestry8", "ClantempGroup");
			ancestry8.rarity = Rarity.R3_Legendary;
			SafeSetStat(ancestry8.base_stats, S.lifespan, 20f);
			SafeSetStat(ancestry8.base_stats, S.stamina, 60f);
			SafeSetStat(ancestry8.base_stats, S.damage, 100f);
			SafeSetStat(ancestry8.base_stats, S.speed, 1f);
			SafeSetStat(ancestry8.base_stats, S.health, 200f);
			SafeSetStat(ancestry8.base_stats, S.armor, 10f);
			SafeSetStat(ancestry8.base_stats, S.critical_chance, 0.3f);
			SafeSetStat(ancestry8.base_stats, S.critical_damage_multiplier, 0.3f);
			SafeSetStat(ancestry8.base_stats, S.mass_2, 20f);
			SafeSetStat(ancestry8.base_stats, S.range, 2f);
			SafeSetStat(ancestry8.base_stats, S.area_of_effect, 2f);
			SafeSetStat(ancestry8.base_stats, S.scale, 0.02f);
			SafeSetStat(ancestry8.base_stats, S.targets, 3f);
			ancestry8.action_attack_target += new AttackAction(attack_ancestry8);
			ancestry8.action_get_hit += new GetHitAction(ancestry8_Attack);
			ancestry8.action_special_effect += new WorldAction(ancestry8Regen);
			AssetManager.clan_traits.add(ancestry8);
			
			ClanTrait money = CclanTrait("ancestry9", "trait/money", "ClantempGroup");
			money.rarity = Rarity.R3_Legendary;
			money.action_special_effect = Money;
			AssetManager.clan_traits.add(money);

			ActorTrait hasten = CreateTrait("hasten", "trait/hasten", "acquired");
			hasten.rarity = Rarity.R3_Legendary;
			SafeSetStat(hasten.base_stats, S.armor, -5f);
			SafeSetStat(hasten.base_stats, S.cities, -5f);
			AssetManager.traits.add(hasten);

			ClanTrait resurrection = CclanTrait("resurrection", "trait/resurrection", "ClantempGroup");
			resurrection.rarity = Rarity.R3_Legendary;
			resurrection.action_death = Resurrection;
			AssetManager.clan_traits.add(resurrection);
		}
		public static bool attack_ancestry8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pSelf == null || !pSelf.isActor())
			{
				return false;
			}
			Actor actor = pSelf.a;
			if (actor == null)
			{
				return false;
			}
			int randomExp = UnityEngine.Random.Range(60, 120);
			pSelf.a.addExperience(randomExp);
			BaseObjectData data = actor.getData();
			if (data == null)
			{
				return false;
			}
			int currentHealth = data.health;
			int maxHealth = actor.getMaxHealth();
			if (currentHealth < maxHealth * 0.8f)
			{
				randomExp = UnityEngine.Random.Range(90, 150);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.5f)
			{
				randomExp = UnityEngine.Random.Range(120, 180);
				pSelf.a.addExperience(randomExp);
			}
			if (currentHealth < maxHealth * 0.3f)
			{
				randomExp = UnityEngine.Random.Range(150, 210);
				pSelf.a.addExperience(randomExp);
			}
			return true;
		}
		public static bool ancestry8_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }
			int randomExp = UnityEngine.Random.Range(60, 120);
            pSelf.a.addExperience(randomExp);
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();
            if (currentHealth < maxHealth * 0.8f)
            {
                randomExp = UnityEngine.Random.Range(90, 150);
            	pSelf.a.addExperience(randomExp);
            }
            if (currentHealth < maxHealth * 0.5f)
            {
                randomExp = UnityEngine.Random.Range(120, 180);
            	pSelf.a.addExperience(randomExp);
            }
			if (currentHealth < maxHealth * 0.3f)
			{
				randomExp = UnityEngine.Random.Range(150, 210);
				pSelf.a.addExperience(randomExp);
			}

            return true;
        }
		public static bool attack_ancestry7(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false;
            }

            if (pTarget.isBuilding())
            {
                return false; // 如果目标是建筑，则返回false
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health <= 1)
            {
                return false; // 如果没有足够的血量，则返回false
            }
			int drainAmount = UnityEngine.Random.Range(10, 31); // 随机汲取的血量范围在10到30之间
            // 目标有足够的血量，执行汲取操作
            pTarget.a.spawnParticle(Toolbox.makeColor("#FF0000"));
            int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health - 1); // 实际汲取的血量，确保目标至少保留1点血量
            pTarget.a.data.health -= actualDrain; // 减少目标的血量
            pSelf.a.data.health = Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量

            return true;
        }
		public static bool SorcererMethod(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (!(pTarget is Actor actor))
			{
				return false;
			}
			float age = actor.getAge();
			bool shouldAddFlair = Mathf.FloorToInt(age) == 8 && !actor.hasTrait("flair1") && !actor.hasTrait("flair2") && !actor.hasTrait("flair3") 
				&& !actor.hasTrait("flair4") && !actor.hasTrait("flair5") && !actor.hasTrait("flair6") && !actor.hasTrait("flair7");
			if (shouldAddFlair)
			{
				var flairWeights = new (string traitId, int weight)[]
				{
					("flair1", 5442),
					("flair2", 2750),
					("flair3", 1200),
					("flair4", 500),
					("flair5", 100),
					("flair6", 6),
					("flair7", 2)
				};
				int totalWeight = flairWeights.Sum(t => t.weight);
				int randomValue = UnityEngine.Random.Range(0, totalWeight);
				string selectedflair = "flair1";
				foreach (var flair in flairWeights)
				{
					if (randomValue < flair.weight)
					{
						selectedflair = flair.traitId;
						break;
					}
					randomValue -= flair.weight;
				}
				actor.addTrait(selectedflair, false);
			}
			return true;
		}
		public static bool KnightMethod(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (!(pTarget is Actor actor))
			{
				return false;
			}
			float age = actor.getAge();
			bool shouldAddTalent = Mathf.FloorToInt(age) == 9 && !actor.hasTrait("talent1") && !actor.hasTrait("talent2") 
				&& !actor.hasTrait("talent3") && !actor.hasTrait("talent4");
			if (shouldAddTalent)
			{
				var talentWeights = new (string traitId, int weight)[]
				{
					("talent1", 60),
					("talent2", 30),
					("talent3", 9),
					("talent4", 1)
				};
				int totalWeight = talentWeights.Sum(t => t.weight);
				int randomValue = UnityEngine.Random.Range(0, totalWeight);
				string selectedTalent = "talent1";
				foreach (var talent in talentWeights)
				{
					if (randomValue < talent.weight)
					{
						selectedTalent = talent.traitId;
						break;
					}
					randomValue -= talent.weight;
				}
				actor.addTrait(selectedTalent, false);
			}
			return true;
		}

		public static bool Money(BaseSimObject pTarget, WorldTile pTile = null)
		{
			int randomExp = UnityEngine.Random.Range(1, 10);
			pTarget.a.addMoney(randomExp);
			return true;
		}
		public static bool sunUMethod(BaseSimObject pTarget, WorldTile pTile = null)
		{
			Actor a = pTarget.a;
			a.addTrait("fire_proof");
			return false;
		}
		public static bool ancestry2Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(30);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry1Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(10);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry3Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(3);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry4Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(7);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry5Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(5);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry6Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(6);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool ancestry8Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                int tHealthToRegen = pTarget.a.getMaxHealthPercent(0.02f);
                pTarget.a.restoreHealth(tHealthToRegen);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
			return true;
		}
		public static bool Resurrection(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget == null || !pTarget.isActor())
			{
				return false;
			}
			if (!(pTarget is Actor actor))
			{
				return false;
			}
			IReadOnlyCollection<ActorTrait> traits = actor.getTraits();
			List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
			foreach (string traitId in allTraitIds)
			{
				actor.removeTrait(traitId);
			}
			actor.addTrait("arcane_reflexes");
			actor.addTrait("battle_reflexes");
			actor.addTrait("fast");
			// 定义可随机的元素特质列表
			string[] elementTraits = { "blessed", "chosen_one", "heart_of_wizard" };
			string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
			int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
			string selectedCombatTrait = combatActionTraits[randomCombatIndex];
			actor.addTrait(selectedCombatTrait);
			int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
			string selectedElementTrait = elementTraits[randomIndex];
			// 添加随机特质到原Actor
			actor.addTrait(selectedElementTrait);
			// 创建新单位并复制数据
			var act = World.world.units.createNewUnit(actor.asset.id, pTile, true);
			if (pTarget.kingdom.isAlive())
				act.kingdom = pTarget.kingdom;
			if (actor.hasClan() && actor.clan.isAlive())
				act.clan = actor.clan;
			ActorTool.copyUnitToOtherUnit(actor, act);
			act.data.setName(actor.getName());
			act.data.health = 999;
			act.data.created_time = World.world.getCurWorldTime();
			act.data.age_overgrowth = 1;
			act.data.level = 5;
			act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
			// 执行传送和特效
			teleportRandom(act);
			PowerLibrary pb = new PowerLibrary();
			pb.divineLightFX(actor.current_tile, null);
			return true;
		}
		public static bool teleportRandom(Actor a)
		{
			MapBox mapBox = World.world as MapBox;
			if (mapBox == null)
			{
				return false;
			}

			CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
			if (citiesManager == null)
			{
				return false;
			}
			// 优先传送至首都
			City originalCity = citiesManager.list.FirstOrDefault(city => 
				city.kingdom == a.kingdom && 
				city.isCapitalCity() && 
				city.isAlive()
			);
			WorldTile targetTile = null;
			// 优先传送至首都
			if (originalCity != null)
			{
				targetTile = originalCity.getTile();
			}
			else // 次选随机王国存活城市
			{
				List<City> kingdomCities = citiesManager.list
					.Where(city => 
						city.kingdom == a.kingdom && 
						city.isAlive())
					.ToList();

				if (kingdomCities.Count == 0)
				{
					return false;
				}

				int randomIndex = UnityEngine.Random.Range(0, kingdomCities.Count);
				targetTile = kingdomCities[randomIndex].getTile();
			}

			if (targetTile == null || targetTile.Type.block || !targetTile.Type.ground)
			{
				return false;
			}

			a.cancelAllBeh();
			a.spawnOn(targetTile, 0f);
			return true;
		}
		private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
		{
			baseStats[statKey] = value;
		}
    }
}
