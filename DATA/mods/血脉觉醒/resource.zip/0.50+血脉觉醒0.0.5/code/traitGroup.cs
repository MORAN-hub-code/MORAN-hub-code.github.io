﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace traitExampleMod.code
{
    internal class traitGroup
    {

        public static void Init()
        {
            ClanTraitGroupAsset ClantempGroup = new ClanTraitGroupAsset();
            ClantempGroup.id = "ClantempGroup";
            ClantempGroup.name = "trait_group_tempGroup";
            ClantempGroup.color = "#FF0000";
            AssetManager.clan_trait_groups.add(ClantempGroup);
        }
    }
}
