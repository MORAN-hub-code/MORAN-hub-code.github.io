using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using System.Diagnostics;

namespace traitExampleMod.code
{
	internal class traits
	{
		private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
		{
			ActorTrait trait = new ActorTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		public static void Init()
		{
			ClanTrait sunU = CclanTrait("ancestry1", "trait/sunU", "ClantempGroup");
			sunU.rarity = Rarity.R3_Legendary;
			SafeSetStat(sunU.base_stats, S.lifespan, 60f);
			SafeSetStat(sunU.base_stats, S.damage, 50f);
			SafeSetStat(sunU.base_stats, S.speed, 0.5f);
			SafeSetStat(sunU.base_stats, S.health, 688f);
			SafeSetStat(sunU.base_stats, S.armor, 20f);
			SafeSetStat(sunU.base_stats, S.intelligence, 5f);
			SafeSetStat(sunU.base_stats, S.attack_speed, 3f);
			SafeSetStat(sunU.base_stats, S.critical_chance, 0.2f);
			SafeSetStat(sunU.base_stats, S.stewardship, 20f);
			SafeSetStat(sunU.base_stats, S.multiplier_damage, 0.2f);
			SafeSetStat(sunU.base_stats, S.cities, 5f);
			SafeSetStat(sunU.base_stats, S.range, 3f);
			SafeSetStat(sunU.base_stats, S.targets, 5f);
			sunU.action_special_effect = new WorldAction(sunUProof);
			AssetManager.clan_traits.add(sunU);

			ClanTrait tree = CclanTrait("ancestry2", "trait/tree", "ClantempGroup");
			tree.rarity = Rarity.R3_Legendary;
			SafeSetStat(tree.base_stats, S.lifespan, 120f);
			SafeSetStat(tree.base_stats, S.damage, 30f);
			SafeSetStat(tree.base_stats, S.health, 888f);
			SafeSetStat(tree.base_stats, S.armor, 20f);
			SafeSetStat(tree.base_stats, S.intelligence, 5f);
			SafeSetStat(tree.base_stats, S.attack_speed, 2f);
			SafeSetStat(tree.base_stats, S.stewardship, 20f);
			SafeSetStat(tree.base_stats, S.multiplier_health, 0.3f);
			SafeSetStat(tree.base_stats, S.range, 2f);
			SafeSetStat(tree.base_stats, S.targets, 5f);
			tree.action_special_effect = new WorldAction(VitalRegen);
			AssetManager.clan_traits.add(tree);

			ClanTrait moonM = CclanTrait("ancestry3", "trait/moonM", "ClantempGroup");
			moonM.rarity = Rarity.R2_Epic;
			SafeSetStat(moonM.base_stats, S.diplomacy, 5f);
			SafeSetStat(moonM.base_stats, S.lifespan, 50f);
			SafeSetStat(moonM.base_stats, S.damage, 40f);
			SafeSetStat(moonM.base_stats, S.speed, 0.5f);
			SafeSetStat(moonM.base_stats, S.health, 588f);
			SafeSetStat(moonM.base_stats, S.armor, 20f);
			SafeSetStat(moonM.base_stats, S.intelligence, 5f);
			SafeSetStat(moonM.base_stats, S.attack_speed, 2f);
			SafeSetStat(moonM.base_stats, S.multiplier_damage, 0.3f);
			SafeSetStat(moonM.base_stats, S.multiplier_health, 0.10f);
			SafeSetStat(moonM.base_stats, S.critical_chance, 0.1f);
			SafeSetStat(moonM.base_stats, S.cities, 3f);
			SafeSetStat(moonM.base_stats, S.range, 3f);
			SafeSetStat(moonM.base_stats, S.targets, 3f);
			AssetManager.clan_traits.add(moonM);

			ClanTrait guard = CclanTrait("ancestry4", "trait/guard", "ClantempGroup");
			guard.rarity = Rarity.R2_Epic;
			SafeSetStat(guard.base_stats, S.lifespan, 40f);
			SafeSetStat(guard.base_stats, S.damage, 30f);
			SafeSetStat(guard.base_stats, S.health, 700f);
			SafeSetStat(guard.base_stats, S.armor, 25f);
			SafeSetStat(guard.base_stats, S.intelligence, 5f);
			SafeSetStat(guard.base_stats, S.attack_speed, 2f);
			SafeSetStat(guard.base_stats, S.multiplier_health, 0.2f);
			SafeSetStat(guard.base_stats, S.targets, 2f);
			AssetManager.clan_traits.add(guard);

			ClanTrait wisdom = CclanTrait("ancestry5", "trait/wisdom", "ClantempGroup");
			wisdom.rarity = Rarity.R2_Epic;
			SafeSetStat(wisdom.base_stats, S.lifespan, 45f);
			SafeSetStat(wisdom.base_stats, S.damage, 30f);
			SafeSetStat(wisdom.base_stats, S.health, 400f);
			SafeSetStat(wisdom.base_stats, S.armor, 10f);
			SafeSetStat(wisdom.base_stats, S.intelligence, 12f);
			SafeSetStat(wisdom.base_stats, S.attack_speed, 2f);
			SafeSetStat(wisdom.base_stats, S.critical_chance, 0.2f);
			SafeSetStat(wisdom.base_stats, S.warfare, 15f);
			SafeSetStat(wisdom.base_stats, S.stewardship, 10f);
			SafeSetStat(wisdom.base_stats, S.multiplier_health, 0.1f);
			SafeSetStat(wisdom.base_stats, S.cities, 6f);
			SafeSetStat(wisdom.base_stats, S.range, 5f);
			SafeSetStat(wisdom.base_stats, S.area_of_effect, 2f);
			SafeSetStat(wisdom.base_stats, S.mana, 200f);
			SafeSetStat(wisdom.base_stats, S.targets, 2f);
			AssetManager.clan_traits.add(wisdom);

			ClanTrait wind = CclanTrait("ancestry6", "trait/wind", "ClantempGroup");
			wind.rarity = Rarity.R2_Epic;
			SafeSetStat(wind.base_stats, S.diplomacy, 5f);
			SafeSetStat(wind.base_stats, S.lifespan, 35f);
			SafeSetStat(wind.base_stats, S.damage, 40f);
			SafeSetStat(wind.base_stats, S.speed, 6f);
			SafeSetStat(wind.base_stats, S.health, 555f);
			SafeSetStat(wind.base_stats, S.armor, 20f);
			SafeSetStat(wind.base_stats, S.intelligence, 3f);
			SafeSetStat(wind.base_stats, S.attack_speed, 6f);
			SafeSetStat(wind.base_stats, S.critical_chance, 0.1f);
			SafeSetStat(wind.base_stats, S.range, 2f);
			SafeSetStat(wind.base_stats, S.targets, 2f);
			AssetManager.clan_traits.add(wind);

			ClanTrait money = CclanTrait("ancestry7", "trait/money", "ClantempGroup");
			money.rarity = Rarity.R2_Epic;
			SafeSetStat(money.base_stats, S.lifespan, 50f);
			SafeSetStat(money.base_stats, S.stamina, 60f);
			SafeSetStat(money.base_stats, S.damage, 70f);
			SafeSetStat(money.base_stats, S.health, 300f);
			SafeSetStat(money.base_stats, S.armor, 20f);
			SafeSetStat(money.base_stats, S.range, 2f);
			SafeSetStat(money.base_stats, S.area_of_effect, 2f);
			SafeSetStat(money.base_stats, S.targets, 1f);
			money.action_attack_target = new AttackAction(attack_money);
			AssetManager.clan_traits.add(money);

			ActorTrait hasten = CreateTrait("hasten", "trait/hasten", "acquired");
			hasten.rarity = Rarity.R3_Legendary;
			SafeSetStat(hasten.base_stats, S.lifespan, 20f);
			SafeSetStat(hasten.base_stats, S.stamina, 60f);
			SafeSetStat(hasten.base_stats, S.damage, 100f);
			SafeSetStat(hasten.base_stats, S.speed, 1f);
			SafeSetStat(hasten.base_stats, S.health, 200f);
			SafeSetStat(hasten.base_stats, S.armor, 10f);
			SafeSetStat(hasten.base_stats, S.critical_chance, 0.3f);
			SafeSetStat(hasten.base_stats, S.critical_damage_multiplier, 0.3f);
			SafeSetStat(hasten.base_stats, S.mass_2, 20f);
			SafeSetStat(hasten.base_stats, S.range, 2f);
			SafeSetStat(hasten.base_stats, S.area_of_effect, 2f);
			SafeSetStat(hasten.base_stats, S.scale, 0.02f);
			SafeSetStat(hasten.base_stats, S.targets, 3f);
                        hasten.action_special_effect = new WorldAction(Evolution);
			AssetManager.traits.add(hasten);

                        ActorTrait blood1 = CreateTrait("blood1", "trait/blood1", "physique");
                        SafeSetStat(blood1.base_stats , S.damage, 100f);
                        SafeSetStat(blood1.base_stats , S.health, 1000f);
                        SafeSetStat(blood1.base_stats , S.accuracy, 2f);
                        SafeSetStat(blood1.base_stats , S.speed, 5f);            
                        SafeSetStat(blood1.base_stats , S.multiplier_speed, 0.1f);
                        SafeSetStat(blood1.base_stats , S.stamina, 50f);
                        SafeSetStat(blood1.base_stats , S.targets, 2f);
                        SafeSetStat(blood1.base_stats , S.range, 1f);
                        SafeSetStat(blood1.base_stats , S.area_of_effect, 1f);
                        SafeSetStat(blood1.base_stats , S.armor, 10f);
                        blood1.action_special_effect = new WorldAction(Vital1Regen);
                        AssetManager.traits.add(blood1);

                        ActorTrait blood2 = CreateTrait("blood2", "trait/blood2", "physique");
                        SafeSetStat(blood2.base_stats , S.damage, 220f);
                        SafeSetStat(blood2.base_stats , S.health, 5000f);
                        SafeSetStat(blood2.base_stats , S.armor, 20f);
                        SafeSetStat(blood2.base_stats , S.targets, 2f);
                        SafeSetStat(blood2.base_stats , S.accuracy, 5f);
                        SafeSetStat(blood2.base_stats , S.multiplier_speed, 0.2f);
                        SafeSetStat(blood2.base_stats , S.stamina, 100f);
                        SafeSetStat(blood2.base_stats , S.speed, 10f);
                        SafeSetStat(blood2.base_stats , S.area_of_effect, 4f);
                        SafeSetStat(blood2.base_stats , S.range, 3f);
                        blood2.action_special_effect = new WorldAction(Vital2Regen);
                        AssetManager.traits.add(blood2);

                        ActorTrait blood3 = CreateTrait("blood3", "trait/blood3", "physique");
                        SafeSetStat(blood3.base_stats , S.damage, 1000f);
                        SafeSetStat(blood3.base_stats , S.health, 15000f);
                        SafeSetStat(blood3.base_stats , S.speed, 20f);
                        SafeSetStat(blood3.base_stats , S.armor, 30f);
                        SafeSetStat(blood3.base_stats , S.targets, 3f);
                        SafeSetStat(blood3.base_stats , S.critical_chance, 0.2f);
                        SafeSetStat(blood3.base_stats , S.accuracy, 10f);
                        SafeSetStat(blood3.base_stats , S.multiplier_speed, 0.3f);
                        SafeSetStat(blood3.base_stats , S.stamina, 150f);
                        SafeSetStat(blood3.base_stats , S.area_of_effect, 6f);
                        SafeSetStat(blood3.base_stats , S.range, 3f);
                        blood3.action_special_effect = new WorldAction(Vital3Regen);
                        AssetManager.traits.add(blood3);

                        ActorTrait blood4 = CreateTrait("blood4", "trait/blood4", "physique");
                        SafeSetStat(blood4.base_stats , S.stewardship, 60f);
                        SafeSetStat(blood4.base_stats , S.damage, 2000f);
                        SafeSetStat(blood4.base_stats , S.health, 45000f);
                        SafeSetStat(blood4.base_stats , S.speed, 25f);
                        SafeSetStat(blood4.base_stats , S.armor, 50f);
                        SafeSetStat(blood4.base_stats , S.area_of_effect, 10f);         
                        SafeSetStat(blood4.base_stats , S.targets, 5f);
                        SafeSetStat(blood4.base_stats , S.critical_chance, 0.3f);
                        SafeSetStat(blood4.base_stats , S.accuracy, 20f);
                        SafeSetStat(blood4.base_stats , S.multiplier_speed, 0.4f);
                        SafeSetStat(blood4.base_stats , S.stamina, 450f);
                        SafeSetStat(blood4.base_stats , S.range, 5f);
                        blood4.action_special_effect = new WorldAction(Vital4Regen);
                        AssetManager.traits.add(blood4);

                        ActorTrait blood5 = CreateTrait("blood5", "trait/blood5", "physique");
                        SafeSetStat(blood5.base_stats , S.stewardship, 100f);
                        SafeSetStat(blood5.base_stats , S.damage, 10000f);
                        SafeSetStat(blood5.base_stats , S.armor, 25f);
                        SafeSetStat(blood5.base_stats , S.health, 240000f);
                        SafeSetStat(blood5.base_stats , S.speed, 35f);
                        SafeSetStat(blood5.base_stats , S.area_of_effect, 10f);
                        SafeSetStat(blood5.base_stats , S.targets, 6f);
                        SafeSetStat(blood5.base_stats , S.critical_chance, 0.5f);
                        SafeSetStat(blood5.base_stats , S.accuracy, 30f);
                        SafeSetStat(blood5.base_stats , S.multiplier_speed, 0.6f);
                        SafeSetStat(blood5.base_stats , S.stamina, 2400f);
                        SafeSetStat(blood5.base_stats , S.range, 6f);
                        blood5.action_special_effect = new WorldAction(Vital5Regen);
                        AssetManager.traits.add(blood5);

			ClanTrait resurrection = CclanTrait("resurrection", "trait/resurrection", "ClantempGroup");
			resurrection.rarity = Rarity.R3_Legendary;
			resurrection.action_death = Resurrection;
			AssetManager.clan_traits.add(resurrection);
		}
		public static bool attack_money(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false;
            }

            if (pTarget.isBuilding())
            {
                return false; // 如果目标是建筑，则返回false
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health <= 1)
            {
                return false; // 如果没有足够的血量，则返回false
            }
			int drainAmount = UnityEngine.Random.Range(10, 31); // 随机汲取的血量范围在10到30之间
            // 目标有足够的血量，执行汲取操作
            pTarget.a.spawnParticle(Toolbox.makeColor("#FF0000"));
            int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health - 1); // 实际汲取的血量，确保目标至少保留1点血量
            pTarget.a.data.health -= actualDrain; // 减少目标的血量
            pSelf.a.data.health = Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量

            return true;
        }
        public static bool Evolution(BaseSimObject pTarget, WorldTile pTile = null)
        {
            int randomExp = UnityEngine.Random.Range(1, 99);
            pTarget.a.addExperience(randomExp);

            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                int tHealthToRegen = pTarget.a.getMaxHealthPercent(0.01f);
                pTarget.a.restoreHealth(tHealthToRegen);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            Actor a = pTarget.a;
            var evolutionTraits = new Dictionary<string, int>
            {
                {"interesting3_1", 10},
                {"interesting3_2", 20},
                {"interesting3_3", 30},
                {"interesting3_4", 40},
                {"interesting3_5", 55}
            };
            string highestTrait = null;
            int maxLevel = 0;
            foreach (var trait in evolutionTraits)
            {
                if (a.data.level > trait.Value && trait.Value > maxLevel)
                {
                    maxLevel = trait.Value;
                    highestTrait = trait.Key;
                }
            }
            if (highestTrait != null)
            {
                foreach (var trait in evolutionTraits)
                {
                    if (trait.Value < maxLevel && a.hasTrait(trait.Key))
                    {
                        a.removeTrait(trait.Key);
                    }
                }
                if (!a.hasTrait(highestTrait))
                {
                    a.addTrait(highestTrait);
                }
            }
            if(a.data.level > 30)
            {
                a.addTrait("fire_proof");
                a.addTrait("freeze_proof");
                a.addTrait("strong_minded");
            }
            if (a.data.level > 40)
            {
                a.addTrait("arcane_reflexes");
                a.addTrait("battle_reflexes");
            }
            if (a.data.level > 50)
            {
                a.addTrait("poison_immune");
                a.addTrait("acid_proof");
                a.addTrait("immune");
            }
            return true;
        }
		public static bool sunUProof(BaseSimObject pTarget, WorldTile pTile = null)
		{
			Actor a = pTarget.a;
			a.addTrait("fire_proof");
			return false;
		}
		public static bool VitalRegen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(15);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Vital2Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(375);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Vital1Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(75);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Vital3Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(1025);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Vital4Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(3075);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Vital5Regen(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget.a.data.health < pTarget.a.getMaxHealth())
			{
				pTarget.a.restoreHealth(18000);
				pTarget.a.spawnParticle(Toolbox.color_heal);
			}
			return true;
		}
		public static bool Resurrection(BaseSimObject pTarget, WorldTile pTile = null)
		{
			if (pTarget == null || !pTarget.isActor())
			{
				return false;
			}
			if (!(pTarget is Actor actor))
			{
				return false;
			}
			IReadOnlyCollection<ActorTrait> traits = actor.getTraits();
			List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
			foreach (string traitId in allTraitIds)
			{
				actor.removeTrait(traitId);
			}
			actor.addTrait("arcane_reflexes");
			actor.addTrait("battle_reflexes");
			actor.addTrait("fast");
			// 定义可随机的元素特质列表
			string[] elementTraits = { "blessed", "chosen_one", "heart_of_wizard" };
			string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
			int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
			string selectedCombatTrait = combatActionTraits[randomCombatIndex];
			actor.addTrait(selectedCombatTrait);
			int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
			string selectedElementTrait = elementTraits[randomIndex];
			// 添加随机特质到原Actor
			actor.addTrait(selectedElementTrait);
			// 创建新单位并复制数据
			var act = World.world.units.createNewUnit(actor.asset.id, pTile, true);
			if (pTarget.kingdom.isAlive())
                act.kingdom = pTarget.kingdom;
			if (actor.hasClan() && actor.clan.isAlive())
    			act.clan = actor.clan;
			ActorTool.copyUnitToOtherUnit(actor, act);
			act.data.setName(actor.getName());
			act.data.health = 999;
			act.data.created_time = World.world.getCurWorldTime();
			act.data.age_overgrowth = 1;
			act.data.level = 5;
			act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
			// 执行传送和特效
			teleportRandom(act);
			PowerLibrary pb = new PowerLibrary();
			pb.divineLightFX(actor.current_tile, null);
			return true;
		}
		public static bool teleportRandom(Actor a)
		{
			MapBox mapBox = World.world as MapBox;
			if (mapBox == null)
			{
				return false;
			}

			CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
			if (citiesManager == null)
			{
				return false;
			}
			// 优先传送至首都
			City originalCity = citiesManager.list.FirstOrDefault(city => 
				city.kingdom == a.kingdom && 
				city.isCapitalCity() && 
				city.isAlive()
			);
			WorldTile targetTile = null;
			// 优先传送至首都
			if (originalCity != null)
			{
				targetTile = originalCity.getTile();
			}
			else // 次选随机王国存活城市
			{
				List<City> kingdomCities = citiesManager.list
					.Where(city => 
						city.kingdom == a.kingdom && 
						city.isAlive())
					.ToList();

				if (kingdomCities.Count == 0)
				{
					return false;
				}

				int randomIndex = UnityEngine.Random.Range(0, kingdomCities.Count);
				targetTile = kingdomCities[randomIndex].getTile();
			}

			if (targetTile == null || targetTile.Type.block || !targetTile.Type.ground)
			{
				return false;
			}

			a.cancelAllBeh();
			a.spawnOn(targetTile, 0f);
			return true;
		}
		private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
		{
			baseStats[statKey] = value;
		}
    }
}
