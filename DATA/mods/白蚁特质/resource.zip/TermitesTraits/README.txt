I wasn't going to post this mod until much further along in its development, but I've decided to pursue a more ambitious 
project putting this one to the side until further notice. So, I thought I'd release what little is done anyways until 
I can get back into it. I apologize it doesn't add much, it was more meant as a learning project. This is my first 
mod, so I'd greatly appreciate feedback and suggestions for when I do get the time to work on this. Also sorry for the 
code being all jumbled into the main file. 

I want to give very special thanks to Cody and KeyMasterer for all their help with 
this mod and helping me learn what I could.

Installation:

export file
drag and drop into mods folder

This mod adds 52 traits and 5 new ages

i apologize for the lack of quality, once again wasn't going to post, but atleast this way i make it possible to 
get feedback and suggestions for when i pick this back up.