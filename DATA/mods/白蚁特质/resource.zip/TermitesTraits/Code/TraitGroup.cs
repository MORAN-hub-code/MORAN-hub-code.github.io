using System;
using UnityEngine;
using NCMS;
using NeoModLoader.General;


namespace ThisIsHell
{
    public static class TraitGroups
    {
        public static void CreateTraitGroups()
        {
            ActorTraitGroupAsset group = new
            ActorTraitGroupAsset()
            {
                id = "test",

                name = "addictions",

                color = "red",

            };
            AssetManager.trait_groups.add(group);
            LM.AddToCurrentLocale("addictions", "Addictions");

        }
        
        

    }
}
    
