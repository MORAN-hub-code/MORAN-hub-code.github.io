﻿using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;




namespace TermitesTraits
{
    public class Class1
    {
    }
}

[ModEntry]
class Main : MonoBehaviour
{
    void Awake()
    {
        Traits.Init();
        Harmony harmony = new Harmony("TermitesTraits");
        MethodInfo original;
        MethodInfo patch;
        original = AccessTools.Method(typeof(Actor), "generatePersonality");
        patch = AccessTools.Method(typeof(Main), "generatePersonality_Postfix");
        harmony.Patch(original, null, new HarmonyMethod(patch));
    }


    public static void generatePersonality_Postfix(Actor __instance)
    {
        List<string> allowedActorNames = new List<string>
        {
            "human", "orc", "elf", "dwarf", "civ_cat", "civ_dog", "civ_chicken",
            "civ_rabbit", "civ_monkey", "civ_fox", "civ_sheep", "civ_cow", "civ_armadillo",
            "civ_wolf", "civ_bear", "civ_rhino", "civ_buffalo", "civ_hyena", "civ_rat",
            "civ_alpaca", "civ_capybara", "civ_goat", "civ_scorpion", "civ_crab", "civ_penguin",
            "civ_turtle", "civ_crocodile", "civ_snake", "civ_frog", "civ_piranha", "civ_liliar",
            "civ_garlic_man", "civ_lemon_man", "civ_acid_gentleman", "civ_crystal_golem", "civ_candy_man"
        };



        if (!allowedActorNames.Contains(__instance.asset.id)) return;

        string[] addictionTraitIDs =
        {
            "Alcohol", "Meth", "Cigarettes", "Heroin", "Weed", "Cocaine", "PCP"
        };

        string[] randomTraitIDs =
        {
            "bananalover", "treehugger", "box", "openbox", "discordmod", "redditmod",
            "frostbite", "chknngt", "blessyou", "melted_shoes", "Haunting Presence", "PaperBag",
            "PlasticBag", "PaperStraw", "PlasticStraw", "ChknLittle", "SpicyChknNggt", "InstantDeath", "CelebStatus",
            "boomer", "extremelyav", "snacksize", "breadbrain", "solarborn", "sandpit_turtle"
        };

        string[] disordersTraitIDs =
        {
            "ptsd", "anxiety", "depression", "nacrolepsy", "insomnia", "schizophrenia", "survivors_guilt",
            "Dissociation", "paranoia", "bipolar"
        };

        string[] sicknessTraitIDs =
        {
            "Poker", "BlackJack", "Slots", "Roulette"
        };

        // First set: Addiction Traits
        foreach (string traitID in addictionTraitIDs)
        {
            var trait = AssetManager.traits.get(traitID);
            if (trait != null)
            {
                int chance = trait.rate_birth; // use rate_birth as the % chance
                if (UnityEngine.Random.Range(0, 100) < chance)
                {
                    __instance.addTrait(traitID);
                }
            }
        }

        // Second set: Random Traits
        foreach (string traitID in randomTraitIDs)
        {
            var trait = AssetManager.traits.get(traitID);
            if (trait != null)
            {
                int chance = trait.rate_birth; // use rate_birth as the % chance
                if (UnityEngine.Random.Range(0, 100) < chance)
                {
                    __instance.addTrait(traitID);
                }
            }
        }
        // third set: Disorder Traits
        foreach (string traitID in disordersTraitIDs)
        {
            var trait = AssetManager.traits.get(traitID);
            if (trait != null)
            {
                int chance = trait.rate_birth; // use rate_birth as the % chance
                if (UnityEngine.Random.Range(0, 100) < chance)
                {
                    __instance.addTrait(traitID);
                }
            }
        }
        // fourth set: Gambling Traits
        foreach (string traitID in addictionTraitIDs)
        {
            var trait = AssetManager.traits.get(traitID);
            if (trait != null)
            {
                int chance = trait.rate_birth; // use rate_birth as the % chance
                if (UnityEngine.Random.Range(0, 100) < chance)
                {
                    __instance.addTrait(traitID);
                }
            }
        }

    }

    //TRAITS

    public static class Traits
    {

        public static void makeNewTrait()
        {

            ActorTrait nicotine = new ActorTrait();
            nicotine.id = "Cigarettes";
            nicotine.path_icon = "ui/Icons/actor_traits/addictions/nicotine";
            nicotine.group_id = "addictions";
            nicotine.type = TraitType.Negative;
            nicotine.can_be_given = true;
            nicotine.can_be_removed = true;
            nicotine.same_trait_mod = 5;
            nicotine.rate_acquire_grow_up = 2;
            nicotine.needs_to_be_explored = false;
            nicotine.rate_birth = 12;
            AssetManager.traits.add(nicotine);
            LM.AddToCurrentLocale("trait_Cigarettes", "Cigarettes");
            LM.AddToCurrentLocale("trait_Cigarettes_info", "addicted to nicotine, suffering from health issues and cravings.");



            nicotine.base_stats.set("health", -20f);
            nicotine.base_stats.set("speed", -2f);
            nicotine.base_stats.set("attack_speed", -3f);
            nicotine.base_stats.set("lifespan", -15f);
            nicotine.base_stats.set("stamina", -15f);

            ActorTrait beer = new ActorTrait();
            beer.id = "Alcohol";
            beer.path_icon = "ui/Icons/actor_traits/addictions/beer";
            beer.group_id = "addictions";
            beer.type = TraitType.Negative;
            beer.can_be_given = true;
            beer.can_be_removed = true;
            beer.same_trait_mod = 5;
            beer.rate_acquire_grow_up = 2;
            beer.needs_to_be_explored = false;
            beer.rate_birth = 18;
            AssetManager.traits.add(beer);
            LM.AddToCurrentLocale("trait_Alcohol", "Alcohol");
            LM.AddToCurrentLocale("trait_Alcohol_info", "An unyielding thirst for alcohol, dulling senses and impairing clear thought.");





            beer.base_stats.set("health", -10f);
            beer.base_stats.set("speed", -2f);
            beer.base_stats.set("attack_speed", -5f);
            beer.base_stats.set("damage", 5f);
            beer.base_stats.set("lifespan", -10f);
            beer.base_stats.set("accuracy", -15f);
            beer.base_stats.set("stamina", -15f);


            ActorTrait drugone = new ActorTrait();
            drugone.id = "Meth";
            drugone.path_icon = "ui/Icons/actor_traits/addictions/meth";
            drugone.group_id = "addictions";
            drugone.type = TraitType.Negative;
            drugone.can_be_given = true;
            drugone.can_be_removed = true;
            drugone.same_trait_mod = 5;
            drugone.rate_acquire_grow_up = 2;
            drugone.needs_to_be_explored = false;
            drugone.rate_birth = 4;
            AssetManager.traits.add(drugone);
            LM.AddToCurrentLocale("trait_Meth", "Meth");
            LM.AddToCurrentLocale("trait_Meth_info", "A dangerous dependency on methamphetamine, causing erratic behavior and severe physical deterioration.");



            drugone.base_stats.set("health", -30f);
            drugone.base_stats.set("speed", 10f);
            drugone.base_stats.set("attack_speed", 20f);
            drugone.base_stats.set("lifespan", -30f);
            drugone.base_stats.set("diplomacy", -20f);
            drugone.base_stats.set("intelligence", -15f);

            ActorTrait drugtwo = new ActorTrait();
            drugtwo.id = "Weed";
            drugtwo.path_icon = "ui/Icons/actor_traits/addictions/Weed";
            drugtwo.group_id = "addictions";
            drugtwo.type = TraitType.Negative;
            drugtwo.can_be_given = true;
            drugtwo.can_be_removed = true;
            drugtwo.same_trait_mod = 5;
            drugtwo.rate_acquire_grow_up = 2;
            drugtwo.needs_to_be_explored = false;
            drugtwo.rate_birth = 8;
            AssetManager.traits.add(drugtwo);
            LM.AddToCurrentLocale("trait_Weed", "Weed");
            LM.AddToCurrentLocale("trait_Weed_info", "A habit formed by constant use of marijuana, leading to sluggishness and a clouded sense of focus.");



            drugtwo.base_stats.set("speed", -2f);
            drugtwo.base_stats.set("attack_speed", -8f);
            drugtwo.base_stats.set("diplomacy", -8f);

            ActorTrait drugthree = new ActorTrait();
            drugthree.id = "Heroin";
            drugthree.path_icon = "ui/Icons/actor_traits/addictions/heroin";
            drugthree.group_id = "addictions";
            drugthree.type = TraitType.Negative;
            drugthree.can_be_given = true;
            drugthree.can_be_removed = true;
            drugthree.same_trait_mod = 5;
            drugthree.rate_acquire_grow_up = 2;
            drugthree.needs_to_be_explored = false;
            drugthree.rate_birth = 3;
            AssetManager.traits.add(drugthree);
            LM.AddToCurrentLocale("trait_Heroin", "Heroin");
            LM.AddToCurrentLocale("trait_Heroin_info", "A crippling addiction to heroin, draining the body’s strength and leaving the mind in a haze of despair.");



            drugthree.base_stats.set("health", -10f);
            drugthree.base_stats.set("speed", -4f);
            drugthree.base_stats.set("attack_speed", -10f);
            drugthree.base_stats.set("lifespan", -30f);
            drugthree.base_stats.set("intelligence", -20f);
            drugthree.base_stats.set("stamina", -15f);

            ActorTrait drugiv = new ActorTrait();
            drugiv.id = "Cocaine";
            drugiv.path_icon = "ui/Icons/actor_traits/addictions/cocaine";
            drugiv.group_id = "addictions";
            drugiv.type = TraitType.Negative;
            drugiv.can_be_given = true;
            drugiv.can_be_removed = true;
            drugiv.same_trait_mod = 5;
            drugiv.rate_acquire_grow_up = 2;
            drugiv.needs_to_be_explored = false;
            drugiv.rate_birth = 4;
            AssetManager.traits.add(drugiv);
            LM.AddToCurrentLocale("trait_Cocaine", "Cocaine");
            LM.AddToCurrentLocale("trait_Cocaine_info", "An intense craving for cocaine, driving erratic behavior and pushing the body to dangerous extremes.");


            drugiv.base_stats.set("health", -15f);
            drugiv.base_stats.set("speed", 20f);
            drugiv.base_stats.set("attack_speed", 25f);
            drugiv.base_stats.set("damage", 5f);
            drugiv.base_stats.set("accuracy", -5f);
            drugiv.base_stats.set("stamina", -20f);
            drugiv.base_stats.set("intelligence", -15f);

            ActorTrait drugv = new ActorTrait();
            drugv.id = "PCP";
            drugv.path_icon = "ui/Icons/actor_traits/addictions/PCP";
            drugv.group_id = "addictions";
            drugv.type = TraitType.Negative;
            drugv.can_be_given = true;
            drugv.can_be_removed = true;
            drugv.same_trait_mod = 5;
            drugv.rate_acquire_grow_up = 2;
            drugv.needs_to_be_explored = false;
            drugv.rate_birth = 4;
            AssetManager.traits.add(drugv);
            LM.AddToCurrentLocale("trait_PCP", "PCP");
            LM.AddToCurrentLocale("trait_PCP_info", "Stays in your system forever");


            drugv.base_stats.set("health", -30f);
            drugv.base_stats.set("speed", 20f);
            drugv.base_stats.set("attack_speed", 25f);
            drugv.base_stats.set("damage", 5f);
            drugv.base_stats.set("accuracy", -5f);
            drugv.base_stats.set("stamina", -20f);
            drugv.base_stats.set("intelligence", -15f);




            ActorTrait grassland = new ActorTrait();
            grassland.id = "prariesblessings";
            grassland.path_icon = "ui/Icons/actor_traits/lifeborn/prariesblessings";
            grassland.group_id = "lifebound";
            grassland.type = TraitType.Positive;
            grassland.can_be_given = false;
            grassland.can_be_removed = false;
            grassland.same_trait_mod = 5;
            grassland.rate_acquire_grow_up = 2;
            grassland.needs_to_be_explored = false;
            AssetManager.traits.add(grassland);
            LM.AddToCurrentLocale("trait_prariesblessings", "Prarie's Blessings");
            LM.AddToCurrentLocale("trait_prariesblessings_info", "Born of the grasslands and blessed by the prairie, this soul is one with the earth, strong and at peace.");

            ActorTrait forest = new ActorTrait();
            forest.id = "woodlandsembrace";
            forest.path_icon = "ui/Icons/actor_traits/lifeborn/woodlandsembrace";
            forest.group_id = "lifebound";
            forest.type = TraitType.Positive;
            forest.can_be_given = false;
            forest.can_be_removed = false;
            forest.same_trait_mod = 5;
            forest.rate_acquire_grow_up = 2;
            forest.needs_to_be_explored = false;
            AssetManager.traits.add(forest);
            LM.AddToCurrentLocale("trait_woodlandsembrace", "Woodland's Embrace");
            LM.AddToCurrentLocale("trait_woodlandsembrace_info", "Born in the forest’s heart, embraced by the trees, this individual thrives in nature’s shelter, calm and resilient.");

            ActorTrait desert = new ActorTrait();
            desert.id = "dunedweller";
            desert.path_icon = "ui/Icons/actor_traits/lifeborn/dunedweller";
            desert.group_id = "lifebound";
            desert.type = TraitType.Positive;
            desert.can_be_given = false;
            desert.can_be_removed = false;
            desert.same_trait_mod = 5;
            desert.rate_acquire_grow_up = 2;
            desert.needs_to_be_explored = false;
            AssetManager.traits.add(desert);
            LM.AddToCurrentLocale("trait_dunedweller", "Dune Dweller");
            LM.AddToCurrentLocale("trait_dunedweller_info", "Born in the mystical sands of the Arcane Desert, this soul thrives in the harsh dunes, drawing power from the desert’s ancient magic.");

            ActorTrait swamp = new ActorTrait();
            swamp.id = "muckborn";
            swamp.path_icon = "ui/Icons/actor_traits/lifeborn/muckborn";
            swamp.group_id = "lifebound";
            swamp.type = TraitType.Positive;
            swamp.can_be_given = false;
            swamp.can_be_removed = false;
            swamp.same_trait_mod = 5;
            swamp.rate_acquire_grow_up = 2;
            swamp.needs_to_be_explored = false;
            AssetManager.traits.add(swamp);
            LM.AddToCurrentLocale("trait_muckborn", "Muckborn");
            LM.AddToCurrentLocale("trait_muckborn_info", "Born in the murky depths of the swamp, this individual is tough and unyielding, thriving in the mist and muck.");

            ActorTrait birch = new ActorTrait();
            birch.id = "birchkin";
            birch.path_icon = "ui/Icons/actor_traits/lifeborn/birchkin";
            birch.group_id = "lifebound";
            birch.type = TraitType.Positive;
            birch.can_be_given = false;
            birch.can_be_removed = false;
            birch.same_trait_mod = 5;
            birch.rate_acquire_grow_up = 2;
            birch.needs_to_be_explored = false;
            AssetManager.traits.add(birch);
            LM.AddToCurrentLocale("trait_birchkin", "Birchkin");
            LM.AddToCurrentLocale("trait_birchkin_info", "Born among the slender birch trees, this individual embodies their resilience and grace, thriving in the cool shade of the forest.");

            ActorTrait infernal = new ActorTrait();
            infernal.id = "magmawalker";
            infernal.path_icon = "ui/Icons/actor_traits/lifeborn/magmawalker";
            infernal.group_id = "lifebound";
            infernal.type = TraitType.Positive;
            infernal.can_be_given = false;
            infernal.can_be_removed = false;
            infernal.same_trait_mod = 5;
            infernal.rate_acquire_grow_up = 2;
            infernal.needs_to_be_explored = false;
            AssetManager.traits.add(infernal);
            LM.AddToCurrentLocale("trait_magmawalker", "Magma Walker");
            LM.AddToCurrentLocale("trait_magmawalker_info", "Born in the Infernal, this soul strides through magma, forged by fire and flame.");

            ActorTrait savannah = new ActorTrait();
            savannah.id = "savannahsoul";
            savannah.path_icon = "ui/Icons/actor_traits/lifeborn/savannahsoul";
            savannah.group_id = "lifebound";
            savannah.type = TraitType.Positive;
            savannah.can_be_given = false;
            savannah.can_be_removed = false;
            savannah.same_trait_mod = 5;
            savannah.rate_acquire_grow_up = 2;
            savannah.needs_to_be_explored = false;
            AssetManager.traits.add(savannah);
            LM.AddToCurrentLocale("trait_savannahsoul", "Savannah Soul");
            LM.AddToCurrentLocale("trait_savannahsoul_info", "Born under the endless sky of the savannah, this individual is strong, resilient, and in tune with the wild, open lands.");

            ActorTrait maple = new ActorTrait();
            maple.id = "amberborn";
            maple.path_icon = "ui/Icons/actor_traits/lifeborn/amberborn";
            maple.group_id = "lifebound";
            maple.type = TraitType.Positive;
            maple.can_be_given = false;
            maple.can_be_removed = false;
            maple.same_trait_mod = 5;
            maple.rate_acquire_grow_up = 2;
            maple.needs_to_be_explored = false;
            AssetManager.traits.add(maple);
            LM.AddToCurrentLocale("trait_amberborn", "Amberborn");
            LM.AddToCurrentLocale("trait_amberborn_info", "Born within the glowing depths of Amber, this soul is encased in ancient warmth, shaped by the eternal glow of the resinous land.");

            ActorTrait corrupt = new ActorTrait();
            corrupt.id = "voidrooted";
            corrupt.path_icon = "ui/Icons/actor_traits/lifeborn/voidrooted";
            corrupt.group_id = "lifebound";
            corrupt.type = TraitType.Positive;
            corrupt.can_be_given = false;
            corrupt.can_be_removed = false;
            corrupt.same_trait_mod = 5;
            corrupt.rate_acquire_grow_up = 2;
            corrupt.needs_to_be_explored = false;
            AssetManager.traits.add(corrupt);
            LM.AddToCurrentLocale("trait_voidrooted", "Voidrooted");
            LM.AddToCurrentLocale("trait_voidrooted_info", "Born in the heart of the Corrupt, this soul is rooted in the void, drawing strength from the darkness and decay around them.");

            ActorTrait shroom = new ActorTrait();
            shroom.id = "fungalkin";
            shroom.path_icon = "ui/Icons/actor_traits/lifeborn/fungalkin";
            shroom.group_id = "lifebound";
            shroom.type = TraitType.Positive;
            shroom.can_be_given = false;
            shroom.can_be_removed = false;
            shroom.same_trait_mod = 5;
            shroom.rate_acquire_grow_up = 2;
            shroom.needs_to_be_explored = false;
            AssetManager.traits.add(shroom);
            LM.AddToCurrentLocale("trait_fungalkin", "Fungalkin");
            LM.AddToCurrentLocale("trait_fungalkin_info", "Born beneath the mushroom canopies, this individual thrives in the damp shadows, their essence intertwined with the fungal depths.");

            ActorTrait candy = new ActorTrait();
            candy.id = "sugarcoated";
            candy.path_icon = "ui/Icons/actor_traits/lifeborn/sugarcoated";
            candy.group_id = "lifebound";
            candy.type = TraitType.Positive;
            candy.can_be_given = false;
            candy.can_be_removed = false;
            candy.same_trait_mod = 5;
            candy.rate_acquire_grow_up = 2;
            candy.needs_to_be_explored = false;
            AssetManager.traits.add(candy);
            LM.AddToCurrentLocale("trait_sugarcoated", "Sugar-coated");
            LM.AddToCurrentLocale("trait_sugarcoated_info", "Born in the sweet embrace of Candy, this individual is as vibrant and sweet as the sugary world around them.");

            ActorTrait garlic = new ActorTrait();
            garlic.id = "stinkwalker";
            garlic.path_icon = "ui/Icons/actor_traits/lifeborn/stinkwalker";
            garlic.group_id = "lifebound";
            garlic.type = TraitType.Positive;
            garlic.can_be_given = false;
            garlic.can_be_removed = false;
            garlic.same_trait_mod = 5;
            garlic.rate_acquire_grow_up = 2;
            garlic.needs_to_be_explored = false;
            AssetManager.traits.add(garlic);
            LM.AddToCurrentLocale("trait_stinkwalker", "Stinkwalker");
            LM.AddToCurrentLocale("trait_stinkwalker_info", "Born in the pungent fields of Garlic, this individual carries the scent of strength, thriving amidst the overpowering stench.");

            ActorTrait sour = new ActorTrait();
            sour.id = "soursoul";
            sour.path_icon = "ui/Icons/actor_traits/lifeborn/soursoul";
            sour.group_id = "lifebound";
            sour.type = TraitType.Positive;
            sour.can_be_given = false;
            sour.can_be_removed = false;
            sour.same_trait_mod = 5;
            sour.rate_acquire_grow_up = 2;
            sour.needs_to_be_explored = false;
            AssetManager.traits.add(sour);
            LM.AddToCurrentLocale("trait_soursoul", "Soursoul");
            LM.AddToCurrentLocale("trait_soursoul_info", "Born in the bitter lands of Sour, this soul is sharp and unyielding, carrying the tang of the sour earth within.");

            ActorTrait enchanted = new ActorTrait();
            enchanted.id = "spellspitter";
            enchanted.path_icon = "ui/Icons/actor_traits/lifeborn/spellspitter";
            enchanted.group_id = "lifebound";
            enchanted.type = TraitType.Positive;
            enchanted.can_be_given = false;
            enchanted.can_be_removed = false;
            enchanted.same_trait_mod = 5;
            enchanted.rate_acquire_grow_up = 2;
            enchanted.needs_to_be_explored = false;
            AssetManager.traits.add(enchanted);
            LM.AddToCurrentLocale("trait_spellspitter", "Spell Spitter");
            LM.AddToCurrentLocale("trait_spellspitter_info", "Born in the mystical Enchanted lands, this individual channels arcane power effortlessly, casting spells with every breath.");

            ActorTrait rock = new ActorTrait();
            rock.id = "stonefoot";
            rock.path_icon = "ui/Icons/actor_traits/lifeborn/stonefoot"; //PLACEHOLDER
            rock.group_id = "lifebound";
            rock.type = TraitType.Positive;
            rock.can_be_given = false;
            rock.can_be_removed = false;
            rock.same_trait_mod = 5;
            rock.rate_acquire_grow_up = 2;
            rock.needs_to_be_explored = false;
            AssetManager.traits.add(rock);
            LM.AddToCurrentLocale("trait_stonefoot", "Stonefoot");
            LM.AddToCurrentLocale("trait_stonefoot_info", "Born in the rugged Rocklands, this individual stands firm and unshakable, their steps as solid as the stones beneath them.");



            ActorTrait crystal = new ActorTrait();
            crystal.id = "crystalveined";
            crystal.path_icon = "ui/Icons/actor_traits/lifeborn/crystalveined";
            crystal.group_id = "lifebound";
            crystal.type = TraitType.Positive;
            crystal.can_be_given = false;
            crystal.can_be_removed = false;
            crystal.same_trait_mod = 5;
            crystal.rate_acquire_grow_up = 2;
            crystal.needs_to_be_explored = false;
            AssetManager.traits.add(crystal);
            LM.AddToCurrentLocale("trait_crystalveined", "Crystal Veined");
            LM.AddToCurrentLocale("trait_crystalveined_info", "Born in the gleaming depths of Crystal, this individual’s veins pulse with the pure energy of the shimmering stones.");

            ActorTrait permafrost = new ActorTrait();
            permafrost.id = "blizzardstepper";
            permafrost.path_icon = "ui/Icons/actor_traits/lifeborn/blizzardstepper";
            permafrost.group_id = "lifebound";
            permafrost.type = TraitType.Positive;
            permafrost.can_be_given = false;
            permafrost.can_be_removed = false;
            permafrost.same_trait_mod = 5;
            permafrost.rate_acquire_grow_up = 2;
            permafrost.needs_to_be_explored = false;
            AssetManager.traits.add(permafrost);
            LM.AddToCurrentLocale("trait_blizzardstepper", "Blizzard Stepper");
            LM.AddToCurrentLocale("trait_blizzardstepper_info", "Born in the frozen wastelands of Permafrost, this individual moves with ease through the blizzards, untouched by the biting cold.");

            ActorTrait flower = new ActorTrait();
            flower.id = "pollenblooded";
            flower.path_icon = "ui/Icons/actor_traits/lifeborn/pollenblooded";
            flower.group_id = "lifebound";
            flower.type = TraitType.Positive;
            flower.can_be_given = false;
            flower.can_be_removed = false;
            flower.same_trait_mod = 5;
            flower.rate_acquire_grow_up = 2;
            flower.needs_to_be_explored = false;
            AssetManager.traits.add(flower);
            LM.AddToCurrentLocale("trait_pollenblooded", "Pollen Blooded");
            LM.AddToCurrentLocale("trait_pollenblooded_info", "Born amidst the vibrant blooms of the Flower realm, this individual’s essence is infused with the sweet power of pollen.");

            ActorTrait celestial = new ActorTrait();
            celestial.id = "etherflow";
            celestial.path_icon = "ui/Icons/actor_traits/lifeborn/etherflow";
            celestial.group_id = "lifebound";
            celestial.type = TraitType.Positive;
            celestial.can_be_given = false;
            celestial.can_be_removed = false;
            celestial.same_trait_mod = 5;
            celestial.rate_acquire_grow_up = 2;
            celestial.needs_to_be_explored = false;
            AssetManager.traits.add(celestial);
            LM.AddToCurrentLocale("trait_etherflow", "Etherflow");
            LM.AddToCurrentLocale("trait_etherflow_info", "Born under the cosmic skies of the Celestial realm, this individual is intertwined with the flowing energies of the ether, radiating otherworldly power.");

            ActorTrait singularity = new ActorTrait();
            singularity.id = "tidalshift";
            singularity.path_icon = "ui/Icons/actor_traits/lifeborn/tidalshift";
            singularity.group_id = "lifebound";
            singularity.type = TraitType.Positive;
            singularity.can_be_given = false;
            singularity.can_be_removed = false;
            singularity.same_trait_mod = 5;
            singularity.rate_acquire_grow_up = 2;
            singularity.needs_to_be_explored = false;
            AssetManager.traits.add(singularity);
            LM.AddToCurrentLocale("trait_tidalshift", "Tidalshift");
            LM.AddToCurrentLocale("trait_tidalshift_info", "Born at the edge of the Singularity, this individual is shaped by the cosmic tides, constantly shifting with the flow of time and space.");

            ActorTrait paradox = new ActorTrait();
            paradox.id = "timeworn";
            paradox.path_icon = "ui/Icons/actor_traits/lifeborn/timeworn";
            paradox.group_id = "lifebound";
            paradox.type = TraitType.Positive;
            paradox.can_be_given = false;
            paradox.can_be_removed = false;
            paradox.same_trait_mod = 5;
            paradox.rate_acquire_grow_up = 2;
            paradox.needs_to_be_explored = false;
            AssetManager.traits.add(paradox);
            LM.AddToCurrentLocale("trait_timeworn", "Timeworn");
            LM.AddToCurrentLocale("trait_timeworn_info", "Born within the tangled layers of the Paradox, this individual carries the weight of ages, their essence twisted by the flow of time.");

            ActorTrait clover = new ActorTrait();
            clover.id = "clovertoed";
            clover.path_icon = "ui/Icons/actor_traits/lifeborn/clovertoed";
            clover.group_id = "lifebound";
            clover.type = TraitType.Positive;
            clover.can_be_given = false;
            clover.can_be_removed = false;
            clover.same_trait_mod = 5;
            clover.rate_acquire_grow_up = 2;
            clover.needs_to_be_explored = false;
            AssetManager.traits.add(clover);
            LM.AddToCurrentLocale("trait_clovertoed", "Clovertoed");
            LM.AddToCurrentLocale("trait_clovertoed_info", "Born under the lucky skies of Luck, this individual’s steps are blessed, always guided by the fortune of four-leaf clovers.");

            ActorTrait wasteland = new ActorTrait();
            wasteland.id = "feralforward";
            wasteland.path_icon = "ui/Icons/actor_traits/lifeborn/feralforward";
            wasteland.group_id = "lifebound";
            wasteland.type = TraitType.Positive;
            wasteland.can_be_given = false;
            wasteland.can_be_removed = false;
            wasteland.same_trait_mod = 5;
            wasteland.rate_acquire_grow_up = 2;
            wasteland.needs_to_be_explored = false;
            AssetManager.traits.add(wasteland);
            LM.AddToCurrentLocale("trait_feralforward", "Feral Forward");
            LM.AddToCurrentLocale("trait_feralforward_info", "Born in the harsh Wastelands, this individual moves with primal instinct, always pushing forward through the desolation.");


            ActorTrait randomi = new ActorTrait();
            randomi.id = "bananalover";
            randomi.path_icon = "ui/Icons/actor_traits/random/bananalover";
            randomi.group_id = "random";
            randomi.type = TraitType.Positive;
            randomi.can_be_given = false;
            randomi.can_be_removed = false;
            randomi.same_trait_mod = 5;
            randomi.rate_acquire_grow_up = 2;
            randomi.needs_to_be_explored = true;
            randomi.rate_birth = 1;
            AssetManager.traits.add(randomi);
            LM.AddToCurrentLocale("trait_bananalover", "Lover of Bananas");
            LM.AddToCurrentLocale("trait_bananalover_info", "Mf loves them some bananananas");

            ActorTrait randomii = new ActorTrait();
            randomii.id = "treehugger";
            randomii.path_icon = "ui/Icons/actor_traits/random/treehugger";
            randomii.group_id = "random";
            randomii.type = TraitType.Positive;
            randomii.can_be_given = false;
            randomii.can_be_removed = false;
            randomii.same_trait_mod = 5;
            randomii.rate_acquire_grow_up = 2;
            randomii.needs_to_be_explored = true;
            randomii.rate_birth = 1;
            AssetManager.traits.add(randomii);
            LM.AddToCurrentLocale("trait_treehugger", "Tree Hugger");
            LM.AddToCurrentLocale("trait_treehugger_info", "A hugger of trees");

            ActorTrait randomiii = new ActorTrait();
            randomiii.id = "rapman";
            randomiii.path_icon = "ui/Icons/actor_traits/random/rapman";
            randomiii.group_id = "random";
            randomiii.type = TraitType.Positive;
            randomiii.can_be_given = true;
            randomiii.can_be_removed = true;
            randomiii.same_trait_mod = 5;
            randomiii.rate_acquire_grow_up = 2;
            randomiii.needs_to_be_explored = true;
            randomiii.rate_birth = 1;
            AssetManager.traits.add(randomiii);
            LM.AddToCurrentLocale("trait_rapman", "Rapman");
            LM.AddToCurrentLocale("trait_rapman_info", "That one kid in school who wanted to be a rapper");

            ActorTrait randomiv = new ActorTrait();
            randomiv.id = "blessyou";
            randomiv.path_icon = "ui/Icons/actor_traits/random/blessyou";
            randomiv.group_id = "random";
            randomiv.type = TraitType.Positive;
            randomiv.can_be_given = true;
            randomiv.can_be_removed = true;
            randomiv.same_trait_mod = 5;
            randomiv.rate_acquire_grow_up = 2;
            randomiv.needs_to_be_explored = true;
            randomiv.rate_birth = 1;
            AssetManager.traits.add(randomiv);
            LM.AddToCurrentLocale("trait_blessyou", "Sneeze of Doom");
            LM.AddToCurrentLocale("trait_blessyou_info", "A dads 'Sneeze of Doom'");


            ActorTrait randomvi = new ActorTrait();
            randomvi.id = "box";
            randomvi.path_icon = "ui/Icons/actor_traits/random/box";
            randomvi.group_id = "random";
            randomvi.type = TraitType.Positive;
            randomvi.can_be_given = true;
            randomvi.can_be_removed = true;
            randomvi.same_trait_mod = 5;
            randomvi.rate_acquire_grow_up = 2;
            randomvi.needs_to_be_explored = true;
            randomvi.rate_birth = 1;
            AssetManager.traits.add(randomvi);
            LM.AddToCurrentLocale("trait_box", "BOX");
            LM.AddToCurrentLocale("trait_box_info", "This is a box");

            ActorTrait randomvii = new ActorTrait();
            randomvii.id = "openbox";
            randomvii.path_icon = "ui/Icons/actor_traits/random/openbox";
            randomvii.group_id = "random";
            randomvii.type = TraitType.Positive;
            randomvii.can_be_given = true;
            randomvii.can_be_removed = true;
            randomvii.same_trait_mod = 5;
            randomvii.rate_acquire_grow_up = 2;
            randomvii.needs_to_be_explored = true;
            randomvii.rate_birth = 1;
            AssetManager.traits.add(randomvii);
            LM.AddToCurrentLocale("trait_openbox", "OPEN BOX");
            LM.AddToCurrentLocale("trait_openbox_info", "This is a box, but open");

            ActorTrait randomviii = new ActorTrait();
            randomviii.id = "chknngt";
            randomviii.path_icon = "ui/Icons/actor_traits/random/chknngt";
            randomviii.group_id = "random";
            randomviii.type = TraitType.Positive;
            randomviii.can_be_given = true;
            randomviii.can_be_removed = true;
            randomviii.same_trait_mod = 5;
            randomviii.rate_acquire_grow_up = 2;
            randomviii.needs_to_be_explored = true;
            randomviii.rate_birth = 1;
            AssetManager.traits.add(randomviii);
            LM.AddToCurrentLocale("trait_chknngt", "CHICKEN NUGGETS!!!");
            LM.AddToCurrentLocale("trait_chknngt_info", "That one random dude you met who only eats chicken nuggets");

            ActorTrait randomix = new ActorTrait();
            randomix.id = "discordmod";
            randomix.path_icon = "ui/Icons/actor_traits/random/discordmod";
            randomix.group_id = "random";
            randomix.type = TraitType.Positive;
            randomix.can_be_given = true;
            randomix.can_be_removed = true;
            randomix.same_trait_mod = 5;
            randomix.rate_acquire_grow_up = 2;
            randomix.needs_to_be_explored = true;
            randomix.rate_birth = 1;
            AssetManager.traits.add(randomix);
            LM.AddToCurrentLocale("trait_discordmod", "Runecord Mod");
            LM.AddToCurrentLocale("trait_discordmod_info", "Your typical Runecord Mod");

            ActorTrait randomx = new ActorTrait();
            randomx.id = "redditmod";
            randomx.path_icon = "ui/Icons/actor_traits/random/redditmod";
            randomx.group_id = "random";
            randomx.type = TraitType.Positive;
            randomx.can_be_given = true;
            randomx.can_be_removed = true;
            randomx.same_trait_mod = 5;
            randomx.rate_acquire_grow_up = 2;
            randomx.needs_to_be_explored = true;
            randomx.rate_birth = 1;
            AssetManager.traits.add(randomx);
            LM.AddToCurrentLocale("trait_redditmod", "Runeddit Mod");
            LM.AddToCurrentLocale("trait_redditmod_info", "Your typical Runeddit Mod");

            ActorTrait randomxi = new ActorTrait();
            randomxi.id = "sandpit_turtle";
            randomxi.path_icon = "ui/Icons/actor_traits/random/Sandpit_Turtle";
            randomxi.group_id = "random";
            randomxi.type = TraitType.Negative;
            randomxi.can_be_given = true;
            randomxi.same_trait_mod = 5;
            randomxi.rate_acquire_grow_up = 2;
            randomxi.rate_inherit = 5;
            randomxi.needs_to_be_explored = true;
            randomxi.rate_birth = 1;
            AssetManager.traits.add(randomxi);
            LM.AddToCurrentLocale("trait_sandpit_turtle", "Sandpit Turtle");
            LM.AddToCurrentLocale("trait_sandpit_turtle_info", "THIS! IS! SANDPIT TURTLE!!!! OVER AND OVER AGAIN AND AGAIN!!!!");



            ActorTrait randomxii = new ActorTrait();
            randomxii.id = "melted_shoes";
            randomxii.path_icon = "ui/Icons/actor_traits/random/melted_shoe_placeholder";
            randomxii.group_id = "random";
            randomxii.type = TraitType.Negative;
            randomxii.can_be_given = true;
            randomxii.same_trait_mod = 5;
            randomxii.rate_acquire_grow_up = 2;
            randomxii.rate_inherit = 5;
            randomxii.needs_to_be_explored = true;
            randomxii.rate_birth = 1;
            AssetManager.traits.add(randomxii);
            LM.AddToCurrentLocale("trait_melted_shoes", "Melted Shoes");
            LM.AddToCurrentLocale("trait_melted_shoes_info", "His shoes melted"); //PLACEHOLDER

            randomxii.base_stats.set("speed", -3f);



            ActorTrait randomxiii = new ActorTrait();
            randomxiii.id = "frostbite";
            randomxiii.path_icon = "ui/Icons/actor_traits/random/frostbite";
            randomxiii.group_id = "random";
            randomxiii.type = TraitType.Negative;
            randomxiii.can_be_given = true;
            randomxiii.can_be_removed = true;
            randomxiii.same_trait_mod = 5;
            randomxiii.rate_acquire_grow_up = 2;
            randomxiii.needs_to_be_explored = true;
            randomxiii.rate_birth = 1;
            AssetManager.traits.add(randomxiii);
            LM.AddToCurrentLocale("trait_frostbite", "Frostbite");
            LM.AddToCurrentLocale("trait_frostbite_info", "MFN COLD OUT HERE"); //PLACEHOLDER
            ActorTrait rXIII = randomxiii;
            rXIII.action_special_effect = (WorldAction)Delegate.Combine(rXIII.action_special_effect, new WorldAction(ActionLibrary.coldAuraEffect));


            ActorTrait randomxiv = new ActorTrait();
            randomxiv.id = "solarborn";
            randomxiv.path_icon = "ui/Icons/actor_traits/random/solarborn";
            randomxiv.group_id = "random";
            randomxiv.type = TraitType.Negative;
            randomxiv.can_be_given = true;
            randomxiv.can_be_removed = true;
            randomxiv.same_trait_mod = 5;
            randomxiv.rate_acquire_grow_up = 2;
            randomxiv.needs_to_be_explored = true;
            randomxiv.rate_birth = 1;
            AssetManager.traits.add(randomxiv);
            LM.AddToCurrentLocale("trait_solarborn", "Solarborn");
            LM.AddToCurrentLocale("trait_solarborn_info", "Born from the sun (Scrapped)"); //PLACEHOLDER
            ActorTrait rXIV = randomxiv;



            ActorTrait randomxv = new ActorTrait();
            randomxv.id = "Haunting Presence";
            randomxv.path_icon = "ui/Icons/actor_traits/random/hauntingpresence";
            randomxv.group_id = "random";
            randomxv.type = TraitType.Negative;
            randomxv.can_be_given = true;
            randomxv.can_be_removed = true;
            randomxv.same_trait_mod = 5;
            randomxv.rate_acquire_grow_up = 2;
            randomxv.needs_to_be_explored = true;
            randomxv.rate_birth = 1;
            AssetManager.traits.add(randomxv);
            LM.AddToCurrentLocale("trait_Haunting Presence", "Haunting Presence");
            LM.AddToCurrentLocale("trait_Haunting Presence_info", "Surrounded by what's not visible (Scrapped)"); //PLACEHOLDER
            ActorTrait rXV = randomxv;
            rXV.action_special_effect = (WorldAction)Delegate.Combine(rXV.action_special_effect, new WorldAction(ActionLibrary.spawnGhost));

            ActorTrait randomxvi = new ActorTrait();
            randomxvi.id = "boomer";
            randomxvi.path_icon = "ui/Icons/actor_traits/random/boomer";
            randomxvi.group_id = "random";
            randomxvi.type = TraitType.Negative;
            randomxvi.can_be_given = true;
            randomxvi.can_be_removed = true;
            randomxvi.same_trait_mod = 5;
            randomxvi.rate_acquire_grow_up = 2;
            randomxvi.needs_to_be_explored = true;
            randomxvi.rate_birth = 1;
            AssetManager.traits.add(randomxvi);
            LM.AddToCurrentLocale("trait_boomer", "Boomer");
            LM.AddToCurrentLocale("trait_boomer_info", "Built like a bomb. High damage, low health.");
            ActorTrait rXVI = randomxvi;
            rXVI.action_special_effect = (WorldAction)Delegate.Combine(rXVI.action_special_effect, new WorldAction(ActionLibrary.deathMark));
            rXVI.action_special_effect = (WorldAction)Delegate.Combine(rXVI.action_special_effect, new WorldAction(ActionLibrary.canThrowBomb));

            randomxvi.base_stats.set("health", -50f);
            randomxvi.base_stats.set("damage", 20f);
            randomxvi.base_stats.set("armor", -5f);

            ActorTrait randomxvii = new ActorTrait();
            randomxvii.id = "breadbrain";
            randomxvii.path_icon = "ui/Icons/actor_traits/random/breadbrain";
            randomxvii.group_id = "random";
            randomxvii.type = TraitType.Negative;
            randomxvii.can_be_given = true;
            randomxvii.can_be_removed = true;
            randomxvii.same_trait_mod = 5;
            randomxvii.rate_acquire_grow_up = 2;
            randomxvii.needs_to_be_explored = true;
            randomxvii.rate_birth = 1;
            AssetManager.traits.add(randomxvii);
            LM.AddToCurrentLocale("trait_breadbrain", "Bread Brain");
            LM.AddToCurrentLocale("trait_breadbrain_info", "Loaf of bread for a brain. Smells amazing.");

            randomxvii.base_stats.set("health", -20f);
            randomxvii.base_stats.set("armor", -5f);
            randomxvii.base_stats.set("intelligence", -25f);

            ActorTrait randomxviii = new ActorTrait();
            randomxviii.id = "snacksize";
            randomxviii.path_icon = "ui/Icons/actor_traits/random/snacksize";
            randomxviii.group_id = "random";
            randomxviii.type = TraitType.Negative;
            randomxviii.can_be_given = true;
            randomxviii.can_be_removed = true;
            randomxviii.same_trait_mod = 5;
            randomxviii.rate_acquire_grow_up = 2;
            randomxviii.needs_to_be_explored = true;
            randomxviii.rate_birth = 1;
            AssetManager.traits.add(randomxviii);
            LM.AddToCurrentLocale("trait_snacksize", "Snack Sized");
            LM.AddToCurrentLocale("trait_snacksize_info", "Just a small person");

            randomxviii.base_stats.set("scale", -0.025f);
            randomxviii.base_stats.set("speed", 2f);
            randomxviii.base_stats.set("armor", -2f);
            randomxviii.base_stats.set("health", -30f);

            ActorTrait randomxix = new ActorTrait();
            randomxix.id = "extremelyav";
            randomxix.path_icon = "ui/Icons/actor_traits/random/extremelyav";
            randomxix.group_id = "random";
            randomxix.type = TraitType.Negative;
            randomxix.can_be_given = true;
            randomxix.can_be_removed = true;
            randomxix.same_trait_mod = 5;
            randomxix.rate_acquire_grow_up = 2;
            randomxix.needs_to_be_explored = true;
            randomxix.rate_birth = 1;
            AssetManager.traits.add(randomxix);
            LM.AddToCurrentLocale("trait_extremelyav", "Extremely Average");
            LM.AddToCurrentLocale("trait_extremelyav_info", "Hi, I'm Normal");

            ActorTrait randomxx = new ActorTrait();
            randomxx.id = "PlasticBag";  //I CANT FUCKING SLEEP
            randomxx.path_icon = "ui/Icons/actor_traits/random/PlasticBag"; //sprite done
            randomxx.group_id = "random";
            randomxx.type = TraitType.Negative;
            randomxx.can_be_given = true;
            randomxx.can_be_removed = true;
            randomxx.same_trait_mod = 5;
            randomxx.rate_acquire_grow_up = 2;
            randomxx.needs_to_be_explored = true;
            randomxx.rate_birth = 1;
            AssetManager.traits.add(randomxx);
            LM.AddToCurrentLocale("trait_PlasticBag", "Plastic Bag");


            ActorTrait randomxxi = new ActorTrait();
            randomxxi.id = "PaperBag";
            randomxxi.path_icon = "ui/Icons/actor_traits/random/PaperBag"; //sprite done
            randomxxi.group_id = "random";
            randomxxi.type = TraitType.Negative;
            randomxxi.can_be_given = true;
            randomxxi.can_be_removed = true;
            randomxxi.same_trait_mod = 5;
            randomxxi.rate_acquire_grow_up = 2;
            randomxxi.needs_to_be_explored = true;
            randomxxi.rate_birth = 1;
            AssetManager.traits.add(randomxxi);
            LM.AddToCurrentLocale("trait_PaperBag", "Paper Bag");

            ActorTrait randomxxii = new ActorTrait();
            randomxxii.id = "PlasticStraw";
            randomxxii.path_icon = "ui/Icons/actor_traits/random/PlasticStraw"; //sprite done
            randomxxii.group_id = "random";
            randomxxii.type = TraitType.Negative;
            randomxxii.can_be_given = true;
            randomxxii.can_be_removed = true;
            randomxxii.same_trait_mod = 5;
            randomxxii.rate_acquire_grow_up = 2;
            randomxxii.needs_to_be_explored = true;
            randomxxii.rate_birth = 1;
            AssetManager.traits.add(randomxxii);
            LM.AddToCurrentLocale("trait_PlasticStraw", "Plastic Straw");
            LM.AddToCurrentLocale("trait_PlasticStraw_info", "Turtles no bueno");

            ActorTrait randomxxiii = new ActorTrait();
            randomxxiii.id = "PaperStraw";
            randomxxiii.path_icon = "ui/Icons/actor_traits/random/PaperStraw"; //sprite done
            randomxxiii.group_id = "random";
            randomxxiii.type = TraitType.Negative;
            randomxxiii.can_be_given = true;
            randomxxiii.can_be_removed = true;
            randomxxiii.same_trait_mod = 5;
            randomxxiii.rate_acquire_grow_up = 2;
            randomxxiii.needs_to_be_explored = true;
            randomxxiii.rate_birth = 1;
            AssetManager.traits.add(randomxxiii);
            LM.AddToCurrentLocale("trait_PaperStraw", "Paper Straw");
            LM.AddToCurrentLocale("trait_PaperStraw_info", "IT MELTED IN MY DRINK");

            ActorTrait randomxxiv = new ActorTrait();
            randomxxiv.id = "ChknLittle";
            randomxxiv.path_icon = "ui/Icons/actor_traits/random/ChknLittle"; //sprite done
            randomxxiv.group_id = "random";
            randomxxiv.type = TraitType.Negative;
            randomxxiv.can_be_given = true;
            randomxxiv.can_be_removed = true;
            randomxxiv.same_trait_mod = 5;
            randomxxiv.rate_acquire_grow_up = 2;
            randomxxiv.needs_to_be_explored = true;
            randomxxiv.rate_birth = 1;
            AssetManager.traits.add(randomxxiv);
            LM.AddToCurrentLocale("trait_ChknLittle", "Chicken Little?");
            LM.AddToCurrentLocale("trait_ChknLittle_info", "*Kick*");

            ActorTrait randomxxv = new ActorTrait();
            randomxxv.id = "SpicyChknNggt";
            randomxxv.path_icon = "ui/Icons/actor_traits/random/SpicyChknNggt"; //sprite done
            randomxxv.group_id = "random";
            randomxxv.type = TraitType.Negative;
            randomxxv.can_be_given = true;
            randomxxv.can_be_removed = true;
            randomxxv.same_trait_mod = 5;
            randomxxv.rate_acquire_grow_up = 2;
            randomxxv.needs_to_be_explored = true;
            randomxxv.rate_birth = 1;
            AssetManager.traits.add(randomxxv);
            LM.AddToCurrentLocale("trait_SpicyChknNggt", "Spicy Chicken Nuggets");
            LM.AddToCurrentLocale("trait_SpicyChknNggt_info", "They're better!");


            ActorTrait randomxxvi = new ActorTrait();
            randomxxvi.id = "InstantDeath";
            randomxxvi.path_icon = "ui/Icons/actor_traits/random/InstantDeath"; //sprite done
            randomxxvi.group_id = "random";
            randomxxvi.type = TraitType.Negative;
            randomxxvi.can_be_given = true;
            randomxxvi.can_be_removed = true;
            randomxxvi.same_trait_mod = 5;
            randomxxvi.rate_acquire_grow_up = 2;
            randomxxvi.needs_to_be_explored = true;
            randomxxvi.rate_birth = 1;
            AssetManager.traits.add(randomxxvi);
            LM.AddToCurrentLocale("trait_InstantDeath", "Instant Death");
            LM.AddToCurrentLocale("trait_InstantDeath_info", "Sometimes people just get too powerful.... or they're assholes.");
            randomxxvi.action_special_effect = (WorldAction)InstantDeath;


            ActorTrait randomxxvii = new ActorTrait();
            randomxxvii.id = "CelebStatus";
            randomxxvii.path_icon = "ui/Icons/actor_traits/random/CelebStatus"; //sprite done
            randomxxvii.group_id = "random";
            randomxxvii.type = TraitType.Positive;
            randomxxvii.can_be_given = true;
            randomxxvii.can_be_removed = true;
            randomxxvii.same_trait_mod = 5;
            randomxxvii.rate_acquire_grow_up = 2;
            randomxxvii.needs_to_be_explored = true;
            randomxxvii.rate_birth = 1;
            AssetManager.traits.add(randomxxvii);
            LM.AddToCurrentLocale("trait_CelebStatus", "Celebrity");
            LM.AddToCurrentLocale("trait_CelebStatus_info", "Give this to someone worthy of the Instant Death trait");

            ActorTrait randomxxviii = new ActorTrait();
            randomxxviii.id = "GodIsAWeapon";
            randomxxviii.path_icon = "ui/Icons/actor_traits/random/GodIsAWeapon"; //sprite done
            randomxxviii.group_id = "random";
            randomxxviii.type = TraitType.Positive;
            randomxxviii.can_be_given = false;
            randomxxviii.can_be_removed = true;
            randomxxviii.same_trait_mod = 5;
            randomxxviii.rate_acquire_grow_up = 2;
            randomxxviii.needs_to_be_explored = false;
            randomxxviii.rate_birth = 1;
            AssetManager.traits.add(randomxxviii);
            LM.AddToCurrentLocale("trait_GodIsAWeapon", "God is a weapon ft. Marilyn Manson");
            LM.AddToCurrentLocale("trait_GodIsAWeapon_info", "This is just a music suggestion. released by Falling In Reverse featuring Marilyn Manson. this has no functionality at all. cant even be given");













            ActorTrait disorderi = new ActorTrait();
            disorderi.id = "ptsd";
            disorderi.path_icon = "ui/Icons/actor_traits/disorders/ptsd"; // PlaceHolder
            disorderi.group_id = "disorders";
            disorderi.type = TraitType.Negative;
            disorderi.can_be_given = true;
            disorderi.can_be_removed = true;
            disorderi.same_trait_mod = 5;
            disorderi.rate_acquire_grow_up = 2;
            disorderi.needs_to_be_explored = false;
            disorderi.rate_birth = 1;
            AssetManager.traits.add(disorderi);
            LM.AddToCurrentLocale("trait_ptsd", "PTSD");
            LM.AddToCurrentLocale("trait_ptsd_info", "Seen some shit (Scrapped)");

            ActorTrait disorderii = new ActorTrait();
            disorderii.id = "anxiety";
            disorderii.path_icon = "ui/Icons/actor_traits/disorders/anxiety"; //Placeholder
            disorderii.group_id = "disorders";
            disorderii.type = TraitType.Negative;
            disorderii.can_be_given = true;
            disorderii.can_be_removed = true;
            disorderii.same_trait_mod = 5;
            disorderii.rate_acquire_grow_up = 2;
            disorderii.needs_to_be_explored = false;
            disorderii.rate_birth = 1;
            AssetManager.traits.add(disorderii);
            LM.AddToCurrentLocale("trait_anxiety", "Anxiety");
            LM.AddToCurrentLocale("trait_anxiety_info", "Never ending worry and nervousness (Scrapped)");

            ActorTrait disorderiii = new ActorTrait();
            disorderiii.id = "depression";
            disorderiii.path_icon = "ui/Icons/actor_traits/disorders/depression"; //Placeholder
            disorderiii.group_id = "disorders";
            disorderiii.type = TraitType.Negative;
            disorderiii.can_be_given = true;
            disorderiii.can_be_removed = true;
            disorderiii.same_trait_mod = 5;
            disorderiii.rate_acquire_grow_up = 2;
            disorderiii.needs_to_be_explored = false;
            disorderiii.rate_birth = 1;
            AssetManager.traits.add(disorderiii);
            LM.AddToCurrentLocale("trait_depression", "Depression");
            LM.AddToCurrentLocale("trait_depression_info", "(Scrapped)");

            ActorTrait disorderiv = new ActorTrait();
            disorderiv.id = "Dissociation";
            disorderiv.path_icon = "ui/Icons/actor_traits/disorders/Dissociation"; //Placeholder
            disorderiv.group_id = "disorders";
            disorderiv.type = TraitType.Negative;
            disorderiv.can_be_given = true;
            disorderiv.can_be_removed = true;
            disorderiv.same_trait_mod = 5;
            disorderiv.rate_acquire_grow_up = 2;
            disorderiv.needs_to_be_explored = false;
            disorderiv.rate_birth = 1;
            AssetManager.traits.add(disorderiv);
            LM.AddToCurrentLocale("trait_Dissociation", "Dissociation");


            ActorTrait disordervii = new ActorTrait();
            disordervii.id = "schizophrenia";
            disordervii.path_icon = "ui/Icons/actor_traits/disorders/schizophrenia"; //Placeholder
            disordervii.group_id = "disorders";
            disordervii.type = TraitType.Negative;
            disordervii.can_be_given = true;
            disordervii.can_be_removed = true;
            disordervii.same_trait_mod = 5;
            disordervii.rate_acquire_grow_up = 2;
            disordervii.needs_to_be_explored = false;
            disordervii.rate_birth = 1;
            AssetManager.traits.add(disordervii);
            LM.AddToCurrentLocale("trait_schizophrenia", "Schizophrenia");
            LM.AddToCurrentLocale("trait_schizophrenia_info", "(Scrapped)");


            ActorTrait disorderviii = new ActorTrait();
            disorderviii.id = "survivors_guilt";
            disorderviii.path_icon = "ui/Icons/actor_traits/disorders/survivors_guilt"; //Placeholder
            disorderviii.group_id = "disorders";
            disorderviii.type = TraitType.Negative;
            disorderviii.can_be_given = true;
            disorderviii.can_be_removed = true;
            disorderviii.same_trait_mod = 5;
            disorderviii.rate_acquire_grow_up = 2;
            disorderviii.needs_to_be_explored = false;
            disorderviii.rate_birth = 1;
            AssetManager.traits.add(disorderviii);
            LM.AddToCurrentLocale("trait_survivors_guilt", "Survivor Guilt");

            ActorTrait disorderix = new ActorTrait();
            disorderix.id = "bipolar";
            disorderix.path_icon = "ui/Icons/actor_traits/disorders/bipolar"; //Placeholder
            disorderix.group_id = "disorders";
            disorderix.type = TraitType.Negative;
            disorderix.can_be_given = true;
            disorderix.can_be_removed = true;
            disorderix.same_trait_mod = 5;
            disorderix.rate_acquire_grow_up = 2;
            disorderix.needs_to_be_explored = false;
            disorderix.rate_birth = 1;
            AssetManager.traits.add(disorderix);
            LM.AddToCurrentLocale("trait_bipolar", "Bipolar Disorder");

            ActorTrait disorderx = new ActorTrait();
            disorderx.id = "paranoia";
            disorderx.path_icon = "ui/Icons/actor_traits/disorders/paranoia";
            disorderx.group_id = "disorders";
            disorderx.type = TraitType.Negative;
            disorderx.can_be_given = true;
            disorderx.can_be_removed = true;
            disorderx.same_trait_mod = 5;
            disorderx.rate_acquire_grow_up = 2;
            disorderx.needs_to_be_explored = false;
            disorderx.rate_birth = 1;
            AssetManager.traits.add(disorderx);
            LM.AddToCurrentLocale("trait_paranoia", "Paranoia");
            LM.AddToCurrentLocale("trait_paranoia_info", "(Scrapped)");

            ActorTrait disorderxi = new ActorTrait();
            disorderxi.id = "insomnia";  //I CANT FUCKING SLEEP
            disorderxi.path_icon = "ui/Icons/actor_traits/disorders/insomnia"; //sprite done
            disorderxi.group_id = "disorders";
            disorderxi.type = TraitType.Negative;
            disorderxi.can_be_given = true;
            disorderxi.can_be_removed = true;
            disorderxi.same_trait_mod = 5;
            disorderxi.rate_acquire_grow_up = 2;
            disorderxi.needs_to_be_explored = false;
            disorderxi.rate_birth = 1;
            AssetManager.traits.add(disorderxi);
            LM.AddToCurrentLocale("trait_insomnia", "Insomnia");

            ActorTrait disorderxii = new ActorTrait();
            disorderxii.id = "narcolepsy";  //All I Do is FUcking Sleep
            disorderxii.path_icon = "ui/Icons/actor_traits/disorders/narcolepsy"; //sprite done
            disorderxii.group_id = "disorders";
            disorderxii.type = TraitType.Negative;
            disorderxii.can_be_given = true;
            disorderxii.can_be_removed = true;
            disorderxii.same_trait_mod = 5;
            disorderxii.rate_acquire_grow_up = 2;
            disorderxii.needs_to_be_explored = false;
            disorderxii.rate_birth = 1;
            AssetManager.traits.add(disorderxii);
            LM.AddToCurrentLocale("trait_narcolepsy", "Narcolepsy");

            ActorTrait sicknessI = new ActorTrait();
            sicknessI.id = "Malaria";
            sicknessI.path_icon = "ui/Icons/actor_traits/illness/Malaria";
            sicknessI.group_id = "sickness";
            sicknessI.type = TraitType.Negative;
            sicknessI.can_be_cured = true;
            sicknessI.can_be_given = true;
            sicknessI.can_be_removed = true;
            sicknessI.can_be_removed_by_divine_light = true;
            sicknessI.can_be_removed_by_accelerated_healing = true;
            sicknessI.same_trait_mod = 5;
            sicknessI.rate_acquire_grow_up = 3;
            sicknessI.needs_to_be_explored = false;
            AssetManager.traits.add(sicknessI);
            LM.AddToCurrentLocale("trait_Malaria", "Malaria");
            LM.AddToCurrentLocale("trait_Malaria_info", "Messed with the wrong Mosquito");


            sicknessI.addOpposite("immune");
            sicknessI.addOpposite("immortal");
            sicknessI.addOpposite("boat");
            sicknessI.addOpposite("plague");
            ActorTrait sI = sicknessI;
            sI.action_special_effect = (WorldAction)Delegate.Combine(sI.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sicknessI.base_stats.set("multiplier_speed", -0.3f);
            sicknessI.base_stats.set("multiplier_damage", -0.2f);
            sicknessI.base_stats.set("health", -16);


            ActorTrait sicknessII = new ActorTrait();
            sicknessII.id = "Covid19";
            sicknessII.path_icon = "ui/Icons/actor_traits/illness/Covid";
            sicknessII.group_id = "sickness";
            sicknessII.type = TraitType.Negative;
            sicknessII.can_be_cured = false;
            sicknessII.can_be_given = true;
            sicknessII.can_be_removed = true;
            sicknessII.can_be_removed_by_divine_light = true;
            sicknessII.can_be_removed_by_accelerated_healing = true;
            sicknessII.same_trait_mod = 5;
            sicknessII.rate_acquire_grow_up = 3;
            sicknessII.needs_to_be_explored = false;
            sicknessII.addOpposite("immune");
            sicknessII.addOpposite("immortal");
            sicknessII.addOpposite("boat");
            sicknessII.addOpposite("plague");
            AssetManager.traits.add(sicknessII);
            LM.AddToCurrentLocale("trait_Covid19", "Covid-19");
            LM.AddToCurrentLocale("trait_Covid19_info", "Oh look a bat");
            ActorTrait sII = sicknessII;
            sII.action_special_effect = (WorldAction)Delegate.Combine(sII.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sII.action_special_effect = (WorldAction)Delegate.Combine(sII.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sicknessII.base_stats.set("multiplier_speed", -0.3f);
            sicknessII.base_stats.set("multiplier_damage", -0.16f);
            sicknessII.base_stats.set("health", -24);


            ActorTrait sicknessIII = new ActorTrait();
            sicknessIII.id = "Flu";
            sicknessIII.path_icon = "ui/Icons/actor_traits/illness/Flu";
            sicknessIII.group_id = "sickness";
            sicknessIII.type = TraitType.Negative;
            sicknessIII.can_be_cured = false;
            sicknessIII.can_be_given = true;
            sicknessIII.can_be_removed = true;
            sicknessIII.can_be_removed_by_divine_light = true;
            sicknessIII.can_be_removed_by_accelerated_healing = true;
            sicknessIII.same_trait_mod = 5;
            sicknessIII.rate_acquire_grow_up = 3;
            sicknessIII.needs_to_be_explored = false;
            sicknessIII.addOpposite("immune");
            sicknessIII.addOpposite("immortal");
            sicknessIII.addOpposite("boat");
            sicknessIII.addOpposite("plague");
            AssetManager.traits.add(sicknessIII);
            LM.AddToCurrentLocale("trait_Flu", "Flu");
            LM.AddToCurrentLocale("trait_Flu_info", "Cough Cough");

            ActorTrait sIII = sicknessIII;
            sIII.action_special_effect = (WorldAction)Delegate.Combine(sIII.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sIII.action_special_effect = (WorldAction)Delegate.Combine(sIII.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sicknessIII.base_stats.set("multiplier_speed", -0.3f);
            sicknessIII.base_stats.set("multiplier_damage", -0.12f);
            sicknessIII.base_stats.set("health", -12);

            ActorTrait sicknessIV = new ActorTrait();
            sicknessIV.id = "pneumonia";
            sicknessIV.path_icon = "ui/Icons/actor_traits/illness/Pneumonia";
            sicknessIV.group_id = "sickness";
            sicknessIV.type = TraitType.Negative;
            sicknessIV.can_be_cured = true;
            sicknessIV.can_be_given = true;
            sicknessIV.can_be_removed = true;
            sicknessIV.can_be_removed_by_divine_light = true;
            sicknessIV.can_be_removed_by_accelerated_healing = true;
            sicknessIV.same_trait_mod = 5;
            sicknessIV.rate_acquire_grow_up = 3;
            sicknessIV.needs_to_be_explored = false;
            sicknessIV.addOpposite("immune");
            sicknessIV.addOpposite("immortal");
            sicknessIV.addOpposite("boat");
            sicknessIV.addOpposite("plague");
            AssetManager.traits.add(sicknessIV);
            LM.AddToCurrentLocale("trait_pneumonia", "Pneumonia");
            LM.AddToCurrentLocale("trait_pneumonia_info", "Cough Cough");

            ActorTrait sIV = sicknessIV;
            sIV.action_special_effect = (WorldAction)Delegate.Combine(sIV.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sIV.action_special_effect = (WorldAction)Delegate.Combine(sIV.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sicknessIV.base_stats.set("multiplier_speed", -0.4f);
            sicknessIV.base_stats.set("multiplier_damage", -0.18f);
            sicknessIV.base_stats.set("health", -28);

            ActorTrait sicknessV = new ActorTrait();
            sicknessV.id = "Ecoli";
            sicknessV.path_icon = "ui/Icons/actor_traits/illness/EColi";
            sicknessV.group_id = "sickness";
            sicknessV.type = TraitType.Negative;
            sicknessV.can_be_cured = true;
            sicknessV.can_be_given = true;
            sicknessV.can_be_removed = true;
            sicknessV.can_be_removed_by_divine_light = true;
            sicknessV.can_be_removed_by_accelerated_healing = true;
            sicknessV.same_trait_mod = 5;
            sicknessV.rate_acquire_grow_up = 3;
            sicknessV.needs_to_be_explored = false;
            sicknessV.addOpposite("immune");
            sicknessV.addOpposite("immortal");
            sicknessV.addOpposite("boat");
            sicknessV.addOpposite("plague");
            AssetManager.traits.add(sicknessV);
            LM.AddToCurrentLocale("trait_Ecoli", "E. Coli");
            LM.AddToCurrentLocale("trait_Ecoli_info", "The ground beef is now recalled");


            ActorTrait sV = sicknessV;
            sV.action_special_effect = (WorldAction)Delegate.Combine(sV.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sV.action_special_effect = (WorldAction)Delegate.Combine(sV.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sicknessV.base_stats.set("health", -14);

            ActorTrait sicknessVI = new ActorTrait();
            sicknessVI.id = "Salmonella";
            sicknessVI.path_icon = "ui/Icons/actor_traits/illness/Salmonella";
            sicknessVI.group_id = "sickness";
            sicknessVI.type = TraitType.Negative;
            sicknessVI.can_be_cured = true;
            sicknessVI.can_be_given = true;
            sicknessVI.can_be_removed = true;
            sicknessVI.can_be_removed_by_divine_light = true;
            sicknessVI.can_be_removed_by_accelerated_healing = true;
            sicknessVI.same_trait_mod = 5;
            sicknessVI.rate_acquire_grow_up = 3;
            sicknessVI.needs_to_be_explored = false;
            sicknessVI.addOpposite("immune");
            sicknessVI.addOpposite("immortal");
            sicknessVI.addOpposite("boat");
            sicknessVI.addOpposite("plague");
            AssetManager.traits.add(sicknessVI);
            LM.AddToCurrentLocale("trait_Salmonella", "Salmonella");
            LM.AddToCurrentLocale("trait_Salmonella_info", "ITS RAW");
            sicknessIV.base_stats.set("multiplier_speed", -0.3f);
            sicknessIV.base_stats.set("multiplier_damage", -0.16f);

            ActorTrait sVI = sicknessVI;
            sVI.action_special_effect = (WorldAction)Delegate.Combine(sVI.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sVI.action_special_effect = (WorldAction)Delegate.Combine(sVI.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sicknessVI.base_stats.set("health", -15);

            ActorTrait sicknessVII = new ActorTrait();
            sicknessVII.id = "SpaceAids";
            sicknessVII.path_icon = "ui/Icons/actor_traits/illness/SpaceAids";
            sicknessVII.group_id = "sickness";
            sicknessVII.type = TraitType.Negative;
            sicknessVII.can_be_cured = true;
            sicknessVII.can_be_given = true;
            sicknessVII.can_be_removed = true;
            sicknessVII.can_be_removed_by_divine_light = true;
            sicknessVII.can_be_removed_by_accelerated_healing = true;
            sicknessVII.same_trait_mod = 5;
            sicknessVII.rate_acquire_grow_up = 3;
            sicknessVII.needs_to_be_explored = false;
            sicknessVII.addOpposite("immune");
            sicknessVII.addOpposite("immortal");
            sicknessVII.addOpposite("boat");
            sicknessVII.addOpposite("plague");
            AssetManager.traits.add(sicknessVII);
            LM.AddToCurrentLocale("trait_SpaceAids", "Space Aids");
            LM.AddToCurrentLocale("trait_SpaceAids_info", "......");

            ActorTrait sVII = sicknessVII;
            sVII.action_special_effect = (WorldAction)Delegate.Combine(sVII.action_special_effect, new WorldAction(ActionLibrary.plagueEffect));
            sVII.action_special_effect = (WorldAction)Delegate.Combine(sVII.action_special_effect, new WorldAction(ActionLibrary.contagiousEffect));
            sicknessVII.base_stats.set("multiplier_speed", -0.6f);
            sicknessVII.base_stats.set("multiplier_damage", -0.34f);
            sicknessVII.base_stats.set("health", -43f);
            sicknessVII.base_stats.set("lifespan", -32f);

            ActorTrait sicknessVIII = new ActorTrait();
            sicknessVIII.id = "TS19";
            sicknessVIII.path_icon = "ui/Icons/actor_traits/illness/TS19";
            sicknessVIII.group_id = "sickness";
            sicknessVIII.type = TraitType.Negative;
            sicknessVIII.can_be_cured = true;
            sicknessVIII.can_be_given = true;
            sicknessVIII.can_be_removed = true;
            sicknessVIII.can_be_removed_by_divine_light = true;
            sicknessVIII.can_be_removed_by_accelerated_healing = false;
            sicknessVIII.same_trait_mod = 5;
            sicknessVIII.rate_acquire_grow_up = 3;
            sicknessVIII.needs_to_be_explored = false;
            sicknessVIII.addOpposite("immune");
            sicknessVIII.addOpposite("immortal");
            sicknessVIII.addOpposite("boat");
            sicknessVIII.addOpposite("plague");
            sicknessVIII.action_attack_target = new AttackAction(ActionLibrary.zombieInfectAttack);
            AssetManager.traits.add(sicknessVIII);
            LM.AddToCurrentLocale("trait_TS19", "TS-19");
            LM.AddToCurrentLocale("trait_TS19_info", "Virus from Walking Dead");

            ActorTrait sVIII = sicknessVIII;
            sVIII.action_special_effect = (WorldAction)Delegate.Combine(sVII.action_special_effect, new WorldAction(ActionLibrary.zombieEffect));
            sVIII.action_special_effect = (WorldAction)Delegate.Combine(sVII.action_special_effect, new WorldAction(ActionLibrary.turnIntoZombie));
            sicknessVII.base_stats.set("speed", -2f);



            ActorTrait addictionI = new ActorTrait();
            addictionI.id = "Poker";
            addictionI.path_icon = "ui/Icons/actor_traits/gambling/Poker";
            addictionI.group_id = "gambling";
            addictionI.type = TraitType.Negative;
            addictionI.can_be_given = true;
            addictionI.can_be_removed = true;
            addictionI.same_trait_mod = 5;
            addictionI.rate_acquire_grow_up = 2;
            addictionI.needs_to_be_explored = false;
            addictionI.rate_birth = 4;
            AssetManager.traits.add(addictionI);
            LM.AddToCurrentLocale("trait_Poker", "Poker");
            LM.AddToCurrentLocale("trait_Poker_info", "All In!");

            ActorTrait addictionII = new ActorTrait();
            addictionII.id = "BlackJack";
            addictionII.path_icon = "ui/Icons/actor_traits/gambling/blackjack";
            addictionII.group_id = "gambling";
            addictionII.type = TraitType.Negative;
            addictionII.can_be_given = true;
            addictionII.can_be_removed = true;
            addictionII.same_trait_mod = 5;
            addictionII.rate_acquire_grow_up = 2;
            addictionII.needs_to_be_explored = false;
            addictionII.rate_birth = 4;
            AssetManager.traits.add(addictionII);
            LM.AddToCurrentLocale("trait_BlackJack", "BlackJack");
            LM.AddToCurrentLocale("trait_BlackJack_info", "Hit Me!");

            ActorTrait addictionIII = new ActorTrait();
            addictionIII.id = "Slots";
            addictionIII.path_icon = "ui/Icons/actor_traits/gambling/slots";
            addictionIII.group_id = "gambling";
            addictionIII.type = TraitType.Negative;
            addictionIII.can_be_given = true;
            addictionIII.can_be_removed = true;
            addictionIII.same_trait_mod = 5;
            addictionIII.rate_acquire_grow_up = 2;
            addictionIII.needs_to_be_explored = false;
            addictionIII.rate_birth = 4;
            AssetManager.traits.add(addictionIII);
            LM.AddToCurrentLocale("trait_Slots", "Slots");
            LM.AddToCurrentLocale("trait_Slots_info", "Easily the WORST casino game");

            ActorTrait addictionIV = new ActorTrait();
            addictionIV.id = "Roulette";
            addictionIV.path_icon = "ui/Icons/actor_traits/gambling/Roulette";
            addictionIV.group_id = "gambling";
            addictionIV.type = TraitType.Negative;
            addictionIV.can_be_given = true;
            addictionIV.can_be_removed = true;
            addictionIV.same_trait_mod = 5;
            addictionIV.rate_acquire_grow_up = 2;
            addictionIV.needs_to_be_explored = false;
            addictionIV.rate_birth = 4;
            AssetManager.traits.add(addictionIV);
            LM.AddToCurrentLocale("trait_Roulette", "Roulette");
            LM.AddToCurrentLocale("trait_Roulette_info", "Easily the BEST casino game");

            ActorTrait addictionV = new ActorTrait();
            addictionV.id = "Sports";
            addictionV.path_icon = "ui/Icons/actor_traits/gambling/Sports";
            addictionV.group_id = "gambling";
            addictionV.type = TraitType.Negative;
            addictionV.can_be_given = true;
            addictionV.can_be_removed = true;
            addictionV.same_trait_mod = 5;
            addictionV.rate_acquire_grow_up = 2;
            addictionV.needs_to_be_explored = false;
            addictionV.rate_birth = 4;
            AssetManager.traits.add(addictionV);
            LM.AddToCurrentLocale("trait_Sports", "Sports Betting");
            LM.AddToCurrentLocale("trait_Sports_info", "Also better than slots");








        }





        //WORLD AGES

        public static void CreateWorldAgeAsset()
        {
            WorldAgeAsset sea = new WorldAgeAsset();
            {
                sea.id = "age_sea";
                sea.path_icon = "ui/Icons/ages/iconAgeSea";
                sea.rate = 5;
                sea.overlay_ash = false;
                sea.era_effect_overlay_alpha = 0.5f;

            }
            ;
            AssetManager.era_library.add(sea);
            LM.AddToCurrentLocale("age_sea_title", "Age of the Sea");

            WorldAgeAsset waste = new WorldAgeAsset();
            {
                waste.id = "age_waste";
                waste.path_icon = "ui/Icons/ages/iconAgeWaste";
                waste.rate = 5;
                waste.biomes = AssetLibrary<WorldAgeAsset>.h<string>(new string[]
            {

            });

            }
            ;
            AssetManager.era_library.add(waste);
            LM.AddToCurrentLocale("age_waste_title", "Age of Waste");

            WorldAgeAsset creator = new WorldAgeAsset();
            {
                creator.id = "age_creator";
                creator.path_icon = "ui/Icons/ages/iconAgeCreator";
                creator.rate = 5;

            }
            ;
            AssetManager.era_library.add(creator);
            LM.AddToCurrentLocale("age_creator_title", "Age of the Creator");

            WorldAgeAsset addict = new WorldAgeAsset();
            {
                addict.id = "age_addiction";
                addict.path_icon = "ui/Icons/ages/iconAgeAddiction";
                addict.rate = 5;

            }
            ;
            AssetManager.era_library.add(addict);
            LM.AddToCurrentLocale("age_addiction_title", "Age of Addiction");

            WorldAgeAsset corruption = new WorldAgeAsset();
            {
                corruption.id = "age_destruction";
                corruption.path_icon = "ui/Icons/ages/iconAgeDestruction";
                corruption.rate = 5;
            }

            AssetManager.era_library.add(corruption);
            LM.AddToCurrentLocale("age_destruction_title", "Age of Destruction");



        }



        //Status Effects

        public static void CreateNewStatus()
        {
            StatusAsset Addiction = new StatusAsset();

            {
                Addiction.id = "Addicted";
                Addiction.duration = 100f;
                Addiction.path_icon = "ui/Icons/status_effects/Weed";
                AssetManager.status.add(Addiction);
                LM.AddToCurrentLocale("Addicted", "Addicted");
                LM.AddToCurrentLocale("Addicted_info", "This mf high as shit");
            }

        }











        //TRAIT GROUPS

        public static void CreateTraitGroups()
        {
            ActorTraitGroupAsset group = new ActorTraitGroupAsset();

            {
                group.id = "addictions";

                group.name = "Addictions";

                group.color = "red";

            }
            ;
            AssetManager.trait_groups.add(group);
            LM.AddToCurrentLocale("addictions", "Substance Addictions");

            ActorTraitGroupAsset nature = new ActorTraitGroupAsset();

            {
                nature.id = "lifebound";

                nature.name = "Lifebound";

                nature.color = "#075A14";

            }
            ;
            AssetManager.trait_groups.add(nature);
            LM.AddToCurrentLocale("lifebound", "Lifebound");

            ActorTraitGroupAsset random = new ActorTraitGroupAsset();

            {
                random.id = "random";

                random.name = "random";

                random.color = "#C26753";

            }
            ;
            AssetManager.trait_groups.add(random);
            LM.AddToCurrentLocale("random", "Random");

            ActorTraitGroupAsset disorders = new ActorTraitGroupAsset();

            {
                disorders.id = "disorders";

                disorders.name = "disorders";

                disorders.color = "#25368A";

            }
            ;
            AssetManager.trait_groups.add(disorders);
            LM.AddToCurrentLocale("disorders", "Disorders");

            ActorTraitGroupAsset sickness = new ActorTraitGroupAsset();

            {
                sickness.id = "sickness";

                sickness.name = "sickness";

                sickness.color = "4E8446";
            }
            ;
            AssetManager.trait_groups.add(sickness);
            LM.AddToCurrentLocale("sickness", "Illnesses");

            ActorTraitGroupAsset gambling = new ActorTraitGroupAsset(); //make poker chip sprites for every addiction

            {
                gambling.id = "gambling";

                gambling.name = "gambling";

                gambling.color = "#3D7DB5";
            }
            ;
            AssetManager.trait_groups.add(gambling);
            LM.AddToCurrentLocale("gambling", "Gambling Addictions");




        }





        public static bool InstantDeath(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (Randy.randomChance(10.0f))
            {
                pTarget.a.getHit(10000000f, true, AttackType.Other, null, true, false);
            }
            return true;
        }








        public static void Init()
        {
            makeNewTrait();

            CreateTraitGroups();

            CreateWorldAgeAsset();

            CreateNewStatus();










        }


    }
}




