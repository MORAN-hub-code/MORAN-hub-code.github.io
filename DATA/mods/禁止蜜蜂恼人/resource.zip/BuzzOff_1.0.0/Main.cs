﻿using HarmonyLib;
using NeoModLoader.api;

namespace BuzzOff {
    public class Main : BasicMod<Main> {
        protected override void OnModLoad() {
            Harmony.CreateAndPatchAll(GetType());
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(BuildingManager), nameof(BuildingManager.addBuilding), typeof(BuildingAsset),
            typeof(WorldTile), typeof(bool), typeof(bool), typeof(BuildPlacingType))]
        private static bool addBuilding_Prefix(BuildingAsset pAsset) {
            return !Instance.GetConfig()["General"]["Disable Hive Spawning"].BoolVal || pAsset.id != "beehive";
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(ActionLibrary), nameof(ActionLibrary.tryToEvolveUnitViaMonolith))]
        [HarmonyPatch(typeof(ActionLibrary), nameof(ActionLibrary.tryToEvolveUnitViaAscension))]
        private static bool tryToEvolveUnit_ViaAscension_Prefix(Actor pActor) {
            return !Instance.GetConfig()["General"]["Disable Bee Evolution"].BoolVal || pActor.asset.id != "bee";
        }
    }
}