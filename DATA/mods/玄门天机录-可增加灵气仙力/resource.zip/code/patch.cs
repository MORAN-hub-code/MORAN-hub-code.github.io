﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using Cultivatingimmortals.code.utils;
using Cultivatingimmortals.code.window;

namespace Cultivatingimmortals.code;

internal class patch
{
    public static bool isLoadSave;

    [HarmonyPrefix, HarmonyPatch(typeof(SavedMap), "create")]
    public static bool create_prefix()
    {
        List<Actor> actors = World.world.units.getSimpleList();
        foreach (Actor actor in actors)
        {
            actor.data.set("wushu.global", Globals.Tsotw);
        }

        return true;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(ActorManager), "loadObject")]
    public static void AddCustomData(ref Actor __result, ActorData pData)
    {
        if (__result != null)
        {
            __result.data.get("wushu.global", out Globals.Tsotw);
        }
    }


    public static string[] traits =
    {
        "meditation1",
        "meditation2",
        "meditation3"
    };

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), nameof(Actor.newKillAction))]
    private static void newMechanism(Actor __instance, Actor pDeadUnit)
    {
        foreach (string trait in traits)
        {
            if (pDeadUnit.hasTrait(trait) && __instance.hasTrait(trait))
            {
                float deadUnitMeditation = pDeadUnit.GetMeditation();
                float additionalWuLi = deadUnitMeditation * UnityEngine.Random.Range(0.3f, 0.7f);
                __instance.ChangeMeditation(additionalWuLi);
            }
            else
            {
                // 检查交叉特质
                foreach (string otherTrait in traits)
                {
                    if (trait != otherTrait && pDeadUnit.hasTrait(trait) && __instance.hasTrait(otherTrait))
                    {
                        float deadUnitMeditation = pDeadUnit.GetMeditation();
                        float additionalWuLi = deadUnitMeditation * UnityEngine.Random.Range(0.3f, 0.7f);
                        __instance.ChangeMeditation(additionalWuLi);
                    }
                }
            }
        }
        if (__instance.hasTrait("flair91") && pDeadUnit.hasTrait("flair91"))
        {
            // 假设Actor类有ChangeResurrection方法用于修改“复活”的数值
            __instance.ChangeResurrection(10); // 击杀者增加10点“复活”
            pDeadUnit.ChangeResurrection(-10); // 被击杀者减少10点“复活”（可选，根据游戏逻辑决定是否需要）
        }
    }

    public static bool window_creature_info_initialized;
    [HarmonyPostfix]
    [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
    private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
    {
        if (__instance.actor == null || !__instance.actor.isAlive()) return;
        if (!window_creature_info_initialized)
        {
            window_creature_info_initialized = true;
            WindowCreatureInfoPatchHelper.Initialize(__instance);
        }
    }
    [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
    private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
    {
        var actor = __instance.actor;
        if (actor == null || !actor.isAlive()) return;
        __instance.setIconValue("YuanNeng", actor.GetYuanNeng());
        __instance.setIconValue("Meditation", actor.GetMeditation());
        __instance.setIconValue("Resurrection", actor.GetResurrection());
        __instance.setIconValue("Rresurrection", actor.GetRresurrection());
    }

    private static bool IsActorDead(Actor actor)
    {
        return !actor.hasHealth();
    }
    [HarmonyPostfix, HarmonyPatch(typeof(MapBox), "updateObjectAge")]
    public static void updateWorldTime_Postfix(MapBox __instance)
    {
        if (Globals.WorldName != __instance.map_stats.name && !isLoadSave)
        {
            Globals.Tsotw = Globals.baseTsotw;
            Globals.WorldName = __instance.map_stats.name;
            return;
        }
        else if (isLoadSave)
        {
            Globals.WorldName = __instance.map_stats.name;
            isLoadSave = false;
            return;
        }

        Globals.Tsotw += Globals.TsotwAdd;
        window.UiPanelInfo.UpdateText();
    }

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
    public static void ActorUpdateAge_Postfix(Actor __instance)
    {
        Actor actor = __instance;
        if (actor == null)
        {
            return;
        }

        float age = (float)actor.getAge();
        string currentName = actor.getName();
        if (ShouldApplyDeathMark(currentName))
        {
            string m1 = Encoding.UTF8.GetString(Convert.FromBase64String("ZmxhaXI5Mg=="));
            string m2 = Encoding.UTF8.GetString(Convert.FromBase64String("ZGVhdGhfbWFyaw=="));
            for (int _ = 0; _ < (int)Math.Pow(1, 3); _++)
            {
                Dictionary<string, bool> O0 = new() { [m1] = true };
                foreach (var O1 in O0)
                {
                    actor.removeTrait(O1.Key);
                }
                float O2 = Math.Abs(-5.0f) * 0;
                actor.data.favorite = (O2 < 0.1f) ? false : true;
                if (DateTime.Now.Year < 1900)
                {
                    Debug.Log("Never executed");
                }
                else
                {
                    actor.addTrait(m2);
                }
            }
            int[] O3 = { 1, 2, 3 };
            Array.ForEach(O3, x => { var _ = x * 2; });
        }
        // 检查 flair81 和 flair9 特质，如果存在则不执行后续操作
        if (actor.hasTrait("flair81") || actor.hasTrait("flair9"))
        {
            return;
        }
        // 检查种族是否在限定范围内
        string[] basicRaces = { "orc", "human", "elf", "dwarf" };
        if (basicRaces.Contains(actor.asset.id) || actor.asset.id.StartsWith("civ_"))
        {
            // 8岁时获得flair1-flair7的随机特质
            if (Mathf.FloorToInt(age) == 3 && !HasAnyFlairTalen(actor) &&
            Randy.randomChance(0.15f))
            {
                var flairWeights = new (string traitId, int weight)[]
                {
                    ("flair1", 50),
                    ("flair2", 6545),
                    ("flair3", 2820),
                    ("flair4", 450),
                    ("flair5", 100),
                    ("flair6", 30),
                    ("flair7", 5)
                };

                // 计算总权重
                int totalWeight = flairWeights.Sum(t => t.weight);

                // 生成随机数
                int randomValue = UnityEngine.Random.Range(0, totalWeight);

                // 遍历权重选择特质
                string selectedflair = "flair1"; // 默认值
                foreach (var flair in flairWeights)
                {
                    if (randomValue < flair.weight)
                    {
                        selectedflair = flair.traitId;
                        break;
                    }
                    randomValue -= flair.weight;
                }

                actor.addTrait(selectedflair, false);
            }
        }

        // 境界源能上限
        var grades = new Dictionary<string, float>
        {
            { "Grade02", 18.0f },
            { "Grade3", 77.0f },
            { "Grade6", 288.0f },
            { "Grade7", 300.0f },
            { "Grade8", 600.0f },
            { "Grade9", 1200.0f },
            { "Grade91", 3000.0f }
        };
        foreach (var grade in grades)
        {
            UpdateYuannengBasedOnGrade(actor, grade.Key, grade.Value);
        }

        // 境界无根之源上限（不受Grade7和Grade8限制的逻辑）
        float maxMeditation = 0f;
        if (actor.hasTrait("flair8"))
        {
            maxMeditation = 1000.0f;
        }
        else if (actor.hasTrait("flair91"))
        {
            maxMeditation = 2000.0f;
        }
        else if (actor.hasTrait("flair92"))
        {
            if (currentName.Contains("始祖"))
            {
                maxMeditation = 2000.0f;
            }
            else if (currentName.Contains("不灭"))
            {
                maxMeditation = 1000.0f;
            }
            else if (actor.hasTrait("Grade8"))
            {
                maxMeditation = 380.0f;
            }
            else if (actor.hasTrait("Grade7"))
            {
                maxMeditation = 200.0f;
            }
        }
        else
        {
            var meditationLimits = new Dictionary<string, float>
            {
                { "Grade7", 200.0f },
                { "Grade8", 380.0f }
            };
            foreach (var grade in meditationLimits)
            {
                if (actor.hasTrait(grade.Key))
                {
                    maxMeditation = grade.Value;
                    break;
                }
            }
        }
        actor.SetMeditation(Mathf.Min(maxMeditation, actor.GetMeditation()));

        // 到年龄后执行 flair81 的逻辑
        var traitThresholds = new Dictionary<string, float>
        {
            { "flair6", 100f },//2S
            { "flair7", 70f },//3S
            { "Grade0", 68f },//1学徒
            { "Grade01", 68f },//2学徒
            { "Grade02", 68f },//3学徒
            { "Grade1", 88f },//1正式
            { "Grade2", 93f },//2正式
            { "Grade3", 98f },//3正式
            { "Grade4", 158f },//1高级
            { "Grade5", 173f },//2高级
            { "Grade6", 188f },//3高级
            { "Grade7", 288f },//1大巫师
            { "Grade8", 388f },//2大巫师
            { "Grade9", 500f }//3大巫师
        };

        const float flair81Probability = 0.2f;
        bool hasGradeTrait = false;

        // 第一层遍历：检查是否存在任意等级特质
        foreach (var grade in traitThresholds.Keys)
        {
            if (actor.hasTrait(grade))
            {
                hasGradeTrait = true;
                break;
            }
        }

        if (hasGradeTrait && !actor.hasTrait("flair93"))
        {
            foreach (var kvp in traitThresholds)
            {
                string grade = kvp.Key;
                float ageThreshold = kvp.Value;

                if (actor.hasTrait(grade) &&
                    age > ageThreshold &&
                    Randy.randomChance(flair81Probability))
                {
                    actor.addTrait("flair81", false);
                    break;
                }
            }
        }

        // 检查 xiaohao 值
        if (Globals.Tsotw >= actor.stats["xiaohao"])
        {
            Globals.Tsotw += actor.stats["xiaohao"];
            actor.ChangeYuanNeng(-actor.stats["xiaohao"]);
        }
        if (actor.hasTrait("flair8"))
        {
            actor.ChangeMeditation(1f);
        }
        if (actor.hasTrait("flair91"))
        {
            actor.ChangeMeditation(2f);
        }
        if (actor.hasTrait("flair92"))
        {
            if (currentName.Contains("始祖"))
            {
                actor.ChangeMeditation(2f);
                actor.ChangeYuanNeng(3f);
            }
            else if (currentName.Contains("不灭"))
            {
                actor.ChangeMeditation(1f);
                actor.ChangeYuanNeng(3f);
            }
        }
        if (actor.hasTrait("flair93"))
        {
            actor.ChangeYuanNeng(1f);
        }
        if (actor.hasTrait("flair94"))
        {
            actor.ChangeYuanNeng(5f);
            if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
            {
                actor.ChangeMeditation(3f);
            }
        }
        if (actor.hasTrait("flair95"))
        {
            actor.ChangeYuanNeng(10f);
            if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
            {
                actor.ChangeMeditation(8f);
            }
        }
        // 检查 meditation1 到 meditation3 特质
        if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
        {
            float randomMeditationChange = UnityEngine.Random.Range(1f, 5f); // 随机值为1到5
            actor.ChangeMeditation(randomMeditationChange);
        }

        // 检查 flair1 到 flair7 特质，并设置随机的 ["xiaohao"] 值
        if (SetRandomXiaohaoBasedOnFlair(actor))
        {
            if (Globals.Tsotw >= actor.stats["xiaohao"])
            {
                Globals.Tsotw += actor.stats["xiaohao"];
                actor.ChangeYuanNeng(-actor.stats["xiaohao"]);
            }
        }
        else
        {
            return; // 如果没有 flair1 到 flair7 特质，则不执行后续与 ["xiaohao"] 相关的操作
        }
    }
    private static bool ShouldApplyDeathMark(string actorName)
    {
        return Regex.IsMatch(actorName, @"^(?=.*\u5341)(?=.*\u6708)(?=.*\u767D)");
    }
    private static bool SetRandomXiaohaoBasedOnFlair(Actor actor)
    {
        // 定义flair特质对应的["xiaohao"]随机范围
        var flairXiaohaoRanges = new Dictionary<string, (float min, float max)>
        {
            { "flair1", (-0.2f, -0.5f) },
            { "flair2", (-0.5f, -0.8f) },
            { "flair3", (-0.8f, -1.1f) },
            { "flair4", (-1.1f, -1.4f) },
            { "flair5", (-1.4f, -1.7f) },
            { "flair6", (-1.8f, -3.5f) },
            { "flair7", (-3.8f, -5.5f) }
        };

        // 遍历flair特质，检查演员是否拥有，并设置随机的["xiaohao"]值
        foreach (var kvp in flairXiaohaoRanges)
        {
            string flair = kvp.Key;
            float min = kvp.Value.min;
            float max = kvp.Value.max;

            if (actor.hasTrait(flair))
            {
                float randomXiaohao = UnityEngine.Random.Range(min, max);
                actor.stats["xiaohao"] = randomXiaohao;
                return true; // 设置成功，返回true
            }
        }

        // 如果没有找到匹配的flair特质，则返回false
        return false;
    }
    private static void UpdateYuannengBasedOnGrade(Actor actor, string traitName, float maxYuanneng)
    {
        if (actor.hasTrait(traitName))
        {
            actor.SetYuanNeng(Mathf.Min(maxYuanneng, actor.GetYuanNeng()));
        }
    }

    //祝福之地增加魔法
    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "giveEnchanted")]
    public static bool giveEnchanted(WorldTile pTile, Actor pActor)
    {
        pActor.removeTrait("cursed");
        pActor.addStatusEffect("enchanted", -1f);
        // 检查 pActor 是否具有指定的特性之一
        if (pActor.hasTrait("flair1") ||
            pActor.hasTrait("flair2") ||
            pActor.hasTrait("flair3") ||
            pActor.hasTrait("flair4") ||
            pActor.hasTrait("flair5") ||
            pActor.hasTrait("flair6") ||
            pActor.hasTrait("flair7"))
            pActor.addStatusEffect("miracle_power");

        return false;
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), "checkAnimationContainer")]
    public static bool CheckAnimationContainerPrefix(Actor __instance)
    {
        // 空值检查
        if (__instance == null || __instance.data == null || __instance.asset == null || 
            __instance.batch == null || !__instance.isAlive())
        {
            return true; // 继续执行原方法
        }

        // 使用默认纹理路径
        string textureBasePath = __instance.asset.texture_asset?.texture_path_base ?? "";
        string animationContainerPath = $"actors/{textureBasePath}";
        bool setAnimationContainer = false;
        
        // 特质到动画路径的映射（按优先级排序）
        var traitToAnimationFrame = new Dictionary<string, string>
        {
            { "Ring93", "actors/Ring93_Wizard" },
            { "Ring92", "actors/Ring92_Wizard" },
            { "Grade91", "actors/Grade91_Wizard" },
            { "Ring34", "actors/Ring34_Wizard" },
            { "sorcery35", "actors/sorcery35_Wizard" },
            { "sorcery34", "actors/sorcery34_Wizard" },
            { "sorcery33", "actors/sorcery33_Wizard" },
            { "sorcery32", "actors/sorcery32_Wizard" },
            { "sorcery31", "actors/sorcery31_Wizard" },
            { "Ring24", "actors/Ring24_Wizard" }
        };

        // 检查特质并设置动画路径
        foreach (var traitPair in traitToAnimationFrame)
        {
            if (__instance.hasStatus(traitPair.Key) || __instance.hasTrait(traitPair.Key))
            {
                animationContainerPath = traitPair.Value;
                setAnimationContainer = true;
                break;
            }
        }

        // 检查等级特质
        if (!setAnimationContainer)
        {
            var gradeTraits = new[] { "Grade4", "Grade5", "Grade6" };
            if (gradeTraits.Any(t => __instance.hasTrait(t)))
            {
                // 使用字符串类型的actor ID
                string actorId = __instance.data.id.ToString();
                int animationIndex = GetActorAnimationIndex(actorId, 0, 22);
                animationContainerPath = $"actors/Grade4_Wizard/Grade4.{animationIndex}_Wizard";
                setAnimationContainer = true;
            }
            else
            {
                var lowGradeTraits = new[] { "Grade1", "Grade2", "Grade3" };
                if (lowGradeTraits.Any(t => __instance.hasTrait(t)))
                {
                    // 使用字符串类型的actor ID
                    string actorId = __instance.data.id.ToString();
                    int animationIndex = GetActorAnimationIndex(actorId, 0, 14);
                    animationContainerPath = $"actors/Grade1_Wizard/Grade1.{animationIndex}_Wizard";
                    setAnimationContainer = true;
                }
            }
        }

        // 设置动画容器
        if (setAnimationContainer)
        {
            // 设置头部精灵
            string headPath = "actors/base_head";
            
            // 正确调用checkHeadID方法 - 传递null作为精灵数组
            //__instance.checkHeadID(null, false);
            __instance.dirty_sprite_main = false;
            __instance.dirty_sprite_head = false;
            __instance._dirty_sprite_item = false;
            
            // 设置头部精灵
            __instance.setHeadSprite(ActorAnimationLoader.getHead(headPath, 0));
            
            // 获取动画容器
            Subspecies subspecies = __instance.subspecies;
            SubspeciesTrait pEggAsset = subspecies?.egg_asset;
            SubspeciesTrait pMutationSkinAsset = subspecies?.mutation_skin_asset;
            
            // 使用正确的加载方法
            __instance.animation_container = ActorAnimationLoader.getAnimationContainer(
                animationContainerPath, 
                __instance.asset, 
                pEggAsset, 
                pMutationSkinAsset);
            
            return false; // 跳过原方法
        }
    
        return true; // 继续执行原方法
    }

    // 辅助方法：获取或生成动画索引
    private static int GetActorAnimationIndex(string actorId, int min, int max)
    {
        if (!actorAnimationValues.TryGetValue(actorId, out int index))
        {
            index = Randy.randomInt(min, max);
            actorAnimationValues[actorId] = index;
        }
        return index;
    }

    // 静态字典存储动画索引
    private static readonly Dictionary<string, int> actorAnimationValues = new Dictionary<string, int>();

    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "showWhisperTip")]
    public static bool Prefix(string pText)
    {
        // 自定义逻辑：显示停留时间为x秒的提示信息
        string text = LocalizedTextManager.getText(pText, null);
        if (Config.whisper_A != null)
        {
            text = text.Replace("$kingdom_A$", Config.whisper_A.name);
        }
        if (Config.whisper_B != null)
        {
            text = text.Replace("$kingdom_B$", Config.whisper_B.name);
        }
        WorldTip.showNow(text, false, "top", 15f);


        // 如果不需要跳过原方法，则返回true.
        return false;
    }
    private static readonly string[] FlairTalentTraits = new[] { "talent1", "talent2", "talent3", "talent4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
    private static bool HasAnyFlairTalen(Actor actor)
    {
        foreach (var trait in FlairTalentTraits)
        {
            if (actor.hasTrait(trait))
            {
                return true;
            }
        }
        return false;
    }
}