﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;

namespace Cultivatingimmortals.code
{
    internal class traits
    {

        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
        public static void AddActorTrait(string id, string pathIcon)
        {
            ActorTrait flair = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "interesting3",
                needs_to_be_explored = false
            };
            flair.action_special_effect += traitAction.Grade0_effectAction; //学徒•初识的升级条件
            AssetManager.traits.add(flair);
        }
        public static bool ClanFlairMethod(BaseSimObject pTarget, WorldTile pTile = null, int minFlairLevel = 1)
        {
            if (!(pTarget is Actor actor)) return false;
            
            float age = actor.getAge();
            if (Mathf.FloorToInt(age) != 8) return true;
            
            // 定义需要检查的特质列表
            string[] traitsToCheck = 
            {
                "talent1", "talent2", "talent3", "talent4",
                "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7"
            };
            
            // 检查是否已拥有任何相关特质
            if (traitsToCheck.Any(actor.hasTrait)) return true;
            
            // 根据 minFlairLevel 设置不同的天赋范围
            var flairWeights = new List<(string traitId, int weight)>();
            if (minFlairLevel <= 1) flairWeights.Add(("flair1", 5442));
            if (minFlairLevel <= 2) flairWeights.Add(("flair2", 2750));
            if (minFlairLevel <= 3) flairWeights.Add(("flair3", 1200));
            if (minFlairLevel <= 4) flairWeights.Add(("flair4", 500));
            if (minFlairLevel <= 5) flairWeights.Add(("flair5", 100));
            if (minFlairLevel <= 6) flairWeights.Add(("flair6", 6));
            if (minFlairLevel <= 7) flairWeights.Add(("flair7", 2));
            
            if (flairWeights.Count == 0) return true;
            
            // 计算总权重并随机选择
            int totalWeight = flairWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);
            
            foreach (var flair in flairWeights)
            {
                if (randomValue < flair.weight)
                {
                    actor.addTrait(flair.traitId, false);
                    break;
                }
                randomValue -= flair.weight;
            }
            
            return true;
        }
        public static void Init()
        {
            //特质id↓ //贴图路径↓ //诞生率↓ //排斥的特质↓
            AddActorTrait("flair1", "trait/flair1");//D天赋
            AddActorTrait("flair2", "trait/flair2");//C天赋
            AddActorTrait("flair3", "trait/flair3");//B天赋
            AddActorTrait("flair4", "trait/flair4");//A天赋
            AddActorTrait("flair5", "trait/flair5");//S天赋

            // 定义氏族特质配置（包含图标路径）
            var clanTraits = new List<(string id, string iconPath, int minLevel)>
            {
                ("ClanFlair1", "trait/flair1", 1),
                ("ClanFlair2", "trait/flair2", 2),
                ("ClanFlair3", "trait/flair3", 3),
                ("ClanFlair4", "trait/flair4", 4),
                ("ClanFlair5", "trait/flair5", 5)
            };

            // 批量创建并添加氏族特质
            foreach (var (id, iconPath, minLevel) in clanTraits)
            {
                ClanTrait clanTrait = CclanTrait(
                    id: id,
                    path_icon: iconPath, // 使用指定的图标路径
                    group_id: "spirit"
                );
                
                clanTrait.action_special_effect += (target, tile) => 
                    ClanFlairMethod(target, tile, minLevel);
                
                AssetManager.clan_traits.add(clanTrait);
            }

            ActorTrait flair6 = CreateTrait("flair6", "trait/flair6", "interesting3");
            SafeSetStat(flair6.base_stats, strings.S.multiplier_lifespan, -0.4f);
            SafeSetStat(flair6.base_stats, strings.S.intelligence, 15f);
            SafeSetStat(flair6.base_stats, strings.S.damage, 60f);
            SafeSetStat(flair6.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(flair6.base_stats, strings.S.health, 300f);
            SafeSetStat(flair6.base_stats, strings.S.armor, 10f);
            SafeSetStat(flair6.base_stats, strings.S.targets, 2f);
            SafeSetStat(flair6.base_stats, strings.S.knockback, 1f);
            SafeSetStat(flair6.base_stats, "Resist", 1f);
            flair6.action_special_effect += traitAction.SS_Collection;//收藏
            flair6.action_special_effect += traitAction.Grade0_effectAction;//学徒•初识的升级条件
            flair6.action_special_effect += (WorldAction)Delegate.Combine(flair6.action_special_effect,
new WorldAction(traitAction.flair6_Regen)); //再生效果
            AssetManager.traits.add(flair6);

            ActorTrait flair7 = CreateTrait("flair7", "trait/flair7", "interesting3");
            SafeSetStat(flair7.base_stats, strings.S.multiplier_lifespan, -0.6f);
            SafeSetStat(flair7.base_stats, strings.S.intelligence, 30f);
            SafeSetStat(flair7.base_stats, strings.S.damage, 100f);
            SafeSetStat(flair7.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(flair7.base_stats, strings.S.health, 500f);
            SafeSetStat(flair7.base_stats, strings.S.armor, 20f);
            SafeSetStat(flair7.base_stats, strings.S.targets, 3f);
            SafeSetStat(flair7.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(flair7.base_stats, "Resist", 1f);
            flair7.action_special_effect += traitAction.SSS_Collection;//收藏
            flair7.action_special_effect += traitAction.Grade0_effectAction;//学徒•初识的升级条件
            flair7.action_special_effect += (WorldAction)Delegate.Combine(flair7.action_special_effect,
new WorldAction(traitAction.flair7_Regen)); //再生效果
            AssetManager.traits.add(flair7);

            ActorTrait meditation1 = CreateTrait("meditation1", "trait/meditation1", "interesting3");
            AssetManager.traits.add(meditation1);

            ActorTrait meditation2 = CreateTrait("meditation2", "trait/meditation2", "interesting3");
            AssetManager.traits.add(meditation2);

            ActorTrait meditation3 = CreateTrait("meditation3", "trait/meditation3", "interesting3");
            AssetManager.traits.add(meditation3);

            ActorTrait flair8 = CreateTrait("flair8", "trait/flair8", "interesting3");//大巫师•灵魂
            SafeSetStat(flair8.base_stats, strings.S.intelligence, 30f);
            SafeSetStat(flair8.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(flair8.base_stats, strings.S.damage, 60f);
            SafeSetStat(flair8.base_stats, strings.S.armor, 20f);
            SafeSetStat(flair8.base_stats, strings.S.health, 300f);
            SafeSetStat(flair8.base_stats, strings.S.multiplier_offspring, -100f);
            SafeSetStat(flair8.base_stats, "xiaohao", -2f);//每年-2点世界源力+2点源能
            SafeSetStat(flair8.base_stats, strings.S.stamina, 100f);//耐力+100
            flair8.action_death = traitAction.flair8_death;//重生效果+随机BAS
            flair8.action_special_effect += (WorldAction)Delegate.Combine(flair8.action_special_effect,
new WorldAction(traitAction.flair8_Regen)); //再生效果
            AssetManager.traits.add(flair8);

            ActorTrait flair81 = CreateTrait("flair81", "trait/flair81", "interesting3");//禁巫
            AssetManager.traits.add(flair81);

            ActorTrait flair9 = CreateTrait("flair9", "trait/flair9", "interesting3");//禁巫之族
            AssetManager.traits.add(flair9);

            ActorTrait flair91 = CreateTrait("flair91", "trait/flair91", "interesting3");
            SafeSetStat(flair91.base_stats, strings.S.intelligence, 88f);
            SafeSetStat(flair91.base_stats, strings.S.lifespan, 10f);//寿命+10
            SafeSetStat(flair91.base_stats, strings.S.damage, 120f);
            SafeSetStat(flair91.base_stats, strings.S.armor, 30f);
            SafeSetStat(flair91.base_stats, strings.S.health, 900f);
            SafeSetStat(flair91.base_stats, strings.S.multiplier_offspring, -10f);
            SafeSetStat(flair91.base_stats, "xiaohao", -2f);//每年-2点世界源力+2点源能
            SafeSetStat(flair91.base_stats, strings.S.stamina, 200f);//耐力+200
            flair91.action_death = traitAction.flair91_death;//重生效果
            flair91.action_special_effect += (WorldAction)Delegate.Combine(flair91.action_special_effect,
new WorldAction(traitAction.flair91_Regen)); //再生效果
            AssetManager.traits.add(flair91);

            ActorTrait flair92 = CreateTrait("flair92", "trait/flair92", "interesting3");
            SafeSetStat(flair92.base_stats, strings.S.multiplier_offspring, -10f);
            flair92.action_death = traitAction.flair92_death; //重生效果
            flair92.action_special_effect += (WorldAction)Delegate.Combine(flair92.action_special_effect,
new WorldAction(traitAction.flair92_Regen)); //再生效果
            AssetManager.traits.add(flair92);

            ActorTrait flair93 = CreateTrait("flair93", "trait/flair93", "interesting3");
            AssetManager.traits.add(flair93);

            ActorTrait flair94 = CreateTrait("flair94", "trait/flair94", "interesting3");
            AssetManager.traits.add(flair94);

            ActorTrait flair95 = CreateTrait("flair95", "trait/flair95", "interesting3");
            AssetManager.traits.add(flair95);

            ActorTrait Bestow1 = CreateTrait("Bestow1", "trait/Bestow1", "interesting5");
            Bestow1.action_special_effect += (WorldAction)Delegate.Combine(Bestow1.action_special_effect,
                    new WorldAction(traitAction.Bestow1_Regen));
            AssetManager.traits.add(Bestow1);

            ActorTrait Bestow2 = CreateTrait("Bestow2", "trait/Bestow2", "interesting5");
            Bestow2.action_special_effect += (WorldAction)Delegate.Combine(Bestow2.action_special_effect,
                    new WorldAction(traitAction.Bestow2_Regen));
            AssetManager.traits.add(Bestow2);

            ActorTrait Bestow3 = CreateTrait("Bestow3", "trait/Bestow3", "interesting5");
            Bestow3.action_special_effect += (WorldAction)Delegate.Combine(Bestow3.action_special_effect,
                    new WorldAction(traitAction.Bestow3_Regen));
            AssetManager.traits.add(Bestow3);

            ActorTrait Bestow4 = CreateTrait("Bestow4", "trait/Bestow4", "interesting5");
            Bestow4.action_special_effect += (WorldAction)Delegate.Combine(Bestow4.action_special_effect,
                    new WorldAction(traitAction.Bestow4_Regen));
            AssetManager.traits.add(Bestow4);

            ActorTrait Bestow5 = CreateTrait("Bestow5", "trait/Bestow5", "interesting5");
            Bestow5.action_special_effect += (WorldAction)Delegate.Combine(Bestow5.action_special_effect,
                    new WorldAction(traitAction.Bestow5_Regen));
            AssetManager.traits.add(Bestow5);

            ActorTrait Bestow6 = CreateTrait("Bestow6", "trait/Bestow6", "interesting5");
            Bestow6.action_special_effect += (WorldAction)Delegate.Combine(Bestow6.action_special_effect,
                    new WorldAction(traitAction.Bestow6_Regen));
            AssetManager.traits.add(Bestow6);

            ActorTrait Bestow7 = CreateTrait("Bestow7", "trait/Bestow7", "interesting5");
            Bestow7.action_special_effect += (WorldAction)Delegate.Combine(Bestow7.action_special_effect,
                    new WorldAction(traitAction.Bestow7_Regen));
            AssetManager.traits.add(Bestow7);

            ActorTrait Bestow8 = CreateTrait("Bestow8", "trait/Bestow8", "interesting5");
            Bestow8.action_special_effect += (WorldAction)Delegate.Combine(Bestow8.action_special_effect,
                    new WorldAction(traitAction.Bestow8_Regen));
            AssetManager.traits.add(Bestow8);

            ActorTrait Bestow9 = CreateTrait("Bestow9", "trait/Bestow9", "interesting5");
            Bestow9.action_special_effect += (WorldAction)Delegate.Combine(Bestow9.action_special_effect,
                    new WorldAction(traitAction.Bestow9_Regen));
            AssetManager.traits.add(Bestow9);

            ActorTrait Bestow91 = CreateTrait("Bestow91", "trait/Bestow91", "interesting5");
            Bestow91.action_special_effect += (WorldAction)Delegate.Combine(Bestow91.action_special_effect,
                    new WorldAction(traitAction.Bestow91_Regen));
            AssetManager.traits.add(Bestow91);

            ActorTrait Bestow92 = CreateTrait("Bestow92", "trait/Bestow92", "interesting5");
            Bestow92.action_special_effect += (WorldAction)Delegate.Combine(Bestow92.action_special_effect,
                    new WorldAction(traitAction.Bestow92_Regen));
            AssetManager.traits.add(Bestow92);

            ActorTrait Bestow93 = CreateTrait("Bestow93", "trait/Bestow93", "interesting5");
            Bestow93.action_special_effect += (WorldAction)Delegate.Combine(Bestow93.action_special_effect,
                    new WorldAction(traitAction.Bestow93_Regen));
            AssetManager.traits.add(Bestow93);

            ActorTrait Bestow94 = CreateTrait("Bestow94", "trait/Bestow94", "interesting5");
            Bestow94.action_special_effect += (WorldAction)Delegate.Combine(Bestow94.action_special_effect,
                    new WorldAction(traitAction.Bestow94_Regen));
            AssetManager.traits.add(Bestow94);

            ActorTrait Bestow95 = CreateTrait("Bestow95", "trait/Bestow95", "interesting5");
            Bestow95.action_special_effect += (WorldAction)Delegate.Combine(Bestow95.action_special_effect,
                    new WorldAction(traitAction.Bestow95_Regen));
            AssetManager.traits.add(Bestow95);

            ActorTrait Bestow96 = CreateTrait("Bestow96", "trait/Bestow96", "interesting5");
            Bestow96.action_special_effect += (WorldAction)Delegate.Combine(Bestow96.action_special_effect,
                    new WorldAction(traitAction.Bestow96_Regen));
            AssetManager.traits.add(Bestow96);

            ActorTrait Bestow97 = CreateTrait("Bestow97", "trait/Bestow97", "interesting5");
            Bestow97.action_special_effect += (WorldAction)Delegate.Combine(Bestow97.action_special_effect,
                    new WorldAction(traitAction.Bestow97_Regen));
            AssetManager.traits.add(Bestow97);

            ActorTrait Bestow98 = CreateTrait("Bestow98", "trait/Bestow98", "interesting5");
            Bestow98.action_special_effect += (WorldAction)Delegate.Combine(Bestow98.action_special_effect,
                    new WorldAction(traitAction.Bestow98_Regen));
            AssetManager.traits.add(Bestow98);

            ActorTrait Bestow99 = CreateTrait("Bestow99", "trait/Bestow99", "interesting5");
            Bestow99.action_special_effect += (WorldAction)Delegate.Combine(Bestow99.action_special_effect,
                    new WorldAction(traitAction.Bestow99_Regen));
            AssetManager.traits.add(Bestow99);

            //巫师境界↓
            ActorTrait Grade0 = CreateTrait("Grade0", "trait/Grade0", "interesting2");//学徒•初识
            SafeSetStat(Grade0.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(Grade0.base_stats, strings.S.damage, 40f);
            SafeSetStat(Grade0.base_stats, strings.S.health, 100f);
            SafeSetStat(Grade0.base_stats, strings.S.intelligence, 1f);
            SafeSetStat(Grade0.base_stats, "Dodge", 10f);
            Grade0.action_special_effect += traitAction.Grade01_effectAction; //学徒•掌控的升级条件
            AssetManager.traits.add(Grade0);

            ActorTrait Grade01 = CreateTrait("Grade01", "trait/Grade01", "interesting2");//学徒•掌控
            SafeSetStat(Grade01.base_stats, strings.S.lifespan, 20f);//寿命+20
            SafeSetStat(Grade01.base_stats, strings.S.damage, 70f);//伤害+40
            SafeSetStat(Grade01.base_stats, strings.S.health, 400f);//生命+400
            SafeSetStat(Grade01.base_stats, strings.S.intelligence, 2f);//智力+2
            SafeSetStat(Grade01.base_stats, strings.S.targets, 1f);
            SafeSetStat(Grade01.base_stats, strings.S.accuracy, 2f); //准确度+2
            SafeSetStat(Grade01.base_stats, "Dodge", 20f);
            Grade01.action_special_effect += traitAction.Grade02_effectAction; //学徒•精通的升级条件
            Grade01.action_special_effect += (WorldAction)Delegate.Combine(Grade01.action_special_effect,
new WorldAction(traitAction.Grade01_Regen)); //学徒•掌控的再生效果
            AssetManager.traits.add(Grade01);

            ActorTrait Grade02 = CreateTrait("Grade02", "trait/Grade02", "interesting2"); // 学徒•精通
            SafeSetStat(Grade02.base_stats, strings.S.lifespan, 30f); // 寿命+30
            SafeSetStat(Grade02.base_stats, strings.S.damage, 140f);
            SafeSetStat(Grade02.base_stats, strings.S.health, 800f);
            SafeSetStat(Grade02.base_stats, strings.S.speed, 5f);
            SafeSetStat(Grade02.base_stats, strings.S.intelligence, 3f);
            SafeSetStat(Grade02.base_stats, strings.S.range, 1f); // 射程+1
            SafeSetStat(Grade02.base_stats, strings.S.area_of_effect, 1f);
            SafeSetStat(Grade02.base_stats, strings.S.targets, 2f);
            SafeSetStat(Grade02.base_stats, strings.S.accuracy, 5f); // 准确度+5
            SafeSetStat(Grade02.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(Grade02.base_stats, "Resist", 1f);
            SafeSetStat(Grade02.base_stats, "Dodge", 30f);
            Grade02.action_special_effect += traitAction.Grade1_effectAction; // 正式巫师•塑造的升级条件
            Grade02.action_special_effect += (WorldAction)Delegate.Combine(Grade02.action_special_effect,
                new WorldAction(traitAction.Grade02_Regen)); // 学徒•精通的再生效果
            AssetManager.traits.add(Grade02);

            ActorTrait Grade1 = CreateTrait("Grade1", "trait/Grade1", "interesting2"); // 正式巫师•塑造
            SafeSetStat(Grade1.base_stats, strings.S.lifespan, 70f); // 寿命+20
            SafeSetStat(Grade1.base_stats, strings.S.damage, 300f);
            SafeSetStat(Grade1.base_stats, strings.S.health, 3000f);
            SafeSetStat(Grade1.base_stats, strings.S.armor, 20f);
            SafeSetStat(Grade1.base_stats, strings.S.speed, 10f);
            SafeSetStat(Grade1.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(Grade1.base_stats, strings.S.range, 3f); // 射程+3
            SafeSetStat(Grade1.base_stats, strings.S.area_of_effect, 4f); // 近战范围+3
            SafeSetStat(Grade1.base_stats, strings.S.targets, 3f); // 可攻击目标+1
            SafeSetStat(Grade1.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(Grade1.base_stats, "Resist", 1f);
            SafeSetStat(Grade1.base_stats, "Dodge", 50f);
            SafeSetStat(Grade1.base_stats, "Accuracy", 20f);
            SafeSetStat(Grade1.base_stats, strings.S.mass_2, 10f);//体重+10
            SafeSetStat(Grade1.base_stats, strings.S.accuracy, 10f); // 准确度+10
            SafeSetStat(Grade1.base_stats, strings.S.stamina, 30f); //耐力+30
            Grade1.action_special_effect += traitAction.Grade2_effectAction; // 升正式巫师•元素的条件
            Grade1.action_special_effect += (WorldAction)Delegate.Combine(Grade1.action_special_effect,
                new WorldAction(traitAction.Grade1_Regen)); // 正式巫师•塑造的再生效果
            AssetManager.traits.add(Grade1);

            ActorTrait Grade2 = new ActorTrait();
            Grade2.id = "Grade2"; //正式巫师•元素
            Grade2.path_icon = "trait/Grade2";
            Grade2.needs_to_be_explored = false;
            Grade2.group_id = "interesting2";
            Grade2.base_stats = new BaseStats();
            Grade2.base_stats[strings.S.lifespan] = 80f;
            Grade2.base_stats[strings.S.damage] = 600f;
            Grade2.base_stats[strings.S.health] = 6000f;
            Grade2.base_stats[strings.S.armor] = 20f;
            Grade2.base_stats[strings.S.speed] = 12f;
            Grade2.base_stats[strings.S.intelligence] = 20f;
            Grade2.base_stats[strings.S.range] = 3f;
            Grade2.base_stats[strings.S.area_of_effect] = 5f;
            Grade2.base_stats[strings.S.targets] = 3f;
            Grade2.base_stats[strings.S.knockback] = 1f;//击退+1
            Grade2.base_stats["Resist"] = 1f;
            Grade2.base_stats["Dodge"] = 60f;
            Grade2.base_stats["Accuracy"] = 30f;
            Grade2.base_stats[strings.S.mass_2] = 15f;//体重+15
            Grade2.base_stats[strings.S.accuracy] = 15f; //准确度+15
            Grade2.base_stats[strings.S.stamina] = 40f; //耐力+40
            Grade2.action_special_effect += traitAction.Grade3_effectAction; //正式巫师•冥想的条件
            Grade2.action_special_effect += (WorldAction)Delegate.Combine(Grade2.action_special_effect,
                new WorldAction(traitAction.Grade2_Regen)); //正式巫师•元素的再生效果
            AssetManager.traits.add(Grade2);

            ActorTrait Grade3 = new ActorTrait();
            Grade3.id = "Grade3"; //正式巫师•冥想
            Grade3.path_icon = "trait/Grade3";
            Grade3.needs_to_be_explored = false;
            Grade3.group_id = "interesting2";
            Grade3.base_stats = new BaseStats();
            Grade3.base_stats[strings.S.lifespan] = 90f;
            Grade3.base_stats[strings.S.damage] = 1200f;
            Grade3.base_stats[strings.S.health] = 12000f;
            Grade3.base_stats[strings.S.armor] = 30f;
            Grade3.base_stats[strings.S.speed] = 15f;
            Grade3.base_stats[strings.S.intelligence] = 30f;
            Grade3.base_stats[strings.S.range] = 5f;
            Grade3.base_stats[strings.S.area_of_effect] = 6f;
            Grade3.base_stats[strings.S.targets] = 3f;
            Grade3.base_stats[strings.S.knockback] = 1f;//击退+1
            Grade3.base_stats["Resist"] = 1f;
            Grade3.base_stats[strings.S.warfare] = 5f;
            Grade3.base_stats[strings.S.stewardship] = 10f;
            Grade3.base_stats["Dodge"] = 70f;
            Grade3.base_stats["Accuracy"] = 40f;
            Grade3.base_stats[strings.S.mass_2] = 20f;//体重+20
            Grade3.base_stats[strings.S.accuracy] = 20f; //准确度+20
            Grade3.base_stats[strings.S.stamina] = 50f; //耐力+50
            Grade3.action_special_effect += traitAction.Grade4_effectAction; //升高级巫师•黎明的条件
            Grade3.action_special_effect += (WorldAction)Delegate.Combine(Grade3.action_special_effect,
                new WorldAction(traitAction.Grade3_Regen)); //正式巫师•冥想的再生效果
            AssetManager.traits.add(Grade3);

            ActorTrait Grade4 = new ActorTrait();
            Grade4.id = "Grade4"; //高级巫师•黎明
            Grade4.path_icon = "trait/Grade4";
            Grade4.needs_to_be_explored = false;
            Grade4.group_id = "interesting2";
            Grade4.base_stats = new BaseStats();
            Grade4.base_stats[strings.S.lifespan] = 140f;
            Grade4.base_stats[strings.S.damage] = 3000f;
            Grade4.base_stats[strings.S.health] = 30000f;
            Grade4.base_stats[strings.S.armor] = 40f;
            Grade4.base_stats[strings.S.speed] = 20f;
            Grade4.base_stats[strings.S.intelligence] = 60f;
            Grade4.base_stats[strings.S.range] = 8f;
            Grade4.base_stats[strings.S.area_of_effect] = 10f;
            Grade4.base_stats[strings.S.targets] = 5f;
            Grade4.base_stats[strings.S.knockback] = 2f;
            Grade4.base_stats["Resist"] = 2f;
            Grade4.base_stats[strings.S.warfare] = 6f;
            Grade4.base_stats[strings.S.stewardship] = 12f;
            Grade4.base_stats["xiaohao"] = -1f;//每年-1点世界源力+1点源能
            Grade4.base_stats["Dodge"] = 100f;
            Grade4.base_stats["Accuracy"] = 70f;
            Grade4.base_stats[strings.S.mass_2] = 30f;//体重+30
            Grade4.base_stats[strings.S.accuracy] = 30f; //准确度+30
            Grade4.base_stats[strings.S.stamina] = 80f; //耐力+80
            Grade4.action_special_effect += traitAction.Grade5_effectAction; //升高级巫师•扩展的条件
            Grade4.action_special_effect += (WorldAction)Delegate.Combine(Grade4.action_special_effect,
                new WorldAction(traitAction.Grade4_Regen)); //高级巫师•黎明的再生效果
            AssetManager.traits.add(Grade4);


            ActorTrait Grade5 = new ActorTrait();
            Grade5.id = "Grade5"; //高级巫师•扩展
            Grade5.path_icon = "trait/Grade5";
            Grade5.needs_to_be_explored = false;
            Grade5.group_id = "interesting2";
            Grade5.base_stats = new BaseStats();
            Grade5.base_stats[strings.S.lifespan] = 155f;
            Grade5.base_stats[strings.S.damage] = 6000f;
            Grade5.base_stats[strings.S.health] = 60000f;
            Grade5.base_stats[strings.S.armor] = 40f;
            Grade5.base_stats[strings.S.speed] = 25f;
            Grade5.base_stats[strings.S.intelligence] = 100f;
            Grade5.base_stats[strings.S.range] = 8f;
            Grade5.base_stats[strings.S.area_of_effect] = 10f;
            Grade5.base_stats[strings.S.targets] = 5f;
            Grade5.base_stats[strings.S.knockback] = 2f;//击退+1
            Grade5.base_stats["Resist"] = 2f;
            Grade5.base_stats[strings.S.warfare] = 7f;
            Grade5.base_stats[strings.S.stewardship] = 16f;
            Grade5.base_stats["xiaohao"] = -1f;
            Grade5.base_stats["Dodge"] = 110f;
            Grade5.base_stats["Accuracy"] = 80f;
            Grade5.base_stats[strings.S.mass_2] = 35f;//体重+35
            Grade5.base_stats[strings.S.accuracy] = 35f; //准确度+35
            Grade5.base_stats[strings.S.stamina] = 100f; //耐力+100
            Grade5.action_special_effect += traitAction.Grade6_effectAction; //升高级巫师•巅峰的条件
            Grade5.action_special_effect += (WorldAction)Delegate.Combine(Grade5.action_special_effect,
                new WorldAction(traitAction.Grade5_Regen)); //高级巫师•扩展的再生效果
            AssetManager.traits.add(Grade5);


            ActorTrait Grade6 = new ActorTrait();
            Grade6.id = "Grade6"; //高级巫师•巅峰
            Grade6.path_icon = "trait/Grade6";
            Grade6.needs_to_be_explored = false;
            Grade6.group_id = "interesting2";
            Grade6.base_stats = new BaseStats();
            Grade6.base_stats[strings.S.lifespan] = 170f;
            Grade6.base_stats[strings.S.damage] = 12000f;
            Grade6.base_stats[strings.S.health] = 120000f;
            Grade6.base_stats[strings.S.armor] = 50f;
            Grade6.base_stats[strings.S.speed] = 30f;
            Grade6.base_stats[strings.S.intelligence] = 150f;
            Grade6.base_stats[strings.S.attack_speed] = 1f;
            Grade6.base_stats[strings.S.range] = 8f;
            Grade6.base_stats[strings.S.area_of_effect] = 10f;
            Grade6.base_stats[strings.S.targets] = 6f;
            Grade6.base_stats[strings.S.knockback] = 2f;
            Grade6.base_stats["Resist"] = 2f;
            Grade6.base_stats[strings.S.warfare] = 9f;
            Grade6.base_stats[strings.S.stewardship] = 18f;
            Grade6.base_stats["xiaohao"] = -1f;
            Grade6.base_stats["Dodge"] = 120f;
            Grade6.base_stats["Accuracy"] = 90f;
            Grade6.base_stats[strings.S.mass_2] = 40f;//体重+40
            Grade6.base_stats[strings.S.accuracy] = 40f; //准确度+40
            Grade6.base_stats[strings.S.stamina] = 120f; //耐力+120
            Grade6.action_special_effect += traitAction.Grade7_effectAction; //升大巫师•铭刻的条件
            Grade6.action_special_effect += (WorldAction)Delegate.Combine(Grade6.action_special_effect,
                new WorldAction(traitAction.Grade6_Regen)); //高级巫师•巅峰三阶的再生效果
            AssetManager.traits.add(Grade6);


            ActorTrait Grade7 = new ActorTrait();
            Grade7.id = "Grade7"; //大巫师•铭刻
            Grade7.path_icon = "trait/Grade7";
            Grade7.needs_to_be_explored = false;
            Grade7.group_id = "interesting2";
            Grade7.base_stats = new BaseStats();
            Grade7.base_stats[strings.S.lifespan] = 240f;
            Grade7.base_stats[strings.S.damage] = 30000f;
            Grade7.base_stats[strings.S.health] = 300000f;
            Grade7.base_stats[strings.S.intelligence] = 250f;
            Grade7.base_stats[strings.S.critical_chance] = 0.10f;
            Grade7.base_stats[strings.S.armor] = 80f;
            Grade7.base_stats[strings.S.speed] = 50f;
            Grade7.base_stats[strings.S.multiplier_damage] = 0.20f;
            Grade7.base_stats[strings.S.multiplier_health] = 0.20f;
            Grade7.base_stats[strings.S.range] = 10f;
            Grade7.base_stats[strings.S.area_of_effect] = 15f;
            Grade7.base_stats[strings.S.targets] = 10f;
            Grade7.base_stats[strings.S.knockback] = 3f;
            Grade7.base_stats["Resist"] = 3f;
            Grade7.base_stats[strings.S.warfare] = 10f;
            Grade7.base_stats[strings.S.stewardship] = 20f;
            Grade7.base_stats["xiaohao"] = -20f;
            Grade7.base_stats["Dodge"] = 150f;
            Grade7.base_stats["Accuracy"] = 120f;
            Grade7.base_stats[strings.S.mass_2] = 50f;//体重+50
            Grade7.base_stats[strings.S.accuracy] = 50f; //准确度+50
            Grade7.base_stats[strings.S.stamina] = 240f; //耐力+240
            Grade7.action_special_effect += traitAction.Grade8_effectAction; //大巫师•巅峰的条件
            Grade7.action_special_effect += (WorldAction)Delegate.Combine(Grade7.action_special_effect,
                new WorldAction(traitAction.Grade7_Regen)); //大巫师•铭刻的再生效果
            AssetManager.traits.add(Grade7);


            ActorTrait Grade8 = new ActorTrait();
            Grade8.id = "Grade8"; //大巫师•巅峰
            Grade8.path_icon = "trait/Grade8";
            Grade8.needs_to_be_explored = false;
            Grade8.group_id = "interesting2";
            Grade8.base_stats = new BaseStats();
            Grade8.base_stats[strings.S.lifespan] = 340f;
            Grade8.base_stats[strings.S.damage] = 70000f;
            Grade8.base_stats[strings.S.health] = 700000f;
            Grade8.base_stats[strings.S.intelligence] = 350f;
            Grade8.base_stats[strings.S.critical_chance] = 0.10f;
            Grade8.base_stats[strings.S.armor] = 100f;
            Grade8.base_stats[strings.S.speed] = 60f;
            Grade8.base_stats[strings.S.multiplier_damage] = 0.20f;
            Grade8.base_stats[strings.S.multiplier_health] = 0.20f;
            Grade8.base_stats[strings.S.range] = 10f;
            Grade8.base_stats[strings.S.area_of_effect] = 20f;
            Grade8.base_stats[strings.S.targets] = 15f;
            Grade8.base_stats[strings.S.knockback] = 3f;
            Grade8.base_stats["Resist"] = 3f;
            Grade8.base_stats[strings.S.warfare] = 12f;
            Grade8.base_stats[strings.S.stewardship] = 23f;
            Grade8.base_stats["xiaohao"] = -40f;
            Grade8.base_stats["Dodge"] = 180f;
            Grade8.base_stats["Accuracy"] = 150f;
            Grade8.base_stats[strings.S.mass_2] = 60f;//体重+60
            Grade8.base_stats[strings.S.accuracy] = 60f; //准确度+60
            Grade8.base_stats[strings.S.stamina] = 360f; //耐力+360
            Grade8.action_special_effect += traitAction.Grade9_effectAction; //升大巫师•不死的条件
            Grade8.action_special_effect += (WorldAction)Delegate.Combine(Grade8.action_special_effect,
                new WorldAction(traitAction.Grade8_Regen)); //大巫师•巅峰的再生效果
            AssetManager.traits.add(Grade8);


            ActorTrait Grade9 = new ActorTrait();
            Grade9.id = "Grade9"; //大巫师•不死
            Grade9.path_icon = "trait/Grade9";
            Grade9.needs_to_be_explored = false;
            Grade9.group_id = "interesting2";
            Grade9.base_stats = new BaseStats();
            Grade9.base_stats[strings.S.lifespan] = 500f;
            Grade9.base_stats[strings.S.damage] = 300000f;
            Grade9.base_stats[strings.S.health] = 3000000f;
            Grade9.base_stats[strings.S.armor] = 200f;
            Grade9.base_stats[strings.S.speed] = 80f;
            Grade9.base_stats[strings.S.intelligence] = 550f;
            Grade9.base_stats[strings.S.critical_chance] = 0.10f;
            Grade9.base_stats[strings.S.multiplier_damage] = 0.20f;
            Grade9.base_stats[strings.S.multiplier_health] = 0.20f;
            Grade9.base_stats[strings.S.range] = 10f;
            Grade9.base_stats[strings.S.area_of_effect] = 25f;
            Grade9.base_stats[strings.S.targets] = 20f;
            Grade9.base_stats[strings.S.knockback] = 5f;
            Grade9.base_stats["Resist"] = 5f;
            Grade9.base_stats[strings.S.warfare] = 12f;
            Grade9.base_stats[strings.S.stewardship] = 25f;
            Grade9.base_stats["xiaohao"] = -60f;
            Grade9.base_stats["Dodge"] = 210f;
            Grade9.base_stats["Accuracy"] = 180f;
            Grade9.base_stats[strings.S.mass_2] = 80f;//体重+80
            Grade9.base_stats[strings.S.accuracy] = 80f; //准确度+80
            Grade9.base_stats[strings.S.stamina] = 500f; //耐力+500
            Grade9.action_special_effect += traitAction.Grade91_effectAction; //升始祖的条件
            Grade9.action_special_effect += (WorldAction)Delegate.Combine(Grade9.action_special_effect,
                new WorldAction(traitAction.Grade9_Regen)); //大巫师•不死的再生效果
            AssetManager.traits.add(Grade9);


            ActorTrait Grade91 = new ActorTrait();
            Grade91.id = "Grade91"; //始祖
            Grade91.path_icon = "trait/Grade10";
            Grade91.needs_to_be_explored = false;
            Grade91.group_id = "interesting2";
            Grade91.base_stats = new BaseStats();
            Grade91.base_stats[strings.S.scale] = -0.05f; //体型缩小5%
            Grade91.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            Grade91.base_stats[strings.S.damage] = 10000000f;//1000w伤害
            Grade91.base_stats[strings.S.health] = 100000000f;//1E血量
            Grade91.base_stats[strings.S.armor] = 300f;
            Grade91.base_stats[strings.S.speed] = 100f;
            Grade91.base_stats[strings.S.intelligence] = 999f;
            Grade91.base_stats[strings.S.critical_chance] = 0.30f;
            Grade91.base_stats[strings.S.multiplier_damage] = 0.30f;
            Grade91.base_stats[strings.S.multiplier_health] = 0.30f;
            Grade91.base_stats[strings.S.range] = 20f;//攻击范围
            Grade91.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            Grade91.base_stats[strings.S.targets] = 30f;//可攻击的目标
            Grade91.base_stats[strings.S.knockback] = 10f;//击退
            Grade91.base_stats["Resist"] = 10f;
            Grade91.base_stats[strings.S.warfare] = 15f;//指挥
            Grade91.base_stats[strings.S.stewardship] = 30f;//组织
            Grade91.base_stats["xiaohao"] = -500f;
            Grade91.base_stats["Dodge"] = 500f;
            Grade91.base_stats["Accuracy"] = 470f;
            Grade91.base_stats[strings.S.mass_2] = 300f;//体重+100
            Grade91.base_stats[strings.S.accuracy] = 300f;//准确度
            Grade91.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            Grade91.action_death = traitAction.Grade91_death;
            Grade91.action_attack_target += new AttackAction((traitAction.attack_Grade91));
            Grade91.action_special_effect += new WorldAction((traitAction.hunger_Grade91));//不会饥饿
            Grade91.action_get_hit += new GetHitAction(traitAction.Grade91_Attack);
            Grade91.action_special_effect += (WorldAction)Delegate.Combine(Grade91.action_special_effect,
                new WorldAction(traitAction.Grade91_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(Grade91);


            ActorTrait sorcery01 = new ActorTrait();
            sorcery01.id = "sorcery01"; //零环•轻身术
            sorcery01.path_icon = "trait/sorcery01";
            sorcery01.needs_to_be_explored = false;
            sorcery01.group_id = "interesting4";
            sorcery01.action_attack_target += new AttackAction((traitAction.attack_sorcery01));
            AssetManager.traits.add(sorcery01);

            ActorTrait sorcery02 = new ActorTrait();
            sorcery02.id = "sorcery02"; //零环•烈焰之握
            sorcery02.path_icon = "trait/sorcery02";
            sorcery02.needs_to_be_explored = false;
            sorcery02.group_id = "interesting4";
            sorcery02.action_attack_target += new AttackAction((traitAction.attack_sorcery02));
            AssetManager.traits.add(sorcery02);

            ActorTrait sorcery03 = new ActorTrait();
            sorcery03.id = "sorcery03"; //零环•水幻迷障
            sorcery03.path_icon = "trait/sorcery03";
            sorcery03.needs_to_be_explored = false;
            sorcery03.group_id = "interesting4";
            sorcery03.action_attack_target += new AttackAction((traitAction.attack_sorcery03));
            AssetManager.traits.add(sorcery03);

            ActorTrait sorcery04 = new ActorTrait();
            sorcery04.id = "sorcery04"; //零环•生命祈愈
            sorcery04.path_icon = "trait/sorcery04";
            sorcery04.needs_to_be_explored = false;
            sorcery04.group_id = "interesting4";
            sorcery04.base_stats = new BaseStats();
            sorcery04.base_stats[strings.S.health] = 100f;
            sorcery04.action_special_effect += (WorldAction)Delegate.Combine(sorcery04.action_special_effect,
                new WorldAction(traitAction.sorcery04_Regen)); //再生效果
            AssetManager.traits.add(sorcery04);

            ActorTrait sorcery05 = new ActorTrait();
            sorcery05.id = "sorcery05"; //零环•大地壁垒
            sorcery05.path_icon = "trait/sorcery05";
            sorcery05.needs_to_be_explored = false;
            sorcery05.group_id = "interesting4";
            sorcery05.action_attack_target += new AttackAction((traitAction.attack_sorcery05));
            AssetManager.traits.add(sorcery05);

            ActorTrait sorcery06 = new ActorTrait();
            sorcery06.id = "sorcery06"; //零环•蔓藤囚牢
            sorcery06.path_icon = "trait/sorcery06";
            sorcery06.needs_to_be_explored = false;
            sorcery06.group_id = "interesting4";
            sorcery06.action_attack_target += new AttackAction((traitAction.attack_sorcery06));
            AssetManager.traits.add(sorcery06);

            ActorTrait sorcery07 = new ActorTrait();
            sorcery07.id = "sorcery07"; //零环•鹰隼凝视
            sorcery07.path_icon = "trait/sorcery07";
            sorcery07.needs_to_be_explored = false;
            sorcery07.group_id = "interesting4";
            sorcery07.action_attack_target += new AttackAction((traitAction.attack_sorcery07));
            AssetManager.traits.add(sorcery07);

            ActorTrait sorcery11 = new ActorTrait();
            sorcery11.id = "sorcery11"; //一环•肌肉松弛术
            sorcery11.path_icon = "trait/sorcery11";
            sorcery11.needs_to_be_explored = false;
            sorcery11.group_id = "interesting4";
            sorcery11.action_attack_target += new AttackAction((traitAction.attack_sorcery11));
            AssetManager.traits.add(sorcery11);

            ActorTrait sorcery12 = new ActorTrait();
            sorcery12.id = "sorcery12"; //一环•缠绕之网
            sorcery12.path_icon = "trait/sorcery12";
            sorcery12.needs_to_be_explored = false;
            sorcery12.group_id = "interesting4";
            sorcery12.action_attack_target += new AttackAction((traitAction.attack_sorcery12));
            AssetManager.traits.add(sorcery12);

            ActorTrait sorcery13 = new ActorTrait();
            sorcery13.id = "sorcery13"; //一环•土之坚甲
            sorcery13.path_icon = "trait/sorcery13";
            sorcery13.needs_to_be_explored = false;
            sorcery13.group_id = "interesting4";
            sorcery13.action_attack_target += new AttackAction((traitAction.attack_sorcery13));
            AssetManager.traits.add(sorcery13);

            ActorTrait sorcery14 = new ActorTrait();
            sorcery14.id = "sorcery14"; //一环•复苏之流
            sorcery14.path_icon = "trait/sorcery14";
            sorcery14.needs_to_be_explored = false;
            sorcery14.group_id = "interesting4";
            sorcery14.base_stats = new BaseStats();
            sorcery14.base_stats[strings.S.health] = 250f;
            sorcery14.action_special_effect += (WorldAction)Delegate.Combine(sorcery14.action_special_effect,
                new WorldAction(traitAction.sorcery14_Regen)); //再生效果
            AssetManager.traits.add(sorcery14);

            ActorTrait sorcery15 = new ActorTrait();
            sorcery15.id = "sorcery15"; //一环•风行术
            sorcery15.path_icon = "trait/sorcery15";
            sorcery15.needs_to_be_explored = false;
            sorcery15.group_id = "interesting4";
            sorcery15.action_attack_target += new AttackAction((traitAction.attack_sorcery15));
            AssetManager.traits.add(sorcery15);

            ActorTrait sorcery16 = new ActorTrait();
            sorcery16.id = "sorcery16"; //一环•水雾术
            sorcery16.path_icon = "trait/sorcery16";
            sorcery16.needs_to_be_explored = false;
            sorcery16.group_id = "interesting4";
            sorcery16.action_attack_target += new AttackAction((traitAction.attack_sorcery16));
            AssetManager.traits.add(sorcery16);

            ActorTrait sorcery17 = new ActorTrait();
            sorcery17.id = "sorcery17"; //一环•气机牵引
            sorcery17.path_icon = "trait/sorcery17";
            sorcery17.needs_to_be_explored = false;
            sorcery17.group_id = "interesting4";
            sorcery17.action_attack_target += new AttackAction((traitAction.attack_sorcery17));
            AssetManager.traits.add(sorcery17);

            ActorTrait sorcery18 = new ActorTrait();
            sorcery18.id = "sorcery18"; //一环•破甲附魔
            sorcery18.path_icon = "trait/sorcery18";
            sorcery18.needs_to_be_explored = false;
            sorcery18.group_id = "interesting4";
            sorcery18.action_attack_target += new AttackAction((traitAction.attack_sorcery18));
            AssetManager.traits.add(sorcery18);

            ActorTrait sorcery22 = new ActorTrait();
            sorcery22.id = "sorcery22"; //二环•星之致幻
            sorcery22.path_icon = "trait/sorcery22";
            sorcery22.needs_to_be_explored = false;
            sorcery22.group_id = "interesting4";
            sorcery22.action_attack_target += new AttackAction((traitAction.attack_sorcery22));
            AssetManager.traits.add(sorcery22);

            ActorTrait sorcery23 = new ActorTrait();
            sorcery23.id = "sorcery23"; //二环•血液汲取
            sorcery23.path_icon = "trait/sorcery23";
            sorcery23.needs_to_be_explored = false;
            sorcery23.group_id = "interesting4";
            sorcery23.action_attack_target += new AttackAction((traitAction.attack_sorcery23));
            AssetManager.traits.add(sorcery23);

            ActorTrait sorcery24 = new ActorTrait();
            sorcery24.id = "sorcery24"; //二环•岩石护壁
            sorcery24.path_icon = "trait/sorcery24";
            sorcery24.needs_to_be_explored = false;
            sorcery24.group_id = "interesting4";
            sorcery24.action_attack_target += new AttackAction((traitAction.attack_sorcery24));
            AssetManager.traits.add(sorcery24);

            ActorTrait sorcery25 = new ActorTrait();
            sorcery25.id = "sorcery25"; //二环•生命涌泉
            sorcery25.path_icon = "trait/sorcery25";
            sorcery25.needs_to_be_explored = false;
            sorcery25.group_id = "interesting4";
            sorcery25.base_stats = new BaseStats();
            sorcery25.base_stats[strings.S.health] = 2000f;
            sorcery25.action_special_effect += (WorldAction)Delegate.Combine(sorcery25.action_special_effect,
                new WorldAction(traitAction.sorcery25_Regen)); //再生效果
            AssetManager.traits.add(sorcery25);

            ActorTrait sorcery26 = new ActorTrait();
            sorcery26.id = "sorcery26"; //二环•生命流逝
            sorcery26.path_icon = "trait/sorcery26";
            sorcery26.needs_to_be_explored = false;
            sorcery26.group_id = "interesting4";
            sorcery26.action_attack_target += new AttackAction((traitAction.attack_sorcery26));
            AssetManager.traits.add(sorcery26);

            ActorTrait sorcery27 = new ActorTrait
            {
                id = "sorcery27", //二环•因果印记
                path_icon = "trait/sorcery27",
                needs_to_be_explored = false,
                group_id = "interesting4"
            };
            sorcery27.action_attack_target += new AttackAction((traitAction.attack_sorcery27));
            AssetManager.traits.add(sorcery27);

            ActorTrait sorcery28 = new ActorTrait
            {
                id = "sorcery28", //二环•相位星痕步
                path_icon = "trait/sorcery28",
                needs_to_be_explored = false,
                group_id = "interesting4"
            };
            sorcery28.action_attack_target += new AttackAction((traitAction.attack_sorcery28));
            AssetManager.traits.add(sorcery28);

            ActorTrait sorcery29 = new ActorTrait
            {
                id = "sorcery29", //二环•贯穿之锋
                path_icon = "trait/sorcery29",
                needs_to_be_explored = false,
                group_id = "interesting4"
            };
            sorcery29.action_attack_target += new AttackAction((traitAction.attack_sorcery29));
            AssetManager.traits.add(sorcery29);

            ActorTrait sorcery31 = new ActorTrait
            {
                id = "sorcery31", //三环•斥力场
                path_icon = "trait/sorcery31",
                needs_to_be_explored = false,
                group_id = "interesting4",
                base_stats = new BaseStats
                {
                    [strings.S.health] = 250f,
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            sorcery31.action_attack_target += new AttackAction((traitAction.attack_sorcery31));
            AssetManager.traits.add(sorcery31);

            ActorTrait sorcery32 = new ActorTrait
            {
                id = "sorcery32", //三环•裂界爆炎
                path_icon = "trait/sorcery32",
                needs_to_be_explored = false,
                group_id = "interesting4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            sorcery32.action_attack_target += new AttackAction((traitAction.attack_sorcery32));
            AssetManager.traits.add(sorcery32);

            ActorTrait sorcery33 = new ActorTrait
            {
                id = "sorcery33", //三环•雷霆术
                path_icon = "trait/sorcery33",
                needs_to_be_explored = false,
                group_id = "interesting4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            sorcery33.action_attack_target += new AttackAction((traitAction.attack_sorcery33));
            AssetManager.traits.add(sorcery33);

            ActorTrait sorcery34 = new ActorTrait
            {
                id = "sorcery34", //三环•血眸通界·万象饲己之仪
                path_icon = "trait/sorcery34",
                needs_to_be_explored = false,
                group_id = "interesting4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f
                }
            };
            sorcery34.action_get_hit += new GetHitAction(traitAction.sorcery34_Attack);//狂暴状态方法
            AssetManager.traits.add(sorcery34);

            ActorTrait sorcery35 = new ActorTrait
            {
                id = "sorcery35", //三环•黯镰噬魂·万灵湮灭之仪
                path_icon = "trait/sorcery35",
                needs_to_be_explored = false,
                group_id = "interesting4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.03f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            AssetManager.traits.add(sorcery35);
        }
        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}