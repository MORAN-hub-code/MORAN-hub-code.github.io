﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace Warrior.code
{
    internal class traitAction
    {
        public static bool Knight1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.学徒骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Knight2", "Knight3", "Knight4", "Knight5", "Knight6" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Knight1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );

            return true;
        }

        public static bool Knight2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetKnight() <= 9.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.8;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight1",
                "Knight2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Knight22" }
            );

            return true;
        }

        public static bool Knight3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 8)
            {
                // 添加Knight1特质
                upTrait("特质", "Knight1", a, new string[] { "Knight2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 17.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Knight2",
                "Knight3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight22"
                },
                new string[] { "Knight3+", selectedTrait }
            );

            return true;
        }

        public static bool Knight4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.中级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 16)
            {
                upTrait("特质", "Knight2", a, new string[] { "Knight3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 31.99)
            {
                return false;
            }

            a.ChangeKnight(-3);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight3",
                "Knight4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight3+"
                },
                new string[] { "Knight4+" }
            );

            return true;
        }

        public static bool Knight5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.高骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 29)
            {
                upTrait("特质", "Knight3", a, new string[] { "Knight4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 52.99)
            {
                return false;
            }

            a.ChangeKnight(-4);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Knight4",
                "Knight5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight4+"
                },
                (selectedTrait != null) ? 
                new string[] { "Knight5+", selectedTrait } : 
                new string[] { "Knight5+" }
            );

            return true;
        }

        public static bool Knight6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 49)
            {
                upTrait("特质", "Knight4", a, new string[] { "Knight5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 67.99)
            {
                return false;
            }

            a.ChangeKnight(-5);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }

            string actorName = a.getName();
            bool hasTitle = _knightTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _knightTitles.Length);
                string selectedTitle = _knightTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Knight5",
                "Knight6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight5+"
                },
                (selectedTrait != null) ? 
                new string[] { "Knight6+", "freeze_proof", "fire_proof", selectedTrait } : 
                new string[] { "Knight6+", "freeze_proof", "fire_proof" }
            );

            return true;
        }

        public static bool Knight7_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 63)
            {
                upTrait("特质", "Knight5", a, new string[] { "Knight6" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            return true;
        }
        private static readonly string[] _knightTitles = { "「草鞋追风客」", "「疯狗刀」", "「笑面狐」", "「独眼判官」", "「醉罗汉」", "「独孤求败」", "「任我行」"
, "「铁掌水上漂」", "「星宿老怪」", "「剑宗遗老」", "「剑魔」", "「浪子剑客」", "「飞天狐狸」", "「铁尺量天」", "「毒舌书生」", "「无常簿主」", "「回风拂柳剑」", "「青竹蛇君」"
, "「铁面阎罗」", "「断尾蝎王」", "「折剑人」", "「血线牵魂针」", "「笑面尸匠」", "「剥皮罗汉」", "「竹叶青娘子」", "「哭坟人」", "「血衣侯」", "「玉笛公子」"
, "「青城鬼脸」", "「碧磷毒手」", "「寒江独钓」", "「断碑书生」", "「雁门孤狼」", "「金顶飞鹰」", "「玉笔判官」", "「千仞毒叟」", "「血弥陀」", "「银蛇郎君」"
, "「铁面丹心」", "「玄冰老怪」" , "「黑木无常」", "「峨眉断情」" , "「无鞘刀」", "「三更死」", "「白骨画眉」" , "「血玲珑」", "「无泪人」", "「黑雪」", "「残红泣」"
, "「孤灯灭」", "「寒鸦」", "「孤剑」", "「碎梦无痕」", "「枯骨留香」", "「孤星葬剑」", "「无间鬼手」", "「断鸿刀」", "「青冥客」", "「哭丧人」", "「无鞘剑」", "「凌空一羽」"
, "「八步赶蟾」", "「无影剑」", "「踏雪无痕」", "「天琊剑」", "「天罡刀」", "「飞虹腿」", "「无影腿」", "「惊鸿刀」", "「妙手空空」", "「夺命书生」"};

        //骑士的恢复生命值效果
        public static bool Knight1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
