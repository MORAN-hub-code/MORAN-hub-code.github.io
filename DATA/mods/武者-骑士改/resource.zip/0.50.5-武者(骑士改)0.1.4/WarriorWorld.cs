﻿using HarmonyLib;

using WarriorWorld.code;

using NeoModLoader.api;

namespace WarriorWorld
{
    internal class WarriorWorldClass : BasicMod<WarriorWorldClass>
    {
        public static string id = "shiyue.worldbox.mod.WarriorWorld";
        protected override void OnModLoad()
        {
            stats.Init();
            traitGroup.Init();
            traits.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }

    }

}
