﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace WarriorWorld.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;
        
        private static readonly HashSet<string> BasicRaces = new() { "orc", "human", "elf", "dwarf" };
        private static readonly HashSet<string> FlairTalentTraits = new() 
        { 
            "talent1", "talent2", "talent3", "talent4", 
            "flair1", "flair2", "flair3", "flair4", 
            "flair5", "flair6", "flair7" 
        };
        
        private const float TalentRandomChance = 0.3f;
        private const float Talent6Chance = 0.2f;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive()) return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }
        }
        [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
        private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
        {
            var actor = __instance.actor;
            if (actor == null || !actor.isAlive()) return;
            __instance.setIconValue("Knight", actor.GetKnight());
        }

        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_KnightPostfix(Actor __instance)
        {
            if (__instance == null) return;

            float age = (float)__instance.getAge();
            bool hasTalent5 = __instance.hasTrait("talent5");
            bool hasTalent6 = __instance.hasTrait("talent6");
            bool hasTalent7 = __instance.hasTrait("talent7");
            
            if (IsBasicRaceOrCiv(__instance.asset.id))
            {
                HandleBasicRaceTraits(__instance, age, hasTalent5, hasTalent6);
            }

            ApplyTraitEffects(__instance, hasTalent5, hasTalent6);
            
            ApplyKnightGrades(__instance);
        }
        
        private static bool IsBasicRaceOrCiv(string assetId)
        {
            return BasicRaces.Contains(assetId) || assetId.StartsWith("civ_");
        }

        private static void HandleBasicRaceTraits(Actor actor, float age, bool hasTalent5, bool hasTalent6)
        {
            if (Mathf.FloorToInt(age) == 9 && 
                !hasTalent5 && 
                !hasTalent6 && 
                !HasAnyFlairTalen(actor) && 
                Randy.randomChance(TalentRandomChance))
            {
                string selectedTalent = SelectRandomTalent();
                actor.addTrait(selectedTalent, false);
            }
        }

        private static string SelectRandomTalent()
        {
            var talentWeights = new (string traitId, int weight)[]
            {
                ("talent1", 604),
                ("talent2", 300),
                ("talent3", 90),
                ("talent4", 6)
            };

            int totalWeight = talentWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);

            foreach (var talent in talentWeights)
            {
                if (randomValue < talent.weight)
                {
                    return talent.traitId;
                }
                randomValue -= talent.weight;
            }

            return "talent1";
        }

        private static void ApplyTraitEffects(Actor actor, bool hasTalent5, bool hasTalent6)
        {
            var talentEffects = new Dictionary<string, (float min, float max)>
            {
                { "talent1", (0.5f, 1.5f) },
                { "talent2", (1.0f, 2.0f) },
                { "talent3", (1.5f, 2.5f) },
                { "talent4", (2.0f, 5.0f) },
                { "talent6", (-1.0f, -2.0f) },
                { "talent7", (1.0f, 1.0f) }
            };

            foreach (var effect in talentEffects)
            {
                string traitId = effect.Key;
                
                if ((hasTalent6 || hasTalent5) && 
                    (traitId == "talent1" || traitId == "talent2" || traitId == "talent3" || traitId == "talent4"))
                {
                    continue;
                }

                if (actor.hasTrait(traitId))
                {
                    (float min, float max) = effect.Value;
                    float knightChange = UnityEngine.Random.Range(min, max);
                    actor.ChangeKnight(knightChange);
                }
            }

            if (!actor.hasTrait("talent7"))
            {
                var knightThresholds = new Dictionary<string, float>
                {
                    { "Knight1", 40f },
                    { "Knight2", 50f },
                    { "Knight3", 50f },
                    { "Knight4", 65f },
                    { "Knight5", 70f },
                    { "Knight6", 100f }
                };

                foreach (var threshold in knightThresholds)
                {
                    if (actor.hasTrait(threshold.Key) &&
                        (float)actor.getAge() > threshold.Value &&
                        Randy.randomChance(Talent6Chance))
                    {
                        actor.addTrait("talent6", false);
                    }
                }
            }
        }

        private static void ApplyKnightGrades(Actor actor)
        {
            var knightGrades = new Dictionary<string, float>
            {
                { "Knight1", 10f },
                { "Knight2", 18f },
                { "Knight3", 32f },
                { "Knight4", 53f },
                { "Knight5", 68f },
                { "Knight6", 75f },
            };

            foreach (var grade in knightGrades)
            {
                if (actor.hasTrait(grade.Key))
                {
                    float currentKnight = actor.GetKnight();
                    actor.SetKnight(Mathf.Min(grade.Value, currentKnight));
                }
            }
        }

        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (string trait in FlairTalentTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}