using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using ReflectionUtility;
using NCMS;
using NCMS.Utils;

namespace Desadaptation
{
    [Serializable]
    public class DesadaptationTraits : MonoBehaviour
    {

        public static void Initialize()
        {
            AddDesadaptation();
            //AddLimits();
        }
        static SubspeciesTrait CreateHarmonyTrait(string id, string[] oppositeTraits, string path, float limit) 
        {
            var trait = new SubspeciesTrait
            {
                id = id,
                group_id = "harmony",
                rarity = Rarity.R0_Normal,
                in_mutation_pot_remove = false,
                in_mutation_pot_add = false,
                spawn_random_trait_allowed = false,
                priority = 100,
                path_icon = path,
             };
            trait.base_stats_meta = new BaseStats();
            trait.base_stats_meta["limit_population"] = limit;
            //LocalizedTextManager.add("subspecies_trait_"+trait.id, trait.id);
            foreach (string t in oppositeTraits)
                if (t != id)
                    trait.addOpposite(t);
            AssetManager.subspecies_traits.add(trait);        
            return trait;
        }
        private static void AddLimits()
        {
            string[] oppositeTraits = { "population_small", "population_moderate", "population_large",
                "population_expansive", "10_limit",
                "20_limit", "30_limit",
                "200_limit", "150_limit", "300_limit"};
            CreateHarmonyTrait("10_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 10f);
            CreateHarmonyTrait("20_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 20f);
            CreateHarmonyTrait("30_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 30f);
            CreateHarmonyTrait("200_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 200f);
            CreateHarmonyTrait("150_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 150f);
            CreateHarmonyTrait("300_limit", oppositeTraits, "ui/ws3icons/desadaptation_Green", 300f);
            
            foreach (string traitId in new[] { "population_small", "population_moderate", "population_large", "population_expansive" })
            {
                var trait = AssetManager.subspecies_traits.get(traitId);
                if (trait == null) continue;

                foreach (string t in oppositeTraits)
                    if (t != traitId)
                        trait.addOpposite(t);
            }
        }
        private static void AddDesadaptation()
        {
            SubspeciesTrait desadaptation_crystal = new SubspeciesTrait();
            desadaptation_crystal.id = "desadaptation_crystal";
            desadaptation_crystal.group_id = "adaptations";
            desadaptation_crystal.path_icon = "ui/Ws3icons/desadaptation_crystal";
            desadaptation_crystal.remove_for_zombies = true;
            desadaptation_crystal.rarity = Rarity.R0_Normal;
            desadaptation_crystal.unlocked_with_achievement = false;
            desadaptation_crystal.base_stats_meta = new BaseStats();
            desadaptation_crystal.base_stats_meta.addTag("desadaptation_Crystal");
            AssetManager.subspecies_traits.add(desadaptation_crystal);
            //addTraitToLocalizedLibrary("ru",desadaptation_crystal.id, "Кристаллическая дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_crystal.id, "Crystal disadaptation", "");

            SubspeciesTrait desadaptation_Green = new SubspeciesTrait();
            desadaptation_Green.id = "desadaptation_green";
            desadaptation_Green.group_id = "adaptations";
            desadaptation_Green.path_icon = "ui/ws3icons/desadaptation_Green";
            desadaptation_Green.remove_for_zombies = true;
            desadaptation_Green.rarity = Rarity.R0_Normal;
            desadaptation_Green.unlocked_with_achievement = false;
            desadaptation_Green.base_stats_meta = new BaseStats();
            desadaptation_Green.base_stats_meta.addTag("desadaptation_Green");
            AssetManager.subspecies_traits.add(desadaptation_Green);
            //addTraitToLocalizedLibrary("ru",desadaptation_Green.id, "Дизадаптация поля","");
            //addTraitToLocalizedLibrary("en",desadaptation_Green.id, "Green disadaptation", "");
            

            SubspeciesTrait desadaptation_Savanna = new SubspeciesTrait();
            desadaptation_Savanna.id = "desadaptation_savanna";
            desadaptation_Savanna.group_id = "adaptations";
            desadaptation_Savanna.path_icon = "ui/ws3icons/desadaptation_Savanna";
            desadaptation_Savanna.remove_for_zombies = true;
            desadaptation_Savanna.rarity = Rarity.R0_Normal;
            desadaptation_Savanna.unlocked_with_achievement = false;
            desadaptation_Savanna.base_stats_meta = new BaseStats();
            desadaptation_Savanna.base_stats_meta.addTag("desadaptation_Savanna");
            AssetManager.subspecies_traits.add(desadaptation_Savanna);
            //addTraitToLocalizedLibrary("ru",desadaptation_Savanna.id, "Дизадаптация Саванны","");
            //addTraitToLocalizedLibrary("en",desadaptation_Savanna.id, "Disadaptation of the Savannah", "");
            
            SubspeciesTrait desadaptation_Enchanted = new SubspeciesTrait();
            desadaptation_Enchanted.id = "desadaptation_enchanted";
            desadaptation_Enchanted.group_id = "adaptations";
            desadaptation_Enchanted.path_icon = "ui/ws3icons/desadaptation_Enchanted";
            desadaptation_Enchanted.remove_for_zombies = true;
            desadaptation_Enchanted.rarity = Rarity.R0_Normal;
            desadaptation_Enchanted.unlocked_with_achievement = false;
            desadaptation_Enchanted.base_stats_meta = new BaseStats();
            desadaptation_Enchanted.base_stats_meta.addTag("desadaptation_Enchanted");
            AssetManager.subspecies_traits.add(desadaptation_Enchanted);
            //addTraitToLocalizedLibrary("ru",desadaptation_Enchanted.id, "Зачарованная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Enchanted.id, "Enchanted disadaptation", "");
            

            SubspeciesTrait desadaptation_Mushroom = new SubspeciesTrait();
            desadaptation_Mushroom.id = "desadaptation_mushroom";
            desadaptation_Mushroom.group_id = "adaptations";
            desadaptation_Mushroom.path_icon = "ui/ws3icons/desadaptation_Mushroom";
            desadaptation_Mushroom.remove_for_zombies = true;
            desadaptation_Mushroom.rarity = Rarity.R0_Normal;
            desadaptation_Mushroom.unlocked_with_achievement = false;
            desadaptation_Mushroom.base_stats_meta = new BaseStats();
            desadaptation_Mushroom.base_stats_meta.addTag("desadaptation_Mushroom");
            AssetManager.subspecies_traits.add(desadaptation_Mushroom);
            //addTraitToLocalizedLibrary("ru",desadaptation_Mushroom.id, "Грибная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Mushroom.id, "Mushroom disadaptation", "");
            

            SubspeciesTrait desadaptation_Jungle = new SubspeciesTrait();
            desadaptation_Jungle.id = "desadaptation_jungle";
            desadaptation_Jungle.group_id = "adaptations";
            desadaptation_Jungle.path_icon = "ui/ws3icons/desadaptation_Jungle";
            desadaptation_Jungle.remove_for_zombies = true;
            desadaptation_Jungle.rarity = Rarity.R0_Normal;
            desadaptation_Jungle.unlocked_with_achievement = false;
            desadaptation_Jungle.base_stats_meta = new BaseStats();
            desadaptation_Jungle.base_stats_meta.addTag("desadaptation_Jungle");
            AssetManager.subspecies_traits.add(desadaptation_Jungle);
            //addTraitToLocalizedLibrary("ru",desadaptation_Jungle.id, "Дизадаптация к джунглям","Слишком влажно и жарко");
            //addTraitToLocalizedLibrary("en",desadaptation_Jungle.id, "Disadaptation to the jungle", "It's too humid and hot");
            

            SubspeciesTrait desadaptation_Rocklands = new SubspeciesTrait();
            desadaptation_Rocklands.id = "desadaptation_rocklands";
            desadaptation_Rocklands.group_id = "adaptations";
            desadaptation_Rocklands.path_icon = "ui/ws3icons/desadaptation_Rocklands";
            desadaptation_Rocklands.remove_for_zombies = true;
            desadaptation_Rocklands.rarity = Rarity.R0_Normal;
            desadaptation_Rocklands.unlocked_with_achievement = false;
            desadaptation_Rocklands.base_stats_meta = new BaseStats();
            desadaptation_Rocklands.base_stats_meta.addTag("desadaptation_Rocklands");
            AssetManager.subspecies_traits.add(desadaptation_Rocklands);
            //addTraitToLocalizedLibrary("ru",desadaptation_Rocklands.id, "Каменная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Rocklands.id, "Rocklands disadaptation", "");
            

            SubspeciesTrait desadaptation_Candy = new SubspeciesTrait();
            desadaptation_Candy.id = "desadaptation_candy";
            desadaptation_Candy.group_id = "adaptations";
            desadaptation_Candy.path_icon = "ui/ws3icons/desadaptation_Candy";
            desadaptation_Candy.remove_for_zombies = true;
            desadaptation_Candy.rarity = Rarity.R0_Normal;
            desadaptation_Candy.unlocked_with_achievement = false;
            desadaptation_Candy.base_stats_meta = new BaseStats();
            desadaptation_Candy.base_stats_meta.addTag("desadaptation_Candy");
            AssetManager.subspecies_traits.add(desadaptation_Candy);
            //addTraitToLocalizedLibrary("ru",desadaptation_Candy.id, "Конфетная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Candy.id, "Candy disadaptation", "");
            

            SubspeciesTrait desadaptation_Lemon = new SubspeciesTrait();
            desadaptation_Lemon.id = "desadaptation_lemon";
            desadaptation_Lemon.group_id = "adaptations";
            desadaptation_Lemon.path_icon = "ui/ws3icons/desadaptation_Lemon";
            desadaptation_Lemon.remove_for_zombies = true;
            desadaptation_Lemon.rarity = Rarity.R0_Normal;
            desadaptation_Lemon.unlocked_with_achievement = false;
            desadaptation_Lemon.base_stats_meta = new BaseStats();
            desadaptation_Lemon.base_stats_meta.addTag("desadaptation_Lemon");
            AssetManager.subspecies_traits.add(desadaptation_Lemon);
            //addTraitToLocalizedLibrary("ru", desadaptation_Lemon.id, "Лимонная дизадаптация","");
            //addTraitToLocalizedLibrary("en", desadaptation_Lemon.id, "Lemon disadaptation", "");
            

            SubspeciesTrait desadaptation_Birch = new SubspeciesTrait();
            desadaptation_Birch.id = "desadaptation_birch";
            desadaptation_Birch.group_id = "adaptations";
            desadaptation_Birch.path_icon = "ui/ws3icons/desadaptation_Birch";
            desadaptation_Birch.remove_for_zombies = true;
            desadaptation_Birch.rarity = Rarity.R0_Normal;
            desadaptation_Birch.unlocked_with_achievement = false;
            desadaptation_Birch.base_stats_meta = new BaseStats();
            desadaptation_Birch.base_stats_meta.addTag("desadaptation_Birch");
            AssetManager.subspecies_traits.add(desadaptation_Birch);
            //addTraitToLocalizedLibrary("ru",desadaptation_Birch.id, "Аллергия на родину)","");
            //addTraitToLocalizedLibrary("en",desadaptation_Birch.id, "Allergy to birch", "");

            SubspeciesTrait desadaptation_Maple = new SubspeciesTrait();
            desadaptation_Maple.id = "desadaptation_maple";
            desadaptation_Maple.group_id = "adaptations";
            desadaptation_Maple.path_icon = "ui/ws3icons/desadaptation_Maple";
            desadaptation_Maple.remove_for_zombies = true;
            desadaptation_Maple.rarity = Rarity.R0_Normal;
            desadaptation_Maple.unlocked_with_achievement = false;
            desadaptation_Maple.base_stats_meta = new BaseStats();
            desadaptation_Maple.base_stats_meta.addTag("desadaptation_Maple");
            AssetManager.subspecies_traits.add(desadaptation_Maple);
            //addTraitToLocalizedLibrary("ru",desadaptation_Maple.id, "Кленовая дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Maple.id, "Maple disadaptation", "");
            

            SubspeciesTrait desadaptation_Flower = new SubspeciesTrait();
            desadaptation_Flower.id = "desadaptation_flower";
            desadaptation_Flower.group_id = "adaptations";
            desadaptation_Flower.path_icon = "ui/ws3icons/desadaptation_Flower";
            desadaptation_Flower.remove_for_zombies = true;
            desadaptation_Flower.rarity = Rarity.R0_Normal;
            desadaptation_Flower.unlocked_with_achievement = false;
            desadaptation_Flower.base_stats_meta = new BaseStats();
            desadaptation_Flower.base_stats_meta.addTag("desadaptation_Flower");
            AssetManager.subspecies_traits.add(desadaptation_Flower);
            //addTraitToLocalizedLibrary("ru",desadaptation_Flower.id, "Цветочная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Flower.id, "Flower disadaptation", "");
            

            SubspeciesTrait desadaptation_Garlic = new SubspeciesTrait();
            desadaptation_Garlic.id = "desadaptation_garlic";
            desadaptation_Garlic.group_id = "adaptations";
            desadaptation_Garlic.path_icon = "ui/ws3icons/desadaptation_Garlic";
            desadaptation_Garlic.remove_for_zombies = true;
            desadaptation_Garlic.rarity = Rarity.R0_Normal;
            desadaptation_Garlic.unlocked_with_achievement = false;
            desadaptation_Garlic.base_stats_meta = new BaseStats();
            desadaptation_Garlic.base_stats_meta.addTag("desadaptation_Garlic");
            AssetManager.subspecies_traits.add(desadaptation_Garlic);
            //addTraitToLocalizedLibrary("ru",desadaptation_Garlic.id, "Чесночная дизадаптация","Фуу... Чеснок");
            //addTraitToLocalizedLibrary("en",desadaptation_Garlic.id, "Garlic disadaptation", "Ugh... Garlic");
            

            SubspeciesTrait desadaptation_Paradox = new SubspeciesTrait();
            desadaptation_Paradox.id = "desadaptation_paradox";
            desadaptation_Paradox.group_id = "adaptations";
            desadaptation_Paradox.path_icon = "ui/ws3icons/desadaptation_Paradox";
            desadaptation_Paradox.remove_for_zombies = true;
            desadaptation_Paradox.rarity = Rarity.R0_Normal;
            desadaptation_Paradox.unlocked_with_achievement = false;
            desadaptation_Paradox.base_stats_meta = new BaseStats();
            desadaptation_Paradox.base_stats_meta.addTag("desadaptation_Paradox");
            AssetManager.subspecies_traits.add(desadaptation_Paradox);
            //addTraitToLocalizedLibrary("ru",desadaptation_Paradox.id, "Пародоксальная дизадаптация","Пародоксальное головокружение");
            //addTraitToLocalizedLibrary("en",desadaptation_Paradox.id, "Paradox disadaptation", "Paradoxical vertigo");
            

            SubspeciesTrait desadaptation_Clover = new SubspeciesTrait();
            desadaptation_Clover.id = "desadaptation_clover";
            desadaptation_Clover.group_id = "adaptations";
            desadaptation_Clover.path_icon = "ui/ws3icons/desadaptation_Clover";
            desadaptation_Clover.remove_for_zombies = true;
            desadaptation_Clover.rarity = Rarity.R0_Normal;
            desadaptation_Clover.unlocked_with_achievement = false;
            desadaptation_Clover.base_stats_meta = new BaseStats();
            desadaptation_Clover.base_stats_meta.addTag("desadaptation_Clover");
            AssetManager.subspecies_traits.add(desadaptation_Clover);
            //addTraitToLocalizedLibrary("ru",desadaptation_Clover.id, "Клеверная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Clover.id, "Clover disadaptation", "");
            

            SubspeciesTrait desadaptation_Singularity = new SubspeciesTrait();
            desadaptation_Singularity.id = "desadaptation_singularity";
            desadaptation_Singularity.group_id = "adaptations";
            desadaptation_Singularity.path_icon = "ui/ws3icons/desadaptation_Singularity";
            desadaptation_Singularity.remove_for_zombies = true;
            desadaptation_Singularity.rarity = Rarity.R0_Normal;
            desadaptation_Singularity.unlocked_with_achievement = false;
            desadaptation_Singularity.base_stats_meta = new BaseStats();
            desadaptation_Singularity.base_stats_meta.addTag("desadaptation_Singularity");
            AssetManager.subspecies_traits.add(desadaptation_Singularity);
            //addTraitToLocalizedLibrary("ru",desadaptation_Singularity.id, "Уход от сингулярности","");
            //addTraitToLocalizedLibrary("en",desadaptation_Singularity.id, "Avoiding the singularity", "");
            

            SubspeciesTrait desadaptation_Celestial = new SubspeciesTrait();
            desadaptation_Celestial.id = "desadaptation_celestial";
            desadaptation_Celestial.group_id = "adaptations";
            desadaptation_Celestial.path_icon = "ui/ws3icons/desadaptation_Celestial";
            desadaptation_Celestial.remove_for_zombies = true;
            desadaptation_Celestial.rarity = Rarity.R0_Normal;
            desadaptation_Celestial.unlocked_with_achievement = false;
            desadaptation_Celestial.base_stats_meta = new BaseStats();
            desadaptation_Celestial.base_stats_meta.addTag("desadaptation_Celestial");
            AssetManager.subspecies_traits.add(desadaptation_Celestial);
            //addTraitToLocalizedLibrary("ru",desadaptation_Celestial.id, "Небесная дизадаптация","От высоты голова кружится");
            //addTraitToLocalizedLibrary("en",desadaptation_Celestial.id, "Heavenly disadaptation","The height makes my head spin");
            
            SubspeciesTrait desadaptation_Sand = new SubspeciesTrait();
            desadaptation_Sand.id = "desadaptation_sand";
            desadaptation_Sand.group_id = "adaptations";
            desadaptation_Sand.path_icon = "ui/ws3icons/desadaptation_Sand";
            desadaptation_Sand.remove_for_zombies = true;
            desadaptation_Sand.rarity = Rarity.R0_Normal;
            desadaptation_Sand.unlocked_with_achievement = false;
            desadaptation_Sand.base_stats_meta = new BaseStats();
            desadaptation_Sand.base_stats_meta.addTag("desadaptation_Sand");
            AssetManager.subspecies_traits.add(desadaptation_Sand);
            //addTraitToLocalizedLibrary("ru",desadaptation_Sand.id, "Песочная дизадаптация","");
            //addTraitToLocalizedLibrary("en",desadaptation_Sand.id, "Sandy disadaptation","");
        }

        public static void addTraitToLocalizedLibrary(string planguage, string id, string name, string description)
        {
        }
       }
}

