using ReflectionUtility;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ai;
using ai.behaviours;
using HarmonyLib;

namespace Desadaptation
{

    class Patches : MonoBehaviour
    {
        //private static MethodInfo goodForNewDockMethod;
        public static Harmony harmony = new Harmony("androlg.mod.worldbox.Desadaptation");
        public static void init()
        {
            //goodForNewDockMethod = AccessTools.Method("OceanHelper:goodForNewDock");

            harmony.Patch(
                AccessTools.Method(typeof(BuildingManager), "canBuildFrom"),
                prefix: new HarmonyMethod(AccessTools.Method(typeof(Patches), "canBuildFrom_Prefix"))
            );

        }
        static bool canBuildFrom_Prefix(
            BuildingManager __instance,
            WorldTile pTile,
            BuildingAsset pNewBuildingAsset,
            City pCity,
            ref bool __result)
        {
            Subspecies mainSubspecies = pCity?.getMainSubspecies();
        if (mainSubspecies != null 
            && pNewBuildingAsset.city_building 
            && pNewBuildingAsset.check_for_adaptation_tags 
            && pTile.Type.is_biome)
            {
                foreach (BiomeTag tag in pTile.Type.biome_tags)
                {
                    if (mainSubspecies.hasMetaTag("desadaptation_" + tag.ToString()))
                    {
                        __result = false; // Запрещаем строительство
                        return false; // Пропускаем оригинальный метод
                    }
                }
            }

            return true;// Продолжаем оригинальный метод
        }
    }
}