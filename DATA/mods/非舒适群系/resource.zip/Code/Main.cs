using System;
using NCMS;
using UnityEngine;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using NeoModLoader.General;

namespace Desadaptation
{
    [ModEntry]
    class Main : BasicMod<Main>
    {
        public static Main instance;
        public static string mainPath;
        private static bool initialized = false;
        string pastlanguage = "ru";
        string newlanguage = "";

        protected override void OnModLoad()
        {
            if (initialized)
            {
                Debug.LogWarning("[Desadaptation Mod] Main.Awake() already called, skipping initialization.");
                return;
            }

            instance = this;
            mainPath = Application.dataPath;
            GameObject go = new GameObject("DesadaptationTraits");
            DontDestroyOnLoad(go);

            DesadaptationTraits.Initialize();
            Patches.init();

            PatchWorldLawCursed.init();
            //LocalizedTextManager.add("NML_AUTHENTICATION", "Authentication");
            var harmony = new Harmony("com.Desadaptation.mod");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
            Debug.Log("[Desadaptation Mod] Harmony patching applied.");

            initialized = true;
            Debug.Log("[Desadaptation Mod] Main.Awake() completed successfully.");
        }

        void Start()
        {
            
            
        }

        void Update()
        {
            newlanguage = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
            
            if (newlanguage != pastlanguage)
            {
                DesadaptationTraits.Initialize();
            }
            pastlanguage = newlanguage;
        }

        public static class PatchWorldLawCursed
        {
            public static void init()
            {
                var cursedworld = AssetManager.world_laws_library.get("world_law_cursed_world");
                cursedworld.default_state = true;
                Debug.Log("[Desadaptation Mod] PatchWorldLawCursed initialized.");
            }
        }
    }
}