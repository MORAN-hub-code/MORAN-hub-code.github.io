﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        // 添加击杀数阈值常量
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {1, "JunShi1"},
            {10, "JunShi2"},
            {20, "JunShi3"},
            {30, "JunShi4"},
            {50, "JunShi5"},
            {70, "JunShi6"}
        };
        private static readonly Dictionary<int, string> LevelRewardTraits = new()
        {
            {10, "WaiJiao1"},
            {15, "WaiJiao2"},
            {20, "WaiJiao3"},
            {25, "WaiJiao4"},
            {30, "WaiJiao5"},
            {35, "WaiJiao6"}
        };        
        private static readonly Dictionary<int, string> MoneyRewardTraits = new()
        {
            {10, "GuanLi1"},
            {20, "GuanLi2"},
            {30, "GuanLi3"},
            {50, "GuanLi4"},
            {70, "GuanLi5"},
            {90, "GuanLi6"}
        };  
        // 添加击杀奖励，同组特质唯一
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance)
        {
            if (__instance == null || !__instance.isAlive()) return;

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.kills >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanXun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanYun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanYun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);
            }
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "loadData")]
        public static void Actor_loadData_Postfix(Actor __instance)
        {
            if (__instance == null || !__instance.isAlive()) return;

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var levelReward in LevelRewardTraits.Reverse())
            {
                if (__instance.data.level >= levelReward.Key)
                {
                    highestTraitId = levelReward.Value;
                    break;
                }
            }

            foreach (var moneyReward in MoneyRewardTraits.Reverse())
            {
                if (__instance.data.money  >= moneyReward.Key)
                {
                    highestTraitId = moneyReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanYun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanYun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanYun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);
            }
        }

        private static bool IsBasicRaceOrCiv(string assetId)
        {
            // ... existing code ...
            return false; // Placeholder return, actual implementation needed
        }
    }
}