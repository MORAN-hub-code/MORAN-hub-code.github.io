﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChivalryWizardingWorld.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset ZhanYun = new ActorTraitGroupAsset();
            ZhanYun.id = "ZhanYun";
            ZhanYun.name = "战争艺术";
            ZhanYun.color = "#66CCFF";
            AssetManager.trait_groups.add(ZhanYun);
        }
    }
}
