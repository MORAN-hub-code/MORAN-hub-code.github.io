﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using strings;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        public static void Init()
        {
            ActorTrait JunShi1 = new ActorTrait();
            JunShi1.id = "JunShi1";
            JunShi1.path_icon = "trait/JunShi1";
            JunShi1.needs_to_be_explored = false;
            JunShi1.group_id = "ZhanYun";
            JunShi1.base_stats = new BaseStats();
            JunShi1.base_stats[strings.S.warfare] = 10f;
            AssetManager.traits.add(JunShi1);

            ActorTrait JunShi2 = new ActorTrait();
            JunShi2.id = "JunShi2";
            JunShi2.path_icon = "trait/JunShi2";
            JunShi2.needs_to_be_explored = false;
            JunShi2.group_id = "ZhanYun";
            JunShi2.base_stats = new BaseStats();
            JunShi2.base_stats[strings.S.warfare] = 30f;
            AssetManager.traits.add(JunShi2);

            ActorTrait JunShi3 = new ActorTrait();
            JunShi3.id = "JunShi3";
            JunShi3.path_icon = "trait/JunShi3";
            JunShi3.needs_to_be_explored = false;
            JunShi3.group_id = "ZhanYun";
            JunShi3.base_stats = new BaseStats();
            JunShi3.base_stats[strings.S.warfare] = 70f;
            AssetManager.traits.add(JunShi3);

            ActorTrait JunShi4 = new ActorTrait();
            JunShi4.id = "JunShi4";
            JunShi4.path_icon = "trait/JunShi4";
            JunShi4.needs_to_be_explored = false;
            JunShi4.group_id = "ZhanYun";
            JunShi4.base_stats = new BaseStats();
            JunShi4.base_stats[strings.S.lifespan] = 20f;
            JunShi4.base_stats[strings.S.warfare] = 150f;
            AssetManager.traits.add(JunShi4);

            ActorTrait JunShi5 = new ActorTrait();
            JunShi5.id = "JunShi5";
            JunShi5.path_icon = "trait/JunShi5";
            JunShi5.needs_to_be_explored = false;
            JunShi5.group_id = "ZhanYun";
            JunShi5.base_stats = new BaseStats();
            JunShi5.base_stats[strings.S.damage] = 50f;
            JunShi5.base_stats[strings.S.warfare] = 320f;
            JunShi5.base_stats[strings.S.lifespan] = 50f;
            AssetManager.traits.add(JunShi5);

            ActorTrait JunShi6 = new ActorTrait();
            JunShi6.id = "JunShi6";
            JunShi6.path_icon = "trait/JunShi6";
            JunShi6.needs_to_be_explored = false;
            JunShi6.group_id = "ZhanYun";
            JunShi6.base_stats = new BaseStats();
            JunShi6.base_stats[strings.S.stewardship] = 150f;
            JunShi6.base_stats[strings.S.warfare] = 666f;
            JunShi6.base_stats[strings.S.lifespan] = 200f;
            JunShi6.base_stats[strings.S.armor] = 20f;
            JunShi6.base_stats[strings.S.diplomacy] = 150f;
            JunShi6.base_stats[strings.S.health] = 999f;
            AssetManager.traits.add(JunShi6);

            ActorTrait WaiJiao1 = new ActorTrait();
            WaiJiao1.id = "WaiJiao1";
            WaiJiao1.path_icon = "trait/WaiJiao1";
            WaiJiao1.needs_to_be_explored = false;
            WaiJiao1.group_id = "ZhanYun";
            WaiJiao1.base_stats = new BaseStats();
            WaiJiao1.base_stats[strings.S.diplomacy] = 10f;
            AssetManager.traits.add(WaiJiao1);

            ActorTrait WaiJiao2 = new ActorTrait();
            WaiJiao2.id = "WaiJiao2";
            WaiJiao2.path_icon = "trait/WaiJiao2";
            WaiJiao2.needs_to_be_explored = false;
            WaiJiao2.group_id = "ZhanYun";
            WaiJiao2.base_stats = new BaseStats();
            WaiJiao2.base_stats[strings.S.diplomacy] = 30f;
            AssetManager.traits.add(WaiJiao2);

            ActorTrait WaiJiao3 = new ActorTrait();
            WaiJiao3.id = "WaiJiao3";
            WaiJiao3.path_icon = "trait/WaiJiao3";
            WaiJiao3.needs_to_be_explored = false;
            WaiJiao3.group_id = "ZhanYun";
            WaiJiao3.base_stats = new BaseStats();
            WaiJiao3.base_stats[strings.S.diplomacy] = 70f;
            AssetManager.traits.add(WaiJiao3);

            ActorTrait WaiJiao4 = new ActorTrait();
            WaiJiao4.id = "WaiJiao4";
            WaiJiao4.path_icon = "trait/WaiJiao4";
            WaiJiao4.needs_to_be_explored = false;
            WaiJiao4.group_id = "ZhanYun";
            WaiJiao4.base_stats = new BaseStats();
            WaiJiao4.base_stats[strings.S.lifespan] = 20f;
            WaiJiao4.base_stats[strings.S.diplomacy] = 150f;
            AssetManager.traits.add(WaiJiao4);

            ActorTrait WaiJiao5 = new ActorTrait();
            WaiJiao5.id = "WaiJiao5";
            WaiJiao5.path_icon = "trait/WaiJiao5";
            WaiJiao5.needs_to_be_explored = false;
            WaiJiao5.group_id = "ZhanYun";
            WaiJiao5.base_stats = new BaseStats();
            WaiJiao5.base_stats[strings.S.damage] = 50f;
            WaiJiao5.base_stats[strings.S.diplomacy] = 320f;
            WaiJiao5.base_stats[strings.S.lifespan] = 50f;
            AssetManager.traits.add(WaiJiao5);

            ActorTrait WaiJiao6 = new ActorTrait();
            WaiJiao6.id = "WaiJiao6";
            WaiJiao6.path_icon = "trait/WaiJiao6";
            WaiJiao6.needs_to_be_explored = false;
            WaiJiao6.group_id = "ZhanYun";
            WaiJiao6.base_stats = new BaseStats();
            WaiJiao6.base_stats[strings.S.stewardship] = 150f;
            WaiJiao6.base_stats[strings.S.warfare] = 150f;
            WaiJiao6.base_stats[strings.S.lifespan] = 200f;
            WaiJiao6.base_stats[strings.S.armor] = 20f;
            WaiJiao6.base_stats[strings.S.diplomacy] = 666f;
            WaiJiao6.base_stats[strings.S.health] = 999f;
            AssetManager.traits.add(WaiJiao6);


            ActorTrait GuanLi1 = new ActorTrait();
            GuanLi1.id = "GuanLi1";
            GuanLi1.path_icon = "trait/GuanLi1";
            GuanLi1.needs_to_be_explored = false;
            GuanLi1.group_id = "ZhanYun";
            GuanLi1.base_stats = new BaseStats();
            GuanLi1.base_stats[strings.S.stewardship] = 10f;
            AssetManager.traits.add(GuanLi1);

            ActorTrait GuanLi2 = new ActorTrait();
            GuanLi2.id = "GuanLi2";
            GuanLi2.path_icon = "trait/GuanLi2";
            GuanLi2.needs_to_be_explored = false;
            GuanLi2.group_id = "ZhanYun";
            GuanLi2.base_stats = new BaseStats();
            GuanLi2.base_stats[strings.S.stewardship] = 30f;
            AssetManager.traits.add(GuanLi2);

            ActorTrait GuanLi3 = new ActorTrait();
            GuanLi3.id = "GuanLi3";
            GuanLi3.path_icon = "trait/GuanLi3";
            GuanLi3.needs_to_be_explored = false;
            GuanLi3.group_id = "ZhanYun";
            GuanLi3.base_stats = new BaseStats();
            GuanLi3.base_stats[strings.S.stewardship] = 70f;
            AssetManager.traits.add(GuanLi3);

            ActorTrait GuanLi4 = new ActorTrait();
            GuanLi4.id = "GuanLi4";
            GuanLi4.path_icon = "trait/GuanLi4";
            GuanLi4.needs_to_be_explored = false;
            GuanLi4.group_id = "ZhanYun";
            GuanLi4.base_stats = new BaseStats();
            GuanLi4.base_stats[strings.S.stewardship] = 20f;
            GuanLi4.base_stats[strings.S.warfare] = 150f;
            AssetManager.traits.add(GuanLi4);

            ActorTrait GuanLi5 = new ActorTrait();
            GuanLi5.id = "GuanLi5";
            GuanLi5.path_icon = "trait/GuanLi5";
            GuanLi5.needs_to_be_explored = false;
            GuanLi5.group_id = "ZhanYun";
            GuanLi5.base_stats = new BaseStats();
            GuanLi5.base_stats[strings.S.damage] = 50f;
            GuanLi5.base_stats[strings.S.stewardship] = 320f;
            GuanLi5.base_stats[strings.S.lifespan] = 50f;
            AssetManager.traits.add(GuanLi5);

            ActorTrait GuanLi6 = new ActorTrait();
            GuanLi6.id = "GuanLi6";
            GuanLi6.path_icon = "trait/GuanLi6";
            GuanLi6.needs_to_be_explored = false;
            GuanLi6.group_id = "ZhanYun";
            GuanLi6.base_stats = new BaseStats();
            GuanLi6.base_stats[strings.S.stewardship] = 666f;
            GuanLi6.base_stats[strings.S.warfare] = 150f;
            GuanLi6.base_stats[strings.S.lifespan] = 200f;
            GuanLi6.base_stats[strings.S.armor] = 20f;
            GuanLi6.base_stats[strings.S.diplomacy] = 150f;
            GuanLi6.base_stats[strings.S.health] = 999f;
            AssetManager.traits.add(GuanLi6);
        }
    }
}