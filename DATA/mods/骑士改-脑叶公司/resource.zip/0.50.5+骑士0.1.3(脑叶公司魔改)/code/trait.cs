﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();
            
            return trait;
        }
        public static ActorTrait talent_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait talent = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "SeedsofLife",
                needs_to_be_explored = false
            };
            talent.action_special_effect += traitAction.Knight1_effectAction;
            AssetManager.traits.add(talent);
            return talent;
        }
        public static void Init()
        {
            _=talent_AddActorTrait("talent1", "trait/talent1");//骑士天赋•下
            _=talent_AddActorTrait("talent2", "trait/talent2");//骑士天赋•中
            _=talent_AddActorTrait("talent3", "trait/talent3");//骑士天赋•上
            _=talent_AddActorTrait("talent4", "trait/talent4");//骑士天赋•完美

            ActorTrait talent5 = CreateTrait("talent5", "trait/talent5", "SeedsofLife");
            talent5.rate_inherit = 100;
            AssetManager.traits.add(talent5);
            
            ActorTrait talent6 = CreateTrait("talent6", "trait/talent6", "SeedsofLife");
            AssetManager.traits.add(talent6);

            ActorTrait talent7 = CreateTrait("talent7", "trait/talent7", "Knight");
            AssetManager.traits.add(talent7);

            ActorTrait autonomy1 = CreateTrait("autonomy1", "trait/autonomy1", "Knight");
            SafeSetStat(autonomy1.base_stats, strings.S.critical_chance, 0.1f);
            SafeSetStat(autonomy1.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(autonomy1.base_stats, strings.S.accuracy, 1f);
            AssetManager.traits.add(autonomy1);

            ActorTrait autonomy2 = CreateTrait("autonomy2", "trait/autonomy2", "Knight");
            SafeSetStat(autonomy2.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(autonomy2.base_stats, strings.S.skill_combat, 0.2f);
            SafeSetStat(autonomy2.base_stats, strings.S.accuracy, 3f);
            AssetManager.traits.add(autonomy2);

            ActorTrait autonomy3 = CreateTrait("autonomy3", "trait/autonomy3", "Knight");
            SafeSetStat(autonomy3.base_stats , strings.S.skill_combat, 0.3f);
            SafeSetStat(autonomy3.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(autonomy3.base_stats , strings.S.critical_chance, 0.3f);
            AssetManager.traits.add(autonomy3);
            
            ActorTrait autonomy4 = CreateTrait("autonomy4", "trait/autonomy4", "Knight");
            SafeSetStat(autonomy4.base_stats , strings.S.skill_combat, 0.4f);
            SafeSetStat(autonomy4.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(autonomy4.base_stats , strings.S.critical_chance, 0.5f);
            AssetManager.traits.add(autonomy4);

            ActorTrait autonomy5 = CreateTrait("autonomy5", "trait/autonomy5", "Knight");
            SafeSetStat(autonomy5.base_stats , strings.S.skill_combat, 0.5f);
            SafeSetStat(autonomy5.base_stats , strings.S.accuracy, 15f);
            SafeSetStat(autonomy5.base_stats , strings.S.critical_chance, 0.7f);
            AssetManager.traits.add(autonomy5);

            ActorTrait autonomy6 = CreateTrait("autonomy6", "trait/autonomy6", "Knight");
            SafeSetStat(autonomy6.base_stats , strings.S.skill_combat, 0.6f);
            SafeSetStat(autonomy6.base_stats , strings.S.accuracy, 20f);
            SafeSetStat(autonomy6.base_stats , strings.S.critical_chance, 0.9f);
            AssetManager.traits.add(autonomy6);

            ActorTrait brave1 = CreateTrait("brave1", "trait/brave1", "Knight");
            SafeSetStat(brave1.base_stats, strings.S.health, 1000f);
            SafeSetStat(brave1.base_stats, strings.S.stamina, 100f);
            SafeSetStat(brave1.base_stats, strings.S.lifespan, 10f);
            AssetManager.traits.add(brave1);

            ActorTrait brave2 = CreateTrait("brave2", "trait/brave2", "Knight");
            SafeSetStat(brave2.base_stats, strings.S.health, 3000f);
            SafeSetStat(brave2.base_stats, strings.S.stamina, 300f);
            SafeSetStat(brave2.base_stats, strings.S.lifespan, 30f);
            AssetManager.traits.add(brave2);

            ActorTrait brave3 = CreateTrait("brave3", "trait/brave3", "Knight");
            SafeSetStat(brave3.base_stats, strings.S.health, 6000f);
            SafeSetStat(brave3.base_stats, strings.S.stamina, 600f);
            SafeSetStat(brave3.base_stats, strings.S.lifespan, 60f);
            AssetManager.traits.add(brave3);
            
            ActorTrait brave4 = CreateTrait("brave4", "trait/brave4", "Knight");
            SafeSetStat(brave4.base_stats, strings.S.health, 9000f);
            SafeSetStat(brave4.base_stats, strings.S.stamina, 900f);
            SafeSetStat(brave4.base_stats, strings.S.lifespan, 90f);
            AssetManager.traits.add(brave4);

            ActorTrait brave5 = CreateTrait("brave5", "trait/brave5", "Knight");
            SafeSetStat(brave5.base_stats, strings.S.health, 12000f);
            SafeSetStat(brave5.base_stats, strings.S.stamina, 1200f);
            SafeSetStat(brave5.base_stats, strings.S.lifespan, 120f);
            AssetManager.traits.add(brave5);

            ActorTrait brave6 = CreateTrait("brave6", "trait/brave6", "Knight");
            SafeSetStat(brave6.base_stats, strings.S.health, 24000f);
            SafeSetStat(brave6.base_stats, strings.S.stamina, 2400f);
            SafeSetStat(brave6.base_stats, strings.S.lifespan, 240f);
            AssetManager.traits.add(brave6);

            ActorTrait careful1 = CreateTrait("careful1", "trait/careful1", "Knight");
            SafeSetStat(careful1.base_stats, strings.S.mana, 100f);
            SafeSetStat(careful1.base_stats, strings.S.area_of_effect, 1f);
            SafeSetStat(careful1.base_stats, strings.S.armor, 10f);
            AssetManager.traits.add(careful1);

            ActorTrait careful2 = CreateTrait("careful2", "trait/careful2", "Knight");
            SafeSetStat(careful2.base_stats, strings.S.mana, 300f);
            SafeSetStat(careful2.base_stats, strings.S.area_of_effect, 2f);
            SafeSetStat(careful2.base_stats, strings.S.armor, 20f);
            AssetManager.traits.add(careful2);

            ActorTrait careful3 = CreateTrait("careful3", "trait/careful3", "Knight");
            SafeSetStat(careful3.base_stats, strings.S.mana, 1000f);
            SafeSetStat(careful3.base_stats, strings.S.area_of_effect, 3f);
            SafeSetStat(careful3.base_stats, strings.S.armor, 30f);
            AssetManager.traits.add(careful3);
            
            ActorTrait careful4 = CreateTrait("careful4", "trait/careful4", "Knight");
            SafeSetStat(careful4.base_stats, strings.S.mana, 3000f);
            SafeSetStat(careful4.base_stats, strings.S.area_of_effect, 5f);
            SafeSetStat(careful4.base_stats, strings.S.armor, 50f);
            AssetManager.traits.add(careful4);

            ActorTrait careful5 = CreateTrait("careful5", "trait/careful5", "Knight");
            SafeSetStat(careful5.base_stats, strings.S.mana, 6000f);
            SafeSetStat(careful5.base_stats, strings.S.area_of_effect, 7f);
            SafeSetStat(careful5.base_stats, strings.S.armor, 70f);
            AssetManager.traits.add(careful5);

            ActorTrait careful6 = CreateTrait("careful6", "trait/careful6", "Knight");
            SafeSetStat(careful6.base_stats, strings.S.mana, 9000f);
            SafeSetStat(careful6.base_stats, strings.S.area_of_effect, 9f);
            SafeSetStat(careful6.base_stats, strings.S.armor, 90f);
            AssetManager.traits.add(careful6);

            ActorTrait justice1 = CreateTrait("justice1", "trait/justice1", "Knight");
            SafeSetStat(justice1.base_stats, strings.S.speed, 10f);
            SafeSetStat(justice1.base_stats, strings.S.targets, 1f);
            SafeSetStat(justice1.base_stats, strings.S.damage, 10f);
            AssetManager.traits.add(justice1);

            ActorTrait justice2 = CreateTrait("justice2", "trait/justice2", "Knight");
            SafeSetStat(justice2.base_stats, strings.S.speed, 15f);
            SafeSetStat(justice2.base_stats, strings.S.targets, 3f);
            SafeSetStat(justice2.base_stats, strings.S.damage, 30f);
            AssetManager.traits.add(justice2);

            ActorTrait justice3 = CreateTrait("justice3", "trait/justice3", "Knight");
            SafeSetStat(justice3.base_stats, strings.S.speed, 25f);
            SafeSetStat(justice3.base_stats, strings.S.targets, 5f);
            SafeSetStat(justice3.base_stats, strings.S.damage, 50f);
            AssetManager.traits.add(justice3);
            
            ActorTrait justice4 = CreateTrait("justice4", "trait/justice4", "Knight");
            SafeSetStat(justice4.base_stats, strings.S.speed, 35f);
            SafeSetStat(justice4.base_stats, strings.S.targets, 7f);
            SafeSetStat(justice4.base_stats, strings.S.damage, 70f);
            AssetManager.traits.add(justice4);

            ActorTrait justice5 = CreateTrait("justice5", "trait/justice5", "Knight");
            SafeSetStat(justice5.base_stats, strings.S.speed, 45f);
            SafeSetStat(justice5.base_stats, strings.S.targets, 9f);
            SafeSetStat(justice5.base_stats, strings.S.damage, 180f);
            AssetManager.traits.add(justice5);

            ActorTrait justice6 = CreateTrait("justice6", "trait/justice6", "Knight");
            SafeSetStat(justice6.base_stats, strings.S.speed, 80f);
            SafeSetStat(justice6.base_stats, strings.S.targets, 10f);
            SafeSetStat(justice6.base_stats, strings.S.damage, 250f);
            AssetManager.traits.add(justice6);

            ActorTrait Knight1 = CreateTrait("Knight1", "trait/Knight1", "Knight");
            SafeSetStat(Knight1.base_stats , strings.S.damage, 30f);
            SafeSetStat(Knight1.base_stats , strings.S.health, 200f);
            SafeSetStat(Knight1.base_stats , strings.S.stamina, 10f);
            SafeSetStat(Knight1.base_stats , strings.S.mana, 10f);
            Knight1.action_special_effect += traitAction.Knight2_effectAction;
            Knight1.action_special_effect += traitAction.Knight1_Regen;
            AssetManager.traits.add(Knight1);

            ActorTrait Knight2 = CreateTrait("Knight2", "trait/Knight2", "Knight");
            SafeSetStat(Knight2.base_stats , strings.S.damage, 50f);
            SafeSetStat(Knight2.base_stats , strings.S.health, 300f);
            SafeSetStat(Knight2.base_stats , strings.S.accuracy, 1f);
            SafeSetStat(Knight2.base_stats , strings.S.multiplier_speed, 0.1f);
            SafeSetStat(Knight2.base_stats , strings.S.stamina, 20f);
            SafeSetStat(Knight2.base_stats , strings.S.mana, 20f);
            Knight2.action_special_effect += traitAction.Knight3_effectAction;
            Knight2.action_special_effect += traitAction.Knight2_Regen;
            AssetManager.traits.add(Knight2);

            ActorTrait Knight3 = CreateTrait("Knight3", "trait/Knight3", "Knight");
            SafeSetStat(Knight3.base_stats , strings.S.damage, 60f);
            SafeSetStat(Knight3.base_stats , strings.S.health, 400f);
            SafeSetStat(Knight3.base_stats , strings.S.armor, 5f);
            SafeSetStat(Knight3.base_stats , strings.S.targets, 0.1f);
            SafeSetStat(Knight3.base_stats , strings.S.accuracy, 2f);
            SafeSetStat(Knight3.base_stats , strings.S.multiplier_speed, 0.2f);
            SafeSetStat(Knight3.base_stats , strings.S.stamina, 30f);
            SafeSetStat(Knight3.base_stats , strings.S.mana, 30f);
            Knight3.action_special_effect += traitAction.Knight4_effectAction;
            Knight3.action_special_effect += traitAction.Knight3_Regen;
            AssetManager.traits.add(Knight3);

            ActorTrait Knight4 = CreateTrait("Knight4", "trait/Knight4", "Knight");
            SafeSetStat(Knight4.base_stats , strings.S.damage, 70f);
            SafeSetStat(Knight4.base_stats , strings.S.health, 500f);
            SafeSetStat(Knight4.base_stats , strings.S.speed, 5f);
            SafeSetStat(Knight4.base_stats , strings.S.armor, 10f);
            SafeSetStat(Knight4.base_stats , strings.S.targets, 1f);
            SafeSetStat(Knight4.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(Knight4.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(Knight4.base_stats , strings.S.multiplier_speed, 0.3f);
            SafeSetStat(Knight4.base_stats , strings.S.stamina, 40f);
            SafeSetStat(Knight4.base_stats , strings.S.mana, 40f);
            Knight4.action_special_effect += traitAction.Knight5_effectAction;
            Knight4.action_special_effect += traitAction.Knight4_Regen;
            AssetManager.traits.add(Knight4);

            ActorTrait Knight5 = CreateTrait("Knight5", "trait/Knight5", "Knight");
            SafeSetStat(Knight5.base_stats , strings.S.warfare, 3f);
            SafeSetStat(Knight5.base_stats , strings.S.damage, 100f);
            SafeSetStat(Knight5.base_stats , strings.S.health, 800f);
            SafeSetStat(Knight5.base_stats , strings.S.speed, 10f);
            SafeSetStat(Knight5.base_stats , strings.S.armor, 15f);
            SafeSetStat(Knight5.base_stats , strings.S.targets, 2f);
            SafeSetStat(Knight5.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(Knight5.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(Knight5.base_stats , strings.S.multiplier_speed, 0.4f);
            SafeSetStat(Knight5.base_stats , strings.S.stamina, 50f);
            SafeSetStat(Knight5.base_stats , strings.S.mana, 50f);
            Knight5.action_special_effect += traitAction.Knight6_effectAction;
            Knight5.action_special_effect += traitAction.Knight5_Regen;
            AssetManager.traits.add(Knight5);

            ActorTrait Knight6 = CreateTrait("Knight6", "trait/Knight6", "Knight");
            SafeSetStat(Knight6.base_stats , strings.S.warfare, 5f);
            SafeSetStat(Knight6.base_stats , strings.S.damage, 180f);
            SafeSetStat(Knight6.base_stats , strings.S.armor, 25f);
            SafeSetStat(Knight6.base_stats , strings.S.health, 1500f);
            SafeSetStat(Knight6.base_stats , strings.S.speed, 15f);
            SafeSetStat(Knight6.base_stats , strings.S.area_of_effect, 1f);
            SafeSetStat(Knight6.base_stats , strings.S.targets, 5f);
            SafeSetStat(Knight6.base_stats , strings.S.critical_chance, 0.3f);
            SafeSetStat(Knight6.base_stats , strings.S.accuracy, 15f);
            SafeSetStat(Knight6.base_stats , strings.S.multiplier_speed, 0.6f);
            SafeSetStat(Knight6.base_stats , strings.S.stamina, 70f);
            SafeSetStat(Knight6.base_stats , strings.S.mana, 70f);
            Knight6.action_special_effect += traitAction.Knight7_effectAction;
            Knight6.action_special_effect += traitAction.Knight6_Regen;
            AssetManager.traits.add(Knight6);

            ActorTrait warping1 = CreateTrait("warping1", "trait/warping1", "Knight");
            SafeSetStat(warping1.base_stats , strings.S.damage, 50f);
            SafeSetStat(warping1.base_stats , strings.S.health, 300f);
            SafeSetStat(warping1.base_stats , strings.S.accuracy, 1f);
            SafeSetStat(warping1.base_stats , strings.S.multiplier_speed, 0.1f);
            SafeSetStat(warping1.base_stats , strings.S.stamina, 20f);
            SafeSetStat(warping1.base_stats , strings.S.mana, 20f);
            warping1.action_special_effect += traitAction.warping1_Regen;
            AssetManager.traits.add(warping1);

            ActorTrait warping2 = CreateTrait("warping2", "trait/warping2", "Knight");
            SafeSetStat(warping2.base_stats , strings.S.damage, 60f);
            SafeSetStat(warping2.base_stats , strings.S.health, 400f);
            SafeSetStat(warping2.base_stats , strings.S.armor, 5f);
            SafeSetStat(warping2.base_stats , strings.S.targets, 0.1f);
            SafeSetStat(warping2.base_stats , strings.S.accuracy, 2f);
            SafeSetStat(warping2.base_stats , strings.S.multiplier_speed, 0.2f);
            SafeSetStat(warping2.base_stats , strings.S.stamina, 30f);
            SafeSetStat(warping2.base_stats , strings.S.mana, 30f);
            warping2.action_special_effect += traitAction.warping2_Regen;
            AssetManager.traits.add(warping2);

            ActorTrait warping3 = CreateTrait("warping3", "trait/warping3", "Knight");
            SafeSetStat(warping3.base_stats , strings.S.damage, 70f);
            SafeSetStat(warping3.base_stats , strings.S.health, 500f);
            SafeSetStat(warping3.base_stats , strings.S.speed, 5f);
            SafeSetStat(warping3.base_stats , strings.S.armor, 10f);
            SafeSetStat(warping3.base_stats , strings.S.targets, 1f);
            SafeSetStat(warping3.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(warping3.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(warping3.base_stats , strings.S.multiplier_speed, 0.3f);
            SafeSetStat(warping3.base_stats , strings.S.stamina, 40f);
            SafeSetStat(warping3.base_stats , strings.S.mana, 40f);
            warping3.action_special_effect += traitAction.warping3_Regen;
            AssetManager.traits.add(warping3);

            ActorTrait warping4 = CreateTrait("warping4", "trait/warping4", "Knight");
            SafeSetStat(warping4.base_stats , strings.S.warfare, 3f);
            SafeSetStat(warping4.base_stats , strings.S.damage, 100f);
            SafeSetStat(warping4.base_stats , strings.S.health, 800f);
            SafeSetStat(warping4.base_stats , strings.S.speed, 10f);
            SafeSetStat(warping4.base_stats , strings.S.armor, 15f);
            SafeSetStat(warping4.base_stats , strings.S.targets, 2f);
            SafeSetStat(warping4.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(warping4.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(warping4.base_stats , strings.S.multiplier_speed, 0.4f);
            SafeSetStat(warping4.base_stats , strings.S.stamina, 50f);
            SafeSetStat(warping4.base_stats , strings.S.mana, 50f);
            warping4.action_special_effect += traitAction.warping4_Regen;
            AssetManager.traits.add(warping4);

            ActorTrait warping5 = CreateTrait("warping5", "trait/warping5", "Knight");
            SafeSetStat(warping5.base_stats , strings.S.warfare, 5f);
            SafeSetStat(warping5.base_stats , strings.S.damage, 180f);
            SafeSetStat(warping5.base_stats , strings.S.armor, 25f);
            SafeSetStat(warping5.base_stats , strings.S.health, 1500f);
            SafeSetStat(warping5.base_stats , strings.S.speed, 15f);
            SafeSetStat(warping5.base_stats , strings.S.area_of_effect, 1f);
            SafeSetStat(warping5.base_stats , strings.S.targets, 5f);
            SafeSetStat(warping5.base_stats , strings.S.critical_chance, 0.3f);
            SafeSetStat(warping5.base_stats , strings.S.accuracy, 15f);
            SafeSetStat(warping5.base_stats , strings.S.multiplier_speed, 0.6f);
            SafeSetStat(warping5.base_stats , strings.S.stamina, 70f);
            SafeSetStat(warping5.base_stats , strings.S.mana, 70f);
            warping5.action_special_effect += traitAction.warping5_Regen;
            AssetManager.traits.add(warping5);
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}