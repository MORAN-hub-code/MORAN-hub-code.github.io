using System;
using UnityEngine;
using NCMS;

namespace 寒海的全解锁
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        public static bool load = true;
        void Update()
        {
          if (load || Input.GetKeyUp(KeyCode.F9) && Input.GetKeyUp(KeyCode.F10) || Input.GetKey(KeyCode.F9) && Input.GetKeyUp(KeyCode.F10) || Input.GetKey(KeyCode.F10) && Input.GetKeyUp(KeyCode.F9))
          {
            GameProgress.instance.unlockAllAchievements();
          	GameProgress.instance.debugUnlockAll();
            MonoBehaviour.print("已加载全解锁!");
            load = false;
          }
        }
    }
}