using System;
using UnityEngine;
using NCMS;

namespace 寒海的全解锁
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
			SmoothLoader.add(delegate
			{
              GameProgress.instance.unlockAllAchievements();
			}, "解锁全成就中", false, 0.01f);
			SmoothLoader.add(delegate
			{
          	  GameProgress.instance.debugUnlockAll();
			}, "解锁一大堆东西中", false, 0.01f);
        }
    }
}