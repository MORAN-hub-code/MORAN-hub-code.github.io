﻿using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NCMS.Utils;
using System.Reflection;
using Newtonsoft.Json;
using System.IO;

namespace MapMod
{
    class MapPatch
    {
        // For json deserialization
        internal class JsonConfig 
        {
            public int width;
            public int height;
        }
        public static void init()
        {
            Harmony.CreateAndPatchAll(typeof(MapPatch));
        }

        [HarmonyPatch(typeof(MapBox), "setMapSize")]
        [HarmonyPrefix]
        static void mapPatch(ref int pWidth, ref int pHeight)
        {
            // Json config value for setting width and heigh values useful so dont
            // have to close game and reset values every change
            var values = File.ReadAllText(@"Mods/MapSize/Code/config.json");
            var json = JsonConvert.DeserializeObject<JsonConfig>(values);

            // By setting either value to below zero in config wont set values
            // This is good for loading maps or just using standard sizes in game
            if (json.width < 0 || json.height < 0)
            {
                return;
            }
            pWidth = json.width;
            pHeight = json.height;
        }

        [HarmonyPatch(typeof(MapBox), "setMapSize")]
        [HarmonyPostfix]
        static void mapPatchCheck(int pWidth, int pHeight)
        {
            Debug.Log($"Map Width {pWidth}, Height {pHeight}");
        }
    }
}
