﻿using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Text;

namespace MapMod
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        public void Awake()
        {
            MapPatch.init();
        }

    }
}