Unzip file and place in game's mod folder
Tested using NML and version 0.22.9
Targeted Game Build: 558