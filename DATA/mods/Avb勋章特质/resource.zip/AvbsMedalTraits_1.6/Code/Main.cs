using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using HarmonyLib;

namespace avbmedaltraits{
    class Main : BasicMod<Main>{
        public static Main instance;
        static Harmony _harmony;
        protected override void OnModLoad(){
            Traits.init();
            _harmony = new Harmony("AvbMedals");
            _harmony.PatchAll();
        }
    }
	[HarmonyPatch(typeof(Actor), "newKillAction")]
	public class KilltoMedalTraitFunction{
		static bool Prefix(Actor __instance, Actor pDeadUnit, Kingdom pPrevKingdom, AttackType pAttackType)
    	{
			__instance.data.kills++;
			if (__instance.hasWeapon())
			{
				__instance.getWeapon().countKill();
			}
			if (__instance.isKingdomCiv() && pPrevKingdom.isCiv())
			{
				War tWar = World.world.wars.getWar(__instance.kingdom, pPrevKingdom, false);
				if (tWar != null)
				{
					if (tWar.isAttacker(__instance.kingdom))
					{
						tWar.increaseDeathsDefenders(pAttackType);
					}
					else
					{
						tWar.increaseDeathsAttackers(pAttackType);
					}
				}
			}
			if (!__instance.isAlive())
			{
				return false;
			}
			if (__instance.timer_action <= 0f)
			{
				__instance.makeWait(Randy.randomFloat(0.1f, 1f));
			}
			if (__instance.hasTrait("bloodlust"))
			{
				__instance.changeHappiness("just_killed", 0);
			}
			int tMoneys = pDeadUnit.giveAllLootAndMoney();
			__instance.addLoot(tMoneys);
			__instance.takeAllResources(pDeadUnit);
			if (__instance.data.kills > 10)
			{
				__instance.addTrait("veteran", false);
			}
			if (__instance.asset.is_humanoid) //Medal Checks
			{
				if (__instance.data.kills >= 1 && __instance.data.kills < 5)
				{
					__instance.addTrait("Bone Rank", false);
				}
				if (__instance.data.kills >= 5 && __instance.data.kills < 10)
				{
					__instance.addTrait("Wood Rank", false);
					__instance.removeTrait("Bone Rank");
				}
				if (__instance.data.kills >= 10 && __instance.data.kills < 15)
				{
					__instance.addTrait("Stone Rank", false);
					__instance.removeTrait("Wood Rank");
				}
				if (__instance.data.kills >= 15 && __instance.data.kills < 20)
				{
					__instance.addTrait("Copper Rank", false);
					__instance.removeTrait("Stone Rank");
				}
				if (__instance.data.kills >= 20 && __instance.data.kills < 25)
				{
					__instance.addTrait("Bronze Rank", false);
					__instance.removeTrait("Copper Rank");
				}
				if (__instance.data.kills >= 25 && __instance.data.kills < 30)
				{
					__instance.addTrait("Silver Rank", false);
					__instance.removeTrait("Bronze Rank");
				}
				if (__instance.data.kills >= 30 && __instance.data.kills < 35)
				{
					__instance.addTrait("Iron Rank", false);
					__instance.removeTrait("Silver Rank");
				}
				if (__instance.data.kills >= 35 && __instance.data.kills < 40)
				{
					__instance.addTrait("Steel Rank", false);
					__instance.removeTrait("Iron Rank");
				}
				if (__instance.data.kills >= 40 && __instance.data.kills < 50)
				{
					__instance.addTrait("Mythril Rank", false);
					__instance.removeTrait("Steel Rank");
				}
				if (__instance.data.kills >= 50 && __instance.data.kills < 100)
				{
					__instance.addTrait("Adamantine Rank", false);
					__instance.removeTrait("Mythril Rank");
				}
				if (__instance.data.kills >= 100 && __instance.data.kills < 150)
				{
					__instance.addTrait("Gem Rank", false);
					__instance.removeTrait("Adamantine Rank");
				}
				if (__instance.data.kills >= 150 && __instance.data.kills < 300)
				{
					__instance.addTrait("Ice Rank", false);
					__instance.removeTrait("Gem Rank");
				}
				if (__instance.data.kills >= 300 && __instance.data.kills < 500)
				{
					__instance.addTrait("Flame Rank", false);
					__instance.removeTrait("Ice Rank");
				}
				if (__instance.data.kills >= 500 && __instance.data.kills < 750)
				{
					__instance.addTrait("Crystal Rank", false);
					__instance.removeTrait("Flame Rank");
				}
				if (__instance.data.kills >= 750 && __instance.data.kills < 1000)
				{
					__instance.addTrait("Blood Rank", false);
					__instance.removeTrait("Crystal Rank");
				}
				if (__instance.data.kills >= 1000)
				{
					__instance.addTrait("Void Rank", false);
					__instance.removeTrait("Blood Rank");
				}
			}
			else { //Ribbon Checks
				if (__instance.data.kills >= 1 && __instance.data.kills < 5)
				{
					__instance.addTrait("Bone Grade", false);
				}
				if (__instance.data.kills >= 5 && __instance.data.kills < 10)
				{
					__instance.addTrait("Wood Grade", false);
					__instance.removeTrait("Bone Grade");
				}
				if (__instance.data.kills >= 10 && __instance.data.kills < 15)
				{
					__instance.addTrait("Stone Grade", false);
					__instance.removeTrait("Wood Grade");
				}
				if (__instance.data.kills >= 15 && __instance.data.kills < 20)
				{
					__instance.addTrait("Copper Grade", false);
					__instance.removeTrait("Stone Grade");
				}
				if (__instance.data.kills >= 20 && __instance.data.kills < 25)
				{
					__instance.addTrait("Bronze Grade", false);
					__instance.removeTrait("Copper Grade");
				}
				if (__instance.data.kills >= 25 && __instance.data.kills < 30)
				{
					__instance.addTrait("Silver Grade", false);
					__instance.removeTrait("Bronze Grade");
				}
				if (__instance.data.kills >= 30 && __instance.data.kills < 35)
				{
					__instance.addTrait("Iron Grade", false);
					__instance.removeTrait("Silver Grade");
				}
				if (__instance.data.kills >= 35 && __instance.data.kills < 40)
				{
					__instance.addTrait("Steel Grade", false);
					__instance.removeTrait("Iron Grade");
				}
				if (__instance.data.kills >= 40 && __instance.data.kills < 50)
				{
					__instance.addTrait("Mythril Grade", false);
					__instance.removeTrait("Steel Grade");
				}
				if (__instance.data.kills >= 50 && __instance.data.kills < 100)
				{
					__instance.addTrait("Adamantine Grade", false);
					__instance.removeTrait("Mythril Grade");
				}
				if (__instance.data.kills >= 100 && __instance.data.kills < 150)
				{
					__instance.addTrait("Gem Grade", false);
					__instance.removeTrait("Adamantine Grade");
				}
				if (__instance.data.kills >= 150 && __instance.data.kills < 300)
				{
					__instance.addTrait("Ice Grade", false);
					__instance.removeTrait("Gem Grade");
				}
				if (__instance.data.kills >= 300 && __instance.data.kills < 500)
				{
					__instance.addTrait("Flame Grade", false);
					__instance.removeTrait("Ice Grade");
				}
				if (__instance.data.kills >= 500 && __instance.data.kills < 750)
				{
					__instance.addTrait("Crystal Grade", false);
					__instance.removeTrait("Flame Grade");
				}
				if (__instance.data.kills >= 750 && __instance.data.kills < 1000)
				{
					__instance.addTrait("Blood Grade", false);
					__instance.removeTrait("Crystal Grade");
				}
				if (__instance.data.kills >= 1000)
				{
					__instance.addTrait("Void Grade", false);
					__instance.removeTrait("Blood Grade");
				}
			}//medal trait check end
			__instance.addExperience(pDeadUnit.asset.experience_given);
			__instance.addRenown(pDeadUnit.asset.experience_given);
			if (__instance.hasTrait("madness"))
			{
				__instance.restoreHealth(__instance.getMaxHealthPercent(0.05f));
			}
			if (__instance.understandsHowToUseItems() && !pDeadUnit.hasTrait("infected") && __instance.canTakeItems())
			{
				__instance.takeItems(pDeadUnit, 1f, 0);
			}
			__instance.checkRageDemon();
			return false;
		}
	}
}