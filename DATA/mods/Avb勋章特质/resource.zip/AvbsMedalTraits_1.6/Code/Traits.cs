using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using ai;
using NeoModLoader.api.attributes;
using NeoModLoader.api; 
using NeoModLoader.General;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Reflection;
using NCMS.Utils;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace avbmedaltraits{
    internal static class Traits{
        public static void init(){
            AssetManager.trait_groups.add(new ActorTraitGroupAsset{
               id = "Medal",
               name = "trait_group_medal",
               color = "#AA6C39"
            }); 
//Ranks
  //Bone (1 kill)
  //Wood (5 kills)
  //Stone (10 kills)
  //Copper (15 kills)
  //Bronze (20 kills) 
  //Silver (25 kills)
  //Iron (30 kills)
  //Steel (35 kills)
  //Mythril (40 kills)
  //Adamantine (50 kills)
  //Gem (100 kills)
  //Ice (150 kills)
  //Flame (300 kills)
  //Crystal (500 kills)
  //Blood (750 kills)
  //Void (1000 kills)
//Medal Traits
        #region boneMedal
            ActorTrait boneMedal = new ActorTrait()
            {
                id = "Bone Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalBone",
                needs_to_be_explored = false
            };
            boneMedal.base_stats = new BaseStats();
            boneMedal.base_stats.set("diplomacy", 1f);
            boneMedal.base_stats.set("warfare", 1f);
            boneMedal.base_stats.set("stewardship", 1f);
            AssetManager.traits.add(boneMedal);
        #endregion
        
        #region woodMedal
            ActorTrait woodMedal = new ActorTrait()
            {
                id = "Wood Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalWood",
                needs_to_be_explored = false
            };
            woodMedal.base_stats = new BaseStats();
            woodMedal.base_stats.set("diplomacy", 2f);
            woodMedal.base_stats.set("warfare", 2f);
            woodMedal.base_stats.set("stewardship", 2f);
            AssetManager.traits.add(woodMedal);
        #endregion

        #region stoneMedal
            ActorTrait stoneMedal = new ActorTrait()
            {
                id = "Stone Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalStone",
                needs_to_be_explored = false
            };
            stoneMedal.base_stats = new BaseStats();
            stoneMedal.base_stats.set("diplomacy", 3f);
            stoneMedal.base_stats.set("warfare", 3f);
            stoneMedal.base_stats.set("stewardship", 3f);
            AssetManager.traits.add(stoneMedal);
        #endregion

        #region copperMedal
            ActorTrait copperMedal = new ActorTrait()
            {
                id = "Copper Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalCopper",
                needs_to_be_explored = false
            };
            copperMedal.base_stats = new BaseStats();
            copperMedal.base_stats.set("diplomacy", 5f);
            copperMedal.base_stats.set("warfare", 5f);
            copperMedal.base_stats.set("stewardship", 5f);
            AssetManager.traits.add(copperMedal);
        #endregion

        #region bronzeMedal
            ActorTrait bronzeMedal = new ActorTrait()
            {
                id = "Bronze Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalBronze",
                needs_to_be_explored = false
            };
            bronzeMedal.base_stats = new BaseStats();
            bronzeMedal.base_stats.set("diplomacy", 5f);
            bronzeMedal.base_stats.set("warfare", 5f);
            bronzeMedal.base_stats.set("stewardship", 5f);
            bronzeMedal.base_stats.set("armor", 1f);
            AssetManager.traits.add(bronzeMedal);
        #endregion

        #region silverMedal
            ActorTrait silverMedal = new ActorTrait()
            {
                id = "Silver Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalSilver",
                needs_to_be_explored = false
            };
            silverMedal.base_stats = new BaseStats();
            silverMedal.base_stats.set("diplomacy", 5f);
            silverMedal.base_stats.set("warfare", 5f);
            silverMedal.base_stats.set("stewardship", 5f);
            silverMedal.base_stats.set("armor", 3f);
            AssetManager.traits.add(silverMedal);
        #endregion

        #region ironMedal
            ActorTrait ironMedal = new ActorTrait()
            {
                id = "Iron Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalIron",
                needs_to_be_explored = false
            };
            ironMedal.base_stats = new BaseStats();
            ironMedal.base_stats.set("diplomacy", 8f);
            ironMedal.base_stats.set("warfare", 8f);
            ironMedal.base_stats.set("stewardship", 8f);
            ironMedal.base_stats.set("armor", 5f);
            AssetManager.traits.add(ironMedal);
        #endregion

        #region steelMedal
            ActorTrait steelMedal = new ActorTrait()
            {
                id = "Steel Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalSteel",
                needs_to_be_explored = false
            };
            steelMedal.base_stats = new BaseStats();
            steelMedal.base_stats.set("diplomacy", 8f);
            steelMedal.base_stats.set("warfare", 8f);
            steelMedal.base_stats.set("stewardship", 8f);
            steelMedal.base_stats.set("armor", 8f);
            AssetManager.traits.add(steelMedal);
        #endregion

        #region mythrilMedal
            ActorTrait mythrilMedal = new ActorTrait()
            {
                id = "Mythril Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalMythril",
                needs_to_be_explored = false
            };
            mythrilMedal.base_stats = new BaseStats();
            mythrilMedal.base_stats.set("diplomacy", 10f);
            mythrilMedal.base_stats.set("warfare", 10f);
            mythrilMedal.base_stats.set("stewardship", 10f);
            mythrilMedal.base_stats.set("armor", 10f);
            AssetManager.traits.add(mythrilMedal);
        #endregion

        #region adamantineMedal
            ActorTrait adamantineMedal = new ActorTrait()
            {
                id = "Adamantine Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalAdamantine",
                needs_to_be_explored = false
            };
            adamantineMedal.base_stats = new BaseStats();
            adamantineMedal.base_stats.set("diplomacy", 15f);
            adamantineMedal.base_stats.set("warfare", 15f);
            adamantineMedal.base_stats.set("stewardship", 15f);
            adamantineMedal.base_stats.set("armor", 15f);
            AssetManager.traits.add(adamantineMedal);
        #endregion

        #region gemMedal
            ActorTrait gemMedal = new ActorTrait()
            {
                id = "Gem Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalGem",
                needs_to_be_explored = false
            };
            gemMedal.base_stats = new BaseStats();
            gemMedal.base_stats.set("diplomacy", 20f);
            gemMedal.base_stats.set("warfare", 20f);
            gemMedal.base_stats.set("stewardship", 20f);
            gemMedal.base_stats.set("armor", 20f);
            AssetManager.traits.add(gemMedal);
        #endregion

        #region iceMedal
            ActorTrait iceMedal = new ActorTrait()
            {
                id = "Ice Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalIce",
                needs_to_be_explored = false
            };
            iceMedal.base_stats = new BaseStats();
            iceMedal.base_stats.set("diplomacy", 25f);
            iceMedal.base_stats.set("warfare", 25f);
            iceMedal.base_stats.set("stewardship", 25f);
            iceMedal.base_stats.set("armor", 25f);
            AssetManager.traits.add(iceMedal);
        #endregion

        #region flameMedal
            ActorTrait flameMedal = new ActorTrait()
            {
                id = "Flame Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalFlame",
                needs_to_be_explored = false
            };
            flameMedal.base_stats = new BaseStats();
            flameMedal.base_stats.set("diplomacy", 35f);
            flameMedal.base_stats.set("warfare", 35f);
            flameMedal.base_stats.set("stewardship", 35f);
            flameMedal.base_stats.set("armor", 35f);
            AssetManager.traits.add(flameMedal);
        #endregion

        #region crystalMedal
            ActorTrait crystalMedal = new ActorTrait()
            {
                id = "Crystal Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalCrystal",
                needs_to_be_explored = false
            };
            crystalMedal.base_stats = new BaseStats();
            crystalMedal.base_stats.set("diplomacy", 50f);
            crystalMedal.base_stats.set("warfare", 50f);
            crystalMedal.base_stats.set("stewardship", 50f);
            crystalMedal.base_stats.set("armor", 50f);
            AssetManager.traits.add(crystalMedal);
        #endregion

        #region bloodMedal
            ActorTrait bloodMedal = new ActorTrait()
            {
                id = "Blood Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalBlood",
                needs_to_be_explored = false
            };
            bloodMedal.base_stats = new BaseStats();
            bloodMedal.base_stats.set("diplomacy", 75f);
            bloodMedal.base_stats.set("warfare", 75f);
            bloodMedal.base_stats.set("stewardship", 75f);
            bloodMedal.base_stats.set("armor", 75f);
            AssetManager.traits.add(bloodMedal);
        #endregion

        #region voidMedal
            ActorTrait voidMedal = new ActorTrait()
            {
                id = "Void Rank",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconMedalVoid",
                needs_to_be_explored = false
            };
            voidMedal.base_stats = new BaseStats();
            voidMedal.base_stats.set("diplomacy", 100f);
            voidMedal.base_stats.set("warfare", 100f);
            voidMedal.base_stats.set("stewardship", 100f);
            voidMedal.base_stats.set("armor", 100f);
            AssetManager.traits.add(voidMedal);
        #endregion
// //Non-Civ Ribbon Traits-------------------------------------------------------------------------------------------------------
        #region boneGrade
            ActorTrait boneGrade = new ActorTrait()
            {
                id = "Bone Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionBone",
                needs_to_be_explored = false
            };
            boneGrade.base_stats = new BaseStats();
            boneGrade.base_stats.set("damage", 1f);
            AssetManager.traits.add(boneGrade);
        #endregion
        
        #region woodGrade
            ActorTrait woodGrade = new ActorTrait()
            {
                id = "Wood Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionWood",
                needs_to_be_explored = false
            };
            woodGrade.base_stats = new BaseStats();
            woodGrade.base_stats.set("damage", 2f);
            woodGrade.base_stats.set("critical_chance", 0.05f);
            AssetManager.traits.add(woodGrade);
        #endregion

        #region stoneGrade
            ActorTrait stoneGrade = new ActorTrait()
            {
                id = "Stone Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionStone",
                needs_to_be_explored = false
            };
            stoneGrade.base_stats = new BaseStats();
            stoneGrade.base_stats.set("damage", 3f);
            stoneGrade.base_stats.set("critical_chance", 0.10f);
            AssetManager.traits.add(stoneGrade);
        #endregion

        #region copperGrade
            ActorTrait copperGrade = new ActorTrait()
            {
                id = "Copper Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionCopper",
                needs_to_be_explored = false
            };
            copperGrade.base_stats = new BaseStats();
            copperGrade.base_stats.set("damage", 4f);
            copperGrade.base_stats.set("critical_chance", 0.10f);
            copperGrade.base_stats.set("speed", 1f);
            AssetManager.traits.add(copperGrade);
        #endregion

        #region bronzeGrade
            ActorTrait bronzeGrade = new ActorTrait()
            {
                id = "Bronze Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionBronze",
                needs_to_be_explored = false
            };
            bronzeGrade.base_stats = new BaseStats();
            bronzeGrade.base_stats.set("damage", 5f);
            bronzeGrade.base_stats.set("critical_chance", 0.15f);
            bronzeGrade.base_stats.set("speed", 5f);
            bronzeGrade.base_stats.set("armor", 1f);
            AssetManager.traits.add(bronzeGrade);
        #endregion

        #region silverGrade
            ActorTrait silverGrade = new ActorTrait()
            {
                id = "Silver Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionSilver",
                needs_to_be_explored = false
            };
            silverGrade.base_stats = new BaseStats();
            silverGrade.base_stats.set("damage", 8f);
            silverGrade.base_stats.set("critical_chance", 0.2f);
            silverGrade.base_stats.set("speed", 8f);
            silverGrade.base_stats.set("armor", 3f);
            AssetManager.traits.add(silverGrade);
        #endregion

        #region ironGrade
            ActorTrait ironGrade = new ActorTrait()
            {
                id = "Iron Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionIron",
                needs_to_be_explored = false
            };
            ironGrade.base_stats = new BaseStats();
            ironGrade.base_stats.set("damage", 10f);
            ironGrade.base_stats.set("critical_chance", 0.25f);
            ironGrade.base_stats.set("speed", 10f);
            ironGrade.base_stats.set("armor", 5f);
            AssetManager.traits.add(ironGrade);
        #endregion

        #region steelGrade
            ActorTrait steelGrade = new ActorTrait()
            {
                id = "Steel Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionSteel",
                needs_to_be_explored = false
            };
            steelGrade.base_stats = new BaseStats();
            steelGrade.base_stats.set("damage", 12f);
            steelGrade.base_stats.set("critical_chance", 0.3f);
            steelGrade.base_stats.set("speed", 12f);
            steelGrade.base_stats.set("armor", 8f);
            AssetManager.traits.add(steelGrade);
        #endregion

        #region mythrilGrade
            ActorTrait mythrilGrade = new ActorTrait()
            {
                id = "Mythril Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionMythril",
                needs_to_be_explored = false
            };
            mythrilGrade.base_stats = new BaseStats();
            mythrilGrade.base_stats.set("damage", 13f);
            mythrilGrade.base_stats.set("critical_chance", 0.35f);
            mythrilGrade.base_stats.set("speed", 13f);
            mythrilGrade.base_stats.set("armor", 10f);
            AssetManager.traits.add(mythrilGrade);
        #endregion

        #region adamantineGrade
            ActorTrait adamantineGrade = new ActorTrait()
            {
                id = "Adamantine Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionAdamantine",
                needs_to_be_explored = false
            };
            adamantineGrade.base_stats = new BaseStats();
            adamantineGrade.base_stats.set("damage", 15f);
            adamantineGrade.base_stats.set("critical_chance", 0.4f);
            adamantineGrade.base_stats.set("speed", 15f);
            adamantineGrade.base_stats.set("armor", 15f);
            AssetManager.traits.add(adamantineGrade);
        #endregion

        #region gemGrade
            ActorTrait gemGrade = new ActorTrait()
            {
                id = "Gem Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionGem",
                needs_to_be_explored = false
            };
            gemGrade.base_stats = new BaseStats();
            gemGrade.base_stats.set("damage", 10f);
            gemGrade.base_stats.set("critical_chance", 0.4f);
            gemGrade.base_stats.set("speed", 10f);
            gemGrade.base_stats.set("armor", 20f);
            AssetManager.traits.add(gemGrade);
        #endregion

        #region iceGrade
            ActorTrait iceGrade = new ActorTrait()
            {
                id = "Ice Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionIce",
                needs_to_be_explored = false
            };
            iceGrade.base_stats = new BaseStats();
            iceGrade.base_stats.set("damage", 15f);
            iceGrade.base_stats.set("critical_chance", 0.45f);
            iceGrade.base_stats.set("speed", 15f);
            iceGrade.base_stats.set("armor", 25f);
            AssetManager.traits.add(iceGrade);
        #endregion

        #region flameGrade
            ActorTrait flameGrade = new ActorTrait()
            {
                id = "Flame Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionFlame",
                needs_to_be_explored = false
            };
            flameGrade.base_stats = new BaseStats();
            flameGrade.base_stats.set("damage", 20f);
            flameGrade.base_stats.set("critical_chance", 0.5f);
            flameGrade.base_stats.set("speed", 20f);
            flameGrade.base_stats.set("armor", 35f);
            AssetManager.traits.add(flameGrade);
        #endregion

        #region crystalGrade
            ActorTrait crystalGrade = new ActorTrait()
            {
                id = "Crystal Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionCrystal",
                needs_to_be_explored = false
            };
            crystalGrade.base_stats = new BaseStats();
            crystalGrade.base_stats.set("damage", 25f);
            crystalGrade.base_stats.set("critical_chance", 0.6f);
            crystalGrade.base_stats.set("speed", 25f);
            crystalGrade.base_stats.set("armor", 50f);
            AssetManager.traits.add(crystalGrade);
        #endregion

        #region bloodGrade
            ActorTrait bloodGrade = new ActorTrait()
            {
                id = "Blood Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionBlood",
                needs_to_be_explored = false
            };
            bloodGrade.base_stats = new BaseStats();
            bloodGrade.base_stats.set("damage", 35f);
            bloodGrade.base_stats.set("critical_chance", 0.85f);
            bloodGrade.base_stats.set("speed", 35f);
            bloodGrade.base_stats.set("armor", 75f);
            AssetManager.traits.add(bloodGrade);
        #endregion

        #region voidGrade
            ActorTrait voidGrade = new ActorTrait()
            {
                id = "Void Grade",
                group_id = "Medal",
                path_icon = $"ui/Icons/iconRibbionVoid",
                needs_to_be_explored = false
            };
            voidGrade.base_stats = new BaseStats();
            voidGrade.base_stats.set("damage", 50f);
            voidGrade.base_stats.set("critical_chance", 1f);
            voidGrade.base_stats.set("speed", 50f);
            voidGrade.base_stats.set("armor", 100f);
            AssetManager.traits.add(voidGrade);
        #endregion
        }//end of trait creation
    }
}