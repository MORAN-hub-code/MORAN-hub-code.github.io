using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoCopilot.code
{
    public class WitchcraftConfig
    {
        /// <summary>
        /// 天赋随机概率（默认0.15 = 15%）
        public static float TalentRandomChance { get; set; } = 0.15f;
        
        /// <summary>
        /// flair1权重（默认5442）
        public static float Flair1Weight { get; set; } = 5442;
        
        /// <summary>
        /// flair2权重（默认2750）
        public static float Flair2Weight { get; set; } = 2750;
        
        /// <summary>
        /// flair3权重（默认1200）
        public static float Flair3Weight { get; set; } = 1200;
        
        /// <summary>
        /// flair4权重（默认500）
        public static float Flair4Weight { get; set; } = 500;
        
        /// <summary>
        /// flair5权重（默认100）
        public static float Flair5Weight { get; set; } = 100;
        
        /// <summary>
        /// flair6权重（默认6）
        public static float Flair6Weight { get; set; } = 6;
        
        /// <summary>
        /// flair7权重（默认2）
        public static float Flair7Weight { get; set; } = 2;
        
        /// <summary>
        /// 天赋随机概率配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void p_gift(float pCurrentValue)
        {
            TalentRandomChance = pCurrentValue;
        }
        
        /// <summary>
        /// flair1权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_1(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair1Weight = 5442;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair1Weight = value;
            }
        }
        
        /// <summary>
        /// flair2权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_2(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair2Weight = 2750;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair2Weight = value;
            }
        }
        
        /// <summary>
        /// flair3权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_3(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair3Weight = 1200;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair3Weight = value;
            }
        }
        
        /// <summary>
        /// flair4权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_4(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair4Weight = 500;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair4Weight = value;
            }
        }
        
        /// <summary>
        /// flair5权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_5(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair5Weight = 100;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair5Weight = value;
            }
        }
        
        /// <summary>
        /// flair6权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_6(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair6Weight = 6;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair6Weight = value;
            }
        }
        
        /// <summary>
        /// flair7权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void f_weight_7(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Flair7Weight = 2;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Flair7Weight = value;
            }
        }
    }
}