using UnityEngine;
using System.Collections.Generic;

namespace VideoCopilot.code.utils;

public static class ActorExtensions
{
    private const string yuanneng_key = "wushu.yuannengNum";
    private const string meditation_key = "wushu.meditationNum";
    private const string resurrection_key = "wushu.resurrectionNum";
    private const string Rresurrection_key = "wushu.RresurrectionNum";
    // 头衔管理相关常量和方法
    private const string title_guid_key = "attribute.title_guid";
    
    public static float GetRresurrection(this Actor actor)
    {
        actor.data.get(Rresurrection_key, out float val, 1);
        return val;
    }
    public static void SetRresurrection(this Actor actor, float val)
    {
        actor.data.set(Rresurrection_key, val);
    }
    public static void ChangeRresurrection(this Actor actor, float delta)
    {
        actor.data.get(Rresurrection_key, out float val, 0);
        val += delta;
        actor.data.set(Rresurrection_key, Mathf.Max(1, val));
    }

    public static float GetResurrection(this Actor actor)
    {
        actor.data.get(resurrection_key, out float val, 0);
        return val;
    }
    public static void SetResurrection(this Actor actor, float val)
    {
        actor.data.set(resurrection_key, val);
    }
    public static void ChangeResurrection(this Actor actor, float delta)
    {
        actor.data.get(resurrection_key, out float val, 0);
        val += delta;
        actor.data.set(resurrection_key, Mathf.Max(0, val));
    }

    public static float GetMeditation(this Actor actor)
    {
        actor.data.get(meditation_key, out float val, 0);
        return val;
    }
    public static void SetMeditation(this Actor actor, float val)
    {
        actor.data.set(meditation_key, val);
    }
    public static void ChangeMeditation(this Actor actor, float delta)
    {
        actor.data.get(meditation_key, out float val, 0);
        val += delta;
        actor.data.set(meditation_key, val);
    }

    public static float GetYuanNeng(this Actor actor)
    {
        actor.data.get(yuanneng_key, out float val, 0);

        return val;
    }

    public static void SetYuanNeng(this Actor actor, float val)
    {
        actor.data.set(yuanneng_key, val);
    }

    public static void ChangeYuanNeng(this Actor actor, float delta)
    {
        actor.data.get(yuanneng_key, out float val, 0);
        val += delta;
        actor.data.set(yuanneng_key, Mathf.Max(0, val));
    }
    
    // 头衔管理扩展方法
    public static string GetTitle(this Actor actor, string title_guid)
    {
        actor.data.get(title_guid, out string title, "头衔");
        return title;
    }
    
    public static List<string> GetTitleGuids(this Actor actor)
    {
        actor.data.get(title_guid_key, out string title_guids_str);
        if (string.IsNullOrEmpty(title_guids_str))
        {
            return new List<string>();
        }
        return new List<string>(title_guids_str.Split(','));
    }
    
    public static void AddTitleGuid(this Actor actor, string title_guid)
    {
        var title_guids = actor.GetTitleGuids();
        if (!title_guids.Contains(title_guid))
        {
            title_guids.Add(title_guid);
            actor.data.set(title_guid_key, string.Join(",", title_guids));
        }
    }
    
    public static void RemoveTitleGuid(this Actor actor, string title_guid)
    {
        var title_guids = actor.GetTitleGuids();
        if (title_guids.Contains(title_guid))
        {
            title_guids.Remove(title_guid);
            actor.data.set(title_guid_key, string.Join(",", title_guids));
        }
    }
    
    // 血脉头衔管理方法
    private const string clanflair_title_key = "attribute.clanflair_title";
    
    public static void SetClanFlairTitle(this Actor actor, string clanFlairId)
    {
        // 根据血脉ID添加对应的头衔
        switch (clanFlairId)
        {
            case "ClanFlair1": // 巫师血脉·初源
                SetTitle(actor, "clanflair1_title", "巫师血脉·初源", new Color(0.5f, 0.5f, 0.5f, 1f));//#808080
                break;
            case "ClanFlair2": // 巫师血脉·承续
                SetTitle(actor, "clanflair2_title", "巫师血脉·承续", new Color(0.2f, 0.8f, 0.2f, 1f));//#33CC33
                break;
            case "ClanFlair3": // 巫师血脉·潮汐
                SetTitle(actor, "clanflair3_title", "巫师血脉·潮汐", new Color(1f, 0.6f, 0.2f, 1f));//#FF9933
                break;
            case "ClanFlair4": // 巫师血脉·铭刻
                SetTitle(actor, "clanflair4_title", "巫师血脉·铭刻", new Color(0.8f, 0.2f, 0.8f, 1f));//#CC33CC
                break;
            case "ClanFlair5": // 巫师血脉·始祖
                SetTitle(actor, "clanflair5_title", "巫师血脉·始祖", new Color(1f, 0.8f, 0.2f, 1f));//#FFCC33
                break;
        }
    }
    
    // 设置头衔的方法
    public static void SetTitle(this Actor actor, string title_guid, string title_text, Color title_color)
    {
        actor.data.set(title_guid, title_text);
        actor.AddTitleGuid(title_guid);
        string colorHex = ColorUtility.ToHtmlStringRGBA(title_color);
        actor.data.set("attribute.title_color_" + title_guid, colorHex);
    }
    
    // 移除头衔的方法
    public static void RemoveTitle(this Actor actor, string title_guid)
    {
        actor.RemoveTitleGuid(title_guid);
    }
}