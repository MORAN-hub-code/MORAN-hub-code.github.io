using UnityEngine;

namespace VideoCopilot.code;

public class CallBack
{
    public static float temp1;
    public static float temp2;
    public static void TSOTW_ADD(string pCurrentValue)
    {
       bool bol = float.TryParse(pCurrentValue,out temp1);
       if (bol)
       {
           Globals.TsotwAdd = temp1;
       }
       else
       {
           Globals.TsotwAdd = 1000.0f;
           Debug.Log("数值格式不正确,请检查");
       }
    }public static void TSOTW_INIT(string pCurrentValue)
    {
       bool bol = float.TryParse(pCurrentValue,out temp2);
       if (bol)
       {
           Globals.baseTsotw = temp2;
       }
       else
       {
           Globals.baseTsotw = 10000.0f;
           Debug.Log("数值格式不正确,请检查");
       }
    }
    
    // 天赋配置回调方法
    public static void p_gift(float pCurrentValue)
    {
        WitchcraftConfig.p_gift(pCurrentValue);
    }
    
    public static void f_weight_1(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_1(pCurrentValue);
    }
    
    public static void f_weight_2(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_2(pCurrentValue);
    }
    
    public static void f_weight_3(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_3(pCurrentValue);
    }
    
    public static void f_weight_4(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_4(pCurrentValue);
    }
    
    public static void f_weight_5(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_5(pCurrentValue);
    }
    
    public static void f_weight_6(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_6(pCurrentValue);
    }
    
    public static void f_weight_7(string pCurrentValue)
    {
        WitchcraftConfig.f_weight_7(pCurrentValue);
    }
}