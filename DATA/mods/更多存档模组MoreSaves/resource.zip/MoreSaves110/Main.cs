﻿using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using HarmonyLib;
using NeoModLoader.api;
using UnityEngine;

namespace MoreSaves {
    internal class Main : BasicMod<Main> {
        private int _currentMaxSlot = 30;

        [HarmonyPatch(typeof(SaveManager), nameof(SaveManager.saveWorldToDirectory))]
        [HarmonyPostfix]
        public static void saveWorldToDirectory(string pFolder, bool pCompress, bool pCheckFolder) {
            Instance.AddRows((Instance.NeededSaves() + 2) / 3 * 3 / 3);
        }

        protected override void OnModLoad() {
            ScrollWindow.showWindow("saves_list");
            ScrollWindow.get("saves_list").clickHide();

            Harmony.CreateAndPatchAll(GetType());

            AddRows((NeededSaves() + 2) / 3 * 3 / 3);
        }

        private void AddRows(int amount) {
            GameObject window = GameObject.Find("/Canvas Container Main/Canvas - Windows/windows/saves_list");
            GameObject content = window.transform.Find("Background/Scroll View/Viewport/Content").gameObject;
            GameObject row = content.transform.Find("Boxes/Row").gameObject;
            SaveSlotWindow saveSlotWindow = window.GetComponent<SaveSlotWindow>();

            for (int i = 0; i < amount; i++) {
                GameObject newRow = Instantiate(row, row.transform.parent);
                BoxPreview box1 = newRow.transform.Find("BoxPreview 1").GetComponent<BoxPreview>();
                BoxPreview box2 = newRow.transform.Find("BoxPreview 2").GetComponent<BoxPreview>();
                BoxPreview box3 = newRow.transform.Find("BoxPreview 3").GetComponent<BoxPreview>();

                box1.setSlot(++_currentMaxSlot);
                box2.setSlot(++_currentMaxSlot);
                box3.setSlot(++_currentMaxSlot);

                saveSlotWindow.previews.Add(box1);
                saveSlotWindow.previews.Add(box2);
                saveSlotWindow.previews.Add(box3);
            }
        }

        private int NeededSaves() {
            return (from directory in Directory.GetDirectories(SaveManager.generateMainPath("saves"))
                    let match = Regex.Match(Path.GetFileName(directory), @"^(save)(\d+)$")
                    where match.Success
                          && SaveManager.doesSaveExist(directory + "\\")
                          && int.Parse(match.Groups[2].Value) != 7734
                    select int.Parse(match.Groups[2].Value) - _currentMaxSlot + 1).Prepend(0)
                .Max();
        }
    }
}