﻿using UnityEngine;

namespace MoreSaves {
    internal static class GameObjectExtension {
        public static GameObject Find(this GameObject parent, string name) {
            foreach (Transform child in parent.transform) {
                if (child.name == name) {
                    return child.gameObject;
                }

                GameObject result = Find(child.gameObject, name);

                if (result != null) {
                    return result;
                }
            }

            return null;
        }
    }
}