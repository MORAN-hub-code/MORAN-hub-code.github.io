﻿using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using HarmonyLib;
using NeoModLoader.api;
using UnityEngine;

namespace MoreSaves {
    internal class Main : BasicMod<Main> {
        private int _currentSlots = 60;
        private GameObject _row;
        private SaveSlotWindow _saveSlotWindow;

        [HarmonyPatch(typeof(WindowPreloader), nameof(WindowPreloader.finalizeWindowsPreloading))]
        [HarmonyPostfix]
        public static void finalizeWindowsPreloading() {
            GameObject window = GameObject.Find("/Canvas Container Main/Canvas - Windows/windows/saves_list");
            Instance._row = window.Find("Row (19) - 57-60");
            Instance._saveSlotWindow = window.GetComponent<SaveSlotWindow>();

            ScrollWindow.showWindow("saves_list");
            ScrollWindow.get("saves_list").clickHide();

            Instance.AddRows(Instance.CalculateExtraRows());
        }

        [HarmonyPatch(typeof(SaveManager), nameof(SaveManager.saveWorldToDirectory))]
        [HarmonyPostfix]
        public static void saveWorldToDirectory(string pFolder, bool pCompress, bool pCheckFolder) {
            Instance.AddRows(Instance.CalculateExtraRows());
        }

        protected override void OnModLoad() {
            Harmony.CreateAndPatchAll(GetType());
        }

        private void AddRows(int amount) {
            for (int i = 0; i < amount; i++) {
                GameObject newRow = Instantiate(_row, _row.transform.parent);

                foreach (Transform child in newRow.transform) {
                    BoxPreview box = child.GetComponent<BoxPreview>();
                    box.setSlot(++_currentSlots);
                    _saveSlotWindow.previews.Add(box);
                }
            }
        }

        private int CalculateExtraRows() {
            string savesFolder = $@"{Application.persistentDataPath}\saves";
            string[] saveDirectories = Directory.GetDirectories(savesFolder);

            int neededSaves = saveDirectories.Select(Path.GetFileName)
                .Select(fileName => Regex.Match(fileName, @"^save(\d+)$"))
                .Where(match => match.Success)
                .Select(match => int.Parse(match.Groups[1].Value))
                .Where(slot => slot != 7734 && SaveManager.doesSaveExist($@"{savesFolder}\save{slot}\"))
                .Select(slot => slot - _currentSlots + 1)
                .Append(0)
                .Max();

            return (neededSaves + 2) / 3 * 3 / 3;
        }
    }
}