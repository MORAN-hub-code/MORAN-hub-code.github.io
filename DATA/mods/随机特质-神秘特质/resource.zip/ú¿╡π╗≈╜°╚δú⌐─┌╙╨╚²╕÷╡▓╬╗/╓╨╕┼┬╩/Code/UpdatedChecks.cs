using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using HarmonyLib;
using NCMS.Utils;
using Newtonsoft.Json;

namespace bbox
{
    class VerySmallTinyLittleMicroMiniPP
    {
        
        public static List<String> RankIds = new List<string> { "Mizunoto", "Mizunoe", "Kanoto", "Kanoe", "Tsuchi_noto", "Tsuchi_noe", "Hinoto", "Hinoe", "Kinoto", "Kinoe", "Hashira"};
         public static List<String> OniRanks = new List<string> { "upperOne", "upperTwo", "upperThree", "upperFour", "upperFive", "upperSix", "lowerOne", "lowerTwo", "lowerThree", "lowerFour", "lowerFive", "lowerSix" };
        //public static List<string> TraitsID = new List<string> {"scar_of_divinity", "flesh_eater", "shiny", "super_health", "death_mark", "energized", "ratKing", "rat", "healing_aura", "savage", "miner", "veteran", "wise", "strong_minded", "peaceful", "zombie", "infected", "mushSpores", "tumorInfection", "plague", "blessed", "cursed", "evil", "kingslayer", "mageslayer", "dragonslayer","giant","tiny", "madness", "immortal", "crippled", "golden_tooth", "eyepatch", "skin_burns","tough", "strong", "weak", "stupid", "genius", "regeneration", "ugly", "fat", "attractive", "fast", "slow", "gluttonous", "burning_feet", "flower_prints","acid_touch","acid_blood", "acid_proof", "fire_blood", "fire_proof", "freeze_proof", "cold_aura", "bomberman", "pyromaniac","greedy","weightless","poisonous","venomous","poison_immune", "eagle_eyed","paranoid","honest", "short_sighted","content","lucky", "unlucky","immune","agile","deceitful","ambitious","bloodlust","pacifist",};
        public static void init(){
            var Units = MapBox.instance.units.getSimpleList();
            foreach(var unit in Units)
            {   
                removeTraits(unit);
                RandomizeTraits(unit);

            }
        }

        public static void removeTraits(Actor unit){ 
            //List<ActorTrait> traits = AssetManager.traits.list;
            unit.updateStats();
            List<string> NewList = unit.data.traits;
            //Debug.Log("Remove traits called");
            if(NewList.Count > 1000){
            for(int i = 1000; i < NewList.Count; i++){
                 if(!RankIds.Contains(NewList[i]) && !OniRanks.Contains(NewList[i])){
                    unit.removeTrait(NewList[i]);
                 }
            }
            }
        }
        public static void RandomizeTraits(Actor unit){
            List<ActorTrait> traits = AssetManager.traits.list;
            int counter = 0;
            foreach(ActorTrait trait in traits){
                if(counter > 1){
                    break;
                    return;
                }
                if(Toolbox.randomChance(0.05f)){
                    string idS = trait.id;
                    if(!RankIds.Contains(idS) && !OniRanks.Contains(idS) && idS != "death_bomb" && idS != "death_nuke"){
                        unit.addTrait(idS);
                        counter++;
                    }
                }
            }
        }

    }

}

