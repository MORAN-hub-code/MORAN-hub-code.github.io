using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;
using Newtonsoft.Json;

namespace bbox{
    [ModEntry]
    class Main : MonoBehaviour{
		internal const string id = "triickstr.mods.worldbox.magic";
		internal static Harmony harmony;
        //internal static Dictionary<string, UnityEngine.Object> modsResources;
        private float update;
        void Awake(){
            //modsResources = Reflection.GetField(typeof(ResourcesPatch), null, "modsResources") as Dictionary<string, UnityEngine.Object>;
			      harmony = new Harmony(id);
                  update = 0f;
            
       }


       public void Update(){
            update += Time.deltaTime;
            if (update > 20.0f)
                {   
                    VerySmallTinyLittleMicroMiniPP.init();
                    update = 0f;
                }
        }
    }

}
