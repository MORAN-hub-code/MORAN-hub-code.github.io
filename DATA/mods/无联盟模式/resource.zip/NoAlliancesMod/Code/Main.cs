using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ai.behaviours;

namespace noAllianceMod{
    class Main : BasicMod<Main>{
        public static Main instance;
        static Harmony _harmony;
        protected override void OnModLoad(){
            PlotsEdit.init();
            _harmony = new Harmony("AvbNoAlliance (unused)");
            _harmony.PatchAll();
        }
    }
    // [HarmonyPatch(typeof(PlotAsset), "checkIsPossible")]
	// public class checkIfAlliancesAreDisabled{
	// 	static bool Prefix(PlotAsset __instance, ref bool __result, Actor pActor, bool pWorldLawsCheck = true)
    // 	{
    //         __result = pActor.hasEnoughMoney(__instance.money_cost) && pActor.level >= __instance.min_level && pActor.renown >= __instance.min_renown_actor && pActor.kingdom.getRenown() >= __instance.min_renown_kingdom && pActor.intelligence >= __instance.min_intelligence && pActor.diplomacy >= __instance.min_diplomacy && pActor.warfare >= __instance.min_warfare && pActor.stewardship >= __instance.min_stewardship && __instance.canBeDoneByRole(pActor) && (!pWorldLawsCheck || __instance.isAllowedByWorldLaws()) && __instance.check_is_possible(pActor);
    //         if (__instance.id == "alliance_create")
    //         {
    //             Debug.LogError($"Level needed: {__instance.min_level}");
    //         }
    //         return false;
    //     }
    // }
}




