using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;

namespace noAllianceMod{
    internal static class PlotsEdit{
        public static void init(){

            PlotAsset alliancecreate = AssetManager.plots_library.get("alliance_create");
            alliancecreate.min_level = 99999;

            PlotAsset alliancejoin = AssetManager.plots_library.get("alliance_join");
            alliancejoin.min_level = 99999;

            PlotAsset alliancedestroy = AssetManager.plots_library.get("alliance_destroy");
            alliancedestroy.min_level = 99999;

            //All plot ids
            // rebellion
            // new_war
            // alliance_create
            // alliance_join
            // alliance_destroy
            // attacker_stop_war
            // new_book
            // new_language
            // new_religion
            // new_culture
            // clan_ascension
            // culture_divide
            // religion_schism
            // language_divergence
            // summon_meteor_rain
            // summon_earthquake
            // summon_thunderstorm
            // summon_stormfront
            // summon_hellstorm
            // summon_demons
            // summon_angles
            // summon_skeletons
            // summon_living_plants
            // big_cast_coffee
            // big_cast_bubble_shield
            // big_cast_madness
            // big_cast_slowness
            // cause_rebellion
        }
    }
}




