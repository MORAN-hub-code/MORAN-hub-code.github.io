Open the Code folder and then PlotsEdit.cs with Notepad or VSC

**Option 1**
Turn the disabling code segment into a comment by adding //'s in front of both lines

**//**PlotAsset alliancecreate = AssetManager.plots\_library.get("alliance\_create");

**//**alliancecreate.min\_level = 99999;

**Option 2**
Simply delete the disabling code segment

*PlotAsset alliancecreate = AssetManager.plots\_library.get("alliance\_create");*

*alliancecreate.min\_level = 99999;*

