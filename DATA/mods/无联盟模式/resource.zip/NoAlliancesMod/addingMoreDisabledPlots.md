1\. Open the Code folder and then open PlotsEdit.cs with Notepad or VSC

2. Copy an existing segment of code and paste it lower down:



**PlotAsset alliancecreate = AssetManager.plots\_library.get("alliance\_create");**

**alliancecreate.min\_level = 99999;**



PlotAsset alliancejoin = AssetManager.plots\_library.get("alliance\_join");

alliancejoin.min\_level = 99999;



PlotAsset alliancedestroy = AssetManager.plots\_library.get("alliance\_destroy");

alliancedestroy.min\_level = 99999;


**PlotAsset alliancecreate = AssetManager.plots\_library.get("alliance\_create");**

**alliancecreate.min\_level = 99999;**



3\. Replace "alliancecreate" with a new word like "disabledplotNew1"


PlotAsset **disabledplotNew1** = AssetManager.plots\_library.get("alliance\_create");

**disabledplotNew1**.min\_level = 99999;


4\. Find the id of the plot you want to disable and paste it in place of "alliance\_create". For example, I want to disable the meteor shower plot:


PlotAsset **disabledplotNew1** = AssetManager.plots\_library.get("summon\_meteor\_rain");

**disabledplotNew1**.min\_level = 99999;


5\. Your done! This plot can no longer appear naturally

