using System;
using UnityEngine;
using HarmonyLib;
using NCMS;

namespace 禁用权能特效
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
          Harmony.CreateAndPatchAll(typeof(Main));
        }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(EffectsLibrary), "spawn")]
	      public static bool spawn(string pID, ref BaseEffect __result)
	      {
          if (pID == "fx_spark")
          {
            __result = null;
            return false;
          }
          return true;
		    }
    }
}