# PantheonsGodMod
A Mod for WorldBox, Adds Gods with custom Effects and stuff.

<a href="https://gamebanana.com/mods/456554"><img src="https://gamebanana.com/mods/embeddables/456554?type=large"/></a>