using CustomModT001.Abstract;
using NeoModLoader.General;

namespace CustomModT001;

public class Tooltips : ExtendLibrary<TooltipAsset, Tooltips>
{
    public static TooltipAsset cultisys { get; private set; }
    public static TooltipAsset common   { get; private set; }

    protected override void OnInit()
    {
        RegisterAssets(ModClass.asset_id_prefix);
        cultisys.callback = ShowCultisys;
        common.callback = ShowCommon;
    }

    private void ShowCommon(Tooltip tooltip, string type, TooltipData data)
    {
        var tip_name = data.tip_name;
        if (LocalizedTextManager.stringExists(tip_name)) tip_name = LM.Get(tip_name);

        tooltip.name.text = tip_name;

        var tip_description = data.tip_description;
        if (LocalizedTextManager.stringExists(tip_description)) tip_description = LM.Get(tip_description);

        tooltip.setDescription(tip_description);

        var tip_description2 = data.tip_description_2;
        if (LocalizedTextManager.stringExists(tip_description2)) tip_description2 = LM.Get(tip_description2);

        tooltip.setBottomDescription(tip_description2);
    }

    private static void ShowCultisys(Tooltip tooltip, string type, TooltipData data)
    {
        Actor actor = data.actor;

        var level = actor.GetCultisysLevel();
        tooltip.name.text = Cultisys.GetName(level);
        if (level < Cultisys.MaxLevel)
        {
            tooltip.setDescription($"{ModClass.asset_id_prefix}.ui.cultiprogress".Localize()+$": {actor.GetExp():N0}/{Cultisys.LevelExpRequired[level]:N0}");
        }

        // 显示基础天赋值
        tooltip.addLineIntText($"{ModClass.asset_id_prefix}.ui.base_talent", (int)actor.GetTalent());
        
        // 显示额外天赋值
        actor.data.get("extra_talent_inheritance", out int extraTalent, 0);
        tooltip.addLineIntText($"{ModClass.asset_id_prefix}_ui_extra_talent", extraTalent);
        BaseStatsHelper.showBaseStats(tooltip.stats_description, tooltip.stats_values, Cultisys.LevelStats[level]);
    }
}