using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api;
using NeoModLoader.General;
using NeoModLoader.General.UI.Tab;
using NeoModLoader.ui;
using UnityEngine;
using UnityEngine.UI;

namespace CustomModT001;

public class ModClass : BasicMod<ModClass>, IReloadable
{
    internal const string asset_id_prefix = "inmny.custommodt001";
    internal const string trait_group_id  = $"{asset_id_prefix}.group";

    public void Reload()
    {
    }

    protected override void OnModLoad()
    {
        AssetManager.trait_groups.add(new ActorTraitGroupAsset
        {
            id = trait_group_id,
            name = trait_group_id,
            color = Toolbox.colorToHex(Color.yellow)
        });
        new ActorTasks().Init();
        new ActorJobs().Init();
        new MapIcons().Init();
        new Terraforms().Init();
        new Stats().Init();
        new Statuses().Init();
        new Traits().Init();
        new Actors().Init();
        new Tooltips().Init();
        new TraitPairs().Init();
        try
        {
            Harmony.CreateAndPatchAll(typeof(Patches), asset_id_prefix);
            Harmony.CreateAndPatchAll(typeof(NamePrefixPatch), asset_id_prefix);
        }
        catch (Exception e)
        {
            do
            {
                Debug.LogError(e);
                e = e.InnerException;
            } while (e != null);
        }

        ScrollWindow intro_window =
            WindowCreator.CreateEmptyWindow($"{asset_id_prefix}.intro", $"{asset_id_prefix}.ui.intro");
        intro_window.scrollRect.gameObject.SetActive(true);

        var content_transform =
            intro_window.scrollRect.transform.Find("Viewport/Content").GetComponent<RectTransform>();
        content_transform.pivot = new Vector2(0.5f,    1);
        content_transform.sizeDelta = new Vector2(180, 0);
        var layout_group = content_transform.gameObject.AddComponent<VerticalLayoutGroup>();
        layout_group.childControlHeight = false;
        layout_group.childControlWidth = false;
        layout_group.childAlignment = TextAnchor.UpperCenter;
        layout_group.childScaleHeight = false;
        layout_group.childScaleWidth = false;
        content_transform.gameObject.AddComponent<ContentSizeFitter>().verticalFit =
            ContentSizeFitter.FitMode.PreferredSize;
        var intro = new GameObject("IntroText", typeof(RectTransform), typeof(Text), typeof(ContentSizeFitter));
        var intro_rect = intro.GetComponent<RectTransform>();
        intro_rect.SetParent(content_transform);
        intro_rect.localPosition = new Vector3(0, 0);
        intro_rect.localScale = new Vector3(1,    1);
        intro_rect.pivot = new Vector2(0.5f,    1);
        intro_rect.sizeDelta = new Vector2(180, 0);
        var fitter = intro.GetComponent<ContentSizeFitter>();
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        var intro_text = intro.GetComponent<Text>();
        intro_text.font = LocalizedTextManager.current_font;
        intro_text.fontSize = 10;
        intro_text.text = @"
功能:
    1. 世界排行榜(嵌在收藏夹中)
    2. 境界查看(人物界面鼠标悬停于头像)
    3. 关闭城市投降(模组列表->模组设置)
设定:
    1. 天赋: 数值与境界提升速度成正比
    2. 额外免伤: 累乘作用于所有非真实 伤害
    3. 蓝量: 用于释放技能
    4. 蓝量恢复: 每10秒恢复量
    5. 吸血: 按造成最终伤害回复生命
    6. 境界: 依次为凡人, 入品, 后天, 先天, 至臻, 超凡, 镇神
";

        ScrollWindow.showWindow(intro_window.screen_id);
        var tab = TabManager.CreateTab(asset_id_prefix, asset_id_prefix, "",
            SpriteTextureLoader.getSprite("inmny/custommodt001/cultilevel"));
        tab.SetLayout(new List<string>()
        {
            "tab"
        });
        
        tab.AddPowerButton("tab", PowerButtonCreator.CreateSimpleButton($"{asset_id_prefix}.config", () =>
        {
            ModConfigureWindow.ShowWindow(GetConfig());
        }, SpriteTextureLoader.getSprite("ui/icons/iconOptions")));
        tab.AddPowerButton("tab", PowerButtonCreator.CreateSimpleButton($"{asset_id_prefix}.top", ()=>
        {
            Patches.window_favorites_global_mode = true;
            ScrollWindow.showWindow("favorites");
        }, SpriteTextureLoader.getSprite("ui/icons/iconCommunity")));

        // 添加境界统计按钮
        tab.AddPowerButton("tab", PowerButtonCreator.CreateSimpleButton($"{asset_id_prefix}.tongji", ()=>
        {
            ScrollWindow tongji_window = WindowCreator.CreateEmptyWindow($"{asset_id_prefix}.tongji", $"{asset_id_prefix}.tongji");
            if (tongji_window == null)
            {
                Debug.LogError("创建境界统计窗口失败: window对象为null");
                return;
            }
            tongji_window.scrollRect.gameObject.SetActive(true);

            tongji_window.transform.Find("Header/Title")?.GetComponent<LocalizedText>()?.setKeyAndUpdate($"{asset_id_prefix}.tongji");

            // 统计所有生物的武道境界
            var realmCounts = new Dictionary<int, int>();
            int maxLevel = Cultisys.MaxLevel;
            string wudaoLevelKey = $"{asset_id_prefix}.wudao_level";

            if (World.world?.units != null)
            {
                foreach (var unit in World.world.units)
                {
                    if (unit?.data != null && unit.asset.civ)
                    {
                        int level = 0;
                        unit.data.get(wudaoLevelKey, out level, 0);
                        if (level <= maxLevel && level >= 0)
                        {
                            if (!realmCounts.ContainsKey(level))
                                realmCounts[level] = 0;
                            realmCounts[level]++;
                        }
                    }
                }
            }

            var scrollRect = tongji_window.scrollRect;
            if (scrollRect != null)
            {
                var content = scrollRect.transform.Find("Viewport/Content");
                if (content != null)
                {
                    var content_transform = content.GetComponent<RectTransform>();
                    if (content_transform != null)
                    {
                        content_transform.pivot = new Vector2(0.5f, 1);
                        content_transform.anchorMin = new Vector2(0, 1);
                        content_transform.anchorMax = new Vector2(1, 1);
                        content_transform.anchoredPosition = new Vector2(0, 0);

                        foreach (Transform child in content)
                            UnityEngine.Object.Destroy(child.gameObject);

                        // 创建统计表格
                        float yOffset = -20f;
                        var font = UnityEngine.Resources.GetBuiltinResource<UnityEngine.Font>("Arial.ttf");
                        int visibleRealmCount = 0;

                        // 按境界等级排序
                        foreach (var level in realmCounts.Keys.OrderBy(l => l))
                        {
                            int count = realmCounts[level];
                            if (count > 0)
                            {
                                visibleRealmCount++;

                                // 创建境界名称文本
                                CreateRealmText(content, font, new Vector2(0, 1), new Vector2(0.7f, 1), new Vector2(35f, yOffset), $"{Cultisys.GetName(level)} ({level})", UnityEngine.TextAnchor.MiddleLeft);

                                // 创建数量文本
                                CreateRealmText(content, font, new Vector2(0.7f, 1), new Vector2(1, 1), new Vector2(-65f, yOffset), count.ToString(), UnityEngine.TextAnchor.MiddleRight);

                                yOffset -= 35f;
                            }
                        }

                        // 根据境界数量调整窗口高度
                        float windowHeight = Math.Max(300, visibleRealmCount * 50);
                        content_transform.sizeDelta = new Vector2(0, windowHeight);
                    }
                }
            }

            if (!string.IsNullOrEmpty(tongji_window.screen_id))
                ScrollWindow.showWindow(tongji_window.screen_id);
            else
                Debug.LogError("显示境界统计窗口失败: screen_id为空");
        }, SpriteTextureLoader.getSprite("inmny/custommodt001/tongji")));

        // 创建UI文本辅助方法
        void CreateRealmText(Transform parent, UnityEngine.Font font, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, string text, UnityEngine.TextAnchor alignment)
        {
            var obj = new UnityEngine.GameObject("RealmText");
            obj.transform.SetParent(parent);
            obj.transform.localScale = Vector3.one;

            var rect = obj.AddComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.pivot = new Vector2(anchorMin.x, 1);
            rect.anchoredPosition = anchoredPosition;
            rect.sizeDelta = new Vector2(0, 30);

            var textComp = obj.AddComponent<UnityEngine.UI.Text>();
            textComp.text = text;
            textComp.font = font;
            textComp.fontSize = 14;
            textComp.color = UnityEngine.Color.white;
            textComp.fontStyle = UnityEngine.FontStyle.Bold;
            textComp.alignment = alignment;
        }
            
        tab.UpdateLayout();
    }

    private void Update()
    {
        EventManager.ProcessDamageEvents();
    }
}