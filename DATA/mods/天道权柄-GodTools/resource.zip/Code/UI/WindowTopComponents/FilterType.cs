namespace GodTools.UI.WindowTopComponents;

public enum FilterType
{
    And,
    Or,
    Not
}