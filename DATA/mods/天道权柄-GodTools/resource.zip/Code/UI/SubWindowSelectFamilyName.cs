using GodTools.UI.Prefabs;

namespace GodTools.UI;

public class SubWindowSelectFamilyName : SubWindow<SubWindowSelectFamilyName>
{
    
}