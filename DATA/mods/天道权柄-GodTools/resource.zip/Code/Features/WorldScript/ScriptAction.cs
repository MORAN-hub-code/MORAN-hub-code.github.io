namespace GodTools.Features.WorldScript;

public class ScriptAction
{
    public string ActionID;
    public string Value;
}