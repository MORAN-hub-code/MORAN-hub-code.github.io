﻿namespace GodTools.Abstract;

internal interface IManager
{
    public void Initialize();
}