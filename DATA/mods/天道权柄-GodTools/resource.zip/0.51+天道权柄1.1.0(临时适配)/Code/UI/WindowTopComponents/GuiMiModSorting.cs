using GodTools.UI.Prefabs;
using UnityEngine;

// ReSharper disable CheckNamespace

namespace GodTools.UI;

public partial class WindowTops
{
#if XULIE
    private void CreateGrid_GUIMIMOD()
    {
        // 创建一个统一的网格来放置灵性和金磅
        TitledGrid guimi_keyword_grid = new_keyword_grid("guimi_mod");
        
        // 添加灵性排序选项
        new_keyword(guimi_keyword_grid, "xulie", "XuLie", (a, b) =>
        {
            // 获取灵性等级 - 使用正确的存储键名
            a.data.get("xulie.xuLieNum", out float a_xulie, 0f);
            b.data.get("xulie.xuLieNum", out float b_xulie, 0f);
            // 升序排序，让灵性低的排在前面
            var res = a_xulie.CompareTo(b_xulie);
            return res;
        }, a =>
        {
            // 显示灵性等级
            a.data.get("xulie.xuLieNum", out float a_xulie, 0f);
            return $"{a_xulie:F1} 灵性";
        });

        // 添加金磅排序选项
        new_keyword(guimi_keyword_grid, "jin_bang", "JinBang", (a, b) =>
        {
            // 获取金磅数量 - 使用正确的存储键名
            a.data.get("xulie.jinBangNum", out float a_jinbang, 0f);
            b.data.get("xulie.jinBangNum", out float b_jinbang, 0f);
            // 升序排序，让金磅少的排在前面
            var res = a_jinbang.CompareTo(b_jinbang);
            return res;
        }, a =>
        {
            // 显示金磅数量
            a.data.get("xulie.jinBangNum", out float a_jinbang, 0f);
            return $"{a_jinbang:F1} 金磅";
        });
    }
#endif
}