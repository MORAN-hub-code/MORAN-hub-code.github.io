#if WITCHCRAFT_WORLDBOX || WITCHCRAFT_KNIGHT
using GodTools.UI.Prefabs;

// ReSharper disable CheckNamespace

namespace GodTools.UI;

public partial class WindowTops
{
#if WITCHCRAFT_WORLDBOX
    private void CreateGrid_WITCHCRAFT_WORLDBOX()
    {
        TitledGrid wushu_keyword_grid = new_keyword_grid("wushu");
        new_keyword(wushu_keyword_grid, "yuanneng", "ui/YuanNeng", (a, b) =>
        {
            a.data.get("wushu.yuannengNum", out float a_level);
            b.data.get("wushu.yuannengNum", out float b_level);
            var res = a_level.CompareTo(b_level);
            return res;
        }, a =>
        {
            a.data.get("wushu.yuannengNum", out float a_level);
            return $"{a_level:F1} 源能";
        });

        new_keyword(wushu_keyword_grid, "meditation", "ui/Meditation", (a, b) =>
        {
            a.data.get("wushu.meditationNum", out float a_meditation);
            b.data.get("wushu.meditationNum", out float b_meditation);
            var res = a_meditation.CompareTo(b_meditation);
            return res;
        }, a =>
        {
            a.data.get("wushu.meditationNum", out float a_meditation);
            return $"{a_meditation:F1} 无根之源";
        });
    }
#endif

#if WITCHCRAFT_KNIGHT
    private void CreateGrid_WITCHCRAFT_KNIGHT()
    {
        TitledGrid knight_keyword_grid = new_keyword_grid("knight");
        new_keyword(knight_keyword_grid, "knight", "Knight", (a, b) =>
        {
            float a_knight = a.data["Knight"];
            float b_knight = b.data["Knight"];
            var res = a_knight.CompareTo(b_knight);
            return res;
        }, a =>
        {
            float a_knight = a.data["Knight"];
            return $"{a_knight:F1} 生命之力";
        });
    }
#endif
}
#endif