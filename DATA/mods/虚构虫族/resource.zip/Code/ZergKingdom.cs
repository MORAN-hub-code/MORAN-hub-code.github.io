﻿using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;
using System.Threading;
using System.Text;
using ai;
using ai.behaviours;
using System.Diagnostics;
using static UnityEngine.GraphicsBuffer;

namespace Zerg
{
    class ZergKingdom//暂时无用，没做完
    {
        public static void init()
        {
            KingdomAsset Zerg = new KingdomAsset();
            Zerg.id = "Zerg";
            Zerg.count_as_danger = true;
            Zerg.mobs = true;
            Zerg.civ = false;
            Zerg.default_kingdom_color = new ColorAsset("#AD00B9");
            AssetManager.kingdoms.add(Zerg);
            World.world.kingdoms_wild.newWildKingdom(Zerg);

            OpinionAsset ZergOption = new OpinionAsset();
            ZergOption.id = "option_zerg";
            ZergOption.translation_key = "option_zerg_key";
            ZergOption.translation_key_negative = "option_zerg_negative";
            ZergOption.calc = delegate (Kingdom pMain, Kingdom pTarget)
            {
                if (pMain == null || pTarget == null)
                {
                    return 0;
                }
                ActorAsset t1 = pMain.getActorAsset();
                ActorAsset t2 = pTarget.getActorAsset();
                if (t1 == null || t2 == null)
                {
                    return 0;
                }
                bool flag = false;
                if (t1.traits != null && t1.traits.Contains("异虫"))
                {
                    flag = !flag;
                }

                if (t2.traits != null && t2.traits.Contains("异虫"))
                {
                    flag = !flag;
                }
                if (flag) return -1000;
                else return 0;
            };
            AssetManager.opinion_library.add(ZergOption);
        }
    }
}