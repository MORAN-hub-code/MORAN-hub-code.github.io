﻿using System.Collections.Generic;

namespace Zerg
{
    class MoreBuilding
    {
        public static void init()
        {
            BuildingAsset infBuilding = AssetManager.buildings.clone("InfBuilding_0", "$building$");
            infBuilding.base_stats[S.health] = 500f;
            infBuilding.fundament = new BuildingFundament(2, 1, 1, 0);
            infBuilding.kingdom = "Zerg";
            infBuilding.can_be_placed_on_liquid = false;
            infBuilding.ignore_buildings = false;
            infBuilding.has_ruin_state = false;
            infBuilding.check_for_close_building = false;
            infBuilding.can_be_living_house = true;
            infBuilding.atlas_asset = AssetManager.dynamic_sprites_library.get("building_shadows");
            infBuilding.has_ruins_graphics = true;
            infBuilding.has_kingdom_color = false;
            infBuilding.burnable = false;
            infBuilding.spawn_units = true;
            infBuilding.spawn_units_asset = SZA.Infested_Unit;
            infBuilding.sprite_path = "buildings/InfBuilding/InfBuilding_0";
            infBuilding.has_sprites_main = true;

            for(int i = 1;i <= 5;i++)
            {
                BuildingAsset Building = AssetManager.buildings.clone($"InfBuilding_{i}", "InfBuilding_0");
                Building.sprite_path = $"buildings/InfBuilding/InfBuilding_{i}";
                Building.spawn_units_asset = i % 2 == 0 ? SZA.Infested_Unit : SZA.Infested_Animal;
                Building.atlas_asset = AssetManager.dynamic_sprites_library.get("building_shadows");
            }
            for (int i = 0; i < 3; i++)
            {
                BuildingAsset Building = AssetManager.buildings.clone($"InfTower_{i}", "watch_tower_human");
                Building.sprite_path = $"buildings/InfBuilding/InfTower_{i}";
                Building.kingdom = "Zerg";
                Building.draw_light_area = false;
                Building.tower_projectile = "summonIU";
                Building.tower_projectile_amount = 1;
                Building.spawn_units = true;
                Building.spawn_units_asset = SZA.Infested_Unit;
                Building.atlas_asset = AssetManager.dynamic_sprites_library.get("building_shadows");
            }
            {
                BuildingAsset Building = AssetManager.buildings.clone("InfHall", "InfTower_0");
                Building.base_stats[S.health] = 2000;
                Building.sprite_path = $"buildings/InfBuilding/InfHall";
                Building.spawn_units_asset = SZA.Infested_Terran;
                Building.atlas_asset = AssetManager.dynamic_sprites_library.get("building_shadows");
            }
            {
                BuildingAsset Building = AssetManager.buildings.clone("InfStatue", "InfBuilding_0");
                Building.sprite_path = $"buildings/InfBuilding/InfStatue";
                Building.spawn_units_asset = SZA.Creep;
                Building.atlas_asset = AssetManager.dynamic_sprites_library.get("building_shadows");
            }

            //BuildingAsset Jingti = AssetManager.buildings.clone("Jingti", SB.mineral_stone);
            //Jingti.sprite_path = "buildings/Jingti";
            //Jingti.draw_light_area = true;
            //Jingti.draw_light_size = 0.2f;
            //Jingti.sparkle_effect = true;

            ////addResource(Jingti, "JTkuang", 4);
            //addResource(Jingti, S_Resource.common_metals, 1);
            //addResource(Jingti, S_Resource.stone, 2);
            //AssetManager.buildings.add(Jingti);
            //AssetManager.buildings.loadSprites(Jingti);

            //foreach (BiomeAsset biome in AssetManager.biome_library.list)
            //{
            //    if (biome.grow_minerals_auto)
            //    {
            //        biome.addMineral("Jingti", 1);
            //    }

            //}
        }

        //public static void addResource(BuildingAsset t, string pID, int pAmount, bool pNewList = false)
        //{
        //    if (t.resources_given == null || pNewList)
        //    {
        //        t.resources_given = new List<ResourceContainer>();
        //    }
        //    t.resources_given.Add(new ResourceContainer
        //    {
        //        id = pID,
        //        amount = pAmount
        //    });
        //}
    }
}