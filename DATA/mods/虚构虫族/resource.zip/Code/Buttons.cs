﻿using System;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using System.IO;
using NeoModLoader.General.UI.Tab;
using NeoModLoader.General;

namespace Zerg
{
    class Buttons
    {
        private static bool lined = false;
        public static int x = 36;
        public static bool button_finish;
        public static int index = 1;
        public static List<string> Zerg_units_id = new List<string>() { SZA.Drone, SZA.Larva, SZA.Overlord, SZA.Zergling, SZA.Queen, SZA.Mutalisk,SZA.Hydralisk, SZA.Baneling, SZA.Infestor , SZA.Leviathan, SZA.SuperLeviathan, SZA.Infected_Humans,SZA.Infested_Terran,SZA.Swarm_Host,SZA.Locust,SZA.Infested_Unit, SZA.Infested_Animal,SZA.Ex_Mutalisk,SZA.Ultralisk,"smart_drone" };
        public static List<string> Zerg_building_id = new List<string>() { SZB.Hatchery, SZB.Lair, SZB.Hive, SZB.Spawning_Pool, SZB.Evolution_Chamber, SZB.Spore_Crawler, SZA.Spore_Crawler_Walk, SZB.Spire, SZB.Baneling_Nest, SZB.Infestation_Pit ,SZB.Ultralisk_Cavern ,SZB.Creep_Tumor ,SZB.Overmind,SZB.Hydralisk_Den,"ChuanSong",SZB.Cocoons_Building,SZB.Cocoons_land_Actor,SZB.Cocoons_Hatchery,SZB.Cocoons_fly_Actor};
        public static Dictionary<string, string> Zerg_description = new Dictionary<string, string>();
        public static void init()
        {
            {
                foreach (string name in Zerg_units_id)
                {
                    CreateNewActorGodPower(name);
                }
                foreach (string name in Zerg_building_id)
                {
                    CreateNewActorGodPower(name);
                }
                CreateNewDropGodPower("Kong_Drop", "KongDrop", 0.2f);
                CreateNewDropGodPower("Zerg_Plague", "ZergPlague", 0.2f);



                CreateNewButton(SZA.Larva);
                index++;

                Zerg_description.Add("工蜂", "虫群...意志...");
                Zerg_description.Add("王虫", "需要孵化更多的王虫……");
                Zerg_description.Add("跳虫", "Zerg Rush");
                Zerg_description.Add("虫后", "虫群永不停歇");
                Zerg_description.Add("爆虫", "啊哈哈哈，毒爆来喽！");
                Zerg_description.Add("异龙", "飞龙骑脸怎么输");
                Zerg_description.Add("虫群宿主", "娜个兵种！");
                Zerg_description.Add("感染者", "一般路过感染虫\n感染者是异虫的地面施法单位\n能使用多种法术能力影响战局");
                Zerg_description.Add("孵化场", "生成菌毯，产生幼虫，虫群的心脏");
                Zerg_description.Add("虫穴", "孵化场的高级形态\n为异虫提供更多的升级方案和建筑方案");
                Zerg_description.Add("主巢", "孵化场的更高级形态\n为异虫提供更多的升级方案和建筑方案");
                Zerg_description.Add("分裂池", "虫巢的核心建筑\n使孵化场可以变异为虫穴\n使幼虫可以变异为跳虫");
                Zerg_description.Add("进化腔", "一座……骨架？");
                Zerg_description.Add("孢子爬虫", "令人恐惧...");
                Zerg_description.Add("孢子爬虫（移动）", "获得了移动的能力，那么代价是什么呢？");
                Zerg_description.Add("尖塔", "使幼虫可以变异为异龙\n为异虫飞行生物提供升级方案");
                Zerg_description.Add("爆虫巢穴", "居家旅行一波流必备\n使幼虫可以变异为爆虫");
                Zerg_description.Add("感染深渊", "使幼虫可以变异为感染者\n使虫穴可以变异为主巢");

                string pFrom, pTo, pFromlocal, pTolocal;
                foreach (KeyValuePair<string, List<MutationAsset>> pair in MutationLibrary.dict)
                {
                    //pFrom = pair.Key;
                    //if (SZB.localized.ContainsKey(pFrom)) pFromlocal = SZB.localized[pFrom];
                    //else pFromlocal = SZA.localized[pFrom];
                    foreach (var mutation in pair.Value)
                    {
                        pTo = mutation.mutationUnit;
                        MonoBehaviour.print(pTo);
                        //if (mutation.building) pTolocal = SZB.localized[pTo];
                        //else pTolocal = SZA.localized[pTo];
                        CreateNewButton(pTo);
                        //CreateNewToggleButton("ZergMutationLimit_" + pTo, pTolocal + "限制", "禁止" + pFromlocal + "变异为" + pTolocal, "Icon.iconZerg");
                    }
                }
                CreateNewButton("smart_drone");


                //CreateNewButton(SZA.Ex_Mutalisk, "精英异龙", "由利维坦孵化的精英");
                //CreateNewButton(SZA.Locust, "蝗虫", "城市化大战泉水钩");
                //CreateNewButton(SZA.Infected_Humans, "异化作战体", "被感染的陆战队员");
                //CreateNewButton(SZA.Infested_Terran, "自爆人", "牺牲我……");
                //CreateNewButton(SZA.Infested_Unit, "被感染的智慧生物", "");
                //CreateNewButton(SZA.Infested_Animal, "被感染的动物", "");
                x += 12;

                //CreateNewButton(SZB.Ultralisk_Cavern, "雷兽窟（未完成）", "");
                //CreateNewButton(SZB.Creep_Tumor, "菌毯肿瘤物", "菌毯已至");
                x += 12;
                CreateNewButton("Zerg_Plague", "drops");
                CreateNewButton("Kong_Drop", "drops");
                //CreateNewButton(SZA.Leviathan, "利维坦(半成品)", "");
                //CreateNewButton(SZA.SuperLeviathan, "凯瑞甘的利维坦(半成品)", "");
                //CreateNewButton(SZB.Overmind, "主宰", "珍爱生命，远离酒驾 \n（尤其是酒驾的星灵）");
                //CreateNewButton("ChuanSong", "主宰传送门", "无尽的异虫正在传送");
                x += 24;
                CreateNewToggleButton("ZergEra", "异虫入侵", "我，即是虫群\n大军灰飞烟灭，世界在我脚下燃烧", "ages/iconAgeZerg");
                CreateNewToggleButton("ZergEra_law", "允许异虫入侵", "许因各自形式产生的异虫入侵\n包括异虫入侵灾难和异虫入侵纪元", "ages/iconAgeZerg");
                CreateNewToggleButton("Gene_Synchronization", "异虫基因库", "开启后，异虫将掠夺生物基因以强化自身", "Icon/iconZerg");
                CreateNewToggleButton("Zhuisha_law", "关闭异虫追杀", "关闭异虫战斗兵种追杀模式\n如果卡顿建议关闭", "Icon/iconZerg");
                CreateNewToggleButton("Hou_law", "关闭虫后增益", "开启后，虫后不会再对孵化场注卵", "Icon/iconZerg");
                CreateNewToggleButton("DroneLimit", "工蜂限制", "开启后，工蜂不可变异为孵化场", "Icon/iconZerg");
                CreateNewToggleButton("ZergActorInfectLimit", "生物感染限制", "开启后，异虫感染不会传播给生物", "Icon/iconZerg");
                CreateNewToggleButton("ZergBuildingInfectLimit", "建筑感染限制", "开启后，感染不会产生被感染的建筑", "Icon/iconZerg");
                CreateNewToggleButton("ZergBiomeLimit", "菌毯肿瘤限制", "开启后，菌毯肿瘤不会主动扩散", "Icon/iconZerg");
                CreateNewToggleButton("show_Zerg_law", "灵能链接", "开启后，使用颜色标记异虫所在区块", "Icon/iconZerg");
                CreateNewToggleButton("Zerg_Same_sub", "一致性", "开启后，上帝手动放置的异虫单位亚种相同", "Icon/iconZerg");
                ZergTab.tab.UpdateLayout();
                button_finish = true;
            }
        }
        public static void CreateNewActorGodPower(string id)
        {
            var godPower = new GodPower
            {
                id = $"spawn{id}",
                show_spawn_effect = true,
                actor_spawn_height = 3f,
                name = $"spawn{id}",
                actor_asset_id = id,
                click_action = new PowerActionWithID((WorldTile pTile, string pPower) => { return MoreAction.spawnUnit(pTile, pPower); })
            };
            AssetManager.powers.add(godPower);
        }

        public static void CreateNewToggleGodPower(string id)
        {
            GodPower power = new GodPower();
            power.id = id;
            power.name = id;
            power.toggle_name = id;
            AssetManager.powers.add(power);
        }

        public static void CreateNewButton(string id,string path = "units")
        {
            ZergTab.tab.AddPowerButton("creature_actor", PowerButtonCreator.CreateGodPowerButton($"spawn{id}", SpriteTextureLoader.getSprite($"EmbededResources/{path}/{id}"),pLocalPosition: new Vector2(x_(index),y_(index))));
            index++;
        }
        public static void CreateNewToggleButton(string id, string name, string description,string path_icon)
        {
            CreateNewToggleGodPower(id);
            ZergTab.tab.AddPowerButton("laws", PowerButtonCreator.CreateToggleButton(id, SpriteTextureLoader.getSprite($"EmbededResources/"+path_icon), pLocalPosition: new Vector2(x_(index), y_(index))));
            index++;
        }
        public static void CreateNewDropGodPower(string id,string drop_id,float fallingChance = 0.06f)
        {
            var Drop = AssetManager.powers.clone("spawn"+id, "$template_drops$");
            Drop.name = "spawn" + id;
            Drop.drop_id = drop_id;
            Drop.falling_chance = fallingChance;
            Drop.cached_drop_asset = AssetManager.drops.get(drop_id);
            Drop.click_power_brush_action = AssetManager.powers.loopWithCurrentBrushPowerForDropsRandom;
        }


        public static float x_(int index) 
        {
            return x + 36 * ((index + 1) / 2);
        }
        public static float y_(int index)
        {
            return (float)(-18 * Math.Pow(-1, index));
        }
    }
}