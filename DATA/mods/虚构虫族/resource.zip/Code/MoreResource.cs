﻿using NCMS.Utils;
using System.Reflection;

namespace Zerg
{
    class MoreResource
    {
        public static void init()
        {
            ResourceAsset JTkuang = AssetManager.resources.clone("JTkuang", "gold");
            JTkuang.id = "JTkuang";
            JTkuang.path_icon = "resources/Jing";
            JTkuang.type = ResType.Strategic;
            Localization.AddOrSet(JTkuang.id, "晶体矿");
        }
    }
}