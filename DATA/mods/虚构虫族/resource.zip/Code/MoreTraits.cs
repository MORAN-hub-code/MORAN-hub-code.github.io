﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReflectionUtility;
using System.Collections;
using System.Text.RegularExpressions;
using System.Reflection;
using HarmonyLib;
using NCMS.Utils;
using UnityEngine;

namespace Zerg
{
    class MoreTraits
    {
        public static void init()
        {
            /*
            ActorTrait chong = new ActorTrait();
            chong.id = "虫族基因（显性）";
            chong.rate_birth = 0;
            chong.opposite = "immune";
            chong.path_icon = "ui/Icons/iconZerg";
            chong.base_stats[S.intelligence] = +20;//base_stats[S.]
            chong.base_stats[S.warfare] = +40;
            chong.base_stats[S.stewardship] = +100;
            chong.group_id = ZergGroup.xugou;
            AssetManager.traits.add(chong);
            //复活分裂机会
            chong.action_death = (WorldAction)Delegate.Combine(chong.action_death, new WorldAction(ZergAction.Chong1));
            //500寿命
            chong.action_special_effect = (WorldAction)Delegate.Combine(chong.action_special_effect, new WorldAction(ZergAction.sanji));
            //交战中摄取敌人的生命治愈己身
            chong.action_attack_target = new AttackAction(ActionLibrary.restoreHealthOnHit);
            addTraitToLocalizedLibrary("cz", chong.id, "死亡千回，终成至高", "虫族基因（显性）");
            PlayerConfig.unlockTrait("虫族基因（显性）");

            ActorTrait chong0 = new ActorTrait();
            chong0.id = "虫族基因（隐性）";
            chong0.rate_birth = 0;
            chong0.rate_inherit = 100;
            chong0.base_stats[S.intelligence] = -5;
            chong0.base_stats[S.warfare] = +30;
            chong0.base_stats[S.diplomacy] = -1000;
            chong0.base_stats[S.stewardship] = +90;
            chong0.group_id = ZergGroup.xugou;
            chong0.path_icon = "ui/Icons/iconZerg";
            AssetManager.traits.add(chong0);
            //三级
            chong0.action_special_effect = (WorldAction)Delegate.Combine(chong0.action_special_effect, new WorldAction(ZergAction.sanji));
            //交战中摄取敌人的生命治愈己身
            chong0.action_attack_target = new AttackAction(ActionLibrary.restoreHealthOnHit);
            addTraitToLocalizedLibrary("cz", chong0.id, " 死亡千回，终成至高 ", "虫族基因（隐性）");

            ActorTrait chong2 = new ActorTrait();
            chong2.id = "虚构虫族母巢";
            chong2.rate_birth = 0;
            chong2.base_stats[S.mod_damage] = +1000;
            chong2.base_stats[S.mod_health] = +1000;
            chong2.base_stats[S.intelligence] = +1000;
            chong2.base_stats[S.warfare] = +200;
            chong2.base_stats[S.diplomacy] = -5;
            chong2.base_stats[S.stewardship] = +1000;
            chong2.group_id = ZergGroup.xugou;
            chong2.path_icon = "ui/Icons/iconZerg";
            AssetManager.traits.add(chong2);
            chong2.action_special_effect = (WorldAction)Delegate.Combine(chong2.action_special_effect, new WorldAction(ZergAction.Chong2));
            //交战中摄取敌人的生命治愈己身
            chong2.action_attack_target = new AttackAction(ActionLibrary.restoreHealthOnHit);
            addTraitToLocalizedLibrary("cz", chong2.id, "异界来客，降临", "虚构虫族母巢");
            PlayerConfig.unlockTrait("虚构虫族母巢");
            */

            ActorTrait LingN = new ActorTrait();
            LingN.id = "灵能觉醒";
            LingN.rate_birth = 4;
            LingN.rate_inherit = 10;
            LingN.group_id = ZergGroup.zergs;
            LingN.can_be_given = true;
            LingN.path_icon = "ui/Icons/iconLingN";
            LingN.action_special_effect = (WorldAction)Delegate.Combine(LingN.action_special_effect, new WorldAction(ZergAction.LingN));
            AssetManager.traits.add(LingN);
            addTraitToLocalizedLibrary("cz", LingN.id, "你被强化了，快送\n可免疫异虫感染", "灵能觉醒");

            ActorTrait chong3 = new ActorTrait
            {
                id = "异虫感染",
                rate_birth = 0,
                can_be_given = false,
                path_icon = "ui/Icons/iconZerg",
                group_id = "special"
            };
            chong3.addOpposite("immune");
            AssetManager.traits.add(chong3);
            chong3.action_death = (WorldAction)Delegate.Combine(chong3.action_death, new WorldAction(ZergAction.Chong4));
            chong3.action_special_effect = (WorldAction)Delegate.Combine(chong3.action_special_effect, new WorldAction(ZergAction.Shanghai));
            addTraitToLocalizedLibrary("cz", chong3.id, "虫群…意志……", "异虫感染");

            ActorTrait chong3bd = new ActorTrait
            {
                id = "异虫病毒",
                rate_birth = 0,
                can_be_given = true,
                path_icon = "ui/Icons/iconZerg",
                group_id = "special"
            };
            chong3bd.addOpposite("immune");
            chong3bd.addOpposite("immortal");
            chong3bd.action_attack_target = ZergAction.Ganran;
            AssetManager.traits.add(chong3bd);


            addTraitToLocalizedLibrary("cz", chong3bd.id, "该单位可以传播异虫病毒", "异虫病毒");

            ActorTrait chong3j = new ActorTrait
            {
                id = "异虫寄生",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                group_id = ZergGroup.zergs
            };
            chong3j.addOpposite("immune");
            chong3j.addOpposite("immortal");
            AssetManager.traits.add(chong3j);
            chong3j.action_death = (WorldAction)Delegate.Combine(chong3j.action_death, new WorldAction(ZergAction.Chong4j));
            chong3j.action_special_effect = (WorldAction)Delegate.Combine(chong3j.action_special_effect, new WorldAction(ZergAction.Shanghai));
            addTraitToLocalizedLibrary("cz", chong3j.id, "已经……来不及了", "异虫寄生");
            chong3j.unlock(true);

            ActorTrait chong3b = new ActorTrait
            {
                id = "异虫",
                rate_birth = 0,
                can_be_given = false,
                path_icon = "ui/Icons/iconZerg",
                group_id = "special"
            };
            chong3b.addOpposite("madness");
            AssetManager.traits.add(chong3b);
            addTraitToLocalizedLibrary("cz", chong3b.id, "归属虫群", "异虫");

            ActorTrait chong4 = new ActorTrait
            {
                id = "工蜂",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4);
            chong4.action_special_effect = ZergAction.MutationSystem;
            //chong4.action_attack_target = new AttackAction(MoreAction.Ganran);
            addTraitToLocalizedLibrary("cz", chong4.id, "虫群…意志……", "工蜂");

            ActorTrait chong4y = new ActorTrait
            {
                id = "幼虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4y);
            chong4y.action_special_effect = ZergAction.MutationSystem;
            //chong4y.action_attack_target = new AttackAction(MoreAction.Ganran);
            addTraitToLocalizedLibrary("cz", chong4y.id, "一切之源", "幼虫");

            ActorTrait chong4t = new ActorTrait
            {
                id = "跳虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4t);
            //跳虫转爆虫
            chong4t.action_special_effect = ZergAction.MutationSystem;
            //跳虫科技 代谢加速
            chong4t.action_special_effect = (WorldAction)Delegate.Combine(chong4t.action_special_effect, new WorldAction(ZergAction.Chong7t_mb));
            //通用科技 地面近战攻击等级 基因同步
            chong4t.action_special_effect = (WorldAction)Delegate.Combine(chong4t.action_special_effect, new WorldAction(ZergAction.Chong7ev));
            //chong4t.action_attack_target = new AttackAction(MoreAction.Ganran);
            addTraitToLocalizedLibrary("cz", chong4t.id, "Zerg Rush", "跳虫");

            ActorTrait chong4db = new ActorTrait
            {
                id = "爆虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4db);
            //毒爆攻击死亡
            chong4db.action_attack_target = (AttackAction)Delegate.Combine(chong4db.action_attack_target, new AttackAction(ZergAction.Chong7zb));
            //毒爆死后自爆伤害
            chong4db.action_death = (WorldAction)Delegate.Combine(chong4db.action_death, new WorldAction(ZergAction.Chong7db));
            //通用科技 地面近战攻击等级 基因同步
            chong4db.action_special_effect = (WorldAction)Delegate.Combine(chong4db.action_special_effect, new WorldAction(ZergAction.Chong7ev));
            addTraitToLocalizedLibrary("cz", chong4db.id, "啊哈哈哈哈，毒爆来咯！", "爆虫");

            ActorTrait chong4c = new ActorTrait
            {
                id = "刺蛇",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4c);

            ActorTrait Ultralisk = new ActorTrait
            {
                id = "雷兽",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(Ultralisk);


            ActorTrait chong4w = new ActorTrait
            {
                id = "王虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4w);
            addTraitToLocalizedLibrary("cz", chong4w.id, "需要孵化更多的王虫……", "王虫");

            ActorTrait chong4yd = new ActorTrait
            {
                id = "异龙",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4yd);
            addTraitToLocalizedLibrary("cz", chong4yd.id, "飞龙骑脸怎么输", "异龙");

            ActorTrait chong4h = new ActorTrait
            {
                id = "虫后",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4h);
            chong4h.action_special_effect = (WorldAction)Delegate.Combine(chong4h.action_special_effect, new WorldAction(ZergAction.Chong7h));
            chong4h.action_special_effect = (WorldAction)Delegate.Combine(chong4h.action_special_effect, new WorldAction(ZergAction.Chong7hj));
            //chong4h.action_attack_target = new AttackAction(MoreAction.Ganran);
            addTraitToLocalizedLibrary("cz", chong4h.id, "虫群永不停歇", "虫后");

            ActorTrait chong4l = new ActorTrait
            {
                id = "利维坦",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4l);
            chong4l.action_special_effect = (WorldAction)Delegate.Combine(chong4l.action_special_effect, new WorldAction(ZergAction.Kongtou));
            addTraitToLocalizedLibrary("cz", chong4l.id, "未完成", "利维坦");

            ActorTrait chong4j = new ActorTrait
            {
                id = "菌毯肿瘤生物",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4j);
            chong4j.action_special_effect = (WorldAction)Delegate.Combine(chong4j.action_attack_target, new WorldAction(ZergAction.Chong7j));
            addTraitToLocalizedLibrary("cz", chong4j.id, "异虫未动，菌毯先行", "菌毯肿瘤生物");

            ActorTrait chong4bao = new ActorTrait
            {
                id = "孢子爬虫（移动）",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4bao.action_special_effect = ZergAction.Chong7jtb;
            AssetManager.traits.add(chong4bao);
            addTraitToLocalizedLibrary("cz", chong4bao.id, "获得了移动的能力，那么代价是什么呢？", "孢子爬虫（移动）");

            ActorTrait chong4gr = new ActorTrait
            {
                id = "感染者",
                rate_birth = 0,
                path_icon = "ui/Icons/iconAM",
                can_be_given = false,
                group_id = "special"
            };
            chong4gr.action_attack_target = ZergAction.Chong7gr_;
            //chong4gr.action_special_effect = MoreAction.Chong8g;
            AssetManager.traits.add(chong4gr);
            addTraitToLocalizedLibrary("cz", chong4gr.id, "感染者是异虫的地面施法单位\n能使用多种法术能力影响战局", "感染者");

            ActorTrait chong4ih = new ActorTrait
            {
                id = "异化作战体",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4ih.action_special_effect = ZergAction.Status_Action;
            AssetManager.traits.add(chong4ih);
            addTraitToLocalizedLibrary("cz", chong4ih.id, "", "异化作战体");

            ActorTrait chong4it = new ActorTrait
            {
                id = "自爆人",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4it.action_attack_target = ZergAction.InTerran_Attack_Action;
            chong4it.action_death = ZergAction.InTerran_Death_Action;
            AssetManager.traits.add(chong4it);
            addTraitToLocalizedLibrary("cz", chong4it.id, "牺牲我一个……", "自爆人");

            ActorTrait chong4iu = new ActorTrait
            {
                id = "被感染的生物",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4iu);
            addTraitToLocalizedLibrary("cz", chong4iu.id, "", "被感染的生物");

            ActorTrait chong4sh = new ActorTrait
            {
                id = "虫群宿主",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4sh.action_attack_target = ZergAction.Swarm_Host_Action;
            AssetManager.traits.add(chong4sh);
            addTraitToLocalizedLibrary("cz", chong4sh.id, "娜个兵种！", "虫群宿主");

            ActorTrait chong4hc = new ActorTrait
            {
                id = "蝗虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4hc.action_special_effect = ZergAction.Status_Action;
            AssetManager.traits.add(chong4hc);
            addTraitToLocalizedLibrary("cz", chong4hc.id, "", "蝗虫");

            ActorTrait chong4sl = new ActorTrait
            {
                id = "凯瑞甘的利维坦",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4sl);
            chong4sl.action_special_effect = (WorldAction)Delegate.Combine(chong4sl.action_special_effect, new WorldAction(ZergAction.Kongtou2));
            addTraitToLocalizedLibrary("cz", chong4sl.id, "未完成", "凯瑞甘的利维坦");


            ActorTrait chong4bnc = new ActorTrait
            {
                id = "暴虐虫",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4bnc);
            chong4bnc.action_special_effect = ZergAction.Status_Action;
            //毒爆攻击死亡
            chong4bnc.action_attack_target = ZergAction.Chong7zb;
            //毒爆死后自爆伤害
            chong4bnc.action_death = ZergAction.Chong7db;
            addTraitToLocalizedLibrary("cz", chong4bnc.id, "妈的和你爆了", "暴虐虫");


            ActorTrait chong4exyi = new ActorTrait
            {
                id = "精英异龙",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong4exyi);
            addTraitToLocalizedLibrary("cz", chong4exyi.id, "由利维坦孵化的精英", "精英异龙");

            createNewZergTrait("代谢加速", "multiplier_speed", 0.2f, "iconMB", "蜕变，完成\n提速狗来咯", "Metabolic Boost");
            createNewZergTrait("异虫近战攻击等级1", "multiplier_damage", 0.1f, "iconev1", "提升所有异虫单位的近战攻击力,简称1攻", "Evolve Melee Attacks Level 1");
            createNewZergTrait("异虫近战攻击等级2", "multiplier_damage", 0.2f, "iconev2", "提升所有异虫单位的近战攻击力,简称2攻", "Evolve Melee Attacks Level 2");
            createNewZergTrait("异虫近战攻击等级3", "multiplier_damage", 0.3f, "iconev3", "提升所有异虫单位的近战攻击力,简称3攻", "Evolve Melee Attacks Level 3");


            ActorTrait chong6 = new ActorTrait
            {
                id = "异虫 孵化场",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong6);
            //孵化
            chong6.action_special_effect = (WorldAction)Delegate.Combine(chong6.action_special_effect, new WorldAction(ZergAction.Chong6h));
            addTraitToLocalizedLibrary("cz", chong6.id, "虫群即将降临", "异虫 孵化场");

            ActorTrait chong6x = new ActorTrait
            {
                id = "异虫虫穴",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong6x);
            //虫穴 巢虫
            chong6x.action_death = (WorldAction)Delegate.Combine(chong6x.action_death, new WorldAction(ZergAction.Chong6c));
            //孵化
            chong6x.action_special_effect = (WorldAction)Delegate.Combine(chong6x.action_special_effect, new WorldAction(ZergAction.Chong6h));
            addTraitToLocalizedLibrary("cz", chong6x.id, "为异虫提供更多的升级方案和建筑方案\n异虫已经降临", "异虫虫穴");

            ActorTrait chong6z = new ActorTrait
            {
                id = "异虫主巢",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong6z);
            //虫穴 巢虫
            chong6z.action_death = (WorldAction)Delegate.Combine(chong6z.action_death, new WorldAction(ZergAction.Chong6c));
            //孵化
            chong6z.action_special_effect = (WorldAction)Delegate.Combine(chong6z.action_special_effect, new WorldAction(ZergAction.Chong6h));
            addTraitToLocalizedLibrary("cz", chong6z.id, "使幼虫可以变异为飞蛇（还没做QAQ）", "异虫主巢");

            ActorTrait chong7b = new ActorTrait
            {
                id = "异虫建筑",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };//建筑特质格式
            chong7b.addOpposite("madness");
            AssetManager.traits.add(chong7b);
            addTraitToLocalizedLibrary("cz", chong7b.id, "必须放置在菌毯上！", "异虫建筑");

            ActorTrait chong7f = new ActorTrait
            {
                id = "分裂池",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong7f.action_special_effect = (WorldAction)Delegate.Combine(chong7f.action_special_effect, new WorldAction(ZergAction.Chong9mb_sd));
            AssetManager.traits.add(chong7f);
            addTraitToLocalizedLibrary("cz", chong7f.id, "虫群正在形成", "分裂池");

            ActorTrait chong7bc = new ActorTrait
            {
                id = "爆虫巢穴",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7bc);
            addTraitToLocalizedLibrary("cz", chong7bc.id, "居家旅行一波必备", "爆虫巢穴");

            ActorTrait chong7j = new ActorTrait
            {
                id = "进化腔",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong7j.action_special_effect = (WorldAction)Delegate.Combine(chong7j.action_special_effect, new WorldAction(ZergAction.Chong9ev_sd));
            AssetManager.traits.add(chong7j);
            addTraitToLocalizedLibrary("cz", chong7j.id, "一座……骨架？", "进化腔");

            ActorTrait chong7bao = new ActorTrait
            {
                id = "孢子爬虫（扎根）",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7bao);
            addTraitToLocalizedLibrary("cz", chong7bao.id, "令人恐惧", "孢子爬虫（扎根）");

            ActorTrait chong7t = new ActorTrait
            {
                id = "菌毯肿瘤",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7t);
            chong7t.action_special_effect = ZergAction.Tumor_Spread_Jun;

            ActorTrait chong7ta = new ActorTrait
            {
                id = "尖塔",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7ta);

            ActorTrait chong7cc = new ActorTrait
            {
                id = "刺蛇巢",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7cc);
            addTraitToLocalizedLibrary("cz", chong7cc.id, "", "刺蛇巢");

            ActorTrait chong7sh = new ActorTrait
            {
                id = "感染深渊",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7sh);
            addTraitToLocalizedLibrary("cz", chong7sh.id, "娜个建筑！\n使幼虫可以变异为感染者\n（虫群宿主还没做QAQ）", "感染深渊");

            ActorTrait chong7le = new ActorTrait
            {
                id = "雷兽窟",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7le);
            addTraitToLocalizedLibrary("cz", chong7le.id, "未完成", "雷兽窟");

            ActorTrait chong7cj = new ActorTrait
            {
                id = "虫茧",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7cj);
            chong7cj.action_special_effect = ZergAction.MutationFinish;
            addTraitToLocalizedLibrary("cz", chong7cj.id, "猜猜里面是什么", "虫茧");

            ActorTrait chong7zz = new ActorTrait
            {
                id = "主宰",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong7zz.action_special_effect = (WorldAction)Delegate.Combine(chong7zz.action_special_effect, new WorldAction(ZergAction.Chong10));
            chong7zz.action_special_effect = (WorldAction)Delegate.Combine(chong7zz.action_special_effect, new WorldAction(ZergAction.Chong10cs));
            chong7zz.action_get_hit = (GetHitAction)Delegate.Combine(chong7zz.action_get_hit, new GetHitAction(ZergAction.Chong10run));
            AssetManager.traits.add(chong7zz);
            addTraitToLocalizedLibrary("cz", chong7zz.id, "异虫，降临", "主宰");

            ActorTrait chong7cs = new ActorTrait
            {
                id = "主宰传送门 开启",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong7cs.action_special_effect = (WorldAction)Delegate.Combine(chong7cs.action_special_effect, new WorldAction(ZergAction.Chong10cskq));
            AssetManager.traits.add(chong7cs);
            addTraitToLocalizedLibrary("cz", chong7cs.id, "希望位面没事", "主宰传送门 开启");

            ActorTrait chong7cs1 = new ActorTrait
            {
                id = "主宰传送门",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong7cs1.action_special_effect = (WorldAction)Delegate.Combine(chong7cs1.action_special_effect, new WorldAction(ZergAction.Chong10cs_zh));
            AssetManager.traits.add(chong7cs1);
            addTraitToLocalizedLibrary("cz", chong7cs1.id, "希望位面没事", "主宰传送门");

            ActorTrait chong7csz = new ActorTrait
            {
                id = "传送门召唤物",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(chong7csz);
            addTraitToLocalizedLibrary("cz", chong7csz.id, "", "传送门召唤物");


            ActorTrait ZergCommander = new ActorTrait
            {
                id = "虫族指挥官",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(ZergCommander);
            addTraitToLocalizedLibrary("cz", ZergCommander.id, "身份标识", "虫族指挥官");

            ActorTrait Biomass = new ActorTrait
            {
                id = "Zerg_Biomass",
                rate_birth = 0,
                path_icon = "ui/Icons/iconzerg",
                can_be_given = false,
                group_id = "special"
            };
            AssetManager.traits.add(Biomass);


            //ActorTrait Commander = new ActorTrait//已独立为单独模组
            //{
            //    id = "指挥官",
            //    rate_birth = 0.25f,
            //    path_icon = "ui/Icons/iconCeshi",
            //    can_be_given = true,
            //    group_id = "special"
            //};
            //Commander.action_special_effect = MoreAction.Commander;
            //AssetManager.traits.add(Commander);
            //addTraitToLocalizedLibrary("cz", Commander.id, "身份标识", "指挥官");

            createNewZergTrait("变异为 孵化场");
            createNewZergTrait("变异为 分裂池");
            createNewZergTrait("变异为 进化腔");
            createNewZergTrait("变异为 虫穴");
            createNewZergTrait("变异为 爆虫巢穴");
            createNewZergTrait("变异为 孢子爬虫");
            createNewZergTrait("变异为 尖塔");
            createNewZergTrait("变异为 感染深渊");
            createNewZergTrait("变异为 刺蛇巢");
            createNewZergTrait("变异为 主巢");
            createNewZergTrait("变异为 工蜂");
            createNewZergTrait("变异为 跳虫");
            createNewZergTrait("变异为 爆虫");
            createNewZergTrait("变异为 王虫");
            createNewZergTrait("变异为 异龙");
            createNewZergTrait("变异为 感染者");
            createNewZergTrait("变异为 虫群宿主");
            createNewZergTrait("变异为 精英异龙");
            createNewZergTrait("变异为 刺蛇");
            createNewZergTrait("变异为 雷兽");
            createNewZergTrait("变异为 雷兽窟");
            /*
            ActorTrait jiyin1 = new ActorTrait();
            jiyin1.id = "基因进化 一阶";
            jiyin1.base_stats[S.mod_damage] = +0.1f;
            jiyin1.base_stats[S.mod_health] = +0.1f;
            jiyin1.group_id = ZergGroup.xugou;
            jiyin1.path_icon = "ui/Icons/iconjiyin";
            jiyin1.action_death = (WorldAction)Delegate.Combine(jiyin1.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin1);
            addTraitToLocalizedLibrary("cz", jiyin1.id, "基因进化 一阶", "基因进化 一阶");

            ActorTrait jiyin2 = new ActorTrait();
            jiyin2.id = "基因进化 二阶";
            jiyin2.base_stats[S.mod_damage] = +0.50;
            jiyin2.base_stats[S.mod_health] = +50;
            jiyin2.group_id = ZergGroup.xugou;
            jiyin2.path_icon = "ui/Icons/iconjiyin";
            jiyin2.action_death = (WorldAction)Delegate.Combine(jiyin2.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin2);
            addTraitToLocalizedLibrary("cz", jiyin2.id, "基因进化 二阶", "基因进化 二阶");

            ActorTrait jiyin3 = new ActorTrait();
            jiyin3.id = "基因进化 三阶";
            jiyin3.base_stats[S.mod_damage] = +2.50;
            jiyin3.base_stats[S.mod_health] = +2.50;
            jiyin3.group_id = ZergGroup.xugou;
            jiyin3.path_icon = "ui/Icons/iconjiyin";
            jiyin3.action_death = (WorldAction)Delegate.Combine(jiyin3.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin3);
            addTraitToLocalizedLibrary("cz", jiyin3.id, "基因进化 三阶", "基因进化 三阶");

            ActorTrait jiyin4 = new ActorTrait();
            jiyin4.id = "基因进化 四阶";
            jiyin4.base_stats[S.mod_damage] = +7.50;
            jiyin4.base_stats[S.mod_health] = +7.50;
            jiyin4.group_id = ZergGroup.xugou;
            jiyin4.path_icon = "ui/Icons/iconjiyin";
            jiyin4.action_death = (WorldAction)Delegate.Combine(jiyin4.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin4);
            addTraitToLocalizedLibrary("cz", jiyin4.id, "基因进化 四阶", "基因进化 四阶");

            ActorTrait jiyin5 = new ActorTrait();
            jiyin5.id = "基因进化 五阶";
            jiyin5.base_stats[S.mod_damage] = +20.00;
            jiyin5.base_stats[S.mod_health] = +20.00;
            jiyin5.group_id = ZergGroup.xugou;
            jiyin5.path_icon = "ui/Icons/iconjiyin";
            jiyin5.action_death = (WorldAction)Delegate.Combine(jiyin5.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin5);
            addTraitToLocalizedLibrary("cz", jiyin5.id, "基因进化 五阶", "基因进化 五阶");

            ActorTrait jiyin6 = new ActorTrait();
            jiyin6.id = "基因进化 六阶";
            jiyin6.base_stats[S.mod_damage] = +40.00;
            jiyin6.base_stats[S.mod_health] = +40.00;
            jiyin6.group_id = ZergGroup.xugou;
            jiyin6.path_icon = "ui/Icons/iconjiyin";
            jiyin6.action_death = (WorldAction)Delegate.Combine(jiyin6.action_death, new WorldAction(ZergAction.JY0));
            AssetManager.traits.add(jiyin6);
            addTraitToLocalizedLibrary("cz", jiyin6.id, "基因进化 六阶", "基因进化 六阶");

            ActorTrait jiyin7 = new ActorTrait();
            jiyin7.id = "基因进化 七阶";
            jiyin7.base_stats[S.mod_damage] = +10.00;
            jiyin7.base_stats[S.mod_health] = +100.00;
            jiyin7.group_id = ZergGroup.xugou;
            jiyin7.path_icon = "ui/Icons/iconjiyin";
            //jiyin7.action_death = (WorldAction)Delegate.Combine(jiyin7.action_death, new WorldAction(MoreAction.JY0));
            AssetManager.traits.add(jiyin7);
            addTraitToLocalizedLibrary("cz", jiyin7.id, "基因进化 七阶", "基因进化 七阶");

            ActorTrait xibao = new ActorTrait();
            xibao.id = "细胞活化";
            xibao.group_id = ZergGroup.xugou;
            xibao.path_icon = "ui/Icons/iconxibao";
            xibao.action_special_effect = (WorldAction)Delegate.Combine(xibao.action_special_effect, new WorldAction(ZergAction.huohua));
            AssetManager.traits.add(xibao);
            addTraitToLocalizedLibrary("cz", xibao.id, "细胞活化", "细胞活化");
            PlayerConfig.unlockTrait("细胞活化");

            ActorTrait aixibao = new ActorTrait();
            aixibao.id = "基因活化";
            aixibao.rate_birth = 0.2f;
            aixibao.group_id = ZergGroup.xugou;
            aixibao.path_icon = "ui/Icons/iconxibao";
            aixibao.action_special_effect = (WorldAction)Delegate.Combine(aixibao.action_special_effect, new WorldAction(ZergAction.JYhuohua));
            AssetManager.traits.add(aixibao);
            addTraitToLocalizedLibrary("cz", aixibao.id, "基因活化", "基因活化");

            PlayerConfig.unlockTrait("中子灭杀");
            ActorTrait zhongzi = new ActorTrait
            {
                id = "中子灭杀",
                path_icon = "ui/Icons/iconImmune",
                group_id = ZergGroup.zergs
            };
            zhongzi.action_special_effect = (WorldAction)Delegate.Combine(zhongzi.action_special_effect, new WorldAction(ZergAction.Miesha));
            AssetManager.traits.add(zhongzi);
            addTraitToLocalizedLibrary("cz", zhongzi.id, "有人会称这种彻底消灭智慧生命  只保留无机质的做法          为邪‌‌​​‌​​‌​‌​‌​‌​‌​‌​恶的战争罪行      而我们将其称为高效", "中子灭杀");
            PlayerConfig.unlockTrait("中子灭杀");

            ActorTrait dibao = new ActorTrait
            {
                id = "地爆天星",
                group_id = ZergGroup.zergs
            };
            dibao.base_stats[S.mod_health] = -100000;
            dibao.base_stats[S.speed] = -1000;
            dibao.path_icon = "ui/Icons/iconMeteorite";
            dibao.action_special_effect = (WorldAction)Delegate.Combine(dibao.action_special_effect, new WorldAction(ZergAction.Tianxing));
            AssetManager.traits.add(dibao);
            addTraitToLocalizedLibrary("cz", dibao.id, "你家变矿啦", "地爆天星");
            PlayerConfig.unlockTrait("地爆天星");

            ActorTrait anle = new ActorTrait
            {
                id = "安乐天使",
                group_id = ZergGroup.zergs
            };
            anle.base_stats[S.dodge] = +100;
            anle.base_stats[S.speed] = -1000;
            anle.path_icon = "ui/Icons/iconMoodHappy";
            anle.action_special_effect = (WorldAction)Delegate.Combine(anle.action_special_effect, new WorldAction(ZergAction.Tianshi));
            AssetManager.traits.add(anle);
            addTraitToLocalizedLibrary("cz", anle.id, "我们需要一种更加残暴的手段", "安乐天使");
            PlayerConfig.unlockTrait("安乐天使");

            ActorTrait nami = new ActorTrait
            {
                id = "纳米灾疫",
                rate_inherit = 100,
                path_icon = "ui/Icons/iconGreygoo",
                group_id = ZergGroup.zergs
            };
            nami.action_special_effect = (WorldAction)Delegate.Combine(nami.action_special_effect, new WorldAction(ZergAction.Zaiyi));
            AssetManager.traits.add(nami);
            addTraitToLocalizedLibrary("cz", nami.id, "正在寻找有机体", "纳米灾疫");
            PlayerConfig.unlockTrait("纳米灾疫");

            ActorTrait yiti = new ActorTrait
            {
                id = "义体",
                rate_inherit = 100,
                group_id = ZergGroup.zergs
            };
            yiti.base_stats[S.mod_health] = 1f;
            yiti.path_icon = "ui/Icons/iconGreygoo";
            yiti.action_special_effect = (WorldAction)Delegate.Combine(yiti.action_special_effect, new WorldAction(ZergAction.Zaiyi));
            yiti.action_attack_target = new AttackAction(ZergAction.Yiti);
            AssetManager.traits.add(yiti);
            addTraitToLocalizedLibrary("cz", yiti.id, "义体", "义体");
            PlayerConfig.unlockTrait("义体");

            ActorTrait zuzhou = new ActorTrait
            {
                id = "诅咒免疫",
                rate_inherit = 0,
                path_icon = "ui/Icons/iconGreygoo",
                opposite = "cursed",
                group_id = "special"
            };
            AssetManager.traits.add(zuzhou);
            AssetManager.traits.get("cursed").opposite += ",诅咒免疫";
            addTraitToLocalizedLibrary("cz", zuzhou.id, "免疫诅咒", "诅咒免疫");
            PlayerConfig.unlockTrait("诅咒免疫");

            ActorTrait Kingo8 = new ActorTrait
            {
                id = "456Kingo8",
                path_icon = "ui/Icons/icon456",
                rate_birth = 0,
                group_id = "special"
            };
            //无限复活
            //Kingo8.action_death = (WorldAction)Delegate.Combine(Kingo8.action_death, new WorldAction(MoreAction.Chong0));
            //初始三级
            Kingo8.action_special_effect = (WorldAction)Delegate.Combine(Kingo8.action_special_effect, new WorldAction(ZergAction.sanji));
            //交战中摄取敌人的生命治愈己身
            Kingo8.action_attack_target = new AttackAction(ActionLibrary.restoreHealthOnHit);
            AssetManager.traits.add(Kingo8);
            addTraitToLocalizedLibrary("cz", Kingo8.id, "普通的作者", "456Kingo8");
            PlayerConfig.unlockTrait("456Kingo8");

            ActorTrait Aimeng = new ActorTrait
            {
                id = "埃蒙",
                can_be_given = true,
                path_icon = "ui/Icons/iconAM",
                rate_birth = 0,
                group_id = ZergGroup.zergs
            };
            Aimeng.action_attack_target = new AttackAction(ZergAction.Tonghua);
            AssetManager.traits.add(Aimeng);
            addTraitToLocalizedLibrary("cz", Aimeng.id, "只是一只可可爱爱的感染虫而已（）", "埃蒙");
            PlayerConfig.unlockTrait("埃蒙");
            //ActorTrait Ling = new ActorTrait
            //{
            //    id = "测试",
            //    can_be_given = false,
            //    path_icon = "ui/Icons/iconLing",
            //    rate_birth = 0
            //};
            ////Ling.action_special_effect = (WorldAction)Delegate.Combine(Ling.action_special_effect, new WorldAction(MoreAction.Chong3));
            //AssetManager.traits.add(Ling);
            //addTraitToLocalizedLibrary("cz", Ling.id, "测试专用特质", "测试");
            //PlayerConfig.unlockTrait("测试");
            */
        }


        //翻译器，允许制作多语言模组
        //使用方法：addTraitToLocalizedLibrary(中文cz英文en, string id, string description, string name)
        public static void addTraitToLocalizedLibrary(string planguage, string id, string description, string name)
        {
            //MonoBehaviour.print($"\"trait_{id}\":\"{name}\",");
            //MonoBehaviour.print($"\"trait_{id}_info\":\"{description}\",");
            //string language = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
            //if (planguage == language)
            //{
            //    Dictionary<string, string> localizedText = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "localizedText") as Dictionary<string, string>;
            //    localizedText.Add("trait_" + id, name);
            //    localizedText.Add("trait_" + id + "_info", description);
            //}

        }
        private static void createNewZergTrait(string id, string stats_key = null,float stats = 0, string icon = "iconZerg", string cz_description = "", string en_id = "",string en_description = "")
        {
            ActorTrait trait = new ActorTrait
            {
                id = id,
                rate_birth = 0,
                group_id = "special"
            };
            if (stats_key != null) 
            {
                trait.base_stats = new BaseStats();
                trait.base_stats[stats_key] = stats; 
            }
            
            trait.path_icon = $"ui/Icons/{icon}";
            trait.can_be_given = false;
            AssetManager.traits.add(trait);
            addTraitToLocalizedLibrary("cz", trait.id, cz_description, id);
            if(en_id == "")
            {
                en_id = id;
            }
            addTraitToLocalizedLibrary("en", trait.id, en_description, en_id);

        }
    }
}
