﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    internal class ZergSubspeciesTrait
    {
        public static void init()
        {
            SubspeciesTrait NoSleep = new SubspeciesTrait();
            NoSleep.id = "NoSleep";
            NoSleep.group_id = "sleep_cycles";
			NoSleep.rarity = Rarity.R1_Rare;
			NoSleep.priority = 105;
            NoSleep.path_icon = "ui/Icons/iconZerg";
            AssetManager.subspecies_traits.add(NoSleep);

            SubspeciesTrait ZergBiome =  AssetManager.subspecies_traits.clone("adaptation_Jun", "$adaptation$");
            ZergBiome.rarity = Rarity.R2_Epic;
            ZergBiome.base_stats_meta.addTag("can_build_in_biome_Jun");
            ZergBiome.path_icon = "ui/Icons/iconZerg";

            SubspeciesTrait Hivemind = new SubspeciesTrait();
            Hivemind.id = "Hivemind";
            Hivemind.group_id = "advanced_brain";
            Hivemind.rarity = Rarity.R1_Rare;
            Hivemind.priority = 105;
            Hivemind.path_icon = "ui/Icons/iconZerg";
            Hivemind.addDecision("build_zerg_kingdom");
            Hivemind.decisions_assets = new DecisionAsset[1] {ZergJob.dec_build_zerg_kingdom};
            AssetManager.subspecies_traits.add(Hivemind);

            SubspeciesTrait test = AssetManager.subspecies_traits.get("advanced_hippocampus");
            test.decisions_assets.Append(ZergJob.dec_build_zerg_kingdom);
        }
    }
}
