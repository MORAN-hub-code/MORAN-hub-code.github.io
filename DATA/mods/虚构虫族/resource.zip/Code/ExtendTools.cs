﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    internal static class ExtendTools
    {
        public static void setBaseStats(this ActorAsset baseStats, int pHealth, int pDamage, int pSpeed, int pArmor)
        {

            baseStats.addGenome(new ValueTuple<string, float>[]
            {
                new ValueTuple<string, float>("health", pHealth),
                new ValueTuple<string, float>("stamina", 200f),
                new ValueTuple<string, float>("mutation", 0f),
                new ValueTuple<string, float>("damage", pDamage),
                new ValueTuple<string, float>("armor", pArmor),
                new ValueTuple<string, float>("speed", pSpeed)
            });

            baseStats.build_order_template_id = AssetManager.actor_library.get("bee").build_order_template_id;
            baseStats.architecture_id = "civ_druid";
            baseStats.architecture_asset = AssetManager.architecture_library.get(baseStats.architecture_id);
            baseStats.use_tool_items = true;
            baseStats.use_items = true;
            baseStats.banner_id = AssetManager.actor_library.get("bee").banner_id;
        }
    }
}
