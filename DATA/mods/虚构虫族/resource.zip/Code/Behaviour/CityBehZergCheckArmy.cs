﻿using ai.behaviours;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg.Behaviour
{
    public class CityBehZergCityCheckArmy : BehaviourActionCity
    {
        public override BehResult execute(City pCity)
        {
            pCity.checkArmyExistance();
            if (pCity.hasArmy())
            {
                return BehResult.Continue;
            }
            foreach(Actor actor in pCity.units)
            {
                if(MoreActor.Zerg_Fighter.Contains(actor.asset.id))
                {
                    world.armies.newArmy(actor, pCity);
                    break;
                }
            }
            return BehResult.Continue;
        }
    }
}
