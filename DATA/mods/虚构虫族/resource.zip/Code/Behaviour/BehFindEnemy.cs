﻿using HarmonyLib;
//using System;
//using NCMS;
//using NCMS.Utils;
//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text.RegularExpressions;
//using System.Reflection;
//using ReflectionUtility;
//using System.Threading;
//using System.Text;
//using ai;
//using ai.behaviours;

//namespace Zerg
//{
//    class BehFindEnemy : BehaviourActionActor//万分感谢 pvz mod作者 寒海的代码
//    {
//        public override BehResult execute(Actor pActor)
//        {
//            if (BehaviourActionBase<Actor>.world.worldLaws.world_law_peaceful_monsters.boolVal)
//            {
//                return BehResult.Stop;
//            }
//            if (pActor.tileTarget != null && pActor.attackTarget == null || pActor.attackTarget != null)
//            {
//                return BehResult.Stop;
//            }
//            Actor unit = null;
//            float num = 0f;
//            foreach (Actor unit2 in world.units)
//            {
//                if (unit2.kingdom != null && pActor.kingdom.isEnemy(unit2.kingdom)
//                && unit2 != pActor && Main.isTargetOk(pActor, unit2))
//                {
//                    float num2 = Toolbox.DistTile(unit2.currentTile, pActor.currentTile);
//                    if (unit == null || num2 < num)
//                    {
//                        unit = unit2; num = num2;
//                    }
//                }
//            }
//            if (unit == null)
//            {
//                return BehResult.Stop;
//            }

//            pActor.beh_actor_target = unit;
//            if (unit != null && unit.data.alive)
//            {
//                pActor.goTo(pActor.beh_actor_target.currentTile, false, false);
//            }
//            return BehResult.Continue;
//        }
//    }
//}