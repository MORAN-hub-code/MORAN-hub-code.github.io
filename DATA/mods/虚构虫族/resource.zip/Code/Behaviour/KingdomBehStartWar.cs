﻿using ai.behaviours;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg.Behaviour
{
    public class KingdomBehStartWar : BehaviourActionKingdom
    {
        public override BehResult execute(Kingdom pKingdom)
        {
            if (!pKingdom.hasKing())
            {
                return BehResult.Stop;
            }
            if(pKingdom.king.asset.id == SZB.Hive)
            {
                foreach(Kingdom kingdom in World.world.kingdoms)
                {
                    if(!pKingdom.isEnemy(kingdom) && kingdom != pKingdom)
                    {
                        world.wars.newWar(pKingdom, kingdom, WarTypeLibrary.spite);
                        WorldLog.logNewWar(pKingdom, kingdom);
                    }
                }
            }
            return BehResult.Continue;
        }

    }
}
