﻿using ai.behaviours;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg.Behaviour
{
    public class CityBehZergUpdateArmy : BehaviourActionCity
    {
        public override BehResult execute(City pCity)
        {
            if (pCity.hasArmy())
            {
                Subspecies sub;
                foreach (string str in MoreActor.Zerg_Fighter)
                {
                    sub = pCity.getSubspecies(str);
                    if (sub != null)
                    {
                        foreach (Actor act in sub.units)
                        {
                            if (act.city == pCity && !act.hasArmy())
                            {
                                act.setArmy(pCity.army);
                            }
                        }
                    }
                }
            }
            return BehResult.Continue;
        }

    }
}
