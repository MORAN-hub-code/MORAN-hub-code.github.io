﻿using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;
using System.Threading;
using System.Text;
using ai;
using ai.behaviours;
using NeoModLoader.api.attributes;

namespace Zerg
{
    class BehFindEnemy2 : BehaviourActionActor//修改自pvz代码的追杀2.0 更适合Zerg宝宝体质的追杀qwq
    {
        [Hotfixable]
        public override BehResult execute(Actor pActor)
        {
            if(Randy.randomChance(0.8f))
            {
                return BehResult.Stop;
            }
            if(!pActor.hasTrait("虫族指挥官"))
            {
                return BehResult.Stop;
            }
            //MonoBehaviour.print("debugbeh");
            if (world.world_laws.dict["world_law_peaceful_monsters"].boolVal)
            {
                return BehResult.Stop;
            }
            if (PlayerConfig.dict["Zhuisha_law"].boolVal)
            {
                return BehResult.Stop;
            }
            if (pActor.tile_target != null && pActor.attack_target == null)
            {
                return BehResult.Stop;
            }
            //MonoBehaviour.print("debugbeh2");
            Actor unit = null;
            float num = 0f;
            foreach (Actor unit2 in Finder.getUnitsFromChunk(pActor.current_tile,0,8))
            {
                //MonoBehaviour.print("finde1");
                if (unit2.kingdom != null && pActor.kingdom.isEnemy(unit2.kingdom)
                && unit2 != pActor && ZergMain.flyerisTargetOk(pActor, unit2))
                {
                    //MonoBehaviour.print("finde2");
                    float num2 = Toolbox.DistTile(unit2.current_tile, pActor.current_tile);
                    if (unit == null || num2 < num)
                    {
                        unit = unit2; num = num2;
                    }
                }
            }
            //MonoBehaviour.print("debugbeh3");
            if (unit == null)
            {
                return BehResult.Stop;
            }
            //MonoBehaviour.print("debugbeh4");
            int cnt = 0;
            foreach (Actor actor in pActor.kingdom.units)
            {
                if (actor.tile_target != null && actor.attack_target == null || actor.attack_target != null || !MoreActor.Zerg_Fighter.Contains(actor.asset.id))
                {
                    continue;
                }
                actor.beh_actor_target = unit;
                if (unit != null && unit.isAlive())
                {
                    actor.goTo(actor.beh_actor_target.current_tile, false, false);
                    cnt++;
                }
                if(cnt > 500)
                {
                    break;
                }

            }

            if (pActor.asset.id == SZA.Overlord)
            {
                if (unit != null && unit.isAlive())
                {
                    pActor.goTo(unit.current_tile, false, false);
                }
            }
            return BehResult.Continue;
        }
    }
}