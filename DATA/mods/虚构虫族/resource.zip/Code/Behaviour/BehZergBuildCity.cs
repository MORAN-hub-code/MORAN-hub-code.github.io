﻿using ai.behaviours;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Zerg.Behaviour
{
    public class BehZergBuildCity : BehaviourActionActor
    {
        public override BehResult execute(Actor pActor)
        {
            MonoBehaviour.print("[Zerg]execute : BehZergBuildCity");
            bool check = true;
            WorldTile tActorTile = pActor.current_tile;
            TileZone tActorZone = tActorTile.zone;
            foreach (TileZone tNeighbourZone in tActorZone.neighbours)
            {
                if (tNeighbourZone.hasCity())
                {
                    WorldTile tTile = tNeighbourZone.city.getTile(false);
                    if (tTile != null && tTile.isSameIsland(tActorTile))
                    {
                        tNeighbourZone.city.addZone(tActorZone);
                        check = false;
                        break;
                    }
                }
            }
            if(check)
            {
                Kingdom kingdom = World.world.kingdoms.makeNewCivKingdom(pActor, null, true);
                City city = World.world.cities.buildNewCity(pActor, pActor.current_zone);
                city.createAI();
                kingdom.createAI();
                pActor.joinCity(city);
                city.setUnitMetas(pActor);
                city.convertSameSpeciesAroundUnit(pActor);
                kingdom.setUnitMetas(pActor);
                city.setUnitMetas(pActor);
                MutationAsset mutation = MutationLibrary.dict[SZA.Drone].Find(a => a.mutationUnit == SZB.Hatchery);

                var act = World.world.units.createNewUnit(mutation.cocoonID, pActor.current_tile);
                act.addStatusEffect("变异", mutation.costTime);
                act.addTrait("变异为 孵化场");
                act.kingdom = pActor.kingdom;
                act.city = pActor.city;
                act.city.units.Add(act);
                kingdom.setKing(act);
                pActor.die(true);
            }
            return BehResult.Continue;
        }
    }
}
