﻿//using HarmonyLib;
//using System;
//using NCMS;
//using NCMS.Utils;
//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text.RegularExpressions;
//using System.Reflection;
//using ReflectionUtility;
//using System.Threading;
//using System.Text;
//using ai;
//using ai.behaviours;

//namespace Zerg
//{
//    class FlyerBehFindEnemy : BehaviourActionActor//万分感谢 pvz mod作者 寒海的代码
//    {
//        public override BehResult execute(Actor pActor)
//        {
//            if (BehaviourActionBase<Actor>.world.worldLaws.world_law_peaceful_monsters.boolVal)
//            {
//                return BehResult.Stop;
//            }
//            if (pActor.tileTarget != null && pActor.attackTarget == null || pActor.attackTarget != null)
//            {
//                return BehResult.Stop;
//            }
//            Building building = null;
//            Actor unit = null;
//            float num = 0f;
//            foreach (Actor unit2 in BehaviourActionBase<Actor>.world.units)
//            {
//                if (unit2.kingdom != null && pActor.kingdom.isEnemy(unit2.kingdom)
//                && unit2 != pActor && Main.flyerisTargetOk(pActor, unit2))
//                {
//                    float num2 = Toolbox.DistTile(unit2.currentTile, pActor.currentTile);
//                    if (unit == null || num2 < num)
//                    {
//                        unit = unit2; num = num2;
//                    }
//                }
//            }
//            foreach (Building building2 in BehaviourActionBase<Actor>.world.kingdoms.getKingdomByID(S.golden_brain).buildings)
//            {
//                if (building2.currentTile.isSameIsland(pActor.currentTile))
//                {
//                    float num2 = Toolbox.DistTile(building2.currentTile, pActor.currentTile);
//                    if (building == null || num2 < num)
//                    {
//                        building = building2;
//                        num = num2;
//                    }
//                }
//            }

//            if (building == null && unit == null)
//            {
//                return BehResult.Stop;
//            }

//            if (unit == null && building == null)
//            {
//                return BehResult.Stop;
//            }

//            pActor.beh_actor_target = unit;
//            pActor.beh_building_target = building;
//            if (unit != null && unit.data.alive)
//            {
//                pActor.goTo(pActor.beh_actor_target.currentTile, false, false);
//            }
//            if (building != null)
//            {
//                pActor.goTo(pActor.beh_building_target.currentTile, false, false);
//            }
//            return BehResult.Continue;
//        }
//    }
//}