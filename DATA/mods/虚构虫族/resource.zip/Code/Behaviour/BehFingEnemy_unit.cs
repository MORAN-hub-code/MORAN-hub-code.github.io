﻿//using ai.behaviours;

//namespace Zerg
//{
//    class BehFindEnemy_unit : BehaviourActionActor//修改自pvz代码的追杀2.0 适用于所有种族qwq
//    {
//        public override BehResult execute(Actor pActor)
//        {
//            Main.print("debug");
//            Actor unit = null;
//            float num = 0f;
//            foreach (Actor unit2 in world.units)
//            {
//                if (unit2.kingdom != null && pActor.kingdom.isEnemy(unit2.kingdom)
//                && unit2 != pActor && Main.flyerisTargetOk(pActor, unit2))
//                {
//                    float num2 = Toolbox.DistTile(unit2.currentTile, pActor.currentTile);
//                    if (unit == null || num2 < num)
//                    {
//                        unit = unit2; num = num2;
//                    }
//                }
//            }
//            if (unit == null)
//            {
//                return BehResult.Stop;
//            }
//            Kingdom kingdom = World.world.kingdoms.dict_hidden[pActor.kingdom.id];
//            foreach (Actor actor in kingdom.units)
//            {
//                if (actor.tileTarget != null && actor.attackTarget == null || actor.attackTarget != null)
//                {
//                    continue;
//                }
//                if (actor.citizen_job != null && actor.citizen_job.id == S.attacker)
//                {
//                    actor.beh_actor_target = unit;
//                   if (unit != null && unit.data.alive)
//                   {
//                       actor.goTo(actor.beh_actor_target.currentTile, false, false);
//                   }
//                }
//            }
//            return BehResult.Continue;
//        }
//    }
//}
