﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    class ZergSkill
    {
        public static void init()
        {

            StatusAsset Meijzs = new StatusAsset();
            Meijzs.id = "霉菌滋生";
            Meijzs.texture = "effects/Meijun";
            Meijzs.sprite_list = new UnityEngine.Sprite[] {SpriteTextureLoader.getSprite(Meijzs.texture+"/0")};
            Meijzs.animated = true;
            Meijzs.duration = 3f;
            Meijzs.action = ZergEffects.Zishen;
            Meijzs.action_interval = 0.1f;
            Meijzs.base_stats[S.speed] = -2147483648;
            Meijzs.path_icon = "ui/Icons/iconchong";
            Meijzs.locale_description = "使目标范围内的单位移动速度降低到最低\n并在3秒内造成总计30点伤害";
            AssetManager.status.add(Meijzs);
            MoreAction.add_id_and_description(Meijzs.id, Meijzs.locale_description);

            createCDEffect("霉菌滋生", 3f);
            createCDEffect("异化作战体", 14f);
            createCDEffect("孵化蝗虫", 20f);
            createCDEffect("孵化异龙", 8f);
            createCDEffect("空投囊", 4f);
            createCDEffect("传送门", 150f);
            ActorTrait chong4gr_sjjs = new ActorTrait
            {
                id = "神经寄生",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            chong4gr_sjjs.action_special_effect = (WorldAction)Delegate.Combine(chong4gr_sjjs.action_special_effect, new WorldAction(ZergAction.Chong7gr_sjjs));
            AssetManager.traits.add(chong4gr_sjjs);
            MoreTraits.addTraitToLocalizedLibrary("cz", chong4gr_sjjs.id, "该生物已被虫族控制", "神经寄生");

            StatusAsset Shenjjs = new StatusAsset();
            Shenjjs.id = "神经寄生";
            Shenjjs.duration = 30f;
            Shenjjs.path_icon = "ui/Icons/iconZerg";
            Shenjjs.locale_description = "使目标单位被感染者控制";
            AssetManager.status.add(Shenjjs);
            MoreAction.add_id_and_description(Shenjjs.id, Shenjjs.locale_description);

            StatusAsset Shenjjs_cd = new StatusAsset();
            Shenjjs_cd.id = "神经寄生冷却";
            Shenjjs_cd.duration = 60f;
            Shenjjs_cd.path_icon = "ui/Icons/iconZerg";
            Shenjjs_cd.locale_description = "";
            AssetManager.status.add(Shenjjs_cd);
            MoreAction.add_id_and_description(Shenjjs_cd.id, Shenjjs_cd.locale_description);

            StatusAsset Buyu_cd = new StatusAsset();
            Buyu_cd.id = "哺育冷却";
            Buyu_cd.duration = 60f;
            Buyu_cd.path_icon = "ui/Icons/iconZerg";
            Buyu_cd.locale_description = "";
            AssetManager.status.add(Buyu_cd);
            MoreAction.add_id_and_description(Buyu_cd.id, Buyu_cd.locale_description);


            ActorTrait Luan = new ActorTrait()
            {
                id = "注卵",
                rate_birth = 0,
                path_icon = "ui/Icons/iconZerg",
                can_be_given = false,
                group_id = "special"
            };
            Luan.action_special_effect = LuanAction;
            AssetManager.traits.add(Luan);
            MoreTraits.addTraitToLocalizedLibrary("cz", Luan.id, "", "注卵");

            StatusAsset ZhuLuan = new StatusAsset();
            ZhuLuan.id = "注卵";
            ZhuLuan.duration = 40f;
            ZhuLuan.path_icon = "ui/Icons/iconZerg";
            ZhuLuan.locale_description = "持续时间结束后产生4只幼虫";
            AssetManager.status.add(ZhuLuan);
            MoreAction.add_id_and_description(ZhuLuan.id, ZhuLuan.locale_description);

            StatusAsset ZhuLuan_cd = new StatusAsset();
            ZhuLuan_cd.id = "注卵冷却";
            ZhuLuan_cd.duration = 60f;
            ZhuLuan_cd.path_icon = "ui/Icons/iconZerg";
            ZhuLuan_cd.locale_description = "";
            AssetManager.status.add(ZhuLuan_cd);
            MoreAction.add_id_and_description(ZhuLuan_cd.id, ZhuLuan_cd.locale_description);

        }

        public static void createCDEffect(string id,float time)
        {
            StatusAsset _cd = new StatusAsset();
            _cd.id = id + "冷却";
            _cd.duration = time;
            _cd.path_icon = "ui/Icons/iconZerg";
            _cd.locale_description = "";
            AssetManager.status.add(_cd);
            MoreAction.add_id_and_description(_cd.id, _cd.locale_description);
        }
        public static bool LuanAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if(pTarget == null) { return false; }
            if (!pTarget.hasStatus("注卵"))
            {
                pTarget.a.removeTrait("注卵");
                for (int i = 0; i < 4; i++)
                {
                    World.world.units.createNewUnit(SZA.Larva, pTile);
                }
            }
            return true;
        }

    }
}
