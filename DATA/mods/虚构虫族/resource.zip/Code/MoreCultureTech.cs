﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;
using System.Reflection;
using ai;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using NCMS.Utils;
using UnityEngine;
using System.ComponentModel;
using UnityEngine.Assertions;
using EpPathFinding.cs;
using System.IO;

namespace Zerg
{
    class MoreCultureTech
    {
        public static void init()
        {
            //CultureTechAsset Jingti = new CultureTechAsset();
            //Jingti.id = "material_Jingti";
            //Jingti.path_icon = "tech/Jing";
            //Jingti.required_level = 20;
            //Jingti.requirements = new List<string>() { "material_iron" };
            //AssetManager.culture_tech.add(Jingti);
            //addCultureIDandInfo(Jingti.id, "晶体矿", "解锁泰伦科技");

            //CultureTechAsset Terran_1 = new CultureTechAsset();
            //Terran_1.id = "Terran_1";
            //Terran_1.path_icon = "tech/TR1";
            //Terran_1.required_level = 30;
            //Terran_1.requirements = new List<string>() { "material_Jingti", "material_steel" };
            //AssetManager.culture_tech.add(Terran_1);
            //addCultureIDandInfo(Terran_1.id, "泰伦科技 一级", "解锁武器C-14型高斯步枪");
        }

        private static void addCultureIDandInfo(string tech_id, string id, string info)
        {
            Localization.AddOrSet("tech_" + tech_id, id);
            Localization.AddOrSet("tech_info_" + tech_id, info);
        }
    }
}