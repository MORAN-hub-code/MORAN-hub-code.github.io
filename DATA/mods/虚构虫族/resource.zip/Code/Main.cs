﻿using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections.Generic;
using HarmonyLib;
using NeoModLoader.api;

namespace Zerg
{

    class ZergMain : BasicMod<ZergMain>
    {
        internal static Harmony harmony;
        private static bool tabInitialized = false;
        private static bool tabsHidden = false;
        private float update;
        public ZergEffects ZergEffects = new ZergEffects();
        public static bool Zerg_Era_on;
        private static bool secondUpdate = true;

        Dictionary<Kingdom, bool> keys = new Dictionary<Kingdom, bool>();

        protected override void OnModLoad()
        {
            Config.isEditor = true;
            //SimGlobals.m.unit_chunk_sight_range = 3;
            Patches.init();
            MutationLibrary.init();
            ZergJob.init();
            ZergAction.init();
            MoreResource.init();
            MoreBuilding.init();
            MoreTerraform.init();

            MoreCultureTech.init();
            ZergGroup.init();
            MoreTraits.init();
            ZergSubspeciesTrait.init();
            MonoBehaviour.print("虫族特质加载成功");
            ZergKingdom.init();
            MoreActor.init();
            MonoBehaviour.print("虫族生物加载成功");


            JunBiome.init();
            MonoBehaviour.print("虫族地形加载成功");

            MoreDisaster.init();
            MonoBehaviour.print("虫族灾难加载成功");
            ZergEffects.init();
            MoreProjectiles.init();
            ZergSkill.init();
            ZergDrops.init();
            ZergEra.init();
            Zergitem.init();
            ZergCloud.init();
            ZergMapIcon.init();

            Harmony.CreateAndPatchAll(typeof(ZergAction));
            Harmony.CreateAndPatchAll(typeof(ZergEra));
        }

        void Update()
        {
            if (!Config.game_loaded)
            {
                return;
            }
            
            if (!tabInitialized)
            {
                MonoBehaviour.print("虫族栏位加载成功");
                ZergTab.init();
                Buttons.init();
                tabInitialized = true;
                ZergTab.tab.powerButton.gameObject.SetActive(!tabsHidden);
            }
            if (Buttons.button_finish)
            {
                //if (PowerButtons.GetToggleValue("ZergEra")&&World.world_era.id != "ZergEra"&&!Zerg_Era_on)
                //{
                //    World.world.era_manager.setCurrentAge(ZergEra.Zerg_Era);
                //    Zerg_Era_on = true;
                //}
                //else if(!PowerButtons.GetToggleValue("ZergEra"))
                //{
                //    if (World.world.era_manager.getNextAge() != null && World.world_era.id == "ZergEra" &&Zerg_Era_on)
                //    {
                //        World.world.era_manager.startNextAge();
                //    }
                //    Zerg_Era_on = false;
                //}
                //if(PowerButtons.GetToggleValue("show_Zerg_law"))
                //{
                //    foreach (Actor unit in World.world.units)
                //    {
                //        if (unit.hasTrait("异虫") || unit.hasTrait("异虫建筑"))
                //        {
                //            QuantumSpriteLibrary.drawQuantumSprite(ZergMapIcon.ZergQuantum, unit.current_tile.zone.centerTile.posV, null, null, null, null, 1f, false, -1f);
                //        }
                //    }
                //}
            }

            if(secondUpdate)
            {
                secondUpdate = false;
                ZergGene.init();
            }
            /*
            foreach (Kingdom kingdom in World.world.kingdoms.list)
            {
                if (kingdom.units.Count < 1000)
                {
                    continue;
                }
                if (!keys.ContainsKey(kingdom))
                {
                    keys.Add(kingdom, true);
                }
                if (keys[kingdom] == false)
                {
                    bool flag = true;
                    foreach (Actor actor in kingdom.units)
                    {
                        if (actor.hasTrait("指挥官"))
                        {
                            flag = false;
                            break;
                        }
                    }
                    keys[kingdom] = flag;
                }
                else
                {
                    if (kingdom.isCiv())
                    {
                        if (kingdom.king != null)
                        {
                            kingdom.king.addTrait("指挥官");
                        }
                    }
                    else
                    {
                        foreach (Actor actor in kingdom.units)
                        {
                            if (actor != null && actor.data.health > 0 && actor.getAge() > 18)
                            {
                                actor.addTrait("指挥官");
                                actor.data.favorite = true;
                                keys[kingdom] = false;
                            }
                        }
                    }
                }
            }*/
        }
        public static bool isTargetOk(Actor pActor, Actor pTarget)
        {
            return pActor != null && pTarget != null && !(pTarget == pActor) && pTarget.current_tile != null
      && pActor.current_tile != null && pActor.canAttackTarget(pTarget) && pTarget.current_tile.isSameIsland(pActor.current_tile);
        }
        public static bool flyerisTargetOk(Actor pActor, Actor pTarget)
        {
            return pActor != null && pTarget != null && !(pTarget == pActor) && pTarget.current_tile != null
      && pActor.current_tile != null && MoreAction.canAttackTarget(pActor,pTarget);
        }

    }
}