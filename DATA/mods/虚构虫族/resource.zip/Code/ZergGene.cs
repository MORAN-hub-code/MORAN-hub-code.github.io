﻿using EpPathFinding.cs;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    class ZergGene
    {
        public static List<string> GenesLibrary = new List<string>();
        public static Dictionary<string, bool> GenesValue = new Dictionary<string, bool>();
        public static bool GenesUpdate = true;
        public static void init()
        {
            //            foreach (ActorTrait trait in AssetManager.traits.list)
            //            {
            //                if (GenesValue.ContainsKey(trait.id))
            //                {
            //                    continue;
            //                }

            //                bool flag = trait.group_id != TraitGroup.mind && trait.group_id != TraitGroup.spirit && trait.group_id != TraitGroup.acquired;
            //                if (trait.group_id == TraitGroup.body)
            //                {
            //                    GenesValue.Add(trait.id, flag);
            //                }
            //                else if (trait.group_id == TraitGroup.special)
            //                {
            //                    GenesValue.Add(trait.id, flag && trait.can_be_given);
            //                }
            //                //else
            //                //{
            //                //    if (trait.base_stats[S.health] < 0 || trait.base_stats[S.mod_health] < 0 || trait.base_stats[S.mod_armor] < 0 || trait.base_stats[S.health] < 0 || trait.base_stats[S.mod_attack_speed] < 0 || trait.base_stats[S.mod_attack_speed] < 0 || trait.base_stats[S.mod_attack_speed] < 0 || trait.base_stats[S.attack_speed] < 0 || trait.base_stats[S.mod_damage] < 0 || trait.base_stats[S.damage] < 0 || trait.base_stats[S.damage_range] < 0 || trait.base_stats[S.range] < 0 || trait.base_stats[S.mod_crit] < 0 || trait.base_stats[S.knockback_reduction] < 0 || trait.base_stats[S.critical_chance] < 0)
            //                //    {
            //                //        GenesValue.Add(trait.id, false);
            //                //    }
            //                //    else
            //                //    {
            //                //        GenesValue.Add(trait.id, true);
            //                //    }
            //                //}
            //            }

            //            GenesValue["lustful"] = false;
            //            GenesValue["tiny"] = false;
            //            GenesValue["ugly"] = false;
            //            GenesValue["fat"] = false;
            //            GenesValue["weak"] = false;
            //            GenesValue["gluttonous"] = false;
            //            GenesValue["flower_prints"] = false;
            //            GenesValue["acid_touch"] = false;
            //            GenesValue["acid_blood"] = false;
            //            GenesValue["fire_touch"] = false;
            //            GenesValue["fire_blood"] = false;
            //            GenesValue["mega_heartbeat"] = false;
            //            GenesValue["bomberman"] = false;
            //            GenesValue["short_sighted"] = false;
            //            GenesValue["pyromaniac"] = false;
            //            GenesValue["bubble_defense"] = false;

            //            GenesValue["shiny"] = false;
            //            GenesValue["super_health"] = false;
            //            GenesValue["death_nuke"] = false;
            //            GenesValue["death_bomb"] = false;
            //            GenesValue["death_mark"] = false;
            //            GenesValue["energized"] = false;
            //            GenesValue["flesh_eater"] = true;

            //            GenesValue["中子灭杀"] = false;
            //            GenesValue["基因活化"] = false;
            //            GenesValue["细胞活化"] = false;
            //            GenesValue["地爆天星"] = false;
            //            GenesValue["安乐天使"] = false;
            //            GenesValue["纳米灾疫"] = false;
            //            GenesValue["义体"] = false;
            //            GenesValue["诅咒免疫"] = false;
            //            GenesValue["456Kingo8"] = false;
            //            GenesValue["虫族基因（显性）"] = false;
            //            GenesValue["虫族基因（隐性）"] = false;
            //            GenesValue["虚构虫族母巢"] = false;
            //            GenesValue["灵能强化"] = false;
            //            GenesValue["异虫感染"] = false;
            //            GenesValue["异虫寄生"] = false;


            //            //foreach (ActorTrait trait in AssetManager.traits.list)
            //            //{
            //            //    if (GenesValue.ContainsKey(trait.id))
            //            //    {
            //            //        Main.print(trait.id + ": " + GenesValue[trait.id]);

            //            //    }
            //            //}
        }


        //        public static bool Genes(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        //        {
        //            if(pTarget != null &&pTarget.isActor())
        //            {
        //                foreach (string trait in pTarget.a.data.traits)
        //                {
        //                    addGenesToList(trait);
        //                }
        //            }
        //            return true;
        //        }

        //        public static void addGenesToList(string trait)
        //        {
        //            if(GenesValue.ContainsKey(trait))
        //            {
        //                if (GenesValue[trait] && ! GenesLibrary.Contains(trait))
        //                {
        //                    GenesLibrary.Add(trait);
        //                    GenesUpdate = true;
        //                }
        //            }
        //}
    }
}
