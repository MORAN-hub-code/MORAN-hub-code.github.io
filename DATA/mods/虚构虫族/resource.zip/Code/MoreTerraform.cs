﻿namespace Zerg
{
    class MoreTerraform
    {
        public static void init()
        {
            //TerraformOptions Meijunzisheng = new TerraformOptions();
            //Meijunzisheng.id = "meijunzisheng";
            //Meijunzisheng.addTrait = "霉菌滋生";
            //AssetManager.terraform.add(Meijunzisheng);
        }
    }
}