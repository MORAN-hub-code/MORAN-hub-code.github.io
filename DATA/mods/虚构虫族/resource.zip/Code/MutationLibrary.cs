﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    class MutationLibrary
    {
        //{ { "孵化场", 60f }, { "分裂池", 10f }, { "进化腔", 25f }, { "孢子爬虫", 6f }, { "尖塔", 17f }, { "爆虫巢穴", 17f }, { "感染深渊", 17f },
        //  { "工蜂", 4f }, { "跳虫", 5f }, { "王虫", 8f }, { "异龙", 10f }, { "爆虫", 10f },{ "感染者", 10f },
        //  { "虫穴", 80f }, { "主巢", 110f }
        public static Dictionary<string, List<MutationAsset>> dict = new Dictionary<string, List<MutationAsset>>();
        public static void init()
        {
            MutationAsset asset;
            Condition condition = new Condition(SZB.Cocoons_Building, 4, false);
            asset = new MutationAsset
            {
                mutationUnit = SZA.Drone,
                chance = 0.1f,
                costTime = 4,
                conditions = { new Condition(SZA.Drone, 5, false) }
            };
            dict.Add(SZA.Larva,new List<MutationAsset> {asset});

            asset = new MutationAsset
            {
                mutationUnit = SZA.Zergling,
                chance = 0.05f,
                num = 2,
                conditions = { new Condition(SZB.Spawning_Pool, 0, true) }
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Overlord,
                chance = 0.025f,
                costTime = 8,
                conditions = { new Condition(SZB.Hatchery, 0, true),new Condition(SZA.Overlord, 4, false), new Condition(SZA.Drone, 3, true) }
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Mutalisk,
                chance = 0.04f,
                costTime = 10,
                conditions = { new Condition(SZB.Spire, 0, true)}
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Hydralisk,
                chance = 0.04f,
                costTime = 10,
                conditions = { new Condition(SZB.Hydralisk_Den, 0, true) }
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Infestor,
                chance = 0.02f,
                costTime = 12,
                conditions = { new Condition(SZB.Infestation_Pit, 0, true) }
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Swarm_Host,
                chance = 0.02f,
                costTime = 12,
                conditions = { new Condition(SZB.Infestation_Pit, 0, true) }
            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Ultralisk,
                chance = 0.02f,
                costTime = 16,
                conditions = { new Condition(SZB.Ultralisk_Cavern, 1, true) }

            };
            dict[SZA.Larva].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZA.Baneling,
                chance = 0.1f,
                costTime = 10,
                cocoonID = SZB.Cocoons_land_Actor,
                conditions = { new Condition(SZB.Baneling_Nest, 1, true) , new Condition(SZA.Baneling, 4, false) }

            };
            dict.Add(SZA.Zergling, new List<MutationAsset> { asset });

            asset = new MutationAsset
            {
                mutationUnit = SZB.Hatchery,
                chance = 0.075f,
                costTime = 60,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Hatchery,1,false), new Condition(SZB.Cocoons_Hatchery, 1, false), new Condition(SZB.Lair, 1, false), new Condition(SZB.Hive, 1, false) }

            };
            dict.Add(SZA.Drone, new List<MutationAsset> { asset });

            asset = new MutationAsset
            {
                mutationUnit = SZB.Spawning_Pool,
                chance = 0.02f,
                costTime = 10,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Hatchery, 0, true), new Condition(SZB.Spawning_Pool, 1, false), new Condition(SZA.Drone, 2, true)  }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Evolution_Chamber,
                chance = 0.01f,
                costTime = 25,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = {new Condition(SZB.Spawning_Pool, 0, true), new Condition(SZB.Evolution_Chamber, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Baneling_Nest,
                chance = 0.02f,
                costTime = 17,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = {new Condition(SZB.Spawning_Pool, 0, true), new Condition(SZB.Baneling_Nest, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Spore_Crawler,
                chance = 0.03f,
                costTime = 6,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Evolution_Chamber, 0, true), new Condition(SZB.Spore_Crawler, 2, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Spire,
                chance = 0.07f,
                costTime = 20,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Lair, 0, true), new Condition(SZB.Spire, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Infestation_Pit,
                chance = 0.03f,
                costTime = 17,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Lair, 0, true), new Condition(SZB.Infestation_Pit, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Ultralisk_Cavern,
                chance = 0.02f,
                costTime = 26,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Hive, 0, true), new Condition(SZB.Ultralisk_Cavern, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Hydralisk_Den,
                chance = 0.07f,
                costTime = 25,
                cocoonID = SZB.Cocoons_Building,
                building = true,
                conditions = { new Condition(SZB.Lair, 0, true), new Condition(SZB.Hydralisk_Den, 1, false), new Condition(SZA.Drone, 2, true) }

            };
            dict[SZA.Drone].Add(asset);

            asset = new MutationAsset
            {
                mutationUnit = SZB.Lair,
                chance = 0.1f,
                costTime = 80,
                cocoonID = SZB.Cocoons_Hatchery,
                building = true,
                conditions = { new Condition(SZB.Spawning_Pool, 0, true), new Condition(SZA.Drone, 2, true) }

            };
            dict.Add(SZB.Hatchery, new List<MutationAsset> { asset });

            asset = new MutationAsset
            {
                mutationUnit = SZB.Hive,
                chance = 0.1f,
                costTime = 120,
                cocoonID = SZB.Cocoons_Hatchery,
                building = true,
                conditions = { new Condition(SZB.Infestation_Pit, 0, true) }

            };
            dict.Add(SZB.Lair, new List<MutationAsset> { asset });
        }
    }
}
