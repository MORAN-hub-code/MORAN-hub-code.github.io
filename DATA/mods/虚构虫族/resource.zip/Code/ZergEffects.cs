﻿using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;
using System.Threading;
using System.Text;
using ai;
using ai.behaviours;

namespace Zerg
{
    class ZergEffects
    {
        public void init()
        {
            StatusAsset Ling = new StatusAsset();
            Ling.id = "灵能强化";
            Ling.texture = "Ling";
            Ling.path_icon = "ui/Icons/iconLingN";
            Ling.locale_description = "灵能觉醒者\n可以免疫神经寄生";
            Ling.animated = true;
            Ling.animation_speed = 0.1f;
            Ling.duration = 999999f;
            Ling.base_stats = new BaseStats();
            Ling.base_stats[S.armor] = 40f;
            Ling.base_stats[S.attack_speed] = 60f;
            Ling.base_stats[S.damage] = 50f;
            AssetManager.status.add(Ling);
            MoreAction.add_id_and_description(Ling.id, Ling.locale_description);



            StatusAsset Turning = new StatusAsset();
            Turning.id = "变异";
            Turning.duration = 3f;
            Turning.action = ZergEffects.Turning;
            Turning.action_interval = 0.1f;
            Turning.base_stats = new BaseStats();
            Turning.base_stats[S.speed] = -2147483648;
            Turning.path_icon = "ui/Icons/iconZerg";
            Turning.locale_description = "变异中";
            AssetManager.status.add(Turning);
            MoreAction.add_id_and_description(Turning.id, Turning.locale_description);

            StatusAsset Time = new StatusAsset();
            Time.id = "持续时间";
            Time.duration = 20f;
            Time.path_icon = "ui/Icons/iconZerg";
            Time.locale_description = "通用持续时间";
            AssetManager.status.add(Time);
            MoreAction.add_id_and_description(Time.id, Time.locale_description);

            StatusAsset Creep = new StatusAsset();
            Creep.id = "菌毯";
            Creep.duration = 5f;
            Creep.action = ZergEffects.Chong7jta;
            Creep.action_interval = 1f;
            Creep.allow_timer_reset = true;
            Creep.base_stats = new BaseStats();
            Creep.base_stats[S.speed] = +20f;
            Creep.base_stats[S.attack_speed] = +20f;
            Creep.path_icon = "ui/Icons/iconZerg";
            Creep.locale_description = "菌毯正在给予异虫源源不断的能量";
            AssetManager.status.add(Creep);
            MoreAction.add_id_and_description(Creep.id, Creep.locale_description);
        }

        public static bool Zishen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            pTarget.a.getHit(1,true,AttackType.Other);
            return true;
        }
        public static bool Turning(BaseSimObject pTarget, WorldTile pTile = null)
        {
            int i = 5;
            if (AssetManager.actor_library.get("Zerg_Overmind")?.units.Count > 0) i++;
            pTarget.a.data.health += i;
            pTarget.a.stats[S.health] += i; 
            pTarget.a.spawnParticle(Toolbox.color_heal);
            return true;
        }

        public static bool Chong7jta(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            a.restoreHealth(1);
            return true;
        }



    }
}