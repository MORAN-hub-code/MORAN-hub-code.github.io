﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

namespace Zerg
{
    class ZergAction
    {
        public static void init()
        {
            return;
        }

        /*/复活十字 已删除
		public static bool Resurrection(BaseSimObject pTarget, WorldTile pTile = null)
		{
			Actor a = pTarget.a;
			if (a.gameObject == null)
			{
				return false;
			}
			if (a == null)
			{
				return false;
			}
			if (!a.haveTrait("resurrection"))
			{
				return false;
			}
			if (!a.inMapBorder())
			{
				return false;
			}
			a.removeTrait("resurrection");
			a.addTrait("resurrectionBroken");
			Actor actor = MapBox.instance.createNewUnit(a.stats.id, a.current_tile, null, 0f, null);
			ActorTool.copyUnitToOtherUnit(a, actor);
			if (!MapBox.instance.qualityChanger.lowRes)
			{
				MapBox.instance.stackEffects.startSpawnEffect(actor.current_tile, "spawn");
			}
			MapBox.instance.destroyActor((Actor)pTarget);

			return true;
		}
		//破碎十字 已删除
		public static bool resurrectionBroken(BaseSimObject pTarget, WorldTile pTile = null)
		{
			Actor a = pTarget.a;
			if (a == null)
			{
				return false;
			}
			if (!a.haveTrait("resurrectionBroken"))
			{
				return false;
			}
			if (Randy.randomChance(0.007f))
			{
				a.removeTrait("resurrectionBroken");
				a.addTrait("resurrection");
			}
			return true;
		}

		//重生者 已删除
		public static bool rebirth(BaseSimObject pTarget, WorldTile pTile = null)
		{

			Actor a = pTarget.a;
			//int i = 0;
			if (a.gameObject == null)
			{
				return false;
			}
			if (a == null)
			{
				return false;
			}
			if (!a.haveTrait("rebirth"))
			{
				return false;
			}
			if (!a.inMapBorder())
			{
				return false;
			}
			Actor actor = MapBox.instance.createNewUnit(a.stats.id, a.current_tile, null, 0f, null);
			ActorTool.copyUnitToOtherUnit(a, actor);
			actor.data.level = 1;
			actor.data.age = Randy.randomInt(8, 12);
			string text1 = actor.getName();
			string text2 = "-Ⅰ";
			#region 名字判断
			if (text1.Contains("-Ⅰ"))
			{
				actor.data.setName(text1.Replace("-Ⅰ", "-Ⅱ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅱ "))
			{
				actor.data.setName(text1.Replace("-Ⅱ ", "-Ⅲ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅲ "))
			{
				actor.data.setName(text1.Replace("-Ⅲ ", "-Ⅳ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅳ "))
			{
				actor.data.setName(text1.Replace("-Ⅳ ", "-Ⅴ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅴ "))
			{
				actor.data.setName(text1.Replace("-Ⅴ ", "-Ⅵ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅵ "))
			{
				actor.data.setName(text1.Replace("-Ⅵ ", "-Ⅶ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅶ "))
			{
				actor.data.setName(text1.Replace("-Ⅶ ", "-Ⅷ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅷ "))
			{
				actor.data.setName(text1.Replace("-Ⅷ ", "-Ⅸ "));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅸ "))
			{
				actor.data.setName(text1.Replace("-Ⅸ ", "-Ⅹ"));
				actor.addTrait("rebirth");
			}
			else if (text1.Contains("-Ⅹ"))
			{
				actor.data.setName("%#$@#&!~(");
				actor.removeTrait("rebirth");
				actor.addTrait("death_bomb");
			}
			else
			{
				actor.data.setName(text1 + text2);
			}
			#endregion
			if (!MapBox.instance.qualityChanger.lowRes)
			{
				MapBox.instance.stackEffects.startSpawnEffect(actor.current_tile, "spawn");
			}
			MapBox.instance.destroyActor((Actor)pTarget);

			return true;
		}*/

        /*
        #region 虚构虫族
        //虫族 无限进化
        public static bool Chong1(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            if (pTarget != null)
            {
                var act = World.world.units.createNewUnit(a.asset.id, pTile);
                a.removeTrait("虫族基因（显性）");
                a.addTrait("虫族基因（隐性）");
                a.addTrait("基因进化 一阶");
                ActorTool.copyUnitToOtherUnit(a, act);
                act.kingdom = pTarget.kingdom;
            }
            return true;

        }
        //虫族 隐性基因
        //public static bool Chong0(BaseSimObject pTarget, WorldTile pTile = null)
        //{
        //    Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
        //    if (pTarget != null)
        //    {
        //        var act = MapBox.instance.createNewUnit(a.stats.id, pTile, null, 0f, null);
        //        ActorTool.copyUnitToOtherUnit(a, act);
        //        act.kingdom = pTarget.kingdom; ;
        //        act.city = pTarget.city;
        //    }
        //    return true;
        //}


        //虫族 母巢
        public static bool Chong2(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            var actorData = a.data;
            a.removeTrait("scar_of_divinity");
            a.addTrait("immortal");
            if (actorData.level < 5)
            {
                actorData.level += 4;
            }
            if (a.hasTrait("虫族基因（显性）") || a.hasTrait("虫族基因（隐性）"))
            {
                a.removeTrait("虫族基因（显性）");
                a.removeTrait("虫族基因（隐性）");
            }
            int i = Randy.randomInt(0, 10);
            if (i >= 9)
            {
                if (pTarget != null)
                {
                    var act = World.world.units.createNewUnit(a.asset.id, pTile);
                    string text1 = act.getName();
                    act.data.setName(text1 + "（虚构虫族 ）");
                    act.addTrait("虫族基因（隐性）");
                    act.kingdom = pTarget.kingdom;
                    act.city = pTarget.city;
                }
            }
            return true;
        }


        //虚构虫族基因共享 效果已完成 未实装
        public static bool Chong3(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (Randy.randomChance(0.5f))
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                var aData = a.data;
                MapBox.instance.getObjectsInChunks(pTile, 10, MapObjectType.Actor);
                for (int i = 0; i < MapBox.instance.temp_map_objects.Count; i++)
                {
                    Actor actor = (Actor)MapBox.instance.temp_map_objects[i];
                    var actorData = actor.data;
                    if (actorData.level < aData.level && (actor.hasTrait("虫族基因（显性）") || actor.hasTrait("虚构虫族母巢") || actor.hasTrait("虫族基因（隐性）")))
                    {
                        actor.restoreHealth(100);
                        actor.spawnParticle(Toolbox.color_heal);
                        actorData.level += 1;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion
        */
        #region 异虫
        //灵能强化
        public static bool LingN(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            if (a.data.health < a.getMaxHealth() / 10f)
            {
                a.addStatusEffect("灵能强化");
            }
            else
            {
                a.finishStatusEffect("灵能强化");
            }
            return true;
        }

        //异虫感染
        public static bool Chong4(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null) return false;
            if (pTarget.isActor())
            {
                Actor a = pTarget.a;
                if (!a.inMapBorder())
                {
                    return false;
                }
                a.removeTrait("异虫感染");
                Actor actor;
                if (a.asset.civ)
                {
                    actor = World.world.units.createNewUnit(SZA.Infested_Unit, pTile);
                }
                else
                {
                    actor = World.world.units.createNewUnit(SZA.Infested_Animal, pTile);
                }
                ActorTool.copyUnitToOtherUnit(a, actor);
                actor.data.setName(Toolbox.LowerCaseFirst(a.getName()) + "(异虫感染)");
                ActionLibrary.removeUnit(a);
            }
            return true;
        }

        //异虫（工蜂） 生成（自带菌毯肿瘤）
        public static bool Chong4j(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                if (!a.inMapBorder())
                {
                    return false;
                }
                a.removeTrait("异虫寄生");

                World.world.units.createNewUnit(SZA.Drone, pTile);
                //World.world.units.createNewUnit(SZA.Creep, pTile);
            }
            return true;
        }

        //异虫 感染
        public static bool Ganran(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.isActor() && Randy.randomChance(0.3f) && !PlayerConfig.dict["ZergActorInfectLimit"].boolVal && !pTarget.a.hasTrait("immune") && pTarget.a.asset.can_turn_into_zombie)
            {
                pTarget.a.addTrait("异虫感染");
            }
            else if (pTarget.isBuilding() && (pTarget.b.data.health <= 0 || pTarget.b.isRuin()) && !PlayerConfig.dict["ZergBuildingInfectLimit"].boolVal)
            {
                if (Randy.randomChance(0.1f)) World.world.buildings.addBuilding("InfTower_" + Randy.randomInt(0, 3), pTile);
                else if (Randy.randomChance(0.1f)) World.world.buildings.addBuilding("InfStatue", pTile);
                else if (Randy.randomChance(0.1f)) World.world.buildings.addBuilding("InfHall", pTile);
                else World.world.buildings.addBuilding("InfBuilding_" + Randy.randomInt(0, 6), pTile);
                ZergAction.Spread_Jun(pTarget, 8, 1f);
            }

            return true;
        }

        //同化
        public static bool Tonghua(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.isActor())
            {
                pTarget.kingdom = pSelf.kingdom;
            }

            return true;
        }
        //异虫 伤害
        public static bool Shanghai(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (Randy.randomChance(0.05f))
            {
                int val = pTarget.a.data.health / 10 + 1;
                int i = Math.Max(100, val);
                pTarget.a.getHit(i, true, AttackType.Plague);
            }
            return true;
        }


        public static bool MutationSystem(BaseSimObject pTarget, WorldTile pTile = null)
        {

            if (pTarget.a.isFighting() && Randy.randomChance(0.5f))
            {
                return false; 
                
            }
            else if(pTarget.a.asset.id == SZA.Drone && pTarget.a.subspecies.hasTrait("prefrontal_cortex") && pTarget.a.kingdom.asset.id == "Zerg")
            {
                return false;
            }
            else
            {
                Actor a = pTarget.a;
                if (!a.asset.flying && (a.current_tile.Type.liquid || a.current_tile.Type.block)) return false;
                if (!MutationLibrary.dict.ContainsKey(a.asset.id))
                {
                    MonoBehaviour.print("ZergError:不存在的变异" + a.asset.id);
                    return false;
                }
                foreach (MutationAsset mutation in MutationLibrary.dict[a.asset.id])
                {
                    //if (PowerButtons.GetToggleValue("ZergMutationLimit_" + mutation.mutationUnit)) continue;
                    if (mutation.building)
                    {
                        if (pTile != null)
                        {
                            bool isHatch = mutation.mutationUnit == SZB.Hatchery;
                            //if (isHatch && PowerButtons.GetToggleValue("DroneLimit")) continue;
                            if (!isHatch && pTile.top_type != null && pTile.top_type.id != JunBiome.jun_low.id && pTile.top_type.id != JunBiome.jun_high.id) continue;
                            int cnt = 0;
                            cnt += Finder.findSpeciesAroundTileChunk(pTile, SZB.Cocoons_Building).Count();
                            cnt += Finder.findSpeciesAroundTileChunk(pTile, SZB.Cocoons_Hatchery).Count();
                            if (cnt > 3) continue;
                        }
                    }
                    if (mutation.check(pTile, AssetManager.actor_library.get("Zerg_Overmind")?.units.Count > 0 ? 1.25f : 1f))
                    {
                        string str = mutation.building ? SZB.localized[mutation.mutationUnit] : SZA.localized[mutation.mutationUnit];
                        for (int i = 0; i < mutation.num; i++)
                        {
                            var act = World.world.units.createNewUnit(mutation.cocoonID, pTile);
                            float time = mutation.costTime;
                            if (AssetManager.actor_library.get("Zerg_Overmind")?.units.Count > 0) time *= 0.75f;
                            act.addStatusEffect("变异", time);
                            act.addTrait("变异为 " + str);
                            act.kingdom = a.kingdom;
                            if (a.city != null)
                            {
                                act.city = a.city;
                                act.city.units.Add(act);
                            }
                            if (a.isKing()) a.kingdom.setKing(act);
                        }
                        pTarget.a.die(true);
                    }
                }
            }
            return true;
        }

        public static bool MutationFinish(BaseSimObject pTarget, WorldTile pTile = null) //变异完成
        {
            Actor a = pTarget.a;
            if (!a.hasStatus("变异"))
            {
                foreach (ActorTrait t in a.traits)
                {
                    string trait = t.id;
                    if (trait.Contains("变异为 "))
                    {
                        string pID = trait.Remove(0, 4);
                        pID = SZManager.findKey(pID);
                        Actor  act = MoreAction.summonZergUnit(pTarget, pID, pTile);
                        //if(PowerButtons.GetToggleValue("Gene_Synchronization") && act.race == AssetManager.raceLibrary.get("Zerg_Fighter"))
                        //{
                        //    foreach (string gene in ZergGene.GenesLibrary)
                        //    {
                        //            act.addTrait(gene);
                        //    }
                        //}
                        if (a.isKing()) a.kingdom.setKing(act);

                    }
                }
                a.die();
            }
            return true;
        }

        public static bool Biomass(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }
            if (!pTarget.isActor())
            {
                return false;
            }
            if (!pSelf.isActor())
            {
                return false;
            }
            if (!pSelf.isAlive())
            {
                return false;
            }
            int tHealthToRestore = (int)(pSelf.a.stats[S.damage] * pSelf.a.GetBiomass() * 0.01f);
            pSelf.a.restoreHealth(tHealthToRestore);
            return true;
        }
        #region
        //毒爆 攻击自爆
        public static bool Chong7zb(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            pSelf.a.die();
            if (pTarget != null && pTarget.isActor())
            {
                pTarget.a.getHit(50, true, pAttackType: AttackType.Acid);
            }
            return true;
        }

        //毒爆 死亡自爆伤害
        public static bool Chong7db(BaseSimObject pTarget, WorldTile pTile = null)
        {

            foreach (var actor in Finder.getUnitsFromChunk(pTile, 1, 5))
            {
                if ((actor.hasTrait("异虫") || actor.hasTrait("异虫建筑")) && actor.kingdom == pTarget.kingdom)
                {
                    continue;
                }
                else
                {
                    actor.getHit(100, true, pAttackType: AttackType.None);
                    actor.getHit(150, false, pAttackType: AttackType.Acid);
                }
            }

            return true;
        }

        //感染虫
        public static bool Chong7gr_(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor act = pSelf.a;
            bool flag = true;
            if (!act.hasStatus("异化作战体冷却"))
            {
                MoreAction.throwAtTile("异化作战体", act, pTile.chunk.tiles.GetRandom());
                act.addStatusEffect("异化作战体冷却");
                //flag = false;
            }
            if (pTarget.isActor())
            {
                Actor a = pTarget.a;
                if (a.kingdom == act.kingdom)
                {
                    act.clearAttackTarget();
                    return true;
                }
                if (!act.hasStatus("霉菌滋生冷却") && flag)
                {
                    flag = false;
                    MoreAction.throwAtTile("霉菌滋生", act, pTarget.current_tile);
                    act.addStatusEffect("霉菌滋生冷却");
                }

                if (!act.hasStatus("神经寄生冷却") && !a.hasTrait("神经寄生") && !a.hasTrait("strong_minded") && !a.hasTrait("灵能强化"))
                {
                    if (a.asset.civ)
                    {
                        a.addStatusEffect("神经寄生", 30f);
                        a.kingdom?.units.Remove(a);
                        a.city?.units.Remove(a);
                    }
                    else if (a.asset.base_stats[S.health] >= 100)
                    {
                        a.addStatusEffect("神经寄生", 180f);
                    }
                    pTarget.kingdom = pSelf.kingdom;
                    if (act.city != null)
                    {
                        a.city = act.city;
                        act.city.units.Add(act);
                    }
                    a.clearAttackTarget();
                    a.addTrait("神经寄生");
                    act.addStatusEffect("神经寄生冷却", 40f);
                    act.clearAttackTarget();
                    flag = false;
                }
            }

            //if(pTarget.isBuilding())
            //{
            //    Building building = pTarget.b;
            //    if (flag)
            //    {
            //        flag = false;
            //        building.getHit(50);
            //        MoreAction.throwAtTile("霉菌滋生", act, pTarget.current_tile);
            //        act.addStatusEffect("霉菌滋生冷却",8f);
            //    }

            //}
            return true;
        }

        public static bool Status_Action(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (!pTarget.hasStatus("持续时间") && !pTarget.a.hasTrait("miracle_born"))
            {
                pTarget.a.die();
            }
            return true;
        }
        public static bool InTerran_Attack_Action(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            pSelf.a.die();
            return true;
        }

        public static bool InTerran_Death_Action(BaseSimObject pTarget, WorldTile pTile = null)
        {
            foreach (BaseSimObject baseSim in Finder.getAllObjectsInChunks(pTile, 4))
            {
                if (baseSim != null && baseSim.kingdom != null && baseSim.kingdom != pTarget.a.kingdom)
                {
                    baseSim.getHit(75, pAttackType: AttackType.Other);
                    baseSim.getHit(425, pAttackType: AttackType.Acid);
                    if (baseSim.isActor() && baseSim.a.data.health < 0 && baseSim.a.asset.can_turn_into_zombie && !baseSim.a.hasTrait("immune"))
                    {
                        Chong4(baseSim, pTile);
                    }
                }
            }
            return true;
        }
        //神经寄生结束
        public static bool Chong7gr_sjjs(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            if (!a.hasStatus("神经寄生"))
            {
                a.removeTrait("神经寄生");
                //if(a.race.nomad_kingdom_id != null && World.world.kingdoms.dict_hidden.ContainsKey(a.race.nomad_kingdom_id)) a.setKingdom(World.world.kingdoms.dict_hidden[a.race.nomad_kingdom_id]);
            }
            return true;
        }

        public static bool Swarm_Host_Action(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor act = pSelf.a;
            if (!act.hasStatus("孵化蝗虫冷却"))
            {
                act.addStatusEffect("孵化蝗虫冷却");
                for (int i = 0; i < 4; i++)
                {
                    MoreAction.throwAtTile("孵化蝗虫", act, pSelf.current_tile.neighboursAll.GetRandom().neighboursAll?.GetRandom());
                }
            }
            return true;
        }

        //虫后 治疗
        public static bool Chong7h(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (Randy.randomChance(0.2f))
            {
                Actor a = pTarget.a;

                foreach (var actor in Finder.getUnitsFromChunk(pTile, 0, 5))
                {
                    if (!a.hasStatus("哺育冷却") && actor.kingdom == a.kingdom && actor.data.health < actor.getMaxHealth())
                    {
                        a.addStatusEffect("哺育冷却");
                        actor.restoreHealth(80);
                        actor.spawnParticle(Toolbox.color_heal);
                    }
                    if (!PlayerConfig.dict["Hou_law"].boolVal && (actor.asset.id == SZB.Hatchery || actor.asset.id == SZB.Lair || actor.asset.id == SZB.Hive))
                    {
                        if (!a.hasStatus("注卵冷却") && !actor.hasStatus("注卵"))
                        {
                            a.addStatusEffect("注卵冷却");
                            actor.addStatusEffect("注卵");
                            actor.addTrait("注卵");
                        }
                    }
                }
            }
            return true;
        }

        //虫后 产出菌毯肿瘤
        public static bool Chong7hj(BaseSimObject pTarget, WorldTile pTile = null)
        {
            int j = Finder.findSpeciesAroundTileChunk(pTile, SZA.Creep).Count();
            int i = Randy.randomInt(0, 100);
            if (j < 3 && i < 7)
            {
                Actor act = World.world.units.createNewUnit(SZA.Creep, pTile);
                act.kingdom = pTarget.kingdom;
                if (pTarget.hasCity())
                { 
                    act.city = pTarget.a.city;
                    act.city.units.Add(act);
                } 
            }
            return true;
        }

        //菌毯肿瘤生物转菌毯肿瘤
        public static bool Chong7j(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (PlayerConfig.dict["ZergBiomeLimit"].boolVal) return false;
            if (pTile != null)
            {
                if (pTile.top_type != null && pTile.top_type.id != JunBiome.jun_low.id && pTile.top_type.id != JunBiome.jun_high.id && pTile.Type.can_be_biome)
                {
                    Actor act = World.world.units.createNewUnit(SZB.Creep_Tumor, pTile);
                    Spread_Jun(pTarget, 10, 1f);
                    act.kingdom = pTarget.kingdom;
                    if (pTarget.hasCity()) {
                        act.city = pTarget.a.city;
                        act.city.units.Add(act);
                    }
                }
            }
            return true;
        }

        //孢子爬虫扎根
        public static bool Chong7jtb(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTile != null)
            {
                if (pTile.top_type != null && (pTile.top_type.id == JunBiome.jun_high.id || pTile.top_type.id == JunBiome.jun_low.id))
                {
                    Actor a = pTarget.a;
                    a.removeTrait("孢子爬虫（移动）");
                    var act = World.world.units.createNewUnit(SZB.Spore_Crawler, pTile);
                    ActorTool.copyUnitToOtherUnit(a, act);
                    act.kingdom = a.kingdom;
                    if (pTarget.hasCity())
                    {
                        act.city = pTarget.a.city;
                        act.city.units.Add(act);
                    }
                    act.addTrait("孢子爬虫（扎根）");
                    a.die(true);
                }
            }
            return true;
        }

        public static Dictionary<string, float> LarvaChance = new Dictionary<string, float> { { SZB.Hatchery, 10f }, { SZB.Lair, 15f }, { SZB.Hive, 20f } };
        //孵化场 虫穴 主巢
        public static bool Chong6h(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Spread_Jun(pTarget, 24, 0.001f);
            if (Randy.randomChance(0.03f) && Finder.findSpeciesAroundTileChunk(pTile, SZA.Queen).Count() <= 1)
            {
                Actor act = MoreAction.summonZergUnit(pTarget, SZA.Queen, pTile);
                if(pTarget.kingdom.king?.asset.id == SZA.Drone)
                {
                    pTarget.kingdom.king = act;
                }
            }
            if (Finder.findSpeciesAroundTileChunk(pTile, SZA.Larva).Count() >= 6)
            {
                return false;
            }

            if (Randy.randomChance(LarvaChance[pTarget.a.asset.id]))
            {
                MoreAction.summonZergUnit(pTarget, SZA.Larva, pTile);
            }
            if (pTarget.a.asset.id == SZB.Hatchery || pTarget.a.asset.id == SZB.Lair) MutationSystem(pTarget, pTile);
            return true;
        }

        #endregion

        //异虫母巢 巢虫（暂时由跳虫代替）
        public static bool Chong6c(BaseSimObject pTarget, WorldTile pTile = null)
        {
            int i = 0;
            while (i < 4)
            {
                MoreAction.summonZergUnit(pTarget, SZA.Zergling, pTile);
                i++;
            }
            return true;
        }
        //利维坦 投掷空投囊
        public static bool Kongtou(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            if (!a.hasStatus("孵化异龙冷却"))
            {
                a.addStatusEffect("孵化异龙冷却");
                for (int i = 0; i < 3; i++)
                {
                    MoreAction.throwAtTile("孵化异龙", a, pTarget.current_tile.neighboursAll.GetRandom().neighboursAll?.GetRandom());
                }
            }
            if (!a.hasStatus("空投囊冷却"))
            {
                a.addStatusEffect("空投囊冷却");
                MapBox.instance.drop_manager.spawn(pTile, "MegaKongDrop", 15f);
            }
            return true;
        }

        //超级利维坦 投掷空投囊
        public static bool Kongtou2(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            a.restoreHealth(500);
            if (!a.hasStatus("孵化异龙冷却"))
            {
                a.addStatusEffect("孵化异龙冷却");
                for (int i = 0; i < 5; i++)
                {
                    MoreAction.throwAtTile("孵化异龙", a, pTarget.current_tile.neighboursAll.GetRandom().neighboursAll?.GetRandom());
                }
            }

            if (!a.hasStatus("空投囊冷却"))
            {
                a.addStatusEffect("空投囊冷却", 2.5f);
                MapBox.instance.drop_manager.spawn(pTile, "MegaKongDrop", 15f);
            }
            return true;
        }
        public static int study_Metabolic_Boost_int = 0;//代谢加速研究进度 >=6000为完成
        public static bool study_Metabolic_Boost = false;//是否为自主研究
        public static bool Metabolic_Boost = false;//是否有代谢加速基因序列
        public static bool Chong9mb_sd(BaseSimObject pTarget, WorldTile pTile = null)//mb -> Metabolic_Boost 代谢加速 sd -> study
        {
            if (study_Metabolic_Boost == false && Metabolic_Boost == false && study_Metabolic_Boost_int < 6000)
            {
                study_Metabolic_Boost_int += 1;
                if (study_Metabolic_Boost_int % 1000 == 0)
                {
                    MonoBehaviour.print("蜕变:跳虫,代谢加速:(" + study_Metabolic_Boost_int + "/6000)");
                }
            }
            else if (study_Metabolic_Boost == false)
            {
                study_Metabolic_Boost = true;
                Metabolic_Boost = true;
                MonoBehaviour.print("蜕变:跳虫,代谢加速,完成");
            }
            return true;
        }

        public static bool Chong7t_mb(BaseSimObject pTarget, WorldTile pTile = null)//跳虫 基因同步 代谢加速(专属科技)
        {
            Actor a = pTarget.a;
            if (Metabolic_Boost)
            {
                a.addTrait("代谢加速");
            }
            return true;
        }

        public static int study_Evolve_Melee_Attacks_Level_int = 0;//进化近战攻击等级研究进度 1级6400 2级7600 3级8800
        public static int study_Evolve_Melee_Attacks_Level = 0;//自主研究与等级 0为未研究 1为1级 2为2级 3为3级
        public static int Evolve_Melee_Attacks_Level = 0;//进化近战攻击等级 0为未研究 1为1级 2为2级 3为3级
        public static bool can_study_Ev2 = false;//是否可研究2攻，拥有虫穴后自动解锁
        public static bool can_study_Ev3 = false;//是否可研究3攻，拥有主巢后自动解锁

        //进化腔 科技研究
        public static bool Chong9ev_sd(BaseSimObject pTarget, WorldTile pTile = null)//ev -> Evolve_Melee_Attacks_Level 进化近战攻击等级  sd -> study
        {
            int s = study_Evolve_Melee_Attacks_Level;
            int i = study_Evolve_Melee_Attacks_Level_int;
            if (s == 0 || (s == 1 && can_study_Ev2) || (s == 2 && can_study_Ev3))
            {
                i += 1;
                study_Evolve_Melee_Attacks_Level_int += 1;
                if ((i == 6400 && s == 0) || (i == 7600 && s == 1) || (i == 8800 && s == 2))
                {
                    study_Evolve_Melee_Attacks_Level++;
                    s++;
                    Evolve_Melee_Attacks_Level = study_Evolve_Melee_Attacks_Level;
                    study_Evolve_Melee_Attacks_Level_int = 0;
                    MonoBehaviour.print("蜕变:异虫进化近战攻击等级" + s + "级,完成");
                }
                if (i % 1000 == 0)
                {
                    if (s == 0)
                    {
                        MonoBehaviour.print("蜕变:异虫进化近战攻击等级 1级:(" + i + "/6400)");
                    }
                    else if (s == 1)
                    {
                        MonoBehaviour.print("蜕变:异虫进化近战攻击等级 2级:(" + i + "/7600)");
                    }
                    else
                    {
                        MonoBehaviour.print("蜕变:异虫进化近战攻击等级 3级:(" + i + "/8800)");
                    }
                }
            }
            return true;
        }

        public static bool Chong7ev(BaseSimObject pTarget, WorldTile pTile = null)//异虫近战单位基因同步 (通用科技)
        {
            Actor a = pTarget.a;
            if (Evolve_Melee_Attacks_Level == 0)
            {
                return false;
            }
            else if (Evolve_Melee_Attacks_Level == 1)
            {
                a.addTrait("异虫近战攻击等级1");
                a.removeTrait("异虫近战攻击等级2");
                a.removeTrait("异虫近战攻击等级3");
            }
            else if (Evolve_Melee_Attacks_Level == 2)
            {
                a.addTrait("异虫近战攻击等级2");
                a.removeTrait("异虫近战攻击等级1");
                a.removeTrait("异虫近战攻击等级3");
            }
            else if (Evolve_Melee_Attacks_Level == 3)
            {
                a.addTrait("异虫近战攻击等级3");
                a.removeTrait("异虫近战攻击等级1");
                a.removeTrait("异虫近战攻击等级2");
            }
            return true;
        }

        public static int Chuansongjishu = 0;//主宰的传送计数
        public static int ChuanSong = 0;//传送门的数量
        public static int ChuanSongcooldown = 30;//开传送门的冷却
        public static int Linumber = 0;//利维坦的数量
        public static bool Chong10(BaseSimObject pTarget, WorldTile pTile = null)//chong10为主宰系列
        {
            if (ChuanSongcooldown > 0)
            {
                ChuanSongcooldown -= 1;
            }
            else
            {
                ChuanSongcooldown = 0;
            }
            if (Randy.randomChance(0.5f))
            {
                int j = Finder.findSpeciesAroundTileChunk(pTile, SZA.Larva).Count();
                if (j < 12)
                {
                    Actor act = World.world.units.createNewUnit(SZA.Larva, pTile);
                    act.kingdom = pTarget.kingdom;
                }
            }
            if (Randy.randomChance(0.25f))
            {
                if (Finder.findSpeciesAroundTileChunk(pTile, SZA.Creep).Count() < 3)
                {
                    Actor act = World.world.units.createNewUnit(SZA.Queen, pTile);
                    act.kingdom = pTarget.kingdom;
                }
            }
            Evolve_Melee_Attacks_Level = 3;
            Metabolic_Boost = true;
            if (World.world_era.id != "ZergEra" && PlayerConfig.dict["ZergEra_law"].boolVal)
            {
                World.world.era_manager.setCurrentAge(ZergEra.Zerg_Era);
            }
            return true;
        }
        public static bool Chong10run(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pSelf.a;
            float i = a.stats[S.health] / 4;
            Chuansongjishu++;
            if ((a.data.health < i && Chuansongjishu >= 10) || pTile.Type.liquid || pTile.Type.block)
            {
                ActionLibrary.teleportRandom(pTarget, pSelf);
                Chuansongjishu -= 10;
            }
            else if (a.data.health > i && Chuansongjishu > 2 && pTarget != null && pTarget.isActor())
            {
                WorldTile worldTile = null;
                while (worldTile == null)
                {
                    worldTile = World.world.islands_calculator.getRandomIslandGround()?.regions.GetRandom()?.tiles.GetRandom();
                }


                BaseEffect baseEffect = EffectsLibrary.spawnAt("fx_teleport_blue", worldTile.posV3, pTarget.a.stats[S.scale]);
                if (baseEffect != null)
                {
                    baseEffect.sprite_animation.setFrameIndex(9);
                }

                pTarget.a.cancelAllBeh();
                pTarget.a.spawnOn(worldTile);
                Chuansongjishu -= 2;
            }
            return true;
        }

        public static bool Chong10cskq(BaseSimObject pTarget, WorldTile pTile = null)//传送门由维持变为开启
        {
            Actor a = pTarget.a;
            Actor act = World.world.units.createNewUnit("ChuanSong1", pTile);
            act.kingdom = a.kingdom;
            a.die(true);
            return true;
        }

        public static bool Chong10cs(BaseSimObject pTarget, WorldTile pTile = null)//主宰开传送门
        {
            if (!pTarget.a.hasStatus("传送门冷却"))
            {
                pTarget.a.addStatusEffect("传送门冷却");
                TileIsland randomIslandGround = World.world.islands_calculator.getRandomIslandGround(true);
                if (randomIslandGround == null)
                {
                    return false;
                }
                WorldTile randomTile = MapBox.instance.tiles_list.GetRandom();
                Actor act = World.world.units.createNewUnit("ChuanSong", randomTile);
                act.kingdom = pTarget.a.kingdom;
            }
            return true;
        }

        public static bool Chong10cs_zh(BaseSimObject pTarget, WorldTile pTile = null)//传送门召唤虫族
        {
            Actor a = pTarget.a;
            if (a.data.health <= 50)//每秒损血
            {
                Actor actor = World.world.units.createNewUnit(SZA.Leviathan, pTile);
                actor.addTrait("传送门召唤物");
                actor.kingdom = a.kingdom;
                a.die(false);
            }
            else
            {
                a.data.health -= 50;
            }
            int health = a.data.health;
            int i = (int)(a.stats[S.health] / 100 - health / 100);
            while (i > 0)
            {
                if (i == 1)
                {
                    Actor act = World.world.units.createNewUnit(SZA.Drone, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.1f) && i != 1)
                {
                    Actor act = World.world.units.createNewUnit(SZA.Drone, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.2f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Zergling, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.3f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Baneling, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.01f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Queen, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.1f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Overlord, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.2f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Mutalisk, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.06f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Infestor, pTile);
                    act.kingdom = a.kingdom;
                }
                if (Randy.randomChance(0.1f))
                {
                    Actor act = World.world.units.createNewUnit(SZA.Swarm_Host, pTile);
                    act.kingdom = a.kingdom;
                }
                i--;
            }
            return true;
        }

        //public static bool Chong8_Overlord(BaseSimObject pTarget, WorldTile pTile = null)
        //{
        //    if (race.units.Count == 0)
        //    {
        //        float chance = 1 / (float)race2.units.Count;
        //        if (Randy.randomChance(chance))
        //        {
        //                pTarget.a.addTrait("虫族指挥官");
        //        }
        //    }
        //    return true;
        //}
        //public static bool Chong8_Overlord_death(BaseSimObject pTarget, WorldTile pTile = null)
        //{
        //    var act =  Finder.findSpeciesAroundTileChunk(pTile, pTarget.a.asset.id);
        //    if(act.Count() > 0)
        //    {
        //        foreach(var a in act)
        //        {
        //            if (!a.hasTrait("虫族指挥官"))
        //            {
        //                a.addTrait("虫族指挥官");
        //            }
        //        }
        //    }
        //    return true;
        //}

        //菌毯
        public static bool Tumor_Spread_Jun(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTile != null)
            {
                if (pTile.top_type == null || (pTile.Type.can_be_biome && pTile.top_type.id != JunBiome.jun_high.id && pTile.top_type.id != JunBiome.jun_low.id))
                {
                    Spread_Jun(pTarget, 10, 1f);
                }
            }
            return true;
        }
        public static void Spread_Jun(BaseSimObject pTarget, float R, float chance)
        {
            if (pTarget == null || !pTarget.current_tile.Type.can_be_biome) return;
            WorldTile tile = pTarget.current_tile;
            TopTileType toptile;
            if (tile.top_type == null || (tile.top_type.id != JunBiome.jun_high.id && tile.top_type.id != JunBiome.jun_low.id) || Randy.randomChance(chance))
            {
                Queue<WorldTile> q = new Queue<WorldTile>();
                Dictionary<WorldTile, bool> dict = new Dictionary<WorldTile, bool>();
                q.Enqueue(tile);
                dict.Add(tile, true);
                while (q.Count > 0)
                {
                    WorldTile worldTile = q.Peek();
                    q.Dequeue();
                    if (!worldTile.Type.can_be_biome) continue;
                    toptile = worldTile.main_type.rank_type == TileRank.Low ? JunBiome.jun_low : JunBiome.jun_high;
                    MapAction.growGreens(worldTile, toptile);
                    if(pTarget.kingdom.isCiv()&&pTarget.getCity() != null&&!worldTile.hasCity())
                    {
                        pTarget.getCity().addZone(worldTile.zone);
                    }
                    int tx = Mathf.Abs(worldTile.x - tile.x);
                    int ty = Mathf.Abs(worldTile.y - tile.y);
                    if (Mathf.Sqrt(tx * tx + ty * ty) > R) continue;
                    foreach (WorldTile t in worldTile.neighbours)
                    {
                        if (dict.ContainsKey(t)) continue;
                        else
                        {
                            dict.Add(t, true);
                            q.Enqueue(t);
                        }
                    }
                }
            }
            return;
        }

        #endregion

        #region 虚构虫族 分裂
        /*
        public static string[] JY = new string[] { "占位", "基因进化 一阶", "基因进化 二阶", "基因进化 三阶", "基因进化 四阶", "基因进化 五阶", "基因进化 六阶", "基因进化 七阶", "基因进化 八阶", "基因进化 九阶" };

        public static bool JY0(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            if (pTarget != null)
            {
                var act = World.world.units.createNewUnit(a.asset.id, pTile);
                int i = 0;
                if (a.hasTrait("基因进化 一阶"))
                {
                    i = 1;
                }
                else if (a.hasTrait("基因进化 二阶"))
                {
                    i = 2;
                }
                else if (a.hasTrait("基因进化 三阶"))
                {
                    i = 3;
                }
                else if (a.hasTrait("基因进化 四阶"))
                {
                    i = 4;
                }
                else if (a.hasTrait("基因进化 五阶"))
                {
                    i = 5;
                }
                else if (a.hasTrait("基因进化 六阶"))
                {
                    i = 6;
                }
                else if (a.hasTrait("基因进化 七阶"))
                {
                    i = 7;
                }
                else if (a.hasTrait("基因进化 八阶"))
                {
                    i = 8;
                }
                string trait_id_remove = JY[i];
                i++;
                string trait_id_add = JY[i];
                a.removeTrait(trait_id_remove);
                a.addTrait(trait_id_add);
                ActorTool.copyUnitToOtherUnit(a, act);
                act.kingdom = pTarget.kingdom;
                act.data.health += i * i * 200;
                act.asset.job = a.asset.job;
            }
            return true;
        }
        */
        #endregion
        /*
        public static bool huohua(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                a.addTrait("death_mark");
                if (a.hasTrait("基因进化 七阶"))
                {
                    a.removeTrait("death_mark");
                    a.removeTrait("细胞活化");
                    a.removeTrait("虫族基因（显性）");
                    a.removeTrait("基因活化");
                }
                
            }
            return true;
        }

        public static bool JYhuohua(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                if (a.hasTrait("虫族基因（隐性）"))
                {
                    a.removeTrait("虫族基因（隐性）");
                    a.removeTrait("基因活化");
                    a.addTrait("虫族基因（显性）");
                }
                else
                {
                    a.addTrait("death_mark");
                }

            }
            return true;
        }
        public static bool Miesha(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                a.removeTrait("虫族基因（显性）");
                a.removeTrait("虫族基因（隐性）");
                a.removeTrait("虚构虫族母巢");
                a.removeTrait("基因活化");
                a.removeTrait("细胞活化");
                a.removeTrait("基因进化 一阶");
                a.removeTrait("基因进化 二阶");
                a.removeTrait("基因进化 三阶");
                a.removeTrait("基因进化 四阶");
                a.removeTrait("基因进化 五阶");
                a.removeTrait("基因进化 六阶");
                a.removeTrait("基因进化 七阶");
                a.removeTrait("纳米灾疫");
                a.removeTrait("义体");
                a.die(true);
            }
            return true;
        }
        public static bool Tianxing(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                a.removeTrait("虫族基因（显性）");
                a.removeTrait("虫族基因（隐性）");
                a.removeTrait("虚构虫族母巢");
                a.removeTrait("基因活化");
                a.removeTrait("细胞活化");
                a.removeTrait("基因进化 一阶");
                a.removeTrait("基因进化 二阶");
                a.removeTrait("基因进化 三阶");
                a.removeTrait("基因进化 四阶");
                a.removeTrait("基因进化 五阶");
                a.removeTrait("基因进化 六阶");
                a.removeTrait("基因进化 七阶");
                a.removeTrait("纳米灾疫");
                a.removeTrait("义体");
                EffectsLibrary.spawn("fx_meteorite", pTarget.current_tile, "meteorite_disaster");
            }
            return true;
        }
        public static bool Tianshi(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
                int i = Randy.randomInt(0, 10000);
                if(i <= 1)
                {
                    a.addTrait("madness");
                }
                else
                {

                }
            }
            return true;
        }

        //纳米灾疫
        public static bool Zaiyi(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                ActorData actorData = Reflection.GetField(a.GetType(), a, "data") as ActorData;
                if (actorData.level < 2)
                {
                    actorData.level += 1;
                }
                int i = Randy.randomInt(0, 100);
                if (a.hasTrait("虫族基因（显性）") || a.hasTrait("虚构虫族母巢") || a.hasTrait("虫族基因（隐性）") || a.hasTrait("基因进化 一阶") || a.hasTrait("基因进化 二阶") || a.hasTrait("基因进化 三阶") || a.hasTrait("基因进化 四阶") || a.hasTrait("基因进化 五阶") || a.hasTrait("基因进化 六阶") || a.hasTrait("基因进化 七阶"))
                {
                    a.removeTrait("纳米灾疫");
                    int j = 0;
                    while(j < 10)
                    {
                        if (Randy.randomChance(0.1f))
                        {
                            int val = pTarget.a.data.health / 10;
                            pTarget.a.getHit(val);
                            j++;
                        }
                        else
                        {
                            j++;
                        }
                    }
                    return true;
                }
                else if (i <= 1)
                {
                    a.removeTrait("基因活化");
                    a.removeTrait("细胞活化");
                    a.removeTrait("纳米灾疫");
                    a.removeTrait("scar_of_divinity");
                    a.addTrait("acid_proof");
                    a.addTrait("fire_proof");
                    a.addTrait("freeze_proof");
                    a.addTrait("poison_immune");
                    a.addTrait("immune");
                    a.addTrait("immortal");
                    a.addTrait("义体");
                }
                else
                {

                }
            }
            return true;
        }

        public static bool sanji(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.level <= 1)
            {
                pTarget.a.data.level += 2;
            }
            return true;
        }

        //义体传播
        public static bool Yiti(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            pTarget.a.spawnParticle(Toolbox.color_infected);
            if (pTarget.isActor() && Randy.randomChance(1f))
            {
                pTarget.a.addTrait("纳米灾疫");
            }

            return true;
        }

        //反射actionlibrary
        [HarmonyPrefix]
        [HarmonyPatch(typeof(ActionLibrary), "turnIntoSkeleton")]
        public static bool turnIntoSkeleton(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            if (a.hasTrait("纳米灾疫") || a.hasTrait("义体") || a.hasTrait("虚构虫族母巢") || a.hasTrait("虫族基因（显性）") || a.hasTrait("虫族基因（隐性）"))
            {
                return false;
            }
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(ActionLibrary), "spawnGhost")]
        public static bool spawnGhost(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            if (a.hasTrait("纳米灾疫") || a.hasTrait("义体") || a.hasTrait("虚构虫族母巢") || a.hasTrait("虫族基因（显性）") || a.hasTrait("虫族基因（隐性）") || a.hasTrait("异虫"))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        */
        //菌毯效果
        public static bool giveZergTrait(WorldTile pTile, Actor pActor)
        {
            if (pActor.hasTrait("异虫") || pActor.hasTrait("异虫建筑"))
            {
                pActor.addStatusEffect("菌毯", 3f,false);
            }
            return true;
        }

        //虫族事件
        public static void spawnZerg(DisasterAsset pAsset)
        {
            for (int a = 0; a < 5; a++)
            {
                WorldTile randomTile = MapBox.instance.tiles_list.GetRandom();
                for (int i = 0; i < 4; i++)
                {
                    World.world.units.createNewUnit(SZA.Drone, randomTile);
                    for (int j = 0; j < 2; j++)
                    {
                        World.world.units.createNewUnit(SZA.Zergling, randomTile);
                    }
                }
                for (int w = 0; w < 2; w++)
                {
                    World.world.units.createNewUnit(SZA.Overlord, randomTile);
                }
                World.world.units.createNewUnit(SZA.Queen, randomTile);
            }
        }

    }
}

