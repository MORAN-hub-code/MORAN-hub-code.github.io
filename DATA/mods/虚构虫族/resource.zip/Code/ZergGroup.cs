﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReflectionUtility;

namespace Zerg
{
    class ZergGroup
    {
        public static string zergs = "zergs";
        public static string xugou = "xugou";
        public static void init()
        {
            ActorTraitGroupAsset zergs = new ActorTraitGroupAsset();
            zergs.id = "zergs";
            zergs.name = "trait_group_zergs";
            zergs.color = "#AD00B9";
            AssetManager.trait_groups.add(zergs);
            //addTraitGroupToLocalizedLibrary("cz", zergs.id, "虫族");

            ActorTraitGroupAsset xugou = new ActorTraitGroupAsset();
            xugou.id = "xugou";
            xugou.name = "trait_group_xugou";
            xugou.color = "#AD00B9";
            AssetManager.trait_groups.add(xugou);
            //addTraitGroupToLocalizedLibrary("cz", xugou.id, "虚构虫族   谨慎使用！");
        }
    }
}