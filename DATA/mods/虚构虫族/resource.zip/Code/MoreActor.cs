﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReflectionUtility;
using System.Collections;
using System.Text.RegularExpressions;
using System.Reflection;
using HarmonyLib;
using NCMS.Utils;
using UnityEngine;
using System.Diagnostics;

namespace Zerg
{
    class MoreActor
    {
        public static List<string> Zerg_Fighter = new List<string>();
        public static List<string> Zerg_Fighter_INF = new List<string>();
        public static void init()
        {
            CivilizedUnits();
        }
        static void CivilizedUnits()
        {
            ActorAsset _Zerg_unit = AssetManager.actor_library.clone("_Zerg_unit", "$mob$");
            _Zerg_unit.trait_group_filter_subspecies = new List<string> { "advanced_brain", "phenotypes" };
            _Zerg_unit.name_template_sets = new string[]{"default_set"};
            _Zerg_unit.has_advanced_textures = false;
            _Zerg_unit.has_baby_form = false;
            _Zerg_unit.name_taxonomic_kingdom = "animalia";
            _Zerg_unit.name_taxonomic_phylum = "neoplasia";
            _Zerg_unit.name_taxonomic_class = "malignomorpha";
            _Zerg_unit.name_taxonomic_order = "oncovorales";
            _Zerg_unit.name_taxonomic_family = "tumoridae";
            _Zerg_unit.name_taxonomic_genus = "neoplasmus";
            _Zerg_unit.name_taxonomic_species = "carcinomus";
            _Zerg_unit.collective_term = "group_cancer";
            _Zerg_unit.disable_jump_animation = true;
            _Zerg_unit.icon = "iconZerg";
            _Zerg_unit.unit_other = true;
            _Zerg_unit.name_locale = "_Zerg_Unit";
            _Zerg_unit.immune_to_tumor = true;
            _Zerg_unit.can_turn_into_tumor = false;
            _Zerg_unit.can_turn_into_zombie = false;
            _Zerg_unit.can_turn_into_ice_one = false;
            _Zerg_unit.use_phenotypes = false;
            _Zerg_unit.kingdom_id_wild = "Zerg";
            _Zerg_unit.color = Toolbox.makeColor("#AD00B9");
            _Zerg_unit.color_hex = "#AD00B9";
            _Zerg_unit.kingdom_id_civilization = "miniciv_insect";
            _Zerg_unit.traits = new List<string> { "异虫", "poison_immune", "immune" };
            _Zerg_unit.music_theme = "Buildings_Tumor";
            _Zerg_unit.sound_hit = "event:/SFX/HIT/HitFlesh";
            _Zerg_unit.body_separate_part_hands = false;
            _Zerg_unit.shadow = false;
            _Zerg_unit.base_stats[S.health] = 1f;
            _Zerg_unit.base_stats[S.speed] = 1f;
            _Zerg_unit.base_stats[S.attack_speed] = 1f;
            _Zerg_unit.base_stats[S.damage] = 1f;
            _Zerg_unit.texture_id= "t_tumor_monster_unit";
            _Zerg_unit.use_items = false;
            _Zerg_unit.take_items = false;
            _Zerg_unit.inspect_children = false;
            _Zerg_unit.inspect_sex = false;
            _Zerg_unit.inspect_generation = false;
            _Zerg_unit.check_flip = AssetManager.actor_library.get("tumor_monster_unit").check_flip;   
            _Zerg_unit.animation_walk = ActorAnimationSequences.walk_0_1;
            _Zerg_unit.animation_idle = ActorAnimationSequences.walk_0_1;
            _Zerg_unit.animation_swim = ActorAnimationSequences.walk_0_1;
            _Zerg_unit.default_subspecies_traits = new List<string> { "NoSleep" , "adaptation_Jun" };
            _Zerg_unit.chromosomes_first = AssetLibrary<ActorAsset>.l<string>(new string[]
        {
            "chromosome_big",
            "chromosome_medium"
        });

            ActorAsset _Zerg_building = AssetManager.actor_library.clone("_Zerg_building", "_Zerg_unit");
            _Zerg_building.damaged_by_ocean = true;
            _Zerg_building.can_level_up = false;
            _Zerg_building.job = new string[] { "building" };
            _Zerg_building.skip_fight_logic = true;
            _Zerg_building.default_attack = "Unable_to_attack";
            _Zerg_building.base_stats[S.scale] = 0.2f;
            _Zerg_building.traits = new List<string> { "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            _Zerg_building.animation_walk = new string[] { "walk_0" };
            _Zerg_building.animation_idle = new string[] { "walk_0" };
            _Zerg_building.animation_swim = new string[] { "walk_0" };
            _Zerg_building.base_stats.addTag("immovable");
            _Zerg_building.can_flip = false;


            //工蜂
            ActorAsset ChongAsset = AssetManager.actor_library.clone(SZA.Drone, "_Zerg_unit");
            ChongAsset.trait_group_filter_subspecies = new List<string> { "phenotypes" };
            ChongAsset.base_stats[S.lifespan] = 500;
            ChongAsset.setBaseStats(250, 15, 20, 20);//生命，攻击，移速，防御
            ChongAsset.traits = new List<string> { "工蜂","异虫","peaceful", "poison_immune", "immune" };
            ChongAsset.default_subspecies_traits.Add("adaptation_Jun");
            setaAnimation(ChongAsset, 2, 3, 3, 1f,0.8f,0.8f);
            addSprite(ChongAsset, "t_Chong");

            ActorAsset Smarter_Zerg = AssetManager.actor_library.clone("smart_drone", SZA.Drone);
            Smarter_Zerg.default_subspecies_traits.Add("Hivemind");
            Smarter_Zerg.kingdom_id_civilization = "miniciv_insect";
            setaAnimation(Smarter_Zerg, 2, 3, 3, 1f, 0.8f, 0.8f);
            addSprite(Smarter_Zerg, "t_Chong");

            //幼虫
            ActorAsset YouAsset = AssetManager.actor_library.clone(SZA.Larva, "_Zerg_unit");
            YouAsset.base_stats[S.lifespan] = 500;
            YouAsset.setBaseStats(50, 0, 0, 70);
            YouAsset.traits = new List<string> { "幼虫", "异虫", "poison_immune", "immune" };
            YouAsset.skip_fight_logic = true;
            YouAsset.animation_walk = new string[] { "idle_0"};
            YouAsset.animation_walk = ActorAnimationSequences.walk_0_1;
            YouAsset.animation_swim = ActorAnimationSequences.swim_0_1;
            setaAnimation(YouAsset, 2, 3, 3, 1f, 1f, 1f);
            addSprite(YouAsset, "t_You");

            //跳虫
            ActorAsset TiaoAsset = AssetManager.actor_library.clone(SZA.Zergling, "_Zerg_unit");
            //TiaoAsset.race = "Zerg_Fighter";
            TiaoAsset.base_stats[S.lifespan] = 500;
            TiaoAsset.setBaseStats(105, 25, 55, 10);
            TiaoAsset.traits = new List<string> { "跳虫", "异虫", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Zergling);
            setaAnimation(TiaoAsset, 1, 2, 4,1f,1f,1f);
            addSprite(TiaoAsset, "t_Tiao");

            //雷兽
            ActorAsset LeiAsset = AssetManager.actor_library.clone(SZA.Ultralisk, "_Zerg_unit");
            LeiAsset.base_stats[S.lifespan] = 1500;
            LeiAsset.setBaseStats(1500, 50, 25, 20);
            LeiAsset.base_stats["targets"] = 10;
            LeiAsset.base_stats[S.attack_speed] = 1;
            LeiAsset.base_stats[S.range] = 4;
            LeiAsset.traits = new List<string> { "雷兽", "异虫", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Ultralisk);
            setaAnimation(LeiAsset, 2, 4, 4, 1f, 1f, 1f);
            addSprite(LeiAsset, "t_Ultralisk");

            //毒爆
            ActorAsset DuBaoAsset = AssetManager.actor_library.clone(SZA.Baneling, "_Zerg_unit");
            //DuBaoAsset.race = "Zerg_Fighter";
            DuBaoAsset.base_stats[S.lifespan] = 500;
            DuBaoAsset.setBaseStats(100, 500, 50, 25);
            DuBaoAsset.traits = new List<string> { "爆虫", "异虫", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Baneling);
            setaAnimation(DuBaoAsset, 1, 2, 5);
            addSprite(DuBaoAsset, "t_DuBao");


            //刺蛇
            ActorAsset CiSheAsset = AssetManager.actor_library.clone(SZA.Hydralisk, "_Zerg_unit");
            CiSheAsset.base_stats[S.lifespan] = 500;
            CiSheAsset.setBaseStats(220, 20, 45, 20);
            CiSheAsset.base_stats[S.attack_speed] = 2;
            CiSheAsset.default_attack = "Jizhen";
            CiSheAsset.base_stats[S.range] = 2f;
            CiSheAsset.base_stats["accuracy"] = 100f;
            CiSheAsset.traits = new List<string> {"刺蛇", "异虫", "backstep", "eagle_eyed", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Hydralisk);
            setaAnimation(CiSheAsset, 2, 2, 6);
            addSprite(CiSheAsset, "t_Hydralisk");

            //感染虫
            ActorAsset GanranAsset = AssetManager.actor_library.clone(SZA.Infestor, "_Zerg_unit");
            //GanranAsset.race = "Zerg_Fighter";
            GanranAsset.base_stats[S.lifespan] = 5000;
            GanranAsset.setBaseStats(270, 0, 50, 10);
            GanranAsset.base_stats[S.knockback] = 0;
            GanranAsset.base_stats[S.attack_speed] = 1;
            GanranAsset.base_stats[S.range] = 8;
            GanranAsset.traits = new List<string> { "感染者", "异虫", "backstep", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Infestor);
            setaAnimation(GanranAsset, 1, 2, 2);
            addSprite(GanranAsset, "t_Ran");

            //虫群宿主
            ActorAsset SuZhuAsset = AssetManager.actor_library.clone(SZA.Swarm_Host, "_Zerg_unit");
            SuZhuAsset.base_stats[S.lifespan] = 5000;
            SuZhuAsset.setBaseStats(480, 0, 50, 20);
            SuZhuAsset.base_stats[S.knockback] = 0;
            SuZhuAsset.base_stats[S.attack_speed] = 1;
            SuZhuAsset.base_stats[S.range] = 16;
            SuZhuAsset.traits = new List<string> { "虫群宿主", "异虫", "backstep", "poison_immune", "immune" };
            SuZhuAsset.animation_idle = new string[] { "idle_0"};
            SuZhuAsset.animation_walk = ActorAnimationSequences.walk_0_3;
            SuZhuAsset.animation_swim = new string[] { "swim_0","swim_1"};
            Zerg_Fighter.Add(SZA.Swarm_Host);
            addSprite(SuZhuAsset, "t_Swarm_Host");
            setaAnimation(SuZhuAsset, 1, 2, 2,2f,0.8f,1f);

            //蝗虫
            ActorAsset HuangAsset = AssetManager.actor_library.clone(SZA.Locust, "_Zerg_unit");
            HuangAsset.base_stats[S.lifespan] = 50;
            HuangAsset.setBaseStats(50, 30, 40, 30);
            HuangAsset.base_stats[S.attack_speed] = 2;
            HuangAsset.base_stats[S.range] = 2;
            HuangAsset.base_stats["accuracy"] = 10f;
            HuangAsset.default_attack = "Xianti";
            HuangAsset.flying = true;
            HuangAsset.die_on_blocks = false;
            HuangAsset.traits = new List<string> { "蝗虫", "异虫", "poison_immune", "immune" };
            Zerg_Fighter.Add(SZA.Locust);
            addSprite(HuangAsset, "t_Locust");
            HuangAsset.animation_idle = new string[] { "walk_0", "walk_1" };
            HuangAsset.animation_walk = new string[] { "walk_0", "walk_1" };
            HuangAsset.animation_swim = new string[] { "walk_0", "walk_1" };

            //暴虐虫
            ActorAsset BaochongAsset = AssetManager.actor_library.clone(SZA.Bile_Swarm, "_Zerg_unit");
            //BaochongAsset.race = "Zerg_Fighter";
            BaochongAsset.base_stats[S.lifespan] = 50;
            BaochongAsset.setBaseStats(50, 30, 75, 30);
            BaochongAsset.base_stats[S.attack_speed] = 1;
            BaochongAsset.base_stats[S.range] = 2;
            BaochongAsset.flying = true;
            BaochongAsset.die_on_blocks = false;
            BaochongAsset.traits = new List<string> { "暴虐虫", "异虫", "poison_immune", "immune" };
            BaochongAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2"};
            BaochongAsset.animation_walk = new string[] { "walk_0","walk_1","walk_2"};
            Zerg_Fighter.Add(SZA.Bile_Swarm);
            addSprite(BaochongAsset, "t_Baochong");

            //异化作战体
            ActorAsset InHuman = AssetManager.actor_library.clone(SZA.Infected_Humans, "_Zerg_unit");
            //InHuman.race = "Zerg_Fighter";
            InHuman.base_stats[S.lifespan] = 50;
            InHuman.setBaseStats(200, 7, 60, 30);
            InHuman.base_stats[S.attack_speed] = 60;
            InHuman.traits = new List<string> { "异化作战体", "异虫", "异虫病毒", "poison_immune", "immune" };
            InHuman.animation_idle = new string[] { "walk_0" };
            InHuman.animation_walk = new string[] { "walk_0", "walk_1", "walk_2" };
            InHuman.animation_swim = new string[] { "walk_0", "walk_1", "walk_2" };
            InHuman.default_attack = "IfC_14";
            Zerg_Fighter.Add(SZA.Infected_Humans);
            addSprite(InHuman, "t_InfectedHumans");

            ActorAsset InTerran = AssetManager.actor_library.clone(SZA.Infested_Terran, SZA.Infected_Humans);
            InTerran.setBaseStats(100, 0, 40, 30);
            InTerran.base_stats[S.attack_speed] = 1;
            //InTerran.race = "Zerg_Fighter_INF";
            InTerran.traits = new List<string> { "自爆人", "异虫", "异虫病毒", "poison_immune", "immune" };
            InTerran.animation_idle = new string[] { "walk_0","walk_1"};
            InTerran.default_attack = "base_attack";
            addSprite(InTerran, "t_InTerran");
            Zerg_Fighter_INF.Add(SZA.Infested_Terran);
            

            ActorAsset InUnit = AssetManager.actor_library.clone(SZA.Infested_Unit, SZA.Infected_Humans);
            InUnit.setBaseStats(100, 10, 30, 10);
            InUnit.base_stats[S.attack_speed] = 2;
            addSprite(InUnit, "t_InUnit");
            //InUnit.race = "Zerg_Fighter_INF";
            InUnit.traits = new List<string> { "被感染的生物", "异虫","异虫病毒", "poison_immune", "immune" };
            InUnit.animation_idle = new string[] { "walk_0"};
            InUnit.animation_walk = new string[] { "walk_0","walk_1","walk_2"};
            InUnit.use_items = true;
            InUnit.default_attack = "base_attack";
            Zerg_Fighter_INF.Add(SZA.Infested_Unit);

            ActorAsset actor = AssetManager.actor_library.get("tumor_monster_animal");

            ActorAsset InAnimal = AssetManager.actor_library.clone(SZA.Infested_Animal, SZA.Infested_Unit);
            InAnimal.setBaseStats(80, 10, 25, 10);
            InAnimal.base_stats[S.attack_speed] = 2;
            InAnimal.texture_asset = actor.texture_asset;
            InAnimal.texture_asset.texture_path_main = actor.texture_asset.texture_path_main;
            //InAnimal.race = "Zerg_Fighter_INF";
            InAnimal.traits = new List<string> { "被感染的生物", "异虫", "异虫病毒", "poison_immune", "immune" };
            InAnimal.animation_idle = actor.animation_idle;
            InAnimal.animation_walk = actor.animation_walk;
            InAnimal.animation_swim = actor.animation_swim;
            InAnimal.use_items = false;

            //王虫
            ActorAsset WangAsset = AssetManager.actor_library.clone(SZA.Overlord, "_Zerg_unit");
            //WangAsset.race = "Zerg_Overlord";
            WangAsset.base_stats[S.lifespan] = 1000;
            addSprite(WangAsset, "t_Wang");
            WangAsset.setBaseStats(500, 0, 20, 20);//生命，攻击，移速，防御
            WangAsset.traits = new List<string> { "王虫","虫族指挥官","异虫", "fire_proof", "poison_immune", "immune" };
            WangAsset.flying = true;
            WangAsset.very_high_flyer = true;
            WangAsset.die_on_blocks = false;
            WangAsset.skip_fight_logic = true;
            WangAsset.base_stats[S.range] = 20;
            WangAsset.job = new string[] { "commander" };
            WangAsset.default_attack = "Unable_to_attack";
            WangAsset.can_attack_buildings = false;
            WangAsset.animation_idle_speed = 2f;
            WangAsset.animation_walk_speed = 2f;
            WangAsset.animation_swim_speed = 2f;
            WangAsset.animation_idle = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };
            WangAsset.animation_walk = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };
            WangAsset.animation_swim = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };

            //虫后
            ActorAsset HouAsset = AssetManager.actor_library.clone(SZA.Queen, "_Zerg_unit");
            //HouAsset.name_template_sets = new string[] { "Hou_name" };
            HouAsset.base_stats[S.lifespan] = 1000;
            addSprite(HouAsset, "t_Hou");
            HouAsset.setBaseStats(750, 20, 10, 20);//生命，攻击，移速，防御
            HouAsset.traits = new List<string> { "虫后", "异虫", "eagle_eyed", "poison_immune", "immune" };
            HouAsset.default_attack = "Jizhen";
            HouAsset.base_stats[S.attack_speed] = 2f;
            HouAsset.base_stats[S.range] = 1f;
            setaAnimation(HouAsset, 2, 2, 2, 1f, 0.8f, 0.8f);

            //异龙
            ActorAsset YiDragonAsset = AssetManager.actor_library.clone(SZA.Mutalisk, "_Zerg_unit");
            //YiDragonAsset.race = "Zerg_Fighter";
            YiDragonAsset.base_stats[S.lifespan] = 1000;
            addSprite(YiDragonAsset, "t_YiDragon");
            YiDragonAsset.setBaseStats(120, 15, 55, 10);//生命，攻击，移速，防御
            YiDragonAsset.traits = new List<string> { "异龙", "异虫", "fire_proof", "poison_immune", "immune" };
            YiDragonAsset.default_attack = "RenChong";
            YiDragonAsset.flying = true;
            YiDragonAsset.very_high_flyer = true;
            YiDragonAsset.die_on_blocks = false;
            YiDragonAsset.base_stats[S.attack_speed] = 2f;
            YiDragonAsset.base_stats[S.range] = 3.6f;
            YiDragonAsset.default_height = 2;
            YiDragonAsset.animation_idle_speed = 5f;
            YiDragonAsset.animation_walk_speed = 5f;
            YiDragonAsset.animation_swim_speed = 5f;
            YiDragonAsset.animation_idle = new string[] { "walk_0", "walk_1", "walk_2", "walk_3", "walk_4", "walk_5" };
            YiDragonAsset.animation_walk = new string[] { "walk_0", "walk_1", "walk_2", "walk_3", "walk_4", "walk_5" };
            YiDragonAsset.animation_swim = new string[] { "walk_0", "walk_1", "walk_2", "walk_3", "walk_4", "walk_5" };
            Zerg_Fighter.Add(SZA.Mutalisk);

            //精英异龙
            ActorAsset ExYiDragonAsset = AssetManager.actor_library.clone(SZA.Ex_Mutalisk, SZA.Mutalisk);
            addSprite(ExYiDragonAsset, "Ex/t_YiDragon");
            ExYiDragonAsset.setBaseStats(280, 50, 50, 30);//生命，攻击，移速，防御
            ExYiDragonAsset.base_stats[S.attack_speed] = 3f;
            ExYiDragonAsset.base_stats[S.scale] = 0.12f;
            ExYiDragonAsset.traits = new List<string> { "精英异龙", "异虫", "fire_proof", "poison_immune", "immune" };
            ExYiDragonAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2"};
            Zerg_Fighter.Add(SZA.Ex_Mutalisk);

            //利维坦
            ActorAsset LiAsset = AssetManager.actor_library.clone(SZA.Leviathan, "_Zerg_unit");
            //LiAsset.name_template_sets = new string[] { "Li_name" };
            //LiAsset.race = "Zerg_Fighter";
            LiAsset.base_stats[S.lifespan] = 5000;
            addSprite(LiAsset, "t_Li");
            LiAsset.setBaseStats(10000, 200, 10, 80);//生命，攻击，移速，防御
            LiAsset.traits = new List<string> { "利维坦", "异虫", "诅咒免疫", "fire_proof", "poison_immune", "freeze_proof", "immune" };
            LiAsset.default_attack = "Kongtou";
            LiAsset.visible_on_minimap = true;
            LiAsset.flying = true;
            LiAsset.very_high_flyer = true;
            LiAsset.ignore_blocks = true;
            LiAsset.die_on_blocks = false;
            LiAsset.base_stats[S.scale] = 0.31f;
            LiAsset.base_stats[S.attack_speed] = 2f;
            LiAsset.base_stats[S.range] = 32f;
            LiAsset.job = new string[] { "Fighter" };
            LiAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_4"};
            Zerg_Fighter.Add(SZA.Leviathan);

            //凯瑞甘的利维坦
            ActorAsset SuperLiAsset = AssetManager.actor_library.clone(SZA.SuperLeviathan, SZA.Leviathan);
            //SuperLiAsset.name_template_sets = new string[] { "Li_name" };
            SuperLiAsset.base_stats[S.lifespan] = 100000;
            addSprite(SuperLiAsset, "t_SuperLi");
            SuperLiAsset.setBaseStats(100000, 900, 10, 99);//生命，攻击，移速，防御
            SuperLiAsset.traits = new List<string> { "凯瑞甘的利维坦", "虫族指挥官" ,"异虫", "诅咒免疫", "fire_proof", "poison_immune", "freeze_proof", "immune" };
            SuperLiAsset.default_attack = "Baochong";
            SuperLiAsset.job = new string[] { "commander" };
            SuperLiAsset.base_stats[S.scale] = 1.0f;
            SuperLiAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2"};

            //菌毯肿瘤生物
            ActorAsset JunAsset = AssetManager.actor_library.clone(SZA.Creep, "_Zerg_unit");
            //JunAsset.name_template_sets = new string[] { "Tan_name" };
            JunAsset.base_stats[S.lifespan] = 1000;
            JunAsset.default_attack = "Unable_to_attack";
            addSprite(JunAsset, "t_Jun");
            JunAsset.can_have_subspecies = false;
            JunAsset.skip_fight_logic = true;
            JunAsset.setBaseStats(5, 0, 40, 0);//生命，攻击，移速，防御
            JunAsset.traits = new List<string> { "菌毯肿瘤生物", "异虫", "诅咒免疫", "fire_proof", "poison_immune", "immune" };
            JunAsset.animation_idle = new string[] { "walk_0"};

            //孢子爬虫
            ActorAsset Bao2Asset = AssetManager.actor_library.clone(SZA.Spore_Crawler_Walk, "_Zerg_unit");
            //Bao2Asset.name_template_sets = new string[] { "Zhu_name" };
            Bao2Asset.base_stats[S.lifespan] = 1000;
            addSprite(Bao2Asset, "t_Baozi2");
            Bao2Asset.setBaseStats(300, 5, 60, 10);//生命，攻击，移速，防御
            Bao2Asset.traits = new List<string> { "孢子爬虫（移动）", "异虫建筑", "eagle_eyed", "fire_proof", "诅咒免疫", "poison_immune", "immune" };
            Bao2Asset.animation_idle = new string[] { "walk_0","walk_1"};


            //异虫 孵化场
            ActorAsset ChaoAsset = AssetManager.actor_library.clone(SZB.Hatchery, "_Zerg_building");
            //ChaoAsset.name_template_sets = new string[] { "Zhu_name" };
            ChaoAsset.base_stats[S.lifespan] = 100000;
            addSprite(ChaoAsset, "t_Chao");
            ChaoAsset.setBaseStats(3000, 0, 0, 20);
            ChaoAsset.traits = new List<string> { "异虫 孵化场", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ChaoAsset.animation_walk = new string[] { "walk_0" };
            ChaoAsset.animation_idle = new string[] { "walk_0" };

            //异虫 虫穴
            ActorAsset Chao2Asset = AssetManager.actor_library.clone(SZB.Lair, SZB.Hatchery);
            //Chao2Asset.name_template_sets = new string[] { "Zhu_name" };
            addSprite(Chao2Asset, "t_Chao2");
            Chao2Asset.setBaseStats(4000, 0, 0, 30);
            Chao2Asset.traits = new List<string> { "异虫虫穴", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            Chao2Asset.animation_walk = new string[] { "walk_0" };
            Chao2Asset.animation_idle = new string[] { "walk_0" };

            //异虫 虫穴
            ActorAsset Chao3Asset = AssetManager.actor_library.clone(SZB.Hive, SZB.Hatchery);
            //Chao3Asset.name_template_sets = new string[] { "Zhu_name" };
            //Chao3Asset.race = SZB.Hive;
            addSprite (Chao3Asset, "t_Chao3");
            Chao3Asset.setBaseStats(5000, 0, 0, 30);
            Chao3Asset.traits = new List<string> { "异虫主巢", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            Chao3Asset.animation_walk = new string[] { "walk_0" };
            Chao3Asset.animation_idle = new string[] { "walk_0" };

            //主宰
            ActorAsset ZhuAsset = AssetManager.actor_library.clone(SZB.Overmind, "_Zerg_building");
            //ZhuAsset.name_template_sets = new string[] { "ZhuZai_name" };
            ZhuAsset.base_stats[S.lifespan] = 1000000;
            //ZhuAsset.race = "Zerg_Overmind";
            ZhuAsset.visible_on_minimap = true;
            addSprite(ZhuAsset, "t_Zhu");
            ZhuAsset.setBaseStats(10000, 0, 0, 37);
            ZhuAsset.base_stats[S.scale] = 0.3f;
            ZhuAsset.job = new string[] { "overmind" };
            ZhuAsset.traits = new List<string> { "主宰","异虫指挥官" ,"异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ZhuAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_3","walk_2","walk_1","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0","walk_0"};

            //主宰传送门 开启
            ActorAsset ChuanSongAsset = AssetManager.actor_library.clone("ChuanSong", "_Zerg_building");
            //ChuanSongAsset.name_template_sets = new string[] { "Chuan_name" };
            addSprite(ChuanSongAsset, "t_Chuan");
            ChuanSongAsset.setBaseStats(5, 0, 0, 0);
            ChuanSongAsset.flying = true;
            ChuanSongAsset.base_stats[S.scale] = 0.36f;
            ChuanSongAsset.job = new string[] { "building" };
            ChuanSongAsset.traits = new List<string> { "主宰传送门 开启", "异虫", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ChuanSongAsset.animation_walk = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_4,walk_5,walk_6,walk_7","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8"};
            ChuanSongAsset.animation_idle = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_4,walk_5,walk_6,walk_7","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8","walk_9","walk_8"};

            //主宰传送门 维持
            ActorAsset ChuanSong1Asset = AssetManager.actor_library.clone("ChuanSong1", "_Zerg_building");
            //ChuanSong1Asset.name_template_sets = new string[] { "Chuan_name" };
            addSprite(ChuanSong1Asset, "t_Chuan1");
            ChuanSong1Asset.setBaseStats(1000, 0, 0, 0);
            ChuanSong1Asset.base_stats[S.scale] = 0.36f;
            ChuanSong1Asset.visible_on_minimap = true;
            ChuanSong1Asset.flying = true;
            ChuanSong1Asset.traits = new List<string> { "主宰传送门", "异虫", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ChuanSong1Asset.animation_walk = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_4,walk_5,walk_6,walk_7","walk_8","walk_9"};
            ChuanSong1Asset.animation_idle = new string[] { "walk_0","walk_1","walk_2","walk_3","walk_4,walk_5,walk_6,walk_7","walk_8","walk_9"};

            //异虫 分裂池
            ActorAsset FenAsset = AssetManager.actor_library.clone(SZB.Spawning_Pool, "_Zerg_building");
            //FenAsset.name_template_sets = new string[] { "Zhu_name" };
            FenAsset.base_stats[S.lifespan] = 100000;
            addSprite(FenAsset, "t_Fen");
            FenAsset.setBaseStats(500, 0, 0, 5);
            FenAsset.traits = new List<string> { "分裂池", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            FenAsset.animation_idle = new string[] { "walk_0"};

            //异虫 爆虫巢穴
            ActorAsset BaoChaoAsset = AssetManager.actor_library.clone(SZB.Baneling_Nest, "_Zerg_building");
            //BaoChaoAsset.name_template_sets = new string[] { "Zhu_name" };
            BaoChaoAsset.base_stats[S.lifespan] = 100000;
            addSprite(BaoChaoAsset, "t_BaoChao");
            BaoChaoAsset.setBaseStats(850, 0, 0, 5);
            BaoChaoAsset.traits = new List<string> { "爆虫巢穴", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            BaoChaoAsset.animation_idle = new string[] { "walk_0"};

            //异虫 雷兽窟
            ActorAsset LeiKuAsset = AssetManager.actor_library.clone(SZB.Ultralisk_Cavern, "_Zerg_building");
            LeiKuAsset.base_stats[S.lifespan] = 100000;
            addSprite(LeiKuAsset, "t_Ultralisk_Cavern");
            LeiKuAsset.setBaseStats(1000, 0, 0, 5);
            LeiKuAsset.traits = new List<string> { "雷兽窟", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            LeiKuAsset.animation_idle = new string[] { "walk_0"};

            //异虫 进化腔
            ActorAsset JinAsset = AssetManager.actor_library.clone(SZB.Evolution_Chamber, "_Zerg_building");
            //JinAsset.name_template_sets = new string[] { "Zhu_name" };
            JinAsset.base_stats[S.lifespan] = 100000;
            addSprite(JinAsset, "t_Jin");
            JinAsset.setBaseStats(750, 0, 0, 5);
            JinAsset.traits = new List<string> { "进化腔", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            JinAsset.animation_idle = new string[] { "walk_0"};

            //异虫 孢子爬虫
            ActorAsset BaoAsset = AssetManager.actor_library.clone(SZB.Spore_Crawler, "_Zerg_building");
            //BaoAsset.name_template_sets = new string[] { "Zhu_name" };
            BaoAsset.base_stats[S.lifespan] = 100000;
            addSprite(BaoAsset, "t_Baozi");
            BaoAsset.setBaseStats(300, 30, 0, 20);
            BaoAsset.base_stats[S.attack_speed] = 5f;
            BaoAsset.default_attack = "Spore";
            BaoAsset.base_stats[S.range] = 8f;
            BaoAsset.base_stats[S.projectiles] = 1;
            BaoAsset.skip_fight_logic = false;
            BaoAsset.traits = new List<string> { "孢子爬虫（扎根）", "异虫建筑", "诅咒免疫", "eagle_eyed", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            BaoAsset.animation_idle = new string[] { "walk_0"};

            //异虫 菌毯
            ActorAsset TanAsset = AssetManager.actor_library.clone(SZB.Creep_Tumor, "_Zerg_building");
            //TanAsset.name_template_sets = new string[] { "Tan_name" };
            TanAsset.base_stats[S.lifespan] = 100000;
            addSprite(TanAsset, "t_Tan");
            TanAsset.setBaseStats(100, 0, 0, 10);
            TanAsset.can_have_subspecies = false;
            TanAsset.traits = new List<string> { "菌毯肿瘤", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            TanAsset.animation_idle = new string[] { "walk_0"};

            //异虫 尖塔
            ActorAsset TaAsset = AssetManager.actor_library.clone(SZB.Spire, "_Zerg_building");
            //TaAsset.name_template_sets = new string[] { "Zhu_name" };
            TaAsset.base_stats[S.lifespan] = 100000;
            addSprite(TaAsset, "t_Ta");
            TaAsset.setBaseStats(850, 0, 0, 5);
            TaAsset.traits = new List<string> { "尖塔", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            TaAsset.animation_idle = new string[] { "walk_0"};

            //异虫 刺蛇巢
            ActorAsset HydraliskDenAsset = AssetManager.actor_library.clone(SZB.Hydralisk_Den, "_Zerg_building");
            HydraliskDenAsset.base_stats[S.lifespan] = 100000;
            addSprite(HydraliskDenAsset, "t_HydraliskDen");
            HydraliskDenAsset.setBaseStats(850, 0, 0, 5);
            HydraliskDenAsset.traits = new List<string> { "刺蛇巢", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            HydraliskDenAsset.animation_idle = new string[] { "walk_0" };

            //异虫 感染深渊
            ActorAsset ShenAsset = AssetManager.actor_library.clone(SZB.Infestation_Pit, "_Zerg_building");
            //ShenAsset.name_template_sets = new string[] { "Zhu_name" };
            ShenAsset.base_stats[S.lifespan] = 100000;
            addSprite(ShenAsset, "t_Shen");
            ShenAsset.setBaseStats(850, 0, 0, 5);
            ShenAsset.base_stats[S.scale] = 0.2f;
            ShenAsset.traits = new List<string> { "感染深渊", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ShenAsset.animation_idle = new string[] { "walk_0"};

            //异虫 虫茧 建筑
            ActorAsset JianAsset = AssetManager.actor_library.clone(SZB.Cocoons_Building, "_Zerg_building");
            //JianAsset.name_template_sets = new string[] { "Jian_name" };
            JianAsset.base_stats[S.lifespan] = 100000;
            addSprite(JianAsset, "New/t_Jian");
            JianAsset.setBaseStats(100, 0, 0, 10);
            JianAsset.can_have_subspecies = false;
            JianAsset.traits = new List<string> { "虫茧", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            JianAsset.animation_walk = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };
            JianAsset.animation_idle = new string[] { "walk_0", "walk_1", "walk_2", "walk_3" };

            //异虫 虫茧 陆地生物
            ActorAsset Jian1Asset = AssetManager.actor_library.clone(SZB.Cocoons_land_Actor, "_Zerg_building");
            //Jian1Asset.name_template_sets = new string[] { "Jian_name" };
            Jian1Asset.base_stats[S.lifespan] = 100000;
            Jian1Asset.base_stats[S.scale] = 0.1f;
            addSprite(Jian1Asset, "t_Jian1");
            Jian1Asset.setBaseStats(100, 0, 0, 10);
            Jian1Asset.can_have_subspecies = false;
            Jian1Asset.traits = new List<string> { "虫茧", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            Jian1Asset.animation_idle = new string[] { "idle_0","idle_1"};

            //异虫 虫茧 飞行生物
            ActorAsset Jian2Asset = AssetManager.actor_library.clone(SZB.Cocoons_fly_Actor, SZB.Cocoons_land_Actor);
            addSprite(Jian2Asset, "t_Jian2");
            Jian2Asset.setBaseStats(100, 0, 0, 10);
            Jian2Asset.flying = true;
            Jian2Asset.very_high_flyer = true;
            Jian2Asset.die_on_blocks = false;
            Jian2Asset.ignore_blocks = true;
            Jian2Asset.animation_idle = new string[] { "idle_0","idle_1"};

            //异虫 虫茧 孵化场升级
            ActorAsset ChaoJAsset = AssetManager.actor_library.clone(SZB.Cocoons_Hatchery, SZB.Cocoons_Building);
            addSprite(ChaoJAsset, "t_ChaoJ");
            ChaoJAsset.setBaseStats(100, 0, 0, 10);
            ChaoJAsset.traits = new List<string> { "虫茧", "异虫建筑", "诅咒免疫", "fire_proof", "freeze_proof", "poison_immune", "immune" };
            ChaoJAsset.animation_idle = new string[] { "walk_0","walk_1"};
            ChaoJAsset.animation_walk = new string[] { "walk_0", "walk_1" };

            foreach(var str in Buttons.Zerg_units_id )
            {
                ActorAsset asset = AssetManager.actor_library.get(str);
                asset.name_locale = asset.id;
                asset.power_id = "spawn"+asset.id;
            }
            foreach (var str in Buttons.Zerg_building_id)
            {
                ActorAsset asset = AssetManager.actor_library.get(str);
                asset.name_locale = asset.id;
                asset.power_id = "spawn" + asset.id;
            }


            createNameTemplate("Chong_name", "虫族", false, true);
            createNameTemplate("Zhu_name", "虫族建筑", false, true);
            createNameTemplate("Tan_name", "肿瘤", false, true);
            createNameTemplate("Jian_name", "虫茧", false, true);
            createNameTemplate("Hou_name", "虫后", false, false);
            createNameTemplate("ZhuZai_name", "主宰", true);
            createNameTemplate("Chuan_name", "主宰传送门", true);
            createNameTemplate("Li_name", "利维坦", true);
        }
        private static void createNameTemplate(string id,string part_group, bool fix_ed = true,bool count = false)
        {
            NameGeneratorAsset name = new NameGeneratorAsset();
            name.id = id;
            name.part_groups = new List<string>();
            name.templates = new List<string[]>();
            name.part_groups.Add(part_group);
            if(!fix_ed)//是否将名字固定
            {
                name.part_groups.Add("1,2,3,4,5,6,7,8,9");
                if(count)//是否使用更多数字来计数
                {
                    name.part_groups.Add(",,,,,,,,,,,,,,,,,,,,1,2,3,4,5,6,7,8,9");
                    name.part_groups.Add(",,,,,,,,,,,,,,,,,,,,1,2,3,4,5,6,7,8,9");
                    name.part_groups.Add(",,,,,,,,,,,,,,,,,,,,1,2,3,4,5,6,7,8,9");
                }
                name.part_groups.Add("号");
            }
            name.templates.Add(new string[] { "part_group" });
            AssetManager.name_generator.add(name);

        }

        private static void addSprite(ActorAsset pAsset,string tPath)
        {
            pAsset.texture_asset = new ActorTextureSubAsset("actors/"+tPath,false);
            pAsset.texture_asset.texture_path_main = "actors/" + tPath;
        }

        private static void setaAnimation(ActorAsset pAsset,int idle,int swim,int walk,float idle_speed = 1f,float swim_speed = 1f, float walk_speed = 1f)
        {
            int i;
            string[] idle_list = new string[idle];
            string[] walk_list = new string[walk];
            string[] swim_list = new string[swim];
            for (i = 0;i < idle;i++) 
            {
                idle_list[i] = $"idle_{i}";
            }
            for (i = 0; i < walk; i++)
            {
                walk_list[i] = $"walk_{i}";
            }
            for (i = 0; i < swim; i++)
            {
                swim_list[i] = $"swim_{i}";
            }
            pAsset.animation_idle = idle_list;
            pAsset.animation_walk = walk_list;
            pAsset.animation_swim = swim_list;
            pAsset.animation_idle_speed = idle_speed;
            pAsset.animation_swim_speed = swim_speed;
            pAsset.animation_walk_speed = walk_speed;
        }
    }


    
}