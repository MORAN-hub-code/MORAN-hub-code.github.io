﻿using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using ReflectionUtility;
using NeoModLoader.General.UI.Tab;
using System.Collections.Generic;

namespace Zerg
{
    class ZergTab
    {
        public static PowersTab tab;
        public static void init()
        {
            tab = TabManager.CreateTab("Zerg", "tab_Zerg", "tab for Zerg",
            SpriteTextureLoader.getSprite("ui/icons/iconZerg"));
            tab.SetLayout(new List<string>()
            {
            "creature_actor",
            "creature_building",
            "god_powers",
            "laws"
            });
        }




    }
}