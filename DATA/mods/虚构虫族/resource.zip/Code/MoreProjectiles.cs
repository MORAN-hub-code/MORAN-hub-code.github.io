﻿using System;
using UnityEngine;
using static UnityEngine.UI.CanvasScaler;

namespace Zerg
{
    class MoreProjectiles
    {
        public static void init()
        {
            ProjectileAsset Meijun = new ProjectileAsset();
            Meijun.id = "霉菌滋生";
            Meijun.animated = true;
            Meijun.texture_shadow = "shadows/projectiles/shadow_ball";
            Meijun.speed = 26;
            Meijun.texture = "iconMeijun";
            Meijun.draw_light_area = false;
            Meijun.impact_actions = MeiJun;
            AssetManager.projectiles.add(Meijun);

            ProjectileAsset kong = new ProjectileAsset();
            kong.id = "空投囊";
            kong.animated = true;
            kong.texture_shadow = "shadows/projectiles/shadow_ball";
            kong.speed = 22;
            kong.texture = "iconKT";
            kong.draw_light_area = false;
            kong.impact_actions = Kong;
            AssetManager.projectiles.add(kong);

            ProjectileAsset IHuman = new ProjectileAsset();
            IHuman.id = "异化作战体";
            IHuman.animated = true;
            IHuman.texture_shadow = "shadows/projectiles/shadow_ball";
            IHuman.speed = 12;
            IHuman.texture = "iconIH";
            IHuman.draw_light_area = false;
            IHuman.impact_actions = summonIH;
            AssetManager.projectiles.add(IHuman);

            ProjectileAsset Acid = AssetManager.projectiles.clone("Zerg_Acid", "arrow");
            Acid.texture = "iconHuang";
            Acid.speed = 30;
            AssetManager.projectiles.add(Acid);

            ProjectileAsset Locust = new ProjectileAsset();
            Locust.id = "孵化蝗虫";
            Locust.animated = true;
            Locust.texture_shadow = "shadows/projectiles/shadow_ball";
            Locust.speed = 2;
            Locust.texture = "iconHuang";
            Locust.draw_light_area = false;
            Locust.impact_actions = summonLocust;
            AssetManager.projectiles.add(Locust);

            ProjectileAsset BombZerg = new ProjectileAsset();
            BombZerg.id = "孵化暴虐虫";
            BombZerg.animated = true;
            BombZerg.texture_shadow = "shadows/projectiles/shadow_ball";
            BombZerg.look_at_target = true;
            BombZerg.speed = 30;
            BombZerg.texture = "iconBaochong";
            BombZerg.mass = 0f;
            BombZerg.draw_light_area = false;
            BombZerg.impact_actions = summonBaoZerg;
            AssetManager.projectiles.add(BombZerg);

            ProjectileAsset Ren = new ProjectileAsset();
            Ren.id = "刃虫";
            Ren.animated = true;
            Ren.texture_shadow = "shadows/projectiles/shadow_ball";
            Ren.look_at_target = true;
            Ren.speed = 36;
            Ren.texture = "iconRen";
            Ren.animation_speed = 60f;
            Ren.mass = 1f;
            Ren.draw_light_area = false;
            Ren.impact_actions = bounce;
            AssetManager.projectiles.add(Ren);

            ProjectileAsset Ren_1 = AssetManager.projectiles.clone("刃虫1","刃虫");
            Ren_1.impact_actions = bounce1;
            ProjectileAsset Ren_2 = AssetManager.projectiles.clone("刃虫2", "刃虫");
            Ren_2.impact_actions = null;

            ProjectileAsset IUnit = AssetManager.projectiles.clone("summonIU", "孵化蝗虫");
            IUnit.speed = 16;
            IUnit.texture = "iconMeijun";
            IUnit.impact_actions = summonIU;

            ProjectileAsset ExYi = AssetManager.projectiles.clone("孵化异龙", "孵化蝗虫");
            ExYi.speed = 16;
            ExYi.impact_actions = summonExYi;

            ProjectileAsset Jizhen = AssetManager.projectiles.clone("脊针", "arrow");
            Jizhen.speed = 60;
            Jizhen.mass = 1f;
            Jizhen.look_at_target = true;

            ProjectileAsset C_14_bullet = AssetManager.projectiles.clone("C_14_bullet", "shotgun_bullet");
            C_14_bullet.id = "C_14_bullet";
            C_14_bullet.speed = 60;
        }

        public static bool summonIH(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = World.world.units.createNewUnit(SZA.Infected_Humans, pTile);
            if (pSelf != null && pSelf.kingdom != null) a.kingdom = pSelf.kingdom;
            a.addStatusEffect("持续时间",14f);
            return true;
        }
        public static bool summonIU(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = World.world.units.createNewUnit(SZA.Infested_Unit, pTile);
            if (pSelf != null && pSelf.kingdom != null) a.kingdom = pSelf.kingdom;
            return true;
        }

        public static bool summonLocust(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = World.world.units.createNewUnit(SZA.Locust, pTile);
            if (pSelf != null && pSelf.kingdom != null) a.kingdom = pSelf.kingdom;
            a.addStatusEffect("持续时间",18f);
            return true;
        }
        public static bool summonBaoZerg(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = World.world.units.createNewUnit(SZA.Bile_Swarm, pTile);
            if (pSelf != null && pSelf.kingdom != null) a.kingdom = pSelf.kingdom;
            a.addStatusEffect("持续时间", 18f);
            return true;
        }

        public static bool bounce(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf != null && pSelf.kingdom != null&&pSelf.isAlive())
            {
                Actor unit = null;
                foreach (Actor unit2 in Finder.getUnitsFromChunk(pTile, 1, 9))
                {
                    if (unit2.kingdom != null && pSelf.kingdom.isEnemy(unit2.kingdom)
                    && unit2 != pSelf)
                    {
                        unit = unit2;
                        break;
                    }
                }
                if (unit != null)
                {
                    Vector2 pos = unit.current_position;
                    float pDist = Vector2.Distance(pTile.pos, pos);
                    Vector3 newPoint = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, pDist);
                    Vector3 newPoint2 = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, unit.stats["size"]);
                    newPoint2.y += 0.5f;
                    World.world.projectiles.spawn(pSelf, unit, "刃虫1", newPoint2, newPoint, pForcedKingdom: pSelf.kingdom);
                }
            }
            return true;
        }
        #region 刃虫复制两遍，很蠢但有效
        public static bool bounce1(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf != null && pSelf.kingdom != null && pSelf.isAlive())
            {
                Actor unit = null;
                foreach (Actor unit2 in Finder.getUnitsFromChunk(pTile, 1, 9))
                {
                    if (unit2.kingdom != null && pSelf.kingdom.isEnemy(unit2.kingdom)
                    && unit2 != pSelf)
                    {
                        unit = unit2;
                        break;
                    }
                }
                if (unit != null)
                {
                    Vector2 pos = unit.current_position;
                    float pDist = Vector2.Distance(pTile.pos, pos);
                    Vector3 newPoint = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, pDist);
                    Vector3 newPoint2 = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, unit.stats["size"]);
                    newPoint2.y += 0.5f;
                    World.world.projectiles.spawn(pSelf, unit, "刃虫2", newPoint2, newPoint, pForcedKingdom: pSelf.kingdom);
                }
            }
            return true;
        }

        public static bool bounce2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            //if (pSelf != null && pSelf.kingdom != null)
            //{
            //    Actor unit = null;
            //    foreach (Actor unit2 in Finder.getUnitsFromChunk(pTile, 1, 9))
            //    {
            //        if (unit2.kingdom != null && pSelf.kingdom.isEnemy(unit2.kingdom)
            //        && unit2 != pSelf)
            //        {
            //            unit = unit2;
            //            break;
            //        }
            //    }
            //    if (unit != null)
            //    {
            //        Vector2 pos = unit.current_position;
            //        float pDist = Vector2.Distance(pTile.pos, pos);
            //        Vector3 newPoint = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, pDist);
            //        Vector3 newPoint2 = Toolbox.getNewPoint(pTile.pos.x, pTile.pos.y, pos.x, pos.y, unit.stats["size"]);
            //        newPoint2.y += 0.5f;
            //        World.world.projectiles.spawn(pSelf, pSelf, "刃虫3", newPoint2, newPoint, pForcedKingdom: pSelf.kingdom);
            //    }
            //}
            return true;
        }
        #endregion


        public static bool summonExYi(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            string str = SZA.localized[SZA.Ex_Mutalisk];
            Actor act = World.world.units.createNewUnit(SZB.Cocoons_fly_Actor, pTile);
            if(pSelf != null && pSelf.kingdom!= null) act.kingdom = pSelf.kingdom;
            act.addStatusEffect("变异", 3f);
            act.addTrait("变异为 " + str);
           //act.kingdom = pSelf?.kingdom;
            //MoreAction.summonZergUnit(, , pTile, );
            return true;
        }
        
        public static bool Kong(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            for(int i = 0;i < 4;i++)
            {
                string str = SZA.Zergling;
                if (Randy.randomChance(0.2f)) str = SZA.Baneling;
                else if (Randy.randomChance(0.07f)) str = SZA.Swarm_Host;
                else if (Randy.randomChance(0.06f)) str = SZA.Infestor;
                Actor act = World.world.units.createNewUnit(str, pTile);
                act.kingdom = pSelf?.kingdom;
            }
            DropsLibrary.useDropSeedOn(pTile, JunBiome.jun_low, JunBiome.jun_high);
            for (int i = 0; i < pTile.neighbours.Length; i++)
            {
                DropsLibrary.useDropSeedOn(pTile.neighbours[i], JunBiome.jun_low, JunBiome.jun_high);
            }
            return true;
        }

        public static bool MeiJun(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            foreach(Actor act in Finder.getUnitsFromChunk(pTile, 1, 0))
            {
                if(act == null) continue;
                if(!act.hasTrait("异虫") && !act.hasTrait("异虫建筑")) 
                    act.addStatusEffect("霉菌滋生");
            }
            return true;
        }
    }


}