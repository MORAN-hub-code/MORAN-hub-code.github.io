﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zerg
{
    class ZergMapIcon
    {
        public static QuantumSpriteAsset ZergQuantum;
        public static void init()
        {
            QuantumSpriteAsset ZergQuantum = new QuantumSpriteAsset();
            ZergQuantum.id = "show_zones_Zerg";
            ZergQuantum.id_prefab = "p_mapZone";
            ZergQuantum.base_scale = 1f;
            ZergQuantum.draw_call = new QuantumSpriteUpdater(DrawZerg);
            ZergQuantum.debug_option = DebugOption.Greg;
            ZergQuantum.create_object = delegate (QuantumSpriteAsset pAsset, QuantumSprite pQSprite)
            {
                pQSprite.setColor(ref pAsset.color);
            };
            ZergQuantum.render_map = true;
            ZergQuantum.add_camera_zoom_multiplier = false;
            ZergQuantum.color = Toolbox.makeColor("#AD00B9", 0.2f);
            AssetManager.quantum_sprites.add(ZergQuantum);
        }

        public static void DrawZerg(QuantumSpriteAsset pAsset)
        {
            foreach (Actor unit in World.world.units)
            {
                if (unit.hasTrait("异虫") || unit.hasTrait("异虫建筑"))
                {
                    QuantumSpriteLibrary.drawQuantumSprite(pAsset, unit.current_tile.zone.centerTile.posV, null, null, null, null, 1f, false, -1f);
                }
            }
        }

    }
}
