﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Zerg
{
    class MutationAsset
    {
        public string mutationUnit = SZA.Drone;
        public int costTime = 10;
        public float chance = 0.05f;
        public string cocoonID = SZB.Cocoons_land_Actor;
        public int num = 1;
        public bool building = false;
        public List<Condition> conditions = new List<Condition>();

        public bool check(WorldTile pTile, float chanceEnhance = 1f)
        {
            if (chance * chanceEnhance < UnityEngine.Random.value) return false;
            bool flag = true;
            foreach (Condition c in conditions)
            {
                if (!c.check(pTile))
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }
    }
}
