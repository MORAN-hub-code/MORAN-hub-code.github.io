﻿using System;
using System.Collections.Generic;
using System.Linq;
using NCMS;
using UnityEngine;
using NCMS.Utils;

namespace Zerg
{
     class JunBiome
    {
        public static TopTileType jun_low;
        public static TopTileType jun_high;
        public static void init()
        {
            BiomeAsset Juntan = new BiomeAsset();
            Juntan.id = "Biome_juntan";
            Juntan.tile_high = "jun_high";
            Juntan.tile_low = "jun_low";
            Juntan.grow_strength = 3;
            Juntan.spread_biome = true;
            Juntan.grow_type_selector_minerals = new GrowTypeSelector(TileActionLibrary.getGrowTypeRandomMineral);
            Juntan.grow_type_selector_trees = new GrowTypeSelector(TileActionLibrary.getGrowTypeRandomTrees);
			Juntan.grow_type_selector_plants = new GrowTypeSelector(TileActionLibrary.getGrowTypeRandomPlants);
            AssetManager.biome_library.add(Juntan);

            jun_high = AssetManager.top_tiles.add(new TopTileType
            {
                cost = 120,
                drawPixel = true,
                id = "jun_high",
                color = new Color32(61, 57, 56, 245),
                height_min = 98,
                grass = true,
                can_be_biome = true,
                strength = 3,
                life = true,
                can_be_set_on_fire = true,
                burnable = true,
                additional_height = new int[]
                {
                15,
                16,
                17,
                14,
                13,
                12,
                11,
                10
                },
                ground = true,
                can_be_farm = false,
                fire_chance = 0.023f,
                remove_on_heat = true,
                can_be_frozen = false,
                step_action = ZergAction.giveZergTrait,
                step_action_chance = 100f,
                only_allowed_to_build_with_tag = "can_build_in_biome_Jun",
                can_build_on = true
            });
            jun_high.setBiome("Juntan");
            jun_high.rank_type = TileRank.High;
            jun_high.can_be_removed_with_spade = true;
            jun_high.creep_rank_type = TileRank.High;
            jun_high.setDrawLayer(TileZIndexes.tumor_high, null);
            jun_high.biome_asset = Juntan;
            AssetManager.top_tiles.loadSpritesForTile(jun_high);

            jun_low = AssetManager.top_tiles.add(new TopTileType
            {
                cost = 120,
                drawPixel = true,
                id = "jun_low",
                color = new Color32(61, 57, 56, 245),
                height_min = 98,
                grass = true,
                can_be_biome = true,
                strength = 3,
                life = true,
                can_be_set_on_fire = true,
                burnable = true,
                additional_height = new int[]
                {
                15,
                16,
                17,
                14,
                13,
                12,
                11,
                10
                },
                ground = true,
                can_be_farm = false,
                fire_chance = 0.023f,
                remove_on_heat = true,
                can_be_frozen = false,
                step_action = ZergAction.giveZergTrait,
                step_action_chance = 100f,
                only_allowed_to_build_with_tag = "can_build_in_biome_Jun",
                can_build_on = true
            }) ;
            jun_low.setBiome("Juntan");
            jun_low.biome_asset = Juntan;
            jun_low.rank_type = TileRank.Low;
            jun_low.setDrawLayer(TileZIndexes.tumor_low, null);
            AssetManager.top_tiles.loadSpritesForTile(jun_low);

        }
    }
}