﻿using UnityEngine;

namespace Zerg
{
    public static class ActorExtensions
    {
        private const string Biomass_key = "Zerg.Biomass";



        public static float GetBiomass(this Actor actor)
        {
            actor.data.get(Biomass_key, out float val, 1);
            return val;
        }
        public static void SetBiomass(this Actor actor, float val)
        {
            actor.data.set(Biomass_key, val);
        }
        public static void AddBiomass(this Actor actor, float delta)
        {
            actor.data.get(Biomass_key, out float val, 0);
            val += delta;
            actor.data.set(Biomass_key, Mathf.Max(0, val));
        }
    }
}
