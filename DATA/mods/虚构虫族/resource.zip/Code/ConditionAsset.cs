﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;

namespace Zerg
{
    public class Condition
    {
        public Condition(string _id,int _num,bool _max) 
        {
            id = _id;
            num = _num;
            max = _max;
        }

        public string id;
        public int num;
        public bool max;//max=true为>num,max=flase为<num
        public bool check(WorldTile pTile) 
        {
            int cnt = Finder.findSpeciesAroundTileChunk(pTile,id).Count();
            return max ? cnt > num : cnt < num;
        }
    }
}
