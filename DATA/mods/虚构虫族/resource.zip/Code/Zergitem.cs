﻿using ReflectionUtility;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine;
using NCMS;

namespace Zerg
{
    class Zergitem
    {
        public static void init()
        {
            EquipmentAsset Meijun = AssetManager.items.clone("Meijun", "$range");
            Meijun.id = "Meijun";
            Meijun.projectile = "霉菌滋生";
            Meijun.material = "base";
            Meijun.path_icon = "ui/Icons/iconchong";
            Meijun.attack_type = WeaponType.Range;
            Meijun.base_stats[S.targets] = 1;
            Meijun.base_stats[S.range] = 10;
            Meijun.base_stats[S.projectiles] = 1;

            EquipmentAsset Kongtou = AssetManager.items.clone("Kongtou", "Meijun");
            Kongtou.id = "Kongtou";
            Kongtou.attack_type = WeaponType.Range;
            Kongtou.path_icon = "ui/Icons/iconchong";
            Kongtou.projectile = "空投囊";

            EquipmentAsset Baochong = AssetManager.items.clone("Baochong", "Meijun");
            Baochong.id = "Baochong";
            Baochong.attack_type = WeaponType.Range;
            Baochong.projectile = "孵化暴虐虫";
            Baochong.path_icon = "ui/Icons/iconchong";
            Baochong.base_stats[S.projectiles] = 4;

            EquipmentAsset Spore = AssetManager.items.clone("Spore", "Meijun");
            Spore.id = "Spore";
            Spore.attack_type = WeaponType.Range;
            Spore.projectile = "Zerg_Acid";
            Spore.path_icon = "ui/Icons/iconchong";
            EquipmentAsset Jizhen = AssetManager.items.clone("Jizhen", "$range");
            Jizhen.id = "Jizhen";
            Jizhen.projectile = "脊针";
            Jizhen.material = "base";
            Jizhen.attack_type = WeaponType.Range;
            Jizhen.path_icon = "ui/Icons/iconchong";
            Jizhen.base_stats[S.projectiles] = 1;
            Jizhen.base_stats[S.range] = 24;

            EquipmentAsset Xianti = AssetManager.items.clone("Xianti", "$range");
            Xianti.id = "Xianti";
            Xianti.projectile = "脊针";
            Xianti.attack_type = WeaponType.Range;
            Xianti.path_icon = "ui/Icons/iconchong";
            Xianti.material = "base";
            Xianti.base_stats[S.projectiles] = 1;
            Xianti.base_stats[S.range] = 1;

            EquipmentAsset Ren = AssetManager.items.clone("RenChong", "$range");
            Ren.projectile = "刃虫";
            Ren.attack_type = WeaponType.Range;
            Ren.path_icon = "ui/Icons/iconchong";
            Ren.base_stats[S.projectiles] = 1;
            Ren.material = "base";

            EquipmentAsset Unable_to_attack = AssetManager.items.clone("Unable_to_attack", "$range");
            Unable_to_attack.id = "Unable_to_attack";
            Unable_to_attack.projectile = "arrow";
            Unable_to_attack.path_icon = "ui/Icons/iconchong";
            Unable_to_attack.material = "base";
            Unable_to_attack.attack_type = WeaponType.Range;
            Unable_to_attack.base_stats[S.projectiles] = 0;
            Unable_to_attack.base_stats[S.range] = 14;

            EquipmentAsset IfC_14 = AssetManager.items.clone("IfC_14", "$range");
            IfC_14.id = "IfC_14";
            IfC_14.projectile = "C_14_bullet";
            IfC_14.path_icon = "ui/Icons/iconchong";
            IfC_14.attack_type = WeaponType.Range;
            IfC_14.material = "base";
            IfC_14.base_stats[S.projectiles] = 1;
            IfC_14.base_stats[S.attack_speed] = 300;
            IfC_14.base_stats[S.range] = 6;


            EquipmentAsset C_14item = AssetManager.items.clone("C_14","shotgun");
            C_14item.id = "C_14";
            C_14item.path_icon = "items/C14";
            C_14item.projectile = "C_14_bullet";
            C_14item.path_icon = "ui/Icons/iconchong";
            //C_14item.tech_needed = "Terran_1";
            C_14item.base_stats[S.projectiles] = 5;
            C_14item.attack_type = WeaponType.Range;
            C_14item.base_stats[S.attack_speed] = 300f;
            C_14item.base_stats[S.damage] = -15;
            C_14item.equipment_value = 300;
            C_14item.material = "steel";
            C_14item.setCost(0, "steel", 1, "JTkuang", 1);
            AssetManager.items.add(C_14item);
            //addItemSprite(C_14item.id, C_14item.material);
            Localization.AddOrSet(C_14item.id, C_14item.id);
            Localization.AddOrSet("item_C_14", "C-14型高斯步枪");



            //var h = AssetManager.raceLibrary.get("human");
            //h.preferred_weapons.Add("C_14");
            //var o = AssetManager.raceLibrary.get("orc");
            //o.preferred_weapons.Add("C_14");
            //var e = AssetManager.raceLibrary.get("elf");
            //e.preferred_weapons.Add("C_14");
            //var d = AssetManager.raceLibrary.get("dwarf");
            //d.preferred_weapons.Add("C_14");

        }
        public static void addItemSprite(string id, string material)
        {
            var dictItems = Reflection.GetField(typeof(ActorAnimationLoader), null, "dictItems") as Dictionary<string, Sprite>;
            var sprite = Resources.Load<Sprite>("actors/items/w_" + id + "_" + material);
            dictItems.Add(sprite.name, sprite);
        }
    }
}