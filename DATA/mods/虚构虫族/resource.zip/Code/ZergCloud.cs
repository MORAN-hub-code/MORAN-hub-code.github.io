﻿using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;
using System.Threading;
using System.Text;
using ai;
using ai.behaviours;

namespace Zerg
{
    class ZergCloud//暂时无用，没做完
    {
        public static void init()
        {
            CloudAsset cloud_zerg = AssetManager.clouds.clone("cloud_zerg", "cloud_rain");
            cloud_zerg.id = "cloud_zerg";
            cloud_zerg.path_sprites=new string[] {"effects/clouds/cloud_Zerg"};
            cloud_zerg.drop_id = "KongDrop2";
            cloud_zerg.cloud_action_1 = new CloudAction(CloudLibrary.dropAction);
			cloud_zerg.speed_max = 8f;
            cloud_zerg.speed_min = 5f;
            cloud_zerg.considered_disaster = true;
            cloud_zerg.interval_action_1 = 3f;
            cloud_zerg.color = Toolbox.makeColor("#AD00B9");
            AssetManager.clouds.add(cloud_zerg);
        }
    }
}