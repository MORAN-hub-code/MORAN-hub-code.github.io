﻿using HarmonyLib;
using NCMS.Utils;
using System.Collections.Generic;
using UnityEngine;

namespace Zerg
{
    
    class ZergEra
    {
        public static Dictionary<string, WorldAgeAsset> ZEra = new Dictionary<string, WorldAgeAsset>();
        public static List<string> ZEraId = new List<string>();
        public static WorldAgeAsset Zerg_Era;
        public static void init()
        {
            Zerg_Era = new WorldAgeAsset();
            Zerg_Era.id = "ZergEra";
            Zerg_Era.rate = 0;
            Zerg_Era.years_max = 5;
            Zerg_Era.years_min = 3;
            Zerg_Era.path_icon = "ui/Icons/ages/iconAgeZerg";
            Zerg_Era.biomes = new HashSet<string>
            {
                "Biome_juntan"
            };
            Zerg_Era.clouds = List.Of<string>(new string[]
            {
               "cloud_zerg"
            });
            Zerg_Era.cloud_interval = 10;
            Zerg_Era.title_color = Toolbox.makeColor("#A079BF", -1f);
            Zerg_Era.era_effect_overlay_alpha = 0.4f;
            Zerg_Era.special_effect_action = KongDrop;
            Localization.AddOrSet("ZergEra_title", "异虫入侵");
            ZEra.Add("ZergEra", Zerg_Era);
            ZEraId.Add(Zerg_Era.id);

        }

        public static void KongDrop()
        {
            for(int i = 0; i < 6; i++)
            {
                WorldTile randomTile = MapBox.instance.tiles_list.GetRandom();
                MapBox.instance.drop_manager.spawn(randomTile, "KongDrop2", 30f);
            }
        }

        //[HarmonyPrefix]
        //[HarmonyPatch(typeof(WorldAgesWindow), "Update")]
        //public static bool Update_WorldAgesWindow(WorldAgesWindow __instance)
        //{
        //    foreach (string EraId in ZergEra.ZEraId)
        //    {
        //        if (World.world_era == ZergEra.ZEra[EraId])
        //        {
        //            __instance.selection_effect.gameObject.transform.position = new Vector3(1477777f, 1477777f);
        //            return false;
        //        }
        //    }
        //    return true;
        //}
    }
}