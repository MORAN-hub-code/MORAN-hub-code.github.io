﻿using System.Collections.Generic;
using UnityEngine;

namespace Zerg
{
    class ZergDrops
    {
        public static void init()
        {
            DropAsset Jingti = AssetManager.drops.clone("Jingti", "gold");
            Jingti.id = "Jingti";
            Jingti.building_asset = "Jingti";

            DropAsset KongDrop = AssetManager.drops.clone("KongDrop", "$spawn_building$");
            KongDrop.path_texture = "drops/Kong";
            KongDrop.falling_speed = 3f;
            KongDrop.falling_height = new Vector2(60f, 90f);
            KongDrop.action_landed = new DropsAction(action_seeds_Jun);

            DropAsset KongDrop2 = AssetManager.drops.clone("KongDrop2", "$spawn_building$");
            KongDrop2.path_texture = "drops/Kong";
            KongDrop2.falling_speed = 3f;
            KongDrop2.falling_height = new Vector2(60f, 90f);
            KongDrop2.action_landed = new DropsAction(action_Landed);

            DropAsset MegaKongDrop = AssetManager.drops.clone("MegaKongDrop", "$spawn_building$");
            MegaKongDrop.path_texture = "drops/MegaKong";
            MegaKongDrop.falling_speed = 3f;
            MegaKongDrop.falling_height = new Vector2(60f, 90f);
            MegaKongDrop.action_landed = new DropsAction(action_MegaLanded);


            DropAsset ZergPlague = AssetManager.drops.clone("ZergPlague", "plague");
            ZergPlague.action_landed = new DropsAction(action_ZergPlague);
        }
        public static void action_seeds_Jun(WorldTile pTile = null, string pDropID = null)
        {
            if (!pTile.isGoodForBoat())
            {
                Actor act = World.world.units.createNewUnit(SZB.Creep_Tumor, pTile);
                ZergAction.Spread_Jun(act, 8, 1f);
            }
            World.world.units.createNewUnit(SZA.Drone, pTile);
            for (int j = 0; j < 4; j++)
            {
                World.world.units.createNewUnit(SZA.Zergling, pTile);
            }
            
        }
        public static void action_ZergPlague(WorldTile pTile = null, string pDropID = null)
        {
            foreach (Actor actor in Finder.getUnitsFromChunk(pTile, 0, 3))
            {
                if (actor.hasTrait("异虫感染"))
                {
                    actor.startShake();
                    actor.startColorEffect();
                }
                else
                {
                    actor.addTrait("异虫感染");
                }
            }
        }

        public static List<string> RandomZerg = new List<string>() { SZA.Queen, SZA.Baneling, SZA.Infestor, SZA.Swarm_Host };
        public static void action_MegaLanded(WorldTile pTile = null, string pDropID = null)
        {
            int a = 9;
            if (!pTile.isGoodForBoat())
            {
                World.world.units.createNewUnit(SZB.Creep_Tumor, pTile);
                World.world.units.createNewUnit(SZA.Drone, pTile);
                a--;
            }
            int i = Randy.randomInt(4, 6);
            for (int j = 0; j < i; j++)
            {
                World.world.units.createNewUnit(SZA.Zergling, pTile);
                a--;
            }
            while (a > 0)
            {
                World.world.units.createNewUnit(RandomZerg.GetRandom(), pTile);
                a--;
            }
        }
        public static void action_Landed(WorldTile pTile = null, string pDropID = null)
        {
            int a = 6;
            if (!pTile.isGoodForBoat())
            {
                World.world.units.createNewUnit(SZB.Creep_Tumor, pTile);
                World.world.units.createNewUnit(SZA.Drone, pTile);
                a--;
            }
            int i = Randy.randomInt(4, 6);
            for (int j = 0; j < i; j++)
            {
                World.world.units.createNewUnit(SZA.Zergling, pTile);
                a--;
            }
            while (a > 0)
            {
                if (Randy.randomChance(0.3f))
                {
                    World.world.units.createNewUnit(SZA.Baneling, pTile);
                    a -= 2;
                    continue;
                }
                else if (Randy.randomChance(0.1f))
                {
                    World.world.units.createNewUnit(SZA.Infestor, pTile);
                    a -= 2;
                    continue;
                }
            }
        }
    }
}
