﻿namespace Zerg
{
    class MoreDisaster
    {
        public static void init()
        {
            DisasterAsset spawnZerg = new DisasterAsset();
            spawnZerg.id = "异虫降临";
            spawnZerg.rate = 5;
            spawnZerg.chance = 0.1f;
            spawnZerg.min_world_cities = 15;
            spawnZerg.min_world_population = 3000;
            spawnZerg.world_log = "worldlog_disaster_Zerg";
            spawnZerg.action = ZergAction.spawnZerg;
            AssetManager.disasters.add(spawnZerg);


        }
    }
}