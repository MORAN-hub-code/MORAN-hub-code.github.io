﻿using NCMS.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics;

namespace Zerg
{
    class MoreAction
    {

        public static bool canAttackTarget(BaseSimObject baseSim,BaseSimObject pTarget, bool pCheckForFactions = true)
        {
            if (!baseSim.isAlive())
            {
                return false;
            }
            if (!pTarget.isAlive())
            {
                return false;
            }
            string tSpeciesID = string.Empty;
            bool tThisIsActor = baseSim.isActor();
            WeaponType tAttackType;
            if (tThisIsActor)
            {
                tSpeciesID = baseSim.a.asset.id;//此处删除了skip attack logic的return false
                tAttackType = baseSim.a.s_type_attack;
            }
            else
            {
                tSpeciesID = baseSim.b.kingdom.getSpecies();
                tAttackType = WeaponType.Range;
            }
            if (pTarget.isActor())
            {
                Actor tActorTarget = pTarget.a;
                if (!tActorTarget.asset.can_be_killed_by_stuff)
                {
                    return false;
                }
                if (tActorTarget.isInsideSomething())
                {
                    return false;
                }
                if (tActorTarget.isFlying() && tAttackType == WeaponType.Melee)
                {
                    return false;
                }
                if (tActorTarget.ai.action != null && tActorTarget.ai.action.special_prevent_can_be_attacked)
                {
                    return false;
                }
                if (tActorTarget.isInMagnet())
                {
                    return false;
                }
                if (pCheckForFactions && baseSim.areFoes(pTarget) && tActorTarget.isKingdomCiv() && baseSim.isKingdomCiv() && !baseSim.hasStatusTantrum() && !tActorTarget.hasStatusTantrum() && !WorldLawLibrary.world_law_angry_civilians.isEnabled())
                {
                    if (tActorTarget.asset.id == tSpeciesID && tActorTarget.profession_asset.is_civilian)
                    {
                        return false;
                    }
                    if (tActorTarget.asset.id == tSpeciesID && tThisIsActor && baseSim.a.profession_asset.is_civilian)
                    {
                        return false;
                    }
                }
                if (pCheckForFactions && baseSim.isActor() && baseSim.a.hasCannibalism() && baseSim.a.isSameSpecies(pTarget.a))
                {
                    Family tFamilyThis = baseSim.a.family;
                    Family tFamilyTarget = tActorTarget.family;
                    if (tFamilyTarget == null || tFamilyThis == null)
                    {
                        return false;
                    }
                    if (baseSim.a.hasFamily())
                    {
                        if (tFamilyTarget == tFamilyThis)
                        {
                            return false;
                        }
                        if (!tFamilyTarget.areMostUnitsHungry() && !tFamilyThis.areMostUnitsHungry())
                        {
                            return false;
                        }
                    }
                }
            }
            else
            {
                Building tBuildingTarget = pTarget.b;
                if (baseSim.isKingdomCiv() && tBuildingTarget.asset.city_building && tBuildingTarget.asset.tower && !tBuildingTarget.isCiv() && tThisIsActor && baseSim.a.profession_asset.is_civilian && !WorldLawLibrary.world_law_angry_civilians.isEnabled() && tBuildingTarget.kingdom.getSpecies() == baseSim.kingdom.getSpecies())
                {
                    return false;
                }
                if (tThisIsActor)
                {
                    return baseSim.a.asset.can_attack_buildings || (baseSim.a.asset.can_attack_brains && pTarget.kingdom.asset.brain);
                }
            }
            if (tThisIsActor)
            {
                ActorAsset tActorAsset = baseSim.a.asset;
                if (!baseSim.a.isWaterCreature() || !baseSim.a.hasRangeAttack())
                {
                    if (baseSim.a.isWaterCreature() && !tActorAsset.force_land_creature)
                    {
                        if (!pTarget.isInLiquid())
                        {
                            return false;
                        }
                        if (!pTarget.current_tile.isSameIsland(baseSim.current_tile))
                        {
                            return false;
                        }
                    }
                    else if (tAttackType == WeaponType.Melee && pTarget.isInLiquid() && !baseSim.a.isWaterCreature())
                    {
                        return false;
                    }
                }
            }
            return true;
        }

       

        public static Actor summonZergUnit(BaseSimObject pTarget ,string pID,WorldTile pTile)
        {
            Subspecies sub = null;
            foreach (Subspecies subspecy in World.world.subspecies)
            {
                if (subspecy.isSpecies(pID))
                {
                    sub = subspecy;
                    break;
                }
            }
            Actor act = World.world.units.createNewUnit(pID, pTile, pSubspecies: sub);
            act.kingdom = pTarget.a.kingdom;
            if(pTarget.hasCity())
            {
                act.city = pTarget.a.city;
                act.city.units.Add(act);
            }
            //if (act.asset.id == SZA.Drone && act.city != null)
            //{
            //    act.subspecies.addTrait("prefrontal_cortex");
            //}

            return act;
        }
        public static void throwAtTile(string id,BaseSimObject pTarget, WorldTile pTile)
        {
            Vector2Int pos = pTile.pos;
            float pDist = Vector2.Distance(pTarget.current_position, pos);
            Vector3 newPoint = Toolbox.getNewPoint(pTarget.current_position.x, pTarget.current_position.y, pos.x, pos.y, pDist);
            Vector3 newPoint2 = Toolbox.getNewPoint(pTarget.current_position.x, pTarget.current_position.y, pos.x, pos.y, pTarget.a.stats["size"]);
            newPoint2.y += 0.5f;
            World.world.projectiles.spawn(pTarget, null, id, newPoint2, newPoint,pForcedKingdom:pTarget.kingdom);
        }

        public  static bool spawnUnit(WorldTile pTile, string pPowerID)
        {
            GodPower godPower = AssetManager.powers.get(pPowerID);
            MusicBox.playSound("event:/SFX/UNIQUE/SpawnWhoosh", pTile.pos.x, pTile.pos.y);
            EffectsLibrary.spawn("fx_spawn", pTile);
            string[] actor_asset_ids = godPower.actor_asset_ids;
            string pStatsID = ((actor_asset_ids == null || actor_asset_ids.Length == 0) ? godPower.actor_asset_id : godPower.actor_asset_ids.GetRandom());

            Subspecies sub = null;
            if(PlayerConfig.dict["Zerg_Same_sub"].boolVal)
            {
                foreach (Subspecies subspecy in World.world.subspecies)
                {
                    if (subspecy.isSpecies(pStatsID))
                    {
                        sub = subspecy;
                        break;
                    }
                }
            }
            Actor pActor = World.world.units.spawnNewUnitByPlayer(pStatsID, pTile, pSpawnSound: true, pMiracleSpawn: true, godPower.actor_spawn_height,sub);
            AchievementLibrary.achievementBackToBetaTesting.check(null, pActor);
            return true;
        }

        public static void add_id_and_description(string str1, string str2)//我亡灵天灾里写的，直接搬，诶嘿
        {
            Localization.AddOrSet(str1, str1);
            Localization.AddOrSet(str2, str2);
        }
        public static void add_id_and_description(string id, string str1, string des, string str2)
        {
            Localization.AddOrSet(id, str1);
            Localization.AddOrSet(des, str2);
        }


        //public static void addItem(Actor a, string pID, string materials = null)//under0.22
        //{
        //    if (a.equipment != null)
        //    {
        //        ItemAsset item_asset = AssetManager.items.get(pID);
        //        if (item_asset != null)
        //        {
        //            if (materials == null) { materials = Randy.getRandom<string>(item_asset.materials); }
        //            a.equipment.getSlot(item_asset.equipment_type).setItem(ItemGenerator.generateItem(
        //            item_asset, materials, World.world.mapStats.year, a.kingdom, a.getName(), 1, a));
        //        }
        //    }
        //}

        //public static bool hasItem(Actor act, string pID)
        //{
        //    if (act.equipment != null)
        //    {
        //        List<ActorEquipmentSlot> AESKList = ActorEquipment.getList(act.equipment);
        //        if (AESKList != null && AESKList.Count > 0)
        //        {
        //            foreach (ActorEquipmentSlot AE in AESKList)
        //            {
        //                if (AE.data != null && AE.data.id == pID) { return true; }
        //            }
        //        }
        //    }
        //    return false;
        //}

        //public static bool canAttackTarget(BaseSimObject baseSim ,BaseSimObject pTarget)//under0.22
        //{
        //    if (!baseSim.isAlive())
        //    {
        //        return false;
        //    }

        //    if (!pTarget.isAlive())
        //    {
        //        return false;
        //    }
        //    Race race = baseSim.a.race;
        //    WeaponType weaponType = baseSim.a.s_attackType;
        //    if (pTarget.isActor())
        //    {
        //        Actor actor = pTarget.a;
        //        if (!actor.asset.canBeKilledByStuff)
        //        {
        //            return false;
        //        }

        //        if (actor.isInsideSomething())
        //        {
        //            return false;
        //        }

        //        if (actor.ai.action != null && actor.ai.action.special_prevent_can_be_attacked)
        //        {
        //            return false;
        //        }

        //        if (actor.isInMagnet())
        //        {
        //            return false;
        //        }

        //        if (baseSim.a.s_attackType == WeaponType.Melee && pTarget.zPosition.y > 0f)
        //        {
        //            return false;
        //        }

        //        if (!actor.kingdom.asset.mad && !baseSim.kingdom.asset.mad && !World.world.worldLaws.world_law_angry_civilians.boolVal)
        //        {
        //            if (actor.race == race && actor.professionAsset.is_civilian)
        //            {
        //                return false;
        //            }

        //            if (actor.race == race && baseSim.a.professionAsset.is_civilian)
        //            {
        //                return false;
        //            }
        //        }

        //        if (actor.isFlying() && weaponType == WeaponType.Melee)
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        Building building = pTarget.b;
        //        if (baseSim.kingdom.isCiv() && building.asset.cityBuilding && building.asset.tower && baseSim.a.professionAsset.is_civilian && !World.world.worldLaws.world_law_angry_civilians.boolVal && building.kingdom.race == baseSim.kingdom.race)
        //        {
        //            return false;
        //        }
        //        if (baseSim.a.asset.canAttackBuildings)
        //        {
        //            return true;
        //        }

        //        if (baseSim.a.asset.canAttackBrains && pTarget.kingdom.asset.brain)
        //        {
        //            return true;
        //        }
        //        return false;
        //    }
        //    if (weaponType == WeaponType.Melee && pTarget.isInLiquid() && !baseSim.a.asset.oceanCreature)
        //    {
        //        return false;
        //    }

        //    return true;
        //}
    }
}
