﻿using ai.behaviours;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

namespace Zerg
{
    class Patches
    {
        public static void init()
        {
            Harmony.CreateAndPatchAll(typeof(Patches));
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitSpawner), "setUnitFromHere")]
        public static void setUnitFromHere(UnitSpawner __instance, ref Actor pActor)
        {
            if (pActor.hasTrait("异虫")|| pActor.hasTrait("异虫建筑"))
            {
                pActor.kingdom = __instance.building.kingdom;
            }
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(BehTrySleep), "execute")]
        public static bool BehTrySleep_execute(BehTrySleep __instance, ref Actor pActor, ref BehResult __result)
        {
            if(pActor.hasSubspeciesTrait("NoSleep"))
            {
                __result = BehResult.Continue;
                return false;
            }
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "createAI")]
        public static bool City_createAI(City __instance)
        {
            if (__instance.kingdom != null && __instance.kingdom.getActorAsset().traits.Contains("异虫"))
            {
                if (!Globals.AI_TEST_ACTIVE)
                {
                    return false;
                }
                __instance.ai = new AiSystemCity(__instance);
                __instance.ai.nextJobDelegate = new GetNextJobID( () => "zerg_city");
                __instance.ai.jobs_library = AssetManager.job_city;
                __instance.ai.task_library = AssetManager.tasks_city;
                MonoBehaviour.print("[Zerg]city normal AI false");
                return false;
            }
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Kingdom), "createAI")]
        public static bool Kingdom_createAI(Kingdom __instance)
        {
            if (__instance.data.original_actor_asset != null && __instance.getActorAsset().traits.Contains("异虫"))
            {
                if (!Globals.AI_TEST_ACTIVE)
                {
                    return false;
                }
                __instance.ai = new AiSystemKingdom(__instance);
                __instance.ai.nextJobDelegate = new GetNextJobID(() => "zerg_kingdom");
                __instance.ai.jobs_library = AssetManager.job_kingdom;
                __instance.ai.task_library = AssetManager.tasks_kingdom;
                MonoBehaviour.print("[Zerg]kingdom normal AI false");
                return false;
            }
            return true;
        }


        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), "pickupResourcesFromKill")]
        public static void Actor_pickupResourcesFromKill(Actor __instance, ref Actor pAttacker)
        {
            if(pAttacker.hasTrait("异虫"))
            {
                pAttacker.AddBiomass(Mathf.Max(5, __instance.getMaxHealth() / 20));
                //float Biomass = pAttacker.GetBiomass();
                //bool flag = false;
                //foreach(ActorTrait t in  pAttacker.traits) 
                //{
                //    if (t.id == "Zerg_Biomass_Add")
                //    {
                //        t.base_stats["multiplier_health"] = Biomass * 0.03f;
                //        t.base_stats["multiplier_attack_speed"] = Biomass * 0.01f;
                //        t.base_stats["multiplier_stamina"] = Biomass * 0.03f;
                //        t.base_stats["multiplier_damage"] = Biomass * 0.005f;
                //        t.base_stats["multiplier_speed"] = Biomass * 0.005f;
                //        t.base_stats["scale"] = Biomass * 0.0002f;
                //        flag = true;
                //    }
                //}
                //if(!flag)
                //{
                //    ActorTrait trait = AssetManager.traits.clone("Zerg_Biomass_Add","Zerg_Biomass");
                //    trait.base_stats["multiplier_health"] = Biomass * 0.03f;
                //    trait.base_stats["multiplier_attack_speed"] = Biomass * 0.01f;
                //    trait.base_stats["multiplier_stamina"] = Biomass * 0.03f;
                //    trait.base_stats["multiplier_damage"] = Biomass * 0.005f;
                //    trait.base_stats["multiplier_speed"] = Biomass * 0.005f;
                //    trait.base_stats["scale"] = Biomass * 0.0002f;
                //    trait.action_attack_target = ZergAction.Biomass;
                //    pAttacker.addTrait(trait);
                //}
            }
        }
        //[HarmonyPrefix]
        //[HarmonyPatch(typeof(Actor), "calculateMainSprite")]
        //public static bool calculateMainSprite(Actor __instance,ref Sprite __result)
        //{
        //    if (__instance.asset.has_override_sprite)
        //    {
        //        __result = __instance.asset.get_override_sprite(__instance);
        //        return false;
        //    }
        //    __instance.checkAnimationContainer();
        //    if (__instance.ai.action != null && __instance.ai.action.force_animation)
        //    {
        //        __result = __instance.animation_container.sprites[__instance.ai.action.force_animation_id];
        //        return false;
        //    }
        //    if (!__instance.isAlive() || __instance._has_stop_idle_animation)
        //    {
        //        __result = __instance.animation_container.idle.frames[0];
        //        return false;
        //    }
        //    float tAnimSpeed = __instance.asset.animation_walk_speed;
        //    bool tSpeedAffectsAnimSpeed = false;
        //    ActorAnimation tAnimation;
        //    if (__instance.is_moving || __instance.timer_jump_animation > 0f || __instance.move_jump_offset.y > 0f || __instance.is_in_magnet)
        //    {
        //        MonoBehaviour.print("debug1");
        //        if (__instance.animation_container.has_swimming && __instance.isAffectedByLiquid())
        //        {
        //            tAnimation = __instance.animation_container.swimming;
        //            tAnimSpeed = __instance.asset.animation_swim_speed;
        //        }
        //        else
        //        {
        //            MonoBehaviour.print("debug2");
        //            tAnimation = __instance.animation_container.walking;
        //        }
        //        tSpeedAffectsAnimSpeed = true;
        //    }
        //    else if (__instance.position_height > 0f)
        //    {
        //        MonoBehaviour.print("debug3");
        //        tAnimation = __instance.animation_container.idle;
        //    }
        //    else if (__instance.animation_container.has_swimming && __instance.isAffectedByLiquid())
        //    {
        //        MonoBehaviour.print("debug4");
        //        tAnimation = __instance.animation_container.swimming;
        //        tAnimSpeed = __instance.asset.animation_swim_speed;
        //        tSpeedAffectsAnimSpeed = true;
        //    }
        //    else
        //    {
        //        MonoBehaviour.print($"debug5{__instance.animation_container.idle == null}");
        //        tAnimation = __instance.animation_container.idle;
        //        tAnimSpeed = __instance.asset.animation_idle_speed;
        //    }
        //    if (__instance.asset.animation_speed_based_on_walk_speed && tSpeedAffectsAnimSpeed)
        //    {
        //        tAnimSpeed *= __instance.stats["speed"] / 10f;
        //        tAnimSpeed = Mathf.Clamp(tAnimSpeed, 4f, tAnimSpeed);
        //    }
        //    Sprite tMainSprite;
        //    if (tAnimation.frames.Length > 1)
        //    {
        //        tMainSprite = AnimationHelper.getSpriteFromList(__instance.GetHashCode(), tAnimation.frames, tAnimSpeed);
        //    }
        //    else
        //    {
        //        tMainSprite = tAnimation.frames[0];
        //    }
        //    __result = tMainSprite;
        //    return false;
        //}

        //[HarmonyPostfix]
        //[HarmonyPatch(typeof(Actor), "isInfectedWithAnything")]
        //public static void isInfectedWithAnything(Actor __instance, ref bool __result)
        //{
        //    if (__instance.hasTrait("异虫感染"))
        //    {
        //        __result = true;
        //    }
        //}
    }
}
