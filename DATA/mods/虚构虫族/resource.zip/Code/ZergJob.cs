﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;
using System.Reflection;
using ai;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using NCMS.Utils;
using UnityEngine;
using System.ComponentModel;
using ai.behaviours;

namespace Zerg
{
    class ZergJob
    {
        public static DecisionAsset dec_build_zerg_kingdom;
        public static void init()
        {
            AssetManager.job_actor.add(new ActorJob
            { id = "building" });
            AssetManager.job_actor.t.addTask("wait");

            AssetManager.job_actor.add(new ActorJob
            { id = "Fighter" });
            AssetManager.job_actor.t.addTask("Fighter");
            AssetManager.job_actor.t.addTask("random_move");

            AssetManager.job_actor.add(new ActorJob
            { id = "FlyFighter" });
            AssetManager.job_actor.t.addTask("Fighter");
            AssetManager.job_actor.t.addTask("random_move");
            //因为判定原因，所以把两个job的功能改成一样的了，否则会因为大量及其耗时的判定导致游戏画面卡死

            AssetManager.job_actor.add(new ActorJob
            { id = "explorers" });
            AssetManager.job_actor.t.addTask("random_move");

            AssetManager.job_actor.add(new ActorJob
            { id = "commander" });
            AssetManager.job_actor.t.addTask("random_move");
            AssetManager.job_actor.t.addTask("Commander");

            AssetManager.job_actor.add(new ActorJob
            { id = "overmind" });
            AssetManager.job_actor.t.addTask("Commander");

            BehaviourTaskActor Fighter = new BehaviourTaskActor();
            Fighter.id = "Fighter";
            Fighter.addBeh(new BehGoToTileTarget());
            AssetManager.tasks_actor.add(Fighter);

            BehaviourTaskActor Commander = new BehaviourTaskActor();
            Commander.id = "Commander";
            Commander.addBeh(new BehFindEnemy2());
            Commander.addBeh(new BehGoToTileTarget());
            AssetManager.tasks_actor.add(Commander);

            //BehaviourTaskActor FlyFighter = new BehaviourTaskActor();
            //FlyFighter.id = "FlyFighter";
            //FlyFighter.addBeh(new FlyerBehFindEnemy());
            //FlyFighter.addBeh(new BehGoToTileTarget());
            //AssetManager.tasks_actor.add(FlyFighter);

            //ActorJob zergqueen = new ActorJob()
            //{
            //    id = "zergmindqueen"
            //};
            //zergqueen.addTask("queen_build_city_here");
            ////zergqueen.addTask("random_move");
            //zergqueen.addTask("queen_nomad_try_build_city");
            //zergqueen.addTask("check_if_stuck_on_small_land");
            //zergqueen.addTask("end_job");
            //AssetManager.job_actor.add(zergqueen);

            //ActorJob zergunit = new ActorJob()
            //{
            //    id = "zergunit"
            //};
            //zergunit.addTask("check_join_city");
            //zergunit.addTask("random_move");
            //zergunit.addTask("check_join_empty_nearby_city");
            //zergunit.addTask("check_if_stuck_on_small_land");
            //zergunit.addTask("end_job");
            //AssetManager.job_actor.add(zergunit);



            DecisionAsset dec_build_zerg_kingdom = new DecisionAsset();
            dec_build_zerg_kingdom.id = "build_zerg_kingdom";
            dec_build_zerg_kingdom.priority = NeuroLayer.Layer_4_Critical;
            dec_build_zerg_kingdom.path_icon = "ui/Icons/iconzerg";
            dec_build_zerg_kingdom.cooldown = 5;
            dec_build_zerg_kingdom.unique = true;
            dec_build_zerg_kingdom.only_safe = true;
            dec_build_zerg_kingdom.weight = 2f;
            ZergJob.dec_build_zerg_kingdom = dec_build_zerg_kingdom;
            AssetManager.decisions_library.add(dec_build_zerg_kingdom);

            BehaviourTaskActor task_build_zerg_kingdom = new BehaviourTaskActor();
            task_build_zerg_kingdom.id = "build_zerg_kingdom";
            task_build_zerg_kingdom.addBeh(new Zerg.Behaviour.BehZergBuildCity());
            AssetManager.tasks_actor.add(task_build_zerg_kingdom);

            BehaviourTaskKingdom task_zerg_kingdom = new BehaviourTaskKingdom();
            task_zerg_kingdom.id = "zerg_start_war";
            task_zerg_kingdom.addBeh(new Zerg.Behaviour.KingdomBehStartWar());
            AssetManager.tasks_kingdom.add(task_zerg_kingdom);

            BehaviourTaskCity task_zerg_city_update_army = new BehaviourTaskCity();
            task_zerg_city_update_army.id = "zerg_city_update_army";
            task_zerg_city_update_army.addBeh(new Zerg.Behaviour.CityBehZergCityCheckArmy());
            task_zerg_city_update_army.addBeh(new Zerg.Behaviour.CityBehZergUpdateArmy());
            AssetManager.tasks_city.add(task_zerg_city_update_army);

            JobCityAsset Zerg_city = new JobCityAsset();
            Zerg_city.id = "zerg_city";
            Zerg_city.addTask("wait1");
            Zerg_city.addTask("zerg_city_update_army"); //太卡，放弃
            AssetManager.job_city.add(Zerg_city);

            KingdomJob Zerg_kingdom = new KingdomJob();
            Zerg_kingdom.id = "zerg_kingdom";
            Zerg_kingdom.addTask("wait1");
            Zerg_kingdom.addTask("zerg_start_war");
            AssetManager.job_kingdom.add(Zerg_kingdom);
        }


    }
}
