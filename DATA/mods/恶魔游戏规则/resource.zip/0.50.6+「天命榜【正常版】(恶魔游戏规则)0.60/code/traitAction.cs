using System;
using System.Linq;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using DemonGameRules.code;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace DemonGameRules2.code
{
    public static class traitAction
    {
        // 前缀称谓字典
        private static readonly Dictionary<string, string[]> _PrefixTitlesnoneMap = new Dictionary<string, string[]>
        {
            {"PrefixTitlesnone", new string[] { "1", "2", "3" }}
        };

        // 修正后的称谓字典
        private static readonly Dictionary<string, string[]> _WarriorTitlesnoneMap = new Dictionary<string, string[]>
        {
            {"WarriorTitlesnone", new string[] { "1", "2", "3" }}
        };

        private static List<string> _availablePrefixes = new List<string>();
        private static List<string> _availableWarriors = new List<string>();
        private static HashSet<string> _usedTitles = new HashSet<string>(); // 高性能去重

        // 文件输出路径
        private static readonly string LogDirectory = Path.Combine(Application.persistentDataPath, "logs");
        private static string currentSessionFile = null;
        private static DateTime sessionStartTime;

        #region 排行榜核心静态变量
        // 击杀排行榜：Key=角色名，Value=击杀数
        public static List<KeyValuePair<string, int>> killLeaderboard = new List<KeyValuePair<string, int>>();

        // 战力排行榜：Key=角色名，Value=战力值
        public static List<KeyValuePair<string, float>> powerLeaderboard = new List<KeyValuePair<string, float>>();

        private static int lastReportedYear = 0;
        private const int REPORT_INTERVAL_YEARS = 50;
        #endregion

        // 防死循环的静态标记
        private static bool _isProcessingExchange = false;
        private static bool _isProcessingHit = false;

        #region 基础功能方法
        // 释放称号的方法，供外部调用
        public static void ReleaseTitle(string title)
        {
            if (_usedTitles.Contains(title))
            {
                _usedTitles.Remove(title);
            }
        }

        public static string GetUniqueTitle()
        {
            // 组合称谓（格式：前缀·称谓）
            string fullTitle = "none";
            // 注：当前返回固定值"none"，若需实际组合逻辑，需补充前缀+称谓的随机/筛选逻辑
            return fullTitle;
        }

        /// <summary>
        /// 获取基础名字（去除头衔、死亡前缀）
        /// </summary>
        public static string GetBaseName(string fullName)
        {
            // 先统一去掉 [死亡]- 前缀
            fullName = TrimDeathPrefix(fullName);

            // 检查破折号分隔符
            int lastDash = fullName.LastIndexOf('-');
            int secondLastDash = lastDash >= 0 ? fullName.LastIndexOf('-', lastDash - 1) : -1;

            int lastSpace = fullName.LastIndexOf(' ');
            int secondLastSpace = lastSpace >= 0 ? fullName.LastIndexOf(' ', lastSpace - 1) : -1;

            bool useDash = lastDash >= 0 && (lastSpace < 0 || lastDash > lastSpace);
            bool useSpace = lastSpace >= 0 && (lastDash < 0 || lastSpace > lastDash);

            if (useDash)
            {
                if (secondLastDash < 0)
                    return fullName.Substring(0, lastDash).Trim();
                else
                    return fullName.Substring(secondLastDash + 1, lastDash - secondLastDash - 1).Trim();
            }
            else if (useSpace)
            {
                if (secondLastSpace < 0)
                    return fullName.Substring(0, lastSpace).Trim();
                else
                    return fullName.Substring(secondLastSpace + 1, lastSpace - secondLastSpace - 1).Trim();
            }

            return fullName;
        }

        /// <summary>
        /// 获取完整称号（去除死亡前缀，保留头衔部分）
        /// </summary>
        public static string GetFullTitle(string fullName)
        {
            // 先统一去掉 [死亡]- 前缀
            fullName = TrimDeathPrefix(fullName);

            int lastDash = fullName.LastIndexOf('-');
            int secondLastDash = lastDash >= 0 ? fullName.LastIndexOf('-', lastDash - 1) : -1;

            int lastSpace = fullName.LastIndexOf(' ');
            int secondLastSpace = lastSpace >= 0 ? fullName.LastIndexOf(' ', lastSpace - 1) : -1;

            bool useDash = lastDash >= 0 && (lastSpace < 0 || lastDash > lastSpace);
            bool useSpace = lastSpace >= 0 && (lastDash < 0 || lastSpace > lastDash);

            if (useDash)
            {
                if (secondLastDash < 0)
                    return fullName.Substring(0, lastDash).Trim();
                else
                    return fullName.Substring(secondLastDash + 1, lastDash - secondLastDash - 1).Trim();
            }
            else if (useSpace)
            {
                if (secondLastSpace < 0)
                    return fullName.Substring(0, lastSpace).Trim();
                else
                    return fullName.Substring(secondLastSpace + 1, lastSpace - secondLastSpace - 1).Trim();
            }

            return fullName;
        }

        /// <summary>
        /// 移除名称开头的 [死亡]- 前缀（防止重复）
        /// </summary>
        public static string TrimDeathPrefix(string name)
        {
            if (string.IsNullOrEmpty(name)) return name;

            while (name.StartsWith("[死亡]-"))
            {
                name = name.Substring("[死亡]-".Length);
            }
            return name;
        }

        // 统一的击杀数颜色方法
        public static string GetKillColor(int kills)
        {
            // 按击杀数分档，兼顾原公开方法（高击杀）和排行榜方法（低击杀）的颜色需求
            return kills switch
            {
                >= 3000 => "#FF4500",  // 3000杀+：橙红色（原排行榜100杀+颜色）
                >= 2000 => "#AA88FF",  // 2000-2999杀：淡紫色（原公开方法）
                >= 1000 => "#66AAFF",  // 1000-1999杀：淡蓝色（原公开方法）
                >= 300 => "#88CC88",   // 300-999杀：淡绿色（原公开方法）
                >= 100 => "#FF6347",   // 100-299杀：浅红色（原排行榜50-99杀颜色）
                >= 50 => "#32CD32",    // 50-99杀：lime绿色（原排行榜20-49杀颜色）
                >= 20 => "#00BFFF",    // 20-49杀：天蓝色（原排行榜10-19杀颜色）
                >= 10 => "#FFFFFF",    // 10-19杀：白色（原排行榜10杀以下颜色）
                _ => "#DDDDDD"         // 1-9杀：灰色（原公开方法默认色）
            };
        }

        public static string GetAttackTypeChinese(AttackType type)
        {
            return type switch
            {
                AttackType.Acid => "酸蚀 / Acid",
                AttackType.Fire => "火焰 / Fire",
                AttackType.Plague => "瘟疫 / Plague",
                AttackType.Infection => "感染 / Infection",
                AttackType.Tumor => "肿瘤 / Tumor",
                AttackType.Other => "恶魔游戏规则 / DemonGameRules",
                AttackType.Divine => "神圣 / Divine",
                AttackType.AshFever => "灰烬热 / Ash Fever",
                AttackType.Metamorphosis => "变异 / Metamorphosis",
                AttackType.Starvation => "饥饿 / Starvation",
                AttackType.Eaten => "吞噬 / Eaten",
                AttackType.Age => "衰老 / Age",
                AttackType.Weapon => "武器 / Weapon",
                AttackType.None => "未知 / None",
                AttackType.Poison => "毒素 / Poison",
                AttackType.Gravity => "地图杀 / Gravity",
                AttackType.Drowning => "溺水 / Drowning",
                AttackType.Water => "水 / Water",
                AttackType.Explosion => "爆炸 / Explosion",
                AttackType.Smile => "微笑 / Smile",
                _ => "空白 / Blank"
            };
        }

        public static string GetHealthColor(int current, int max)
        {
            if (max <= 0) return "#AAAAAA";

            float percentage = (float)current / max;
            return percentage switch
            {
                >= 1.0f => "#70DC70",      // 暗绿色
                >= 0.7f => "#70DC70",      // 柔绿色
                >= 0.4f => "#DDB700",      // 暗金色
                >= 0.2f => "#DD7E00",      // 暗橙色
                _ => "#AAAAAA"             // 白色
            };
        }
        #endregion

        #region   伤害系统


        /// <summary>
        /// 恶魔伤害系统（增强版：加入杀敌数属性影响，伤害和回血随机化）
        /// </summary>
        public static void ExecuteDamageExchange(
            BaseSimObject source,
            BaseSimObject target)
        {

            // 在最前面加 50% 概率不做任何动作
            if (UnityEngine.Random.value < 0.5f)
                return;

            if (_isProcessingExchange) return;

            try
            {
                // 基础检查
                if (!source.hasHealth() || target == null || !target.isActor() || !target.hasHealth())
                    return;

                Actor sourceActor = source.a;
                Actor targetActor = target.a;

                // 获取双方的杀敌数
                int sourceKills = sourceActor.data?.kills ?? 1;
                int targetKills = targetActor.data?.kills ?? 1;

                // 阶段1：源单位处理
                _isProcessingExchange = true;



                // 源单位受到的伤害（基于目标攻击力）
                int damageToSource = CalculateDamage(targetActor, sourceActor, sourceKills, targetKills);

                // 应用伤害
                _isProcessingHit = true;
                sourceActor.getHit(damageToSource, true, AttackType.Other, target, false, false, false);
                _isProcessingHit = false;

                // 检查源单位是否存活
                if (!source.hasHealth())
                {
                    return;
                }

                // 源单位回血（击杀数的一半，生命值>100才回血）
                if (source.hasHealth() && sourceActor.getHealth() > 100)
                {
                    int sourceHeal = Mathf.Max(1, sourceKills / 2);  // 至少回复1点
                    sourceActor.restoreHealth(sourceHeal);
                }



                // 目标单位受到的伤害（基于源攻击力）
                int damageToTarget = CalculateDamage(sourceActor, targetActor, targetKills, sourceKills);

                // 应用伤害
                _isProcessingHit = true;
                targetActor.getHit(damageToTarget, true, AttackType.Other, source, false, false, false);
                _isProcessingHit = false;

                // 目标单位回血（击杀数的一半，生命值>100才回血）
                if (target.hasHealth() && targetActor.getHealth() > 100)
                {
                    int targetHeal = Mathf.Max(1, targetKills / 2);  // 至少回复1点
                    targetActor.restoreHealth(targetHeal);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[伤害交换异常] {ex.Message}");
            }
            finally
            {
                _isProcessingExchange = false;
            }
        }

        // 简化伤害计算逻辑
        private static int CalculateDamage(Actor from, Actor to, int fromKills, int toKills)
        {
            // 基础伤害计算（基于攻击力 + 攻击方杀敌数）
            int baseDamage = Mathf.Max(1, (int)(from.stats["damage"] * 1f) + fromKills);

            // 攻击方杀敌数增益
            float killDamageBonus = Mathf.Min(fromKills / 100f * 0.04f, 5f);
            float damageMultiplier = 1 + killDamageBonus;

            // 计算最终伤害（至少为1点）
            int finalDamage = Mathf.Max(1, Mathf.RoundToInt(baseDamage * damageMultiplier));

            // 最低伤害保证为攻击方杀敌数
            finalDamage = Mathf.Max(finalDamage, fromKills * 1);

            return finalDamage;
        }








        #endregion

        #region 排行榜辅助方法
        /// <summary>
        /// 确保存活单位排在排行榜前面
        /// </summary>
        /// 


        public static void EnsureLivingFirstPlace()
        {


            if (World.world?.units == null) return;

            // 获取所有存活单位
            var livingUnits = World.world.units
                .Where(actor => actor != null && actor.hasHealth() && !actor.name.StartsWith("[死亡]-"))
                .Select(actor =>
                {
                    string baseName = TrimDeathPrefix(GetBaseName(actor.name));
                    string kingdom = actor.kingdom?.name ?? "无阵营";
                    string displayName = $"{actor.name}({kingdom})";
                    int kills = actor.data?.kills ?? 0;
                    return new KeyValuePair<string, int>(displayName, kills);
                })
                .GroupBy(e => TrimDeathPrefix(GetBaseName(e.Key.Split('(')[0])))
                .Select(g => g.OrderByDescending(x => x.Value).First())
                .OrderByDescending(e => e.Value)
                .ToList();

            // 取前三名
            var top3 = livingUnits.Take(3).ToList();

            // 剩余单位（存活第4名之后 + 死亡单位）
            var remainingLiving = livingUnits.Skip(3);
            var deadUnits = killLeaderboard
                .Where(e => e.Key.StartsWith("[死亡]-"))
                .Select(e => new KeyValuePair<string, int>(e.Key, e.Value));

            var restUnits = remainingLiving.Concat(deadUnits)
                .GroupBy(e => TrimDeathPrefix(GetBaseName(e.Key.Split('(')[0])))
                .Select(g => g.OrderByDescending(x => x.Value).First())
                .OrderByDescending(e => e.Value)
                .Take(7)
                .ToList();

            // 更新排行榜前 10
            killLeaderboard = top3.Concat(restUnits).ToList();

            
        }

        /// <summary>
        /// 检查单位是否存活（通过显示名称判断）
        /// </summary>
        private static bool IsUnitAlive(string unitEntry)
        {
            return !unitEntry.StartsWith("[死亡]-");
        }
        #endregion

        #region 战力计算与排行榜更新
        /// <summary>
        /// 计算单位战力值（基于属性、击杀数和年龄）
        /// </summary>
        public static float CalculatePower(Actor actor)
        {
            if (actor == null || !actor.hasHealth()) return 0;

            // 基础属性
            float damage = actor.stats["damage"];
            float health = actor.stats["health"];
            float speed = actor.stats["speed"];
            float armor = actor.stats["armor"];

            // 击杀数加成
            int kills = actor.data?.kills ?? 0;
            float killBonus = kills * 0.5f;

            // 年龄加成（年龄越大经验越丰富）
            float age = (float)actor.getAge();
            float ageBonus = Mathf.Min(age * 0.1f, 10f); // 最大10点加成

            // 计算综合战力
            float power = (damage * 2) + (health * 0.5f) + (speed * 0.5f) + (armor * 1.5f) + killBonus + ageBonus;

            return Mathf.Round(power * 10f) / 10f; // 保留一位小数
        }

        /// <summary>
        /// 更新战力排行榜
        /// </summary>
        public static void UpdatePowerLeaderboard()
        {
            if (World.world?.units == null) return;

            // 清空现有榜单
            powerLeaderboard.Clear();

            // 获取所有存活单位并计算战力
            var livingUnits = World.world.units
                .Where(actor => actor != null && actor.hasHealth() && !actor.name.StartsWith("[死亡]-"))
                .Select(actor =>
                {
                    string baseName = TrimDeathPrefix(GetBaseName(actor.name));
                    string kingdom = actor.kingdom?.name ?? "无阵营";
                    string displayName = $"{actor.name}({kingdom})";
                    float power = CalculatePower(actor);
                    return new KeyValuePair<string, float>(displayName, power);
                })
                .GroupBy(e => TrimDeathPrefix(GetBaseName(e.Key.Split('(')[0])))
                .Select(g => g.OrderByDescending(x => x.Value).First())
                .OrderByDescending(e => e.Value)
                .ToList();

            // 取前十名
            powerLeaderboard = livingUnits.Take(10).ToList();
        }
        #endregion

        #region 文件输出方法
        /// <summary>
        /// 初始化新的会话文件
        /// </summary>
        public static void InitializeNewSessionFile()
        {
            try
            {
                // 确保目录存在
                if (!Directory.Exists(LogDirectory))
                {
                    Directory.CreateDirectory(LogDirectory);
                }

                // 记录会话开始时间
                sessionStartTime = DateTime.Now;

                // 生成基于时间的文件名
                string timestamp = sessionStartTime.ToString("yyyyMMdd_HHmmss");
                currentSessionFile = Path.Combine(LogDirectory, $"leaderboard_{timestamp}.txt");

                // 创建文件并写入会话开始信息
                string sessionHeader = $"游戏会话开始时间: {sessionStartTime:yyyy-MM-dd HH:mm:ss}\n";
                sessionHeader += "=".Repeat(50) + "\n\n";

                File.WriteAllText(currentSessionFile, sessionHeader);

                Debug.Log($"新的排行榜文件已创建: {currentSessionFile}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"创建排行榜文件失败: {ex.Message}");
                currentSessionFile = null;
            }
        }

        /// <summary>
        /// 将排行榜信息写入当前会话文件
        /// </summary>
        public static void WriteLeaderboardToFile(string content)
        {
            if (string.IsNullOrEmpty(currentSessionFile)) return;

            try
            {
                        // 追加写入文件
                File.AppendAllText(currentSessionFile, content);
                
                // 只有在重要事件时才显示日志，减少控制台输出
                if (content.Contains("大道争锋") || content.Contains("荣耀榜"))
                {
                    Debug.Log($"重要信息已保存到: {currentSessionFile}");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"保存信息到文件失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 生成纯文本格式的排行榜信息（不含颜色标签）
        /// </summary>
        private static string GeneratePlainTextLeaderboard(int globalLivingCount, int year)
        {
            StringBuilder sb = new StringBuilder();

            // 添加记录时间戳
            sb.AppendLine($"【世界历{year}年 - 第{(year/50)+1}次荣耀榜】");
            sb.AppendLine($"记录时间: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"【世界历{year}年】");
            sb.AppendLine($"存活单位数量: {globalLivingCount}");
            sb.AppendLine();
            

            // 战力排行榜
            sb.AppendLine("【战力排行榜/Power Leaderboard】");
            if (powerLeaderboard.Count > 0)
            {
                for (int i = 0; i < powerLeaderboard.Count && i < 10; i++)
                {
                    var entry = powerLeaderboard[i];
                    string ageInfo = GetUnitAgeInfo(entry.Key);
                    // 移除颜色标签和HTML标签
                    string cleanName = entry.Key;
                    sb.AppendLine($"{i + 1}. {cleanName} - {entry.Value}战力{ageInfo}");
                }
            }
            else
            {
                sb.AppendLine("暂无上榜者/No rankers yet");
            }

            sb.AppendLine();

            // 杀戮排行榜
            sb.AppendLine("【杀戮排行榜/Kills Leaderboard】");
            if (killLeaderboard.Count > 0)
            {
                for (int i = 0; i < killLeaderboard.Count && i < 10; i++)
                {
                    var entry = killLeaderboard[i];
                    string ageInfo = GetUnitAgeInfo(entry.Key);
                    // 移除颜色标签和HTML标签
                    string cleanName = entry.Key;
                    sb.AppendLine($"{i + 1}. {cleanName} - {entry.Value}杀{ageInfo}");
                }
            }
            else
            {
                sb.AppendLine("暂无上榜者/No rankers yet");
            }

            sb.AppendLine("=".Repeat(50) + "\n");

            return sb.ToString();
        }

        /// <summary>
        /// 字符串重复扩展方法
        /// </summary>
        private static string Repeat(this string str, int count)
        {
            if (string.IsNullOrEmpty(str) || count <= 0) return "";

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < count; i++)
            {
                sb.Append(str);
            }
            return sb.ToString();
        }
        #endregion

        #region 排行榜显示逻辑
/// <summary>
/// 获取单位的年龄信息
/// </summary>
private static string GetUnitAgeInfo(string displayName)
{
    try
    {
        // 添加空值检查
        if (string.IsNullOrEmpty(displayName)) return "";
        
        // 解析显示名称获取基础名称和阵营
        string baseName = displayName;
        string kingdom = "无阵营";

        // 查找最后一个 '(' 来分离阵营 - 添加更安全的检查
        if (displayName.Contains("(") && displayName.Contains(")"))
        {
            int parenIndex = displayName.LastIndexOf('(');
            int closingParenIndex = displayName.LastIndexOf(')');
            
            // 确保括号位置有效
            if (parenIndex >= 0 && closingParenIndex > parenIndex && closingParenIndex < displayName.Length)
            {
                baseName = displayName.Substring(0, parenIndex).Trim();
                // 确保不越界
                if (parenIndex + 1 < displayName.Length && closingParenIndex - parenIndex - 1 > 0)
                {
                    kingdom = displayName.Substring(parenIndex + 1, closingParenIndex - parenIndex - 1);
                }
            }
        }

        // 移除可能的死亡前缀
        baseName = TrimDeathPrefix(baseName);
        
        // 如果baseName为空，直接返回
        if (string.IsNullOrEmpty(baseName)) return "";

        // 查找匹配的单位 - 使用更宽松的匹配条件
        var matchedUnit = World.world?.units?.FirstOrDefault(u =>
            u != null &&
            u.hasHealth() &&
            u.name != null &&
            (u.name.Equals(baseName) || u.name.Contains(baseName))
        );

        if (matchedUnit != null)
        {
            float age = (float)matchedUnit.getAge();
            return $" (年龄: {age:F1}岁)";
        }
    }
    catch (Exception ex)
    {
        Debug.LogWarning($"获取年龄信息失败: {ex.Message}");
    }

    return ""; // 找不到单位或出错时返回空字符串
}



        public static void ShowSimplifiedLeaderboard()
        {
            try
            {
                // 检查是否需要初始化新的会话文件
                if (string.IsNullOrEmpty(currentSessionFile))
                {
                    InitializeNewSessionFile();
                }

                int globalLivingCount = World.world?.units?.Count(actor =>
                    actor != null && actor.data != null && actor.data.id > 0 && actor.hasHealth()
                ) ?? 0;

                EnsureLivingFirstPlace(); // 筛选最新击杀榜
                UpdatePowerLeaderboard(); // 更新战力榜

                // 添加世界历时间戳
                int year = 1;
                if (World.world != null)
                {
                    year = (int)(World.world.getCurWorldTime() / 60) + 1;
                }

                // 在消息中添加年份信息
        string leaderboardTextStr = $"[世界历{year}年 - 第{(year/REPORT_INTERVAL_YEARS)+1}次榜单]\n";

                // 先显示战力榜
                leaderboardTextStr += "<color=#FF9900><b>【战力排行榜/Power Leaderboard】</b></color>\n";

        // ========== 修复开始：添加安全检查 ==========
        if (powerLeaderboard != null && powerLeaderboard.Count > 0)
        {
            for (int i = 0; i < Mathf.Min(powerLeaderboard.Count, 10); i++) // 确保不超过10个
            {
                try
                {
                    var entry = powerLeaderboard[i];
                    // 关键修复：添加空值检查
                    if (entry.Key == null) continue;
                    
                    string rankColor;
                    // 前三名固定金/青/铜色
                    if (i == 0) rankColor = "#FFD700";
                    else if (i == 1) rankColor = "#00CED1";
                    else if (i == 2) rankColor = "#CD7F32";
                    else rankColor = "#DDDDDD";

                    // 查找单位并获取年龄
                    string ageInfo = GetUnitAgeInfo(entry.Key);

                    leaderboardTextStr += $"{i + 1}. <color={rankColor}>{entry.Key}</color> - " +
                                        $"<color=#FFCC00>{entry.Value}战力</color>" +
                                        $"<color=#AAAAAA>{ageInfo}</color>\n";
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"处理战力榜第{i+1}位时出错: {ex.Message}");
                    continue;
                }
            }
        }
        else
        {
            leaderboardTextStr += "<color=#AAAAAA>暂无上榜者/No rankers yet</color>\n";
        }

                // 添加分隔线
                leaderboardTextStr += "<color=#666666>────────────────────</color>\n";

                // 再显示击杀榜
                leaderboardTextStr += "<color=#66AAFF><b>【杀戮排行榜/Kills Leaderboard】</b></color>\n";

                if (killLeaderboard != null && killLeaderboard.Count > 0)
        {
            for (int i = 0; i < Mathf.Min(killLeaderboard.Count, 10); i++) // 确保不超过10个
            {
                try
                {
                    var entry = killLeaderboard[i];
                    // 关键修复：添加空值检查
                    if (entry.Key == null) continue;
                    
                    string rankColor;
                    // 前三名固定金/青/铜色，只显示存活单位
                    if (i == 0) rankColor = "#FFD700";
                    else if (i == 1) rankColor = "#00CED1";
                    else if (i == 2) rankColor = "#CD7F32";
                    else rankColor = IsUnitAlive(entry.Key) ? "#DDDDDD" : "#AAAAAA";

                    // 查找单位并获取年龄
                    string ageInfo = GetUnitAgeInfo(entry.Key);

                    leaderboardTextStr += $"{i + 1}. <color={rankColor}>{entry.Key}</color> - " +
                                        $"<color={GetKillColor(entry.Value)}>{entry.Value}杀</color>" +
                                        $"<color=#AAAAAA>{ageInfo}</color>\n";
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"处理击杀榜第{i+1}位时出错: {ex.Message}");
                    continue;
                }
            }
        }
        else
        {
            leaderboardTextStr += "<color=#AAAAAA>暂无上榜者/No rankers yet</color>\n";
        }

                // 调用通知显示
                NotificationHelper.ShowThisMessage(leaderboardTextStr);

                // 控制台日志输出
                Debug.Log(
                    $"\n<color=#666666>════════════════════════════════════════════</color>\n" +
                    $"<color=#FFFF99>☻：{globalLivingCount}</color>\n" +
                    $"{leaderboardTextStr}" +
                    $"<color=#666666>════════════════════════════════════════════</color>\n"
                );

                // 将排行榜信息写入文件
                string plainTextContent = GeneratePlainTextLeaderboard(globalLivingCount, year);
                WriteLeaderboardToFile(plainTextContent);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[简化排行榜异常]：{ex.Message}");
            }
        }
        #endregion


        #region 计时器逻辑
        private const int WAR_INTERVAL_YEARS = 1000;//宣战一次
        private static int lastWarYear = 0;
        private static int lastUnitSpawnYear = 0; // 新增：跟踪上次生成单位的年份
        private static int lastPowerUpdateYear = 0; // 新增：跟踪上次更新战力排行榜的年份
        private const int POWER_UPDATE_INTERVAL_YEARS = 10; // 新增：战力排行榜更新间隔（10年）


        public static void UpdateLeaderboardTimer()
        {
            if (World.world == null) return;

            // 获取当前游戏年份
            int currentYear = (int)(World.world.getCurWorldTime() / 60) + 1;

            // 每 REPORT_INTERVAL_YEARS 年显示排行榜
            if (currentYear >= lastReportedYear + REPORT_INTERVAL_YEARS)
            {
                ShowSimplifiedLeaderboard();
                lastReportedYear = currentYear - (currentYear % REPORT_INTERVAL_YEARS);
            }

            // 每 WAR_INTERVAL_YEARS 年随机国家宣战
            if (currentYear >= lastWarYear + WAR_INTERVAL_YEARS)
            {
                TryRandomWar(); // 调用统一的随机宣战方法（已禁用）
                lastWarYear = currentYear - (currentYear % WAR_INTERVAL_YEARS);
            }

            // 新增：每年调用一次SpawnRandomUnit（已禁用）
            if (currentYear > lastUnitSpawnYear)
            {
                //SpawnRandomUnit(); // 每年生成6个随机单位
                lastUnitSpawnYear = currentYear; // 更新最后生成年份为当前年
            }
            // 新增：每10年更新一次战力排行榜
            if (currentYear >= lastPowerUpdateYear + POWER_UPDATE_INTERVAL_YEARS)
            {
                UpdatePowerLeaderboard(); // 单独更新战力排行榜数据
                lastPowerUpdateYear = currentYear - (currentYear % POWER_UPDATE_INTERVAL_YEARS);
            }

            // 检查帝路事件
            CheckGreatContest();
            // 每帧调用保持疯狂检测方法，但方法内部会按15帧间隔过滤
            EnforceContestantMadness();
        }
        #endregion



        #region 城市叛乱独立机制
        public static void TryRandomWar()
        {
            if (World.world == null || World.world.wars == null) return;

            List<Kingdom> kingdoms = World.world.kingdoms.list;
            if (kingdoms == null || kingdoms.Count == 0) return;

            // ========= 新增：仅剩一个王国时，改为强制内部叛乱 =========
            if (kingdoms.Count == 1)
            {
                Kingdom solo = kingdoms[0];
                if (solo != null && solo.isAlive())
                {
                    int cityCount = solo.cities != null ? solo.cities.Count : 0;
                    if (cityCount >= 2)
                    {
                        UnityEngine.Debug.Log($"[恶魔干涉][单国局面] 世界只剩 {solo.data.name}，改为触发内部叛乱。");
                        TriggerCityRebellion(solo); // 复用你现有的叛乱逻辑
                    }
                    else
                    {
                        UnityEngine.Debug.Log($"[恶魔干涉][单国局面] 仅剩 {solo.data.name} 且城市数={cityCount}，无法触发叛乱（至少需要2座城）。");
                    }
                }
                return; // 单国情形处理完毕
            }
            // =====================================================

            // 2个及以上王国的正常分支（保留你的既有行为）
            // 优先挑选至少2城的王国作为进攻方；否则从全部王国中挑
            List<Kingdom> validAttackers = kingdoms
                .Where(k => k != null && k.isAlive() && k.cities != null && k.cities.Count >= 2)
                .ToList();
            if (validAttackers.Count == 0)
                validAttackers = kingdoms.Where(k => k != null && k.isAlive()).ToList();

            if (validAttackers.Count == 0) return;

            WarManager warManager = World.world.wars;
            Kingdom attacker = validAttackers[Randy.randomInt(0, validAttackers.Count)];

            // 找目标
            Kingdom defender = FindSuitableWarTarget(attacker, kingdoms, warManager);
            WarTypeAsset warType = GetDefaultWarType();

            // 没有任何目标或拿不到战争类型 —— 直接叛乱
            if (defender == null || warType == null)
            {
                UnityEngine.Debug.Log($"[恶魔干涉][无宣战目标/类型] {attacker.data.name} 无法宣战，改为触发叛乱。");
                // 可选保护：避免只有1城时把国家清空（如需允许，删除下面这两行判断）
                if (attacker.cities != null && attacker.cities.Count >= 2)
                    TriggerCityRebellion(attacker);
                else
                    UnityEngine.Debug.Log($"[恶魔干涉][叛乱跳过] {attacker.data.name} 城市不足，避免叛乱导致异常。");
                return;
            }

            // 有目标就尝试宣战
            War newWar = warManager.newWar(attacker, defender, warType);
            if (newWar != null)
            {
                UnityEngine.Debug.Log($" [恶魔干涉]{attacker.data.name} 强制向 {defender.data.name} 宣战！战争名称: {newWar.data.name}");
                return;
            }

            // 宣战失败则直接叛乱（不再检查 hasWars(attacker)）
            UnityEngine.Debug.Log($"[恶魔干涉][宣战失败] {attacker.data.name} 无法对 {defender.data.name} 宣战，改为触发叛乱。");
            if (attacker.cities != null && attacker.cities.Count >= 2)
                TriggerCityRebellion(attacker);
            else
                UnityEngine.Debug.Log($"[恶魔干涉][叛乱跳过] {attacker.data.name} 城市不足，避免叛乱导致异常。");
        }



        private static void TriggerCityRebellion(Kingdom targetKingdom)
        {
            if (targetKingdom == null || targetKingdom.cities == null || targetKingdom.cities.Count == 0)
            {
                UnityEngine.Debug.Log($" {targetKingdom?.data.name} 没有城市，无法触发叛乱。");
                return;
            }

            List<City> rebelliousCities = targetKingdom.cities
                .Where(c => c.getLoyalty() < 30)
                .ToList();

            if (rebelliousCities.Count == 0)
                rebelliousCities = new List<City>(targetKingdom.cities);

            int rebellionCount = Randy.randomInt(1, Mathf.Min(5, rebelliousCities.Count) + 1);
            rebelliousCities.Shuffle();
            List<City> citiesToRebel = rebelliousCities.Take(rebellionCount).ToList();

            UnityEngine.Debug.Log($" {targetKingdom.data.name} 发生叛乱！{rebellionCount}个城市宣布独立。");

            foreach (City rebelCity in citiesToRebel)
            {
                Actor leader = FindCityLeader(rebelCity);
                if (leader != null)
                {
                    Kingdom newKingdom = rebelCity.makeOwnKingdom(leader, true, false);
                    if (newKingdom != null)
                    {
                        UnityEngine.Debug.Log($" {rebelCity.data.name} 成功独立，成立 {newKingdom.data.name}，领导者: {leader.name}");

                        WarTypeAsset warType = GetDefaultWarType();
                        if (warType != null)
                        {
                            World.world.wars.newWar(newKingdom, targetKingdom, warType);
                        }
                    }
                }
                else
                {
                    UnityEngine.Debug.Log($" {rebelCity.data.name} 没有合适的领导者，叛乱失败。");
                }
            }
        }

        private static Actor FindCityLeader(City city)
        {
            if (city.leader != null && city.leader.isAlive())
            {
                return city.leader;
            }

            if (city.units != null && city.units.Count > 0)
            {
                return city.units
                    .Where(actor => actor.isAlive())
                    .OrderByDescending(actor =>
                    {
                        if (actor.stats == null)
                            return 0f;
                        return actor.stats["health"];
                    })
                    .FirstOrDefault();
            }

            return null;
        }

        private static WarTypeAsset GetDefaultWarType()
        {
            if (WarTypeLibrary.normal != null)
            {
                return WarTypeLibrary.normal;
            }

            if (AssetManager.war_types_library != null)
            {
                return AssetManager.war_types_library.get("normal");
            }

            return null;
        }

        private static Kingdom FindSuitableWarTarget(Kingdom attacker, List<Kingdom> kingdoms, WarManager warManager)
        {
            List<Kingdom> possibleTargets = kingdoms.Where(k =>
                k != attacker &&
                !warManager.isInWarWith(attacker, k) &&
                k.isAlive()
            ).ToList();

            return possibleTargets.Count > 0 ? possibleTargets[Randy.randomInt(0, possibleTargets.Count)] : null;
        }
        #endregion

        #region 随机生成
        // 主要种族（90%概率池）- 四大核心种族，每个种族等概率（约22.5%）
        private static readonly List<string> _majorRaces = new List<string>
        {
            "human",   // 人类
            "elf",     // 精灵
            "orc",     // 兽人
            "dwarf"    // 矮人
        };

        // 其他单位（10%概率池）- 所有非核心种族单位，每个单位等概率
        private static readonly List<string> _otherUnits = new List<string>
        {
            // 原始单位列表（排除主要种族）
             "sheep",  "skeleton", 
            // 恶魔、冰原生物、绵羊、天使、骷髅、邪恶法师"demon", "cold_one","angle","evil_mage", 
            "white_mage", "alien", "necromancer", "snowman", "lil_pumpkin",
            // 白法师、外星人、死灵法师、雪人、小南瓜怪
            "bandit",// "UFO", "bioblob", "tumor_monster_unit", "greg",
            // 强盗、不明飞行物、生物blob、肿瘤怪物、格雷格（特殊单位）

            // 火元素单位
            //"fire_elemental", "fire_elemental_blob", "fire_elemental_horse", 
            // 火元素、火元素blob、火元素马
            //"fire_elemental_slug", "fire_elemental_snake",
            // 火元素蛞蝓、火元素蛇

            // 文明单位（civ_前缀表示文明生物）
            "civ_cat", "civ_dog", "civ_chicken", "civ_rabbit", "civ_monkey",
            // 文明猫、文明狗、文明鸡、文明兔子、文明猴子
            "civ_fox", "civ_sheep", "civ_cow", "civ_armadillo", "civ_wolf",
            // 文明狐狸、文明绵羊、文明牛、文明犰狳、文明狼
            "civ_bear", "civ_rhino", "civ_buffalo", "civ_hyena", "civ_rat",
            // 文明熊、文明犀牛、文明水牛、文明鬣狗、文明老鼠
            "civ_alpaca", "civ_capybara", "civ_goat", "civ_scorpion", "civ_crab",
            // 文明羊驼、文明水豚、文明山羊、文明蝎子、文明螃蟹
            "civ_penguin", "civ_turtle", "civ_crocodile", "civ_snake", "civ_frog",
            // 文明企鹅、文明乌龟、文明鳄鱼、文明蛇、文明青蛙
            // "civ_piranha", // 文明食人鱼（已注释，不启用）
            "civ_liliar", "civ_garlic_man", "civ_lemon_man",
            // 文明莉莉尔、文明大蒜人、文明柠檬人
            "civ_acid_gentleman", "civ_crystal_golem", "civ_candy_man", "civ_beetle",
            // 文明酸液绅士、文明水晶傀儡、文明糖果人、文明甲虫

            // 其他单位
            //"acid_blob", 
            // 酸液blob
            // "ant_black", "ant_blue", "ant_green", "ant_red", // 黑蚂蚁、蓝蚂蚁、绿蚂蚁、红蚂蚁（已注释）
            "bear", "bee", "beetle", "buffalo", "butterfly",
            // 熊、蜜蜂、甲虫、水牛、蝴蝶
            // "assimilator", // 同化者（已注释，不启用）
            "smore", "cat", "chicken", "cow", "crab", "crocodile",
            // 棉花糖、猫、鸡、牛、螃蟹、鳄鱼
            // "crabzilla", // 螃蟹zilla（巨型螃蟹，已注释）
            "druid", "fairy", "fire_skull", "fly", "flower_bud",
            // 德鲁伊、仙子、火骷髅、苍蝇、花苞怪
            // "dragon", // 龙（已注释，不启用）
            "lemon_snail", "garl", "fox", "frog", "ghost",
            // 柠檬蜗牛、大蒜怪、狐狸、青蛙、幽灵
            // "god_finger", // 神之手指（已注释，不启用）
            "grasshopper", "hyena", "jumpy_skull",
            // 蚱蜢、鬣狗、跳跳骷髅
            // "living_house", "living_plants", // 活房子、活植物（已注释）
            "monkey",  "penguin",
            // 猴子、蘑菇动物、蘑菇单位、企鹅"mush_animal", "mush_unit",
            // "piranha", // 食人鱼（已注释，不启用）
            "plague_doctor", "rabbit", "raccoon", "seal", "ostrich",
            // 瘟疫医生、兔子、浣熊、海豹、鸵鸟
            // "printer", // 打印机怪（已注释，不启用）
            "unicorn", "rat", "rhino", "snake",
            // 独角兽、老鼠、犀牛、沙蜘蛛、蛇、肿瘤怪物（动物形态） "sand_spider", "tumor_monster_animal",
            "turtle", "wolf"
            // 乌龟、狼、蠕虫、僵尸、僵尸动物"worm", "zombie", "zombie_animal"
            // "zombie_dragon" // 僵尸龙（已注释，不启用）
        };

        // 带权重的随机生成方法（核心：90%四大种族，10%其他单位）
        public static void SpawnRandomUnit()
        {


            string tID;
            // 概率分支：90%选主要种族，10%选其他单位
            if (UnityEngine.Random.value < 0.9f)
            {
                // 四大种族内部等概率随机
                int randomMajorIndex = UnityEngine.Random.Range(0, _majorRaces.Count);
                tID = _majorRaces[randomMajorIndex];
            }
            else
            {
                // 其他单位内部等概率随机
                int randomOtherIndex = UnityEngine.Random.Range(0, _otherUnits.Count);
                tID = _otherUnits[randomOtherIndex];
            }

            // 随机选择生成位置：山地地形（增加空值判断）
            var hillTiles = TileLibrary.hills.getCurrentTiles();
            WorldTile tTile = null;
            if (hillTiles != null && hillTiles.Count > 0)
            {
                int randomTileIndex = UnityEngine.Random.Range(0, hillTiles.Count);
                tTile = hillTiles[randomTileIndex];
            }

            // 奇迹生成概率：10%
            bool tMiracleSpawn = UnityEngine.Random.value < 0.1f;

            // 调用游戏内置方法生成单位（判断地形不为空）
            if (tTile != null)
            {

                // 执行生成逻辑
                for (int i = 0; i < 6; i++)
                {
                    World.world.units.spawnNewUnit(tID, tTile, false, tMiracleSpawn, 6f, null, false);
                }


                // 🌟 生成成功日志：包含单位ID、地形位置、是否奇迹生成，方便调试
                //string miracleLog = tMiracleSpawn ? "【奇迹生成】" : "【普通生成】";
                //Debug.Log($"[单位生成成功] {miracleLog} 单位ID：{tID}，生成位置：({tTile.pos.x}, {tTile.pos.y})");

                // 生成特效（已注释，如需启用可删除//）
                // EffectsLibrary.spawn("fx_spawn", tTile, null, null, 0f, -1f, -1f, null);
            }
            else
            {
                // ❌ 生成失败日志：地形为空
                //Debug.LogWarning($"[单位生成失败] 原因：山地地形列表为空，无法获取生成位置（本次尝试生成的单位ID：{tID}）");
            }
        }
        #endregion

                #region 大道争锋机制 (Great Contest)
            // 大道争锋事件状态
            public static bool IsGreatContestActive = false;
            public static int GreatContestStartYear = 0;
            public static List<Actor> GreatContestants = new List<Actor>();
            public static City GreatContestArenaCity = null;
            private static int _lastGreatContestYear = -960; // 初始值，确保第一次事件可以在第0年触发

            // 大道争锋事件常量
            private const int GREAT_CONTEST_INTERVAL = 480; // 每500年一次
            private const int GREAT_CONTEST_DURATION = 10;  // 持续10年
            private const int MIN_CONTESTANTS = 5;          // 最小参赛人数
            private const int MAX_CONTESTANTS = 10;         // 最大参赛人数
            private const int FINAL_SURVIVORS = 3;          // 剩余3人时结束

            // 新增：帧检测间隔常量（每15帧执行一次）
            private const int MADNESS_CHECK_FRAME_INTERVAL = 15;


            // 独特称号列表
            private static readonly string[] UniqueTitles = new string[]
            {
                "道主"
            };




            /// <summary>
            /// 检查并触发大道争锋事件
            /// </summary>
            public static void CheckGreatContest()
            {
                if (World.world == null) return;
                
                int currentYear = (int)(World.world.getCurWorldTime() / 60) + 1;
                
                // 检查是否达到500年间隔且事件未进行中
                if (!IsGreatContestActive && currentYear >= _lastGreatContestYear + GREAT_CONTEST_INTERVAL)
                {
                    StartGreatContest(currentYear);
                }
                
                // 如果事件正在进行中，检查是否应该结束
                if (IsGreatContestActive)
                {
                    CheckGreatContestProgress(currentYear);
                }
            }

            /// <summary>
            /// 开始大道争锋事件
            /// </summary>
            private static void StartGreatContest(int currentYear)
            {
                try
                {
                    // 获取符合条件的参赛者（按战力排序）
                    var potentialContestants = World.world.units
                        .Where(actor => actor != null && 
                                    actor.hasHealth() && 
                                    !actor.name.StartsWith("[死亡]-") &&
                                    CalculatePower(actor) > 10000) // 战力门槛
                        .OrderByDescending(actor => CalculatePower(actor))
                        .Take(MAX_CONTESTANTS)
                        .ToList();
                    
                    // 检查是否达到最小参赛人数
                    if (potentialContestants.Count < MIN_CONTESTANTS)
                    {
                        Debug.Log($"大道争锋事件取消：符合条件的参赛者不足（需要{MIN_CONTESTANTS}，仅有{potentialContestants.Count}）");
                        _lastGreatContestYear = currentYear - (currentYear % GREAT_CONTEST_INTERVAL);
                        return;
                    }
                    
                    // 随机选择一座城市作为竞技场
                    var cities = World.world.cities.Where(c => c != null && c.zones.Any()).ToList();
                    if (!cities.Any())
                    {
                        Debug.Log("大道争锋事件取消：没有合适的城市作为竞技场");
                        return;
                    }
                    
                    GreatContestArenaCity = cities[UnityEngine.Random.Range(0, cities.Count)];
                    var arenaZone = GreatContestArenaCity.zones.ToArray().GetRandom<TileZone>();
                    var arenaTile = arenaZone.tiles.ToArray().GetRandom<WorldTile>();
                    
                    // 设置事件状态
                    IsGreatContestActive = true;
                    GreatContestStartYear = currentYear;
                    GreatContestants = potentialContestants.Take(Mathf.Min(potentialContestants.Count, MAX_CONTESTANTS)).ToList();
                    _lastGreatContestYear = currentYear - (currentYear % GREAT_CONTEST_INTERVAL);
                    
                    // 计算这是第几次大道争锋
                    int contestNumber = (currentYear / GREAT_CONTEST_INTERVAL) + 1;
                    
                    // 生成史诗般的开始描述
                    string contestStartLog = $"\n【第{contestNumber}次大道争锋 - 世界历{currentYear}年】\n";
                    contestStartLog += $"天地异变，灵气汇聚！{GreatContestArenaCity.name}上空浮现神秘符文，\n";
                    contestStartLog += $"吸引世间{GreatContestants.Count}位顶尖强者前来争夺无上大道！\n\n";
                    
                    contestStartLog += $"【竞技场】：{GreatContestArenaCity.name}\n";
                    contestStartLog += $"【参赛强者】：{GreatContestants.Count}人\n";
                    contestStartLog += $"【持续时间】：{GREAT_CONTEST_DURATION}年\n\n";
                    
                    contestStartLog += "【参赛者名单】（按战力排序）：\n";
                    
                    // 列出所有参赛者，按战力排序
                    var sortedContestants = GreatContestants.OrderByDescending(c => CalculatePower(c)).ToList();
                    for (int i = 0; i < sortedContestants.Count; i++)
                    {
                        var contestant = sortedContestants[i];
                        string kingdom = contestant.kingdom?.name ?? "无阵营";
                        contestStartLog += $"{i + 1}. {contestant.name}({kingdom}) - {CalculatePower(contestant)}战力\n";
                    }
                    
                    contestStartLog += "=".Repeat(50) + "\n\n";

                // 输出日志到调试窗口
                Debug.Log(contestStartLog);
                // 写入文件
                WriteLeaderboardToFile(contestStartLog);
                    
                    // 传送所有参赛者并添加疯狂特质
                    foreach (var contestant in GreatContestants)
                    {
                        try
                        {
                            ActionLibrary.teleportEffect(contestant, arenaTile);
                            contestant.cancelAllBeh();
                            contestant.setCurrentTilePosition(arenaTile);
                            
                            // 先移除可能抵抗疯狂的特质
                            if (contestant.hasTrait("strong_minded"))
                            {
                                contestant.removeTrait("strong_minded");
                            }
                            
                            // 移除其他可能抵抗疯狂的特质
                            if (contestant.hasTrait("peaceful") || contestant.hasTrait("pacifist"))
                            {
                                contestant.removeTrait("peaceful");
                                contestant.removeTrait("pacifist");
                            }
                            
                            // 确保单位处于战斗状态
                            contestant.addTrait("aggressive");
                            contestant.addTrait("bloodlust");
                            
                            // 最后添加疯狂特质
                            contestant.addTrait("madness");
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"设置参赛者 {contestant.name} 时出错: {ex.Message}");
                        }
                    }
                    
                    // 显示通知
                    string notificationText = $"<color=#FFD700>【第{contestNumber}次大道争锋开启】</color>\n" +
                                            $"<color=#FFFFFF>世界历{currentYear}年，{GreatContestants.Count}名强者</color>\n" +
                                            $"<color=#FFCC00>汇聚于{GreatContestArenaCity.name}，争夺无上大道！</color>";
                    NotificationHelper.ShowThisMessage(notificationText);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"大道争锋事件启动失败: {ex.Message}");
                    IsGreatContestActive = false;
                }
            }
            private static int _lastReportedSurvivorCount = -1;
            /// <summary>
            /// 检查大道争锋事件进度
            /// </summary>
            private static void CheckGreatContestProgress(int currentYear)
            {
                try
                {
                    // 检查持续时间是否结束
                    if (currentYear >= GreatContestStartYear + GREAT_CONTEST_DURATION)
                    {
                        EndGreatContest("时间结束");
                        return;
                    }
                    
                    // 更安全的存活参赛者检查
                    var survivors = new List<Actor>();
                    foreach (var contestant in GreatContestants)
                    {
                        try
                        {
                            // 空值检查
                            if (contestant != null && !contestant.isRekt() && contestant.hasHealth())
                            {
                                survivors.Add(contestant);
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"检查参赛者状态时出错: {ex.Message}");
                        }
                    }
                    
                    // 只有当幸存者数量变化时才记录
                    if (survivors.Count != _lastReportedSurvivorCount)
                    {
                        // 记录中途情况
                        if (survivors.Count <= GreatContestants.Count / 2 && survivors.Count > FINAL_SURVIVORS)
                        {
                            string progressLog = $"[世界历{currentYear}年] 大道争锋过半，剩余{survivors.Count}人\n";
                            WriteLeaderboardToFile(progressLog);
                        }
                        
                        _lastReportedSurvivorCount = survivors.Count; // 更新最后报告的幸存者数量
                    }
                    
                    // 检查是否达到结束条件
                    if (survivors.Count <= FINAL_SURVIVORS)
                    {
                        EndGreatContest($"剩余{survivors.Count}人");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"检查大道争锋事件进度时出错: {ex.Message}");
                    // 如果出现严重错误，强制结束事件
                    EndGreatContest("系统错误");
                }
            }

            /// <summary>
            /// 结束大道争锋事件
            /// </summary>
                    private static void EndGreatContest(string reason)
        {
            try
            {
                int currentYear = (int)(World.world.getCurWorldTime() / 60) + 1;
                
                // 计算这是第几次大道争锋
                int contestNumber = (currentYear / GREAT_CONTEST_INTERVAL) + 1;
                
                // 安全的存活参赛者检查
                var survivors = new List<Actor>();
                foreach (var contestant in GreatContestants)
                {
                    try
                    {
                        if (contestant != null && !contestant.isRekt() && contestant.hasHealth())
                        {
                            survivors.Add(contestant);
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning($"检查参赛者状态时出错: {ex.Message}");
                    }
                }
                
                // 移除疯狂特质
                foreach (var contestant in GreatContestants)
                {
                    if (contestant != null && contestant.hasTrait("madness"))
                    {
                        contestant.removeTrait("madness");
                    }
                }
                
                // 记录事件结果 - 使用更史诗的描述
                string eventEndLog = $"\n【第{contestNumber}次大道争锋终结 - 世界历{currentYear}年】\n";
                
                if (survivors.Any())
                {
                    eventEndLog += $"经过{GREAT_CONTEST_DURATION}年的激烈争夺，大道争锋终于落下帷幕！\n";
                    eventEndLog += $"最终，{survivors.Count}位强者从血战中幸存，见证了新时代的开启！\n\n";
                }
                else
                {
                    eventEndLog += $"经过{GREAT_CONTEST_DURATION}年的惨烈厮杀，大道争锋以无人幸存告终！\n";
                    eventEndLog += $"天地同悲，大道空悬，等待下一个轮回的强者崛起！\n\n";
                }
                
                eventEndLog += $"终结原因：{reason}\n";
                eventEndLog += $"最终幸存者：{survivors.Count}人\n";
                
                if (survivors.Any())
                {
                    // 按战力排序幸存者
                    var sortedSurvivors = survivors.OrderByDescending(s => CalculatePower(s)).ToList();
                    var champion = sortedSurvivors.First();
                    
                    // 为冠军选择一个独特称号
                    string uniqueTitle = GetUniqueTitleForChampion(champion, currentYear);
                    
                    eventEndLog += "【最终幸存者名单】：\n";
                    for (int i = 0; i < sortedSurvivors.Count; i++)
                    {
                        var survivor = sortedSurvivors[i];
                        string kingdom = survivor.kingdom?.name ?? "无阵营";
                        string titleMark = (i == 0) ? $"【{uniqueTitle}】" : "";
                        eventEndLog += $"{i + 1}. {titleMark}{survivor.name}({kingdom}) - {CalculatePower(survivor)}战力\n";
                    }
                    
                    eventEndLog += $"\n<color=#FFD700>【大道得主】</color> {champion.name} 力压群雄，获得了「{uniqueTitle}」的无上称号！\n";
                    eventEndLog += $"天地共鸣，万物臣服，新的传奇已然诞生！\n";
                    //ActionLibrary.turnIntoDemon(champion, null);（变恶魔，已禁用）
                }
                else
                {
                    eventEndLog += "无人生还，大道空悬，等待下一个时代的强者！\n";
                }
                
                eventEndLog += "=".Repeat(60) + "\n\n";
                
                Debug.Log(eventEndLog);
                WriteLeaderboardToFile(eventEndLog);
                
                // 显示通知
                string resultText = survivors.Any() ? 
                    $"<color=#FFD700>【第{contestNumber}次大道争锋终结】</color>\n<color=#FFFFFF>{survivors.Count}名强者幸存</color>\n<color=#AAAAAA>世界历{currentYear}年</color>" :
                    $"<color=#FF6666>【第{contestNumber}次大道争锋终结】</color>\n<color=#FFFFFF>无人生还，大道空悬！</color>\n<color=#AAAAAA>世界历{currentYear}年</color>";
                
                NotificationHelper.ShowThisMessage(resultText);
            }
            catch (Exception ex)
            {
                Debug.LogError($"大道争锋事件结束处理失败: {ex.Message}");
            }
            finally
            {
                // 重置事件状态
                IsGreatContestActive = false;
                GreatContestants.Clear();
                GreatContestArenaCity = null;
            }
        }

            /// <summary>
            /// 为冠军获取独特称号
            /// </summary>
            private static string GetUniqueTitleForChampion(Actor champion, int currentYear)
            {
                try
                {
                    // 基于冠军的属性和当前年份生成一个确定性但随机的称号
                    int seed = (int)(champion.data.id + currentYear + CalculatePower(champion));
                    System.Random random = new System.Random(seed);
                    
                    // 从称号列表中随机选择一个
                    string title = UniqueTitles[random.Next(UniqueTitles.Length)];
                    
                    return title;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"生成独特称号时出错: {ex.Message}");
                    return "道主"; // 默认称号
                }
            }
        #endregion

        #region   大道争锋期间自动保持疯狂

        /// <summary>
        /// 检查大道争锋事件进度（判断是否结束、统计幸存者）
        /// </summary>
       

        /// <summary>
        /// 每15帧强制同步所有参赛者的疯狂状态（约0.5秒/次，按30帧/秒计算）
        /// - 基于帧计数控制频率，平衡实时性与性能
        /// - 移除"坚定意志"，补全"疯狂"，确保状态稳定
        /// </summary>
        private static void EnforceContestantMadness()
        {
            // 1. 第一层过滤：事件未活跃/无参赛者/世界为空时，直接返回
            if (!IsGreatContestActive || World.world == null || GreatContestants == null || GreatContestants.Count == 0)
                return;

            // 2. 帧间隔控制：仅当当前帧号能被15整除时，执行检测（核心逻辑）
            // Time.frameCount：Unity内置帧计数器，每帧自动+1（从0开始）
            if (Time.frameCount % MADNESS_CHECK_FRAME_INTERVAL != 0)
                return;

            // 3. 遍历参赛者，同步状态（逻辑与之前一致，仅执行频率变化）
            foreach (var contestant in GreatContestants)
            {
                try
                {
                    // 3.1 防空+防死亡：跳过无效参赛者
                    if (contestant == null || contestant.isRekt() || !contestant.hasHealth())
                        continue;

                    // 3.2 强制移除"坚定意志"（若存在）
                    if (contestant.hasTrait("strong_minded"))
                    {
                        contestant.removeTrait("strong_minded");
                        // 可选：调试日志（发布时删除，避免刷屏）
                        // Debug.Log($"[每15帧检测] {contestant.name} 移除坚定意志");
                    }

                    // 3.3 强制添加"疯狂"（若不存在）
                    if (!contestant.hasTrait("madness"))
                    {
                        contestant.addTrait("madness");
                        // 可选：调试日志（发布时删除）
                        // Debug.Log($"[每15帧检测] {contestant.name} 补全疯狂特质");
                    }
                }
                catch (Exception ex)
                {
                    // 3.4 异常隔离：单个选手出错不影响全局
                    //Debug.LogWarning($"[每15帧检测] 处理{contestant?.name ?? "未知选手"}失败：{ex.Message}");
                }
            }

            // 可选：记录检测帧号（调试用）
            // Debug.Log($"[每15帧检测] 执行完成，当前帧号：{Time.frameCount}");
        }
        #endregion


    }
}
