﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using DemonGameRules2.code;
using System.Collections.Concurrent;

namespace DemonGameRules.code
{
    internal class patch
    {
        // 静态字典声明（移至顶部，确保使用前已声明）
        private static ConcurrentDictionary<long, int> baseDamage = new ConcurrentDictionary<long, int>();
        private static ConcurrentDictionary<long, int> baseHealth = new ConcurrentDictionary<long, int>();
        private static HashSet<string> deadUnitsByBaseName = new HashSet<string>(); // 统一为HashSet，解决命名冲突
        private static readonly System.Random systemRandom = new System.Random(); // 明确使用System.Random并修改变量名避免混淆

        #region 1. MapBox.Start() 补丁 - 初始化+清空字典
        [HarmonyPostfix]
        [HarmonyPatch(typeof(MapBox), "Start")]
        public static void MapBox_Start_Postfix()
        {
            Debug.Log("[排行榜补丁] 已挂载到MapBox.Start()");

            if (traitAction.killLeaderboard == null)
            {
                traitAction.killLeaderboard = new List<KeyValuePair<string, int>>();
                Debug.Log("[排行榜补丁] 初始化空排行榜列表");
            }

            // 清理所有静态数据，确保每局游戏重新计算
            deadUnitsByBaseName.Clear();
            baseDamage.Clear();
            baseHealth.Clear();
        }
        #endregion


        //#region  开局随机生成
        //[HarmonyPostfix]
        //[HarmonyPatch(typeof(MapBox), "finishMakingWorld")]
        //public static void MapBox_finishMakingWorld_Postfix()
        //{
        //    Debug.Log("世界完成生成，开始随机生成10组单位");
        //    Debug.Log("World generation completed, starting to randomly spawn 10 groups of units");

        //    for (int i = 0; i < 10; i++)
        //    {
        //        traitAction.SpawnRandomUnit();
        //    }
        //}
        //#endregion


            #region 2. MapBox.Update() 补丁 - 控制排行榜显示间隔
        [HarmonyPostfix]
        [HarmonyPatch(typeof(MapBox), "Update")]
        public static void MapBox_Update_Postfix()
        {
            if (Config.game_loaded && !SmoothLoader.isLoading())
            {
                traitAction.UpdateLeaderboardTimer();
            }
        }
        #endregion



        #region 3. Actor.updateStats 补丁 - 差值更新版
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "updateStats")]
        public static void Actor_UpdateStats_Postfix(Actor __instance)
        {
            if (__instance == null || __instance.data == null || __instance.data.id <= 0 || __instance.stats == null || !Config.game_loaded || SmoothLoader.isLoading())
                return;

            // 只处理击杀数大于10的单位，小于等于10的直接返回
            if (__instance.data.kills <= 9)
                return;

            try
            {
                long unitId = __instance.data.id;
                int kills = __instance.data.kills;

                BaseStats stats = __instance.stats;

                //// 记录基础属性 - 添加显式类型转换
                //if (!baseDamage.TryGetValue(unitId, out int baseDmg))
                //{
                //    baseDmg = (int)stats["damage"]; // 明确转换float为int
                //    baseDamage[unitId] = baseDmg;
                //}

                if (!baseHealth.TryGetValue(unitId, out int baseHp))
                {
                    baseHp = (int)stats["health"]; // 明确转换float为int
                    baseHealth[unitId] = baseHp;
                }

                // 重新计算属性（显式转换为float）
                //stats["damage"] = (float)(baseDmg + kills * 10);
                stats["health"] = (float)(baseHp + kills * 100);

                // 同步生命值 - 仅修改计算方式为按比例恢复
                if (__instance.hasHealth() && __instance.getHealth() > 100 && !__instance.isFighting()) // ✅ 新增战斗检查
                {
                    int oldMax = __instance.getMaxHealth();
                    int curHp = __instance.getHealth();

                    // 记录加成前的生命值比例
                    float healthRatio = oldMax > 0 ? (float)curHp / oldMax : 1f;

                    __instance.setMaxHealth();
                    int newMax = __instance.getMaxHealth();

                    // 按原比例计算新生命值
                    int newHp = (int)Math.Round(healthRatio * newMax);
                    newHp = Math.Min(newHp, newMax); // 确保不超过新最大值

                    int restoreAmount = newHp - curHp;
                    if (restoreAmount > 0)
                        __instance.restoreHealth(restoreAmount);
                }
            }
            catch (Exception ex)
            {
                // 保留原有单位名称获取逻辑
                Debug.LogWarning($"[击杀数属性加成] 处理单位 {__instance?.data?.name}（ID：{__instance?.data?.id}）失败: {ex.Message}");
            }
        }
        #endregion


        #region 4. 单位死亡时清理属性字典（新增补丁）
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "checkCallbacksOnDeath")]
        public static void Actor_CheckCallbacksOnDeath_Postfix(Actor __instance)
        {
            if (__instance != null && __instance.data != null && __instance.data.id > 0)
            {
                long unitId = __instance.data.id;
                // 移除死亡单位的基础属性记录，避免内存泄漏
                baseDamage.TryRemove(unitId, out _);
                baseHealth.TryRemove(unitId, out _);
            }
        }
        #endregion

        #region 5. 击杀奖励（原有逻辑保留）
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance, Actor pDeadUnit)
        {
            try
            {
                if (!__instance.isAlive())
                    return;

                if (__instance.hasTrait("bloodlust"))
                {
                    __instance.changeHappiness("just_killed", 1);
                }

                if (__instance.data != null && __instance.data.kills > 100 && !__instance.data.favorite)
                {
                    __instance.data.favorite = true;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[击杀奖励异常] {__instance?.data?.name} 错误: {ex.Message}");
            }
        }
        #endregion

        #region 6. 恶魔防御（原有逻辑保留）
        // 一般情况暴毙免疫
        private static bool _isProcessingThorns = false;
        private static bool _isProcessingBlock = false;
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), "getHit")]
        public static bool Actor_getHit_Prefix(
            Actor __instance,
            ref float pDamage,
            AttackType pAttackType,
            BaseSimObject pAttacker)
        {
            // 如果正在处理拦截伤害，直接返回
            if (_isProcessingBlock) return true;

            // 要拦截的所有伤害类型（直接 100% 拦截）
            AttackType[] blockedAttackTypes = new AttackType[]
            {
                AttackType.Poison,     // 中毒攻击
                AttackType.Weapon,     // 武器攻击
                AttackType.Eaten,      // 被吞噬攻击
                AttackType.Plague,     // 瘟疫攻击
                AttackType.Explosion,  // 爆炸攻击
                AttackType.Infection,  // 感染攻击
                AttackType.Tumor,      // 肿瘤攻击
                AttackType.Water,      // 水属性攻击
                AttackType.Drowning,   // 溺水攻击
                AttackType.Fire,       // 火焰攻击
                AttackType.Acid        // 酸液攻击
            };

            // 获取击杀数
            int victimKills = __instance.data?.kills ?? 0;
            bool isHighKill = victimKills > 30;

            // 如果具备特质、击杀数>30、并且当前伤害类型在拦截列表中，且没有攻击者，则 100% 拦截
            if (isHighKill && blockedAttackTypes.Contains(pAttackType) && pAttacker == null)
            {
                try
                {
                    _isProcessingBlock = true;
                    return false; // 直接拦截，不执行原方法
                }
                finally
                {
                    _isProcessingBlock = false;
                }
            }

            // 新增：在受到攻击时触发恶魔防御
            if (pAttacker != null && !_isProcessingThorns)
            {
                try
                {
                    _isProcessingThorns = true;
                    // 直接调用恶魔防御逻辑
                    traitAction.ExecuteDamageExchange(__instance, pAttacker);
                }
                finally
                {
                    _isProcessingThorns = false;
                }
            }

            return true; // 否则允许伤害
        }
        #endregion

        #region 7. 移速限制（原有逻辑保留）
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), "updateMovement")]
        public static bool Actor_updateMovement_Prefix(Actor __instance, ref float pElapsed)
        {
            try
            {
                float currentSpeed = __instance.stats["speed"];
                if (currentSpeed > 50.0f)
                {
                    float speedRatio = 50.0f / currentSpeed;
                    pElapsed *= speedRatio;
                }
                return true;
            }
            catch (Exception ex)
            {
                return true;
            }
        }
        #endregion

        #region 8. 强制激活脑部特质逻辑
        [HarmonyPostfix, HarmonyPatch(typeof(Subspecies), "newSpecies")]
        public static void Subspecies_newSpecies_Postfix(Subspecies __instance)
        {
            // 直接移除所有指定的变形/重生特质
            string[] traitsToRemove = new string[]
            {
                "fire_elemental_form", "fenix_born", "metamorphosis_crab",
                "metamorphosis_chicken", "metamorphosis_wolf", "metamorphosis_butterfly",
                "death_grow_tree", "death_grow_plant", "death_grow_mythril", "metamorphosis_sword"
            };

            foreach (string trait in traitsToRemove)
            {
                if (__instance.hasTrait(trait))
                {
                    __instance.removeTrait(trait);
                }
            }

            // 核心脑部特质
            string[] coreTraits = new string[]
            {
                "amygdala", "advanced_hippocampus", "prefrontal_cortex", "wernicke_area"
            };

            // 完整属性组
            string[] fullTraitGroup = new string[]
            {
                "high_fecundity", "long_lifespan"
            };

            // 检查是否已有前额叶皮层特质
            if (__instance.hasTrait("prefrontal_cortex"))
            {
                // 补齐所有核心脑部特质并添加完整属性组
                foreach (string coreTrait in coreTraits)
                {
                    if (!__instance.hasTrait(coreTrait))
                        __instance.addTrait(coreTrait, true);
                }

                foreach (string trait in fullTraitGroup)
                {
                    __instance.addTrait(trait, true);
                }
            }
            else
            {
                // 随机判定（使用明确的System.Random实例）
                double roll = systemRandom.NextDouble(); // 使用重命名后的随机实例

                if (roll < 0.90)
                {
                    // 90% 概率：仅添加population_minimal特质
                    __instance.addTrait("population_minimal", true);
                }
                else
                {
                    // 10% 概率：尝试添加四个核心脑部特质
                    bool cortexAdded = false;
                    __instance.addTrait("population_minimal", true);
                    foreach (string coreTrait in coreTraits)
                    {
                        if (!__instance.hasTrait(coreTrait))
                        {
                            __instance.addTrait(coreTrait, true);
                            if (coreTrait == "prefrontal_cortex" && __instance.hasTrait("prefrontal_cortex"))
                            {
                                cortexAdded = true;
                            }
                        }
                    }

                    if (cortexAdded)
                    {
                        // 成功添加前额叶皮层，添加完整属性组
                        //__instance.addTrait("population_moderate", true);
                        foreach (string trait in fullTraitGroup)
                        {
                            __instance.addTrait(trait, true);
                        }
                    }
                    else
                    {
                        // 添加失败，退回到population_minimal
                        __instance.addTrait("population_minimal", true);
                    }
                }
            }
        }
        #endregion

        #region 9. 年龄机制
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void Actor_UpdateAge_Postfix(Actor __instance) // 修正方法名，更贴合实际功能
        {
            if (__instance == null || !__instance.hasHealth())
                return;

            float currentAge = (float)__instance.getAge();


            if (__instance.data.kills > 100 && !__instance.data.favorite)
            {
                __instance.data.favorite = true;
            }

            // 2岁以下逻辑
            if (currentAge <= 2f)
            {
                if (__instance.hasTrait("super_health"))
                {
                    __instance.removeTrait("super_health");
                }

                if (!__instance.hasTrait("fertile"))
                {
                    __instance.addTrait("fertile");
                }
            }

            // 50-51岁添加特质
            if (currentAge >= 50f && currentAge <= 51f && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                string[] traitsToAdd = new string[] {
                    "savage", "paranoid","bloodlust","fertile",
                    "evil", "thorns", "greedy", "deceitful"
                };

                foreach (string trait in traitsToAdd)
                {
                    if (!__instance.hasTrait(trait))
                    {
                        __instance.addTrait(trait);
                    }
                }

                // 清除负面状态和特质
                __instance.finishStatusEffect("cursed");
                __instance.removeTrait("infected");
                __instance.removeTrait("mush_spores");
                __instance.removeTrait("tumor_infection");
                __instance.removeTrait("peaceful");
                __instance.removeTrait("super_health");
                __instance.removeTrait("pacifist");
                __instance.removeTrait("content");
                __instance.removeTrait("honest");
                __instance.removeTrait("healing_aura");
                __instance.removeTrait("miracle_born");
                __instance.removeTrait("chosen_one");
                __instance.removeTrait("flesh_eater");
                __instance.removeTrait("regeneration");
            }

        }
        #endregion

        #region 10. 死亡日志与排行榜逻辑
        private static float normalKillLogTimer = 0f;  // 时间窗口计时器
        private static int normalKillLogCount = 0;     // 时间窗口内日志计数
        
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "checkDeath")]
        public static void Actor_checkDeath_Postfix(Actor __instance)
        {
            // 攻击者检测
            Actor attacker = null;
            AttackType deathCause = AttackType.None;
            if (!__instance.attackedBy.isRekt() && __instance.attackedBy.isActor() && __instance.attackedBy != __instance)
            {
                attacker = __instance.attackedBy.a;
                deathCause = __instance._last_attack_type;
            }



            // 受害者阵营信息
            Kingdom tPrevKingdom = __instance.kingdom;
            string victimKingdom = tPrevKingdom?.name ?? "无阵营/No faction";

            // 受害者基础信息
            string victimName = __instance.name;
            int victimKills = __instance.data?.kills ?? 0;
            int victimMaxHealth = __instance.getMaxHealth();

            // 攻击者信息
            int attackerCurrentHealth = 0;
            int attackerMaxHealth = 0;
            int attackerKills = 0;
            string attackerKingdom = "无阵营/No faction";

            if (attacker != null)
            {
                attackerCurrentHealth = attacker.getHealth();
                attackerMaxHealth = attacker.getMaxHealth();
                attackerKills = attacker.data?.kills ?? 0;
                attackerKingdom = attacker.kingdom?.name ?? "无阵营/No faction";
            }

            // 检查单位是否存活
            bool IsUnitAlive(string unitEntry)
            {
                return !unitEntry.StartsWith("[死亡]-");
            }

            // 更新排行榜数据
            void UpdateLeaderboard(string name, string kingdom, int kills)
            {
                
                if (kills <= 5) return;

                string targetBaseName = traitAction.GetBaseName(name);
                // 处理死亡前缀
                bool isDead = name.StartsWith("[死亡]-");
                string cleanName = traitAction.TrimDeathPrefix(name);
                string displayName = isDead ? $"[死亡]-{cleanName}({kingdom})" : $"{cleanName}({kingdom})";

                // 移除同基础名的旧条目
                traitAction.killLeaderboard.RemoveAll(entry =>
                    traitAction.GetBaseName(entry.Key.Split('(')[0]) == targetBaseName
                );

                // 添加新条目并确保存活单位优先
                traitAction.killLeaderboard.Add(new KeyValuePair<string, int>(displayName, kills));
                
            }

            // 高击杀单位（史诗击杀）逻辑
            bool isHighKillVictim = victimKills > 30 &&
                                   __instance.data != null &&
                                   !__instance.hasHealth() &&
                                   !__instance.name.StartsWith("[死亡]-");

            if (isHighKillVictim)
            {
                string originalName = __instance.name;
                string originalKingdom = victimKingdom;

                // 添加死亡前缀
                __instance.data.setName("[死亡]-" + originalName);
                victimName = __instance.name;

                // 更新排行榜
                traitAction.killLeaderboard.RemoveAll(x =>
                    traitAction.GetBaseName(x.Key.Split('(')[0]) == traitAction.GetBaseName(originalName));
                UpdateLeaderboard(__instance.name, originalKingdom, victimKills);

                // 计算奖励击杀数
                int bonusKills = victimKills / 2;
                int attackerKillsAfterBonus = attacker?.data?.kills ?? 0;
                if (attacker != null && attacker.data != null)
                {
                    attackerKillsAfterBonus = attacker.data.kills + bonusKills;
                }

                // 清理无效的排行榜条目
                if (traitAction.killLeaderboard.Count > 0)
                {
                    var leaderboardCopy = new List<KeyValuePair<string, int>>(traitAction.killLeaderboard);
                    foreach (var entry in leaderboardCopy)
                    {
                        int entryIndex = traitAction.killLeaderboard.IndexOf(entry);
                        if (entryIndex < 0 || entryIndex >= 3)
                            continue;

                        string rawName = entry.Key;
                        if (rawName.StartsWith("[死亡]-"))
                            continue;

                        string nameWithoutDeathTag = rawName.StartsWith("[死亡]-") ? rawName.Substring("[死亡]-".Length) : rawName;
                        string nameWithoutKingdom = nameWithoutDeathTag.Split('(')[0].Trim();
                        string entryBaseName = traitAction.GetBaseName(nameWithoutKingdom);

                        bool exists = World.world.units.Any(actor =>
                            actor != null && actor.hasHealth() && traitAction.GetBaseName(actor.name) == entryBaseName
                        );

                        if (!exists)
                        {
                            traitAction.killLeaderboard.Remove(entry);
                            Debug.Log($"<color=#FF9900>【排行榜清理】</color> 移除不存在的存活单位：{rawName}");
                            Debug.Log($"<color=#FF9900>[Ranking List Cleanup]</color> Removing non-existent surviving unit: {rawName}");
                        }
                    }
                    
                }

                // 显示史诗击杀通知
                string showMessage = $"<color=#FFFF00>{attacker?.data?.name ?? "环境Env"}</color>(<color=white>({attackerKills}→{attackerKillsAfterBonus})</color>)" +
                                     $"→→→" +
                                     $"<color=#FFFF00>{victimName}</color>(<color=white>--({victimKills})</color>)\n" +
                                     $"<color=#FF9900>[☠↔☠] +{bonusKills}</color>";

                NotificationHelper.ShowThisMessage(showMessage, 30f);

                // 详细调试日志
                string debugLog = $"\n\n<color=#666666>════════════════════════════════════════════════════════════</color>\n" +
                                 $"【<color=#DD5555>◆ ⚔️ ◆</color>】 " +
                                 $"<color={traitAction.GetHealthColor(attackerCurrentHealth, attackerMaxHealth)}>[HP:{attackerCurrentHealth}/{attackerMaxHealth}]</color> " +
                                 $"<color=#FF9999>{attacker?.data?.name ?? "环境Env"}</color>" +
                                 $"<color={traitAction.GetKillColor(attackerKills)}>({attackerKills}→{attackerKillsAfterBonus})</color>" +
                                 $"<color=#CCCCCC>{attackerKingdom}</color>" +
                                 $"<color=#FF7777> →→→→→→→→→→→→→ </color>" +
                                 $"<color={traitAction.GetHealthColor(0, victimMaxHealth)}>[MaxHP:{victimMaxHealth}]</color> " +
                                 $"<color=#FFCC66>{victimName}</color>" +
                                 $"<color={traitAction.GetKillColor(victimKills)}>({victimKills})</color>" +
                                 $"<color=#CCCCCC>{victimKingdom}</color>\n" +
                                 $"<color=#FF9900>[☠↔☠] +{bonusKills}</color>\n" +
                                 $"<color=#AAAAAA>☠ : </color><color=#888888>{traitAction.GetAttackTypeChinese(deathCause)}</color>\n" +
                                 $"<color=#666666>════════════════════════════════════════════════════════════</color>\n\n";

                Debug.Log(debugLog);

                try
                {
                    // 获取世界历年份
                    int worldYear = 1;
                    if (World.world != null)
                    {
                        worldYear = (int)(World.world.getCurWorldTime() / 60) + 1;
                    }
                    
                    
                    string epicKillLog = $"[世界历{worldYear}年] {attacker?.data?.name ?? "环境Env"}({attackerKingdom}) -> {victimName}({victimKingdom}) +{bonusKills}\n";
                    
                    
                    DemonGameRules2.code.traitAction.WriteLeaderboardToFile(epicKillLog);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"保存史诗击杀记录失败: {ex.Message}");
                }


                // 释放死亡单位的称号
                string fullTitleToRelease = traitAction.GetFullTitle(originalName);
                traitAction.ReleaseTitle(fullTitleToRelease);

                // 击杀转移逻辑
                if (attacker != null && attacker.data != null)
                {
                    // 原攻击者存在，直接加击杀数
                    attacker.data.kills += bonusKills;
                    UpdateLeaderboard(attacker.name, attacker.kingdom?.name ?? "无阵营/No faction", attacker.data.kills);
                }
                else if (bonusKills > 0)
                {
                    bool transferred = false;

                    foreach (var unit in World.world.units)
                    {
                        if (unit == null || !unit.hasHealth() || unit.data == null || unit == __instance)
                            continue;

                        if (unit.data.kills > 30)
                        {
                            // 找到第一个高击杀单位就转移
                            unit.data.kills += bonusKills;
                            UpdateLeaderboard(unit.name, unit.kingdom?.name ?? "无阵营/No faction", unit.data.kills);

                            Debug.Log($"<color=#FF6600>【击杀转移】</color> {victimName} 被环境击杀，{bonusKills}击杀数转移给 {unit.name}");
                            Debug.Log($"<color=#FF6600>[Kill Transfer]</color> {victimName} was killed by the environment, {bonusKills} kills transferred to {unit.name}");

                            transferred = true;
                            break; // 找到一个就结束循环
                        }
                    }

                    // 如果没有找到高击杀单位，再找任意存活单位
                    if (!transferred)
                    {
                        foreach (var unit in World.world.units)
                        {
                            if (unit == null || !unit.hasHealth() || unit.data == null || unit == __instance)
                                continue;

                            unit.data.kills += bonusKills;
                            UpdateLeaderboard(unit.name, unit.kingdom?.name ?? "无阵营/No faction", unit.data.kills);

                            Debug.Log($"<color=#FF6600>【击杀转移】</color> {victimName} 被环境击杀，{bonusKills}击杀数转移给 {unit.name}");
                            Debug.Log($"<color=#FF6600>[Kill Transfer]</color> {victimName} was killed by the environment, {bonusKills} kills transferred to {unit.name}");

                            transferred = true;
                            break;
                        }
                    }

                    if (!transferred)
                    {
                        Debug.LogWarning($"【转移失败】无法找到接收击杀数的单位！{victimName} 的 {bonusKills} 击杀数丢失");
                        Debug.LogWarning($"[Transfer Failed] Unable to find a unit to receive the kills! {bonusKills} kills from {victimName} are lost");

                    }
                }

            }
            // 普通击杀日志（高击杀攻击者）
            else if (attacker != null && attacker.data?.kills > 30 && Randy.randomChance(0.1f))
            {
                // 时间窗口控制（每秒最多1条）
                if (Time.time - normalKillLogTimer > 2f)
                {
                    normalKillLogTimer = Time.time;
                    normalKillLogCount = 0;
                }

                if (normalKillLogCount < 1)
                {
                    normalKillLogCount++;


                    

                    int killerKills = attacker.data?.kills ?? 0;
                    string killerKingdom = attacker.kingdom?.name ?? "无阵营/No faction";

                    Debug.Log(
                        $"\n<color=#666666>-----------------------------</color>\n " +
                        $"<color=#FFFFFF>[⚔️]</color> " +
                        $"<color={traitAction.GetHealthColor(attackerCurrentHealth, attackerMaxHealth)}>[HP:{attackerCurrentHealth}/{attackerMaxHealth}]</color> " +
                        $"<color=#FFAAAA>{attacker.data?.name}</color>" +
                        $"<color={traitAction.GetKillColor(killerKills)}>({killerKills})</color>" +
                        $"<color=#BBBBBB>{killerKingdom}</color>" +
                        $"<color=#FF7777> → </color>" +
                        $"<color={traitAction.GetHealthColor(0, victimMaxHealth)}>[MaxHP:{victimMaxHealth}]</color> " +
                        $"<color=#FFCC66>{victimName}</color>" +
                        $"<color={traitAction.GetKillColor(victimKills)}>({victimKills})</color>" +
                        $"<color=#BBBBBB>{victimKingdom}</color>" +
                        $"\n<color=#AAAAAA>☠: </color><color=#888888>{traitAction.GetAttackTypeChinese(deathCause)}</color>"
                    );
                }
            }

            // 更新攻击者排行榜
            if (attacker != null && attacker.data != null && attacker.data.kills > 0)
            {
                UpdateLeaderboard(attacker.name, attacker.kingdom?.name ?? "无阵营/No faction", attacker.data.kills);

                // 高击杀单位获得心智强化
                if (attacker.data.kills > 100 && Randy.randomChance(0.005f))
                {
                    attacker.removeTrait("madness");
                    attacker.addTrait("strong_minded");
                }
            }


            #region 死亡单位标记（确保排行榜条目带死亡前缀）
            if (!__instance.hasHealth() && victimKills > 10) // 只处理击杀数大于10的单位
            {
                string victimBaseName = traitAction.GetBaseName(victimName);
                deadUnitsByBaseName.Add(victimBaseName);

                // 遍历排行榜，补全死亡前缀（只处理匹配 baseName 且未标记死亡的单位）
                for (int i = 0; i < traitAction.killLeaderboard.Count; i++)
                {
                    var entry = traitAction.killLeaderboard[i];
                    string entryName = entry.Key;

                    // 如果已经带死亡前缀就跳过
                    if (entryName.StartsWith("[死亡]-"))
                        continue;

                    string entryBaseName = traitAction.GetBaseName(entryName.Split('(')[0].Trim());

                    if (entryBaseName == victimBaseName)
                    {
                        string cleanName = traitAction.TrimDeathPrefix(entryName); // 使用 TrimDeathPrefix
                        traitAction.killLeaderboard[i] = new KeyValuePair<string, int>($"[死亡]-{cleanName}", entry.Value);
                    }
                }

                // 高击杀单位强制标记死亡
                if (victimKills > 30)
                {
                    // 使用 TrimDeathPrefix 避免重复前缀
                    string originalName = traitAction.TrimDeathPrefix(__instance.name);
                    __instance.data.setName($"[死亡]-{originalName}");
                }

                // 只移除当前单位的 base name
                deadUnitsByBaseName.Remove(victimBaseName);
            }
            #endregion


        }
        #endregion
    }
}
