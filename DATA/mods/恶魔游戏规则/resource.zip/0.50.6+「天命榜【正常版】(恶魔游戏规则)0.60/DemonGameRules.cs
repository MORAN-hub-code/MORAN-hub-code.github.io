﻿using HarmonyLib;
using DemonGameRules.code;
using NeoModLoader.api;

namespace DemonGameRules
{
    internal class DemonGameRulesClass : BasicMod<DemonGameRulesClass>
    {
        public static string id = "worldbox.mod.DemonGameRules";
        protected override void OnModLoad()
        {
            try
            {
                UnityEngine.Debug.Log("Applying Harmony patches...");
                new Harmony(id).PatchAll(typeof(patch));
                UnityEngine.Debug.Log("Harmony patches applied successfully.");
            }
            catch (System.Exception ex)
            {
                UnityEngine.Debug.LogError($"Error during mod loading: {ex.Message}\n{ex.StackTrace}");
            }
        }
    }
}