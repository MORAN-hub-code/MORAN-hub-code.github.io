using System;
using System.Linq;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using DemonGameRules.code;
using DemonGameRules;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using HarmonyLib; // 为 Traverse 反射取字段
using System.Reflection;
using System.Collections;


namespace DemonGameRules2.code
{
    public static partial class traitAction
    {
        // 结构化 DTO，给 UI 用（PlainLogViewerWindow 会优先反射调用这个）
        public class DGR_LeaderboardRow
        {
            public long Id;        // Actor.data.id（点击打开窗口用）
            public string Name;      // 显示用的名字
            public string Extra;     // 右侧说明（战力/击杀/年龄等）
            public string ColorHex;  // 名字颜色（不带#），如 "FFD700"
        }


        // 行数据（用于“名字按钮 + 右侧说明”）
        private class LBRow
        {
            public long Id;
            public string Name;
            public string Extra;
            public string ColorHex;
        }



        // 反射读取工具（放文件底部也行）
        private static long ReadLong(object o, string name)
        {
            if (o == null) return 0;
            var p = o.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (p != null) { var v = p.GetValue(o, null); if (v != null) return Convert.ToInt64(v); }
            var f = o.GetType().GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (f != null) { var v = f.GetValue(o); if (v != null) return Convert.ToInt64(v); }
            return 0;
        }
        private static string ReadString(object o, string name)
        {
            if (o == null) return null;
            var p = o.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (p != null) return p.GetValue(o, null)?.ToString();
            var f = o.GetType().GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (f != null) return f.GetValue(o)?.ToString();
            return null;
        }



        // 提供结构化行：优先战力榜Top10，再加击杀榜Top10（可按需调整数量/顺序）
        public static List<DGR_LeaderboardRow> GetLeaderboardRows()
        {
            var rows = new List<DGR_LeaderboardRow>();
            if (World.world == null) return rows;

            EnsureLivingFirstPlace();
            UpdatePowerLeaderboard();

            var seenIds = new HashSet<long>();
            var seenNames = new HashSet<string>(StringComparer.Ordinal); // id==0 时用名字去重

            // —— 战力榜 ——
            if (powerLeaderboard != null && powerLeaderboard.Count > 0)
            {
                int take = Mathf.Min(powerLeaderboard.Count, 10);
                for (int i = 0; i < take; i++)
                {
                    var e = powerLeaderboard[i];

                    var actor = TryResolveActorByName(e.Key);
                    long id = actor?.data?.id ?? 0;

                    // 显示名：优先用 Actor 的真名；否则用净化后的 e.Key
                    string displayName = actor != null ? (actor.getName() ?? actor.data.name) : NormalizeName(e.Key);
                    string dedupeName = NormalizeName(displayName);

                    // 去重：有 id 用 id，没 id 用名字
                    if (id > 0) { if (!seenIds.Add(id)) continue; }
                    else { if (!seenNames.Add(dedupeName)) continue; }

                    var rankColor = RankColorHex(i);
                    rows.Add(new DGR_LeaderboardRow
                    {
                        Id = id,
                        Name = displayName,
                        Extra = $"战力:{e.Value}  {StripTags(GetUnitAgeInfo(e.Key))}",
                        ColorHex = rankColor
                    });
                }
            }

            // —— 击杀榜 ——
            if (killLeaderboard != null && killLeaderboard.Count > 0)
            {
                int take = Mathf.Min(killLeaderboard.Count, 10);
                for (int i = 0; i < take; i++)
                {
                    var e = killLeaderboard[i];

                    var actor = TryResolveActorByName(e.Key);
                    long id = actor?.data?.id ?? 0;

                    string displayName = actor != null ? (actor.getName() ?? actor.data.name) : NormalizeName(e.Key);
                    string dedupeName = NormalizeName(displayName);

                    if (id > 0) { if (!seenIds.Add(id)) continue; }
                    else { if (!seenNames.Add(dedupeName)) continue; }

                    bool alive = IsUnitAlive(e.Key);
                    var rankColor = alive ? RankColorHex(i) : "AAAAAA";
                    rows.Add(new DGR_LeaderboardRow
                    {
                        Id = id,
                        Name = displayName,
                        Extra = $"击杀:{e.Value}  {StripTags(GetUnitAgeInfo(e.Key))}",
                        ColorHex = rankColor
                    });
                }
            }

            return rows;
        }


        // —— 工具：按名字尽量解析出 Actor（容错：去标签/括号，支持包含关系；存活优先）——
        private static Actor TryResolveActorByName(string name)
        {
            if (string.IsNullOrEmpty(name) || World.world == null) return null;
            var target = NormalizeName(name);
            var list = World.world.units?.getSimpleList();
            if (list != null)
            {
                Actor fallback = null;
                for (int i = 0; i < list.Count; i++)
                {
                    var a = list[i];
                    if (a?.data == null) continue;
                    var n = NormalizeName(a.getName() ?? a.data.name);

                    // 精确匹配或包含匹配都接受（防止 e.Key 带了职业/种族后缀）
                    bool match = string.Equals(n, target, StringComparison.Ordinal)
                              || string.Equals(n, target, StringComparison.OrdinalIgnoreCase)
                              || n.Contains(target) || target.Contains(n);

                    if (match)
                    {
                        if (a.hasHealth()) return a; // 存活优先
                        if (fallback == null) fallback = a;
                    }
                }
                if (fallback != null) return fallback;
            }
            return null;
        }

        // —— 工具：把 <color> 等富文本标签去掉，给 Extra 用 —— 
        private static string StripTags(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return Regex.Replace(s, "<.*?>", "");
        }

        // —— 工具：名次 → 颜色（可与 BuildLeaderboardRichText 的规则保持一致）——
        private static string RankColorHex(int idx)
        {
            if (idx == 0) return "FFD700"; // 金
            if (idx == 1) return "00CED1"; // 青
            if (idx == 2) return "CD7F32"; // 铜
            return "DDDDDD";               // 普通
        }
        // —— 工具：名字“净化”——去富文本、去括号内容（中英文括号）、去换行空白
        private static string NormalizeName(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = StripTags(s);
            s = Regex.Replace(s, @"[（(].*?[）)]", ""); // 去 “（...）” 或 “(...)”
            s = s.Replace("\\n", " ").Replace("\n", " ").Replace("\r", " ");
            return s.Trim();
        }




    }
}

