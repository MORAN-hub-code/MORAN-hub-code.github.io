// PlainLogViewerWindow.cs — 完整替换版（保留富文本排版 + 悬浮小按钮，不挤布局）
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

using NeoModLoader.General;
using NeoModLoader.General.UI.Tab;
using NeoModLoader.General.UI.Window;

using DemonGameRules2.code; // traitAction.BuildLeaderboardRichText()

namespace DemonGameRules.UI
{
    public class PlainLogViewerWindow : MonoBehaviour
    {
        private ScrollWindow _sw;
        private Transform _contentRoot;

        // 正文富文本 + 悬浮按钮层（不参加布局）
        private Text _richText;
        private RectTransform _buttonsOverlay;
        private Font _font;

        private const int MaxTotalChars = 300_000;
        // —— 固定布局：不随窗口缩放 —— 
        private const bool LOCK_LAYOUT = true;
        private const float LOCK_WIDTH = 520f; // 你想写死的文本宽度，自己定（480~560都行）

        // === 点击性能缓存 ===
        private static bool s_noCreatureWindow = false;        // 标记：没有原生单位窗口，之后别再试

        private static MethodInfo s_locationJumpMI = null;     // HistoryHud.locationJump 缓存
        private static bool s_locationJumpLookedUp = false;

        private float _lastTextWidth = -1f;
        private int _lastContentHash = 0;

        public static void CreateAndInit(string windowId, string titleText)
        {
            var sw = WindowCreator.CreateEmptyWindow(windowId, titleText);
            sw.gameObject.SetActive(false);
            sw.transform_scrollRect.gameObject.SetActive(true);

            var winRT = sw.transform as RectTransform;
            if (winRT != null) winRT.sizeDelta = new Vector2(720, 820);

            var comp = sw.transform_content.gameObject.AddComponent<PlainLogViewerWindow>();
            comp._sw = sw;
            comp._contentRoot = sw.transform_content;
        }

        private void Awake()
        {
            _font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            // 不在 Awake 里 BuildUI：此时 _contentRoot 还没被 CreateAndInit 注入
        }

        private void OnEnable()
        {
            ShowLeaderboard();
            if (_richText == null || _buttonsOverlay == null) { BuildUI(); }

        }

        // ===== 官方直选：完全复刻 ActionLibrary.openUnitWindow 的选中部分 =====
        private void SelectWithoutWindow(Actor a)
        {
            if (a == null) return;

            try
            {
                // 直接用官方静态选择器
                SelectedUnit.clear();
                SelectedUnit.select(a);
                // 不需要打开窗口：ScrollWindow.showWindow("unit") 留给你开关控制
            }
            catch
            {

            }
        }



        // 每帧侦测富文本宽度/内容是否变化，自动重建行内小按钮
        private void LateUpdate()
        {
            // 窗口未就绪或不可见就别干活
            if (_richText == null || _buttonsOverlay == null) return;
            if (!gameObject.activeInHierarchy) return;

            float w = _richText.rectTransform.rect.width;
            int hash = _richText.text?.GetHashCode() ?? 0;

            // 锁定布局：仅内容变更才重建；不看宽度
            bool needRebuild = LOCK_LAYOUT
                ? (hash != _lastContentHash)
                : (!Mathf.Approximately(w, _lastTextWidth) || hash != _lastContentHash);

            if (needRebuild)
            {
                Canvas.ForceUpdateCanvases();
                LayoutRebuilder.ForceRebuildLayoutImmediate(_richText.rectTransform);
                RebuildLineButtons(_richText.text);

                _lastTextWidth = w;
                _lastContentHash = hash;
            }

        }


        // ===== 构建根布局（不强行拉伸子项高度）=====
        private void BuildUI()
        {
            if (_contentRoot == null) return; // 防守

            // 1) 外层容器
            var vlg = _contentRoot.gameObject.GetComponent<VerticalLayoutGroup>();
            if (!vlg) vlg = _contentRoot.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.padding = new RectOffset(25, -100, 0, 80);
            vlg.spacing = 6;
            vlg.childControlHeight = false;
            vlg.childControlWidth = false;
            vlg.childForceExpandHeight = false;
            vlg.childForceExpandWidth = false;

            // 2) 富文本
            var rich = _contentRoot.Find("RichText");
            if (!rich)
            {
                var go = new GameObject("RichText", typeof(Text), typeof(ContentSizeFitter), typeof(LayoutElement));
                go.transform.SetParent(_contentRoot, false);
                _richText = go.GetComponent<Text>();
                _richText.supportRichText = true;
                _richText.horizontalOverflow = HorizontalWrapMode.Overflow; // ← 永不自动换行
                _richText.verticalOverflow = VerticalWrapMode.Overflow;
                _richText.alignment = TextAnchor.UpperLeft;
                _richText.color = Color.white;
                _richText.raycastTarget = false;
                _richText.fontSize = 9;
                _richText.lineSpacing = 1f;
                if (_font) _richText.font = _font;






                var fit = go.GetComponent<ContentSizeFitter>();
                fit.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
                fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

                var le = go.GetComponent<LayoutElement>();
                le.flexibleWidth = 0;             // 不让父布局横向拉伸
                le.preferredWidth = LOCK_WIDTH;    // 锁定宽度
            }
            else _richText = rich.GetComponent<Text>();

            // —— 3) 按钮覆盖层 —— 先创建，再做后续处理
            var overlay = _richText ? _richText.rectTransform.Find("ButtonsOverlay") : null;
            if (!overlay)
            {
                var ogo = new GameObject("ButtonsOverlay", typeof(RectTransform));
                ogo.transform.SetParent(_richText.rectTransform, false);
                _buttonsOverlay = ogo.GetComponent<RectTransform>();
            }
            else
            {
                _buttonsOverlay = overlay.GetComponent<RectTransform>();
                if (_buttonsOverlay.parent != _richText.rectTransform)
                    _buttonsOverlay.SetParent(_richText.rectTransform, false);
            }

            // 现在“它已经存在了”，再去关遮罩、置顶，不会再 NRE
            var mgText = _richText.GetComponent<MaskableGraphic>();
            if (mgText) mgText.maskable = false;

            if (_buttonsOverlay)               // ← 关键守卫
            {
                foreach (var g in _buttonsOverlay.GetComponentsInChildren<MaskableGraphic>(true))
                    g.maskable = false;
                _buttonsOverlay.SetAsLastSibling();
            }

            var sr = _sw.transform_scrollRect ? _sw.transform_scrollRect.GetComponent<ScrollRect>() : null;
            if (sr && sr.viewport)
            {
                var rm = sr.viewport.GetComponent<RectMask2D>();
                var m = sr.viewport.GetComponent<Mask>();
                if (rm) rm.enabled = false;
                if (m) m.enabled = false;

                // ← 新增：把用来做遮罩的白底图也关掉可视/点击
                var vpImg = sr.viewport.GetComponent<Image>();
                if (vpImg)
                {
                    vpImg.color = new Color(1f, 1f, 1f, 0f); // 完全透明
                    vpImg.raycastTarget = false;             // 别挡交互
                                                             // 或者直接 vpImg.enabled = false; 你要是确定不需要这层图
                }

                // 有的 ScrollRect 自己也挂了个白底图，顺手关掉
                var scrollBg = sr.GetComponent<Image>();
                if (scrollBg && scrollBg.color.a > 0.01f)
                    scrollBg.color = new Color(scrollBg.color.r, scrollBg.color.g, scrollBg.color.b, 0f);
            }

            // 4) 现在再安全地应用“锁定布局”的锚点/尺寸
            var rt = _richText.rectTransform;
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, LOCK_WIDTH);

            _buttonsOverlay.anchorMin = new Vector2(0, 1);
            _buttonsOverlay.anchorMax = new Vector2(0, 1);
            _buttonsOverlay.pivot = new Vector2(0, 1);
            _buttonsOverlay.sizeDelta = new Vector2(LOCK_WIDTH, 0f);

            vlg.childForceExpandWidth = false; // 父容器也不要再横向拉伸子项
        }


        static float OneLineHeight(Text t)
        {
            var st = t.GetGenerationSettings(new Vector2(1_000_000f, 1_000_000f));
            float h = t.cachedTextGeneratorForLayout.GetPreferredHeight("字", st) / t.pixelsPerUnit;
            return Mathf.Ceil(h > 1f ? h : (t.fontSize > 0 ? t.fontSize + 2 : 16f));
        }



        private float GetViewportWidth()
        {
            var rt = _sw != null ? _sw.transform_scrollRect as RectTransform : null;
            return (rt && rt.rect.width > 0) ? rt.rect.width : 420f;
        }

        // ===== 渲染：正文 = 你的富文本；按钮 = 右上角悬浮小点，不占布局 =====
        private void ShowLeaderboard()
        {
            if (_contentRoot == null) return;
            if (_richText == null || _buttonsOverlay == null)
            {
                BuildUI();
                if (_richText == null || _buttonsOverlay == null) return;
            }

            string content;
            try { content = traitAction.BuildLeaderboardRichText(); }
            catch (Exception ex) { content = $"<color=#FF6666>生成榜单失败：</color>{ex.Message}"; }

            if (string.IsNullOrEmpty(content))
                content = "<color=#AAAAAA>暂无数据。世界还没加载，或者还没有目标。</color>";

            if (content.Length > MaxTotalChars)
                content = content.Substring(content.Length - MaxTotalChars);

            // 1) 正文直接显示（保持你的排版）
            _richText.text = content;

            // 2) 先让布局跑一遍，拿到正文最终宽度
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(_richText.rectTransform);

            // 3) 重建悬浮按钮
            RebuildLineButtons(content);

            // 4) 滚动条复位底部
            var sr = _sw.transform_scrollRect ? _sw.transform_scrollRect.GetComponent<ScrollRect>() : null;
            if (sr)
            {
                Canvas.ForceUpdateCanvases();
                sr.verticalNormalizedPosition = 0f;
            }
        }

        // 段落类型
        enum BoardSection { None, Power, Kill }

        // 识别“战力榜/战斗榜/击杀榜/杀戮榜”等标题行（中英双语都兜）
        private BoardSection DetectSectionHeader(string rawLine)
        {
            if (string.IsNullOrEmpty(rawLine)) return BoardSection.None;
            var plain = System.Text.RegularExpressions.Regex.Replace(rawLine, "<.*?>", ""); // 去富文本
            if (System.Text.RegularExpressions.Regex.IsMatch(plain, "(【战力排行榜/Power Leaderboard】|战斗榜|力量榜|Power\\s*Board|Combat\\s*Board)", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                return BoardSection.Power;
            if (System.Text.RegularExpressions.Regex.IsMatch(plain, "(【杀戮排行榜/Kills Leaderboard】|杀戮榜|Kill\\s*Board)", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                return BoardSection.Kill;
            return BoardSection.None;
        }


        const bool QUANTIZE_HEIGHT = true;  // 将行高取整，避免小数误差
        const float BASELINE_FIX = -1.0f; // 基线微调（负数=整体下移一点）

        // —— 按行生成悬浮按钮（每行右上角 12×12，小到不挡字）——
        // —— 按行生成悬浮按钮（左上角，随行首行对齐，不受换行影响）——
        private void RebuildLineButtons(string content)
        {
            // 常量统一在此修改
            const float BTN_SIZE = 9f;     // 小按钮尺寸
            const float BTN_MARGIN = 2f;     // 距该段顶部的内缩
            const float BTN_X_LEFT = -22f;   // 负值=伸到文字左外侧；0=贴文本左边缘
            const float BTN_Y_OFFSET = 0f;     // 额外垂直微调（+上 -下）
            const float BASELINE_FIX = -1f;  // 基线微调（中文略高时 -1 更稳）

            // 清空旧按钮
            for (int i = _buttonsOverlay.childCount - 1; i >= 0; i--)
                Destroy(_buttonsOverlay.GetChild(i).gameObject);
            if (string.IsNullOrEmpty(content)) return;

            float width = LOCK_LAYOUT ? LOCK_WIDTH : _richText.rectTransform.rect.width;
            if (width <= 1f) width = LOCK_WIDTH;

            using var sr = new StringReader(content);
            string line;
            int row = 0;

            // === 新增：跟踪当前段落与该段的名次 ===
            BoardSection currSection = BoardSection.None;
            int rankInSection = 0;

            while ((line = sr.ReadLine()) != null)
            {
                // 先看是不是“榜单标题行”，是就切段并清零名次
                var newSec = DetectSectionHeader(line);
                if (newSec != BoardSection.None)
                {
                    currSection = newSec;
                    rankInSection = 0;
                }

                // …………原有的测高逻辑…………
                string lineText = string.IsNullOrEmpty(line) ? " " : line;

                float h_block = OneLineHeight(_richText);


                float h_first = h_block;
                if (h_first < 1f) h_first = (_richText.fontSize > 0 ? _richText.fontSize + 2 : 16f);
                h_first = Mathf.Ceil(h_first);

                // 解析目标（无目标=标题或分隔，不放按钮但要累计 y）
                ExtractTargetFromLine(line, out long id, out string nameClean);
                Actor nameResolved = null;
                if (id <= 0 && !string.IsNullOrEmpty(nameClean))
                    nameResolved = FindActorByName(nameClean);

                if (id <= 0 && nameResolved == null)
                {
                    row++;   // 不是条目，也要推进一行
                    continue; // 没目标，不是“榜单条目”，不编号
                }

                long finalId = id > 0 ? id : (nameResolved?.data?.id ?? 0);
                string finalNm = nameClean;

                // === 关键：这是榜单条目，给它分配名次（每遇到新榜标题时已清零）===
                rankInSection++;
                string rankLabel = rankInSection.ToString();   // 第1名就是 "1"，第10名就是 "10"

                // —— 创建按钮并定位（保留你原来的锚点定位）——
                var btnGO = new GameObject("GoBtn", typeof(Image), typeof(Button));
                btnGO.transform.SetParent(_buttonsOverlay, false);

                var img = btnGO.GetComponent<Image>();
                img.color = new Color(0f, 0f, 0f, 0.5f); // 半透明深色衬底，数字清晰

                var bRT = btnGO.GetComponent<RectTransform>();
                bRT.anchorMin = new Vector2(0, 1);
                bRT.anchorMax = new Vector2(0, 1);
                bRT.pivot = new Vector2(0, 1);
                bRT.sizeDelta = new Vector2(BTN_SIZE, BTN_SIZE);

                // 顶部像素 = 行号 * 行高
                float yTop = -(row * h_first) - BTN_MARGIN;
                // 首行居中，再微调
                float yPos = yTop - 0.5f * (h_first - BTN_SIZE) + BTN_Y_OFFSET + BASELINE_FIX;
                yPos = Mathf.Round(yPos);
                bRT.anchoredPosition = new Vector2(BTN_X_LEFT, yPos);


                // —— 中央小字：编号 —— 
                var icon = new GameObject("Icon", typeof(Text));
                icon.transform.SetParent(btnGO.transform, false);
                var it = icon.GetComponent<Text>();
                it.text = rankLabel;            // 1..10
                it.font = _font;
                it.alignment = TextAnchor.MiddleCenter;
                it.color = Color.white;
                it.resizeTextForBestFit = true; // 两位数自动缩小
                it.resizeTextMinSize = 5;
                it.resizeTextMaxSize = 10;
                it.raycastTarget = false;
                var iRT = it.rectTransform;
                iRT.anchorMin = Vector2.zero; iRT.anchorMax = Vector2.one;
                iRT.offsetMin = Vector2.zero; iRT.offsetMax = Vector2.zero;

                // 加描边，任何底色都清晰
                var outline = icon.AddComponent<Outline>();
                outline.effectColor = new Color(0f, 0f, 0f, 0.9f);
                outline.effectDistance = new Vector2(1f, -1f);

                btnGO.transform.SetAsLastSibling();

                var btn = btnGO.GetComponent<Button>();
                long capturedId = finalId; string capturedNm = finalNm;
                btn.onClick.AddListener(() => OnClickTarget(capturedId, capturedNm));

                row++;   // 每读完一行，行号+1
            }

            _buttonsOverlay.sizeDelta = new Vector2(_buttonsOverlay.sizeDelta.x, row * OneLineHeight(_richText));
        }

        // —— 新增：测“单行高度”（用超宽避免换行），用于按钮垂直对齐 —— 
        private float MeasureSingleLineHeight(Text tpl, string richLine)
        {
            // 给一个极大宽度，确保不换行
            var settings = tpl.GetGenerationSettings(new Vector2(10000f, 0f));
            settings.richText = true;
            float h = tpl.cachedTextGeneratorForLayout.GetPreferredHeight(richLine, settings) / tpl.pixelsPerUnit;
            return h;
        }


        // —— 单行富文本测高（不改布局）——
        private float MeasureLineHeight(Text tpl, string richLine, float width)
        {
            var settings = tpl.GetGenerationSettings(new Vector2(width, 0f));
            settings.richText = true;
            float h = tpl.cachedTextGeneratorForLayout.GetPreferredHeight(richLine, settings) / tpl.pixelsPerUnit;
            return h;
        }

        // —— 从一行富文本中提取 “名字#12345” → (id, name) —— 
        private void ExtractTargetFromLine(string rawLine, out long id, out string nameClean)
        {
            id = 0; nameClean = null;
            if (string.IsNullOrEmpty(rawLine)) return;

            var plain = Regex.Replace(rawLine, "<.*?>", ""); // 去标签
            if (string.IsNullOrEmpty(plain)) return;

            // 先找 “名字#ID”
            var m = Regex.Match(plain, @"^(?<name>.+?)#(?<id>\d+)\b");
            if (m.Success)
            {
                long.TryParse(m.Groups["id"].Value, out id);
                nameClean = m.Groups["name"].Value.Trim();
                return;
            }

            // 兜底：尝试从“序号+名字 - ...”中取名字
            var p = plain.Trim();
            p = Regex.Replace(p, @"^\s*\d+[\.、]\s*", "");
            var cut = p.IndexOf(" - ", StringComparison.Ordinal);
            if (cut < 0) cut = p.IndexOf('（');
            if (cut > 0) p = p.Substring(0, cut);
            if (!string.IsNullOrWhiteSpace(p)) nameClean = p.Trim();
        }

        // ===== 点击：协程（不关窗），先 id 再 name 兜底 =====
        private void OnClickTarget(long actorId, string name)
        {
            StartCoroutine(OpenActorFlow(actorId, name));
        }

        private System.Collections.IEnumerator OpenActorFlow(long actorId, string name)
        {
            Actor a = null;
            if (actorId > 0) a = FindActorById(actorId);
            if (a == null && !string.IsNullOrEmpty(name)) a = FindActorByName(name);
            if (a == null) yield break;

            yield return null; // 下一帧，避免本帧 UI 冲突
            OpenCreatureWindow(a);
        }

        private Actor FindActorById(long id)
        {
            try { return World.world?.units?.get(id); } catch { return null; }
        }

        private Actor FindActorByName(string name)
        {
            try
            {
                var target = Regex.Replace(name ?? "", "<.*?>", "").Trim();
                var list = World.world?.units?.getSimpleList();
                if (list != null)
                {
                    Actor fallback = null;
                    for (int i = 0; i < list.Count; i++)
                    {
                        var a = list[i];
                        if (a?.data == null) continue;
                        var n = Regex.Replace((a.getName() ?? a.data.name) ?? "", "<.*?>", "").Trim();
                        bool match = string.Equals(n, target, StringComparison.Ordinal)
                                  || string.Equals(n, target, StringComparison.OrdinalIgnoreCase)
                                  || n.Contains(target) || target.Contains(n);
                        if (match)
                        {
                            if (a.hasHealth()) return a;
                            if (fallback == null) fallback = a;
                        }
                    }
                    if (fallback != null) return fallback;
                }
            }
            catch { }
            return null;
        }

        // —— 打开单位信息窗口；若失败则定位并尝试选中 —— 
        // —— 打开单位窗口；若禁用或失败则定位并尝试选中 —— 
        private void OpenCreatureWindow(Actor a)
        {
            if (a == null) return;

            // 稳：只做定位 + 官方选中
            TryJumpToActor(a);
            try { SelectedUnit.clear(); SelectedUnit.select(a); } catch { }


        }




        private void TryJumpToActor(Actor a)
        {
            if (a == null) return;

            try
            {
                if (!s_locationJumpLookedUp)
                {
                    var tHist = AppDomain.CurrentDomain.GetAssemblies()
                                 .SelectMany(x => { try { return x.GetTypes(); } catch { return Array.Empty<Type>(); } })
                                 .FirstOrDefault(tp => tp.Name == "HistoryHud" || (tp.FullName != null && tp.FullName.EndsWith(".HistoryHud")));
                    s_locationJumpMI = tHist?.GetMethod("locationJump",
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static,
                        null, new Type[] { typeof(Vector3) }, null);
                    s_locationJumpLookedUp = true;
                }
                if (s_locationJumpMI != null)
                {
                    s_locationJumpMI.Invoke(null, new object[] { a.current_position });
                    return;
                }
            }
            catch { }
            try { World.world?.locatePosition(a.current_position); } catch { }
        }

    }

    // ===== Tab 初始化（与你之前一致）=====
    public static class LogViewerUI
    {
        private static bool _inited;
        private static PowersTab _tab;

        private static Sprite TrySprite(params string[] keys)
        {
            foreach (var k in keys)
            {
                if (string.IsNullOrEmpty(k)) continue;
                var s = SpriteTextureLoader.getSprite(k);
                if (s != null) return s;
            }
            return null;
        }

        public static void Init()
        {
            if (_inited) return;
            _inited = true;

            PlainLogViewerWindow.CreateAndInit("dgr_log_window", "BiaoTi");

            var tabIcon = TrySprite("icons/iconTab", "ui/icons/iconBook");
            _tab = TabManager.CreateTab("dgr_tab", "BiaoTi", "", tabIcon);
            _tab.SetLayout(new List<string> { "tools" });

            var btnIcon = TrySprite("icons/iconCreatureTop", "icons/iconTab", null);
            var btn = PowerButtonCreator.CreateWindowButton("dgr_open_log_window", "dgr_log_window", btnIcon);
            _tab.AddPowerButton("tools", btn);

            // 方案A：打开 NML 原生配置窗口
            var settingsIcon = TrySprite("icons/iconSettings", "icons/iconBook");
            var settingsBtn = PowerButtonCreator.CreateSimpleButton("模组设置", () => OpenNativeModSettings(), settingsIcon);
            _tab.AddPowerButton("tools", settingsBtn);

            _tab.UpdateLayout();
        }

        private static void OpenNativeModSettings()
        {
            try
            {
                var cfg = TryGetMyModConfig();
                if (cfg == null)
                {
                    Debug.LogError("[DGR] 未找到 ModConfig（检查 default_config.json / BasicMod<T>.GetConfig() 暴露情况）");
                    return;
                }

                var wndType = FindTypeBySimpleNames(new[] {
                    "NeoModLoader.ui.ModConfigureWindow",
                    "NeoModLoader.General.ModConfigureWindow",
                    "NeoModLoader.General.UI.ModConfigureWindow",
                    "ModConfigureWindow"
                });
                if (wndType == null) { Debug.LogError("[DGR] 未找到 ModConfigureWindow 类型"); return; }

                var show = wndType.GetMethod("ShowWindow", BindingFlags.Public | BindingFlags.Static);
                if (show == null) { Debug.LogError("[DGR] 未找到 ModConfigureWindow.ShowWindow(...)"); return; }

                show.Invoke(null, new object[] { cfg });
            }
            catch (Exception ex) { Debug.LogError($"[DGR] 打开原生设置窗口失败: {ex}"); }
        }

        private static object TryGetMyModConfig()
        {
            var modType = Type.GetType("DemonGameRules.DemonGameRulesClass")
                       ?? AppDomain.CurrentDomain.GetAssemblies()
                            .SelectMany(a => { try { return a.GetTypes(); } catch { return Array.Empty<Type>(); } })
                            .FirstOrDefault(t => t.Name == "DemonGameRulesClass");
            if (modType == null) return null;

            var pModCfg = modType.GetProperty("ModCfg", BindingFlags.Public | BindingFlags.Static);
            if (pModCfg != null) { var v = pModCfg.GetValue(null, null); if (v != null) return v; }

            object inst = null;
            var pI = modType.GetProperty("I", BindingFlags.Public | BindingFlags.Static);
            if (pI != null) inst = pI.GetValue(null, null);
            if (inst == null)
            {
                var fI = modType.GetField("I", BindingFlags.Public | BindingFlags.Static);
                if (fI != null) inst = fI.GetValue(null);
            }
            if (inst != null)
            {
                var mGetCfg = inst.GetType().GetMethod("GetConfig", BindingFlags.Public | BindingFlags.Instance);
                if (mGetCfg != null) { var v = mGetCfg.Invoke(inst, null); if (v != null) return v; }

                var fCfg2 = inst.GetType().GetField("config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                         ?? inst.GetType().GetField("Config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (fCfg2 != null) { var v = fCfg2.GetValue(inst); if (v != null) return v; }

                var pCfg2 = inst.GetType().GetProperty("config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                         ?? inst.GetType().GetProperty("Config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (pCfg2 != null) { var v = pCfg2.GetValue(inst, null); if (v != null) return v; }
            }

            var fCfg = modType.GetField("config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
                   ?? modType.GetField("Config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (fCfg != null) { var v = fCfg.GetValue(null); if (v != null) return v; }
            var pCfg = modType.GetProperty("config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
                  ?? modType.GetProperty("Config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (pCfg != null) { var v = pCfg.GetValue(null, null); if (v != null) return v; }

            return null;
        }

        private static Type FindTypeBySimpleNames(IEnumerable<string> candidates)
        {
            foreach (var name in candidates)
            {
                var t = Type.GetType(name);
                if (t != null) return t;

                t = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a => { try { return a.GetTypes(); } catch { return Array.Empty<Type>(); } })
                    .FirstOrDefault(tt => tt.FullName == name || tt.Name == name);
                if (t != null) return t;
            }
            return null;
        }
    }
}
