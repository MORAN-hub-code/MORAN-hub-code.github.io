﻿using System.Collections.Generic;
using System.Linq;
using System;
using ai;
using ReflectionUtility;
using UnityEngine;
using VideoCopilot.code.utils;
using System.IO;

namespace VideoCopilot.code
{
    internal class traitAction
    {
       private static readonly string[] yuanyingTitles = 
{
    // 元婴期正道称号
    "清玄道人",   "玉虚真人",   "玄光真人",   "烈风散人",   "白羽道人",
    "云岚真人",   "空灵道人",   "万象散人",   "赤焰灵君",   "云溪子",
    "青松道人",   "问心上人",   "采薇真人",   "听风子",    "栖霞道人",
    "竹隐子",     "漱石上人",   "怀真真人",   "守拙道人",   "折梅子",
    "听松上人",   "闲云真人",   "清溪道人",   "栖真子",    "抚琴上人",
    "玉尘真人",   "观云道人",   "静虚子",     "月华真人",   "松风道人",
    "寒梅子",     "听雨上人",   "清虚真人",   "丹霞道人",   "玄素子",
    "问道上人",   "玉泉真人",   "云鹤道人",   "静松子",    "听风上人",
    "玄真真人",   "竹溪道人",   "素月子",     "玄清真人",   "云游道人",
    "雪松子",     "听山上人",   "清泉真人",   "闲鹤道人",   "玉松子",
    "观山上人",   "松月道人",   "玄松子",     "听虚上人",   "云泉真人",
    "竹鹤道人",   "明墟真人",   "清微上人",   "玉宸道人",   "太虚子",
    "归藏真人",   "玄霄上人",   "紫阳道人",   "青冥子",    "天枢真人",
    "云华上人",   "玄真道人",   "玉虚子",     "太素真人",   "清玄上人",
    "玉衡道人",   "玄月子",     "太乙真人",   "云虚上人",   "青阳道人",
    "玄光子",     "太清真人",   "玉清上人",   "玄河道人",   "云月子",
    "太玄真人",   "玉阳上人",   "玄风道人",   "云虚子",    "太和真人",
    
    // 元婴期魔道/旁门称号
    "玉宸上人",   "赤渊上人",   "血饮道人",   "冥骨真人",   "煞魂子",
    "焚心上人",   "血河道人",   "阴煞真人",   "血魄子",    "冥火上人",
    "血煞道人",   "黄泉真人",   "幽魄上人",   "冥河道人",   "煞月子",
    "葬魂真人",   "阴冥上人",   "鬼河道人",   "幽月子",    "冥魂真人",
    "阴魄上人",   "禅心真人",   "空相上人",   "莲生道人",   "伽蓝子",
    "妙法真人",   "慧觉上人",   "净尘道人",   "慈航真人",   "慧海上人",
    "星谶上人",   "遁甲道人",   "棋枰子",    "符海真人",   "阵枢上人",
    "天衍道人",   "玄算子",     "灵枢真人",   "天机上人",   "符箓道人",
    "丹鼎真人",   "器宗上人",   "药尘子",    "灵傀道人",   "云舟真人",
    "宝鉴上人",   "丹霞道人",   "器灵子",    "药鼎真人",   "云商上人",
    "玄戈上人",   "栖霞道人",   "苍梧子",    "北冥真人",   "南离上人"
};

private static readonly string[] sanxianTitles = 
{
    // 散仙正道
    "璇玑星君",   "瑶光圣主",   "天罗仙尊",   "紫极圣君",   "洞玄仙尊",
    "玉衡真仙",   "太微圣尊",   "天权仙主",   "开阳圣君",   "摇光仙尊",
    "云笈玉圣",   "天河仙君",   "碧落圣主",   "玄穹仙尊",   "丹霄圣君",
    "青阙仙使",   "玉京真仙",   "太渊圣尊",   "天枢仙主",   "紫垣圣君",
    "太虚仙君",   "玉宸圣主",   "九霄仙尊",   "玄穹圣君",   "紫微仙使",
    "洞冥真仙",   "青冥圣尊",   "天衍仙主",   "琅琊圣君",   "归墟仙尊",
    "北斗玉仙",   "太皓圣主",   "云华仙尊",   "乾坤圣君",   "玄天仙使",
    "青阳玉尊",   "太素仙君",   "玉清圣主",   "天枢仙尊",   "沧溟圣君",
    "紫府真仙",   "九光圣尊",   "玄黄仙主",   "洞玄圣君",   "凌霄仙尊",
    "太乙玉圣",   "天罡仙君",   "青霄圣主",   "玄冥仙尊",   "玉虚圣君",
    "紫垣星君",   "天市仙尊",   "太皓圣君",   "勾陈仙使",   "洞明星主",
    "玉衡圣尊",   "天璇真君",   "北辰仙主",   "南斗圣君",   "文昌仙尊",
    "武曲真宰",   "破军圣主",   "左辅仙君",   "右弼圣尊",   "天魁真宰",
    "天钺仙主",   "禄存圣君",   "文曲仙尊",   "廉贞仙尊",   "天府圣主",
    "太阴仙君",   "太阳圣尊",   "天梁真宰",   "天相仙主",   "七杀圣君",
    "擎羊仙尊",   "陀罗仙君",   "火星圣主",   "铃星仙君",   "地劫圣尊",
    "地空仙君",   "天刑仙主",   "天姚圣君",   "红鸾仙尊",   "天喜仙君",
    "龙池圣主",   "凤阁仙君",   "台辅圣尊",   "封诰仙主",   "恩光仙主",

    // 散仙魔道
    "九幽魔尊",   "血狱圣主",   "冥煞仙君",   "噬魂魔尊",   "玄阴圣主",
    "万劫魔君",   "赤炼仙尊",   "黑天魔圣",   "无生魔尊",   "骨煞圣君",
    "冥狱邪尊",   "血煞魔主",   "蚀日鬼君",   "吞界魔尊",   "绝仙煞主",
    "焚宇邪君",   "灭魂魔尊",   "断空煞君",   "陨星鬼主",   "葬神邪尊",
    "万毒尸尊",   "千魂蛊主",   "阴煞傀君",   "血魇毒尊",   "尸魔魂主",
    "骨灵邪君",   "怨煞毒尊",   "腐尸蛊主",   "阴鸦魂君",   "疫鬼毒主",
    "百尸仙君",   "千蛊圣主",   "影劫仙尊",   "阴符魔圣",   "毒煞仙君",
    "魂寂圣主",   "血炼仙尊",   "九阴真圣",   "尸解仙君",   "无常圣尊"
};

private static readonly string[] jinyuanTitles = 
{
    // 金仙正道
    "太虚量劫真王", "紫宸星律圣王", "终始轮转仙王", "九重天阙灵尊", 
    "洞玄真冥法圣", "玄黄开辟真宰", "混虚通明圣君", "太乙量劫法王",
    "赤混元墟灵王", "玉宸启元圣尊", "清浊分形真君", "禹余太虚法尊",
    "元载空洞圣宰", "虚王劫运真王", "赤明量劫法王", "冥通玄寂灵君",
    "梵炁周流圣主", "碧落归墟真王", "丹华紫宸法王", "青玄劫灭圣尊",
    "白墟量劫真宰", "玄都妙相法尊", "神霄玉宸灵尊", "紫微垣律圣王",
    "勾陈劫运真君", "后劫王极法尊", "南华长生圣王", "东极青华真尊",
    "西极皓灵法君", "北宸量劫圣主", "混虚轮转圣尊", "量劫终始法王",
    "玄穹开辟真宰", "九寰通明灵尊", "太乙道衍圣君", "赤混量生法尊",
    "玉宸玄枢灵尊", "清浊归墟圣尊", "禹余量劫真君", "元载通幽法尊",
    "虚王寂灭圣宰", "赤明道枢真尊", "冥通玄量法尊", "梵炁轮转灵君",
    "碧落道生圣主", "丹华通玄真尊", "青玄量灭法尊", "白墟道枢圣尊",
    "玄都混虚真宰", "神霄通明法尊", "紫微量劫灵尊", "勾陈道衍圣王",
    "后劫通玄真君", "南华量生法尊", "东极道枢圣王", "西极混虚真王",
    "北宸通幽法君", "中天量劫圣主", "天梁玄道真宰", "七杀混虚灵王",
    "天府量劫圣王", "太阴道衍真宰", "太阳通幽法尊", "擎羊玄穹圣君",
    "陀罗混虚真宰", "量劫始源真王", "归墟终律圣王", "玄穹开辟仙王",
    "太易轮转灵尊", "混沌通冥法圣", "鸿蒙量生真宰", "虚海溯光圣君",
    "终焉启元法王", "元初寂灭灵王", "太始归真圣王", "空无分形真君",
    "终末太虚法尊", "万道劫运圣宰", "永劫量生真尊", "玄牝轮转法王",
    "终始寂灭灵君", "梵相周流圣主", "量因归墟真王", "丹元紫极法王",
    "青冥劫灭圣尊", "白洞量生真宰", "玄相妙有法王", "神寂玉宸灵王",
    "紫极终律圣尊", "劫运轮转真君", "后因王极法尊", "南冥长生圣王",
    "东墟青华真王", "西极玄冥法君", "北冥量劫圣主", "太初因轨法王",
    "洞虚玄相圣王", "玄宇星核真宰", "紫寰辰脉灵尊", "太素质生圣君",
    "九因终律真尊", "青霄星漩法尊", "碧落玄核圣尊", "丹寰云汉灵尊",
    "归因星移真君",

    // 金仙魔道
    "永劫归墟魔尊", "冥墟焚宇邪尊", "万相寂灭冥君", "无间永夜魔尊",
    "黑渊蚀日邪尊", "赤炼焚宙冥尊", "终湮焚宙魔尊", "永寂蚀空邪主",
    "量劫葬道冥尊", "绝因噬界鬼尊", "玄灭归墟魔君", "终末湮因邪尊",
    "破道焚相冥主", "绝源蚀魂魔尊", "湮宇寂灭邪君", "永夜葬因鬼主"
};

private static readonly string[] hunyuanTitles = 
{
    // 混元正道
    "玉虚紫极道祖", "上清玄穹天尊", "太初混元仙帝", "九宸青冥道主",
    "洞真玉华天尊", "玄黄造化道祖", "紫府通明仙帝", "太乙救苦天尊",
    "赤明开天道主", "玉宸启圣道祖", "清微玄化天尊", "禹余大罗仙帝",
    "郁单无量道主", "虚皇太素天尊", "赤混太无道祖", "冥寂玄通仙帝",
    "太虚玄穹道祖", "紫宸星律天尊", "终始轮转仙帝", "九重天阙道主",
    "洞玄真冥天尊", "玄黄开辟道祖", "混虚通明仙帝", "太乙度厄天尊",
    "赤混元墟道主", "玉宸启元道祖", "清浊分形天尊", "禹余太虚仙帝",
    "元载空洞道主", "虚皇劫运天尊", "赤明量劫道祖", "冥通玄寂仙帝",
    "梵炁周流天尊", "碧落归墟道主", "丹华紫宸道祖", "青玄劫灭天尊",
    "白墟量劫仙帝", "玄都妙相道主", "神霄玉宸真祖", "紫微垣律天尊",
    "勾陈劫运仙帝", "后劫皇极道祖", "南华长生天尊", "东极青华道主",
    "西极皓灵仙祖", "北宸量劫天尊", "南垣司命道祖", "五劫轮转仙帝",
    "三垣律令天尊", "雷劫普化道主", "文枢启明仙祖", "真劫荡魔天尊",
    "幽都玄冥道祖", "岱宗量劫仙帝", "太始归真道祖", "鸿蒙量劫天尊",
    "玄元开辟仙帝", "虚海溯光道主", "终焉轮转天尊", "混沌通冥仙帝",
    "太易量生道祖", "元初寂灭天尊", "空无分形仙帝", "终末太虚道主",
    "万道劫运天尊", "永劫量生仙帝", "玄牝轮转道祖", "终始寂灭天尊",
    "梵相周流仙帝", "量因归墟道祖", "丹元紫极天尊", "青冥劫灭仙帝",
    "白洞量生道主", "玄相妙有天尊", "神寂玉宸仙帝", "紫极终律道祖",
    "劫运轮转天尊", "后因皇极仙帝", "南冥长生道主", "东墟青华天尊",
    "西极玄冥仙帝", "北冥量劫道祖", "太初因轨天尊", "洞虚玄相仙帝",
    "玄宇星核道主", "紫寰辰脉天尊", "太素质生仙帝", "九因终律道祖",
    "青霄星漩天尊", "碧落玄核仙帝", "丹寰云汉道主", "归因星移天尊",
    "太素玄枢仙帝", "紫宸终始道祖",

    // 混元魔道
    "永劫归墟魔祖", "冥墟焚宇妖帝", "玄煞量劫道主", "终末劫运天尊",
    "万相寂灭鬼祖", "无间永夜魔帝", "黑渊蚀日道祖", "赤炼焚宙魔尊",
    "阴墟统御天尊", "玄牝噬道寂主", "罗酆永劫鬼帝", "阿鼻量劫魔祖",
    "黄泉渡灭天尊", "幽劫夺道魔帝", "七终劫运道祖", "贪劫噬宇魔尊",
    "破量真空天尊", "灭世劫磨道主", "永寂轮转魔祖", "业劫红莲魔帝"
};
        //以下为拥有这个巫术状态的效果
        public static bool attack_Ring05(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 10f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示火的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_fire);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        public static bool attack_Ring25(BaseSimObject pTarget, WorldTile pTile = null)
        {
            float pDamage = 900f; // 每次受到的伤害值
            // 目标生命值大于-1，则对目标施加伤害
            if (Randy.randomChance(1f) && pTarget.a.data.health > -1)
            {
                pTarget.getHit(pDamage, true, AttackType.Poison, null, true, false);
            }

            // 在目标位置生成表示感染的粒子效果
            pTarget.a.spawnParticle(Toolbox.color_infected);
            // 使目标开始震动，模拟反应
            pTarget.a.startShake(0.4f, 0.2f, true, false);
            // 返回true，表示效果已成功应用
            return true;
        }

        //以下为巫术
        public static bool attack_sorcery01(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring01", 3f); //零环•轻身术
            }

            return true;
        }

        public static bool attack_sorcery02(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pTarget.a.addStatusEffect("Ring05", 3f); //零环•烈焰之握
            }

            return true;
        }

        public static bool attack_sorcery03(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pTarget.a.addStatusEffect("Ring02", 3f); //零环•水幻迷障
            }

            return true;
        }

        public static bool sorcery04_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(2); //零环•生命祈愈
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery05(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring03", 3f); //零环•大地壁垒
            }

            return true;
        }

        public static bool attack_sorcery06(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring04", 3f); //零环•蔓藤囚牢
            }

            return true;
        }

        public static bool attack_sorcery07(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring06", 3f); //零环•鹰隼凝视
            }

            return true;
        }

        public static bool attack_sorcery11(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.7f)
            {
                pTarget.a.addStatusEffect("Ring11", 6f); //一环•疲惫之手
            }

            return true;
        }

        public static bool attack_sorcery12(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring12", 6f); //一环•缠绕之网
            }

            return true;
        }

        public static bool attack_sorcery13(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring13", 6f); //一环•土之坚甲
            }

            return true;
        }

        public static bool sorcery14_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(23); //一环•复苏之流
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery15(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring14", 6f); //一环•风行术
            }

            return true;
        }

        public static bool attack_sorcery16(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring15", 6f); //一环•水雾术
            }

            return true;
        }

        public static bool attack_sorcery17(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string>
                { "Grade4", "Grade5", "Grade6", "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring16", 6f); //一环•气机牵引
            }

            return true;
        }

        public static bool attack_sorcery22(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring22", 8f); //二环•星之致幻
            }

            return true;
        }

        public static bool attack_sorcery23(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            const int drainAmount = 150; // 定义要汲取的血量
            if (pSelf == null || pSelf.a == null || pSelf.a.data == null)
            {
                return false; // 如果施法者无效，则返回false
            }
            pTarget.a.spawnParticle(Toolbox.makeColor("#FF0000"));
            if (pTarget.isBuilding())
            {
                return false;
            }

            // 检查目标是否有足够的血量可以被汲取
            if (pTarget.a.data.health > 0)
            {
                int actualDrain = Mathf.Min(drainAmount, pTarget.a.data.health); // 实际汲取的血量，不超过目标的当前血量
                pTarget.a.data.health -= actualDrain;                            // 减少目标的血量
                pSelf.a.data.health =
                    Mathf.Min(pSelf.a.getMaxHealth(), pSelf.a.data.health + actualDrain); // 恢复施法者的血量，但不超过其最大血量
            }

            return true;
        }

        public static bool attack_sorcery24(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pSelf.a.addStatusEffect("Ring24", 8f); //二环•岩石护壁
            }

            return true;
        }

        public static bool sorcery25_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000); //二环•生命涌泉
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_sorcery26(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (pTarget.isBuilding())
            {
                return false;
            }

            if (UnityEngine.Random.value < 0.8f)
            {
                pTarget.a.addStatusEffect("Ring25", 5f); //5秒状态:二环•生命流逝
            }

            return true;
        }

        public static bool attack_sorcery27(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring26", 8f); //二环•因果印记
            }

            return true;
        }

        public static bool attack_sorcery28(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade7", "Grade8", "Grade9", "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }

            if (UnityEngine.Random.value < 0.9f)
            {
                pSelf.a.addStatusEffect("Ring27", 8f); //二环•相位星痕步
            }

            return true;
        }

        public static bool attack_sorcery31(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            if (UnityEngine.Random.value < 1f)//三环•斥力场
            {
                Actor a = pTarget.a;
                Actor s = pSelf.a;

                EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);
                return false;
            }

            return false;
        }

        public static bool attack_sorcery32(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 特效的随机大小
            float explosionScaleMin = 0.1f;
            float explosionScaleMax = 0.3f;
            float explosionScale = UnityEngine.Random.Range(explosionScaleMin, explosionScaleMax);

            if (UnityEngine.Random.value < 1f) //三环•裂界爆炎
            {
                // 使用随机大小生成爆炸特效
                EffectsLibrary.spawnAtTileRandomScale("fx_explosion_tiny", pTile, explosionScale, explosionScale);
            }

            return true;
        }

        public static bool attack_sorcery33(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null) //三环•雷霆术
            {
                MapBox.spawnLightningMedium(pTile, 0.25f);
            }

            return false;
        }

        public static bool sorcery34_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 定义一个包含无效特质的HashSet
            var invalidTraits = new HashSet<string> { "Grade91" };
            // 检查pTarget和pTarget.a是否不为null，并且pTarget.a是否具有无效特质中的任何一个
            if (pTarget != null && pTarget.a != null && invalidTraits.Any(trait => pTarget.a.hasTrait(trait)))
            {
                return false; // 如果具有无效特质，则返回false
            }
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }

            // 获取血量
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();

            // 检查血量是否低于60%
            if (currentHealth < maxHealth * 0.6f)
            {
                // 如果血量低于50%，则为目标添加血眸状态
                pSelf.a.addStatusEffect("Ring34", 10f);
            }

            return true;
        }

        public static bool Grade91_Attack(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 空值检查
            if (pSelf == null || !pSelf.isActor())
            {
                return false;
            }

            // 获取 Actor 实例
            Actor actor = pSelf.a;
            if (actor == null)
            {
                return false;
            }

            // 安全获取数据
            BaseObjectData data = actor.getData();
            if (data == null)
            {
                return false;
            }
            int currentHealth = data.health;
            int maxHealth = actor.getMaxHealth();
            if (currentHealth < maxHealth * 0.8f)
            {
                pSelf.a.addStatusEffect("Ring92", 30f);// 检查血量是否低于80%
            }
            if (currentHealth < maxHealth * 0.5f)
            {
                pSelf.a.addStatusEffect("Ring93", 30f);// 检查血量是否低于50%
            }

            return true;
        }

        public static bool attack_Grade91(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pTarget == null)
            {
                return false;
            }
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }
            if (pTile == null)
            {
                return false;
            }
            if (UnityEngine.Random.value < 0.2f)
            {
                EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
            }
            return true;
        }

        //以下为境界带的再生
        public static bool Grade0_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade01_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)6);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade02_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Grade1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)220);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)420);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)620);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)3000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)7000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)30000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool Grade91_EffectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)2000000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)90);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool flair91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)180);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        
        public static bool flair92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth((int)10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool hunger_Grade91(BaseSimObject pTarget, WorldTile pTile = null) //始祖的饱食度
        {
            Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
            if (a != null)
            {
                a.data.nutrition = 100; // 不会饥饿，饱食度一直为100%
            }

            return false;
        }
        
        public static bool Grade91_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (UnityEngine.Random.value < 0.1f)
            {
                ActionLibrary.castTornado(null, pTarget, null);
            }

            return true;
        }
        private static string GetRandomTrait(string[] additionalTraits)
        {
            return additionalTraits[UnityEngine.Random.Range(0, additionalTraits.Length)];
        }

        public static bool Grade0_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 2.99)
            {
                return false;
            }

            string[] forbiddenTraits =
            {
                "Grade01", "Grade02", "Grade1", "Grade2", "Grade3", "Grade4", "Grade5", "Grade6", "Grade7", "Grade8",
                "Grade9", "Grade91"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }
            string actorName = a.getName();
            if (!actorName.Contains("引气") && !actorName.Contains("筑基") && !actorName.Contains("金丹") && !actorName.Contains("元婴")&& !actorName.Contains("化神")&& !actorName.Contains("炼虚")&& !actorName.Contains("合体")&& !actorName.Contains("大乘")&& !actorName.Contains("渡劫")&& !actorName.Contains("散仙")&& !actorName.Contains("真仙") && !actorName.Contains("金仙") && !actorName.Contains("混元") && !a.hasTrait("flair8") && !a.hasTrait("flair91"))
            {
                a.data.setName(pTarget.a.getName()+" 引气");
            }

            upTrait("特质", "Grade0", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
                new string[] { "特质" });

            return true;
        }

        private static string GetNewRandomTrait(string[] additionalTraits)
        {
            // 逻辑从 additionalTraits 中随机选择一个特质
            int randomIndex = UnityEngine.Random.Range(0, additionalTraits.Length);
            return additionalTraits[randomIndex];
        }

        public static bool Grade01_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 5.99)
            {
                return false;
            }
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 引气")) 
            {
            newName = currentName.Replace(" 引气", " 筑基");
            a.data.setName(newName);
            }

            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade01", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade0" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade02_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addStatusEffect("Ring01");
            if (a.GetYuanNeng() <= 8.99)
            {
                return false;
            }
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 筑基"))
            {
                newName = currentName.Replace(" 筑基", " 金丹");
                a.data.setName(newName);
            }

            string[] additionalTraits =
                { "sorcery01", "sorcery02", "sorcery03", "sorcery04", "sorcery05", "sorcery06", "sorcery07" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质


            upTrait("特质", "Grade02", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade01" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 17.99)
            {
                return false;
            }

            a.ChangeYuanNeng(-1);
            double successRate = 0.6; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.9;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.9;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.8;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            // 初始化newName为当前名称
            string newName = currentName;
            if (currentName.Contains(" 金丹"))
            {
            newName = currentName.Replace(" 金丹", " 元婴");
            a.data.setName(newName);
            }

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade1", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "crippled", "skin_burns", "eyepatch", "Grade02" },
                new string[] { "freeze_proof", "fire_proof", randomTrait });

            return true;
        }

        public static bool Grade2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 29.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 元婴"))
            {
                newName = currentName.Replace(" 元婴", " 化神");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-2);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("Grade1", "Grade2", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade1" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 44.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 化神"))
            {
                newName = currentName.Replace(" 化神", " 炼虚");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-3);

            string[] additionalTraits =
                { "sorcery11", "sorcery12", "sorcery13", "sorcery14", "sorcery15", "sorcery16", "sorcery17" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade3", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade2" },
                new string[] { randomTrait });


            return true;
        }

        public static bool Grade4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 69.99)
            {
                return false;
            }
            a.ChangeYuanNeng(-6);
            double successRate = 0.5; //默认概率
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.8;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.7;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.5;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            if (currentName.Contains(" 炼虚"))
            {
                newName = currentName.Replace(" 炼虚", " 合体");
                a.data.setName(newName);
            }

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade4", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade3" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 139.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            if (currentName.Contains(" 合体"))
            {
                newName = currentName.Replace(" 合体", " 大乘");
                a.data.setName(newName);
            }
            a.ChangeYuanNeng(-10);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade5", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade4" },
                new string[] { randomTrait });

            return true;
        }

        public static bool Grade6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 209.99)
            {
                return false;
            }
            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“渡劫”
            var (baseName, _) = ParseName(currentName);
string newTitle = yuanyingTitles [UnityEngine.Random.Range(0, yuanyingTitles .Length)];
a.data.setName($"{newTitle} - {baseName} 渡劫");
            a.ChangeYuanNeng(-20);

            string[] additionalTraits = { "sorcery22", "sorcery23", "sorcery24", "sorcery25", "sorcery26", "sorcery27", "sorcery28" };
            string randomTrait = GetNewRandomTrait(additionalTraits); //获取新随机特质

            upTrait("特质", "Grade6", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade5" },
                new string[] { randomTrait });

            return true;
        }
        private static (string baseName, string realm) ParseName(string name)
{
    string[] parts = name.Split(new[] { " - " }, StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length == 2)
    {
        string[] nameParts = parts[1].Split(' ');
        return (nameParts[0], nameParts.Last());
    }
    return (name.Split(' ')[0], "");
}

        public static bool Grade7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetYuanNeng() <= 287.99)
            {
                return false;
            }
            a.ChangeYuanNeng(-30);
            double successRate = 0.25; //默认概率 
            //根据天赋调整概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.5;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("flair1"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("flair2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("flair3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("flair4"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("flair5"))
            {
                successRate = 0.3;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“登仙”
            var (baseName, _) = ParseName(currentName);
string newTitle = sanxianTitles[UnityEngine.Random.Range(0, sanxianTitles.Length)];
a.data.setName($"{newTitle} - {baseName} 散仙");

            string[] sorceryTraits = { "sorcery31", "sorcery32", "sorcery33", "sorcery34", "sorcery35" };
            string[] meditationTraits = { "meditation1", "meditation2", "meditation3" };
            string randomSorceryTrait = GetNewRandomTrait(sorceryTraits);
            bool hasMeditationTrait = meditationTraits.Any(trait => a.hasTrait(trait));
            string randomMeditationTrait = "";
            if (!hasMeditationTrait)
            {
                randomMeditationTrait = GetNewRandomTrait(meditationTraits); //获取新随机特质
            }
            // 在 Grade8_effectAction 方法末尾 return true; 之前添加：
            a.data.favorite = true; // 散仙境界自动收藏


            upTrait("特质", "Grade7", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade6", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" },
                new string[] { "添加升级外的特质", randomSorceryTrait, randomMeditationTrait });

            return true;
        }

        public static bool Grade8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 199.99)//突破需求
            {
                return false;
            }
            a.ChangeMeditation(-30);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.5;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.4;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.4;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            string newName = currentName;
            // 检查名称中是否包含“合道”，如果包含则替换为“登仙”
            if (currentName.Contains(" 散仙"))
            {
                newName = currentName.Replace(" 散仙", " 真仙");
                a.data.setName(newName);
            }


            upTrait("特质", "Grade8", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade7", "flair81" },
                new string[] { "添加升级外的特质" });

            return true;
        }

        public static bool Grade9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 379.99)//突破需求
            {
                return false;
            }
            a.ChangeMeditation(-50);//突破消耗
            double successRate = 0.1; //突破默认概率
            string currentName = a.getName();
            if (a.hasTrait("flair91"))
            {
                successRate = 0.35;
            }
            else if (a.hasTrait("flair92"))
            {
                if (currentName.Contains(" 始祖"))
                {
                    successRate = 0.35;
                }
                if (currentName.Contains(" 不灭"))
                {
                    successRate = 0.3;
                }
            }
            else if (a.hasTrait("flair8"))
            {
                successRate = 0.3;
            }
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }
            // 初始化newName为当前名称
            string newName = currentName;
            // 检查名称中是否包含“真仙”，如果包含则替换为“金仙”
            if (currentName.Contains(" 真仙"))
{
    var (baseName, _) = ParseName(currentName);
    string newTitle = jinyuanTitles[UnityEngine.Random.Range(0, jinyuanTitles.Length)];
    a.data.setName($"{newTitle} - {baseName} 金仙");
    a.data.favorite = true;
}
            if (!a.hasTrait("flair91") && !a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair8"))
                {
                    a.addTrait("flair8");
                    int randomResurrection = UnityEngine.Random.Range(10, 16);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade9Tips.Count);
            string tip = grade9Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade9", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade8", "talent7", "flair81" },
                new string[] { "添加升级外的特质" });

            return true;
        }
        private static readonly List<string> grade9Tips = new List<string>
        {
            "「九重天劫炼金身，「{0}」踏碎轮回门\n三灾焚尽凡胎骨，紫府玄丹证不泯\n待叩玉京混元境，再借造化塑真神！」",
            "「太虚雷火锻仙胎，「{0}」执印破劫来\n胸中五炁吞星斗，顶上三花映灵台\n纵使道消十二万，残魂犹可问元始！」",
            "「紫府玄光耀八荒，「{0}」历劫显锋芒\n血染星河九千转，魂渡归墟三万场\n今朝且驻大罗境，待化混元镇穹苍！」",
            "「混沌青莲绽灵台，「{0}」叩天显道才\n袖纳阴阳吞日月，掌托星斗炼劫灾\n此身虽未证元始，九死神魂自归来！」",
            "「玄黄血染登仙阶，「{0}」执剑问劫灭\n三千雷火锻道骨，八万魔障淬神魂\n纵使玉京门未启，不灭真灵可重燃！」",
            "「轮回镜碎现真灵，「{0}」涅槃塑仙形\n九转玄功吞日月，大罗道果镇幽冥\n此身已渡无量劫，只待混元叩天门！」",
            "「阴阳双鱼演玄机，「{0}」踏罡步星移\n九幽寒泉淬道剑，大日真火炼仙衣\n纵然身陨归墟海，一点真灵复归一！」",
            "「周天星斗汇灵台，「{0}」执符镇劫灾\n血染天河八万里，魂游太虚三千载\n今朝金仙道果成，他日混元自可待！」",
            "「玄冰劫火淬道心，「{0}」挥袖断光阴\n掌中须弥藏日月，眉间混沌演浮沉\n纵使轮回千百转，不灭真性证混元！」",
            "「洪荒龙脉铸仙基，「{0}」吐纳炼玄虚\n九转金丹吞日月，三清道炁化虹霓\n此身已越生死障，只待鸿蒙重开天！」",
            "「混沌钟鸣震九渊，「{0}」执戈破劫渊\n胸藏星河吞寰宇，指划阴阳定坤乾\n纵使道消魂散尽，真灵不朽自涅槃！」",
            "「太初紫气贯苍穹，「{0}」踏歌御长风\n剑斩因果三千丈，鼎炼阴阳十二重\n今朝金仙道果证，他日重开造化功！」",
            "「归墟潮涌证道时，「{0}」擎天立劫池\n九转玄功吞北斗，大罗剑意破南冥\n纵使形神俱消散，真灵永驻混元碑！」",
            "「周天星斗大阵开，「{0}」执印踏劫来\n血染青冥九千界，魂渡玄黄十二灾\n今朝金身永不灭，他日重定封神台！」",
            "「鸿蒙初判显真形，「{0}」吐纳炼玄精\n掌托日月吞星汉，脚踏阴阳定晦明\n纵使劫火焚万古，道心不昧自长存！」",
            "「混沌青莲再绽时，「{0}」破劫显英姿\n剑断因果了尘缘，鼎镇气运炼真知\n今朝金仙道果就，他日重写封神辞！」"

        };
        public static bool Grade91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetMeditation() <= 999.99)
            {
                return false;
            }

            a.ChangeMeditation(-700);
            double successRate = 0.1; //突破默认概率
            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f); //生成0到1之间的随机数
            if (randomValue > successRate)
            {
                return false;
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 检查名称中是否包含“金仙”，如果包含则替换为“混元”
            var (baseName, _) = ParseName(currentName);
string newTitle = hunyuanTitles[UnityEngine.Random.Range(0, hunyuanTitles.Length)];
a.data.setName($"{newTitle} - {baseName} 混元");
            if (!a.hasTrait("flair92"))
            {
                if (!a.hasTrait("flair91"))
                {
                    a.addTrait("flair91");
                    int randomResurrection = UnityEngine.Random.Range(80, 101);
                    a.ChangeResurrection(randomResurrection);
                }
            }
            PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade91Tips.Count);
            string tip = grade91Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);

            upTrait("特质", "Grade91", a,
                new string[]
                {
                    "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "Grade9", "sorcery31",
                    "sorcery32", "sorcery33", "sorcery34", "sorcery35", "flair8", "flair81"

                },
                new string[] { "特质" });

            return true;
        }
        // 定义一组升级提示信息
        private static readonly List<string> grade91Tips = new List<string>
        {
            "混沌初开鸿蒙启，「{0}」登临玉京台\n三花聚顶凝道果，五炁朝元化仙胎\n掌纳天地归芥子，身演周天作法材\n今朝勘破元始境，方知大道为我开",
            "玉府丹元耀宇空，「{0}」铸道显神通\n骨化天柱撑四极，血涌星河贯九穹\n一念真空消万法，诸天星辰系指中\n此身已证混元体，永镇乾坤造化功",
            "太始玄晶凝窍穴，「{0}」证道显庄严\n鸿蒙劫火煅神骨，造化真金铸圣颜\n掌纳归墟湮日月，袖藏宇宙演诸天\n今立鸿蒙最高处，方知我本道中仙",
            "灵台方寸孕真我，「{0}」悟道显金身\n脐下混沌开天地，眉间星海映乾坤\n三千道藏化虹幕，八万魔尊俱俯臣\n此身即道道即我，万劫不磨永称尊",
            "太虚剑鸣二十四,「{0}」悟剑显神通\n诸天神魔皆俯首,三千大道共称臣\n举手截断光阴水,覆掌重开造化门\n今朝证得剑道极,方知我本道剑尊",
            "紫府青莲开十二,「{0}」证道显玄光\n玉京金阙自生香,血脉化作时光江\n身映诸天无穷界,一念重启万物纲\n此身已证道果极,永镇乾坤创世章",
            "鸿蒙造化演玄机，「{0}」炼道镇寰宇\n九转金丹吞星汉，五方真炁化虹霓\n掌托阴阳分清浊，足踏混沌定玄虚\n今朝证得混元果，万界轮回一念移",
            "太虚星海耀金身，「{0}」登临造化门\n三灾九难凝道骨，十方劫火铸仙魂\n袖卷星河吞日月，指划阴阳定乾坤\n此身已越元始境，重开鸿蒙立道尊",
            "万古长河凝道印，「{0}」踏劫显威神\n血染青冥八万里，魂渡玄黄十二轮\n胸藏混沌吞寰宇，指划阴阳定坤乾\n今立鸿蒙最高处，方知我即道本源",
            "归墟潮涌证混元，「{0}」擎天立道碑\n九幽寒泉淬仙骨，大日真火炼神髓\n掌纳诸天无穷界，身映星海亿万辉\n此身已越轮回外，永镇混沌开新规",
            "混沌青莲再绽时，「{0}」执印定玄机\n剑断因果了尘障，鼎镇气运炼真知\n一念真空生万物，双眸星海映诸夷\n今朝混元道果证，重写鸿蒙创世辞",
            "玄黄母气铸道胎，「{0}」登临显圣台\n九转玄功吞北斗，混元剑意破南垓\n血染星河八万转，魂渡归墟十万灾\n此身已证不灭体，永镇诸天掌劫来",
            "太始真火煅仙形，「{0}」踏劫显威灵\n骨化天柱撑四极，血涌长河贯八溟\n掌托日月吞星斗，足踏阴阳定晦暝\n今立鸿蒙最高境，方知大道即吾名",
            "周天星斗大阵开，「{0}」执符御劫来\n胸藏混沌演浮世，指化阴阳定轮回\n九转金丹吞浩宇，混元道果镇劫灰\n此身已越元始外，重定乾坤造化规",
            "鸿蒙初判显真性，「{0}」吐纳炼玄精\n掌托须弥藏芥子，身映诸天化繁星\n剑断因果三千丈，鼎镇阴阳十二庭\n今朝混元道果证，永驻太虚掌劫经",
            "混沌钟鸣震九幽，「{0}」踏歌御劫游\n血染青冥十万里，魂渡玄黄百万秋\n胸藏星海吞浩宇，指化阴阳定浮沤\n此身已证混元体，重写鸿蒙造化筹",
            "太虚紫气贯长空，「{0}」证道显神通\n九转玄功吞日月，混元剑意破鸿蒙\n掌纳诸天无穷界，身映星海亿万重\n今立道极最高处，方知我即造化宗",
            "玄冰劫火淬道心，「{0}」挥袖断光阴\n脐下混沌开天地，眉间星海映浮沉\n三千道藏化虹幕，八万魔尊俱俯音\n此身即道道即我，万劫不磨永称今",
            "洪荒龙脉铸仙基，「{0}」吐纳炼玄微\n九转金丹吞浩宇，混元道炁化虹飞\n掌托阴阳分清浊，足踏混沌定玄机\n今朝已越轮回外，永镇乾坤造化碑",
            "归墟潮涌证道时，「{0}」擎天立劫池\n剑斩因果三千界，鼎镇阴阳十二支\n血染星河九万转，魂渡玄黄十万罹\n此身已证混元体，永驻太虚掌劫辞",
            "混沌青莲绽灵台，「{0}」叩关显道才\n骨化天柱撑四维，血涌长河贯九垓\n一念真空生万物，双眸星海映诸埃\n今立鸿蒙最高境，方知我即道本来"
           
        };

        public static bool flair8_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」灵魂已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair8");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 添加随机 flair 特质
            string[] flairTraits = { "flair3", "flair4", "flair5" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            a.addTrait(selectedFlair);

            // 创建新单位并设置属性
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 触发特效
            new PowerLibrary().divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            int currentRresurrectionCount = (int)a.GetRresurrection();
            int currentResurrectionCount = (int)a.GetResurrection();
            if (a.GetResurrection() <= 1) // 检查GetResurrection值，如果为1则不执行复活
            {
                string roleName = a.getName();
                string tip = "「" + roleName + "」真灵已被「轮回之渊」吞噬" ;
                ActionLibrary.showWhisperTip(tip);
                return false;
            }

            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));
                
            a.addTrait("flair91");
            a.addTrait("flair5");
            activeMeditations.ForEach(t => a.addTrait(t));

            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(pTarget.a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            // 调整复活计数
            act.ChangeResurrection(currentResurrectionCount - 1);
            act.ChangeRresurrection(currentRresurrectionCount + 1);
            // 特效触发
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);
            return true;
        }
        public static bool flair92_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            // 检查是否有meditationTraits
            var meditationTraits = new[] { "meditation1", "meditation2", "meditation3" };
            var activeMeditations = meditationTraits.Where(t => a.hasTrait(t)).ToList();
            //移除所有特质 + 特定负面特质（合并操作）
            new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague" }
                .Concat(a.getTraits().Select(t => t.getId()))
                .ToList().ForEach(t => a.removeTrait(t));

            a.addTrait("flair92");
            activeMeditations.ForEach(t => a.addTrait(t));
            // 随机选择新特质并添加（同时保留到新单位）
            string[] flairTraits = { "flair3", "flair4", "flair5", "flair6", "talent1", "talent2", "talent3", "talent4", "blessed", "flower_prints" };
            string selectedFlair = flairTraits[UnityEngine.Random.Range(0, flairTraits.Length)];
            a.addTrait(selectedFlair);
            // 创建新单位
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            // 名称清洗（优化为链式操作）
            act.data.setName(new[] { " 圣体", " 道胎" }
                        .Aggregate(a.getName(), (name, keyword) => name.Replace(keyword, "")));
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 8;
            act.data.level = 5;
            teleportRandom(act);
            act.ChangeRresurrection(a.GetRresurrection() + 1);
            // 特效触发
            new PowerLibrary().divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool Grade91_death(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            Grade91_Action(a);
            return true;
        }
        private static bool Grade91_Action(Actor a)
        {
            // 首先计算所有存活的小人总数
            int totalAliveCount = 0;
            List<Actor> simpleList = World.world.units.getSimpleList();
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive())
                {
                    totalAliveCount++;
                    // 所有存活且有相应特质的增加源能和无根之源
                    if (actor.hasTrait("flair1") || actor.hasTrait("flair2") || actor.hasTrait("flair3") ||
                        actor.hasTrait("flair4") || actor.hasTrait("flair5") || actor.hasTrait("flair6") || actor.hasTrait("flair7"))
                    {
                        // 随机增加50~100源能
                        int yuanNengIncrease = UnityEngine.Random.Range(50, 101);
                        actor.ChangeYuanNeng(yuanNengIncrease);
                    }
                    if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
                    {
                        // 随机增加500~1000无根之源
                        int meditationIncrease = UnityEngine.Random.Range(500, 1001);
                        actor.ChangeMeditation(meditationIncrease);
                    }
                }
            }
            
            int num = 0;
            foreach (Actor actor in simpleList)
            {
                if (actor.isAlive() && !actor.data.favorite && !actor.asset.ignored_by_infinity_coin)
                {
                    num++;
                }
            }

            int num2 = (int)Math.Ceiling(num * 0.30); // 计算30%的小人数量
            int num3 = 0;

            EffectInfinityCoin._temp_list.Clear();
            EffectInfinityCoin._temp_list.AddRange(World.world.units);
            EffectInfinityCoin._temp_list.Shuffle<Actor>();
            foreach (Actor actor2 in EffectInfinityCoin._temp_list)
            {
                if (num2 == 0)
                {
                    break;
                }
                if (actor2.isAlive() && !actor2.data.favorite && !actor2.asset.ignored_by_infinity_coin)
                {
                    num3++;
                    num2--;
                    actor2.getHit((float)(actor2.data.health * 1000 + 1), true, AttackType.Other, null, false, false);
                }
            }

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(Grade91deathTips.Count);
            string tip = Grade91deathTips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        private static readonly List<string> Grade91deathTips = new List<string>
        {
            "「{0}」道体化飞烟，混元道果散诸天。虽遭劫难身暂殒，真灵不灭待重燃。\n三清圣境留残影，混沌深处蕴生机。待到天地重开日，再掌乾坤立新篇。",
            "「{0}」道躯显真灵，虽散乾坤意未停。元神化作三千念，各寻机缘待成形。\n九幽深处藏玄机，三十三天留道印。重聚神魂归本位，再演混元破天经。",
            "「{0}」身遭劫火焚，道果化作漫天星。九天之上留光影，九泉之下存道根。\n虽暂离世去，道意永存宇宙心。待到涅槃劫火熄，重生再造混元身。",
            "「{0}」道体显化终，混元道种散苍穹。虽暂入轮回道，真我本意未曾空。\n三界六道留踪迹，九幽十方藏玄功。待得时机成熟日，重证混元掌天宗。",
            "「{0}」身化万千星，道体归寂显玄冥。虽暂离三界外，混元本性未曾泯。\n周天星斗留道印，混沌虚空蕴真灵。待时重聚道体日，再演混元破劫经。",
            "「{0}」道躯遭道劫，混元道果显真形。虽暂离世间去，天地永记混元名。\n三界六道留道韵，三十三天蕴道音。待到劫数轮回转，重铸道体掌天心。",
            "「{0}」道消星海间，混元灵光化三千。九幽黄泉藏道种，三十三天孕真玄。\n轮回百转道心在，劫火千焚本性全。待得紫气东来日，重开混沌掌乾元",
            "「{0}」身陨道未终，真灵分化入鸿蒙。太虚深处藏道印，归墟海眼蕴神通。\n九转轮回磨道性，三灾涅槃炼真容。他日灵光重聚时，再镇诸天万界中",
            "「{0}」道体归太虚，混元灵识化星雨。混沌海眼藏真性，造化玉碟记玄机。\n虽经无量量劫灭，犹存先天一点曦。待得乾坤重启日，重演大道立新规",
            "「{0}」劫灭道身消，真灵化虹贯九霄。周天星斗铭道韵，天地灵脉孕神苗。\n三清圣境留残影，万佛净土藏道标。涅槃劫尽归来日，重定阴阳掌六道",
            "「{0}」道陨天地恸，混元灵光散苍穹。血染星河成道种，魂渡归墟化鸿蒙。\n九幽十殿留名讳，三十三天刻真容。待得轮回重启日，再开混沌演神通",
            "「{0}」身化太初炁，混元道果散寰宇。先天紫气藏真性，造化玉碟录玄机。\n九转涅槃劫火炼，三生化道因果迷。待到星海重聚日，再掌乾坤定玄虚",
            "「{0}」道消混沌海，真灵分化三千外。九重天阙留道印，十八地狱刻真骸。\n轮回百世磨道性，劫火万载炼灵胎。待到星移斗转日，重开天地掌劫来",
            "「{0}」陨落显道真，混元灵光化星辰。黄泉路上种道莲，三生石前刻真文。\n九转轮回存本性，万劫加身炼道魂。待得天地重开际，再临诸天镇乾坤",
            "「{0}」道体归寂灭，混元灵识化风雪。太虚秘境藏道种，混沌海眼孕真诀。\n九幽深处留残影，紫府天宫刻真页。待得涅槃劫尽时，重掌阴阳破天阙",
            "「{0}」身陨道不消，真灵分化入六道。周天星斗铭道韵，九幽黄泉刻真标。\n轮回百转存道性，劫火千焚炼灵苗。待到紫气东来日，重开混沌演玄妙",
            "「{0}」劫灭显道真，混元灵光散乾坤。先天八卦藏道种，后天五行孕灵根。\n九转轮回存道印，三生化劫炼真魂。待得星海重聚日，再临诸天掌道门",
            "「{0}」道体化飞灰，混元灵识入轮回。三生石上刻真印，六道轮中藏玄机。\n九幽深处孕道种，三十三天养灵胚。待得涅槃劫尽日，重开天地立道威",
            "「{0}」陨落道犹存，真灵分化万千痕。周天星斗蕴道韵，天地灵脉养神魂。\n九转劫火炼真性，三生化道悟玄门。待得紫气重聚日，再掌混沌定乾坤",
            "「{0}」道消混沌中，混元灵光贯长空。九重天外留道印，十八狱底刻真容。\n轮回百世存本性，劫火万载炼神通。待得星移斗转日，重开天地掌鸿蒙",
            "「{0}」身陨道不终，真灵分化入鸿蒙。太虚深处藏道种，时空长河孕灵通。\n九转轮回磨道印，三生化劫炼真功。待得涅槃劫尽日，重临诸天镇苍穹"

        };
        public static bool teleportRandom(Actor a)
        {
            MapBox mapBox = World.world as MapBox;
            if (mapBox == null)
            {
                return false;
            }

            CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
            if (citiesManager == null)
            {
                return false;
            }

            List<City> cities = citiesManager.list;
            if (cities.Count == 0)
            {
                return false;
            }

            int randomIndex = UnityEngine.Random.Range(0, citiesManager.list.Count);
            City randomCity = citiesManager.list[randomIndex];

            WorldTile cityCenterTile = randomCity.getTile();
            if (cityCenterTile == null || cityCenterTile.Type.block || !cityCenterTile.Type.ground)
            {
                return false;
            }

            a.cancelAllBeh();
            a.spawnOn(cityCenterTile, 0f);
            return true;
        }
        public static bool flair6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("圣体"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("NewSS");
                        pTarget.a.data.setName(pTarget.a.getName() + " 圣体");
                        actorTipsShown[pTarget.a] = (true, tipsShown.hasShownSSSTip); // 更新状态
                    }
                    return false;
                }
            }
            return true;
        }
        public static bool flair7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health != pTarget.getMaxHealth())
            {
                pTarget.a.restoreHealth(60);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool SSS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("道胎"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(VideoCopilotClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("NewSSS");
                        pTarget.a.data.setName(pTarget.a.getName() + " 道胎");
                        actorTipsShown[pTarget.a] = (tipsShown.hasShownSSTip, true); // 更新状态
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }
        private static Dictionary<Actor, (bool hasShownSSTip, bool hasShownSSSTip)> actorTipsShown = new Dictionary<Actor, (bool, bool)>();
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(string   old_trait, string new_trait, Actor actor, string[] other_Oldtraits = null,
                                   string[] other_newTrait = null)
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}