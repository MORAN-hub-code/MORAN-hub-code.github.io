using System.Collections.Generic;

namespace VideoCopilot.code;

public class Globals
{

    public static float Tsotw;
    public static float baseTsotw;
    public static float TsotwAdd = 1000;
    public static string WorldName = "null";
    public static Dictionary<string,Actor> Actors = new Dictionary<string, Actor>();



}
