﻿
using HarmonyLib;
using NeoModLoader.api;
using Cultivatingimmortals.code;
using Cultivatingimmortals.code.window;


namespace Cultivatingimmortals
{
#if TEST
    internal class CultivatingimmortalsClass : BasicMod<CultivatingimmortalsClass>,IReloadable
    {
        public static ModDeclare modDeclare;
        public static ModConfig config;
        public static string id = "shiyue.worldbox.mod.Cultivatingimmortals";

        protected override void OnModLoad()
        {            
            Config.isEditor = true;
            stats.Init();
            traitGroup.Init();
            traits.Init();
            SorceryEffect.Init();
            UI.Init();
            modDeclare = GetDeclaration();
            config = GetConfig();
            
            WindowManager.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }

        public void Reload()
        {
            
        }
    }
#else
    internal class CultivatingimmortalsClass : BasicMod<CultivatingimmortalsClass>
    {
        public static ModDeclare modDeclare;
        public static ModConfig config;
        public static string id = "shiyue.worldbox.mod.Cultivatingimmortals";

        protected override void OnModLoad()
        {
            Config.isEditor = true;
            stats.Init();
            traitGroup.Init();
            traits.Init();
            SorceryEffect.Init();
            UI.Init();
            modDeclare = GetDeclaration();
            config = GetConfig();

            WindowManager.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }
    }
#endif
}