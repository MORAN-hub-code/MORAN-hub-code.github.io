using ReflectionUtility;
using UnityEngine;
using System.Collections.Generic;


namespace Cultivatingimmortals.code.window;

public class WindowManager
{
    public static void Init()
    {
        AutoUpdate.Init();
        window_init();
        // TODO: 排行榜重做
        // window_attack.Init();
        UiPanelInfo.Init();
        XingKongShe.Init();
        
    }

    public static void window_init()
    {
        Dictionary<string, ScrollWindow> allWindows = (Dictionary<string, ScrollWindow>)Reflection.GetField(typeof(ScrollWindow), null, "_all_windows");
        // Reflection.CallStaticMethod(typeof(ScrollWindow), "checkWindowExist", "inspect_unit");
        // allWindows["inspect_unit"].gameObject.SetActive(false);
        // Reflection.CallStaticMethod(typeof(ScrollWindow), "checkWindowExist", "village");
        // allWindows["village"].gameObject.SetActive(false);
        // Reflection.CallStaticMethod(typeof(ScrollWindow), "checkWindowExist", "debug");
        // allWindows["debug"].gameObject.SetActive(false);
        // Reflection.CallStaticMethod(typeof(ScrollWindow), "checkWindowExist", "kingdom");
        // allWindows["kingdom"].gameObject.SetActive(false);
    }
}