//========= MODERNBOX 2.1.0.1 ============//
//
// Made by Tuxxego
//
//=============================================================================//
using System;
using tools;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using System.Text.RegularExpressions;
using Beebyte.Obfuscator;
using ai;
using ai.behaviours;

namespace M3
{
    public static class CustomItemsList
    {
        public static List<ItemAsset> CustomWeapons = new List<ItemAsset>();
        public static List<ItemAsset> CustomArmors = new List<ItemAsset>();
        public static List<ItemAsset> CustomHelmets = new List<ItemAsset>();
        public static List<ItemAsset> CustomBoots = new List<ItemAsset>();
        public static List<ItemAsset> CustomEquipment = new List<ItemAsset>();

        public static void InitCustomItems()
        {
            if (!AssetManager.items.dict.ContainsKey("Glock17"))
                return;

            CustomWeapons.Add(AssetManager.items.get("Glock17"));
            CustomWeapons.Add(AssetManager.items.get("AK"));
            CustomWeapons.Add(AssetManager.items.get("RPG"));
            CustomWeapons.Add(AssetManager.items.get("Minigun"));
            CustomWeapons.Add(AssetManager.items.get("Sniper"));
            CustomWeapons.Add(AssetManager.items.get("FAMAS"));
            CustomWeapons.Add(AssetManager.items.get("M4A1"));
            CustomWeapons.Add(AssetManager.items.get("ThompsonM1A1"));
            CustomWeapons.Add(AssetManager.items.get("SGT44"));
            CustomWeapons.Add(AssetManager.items.get("XM8"));
            CustomWeapons.Add(AssetManager.items.get("AK103"));
            CustomWeapons.Add(AssetManager.items.get("Uzi"));
            CustomWeapons.Add(AssetManager.items.get("Malorian"));
            CustomWeapons.Add(AssetManager.items.get("DesertEagle"));
            CustomWeapons.Add(AssetManager.items.get("M16"));
            CustomWeapons.Add(AssetManager.items.get("HK416"));
            CustomWeapons.Add(AssetManager.items.get("MP7"));
            CustomWeapons.Add(AssetManager.items.get("M32"));
            CustomWeapons.Add(AssetManager.items.get("Sluggershotgun"));
            CustomWeapons.Add(AssetManager.items.get("Americanshotgun"));


            CustomArmors.Add(AssetManager.items.get("modernarmor"));

            CustomHelmets.Add(AssetManager.items.get("modernhelmet"));

            CustomBoots.Add(AssetManager.items.get("modernboots"));

            CustomEquipment.Add(AssetManager.items.get("grenadebelt"));
            CustomEquipment.Add(AssetManager.items.get("medicpack"));
        }

        public static List<ItemAsset> GetCustomItemsForType(EquipmentType pType)
        {
            switch (pType)
            {
                case EquipmentType.Weapon:
                    return CustomWeapons;
                case EquipmentType.Armor:
                    return CustomArmors;
                case EquipmentType.Helmet:
                    return CustomHelmets;
                case EquipmentType.Boots:
                    return CustomBoots;
                default:
                    return CustomEquipment;
            }
        }
    }

    [HarmonyPatch(typeof(ItemCrafting), "craftItem")]
    public class Patch_ItemCrafting_PrioritizeCustomItems
    {
        static bool Prefix(ref bool __result, Actor pActor, string pCreatorName, EquipmentType pType, int pTries, City pCity)
        {
            if (CustomItemsList.CustomWeapons.Count == 0)
                CustomItemsList.InitCustomItems();

            List<ItemAsset> customItems = CustomItemsList.GetCustomItemsForType(pType);

            if (customItems.Count == 0)
                return true;

            ActorEquipmentSlot tActorSlot = pActor.equipment.getSlot(pType);
            int tCurrentItemValue = tActorSlot.getItem()?.asset.equipment_value ?? 0;

            ItemAsset tItemAssetToCraft = null;
            foreach (ItemAsset item in customItems)
            {
                if (item != null && item.equipment_value > tCurrentItemValue && hasEnoughResourcesToCraft(pActor, item, pCity))
                {
                    tItemAssetToCraft = item;
                    break;
                }
            }

            if (tItemAssetToCraft == null)
                return true;

            Item tItem = World.world.items.generateItem(tItemAssetToCraft, pActor.kingdom, pCreatorName, pTries, pActor);

            if (tActorSlot.isEmpty())
            {
                tActorSlot.setItem(tItem, pActor);
            }
            else
            {
                Item tOldItem = tActorSlot.getItem();
                tActorSlot.takeAwayItemFromSlot();
                pCity.tryToPutItem(tOldItem);
                tActorSlot.setItem(tItem, pActor);
            }

            pActor.spendMoney(tItemAssetToCraft.get_total_cost);
            if (tItemAssetToCraft.cost_resource_id_1 != "none")
            {
                pCity.takeResource(tItemAssetToCraft.cost_resource_id_1, tItemAssetToCraft.cost_resource_1);
            }
            if (tItemAssetToCraft.cost_resource_id_2 != "none")
            {
                pCity.takeResource(tItemAssetToCraft.cost_resource_id_2, tItemAssetToCraft.cost_resource_2);
            }

            __result = true;
            return false;
        }

        private static bool hasEnoughResourcesToCraft(Actor pActor, ItemAsset pAsset, City pCity)
        {
            int tTotalCost = pAsset.get_total_cost;
            if (!pActor.hasEnoughMoney(tTotalCost))
            {
                return false;
            }
            if (pAsset.cost_resource_id_1 != "none" && pAsset.cost_resource_1 > pCity.getResourcesAmount(pAsset.cost_resource_id_1))
            {
                return false;
            }
            if (pAsset.cost_resource_id_2 != "none" && pAsset.cost_resource_2 > pCity.getResourcesAmount(pAsset.cost_resource_id_2))
            {
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(Culture), "getPreferredWeaponSubtypeIDs")]
    public class Patch_Culture_PreferredWeaponSubtypes
    {
        static bool Prefix(ref string __result)
        {
            if (CustomItemsList.CustomWeapons.Count > 0)
            {
                __result = "stick";
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(Culture), "getPreferredWeaponAssets")]
    public class Patch_Culture_PreferredWeaponAssets
    {
        static bool Prefix(ref List<ItemAsset> __result)
        {
            if (CustomItemsList.CustomWeapons.Count > 0)
            {
                __result = CustomItemsList.CustomWeapons;
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(Culture), "hasPreferredWeaponsToCraft")]
    public class Patch_Culture_HasPreferredWeaponsToCraft
    {
        static bool Prefix(ref bool __result)
        {
            if (CustomItemsList.CustomWeapons.Count > 0)
            {
                __result = true;
                return false;
            }
            return true;
        }
    }

    [HarmonyPatch(typeof(ItemLibrary), "fillSubtypesAndGroups")]
    public class Patch_ItemLibrary_FillSubtypesAndGroups
    {
        static void Postfix(ItemLibrary __instance)
        {

            if (!__instance.equipment_by_subtypes.ContainsKey("firearm"))
            {
                __instance.equipment_by_subtypes.Add("firearm", new List<ItemAsset>());
            }

            if (__instance.dict.ContainsKey("Glock17"))
            {
                ItemAsset glock = __instance.get("Glock17");
                if (!__instance.equipment_by_subtypes["firearm"].Contains(glock))
                {
                    __instance.equipment_by_subtypes["firearm"].Add(glock);
                }
            }

            if (__instance.dict.ContainsKey("AK"))
            {
                ItemAsset ak = __instance.get("AK");
                if (!__instance.equipment_by_subtypes["firearm"].Contains(ak))
                {
                    __instance.equipment_by_subtypes["firearm"].Add(ak);
                }
            }

            if (__instance.dict.ContainsKey("RPG"))
            {
                ItemAsset rpg = __instance.get("RPG");
                if (!__instance.equipment_by_subtypes["firearm"].Contains(rpg))
                {
                    __instance.equipment_by_subtypes["firearm"].Add(rpg);
                }
            }

            if (!__instance.equipment_by_subtypes.ContainsKey("stick"))
            {
                __instance.equipment_by_subtypes.Add("stick", new List<ItemAsset>());
            }

            if (__instance.dict.ContainsKey("Glock17"))
            {
                ItemAsset glock = __instance.get("Glock17");
                if (!__instance.equipment_by_subtypes["stick"].Contains(glock))
                {
                    __instance.equipment_by_subtypes["stick"].Add(glock);
                }
            }
        }
    }

    class WeaponsProjectilesEffects : MonoBehaviour
    {
        public static void init()
        {
            WeaponsAndStuff();
        }

        private static void WeaponsAndStuff()
        {
            // Culture Trait
            //
            //=============================================================================//

            // Guns
            //
            //=============================================================================//

            ItemAsset Glock17 = AssetManager.items.clone("Glock17", "$range");
            Glock17.equipment_type = EquipmentType.Weapon;
            Glock17.equipment_subtype = "stick";
            Glock17.translation_key = "Glock17, the bestest gun";
            Glock17.material = "basic";
            Glock17.group_id = "firearm";
            Glock17.metallic = true;
            Glock17.setCost(0, "wood", 1);
            Glock17.minimum_city_storage_resource_1 = 1;
            Glock17.rigidity_rating = 4;
            Glock17.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            Glock17.is_pool_weapon = true;
            Glock17.pool_rate = 15;
            Glock17.path_icon = "ui/icons/items/icon_Glock17";
            Glock17.projectile = "shotgun_bullet";
            Glock17.path_slash_animation = "effects/slashes/slash_punch";
            Glock17.base_stats["projectiles"] = 1f;
            Glock17.base_stats["attack_speed"] = 0f;
            Glock17.base_stats["accuracy"] = 0.5f;
            Glock17.base_stats["damage"] = 30f;
            Glock17.base_stats["critical_chance"] = 0.3f;
            Glock17.base_stats["critical_damage_multiplier"] = 0.5f;
            Glock17.base_stats["recoil"] = 1f;
            Glock17.base_stats["range"] = 8f;
            Glock17.base_stats["targets"] = 1f;
            Glock17.base_stats["damage_range"] = 0.9f;
            Glock17.base_stats["mana"] = 10f;
            Glock17.base_stats["stamina"] = 10f;
            Glock17.equipment_value = 700;
            AssetManager.items.add(Glock17);
            AssetManager.items.pool_weapon_assets_all.Add(Glock17);
            AssetManager.items.pool_weapon_assets_unlocked.Add(Glock17);
            addWeaponsSprite(Glock17.id);

ItemAsset Malorian = AssetManager.items.clone("Malorian", "$range");
Malorian.equipment_type = EquipmentType.Weapon;
Malorian.translation_key = "Malorian Arms 3516";
Malorian.equipment_subtype = "stick";
Malorian.material = "basic";
Malorian.group_id = "firearm";
Malorian.metallic = true;
Malorian.setCost(0, "adamantine", 1, "gems", 1);
Malorian.minimum_city_storage_resource_1 = 1;
Malorian.rigidity_rating = 5;
Malorian.is_pool_weapon = true;
Malorian.pool_rate = 15;
Malorian.path_icon = "ui/icons/items/icon_Malorian";
Malorian.projectile = "shotgun_bullet";
Malorian.path_slash_animation = "effects/slashes/slash_punch";
Malorian.base_stats["projectiles"] = 1f;
Malorian.base_stats["attack_speed"] = 2f;
Malorian.base_stats["accuracy"] = 0.75f;
Malorian.base_stats["damage"] = 75f;
Malorian.base_stats["critical_chance"] = 0.4f;
Malorian.base_stats["critical_damage_multiplier"] = 0.6f;
Malorian.base_stats["recoil"] = 0.5f;
Malorian.base_stats["range"] = 12f;
Malorian.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
Malorian.base_stats["targets"] = 1f;
Malorian.base_stats["damage_range"] = 0.9f;
Malorian.base_stats["mana"] = 25f;
Malorian.base_stats["stamina"] = 15f;
Malorian.equipment_value = 975;
AssetManager.items.add(Malorian);
AssetManager.items.pool_weapon_assets_all.Add(Malorian);
AssetManager.items.pool_weapon_assets_unlocked.Add(Malorian);
addWeaponsSprite(Malorian.id);

ItemAsset DesertEagle = AssetManager.items.clone("DesertEagle", "$range");
DesertEagle.equipment_type = EquipmentType.Weapon;
DesertEagle.translation_key = "Desert Eagle Mark XIX";
DesertEagle.equipment_subtype = "stick";
DesertEagle.material = "basic";
DesertEagle.group_id = "firearm";
DesertEagle.metallic = true;
DesertEagle.setCost(0, "common_metals", 1);
DesertEagle.minimum_city_storage_resource_1 = 1;
DesertEagle.rigidity_rating = 5;
DesertEagle.is_pool_weapon = true;
DesertEagle.pool_rate = 15;
DesertEagle.path_icon = "ui/icons/items/icon_DesertEagle";
DesertEagle.projectile = "shotgun_bullet";
DesertEagle.path_slash_animation = "effects/slashes/slash_punch";
DesertEagle.base_stats["projectiles"] = 1f;
DesertEagle.base_stats["attack_speed"] = -2f;
DesertEagle.base_stats["accuracy"] = 0.7f;
DesertEagle.base_stats["damage"] = 50f;
DesertEagle.base_stats["critical_chance"] = 0.35f;
DesertEagle.base_stats["critical_damage_multiplier"] = 0.5f;
DesertEagle.base_stats["recoil"] = 1f;
DesertEagle.base_stats["range"] = 10f;
DesertEagle.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
DesertEagle.base_stats["targets"] = 1f;
DesertEagle.base_stats["damage_range"] = 0.8f;
DesertEagle.base_stats["mana"] = 12f;
DesertEagle.base_stats["stamina"] = 12f;
DesertEagle.equipment_value = 725;
AssetManager.items.add(DesertEagle);
AssetManager.items.pool_weapon_assets_all.Add(DesertEagle);
AssetManager.items.pool_weapon_assets_unlocked.Add(DesertEagle);
addWeaponsSprite(DesertEagle.id);

            ItemAsset AK = AssetManager.items.clone("AK", "$range");
            AK.equipment_type = EquipmentType.Weapon;
            AK.translation_key = "Avtomat Kalashnikov 47";
            AK.equipment_subtype = "stick";
            AK.material = "basic";
            AK.group_id = "firearm";
            AK.metallic = true;
            AK.setCost(0, "wood", 2);
            AK.minimum_city_storage_resource_1 = 1;
            AK.rigidity_rating = 7;
            AK.is_pool_weapon = true;
            AK.pool_rate = 15;
            AK.path_icon = "ui/icons/items/icon_AK47";
            AK.projectile = "shotgun_bullet";
            AK.path_slash_animation = "effects/slashes/slash_punch";
            AK.base_stats["projectiles"] = 1f;
            AK.base_stats["attack_speed"] = 5f;
            AK.base_stats["accuracy"] = 0.6f;
            AK.base_stats["damage"] = 40f;
            AK.base_stats["critical_chance"] = 0.2f;
            AK.base_stats["critical_damage_multiplier"] = 0.3f;
            AK.base_stats["recoil"] = 0.5f;
            AK.base_stats["range"] = 15f;
             AK.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            AK.base_stats["targets"] = 1f;
            AK.base_stats["damage_range"] = 0.8f;
            AK.base_stats["mana"] = 10f;
            AK.base_stats["stamina"] = 15f;
            AK.equipment_value = 750;
            AssetManager.items.add(AK);
            AssetManager.items.pool_weapon_assets_all.Add(AK);
            AssetManager.items.pool_weapon_assets_unlocked.Add(AK);
            addWeaponsSprite(AK.id);

            ItemAsset Americanshotgun = AssetManager.items.clone("Americanshotgun", "$range");
            Americanshotgun.equipment_type = EquipmentType.Weapon;
            Americanshotgun.translation_key = "Bestest Shotgun";
            Americanshotgun.equipment_subtype = "stick";
            Americanshotgun.material = "basic";
            Americanshotgun.group_id = "firearm";
            Americanshotgun.metallic = true;
            Americanshotgun.setCost(0, "wood", 3);
            Americanshotgun.minimum_city_storage_resource_1 = 1;
            Americanshotgun.rigidity_rating = 3;
            Americanshotgun.is_pool_weapon = true;
            Americanshotgun.pool_rate = 15;
            Americanshotgun.path_icon = "ui/Icons/items/icon_shotgun";
            Americanshotgun.projectile = "shotgun_bullet";
            Americanshotgun.path_slash_animation = "effects/slashes/slash_punch";
            Americanshotgun.base_stats["projectiles"] = 6f;
            Americanshotgun.base_stats["attack_speed"] = -3f;
            Americanshotgun.base_stats["accuracy"] = 0.2f;
            Americanshotgun.base_stats["damage"] = 10f;
            Americanshotgun.base_stats["critical_chance"] = 0.2f;
            Americanshotgun.base_stats["critical_damage_multiplier"] = 0.3f;
            Americanshotgun.base_stats["recoil"] = 1f;
            Americanshotgun.base_stats["range"] = 10f;
            Americanshotgun.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            Americanshotgun.base_stats["targets"] = 1f;
            Americanshotgun.base_stats["damage_range"] = 0.7f;
            Americanshotgun.base_stats["mana"] = 10f;
            Americanshotgun.base_stats["stamina"] = 15f;
            Americanshotgun.equipment_value = 748;
            AssetManager.items.add(Americanshotgun);
            AssetManager.items.pool_weapon_assets_all.Add(Americanshotgun);
            AssetManager.items.pool_weapon_assets_unlocked.Add(Americanshotgun);
            addWeaponsSprite(Americanshotgun.id);

            ItemAsset Sluggershotgun = AssetManager.items.clone("Sluggershotgun", "$range");
            Sluggershotgun.equipment_type = EquipmentType.Weapon;
            Sluggershotgun.translation_key = "Greatest SHotgun";
            Sluggershotgun.equipment_subtype = "stick";
            Sluggershotgun.material = "basic";
            Sluggershotgun.group_id = "firearm";
            Sluggershotgun.metallic = true;
            Sluggershotgun.setCost(0, "wood", 3);
            Sluggershotgun.minimum_city_storage_resource_1 = 1;
            Sluggershotgun.rigidity_rating = 1;
            Sluggershotgun.is_pool_weapon = true;
            Sluggershotgun.pool_rate = 15;
            Sluggershotgun.path_icon = "ui/Icons/items/icon_shotgun";
            Sluggershotgun.projectile = "shotgun_bullet";
            Sluggershotgun.path_slash_animation = "effects/slashes/slash_punch";
            Sluggershotgun.base_stats["projectiles"] = 1f;
            Sluggershotgun.base_stats["attack_speed"] = -3f;
            Sluggershotgun.base_stats["accuracy"] = 0.7f;
            Sluggershotgun.base_stats["damage"] = 80f;
            Sluggershotgun.base_stats["critical_chance"] = 0.2f;
            Sluggershotgun.base_stats["critical_damage_multiplier"] = 4f;
            Sluggershotgun.base_stats["recoil"] = 2f;
            Sluggershotgun.base_stats["range"] = 10f;
            Sluggershotgun.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            Sluggershotgun.base_stats["targets"] = 1f;
            Sluggershotgun.base_stats["damage_range"] = 0.7f;
            Sluggershotgun.base_stats["mana"] = 10f;
            Sluggershotgun.base_stats["stamina"] = 15f;
            Sluggershotgun.equipment_value = 752;
            AssetManager.items.add(Sluggershotgun);
            AssetManager.items.pool_weapon_assets_all.Add(Sluggershotgun);
            AssetManager.items.pool_weapon_assets_unlocked.Add(Sluggershotgun);
            addWeaponsSprite(Sluggershotgun.id);



ItemAsset FAMAS = AssetManager.items.clone("FAMAS", "$range");
FAMAS.equipment_type = EquipmentType.Weapon;
FAMAS.translation_key = "FAMAS F1";
FAMAS.equipment_subtype = "stick";
FAMAS.material = "basic";
FAMAS.group_id = "firearm";
FAMAS.metallic = true;
FAMAS.setCost(0, "common_metals", 2);
FAMAS.minimum_city_storage_resource_1 = 1;
FAMAS.rigidity_rating = 4;
FAMAS.is_pool_weapon = true;
FAMAS.pool_rate = 15;
FAMAS.path_icon = "ui/icons/items/icon_FAMAS";
FAMAS.projectile = "shotgun_bullet";
FAMAS.path_slash_animation = "effects/slashes/slash_punch";
FAMAS.base_stats["projectiles"] = 1f;
FAMAS.base_stats["attack_speed"] = 8f;
FAMAS.base_stats["accuracy"] = 0.65f;
FAMAS.base_stats["damage"] = 35f;
FAMAS.base_stats["critical_chance"] = 0.2f;
FAMAS.base_stats["critical_damage_multiplier"] = 0.3f;
FAMAS.base_stats["recoil"] = 0.7f;
FAMAS.base_stats["range"] = 14f;
FAMAS.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
FAMAS.base_stats["targets"] = 1f;
FAMAS.base_stats["damage_range"] = 0.75f;
FAMAS.base_stats["mana"] = 10f;
FAMAS.base_stats["stamina"] = 15f;
FAMAS.equipment_value = 760;
AssetManager.items.add(FAMAS);
AssetManager.items.pool_weapon_assets_all.Add(FAMAS);
AssetManager.items.pool_weapon_assets_unlocked.Add(FAMAS);
addWeaponsSprite(FAMAS.id);


ItemAsset Uzi = AssetManager.items.clone("Uzi", "$range");
Uzi.equipment_type = EquipmentType.Weapon;
Uzi.translation_key = "Uzi SMG";
Uzi.equipment_subtype = "stick";
Uzi.material = "basic";
Uzi.group_id = "firearm";
Uzi.metallic = true;
Uzi.setCost(0, "common_metals", 1);
Uzi.minimum_city_storage_resource_1 = 1;
Uzi.rigidity_rating = 4;
Uzi.is_pool_weapon = true;
Uzi.pool_rate = 15;
Uzi.path_icon = "ui/icons/items/icon_Uzi";
Uzi.projectile = "shotgun_bullet";
Uzi.path_slash_animation = "effects/slashes/slash_punch";
Uzi.base_stats["projectiles"] = 1f;
Uzi.base_stats["attack_speed"] = 10f;
Uzi.base_stats["accuracy"] = 0.45f;
Uzi.base_stats["damage"] = 25f;
Uzi.base_stats["critical_chance"] = 0.15f;
Uzi.base_stats["critical_damage_multiplier"] = 0.25f;
Uzi.base_stats["recoil"] = 0.9f;
Uzi.base_stats["range"] = 8f;
Uzi.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
Uzi.base_stats["targets"] = 1f;
Uzi.base_stats["damage_range"] = 0.7f;
Uzi.base_stats["mana"] = 8f;
Uzi.base_stats["stamina"] = 10f;
Uzi.equipment_value = 730;
AssetManager.items.add(Uzi);
AssetManager.items.pool_weapon_assets_all.Add(Uzi);
AssetManager.items.pool_weapon_assets_unlocked.Add(Uzi);
addWeaponsSprite(Uzi.id);

ItemAsset MP7 = AssetManager.items.clone("MP7", "$range");
MP7.equipment_type = EquipmentType.Weapon;
MP7.translation_key = "HK MP7";
MP7.equipment_subtype = "stick";
MP7.material = "basic";
MP7.group_id = "firearm";
MP7.metallic = true;
MP7.setCost(0, "common_metals", 1);
MP7.minimum_city_storage_resource_1 = 1;
MP7.rigidity_rating = 5;
MP7.is_pool_weapon = true;
MP7.pool_rate = 15;
MP7.path_icon = "ui/icons/items/icon_MP7";
MP7.projectile = "shotgun_bullet";
MP7.path_slash_animation = "effects/slashes/slash_punch";
MP7.base_stats["projectiles"] = 1f;
MP7.base_stats["attack_speed"] = 9f;
MP7.base_stats["accuracy"] = 0.6f;
MP7.base_stats["damage"] = 28f;
MP7.base_stats["critical_chance"] = 0.2f;
MP7.base_stats["critical_damage_multiplier"] = 0.3f;
MP7.base_stats["recoil"] = 0.4f;
MP7.base_stats["range"] = 9f;
MP7.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
MP7.base_stats["targets"] = 1f;
MP7.base_stats["damage_range"] = 0.75f;
MP7.base_stats["mana"] = 8f;
MP7.base_stats["stamina"] = 10f;
MP7.equipment_value = 740;
AssetManager.items.add(MP7);
AssetManager.items.pool_weapon_assets_all.Add(MP7);
AssetManager.items.pool_weapon_assets_unlocked.Add(MP7);
addWeaponsSprite(MP7.id);


ItemAsset M4A1 = AssetManager.items.clone("M4A1", "$range");
M4A1.equipment_type = EquipmentType.Weapon;
M4A1.translation_key = "M4A1 Carbine";
M4A1.equipment_subtype = "stick";
M4A1.material = "basic";
M4A1.group_id = "firearm";
M4A1.metallic = true;
M4A1.setCost(1, "common_metals", 1);
M4A1.minimum_city_storage_resource_1 = 1;
M4A1.rigidity_rating = 4;
M4A1.is_pool_weapon = true;
M4A1.pool_rate = 15;
M4A1.path_icon = "ui/icons/items/icon_M4A1";
M4A1.projectile = "shotgun_bullet";
M4A1.path_slash_animation = "effects/slashes/slash_punch";
M4A1.base_stats["projectiles"] = 1f;
M4A1.base_stats["attack_speed"] = 6f;
M4A1.base_stats["accuracy"] = 0.7f;
M4A1.base_stats["damage"] = 38f;
M4A1.base_stats["critical_chance"] = 0.2f;
M4A1.base_stats["critical_damage_multiplier"] = 0.3f;
M4A1.base_stats["recoil"] = 0.4f;
M4A1.base_stats["range"] = 14f;
M4A1.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
M4A1.base_stats["targets"] = 1f;
M4A1.base_stats["damage_range"] = 0.8f;
M4A1.base_stats["mana"] = 10f;
M4A1.base_stats["stamina"] = 12f;
M4A1.equipment_value = 844;
AssetManager.items.add(M4A1);
AssetManager.items.pool_weapon_assets_all.Add(M4A1);
AssetManager.items.pool_weapon_assets_unlocked.Add(M4A1);
addWeaponsSprite(M4A1.id);



          ProjectileAsset RPGload = new ProjectileAsset();
          RPGload.id = "RPGload";
          RPGload.texture = "RPGload";
          RPGload.trail_effect_enabled = false;
          RPGload.trigger_on_collision = true;
	      RPGload.look_at_target = true;
          RPGload.draw_light_area = true;
	      RPGload.draw_light_size = 0.1f;
          RPGload.end_effect = "fx_fireball_explosion";
          RPGload.terraform_option = "demon_fireball";
          RPGload.terraform_range = 3;
          RPGload.scale_start = 0.1f;
          RPGload.scale_target = 0.1f;
          RPGload.speed = 20f;
          RPGload.can_be_left_on_ground = true;
          RPGload.can_be_blocked = true;
          AssetManager.projectiles.add(RPGload);

            ItemAsset RPG = AssetManager.items.clone("RPG", "$range");
            RPG.equipment_type = EquipmentType.Weapon;
            RPG.translation_key = "Rocket-propelled grenade";
            RPG.equipment_subtype = "stick";
            RPG.material = "basic";
            RPG.group_id = "firearm";
            RPG.metallic = true;
            RPG.setCost(1, "wood", 3);
            RPG.minimum_city_storage_resource_1 = 1;
            RPG.rigidity_rating = 1;
            RPG.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            RPG.is_pool_weapon = true;
            RPG.pool_rate = 15;
            RPG.path_icon = "ui/icons/items/icon_RocketLauncher";
            RPG.projectile = "RPGload";
            RPG.path_slash_animation = "effects/slashes/slash_punch";
            RPG.base_stats["projectiles"] = 1f;
            RPG.base_stats["accuracy"] = 0.7f;
            RPG.base_stats["attack_speed"] = -5f;
            RPG.base_stats["damage"] = 100f;
            RPG.base_stats["critical_chance"] = 0.5f;
            RPG.base_stats["critical_damage_multiplier"] = 0.5f;
            RPG.base_stats["recoil"] = 2f;
            RPG.base_stats["range"] = 20f;
            RPG.base_stats["targets"] = 3f;
            RPG.base_stats["damage_range"] = 0.7f;
            RPG.base_stats["mana"] = 10f;
            RPG.base_stats["stamina"] = 20f;
            RPG.equipment_value = 800;
            AssetManager.items.add(RPG);
            AssetManager.items.pool_weapon_assets_all.Add(RPG);
            AssetManager.items.pool_weapon_assets_unlocked.Add(RPG);
            addWeaponsSprite(RPG.id);

            ItemAsset Minigun = AssetManager.items.clone("Minigun", "$range");
            Minigun.equipment_type = EquipmentType.Weapon;
            Minigun.translation_key = "Minigun";
            Minigun.animated = true;
            Minigun.equipment_subtype = "stick";
            Minigun.material = "basic";
            Minigun.group_id = "firearm";
            Minigun.metallic = true;
            Minigun.setCost(2, "wood", 4);
            Minigun.minimum_city_storage_resource_1 = 1;
            Minigun.rigidity_rating = 3;
            Minigun.is_pool_weapon = true;
            Minigun.pool_rate = 15;
            Minigun.path_icon = "ui/icons/items/icon_Minigun";
            Minigun.projectile = "shotgun_bullet";
            Minigun.path_slash_animation = "effects/slashes/slash_punch";
            Minigun.base_stats["projectiles"] = 1f;
            Minigun.base_stats["attack_speed"] = 20000f;
            Minigun.base_stats["accuracy"] = 0.3f;
            Minigun.base_stats["damage"] = 20f;
            Minigun.base_stats["critical_chance"] = 0.2f;
            Minigun.base_stats["critical_damage_multiplier"] = 0.3f;
            Minigun.base_stats["recoil"] = 0f;
            Minigun.base_stats["range"] = 15f;
             Minigun.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            Minigun.base_stats["targets"] = 1f;
            Minigun.base_stats["damage_range"] = 0.8f;
            Minigun.base_stats["mana"] = 10f;
            Minigun.base_stats["stamina"] = 15f;
            Minigun.equipment_value = 850;
            AssetManager.items.add(Minigun);
            AssetManager.items.pool_weapon_assets_all.Add(Minigun);
            AssetManager.items.pool_weapon_assets_unlocked.Add(Minigun);
            addWeaponsSprite(Minigun.id);

                        ItemAsset Sniper = AssetManager.items.clone("Sniper", "$range");
            Sniper.equipment_type = EquipmentType.Weapon;
            Sniper.translation_key = "Sniper";
            Sniper.animated = false;
            Sniper.equipment_subtype = "stick";
            Sniper.material = "basic";
            Sniper.group_id = "firearm";
            Sniper.metallic = true;
            Sniper.setCost(3, "wood", 5);
            Sniper.minimum_city_storage_resource_1 = 1;
            Sniper.rigidity_rating = 1;
            Sniper.is_pool_weapon = true;
            Sniper.pool_rate = 15;
            Sniper.path_icon = "ui/icons/items/icon_Sniper";
            Sniper.projectile = "shotgun_bullet";
            Sniper.path_slash_animation = "effects/slashes/slash_punch";
            Sniper.base_stats["projectiles"] = 1f;
            Sniper.base_stats["attack_speed"] = -10f;
            Sniper.base_stats["accuracy"] = 4f;
            Sniper.base_stats["damage"] = 300f;
            Sniper.base_stats["critical_chance"] = 0.5f;
            Sniper.base_stats["critical_damage_multiplier"] = 0.8f;
            Sniper.base_stats["recoil"] = 2f;
            Sniper.base_stats["range"] = 30f;
             Sniper.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            Sniper.base_stats["targets"] = 1f;
            Sniper.base_stats["damage_range"] = 0.1f;
            Sniper.base_stats["mana"] = 10f;
            Sniper.base_stats["stamina"] = 15f;
            Sniper.equipment_value = 900;
            AssetManager.items.add(Sniper);
            AssetManager.items.pool_weapon_assets_all.Add(Sniper);
            AssetManager.items.pool_weapon_assets_unlocked.Add(Sniper);
            addWeaponsSprite(Sniper.id);

            ItemAsset M32 = AssetManager.items.clone("M32", "$range");
            M32.equipment_type = EquipmentType.Weapon;
            M32.translation_key = "M32, the friendly grenade launcher!";
            M32.equipment_subtype = "stick";
            M32.material = "basic";
            M32.group_id = "firearm";
            M32.metallic = true;
            M32.setCost(4, "adamantine", 1);
            M32.minimum_city_storage_resource_1 = 1;
            M32.rigidity_rating = 1;
            M32.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
            M32.is_pool_weapon = true;
            M32.pool_rate = 15;
            M32.path_icon = "ui/icons/items/icon_M32";
            M32.projectile = "cannonball";
            M32.path_slash_animation = "effects/slashes/slash_punch";
            M32.base_stats["projectiles"] = 1f;
            M32.base_stats["accuracy"] = 0.2f;
            M32.base_stats["attack_speed"] = 1f;
            M32.base_stats["damage"] = 70f;
            M32.base_stats["critical_chance"] = 0.5f;
            M32.base_stats["critical_damage_multiplier"] = 0.5f;
            M32.base_stats["recoil"] = 0.5f;
            M32.base_stats["range"] = 8f;
            M32.base_stats["targets"] = 3f;
            M32.base_stats["damage_range"] = 0.7f;
            M32.base_stats["mana"] = 10f;
            M32.base_stats["stamina"] = 20f;
            M32.equipment_value = 950;
            AssetManager.items.add(M32);
            AssetManager.items.pool_weapon_assets_all.Add(M32);
            AssetManager.items.pool_weapon_assets_unlocked.Add(M32);
            addWeaponsSprite(M32.id);


ItemAsset ThompsonM1A1 = AssetManager.items.clone("ThompsonM1A1", "$range");
ThompsonM1A1.equipment_type = EquipmentType.Weapon;
ThompsonM1A1.translation_key = "Thompson M1A1";
ThompsonM1A1.equipment_subtype = "stick";
ThompsonM1A1.material = "basic";
ThompsonM1A1.group_id = "firearm";
ThompsonM1A1.metallic = true;
ThompsonM1A1.setCost(0, "silver", 2);
ThompsonM1A1.minimum_city_storage_resource_1 = 1;
ThompsonM1A1.rigidity_rating = 4;
ThompsonM1A1.is_pool_weapon = true;
ThompsonM1A1.pool_rate = 15;
ThompsonM1A1.path_icon = "ui/icons/items/icon_ThompsonM1A1";
ThompsonM1A1.projectile = "shotgun_bullet";
ThompsonM1A1.path_slash_animation = "effects/slashes/slash_punch";
ThompsonM1A1.base_stats["projectiles"] = 1f;
ThompsonM1A1.base_stats["attack_speed"] = 7f;
ThompsonM1A1.base_stats["accuracy"] = 0.55f;
ThompsonM1A1.base_stats["damage"] = 32f;
ThompsonM1A1.base_stats["critical_chance"] = 0.2f;
ThompsonM1A1.base_stats["critical_damage_multiplier"] = 0.4f;
ThompsonM1A1.base_stats["recoil"] = 0.8f;
ThompsonM1A1.base_stats["range"] = 10f;
ThompsonM1A1.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
ThompsonM1A1.base_stats["targets"] = 1f;
ThompsonM1A1.base_stats["damage_range"] = 0.7f;
ThompsonM1A1.base_stats["mana"] = 10f;
ThompsonM1A1.base_stats["stamina"] = 12f;
ThompsonM1A1.equipment_value = 777;
AssetManager.items.add(ThompsonM1A1);
AssetManager.items.pool_weapon_assets_all.Add(ThompsonM1A1);
AssetManager.items.pool_weapon_assets_unlocked.Add(ThompsonM1A1);
addWeaponsSprite(ThompsonM1A1.id);

ItemAsset shotgun = AssetManager.items.get("shotgun");
shotgun.base_stats["recoil"] = 2f;

ItemAsset SGT44 = AssetManager.items.clone("SGT44", "$range");
SGT44.equipment_type = EquipmentType.Weapon;
SGT44.translation_key = "Sturmgewehr 44";
SGT44.equipment_subtype = "stick";
SGT44.material = "basic";
SGT44.group_id = "firearm";
SGT44.metallic = true;
SGT44.setCost(2, "silver", 1);
SGT44.minimum_city_storage_resource_1 = 1;
SGT44.rigidity_rating = 4;
SGT44.is_pool_weapon = true;
SGT44.pool_rate = 15;
SGT44.path_icon = "ui/icons/items/icon_SGT44";
SGT44.projectile = "shotgun_bullet";
SGT44.path_slash_animation = "effects/slashes/slash_punch";
SGT44.base_stats["projectiles"] = 1f;
SGT44.base_stats["attack_speed"] = 4f;
SGT44.base_stats["accuracy"] = 0.65f;
SGT44.base_stats["damage"] = 45f;
SGT44.base_stats["critical_chance"] = 0.25f;
SGT44.base_stats["critical_damage_multiplier"] = 0.35f;
SGT44.base_stats["recoil"] = 0.6f;
SGT44.base_stats["range"] = 13f;
SGT44.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
SGT44.base_stats["targets"] = 1f;
SGT44.base_stats["damage_range"] = 0.75f;
SGT44.base_stats["mana"] = 15f;
SGT44.base_stats["stamina"] = 18f;
SGT44.equipment_value = 885;
AssetManager.items.add(SGT44);
AssetManager.items.pool_weapon_assets_all.Add(SGT44);
AssetManager.items.pool_weapon_assets_unlocked.Add(SGT44);
addWeaponsSprite(SGT44.id);

ItemAsset XM8 = AssetManager.items.clone("XM8", "$range");
XM8.equipment_type = EquipmentType.Weapon;
XM8.translation_key = "XM8 Prototype";
XM8.equipment_subtype = "stick";
XM8.material = "basic";
XM8.group_id = "firearm";
XM8.metallic = true;
XM8.setCost(0, "common_metals", 2);
XM8.minimum_city_storage_resource_1 = 1;
XM8.rigidity_rating = 4;
XM8.is_pool_weapon = true;
XM8.pool_rate = 15;
XM8.path_icon = "ui/icons/items/icon_XM8";
XM8.projectile = "shotgun_bullet";
XM8.path_slash_animation = "effects/slashes/slash_punch";
XM8.base_stats["projectiles"] = 1f;
XM8.base_stats["attack_speed"] = 5f;
XM8.base_stats["accuracy"] = 0.8f;
XM8.base_stats["damage"] = 37f;
XM8.base_stats["critical_chance"] = 0.3f;
XM8.base_stats["critical_damage_multiplier"] = 0.4f;
XM8.base_stats["recoil"] = 0.3f;
XM8.base_stats["range"] = 16f;
XM8.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
XM8.base_stats["targets"] = 1f;
XM8.base_stats["damage_range"] = 0.85f;
XM8.base_stats["mana"] = 10f;
XM8.base_stats["stamina"] = 14f;
XM8.equipment_value = 790;
AssetManager.items.add(XM8);
AssetManager.items.pool_weapon_assets_all.Add(XM8);
AssetManager.items.pool_weapon_assets_unlocked.Add(XM8);
addWeaponsSprite(XM8.id);

ItemAsset AK103 = AssetManager.items.clone("AK103", "$range");
AK103.equipment_type = EquipmentType.Weapon;
AK103.translation_key = "AK-103";
AK103.equipment_subtype = "stick";
AK103.material = "basic";
AK103.group_id = "firearm";
AK103.metallic = true;
AK103.setCost(0, "common_metals", 2);
AK103.minimum_city_storage_resource_1 = 1;
AK103.rigidity_rating = 4;
AK103.is_pool_weapon = true;
AK103.pool_rate = 15;
AK103.path_icon = "ui/icons/items/icon_AK103";
AK103.projectile = "shotgun_bullet";
AK103.path_slash_animation = "effects/slashes/slash_punch";
AK103.base_stats["projectiles"] = 1f;
AK103.base_stats["attack_speed"] = 5f;
AK103.base_stats["accuracy"] = 0.65f;
AK103.base_stats["damage"] = 62f;
AK103.base_stats["critical_chance"] = 0.25f;
AK103.base_stats["critical_damage_multiplier"] = 0.35f;
AK103.base_stats["recoil"] = 0.6f;
AK103.base_stats["range"] = 15f;
AK103.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
AK103.base_stats["targets"] = 1f;
AK103.base_stats["damage_range"] = 0.8f;
AK103.base_stats["mana"] = 10f;
AK103.base_stats["stamina"] = 15f;
AK103.equipment_value = 860;
AssetManager.items.add(AK103);
AssetManager.items.pool_weapon_assets_all.Add(AK103);
AssetManager.items.pool_weapon_assets_unlocked.Add(AK103);
addWeaponsSprite(AK103.id);




ItemAsset M16 = AssetManager.items.clone("M16", "$range");
M16.equipment_type = EquipmentType.Weapon;
M16.translation_key = "M16A1";
M16.equipment_subtype = "stick";
M16.material = "basic";
M16.group_id = "firearm";
M16.metallic = true;
M16.setCost(0, "common_metals", 1);
M16.minimum_city_storage_resource_1 = 1;
M16.rigidity_rating = 4;
M16.is_pool_weapon = true;
M16.pool_rate = 15;
M16.path_icon = "ui/icons/items/icon_M16";
M16.projectile = "shotgun_bullet";
M16.path_slash_animation = "effects/slashes/slash_punch";
M16.base_stats["projectiles"] = 1f;
M16.base_stats["attack_speed"] = 4f;
M16.base_stats["accuracy"] = 0.7f;
M16.base_stats["damage"] = 36f;
M16.base_stats["critical_chance"] = 0.2f;
M16.base_stats["critical_damage_multiplier"] = 0.3f;
M16.base_stats["recoil"] = 0.5f;
M16.base_stats["range"] = 18f;
M16.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
M16.base_stats["targets"] = 1f;
M16.base_stats["damage_range"] = 0.85f;
M16.base_stats["mana"] = 10f;
M16.base_stats["stamina"] = 15f;
M16.equipment_value = 680;
AssetManager.items.add(M16);
AssetManager.items.pool_weapon_assets_all.Add(M16);
AssetManager.items.pool_weapon_assets_unlocked.Add(M16);
addWeaponsSprite(M16.id);

ItemAsset HK416 = AssetManager.items.clone("HK416", "$range");
HK416.equipment_type = EquipmentType.Weapon;
HK416.translation_key = "HK416";
HK416.equipment_subtype = "stick";
HK416.material = "basic";
HK416.group_id = "firearm";
HK416.metallic = true;
HK416.setCost(0, "common_metals", 2);
HK416.minimum_city_storage_resource_1 = 1;
HK416.rigidity_rating = 4;
HK416.is_pool_weapon = true;
HK416.pool_rate = 15;
HK416.path_icon = "ui/icons/items/icon_HK416";
HK416.projectile = "shotgun_bullet";
HK416.path_slash_animation = "effects/slashes/slash_punch";
HK416.base_stats["projectiles"] = 1f;
HK416.base_stats["attack_speed"] = 6f;
HK416.base_stats["accuracy"] = 0.75f;
HK416.base_stats["damage"] = 39f;
HK416.base_stats["critical_chance"] = 0.25f;
HK416.base_stats["critical_damage_multiplier"] = 0.4f;
HK416.base_stats["recoil"] = 0.35f;
HK416.base_stats["range"] = 16f;
HK416.name_templates = AssetLibrary<ItemAsset>.l<string>("shotgun_name");
HK416.base_stats["targets"] = 1f;
HK416.base_stats["damage_range"] = 0.8f;
HK416.base_stats["mana"] = 10f;
HK416.base_stats["stamina"] = 15f;
HK416.equipment_value = 775;
AssetManager.items.add(HK416);
AssetManager.items.pool_weapon_assets_all.Add(HK416);
AssetManager.items.pool_weapon_assets_unlocked.Add(HK416);
addWeaponsSprite(HK416.id);



            ///////////////ARMOR///////////////////////////////////////////////////////////////

            ItemAsset ModernArmor = AssetManager.items.clone("modernarmor", "$armor");
            ModernArmor.equipment_type = EquipmentType.Armor;
            ModernArmor.material = "basic";
            ModernArmor.metallic = true;
            ModernArmor.path_icon = "ui/icons/items/icon_modernarmor";
            ModernArmor.name_templates = AssetLibrary<ItemAsset>.l<string>("armor_name");
            ModernArmor.setCost(0, "wood", 1);
            ModernArmor.minimum_city_storage_resource_1 = 1;
            ModernArmor.rigidity_rating = 4;
            ModernArmor.base_stats["armor"] = 20f;
            ModernArmor.base_stats["stamina"] = 20f;
            ModernArmor.equipment_value = 700;
            AssetManager.items.add(ModernArmor);


            ItemAsset ModernHelmet = AssetManager.items.clone("modernhelmet", "$helmet");
            ModernHelmet.equipment_type = EquipmentType.Helmet;
            ModernHelmet.material = "basic";
            ModernHelmet.metallic = true;
            ModernHelmet.path_icon = "ui/icons/items/icon_modernhelmet";
            ModernHelmet.setCost(0, "wood", 1);
            ModernHelmet.name_templates = AssetLibrary<ItemAsset>.l<string>("helmet_name");
            ModernHelmet.minimum_city_storage_resource_1 = 1;
            ModernHelmet.rigidity_rating = 4;
            ModernHelmet.base_stats["armor"] = 5f;
            ModernHelmet.base_stats["mana"] = 10f;
            ModernHelmet.base_stats["accuracy"] = 0.6f;
            ModernHelmet.equipment_value = 700;
            AssetManager.items.add(ModernHelmet);

            ItemAsset ModernBoots = AssetManager.items.clone("modernboots", "$boots");
            ModernBoots.equipment_type = EquipmentType.Boots;
            ModernBoots.metallic = true;
            ModernBoots.material = "basic";
            ModernBoots.setCost(0, "wood", 1);
            ModernBoots.path_icon = "ui/icons/items/icon_modernboots";
            ModernBoots.name_templates = AssetLibrary<ItemAsset>.l<string>("boots_name");
            ModernBoots.minimum_city_storage_resource_1 = 1;
            ModernBoots.rigidity_rating = 4;
            ModernBoots.base_stats["armor"] = 5f;
            ModernBoots.base_stats["speed"] = 15f;
            ModernBoots.base_stats["stamina"] = 3f;
            ModernBoots.equipment_value = 700;
            AssetManager.items.add(ModernBoots);

            //////////////////////////Equipments/////////////////////////////////////////////////

            ItemAsset GrenadeBelt = AssetManager.items.clone("grenadebelt", "$amulet");
            GrenadeBelt.equipment_type = EquipmentType.Ring;
            GrenadeBelt.group_id = "ring";
            GrenadeBelt.equipment_subtype = "ring";
            GrenadeBelt.material = "basic";
            GrenadeBelt.metallic = true;
            GrenadeBelt.name_templates = AssetLibrary<ItemAsset>.l<string>("ring_name");
            GrenadeBelt.setCost(0, "common_metals", 1);
            GrenadeBelt.path_icon = "ui/icons/items/MK2Ariel";
            GrenadeBelt.minimum_city_storage_resource_1 = 1;
            GrenadeBelt.rigidity_rating = 2;
            GrenadeBelt.base_stats["damage"] = 10f;
            GrenadeBelt.base_stats["critical_chance"] = 0.3f;
            GrenadeBelt.base_stats["stamina"] = 10f;
            GrenadeBelt.equipment_value = 700;
            AssetManager.items.add(GrenadeBelt);

            ItemAsset MedicPack = AssetManager.items.clone("medicpack", "$ring");
            MedicPack.equipment_type = EquipmentType.Amulet;
            MedicPack.metallic = true;
            MedicPack.equipment_subtype = "amulet";
            MedicPack.group_id = "amulet";
            MedicPack.path_icon = "ui/icons/items/MEDIC";
            MedicPack.name_templates = AssetLibrary<ItemAsset>.l<string>("amulet_name");
            MedicPack.material = "basic";
            MedicPack.setCost(0, "herbs", 1);
            MedicPack.minimum_city_storage_resource_1 = 1;
            MedicPack.rigidity_rating = 2;
            MedicPack.base_stats["health"] = 30f;
            MedicPack.base_stats["stamina"] = 20f;
            MedicPack.equipment_value = 700;
            AssetManager.items.add(MedicPack);

            /////////////////////////////////////////////////////////////////////////////
            CustomItemsList.InitCustomItems();

            if (!AssetManager.items.equipment_by_subtypes.ContainsKey("firearm"))
            {
                AssetManager.items.equipment_by_subtypes.Add("firearm", new List<ItemAsset>());
            }

            if (!AssetManager.items.equipment_by_subtypes.ContainsKey("stick"))
            {
                AssetManager.items.equipment_by_subtypes.Add("stick", new List<ItemAsset>());
            }

            AssetManager.items.equipment_by_subtypes["stick"].Add(Glock17);
            AssetManager.items.equipment_by_subtypes["stick"].Add(AK);
            AssetManager.items.equipment_by_subtypes["stick"].Add(RPG);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Minigun);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Sniper);
            AssetManager.items.equipment_by_subtypes["stick"].Add(FAMAS);
            AssetManager.items.equipment_by_subtypes["stick"].Add(M4A1);
            AssetManager.items.equipment_by_subtypes["stick"].Add(ThompsonM1A1);
            AssetManager.items.equipment_by_subtypes["stick"].Add(SGT44);
            AssetManager.items.equipment_by_subtypes["stick"].Add(XM8);
            AssetManager.items.equipment_by_subtypes["stick"].Add(AK103);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Uzi);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Malorian);
            AssetManager.items.equipment_by_subtypes["stick"].Add(DesertEagle);
            AssetManager.items.equipment_by_subtypes["stick"].Add(M16);
            AssetManager.items.equipment_by_subtypes["stick"].Add(HK416);
            AssetManager.items.equipment_by_subtypes["stick"].Add(MP7);
            AssetManager.items.equipment_by_subtypes["stick"].Add(M32);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Americanshotgun);
            AssetManager.items.equipment_by_subtypes["stick"].Add(Sluggershotgun);

            if (!AssetManager.items.equipment_by_groups_all.ContainsKey("firearm"))
            {
                AssetManager.items.equipment_by_groups_all.Add("firearm", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Glock17);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(AK);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(RPG);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Minigun);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Sniper);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(FAMAS);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(M4A1);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(ThompsonM1A1);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(SGT44);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(XM8);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(AK103);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Uzi);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Malorian);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(DesertEagle);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(M16);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(HK416);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(MP7);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(M32);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Americanshotgun);
            AssetManager.items.equipment_by_groups_all["firearm"].Add(Sluggershotgun);

            if (!AssetManager.items.equipment_by_groups_unlocked.ContainsKey("firearm"))
            {
                AssetManager.items.equipment_by_groups_unlocked.Add("firearm", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Glock17);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(AK);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(RPG);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Minigun);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Sniper);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(FAMAS);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(M4A1);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(ThompsonM1A1);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(SGT44);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(XM8);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(AK103);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Uzi);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Malorian);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(DesertEagle);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(M16);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(HK416);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(MP7);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(M32);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Americanshotgun);
            AssetManager.items.equipment_by_groups_unlocked["firearm"].Add(Sluggershotgun);



            /////////////////////////////////////////////////////////////////////////////


             if (!AssetManager.items.equipment_by_groups_all.ContainsKey("boots"))
            {
                AssetManager.items.equipment_by_groups_all.Add("boots", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["boots"].Add(ModernBoots);


            if (!AssetManager.items.equipment_by_groups_all.ContainsKey("helmet"))
            {
                AssetManager.items.equipment_by_groups_all.Add("helmet", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["helmet"].Add(ModernHelmet);


              if (!AssetManager.items.equipment_by_groups_all.ContainsKey("armor"))
            {
                AssetManager.items.equipment_by_groups_all.Add("armor", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["armor"].Add(ModernArmor);





            /////////////////////////////////////////////////////////////////////////////
            if (!AssetManager.items.equipment_by_groups_all.ContainsKey("ring"))
            {
                AssetManager.items.equipment_by_groups_all.Add("ring", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["ring"].Add(GrenadeBelt);


            if (!AssetManager.items.equipment_by_groups_all.ContainsKey("amulet"))
            {
                AssetManager.items.equipment_by_groups_all.Add("amulet", new List<ItemAsset>());
            }
            AssetManager.items.equipment_by_groups_all["amulet"].Add(MedicPack);


                if (!AssetManager.items.equipment_by_groups_unlocked.ContainsKey("amulet"))
            {
                AssetManager.items.equipment_by_groups_unlocked.Add("amulet", new List<ItemAsset>());
            }
              AssetManager.items.equipment_by_groups_unlocked["amulet"].Add(MedicPack);


                if (!AssetManager.items.equipment_by_groups_unlocked.ContainsKey("ring"))
            {
                AssetManager.items.equipment_by_groups_unlocked.Add("ring", new List<ItemAsset>());
            }
           AssetManager.items.equipment_by_groups_unlocked["ring"].Add(GrenadeBelt);


         if (!AssetManager.items.equipment_by_subtypes.ContainsKey("amulet"))
            {
                AssetManager.items.equipment_by_subtypes.Add("amulet", new List<ItemAsset>());
            }
         AssetManager.items.equipment_by_subtypes["amulet"].Add(MedicPack);


         if (!AssetManager.items.equipment_by_subtypes.ContainsKey("ring"))
            {
                AssetManager.items.equipment_by_subtypes.Add("ring", new List<ItemAsset>());
            }
         AssetManager.items.equipment_by_subtypes["ring"].Add(GrenadeBelt);


        }








        //////THANKS MELVIN SHWUANER///////
 public static void addWeaponsSprite(string id)
    {
        var dictItems = ActorAnimationLoader._dict_items;

        ItemAsset item = AssetManager.items.get(id);
        if (item != null && item.animated)
        {
            List<Sprite> spriteList = new List<Sprite>();

            int frameIndex = 0;
            bool framesFound = false;

            while (true)
            {
                Sprite frameSprite = Resources.Load<Sprite>("weapons/" + id + "_" + frameIndex);

                if (frameSprite != null)
                {
                    spriteList.Add(frameSprite);
                    framesFound = true;
                    frameIndex++;
                }
                else
                {
                    frameSprite = Resources.Load<Sprite>("weapons/" + id + frameIndex);

                    if (frameSprite != null)
                    {
                        spriteList.Add(frameSprite);
                        framesFound = true;
                        frameIndex++;
                    }
                    else
                    {
                        if (framesFound)
                            break;

                        frameSprite = Resources.Load<Sprite>("weapons/" + id + "/main_0_" + frameIndex);

                        if (frameSprite != null)
                        {
                            spriteList.Add(frameSprite);
                            framesFound = true;
                            frameIndex++;
                        }
                        else
                        {
                            if (frameIndex > 0)
                                break;

                            Sprite[] sprites = Resources.LoadAll<Sprite>("weapons/" + id);
                            if (sprites != null && sprites.Length > 0)
                            {
                                foreach (Sprite sprite in sprites)
                                {
                                    spriteList.Add(sprite);
                                }
                                framesFound = true;
                            }

                            break;
                        }
                    }
                }

                if (frameIndex > 20)
                    break;
            }

            if (framesFound && spriteList.Count > 0)
            {
                if (dictItems.ContainsKey("w_" + id))
                {
                    dictItems["w_" + id] = spriteList;
                }
                else
                {
                    dictItems.Add("w_" + id, spriteList);
                }
            }
            else
            {
                Debug.LogError("No animations set: " + id);

                var fallbackSprite = Resources.Load<Sprite>("weapons/" + id);
                if (fallbackSprite != null)
                {
                    if (dictItems.ContainsKey("w_" + id))
                    {
                        dictItems["w_" + id] = new List<Sprite>() { fallbackSprite };
                    }
                    else
                    {
                        dictItems.Add("w_" + id, new List<Sprite>() { fallbackSprite });
                    }
                    Debug.Log("Fallback sprite for: " + id);
                }
            }
        }
        else
        {
            var sprite = Resources.Load<Sprite>("weapons/" + id);
            if (sprite != null)
            {
                if (dictItems.ContainsKey("w_" + id))
                {
                    dictItems["w_" + id] = new List<Sprite>() { sprite };
                }
                else
                {
                    dictItems.Add("w_" + id, new List<Sprite>() { sprite });
                }
            }
            else
            {
                Debug.LogError("No Textures or maidens for: " + id);
            }
        }
    }

}
}
