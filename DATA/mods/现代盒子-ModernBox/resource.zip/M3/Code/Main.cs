//========= MODERNBOX 2.1.0.1 ============//
//
// Made by Tuxxego
//
//=============================================================================//
using System;
using System.IO;
using System.Linq;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;
using Newtonsoft.Json;
using M3;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using System.Threading.Tasks;
using static Config;
using System.Reflection.Emit;
using UnityEngine.Tilemaps;
using UnityEngine.Purchasing.MiniJSON;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;
using UnityEngine.CrashReportHandler;
using System.IO.Compression;
using System.Threading;
using System.Text;
using Beebyte.Obfuscator;
using ai;
using ai.behaviours;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using WorldBoxConsole;
using UnityEngine.UI;
using static TopTileLibrary;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Assertions.Must;
using Random=UnityEngine.Random;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using NeoModLoader.General;


namespace M3{
    [ModEntry]
    class Main : MonoBehaviour{
        #region
        public static Main instance;
        #endregion
        internal const string id = "Tuxxego.mods.worldbox.M3";
        internal static Harmony harmony;
        internal static Dictionary<string, UnityEngine.Object> modsResources;
        public BuildingLibrary buildingLibrary = new BuildingLibrary();
        public const string mainPath = "Mods/M3";

        internal static string ModName
        {
            get { return Mod.Info.Name; }
        }

        void Awake()
        {
            try
            {
                harmony = new Harmony("com.Tuxxego.M3");
                var executingAssembly = Assembly.GetExecutingAssembly();
                harmony.PatchAll(executingAssembly);
                Debug.Log("[M3] Harmony patches applied successfully");


                Buildings.init();
                Debug.Log("[M3] Buildings initialized");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[M3] Exception in Awake: {ex.Message}");
                Debug.LogError($"[M3] Stack Trace: {ex.StackTrace}");
            }
        }

        void Start()
        {
            InitializeComponents();
        }

        void InitializeComponents()
        {
            try
            {
                modsResources = Reflection.GetField(typeof(ResourcesPatch), null, "modsResources") as Dictionary<string, UnityEngine.Object>;
                Debug.Log("Meow meow meow, FEED ME YOU MOTHERF");

                Vehicles.init();

                Traits.init();

                WeaponsProjectilesEffects.init();

                BestestUI.init();

                instance = this;
                Debug.Log("[M3] All components initialized successfully");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Exception in InitializeComponents: {ex.Message}");
                Debug.LogError($"Stack Trace: {ex.StackTrace}");
            }
        }
    }
}
