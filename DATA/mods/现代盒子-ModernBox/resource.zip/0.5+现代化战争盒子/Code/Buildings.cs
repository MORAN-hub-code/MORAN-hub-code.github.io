//========= MODERNBOX 2.1.0.1 ============//
//
// Made by Tuxxego
//
//=============================================================================//
using System;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using System.Text.RegularExpressions;
using Beebyte.Obfuscator;


namespace M3
{
    class Buildings : MonoBehaviour
    {

        public static void init()
        {
            BuildingOrderandStuff();
        }

        private static void BuildingOrderandStuff()
        {

         //   humanoid - plague_doctor evil_mage white_mage civ_cat civ_dog civ_chicken civ_sheep civ_garlic_man civ_lemon_man civ_acid_gentleman bandit

        //    dwarfic  - cold_one snowman civ_armadillo civ_rhino civ_crab civ_penguin civ_turtle civ_crystal_golem civ_candy_man

        //    elfic    - angle  civ_rabbit civ_monkey civ_cow civ_buffalo civ_alpaca civ_capybara civ_goat civ_frog civ_liliar druid fairy

        //    orkish   - necromancer fire_skull  civ_fox civ_wolf civ_bear civ_hyena civ_rat civ_scorpion civ_crocodile civ_snake civ_piranha greg jumpy_skull



//////////////////////////////////////// ALLIANCE RACES //////////////////////////////////


var human = AssetManager.actor_library.get("human");
human.build_order_template_id = "build_order_alliance";

var plague_doctor = AssetManager.actor_library.get("plague_doctor");
plague_doctor.build_order_template_id = "build_order_alliance";

var evil_mage = AssetManager.actor_library.get("evil_mage");
evil_mage.build_order_template_id = "build_order_alliance";

var white_mage = AssetManager.actor_library.get("white_mage");
white_mage.build_order_template_id = "build_order_alliance";

var civ_cat = AssetManager.actor_library.get("civ_cat");
civ_cat.build_order_template_id = "build_order_alliance";

var civ_dog = AssetManager.actor_library.get("civ_dog");
civ_dog.build_order_template_id = "build_order_alliance";

var civ_chicken = AssetManager.actor_library.get("civ_chicken");
civ_chicken.build_order_template_id = "build_order_alliance";

var civ_sheep = AssetManager.actor_library.get("civ_sheep");
civ_sheep.build_order_template_id = "build_order_alliance";

var civ_garlic_man = AssetManager.actor_library.get("civ_garlic_man");
civ_garlic_man.build_order_template_id = "build_order_alliance";

var civ_lemon_man = AssetManager.actor_library.get("civ_lemon_man");
civ_lemon_man.build_order_template_id = "build_order_alliance";

var civ_acid_gentleman = AssetManager.actor_library.get("civ_acid_gentleman");
civ_acid_gentleman.build_order_template_id = "build_order_alliance";

var bandit = AssetManager.actor_library.get("bandit");
bandit.build_order_template_id = "build_order_alliance";



string[] alliancecivs = new string[] { "human", "plague_doctor", "evil_mage", "white_mage", "civ_cat", "civ_dog", "civ_chicken", "civ_sheep", "civ_garlic_man", "civ_lemon_man", "civ_acid_gentleman", "bandit" };

foreach (string allianceciv in alliancecivs)
{
    string barracksId = $"barracks_{allianceciv}";
    BuildingAsset barracks = AssetManager.buildings.get(barracksId);

    if (barracks != null)
    {
        barracks.priority = 100;
        barracks.fundament = new BuildingFundament(3, 3, 4, 0);
        barracks.cost = new ConstructionCost(0, 0, 0, 1);
        barracks.group = allianceciv;
        barracks.shadow = false;
barracks.upgrade_level = 1;
barracks.build_prefer_replace_house = true;
barracks.can_be_upgraded = true;
barracks.upgrade_to = "Barracks_rain_alliance";

        AssetManager.buildings.add(barracks);
    }


    string houseId = $"house_{allianceciv}_0";
    BuildingAsset house = AssetManager.buildings.get(houseId);

    if (house != null)
    {
        house.cost = new ConstructionCost(0, 0, 0, 1);
        house.group = allianceciv;
        house.shadow = false;
house.upgrade_level = 0;
house.can_be_upgraded = true;
house.upgrade_to = "House_rain_alliance";

        AssetManager.buildings.add(house);
    }

      string hallId = $"hall_{allianceciv}_0";
    BuildingAsset hall = AssetManager.buildings.get(hallId);

    if (hall != null)
    {
        hall.cost = new ConstructionCost(0, 0, 0, 1);
        hall.group = allianceciv;
        hall.shadow = false;
        hall.max_houses = 1;
hall.upgrade_level = 0;
hall.can_be_upgraded = true;
hall.upgrade_to = "Hall_rain_alliance";

        AssetManager.buildings.add(hall);
    }

          string templeId = $"temple_{allianceciv}";
    BuildingAsset temple = AssetManager.buildings.get(templeId);

    if (temple != null)
    {
        temple.cost = new ConstructionCost(0, 0, 0, 1);
        temple.shadow = false;
temple.upgrade_level = 0;
temple.group = allianceciv;
temple.can_be_upgraded = true;
temple.max_houses = 1;
temple.storage = true;
temple.book_slots = 10;
temple.build_prefer_replace_house = true;
temple.upgrade_to = "Temple_rain_alliance";

        AssetManager.buildings.add(temple);
    }

      string dockId = $"docks_{allianceciv}";
    BuildingAsset docks = AssetManager.buildings.get(dockId);

    if (docks != null)
    {
docks.cost = new ConstructionCost(0, 0, 0, 1);
docks.shadow = false;
docks.upgrade_level = 2;
docks.can_be_upgraded = true;
docks.build_prefer_replace_house = true;
docks.upgrade_to = "Docks_rain_alliance";
docks.group = allianceciv;
docks.civ_kingdom = allianceciv;

        AssetManager.buildings.add(docks);
    }

}


BuildingAsset Docks_rain_alliance = AssetManager.buildings.clone("Docks_rain_alliance", "docks_human");
Docks_rain_alliance.boat_types = new string[6] { "cargo_alliance_boat", "destroyer_a_alliance_boat", "destroyer_b_alliance_boat", "carrier_alliance_boat", "submarine_alliance_boat", "fishing_alliance_boat" };
Docks_rain_alliance.priority = 100;
Docks_rain_alliance.group = "human";
Docks_rain_alliance.civ_kingdom = "human";
Docks_rain_alliance.cost = new ConstructionCost(0, 0, 0, 1);
Docks_rain_alliance.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Docks_rain_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Docks_rain_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Docks_rain_alliance.base_stats["health"] = 2500f;
Docks_rain_alliance.burnable = false;
Docks_rain_alliance.can_be_upgraded = true;
Docks_rain_alliance.sprite_path = "buildings/dock_rain_universalWIP";
Docks_rain_alliance.has_sprites_main_disabled = false;
Docks_rain_alliance.has_sprites_main = true;
Docks_rain_alliance.has_sprites_ruin = true;
Docks_rain_alliance.shadow = false;
Docks_rain_alliance.upgrade_level = 3;
Docks_rain_alliance.has_sprite_construction = false;
Docks_rain_alliance.upgrade_to = "Docks_rain_alliance";
Docks_rain_alliance.upgraded_from = "docks_human";
AssetManager.buildings.add(Docks_rain_alliance);
AssetManager.buildings.loadSprites(Docks_rain_alliance);


BuildingAsset bonfire_alliance = AssetManager.buildings.clone("bonfire_alliance", "$city_building$");
bonfire_alliance.draw_light_area = true;
bonfire_alliance.draw_light_size = 0.8f;
bonfire_alliance.can_be_abandoned = false;
bonfire_alliance.priority = 120;
bonfire_alliance.type = "type_bonfire";
bonfire_alliance.fundament = new BuildingFundament(2, 2, 2, 0);
bonfire_alliance.construction_progress_needed = 30;
bonfire_alliance.cost = new ConstructionCost();
bonfire_alliance.smoke = true;
bonfire_alliance.smoke_interval = 2.5f;
bonfire_alliance.smoke_offset = new Vector2Int(2, 3);
bonfire_alliance.can_be_living_house = false;
bonfire_alliance.build_place_batch = false;
bonfire_alliance.build_prefer_replace_house = true;
bonfire_alliance.check_for_close_building = false;
bonfire_alliance.produce_biome_food = true;
bonfire_alliance.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBonfire";
bonfire_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
bonfire_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingGeneric";
bonfire_alliance.check_for_adaptation_tags = false;
bonfire_alliance.max_houses = 1;
bonfire_alliance.base_stats["health"] = 1500f;
bonfire_alliance.burnable = false;
bonfire_alliance.can_be_upgraded = true;
bonfire_alliance.sprite_path = "buildings/bonfire_alliance";
bonfire_alliance.has_sprites_main_disabled = false;
bonfire_alliance.has_sprites_main = true;
bonfire_alliance.has_sprites_ruin = true;
bonfire_alliance.shadow = false;
bonfire_alliance.upgrade_level = 0;
bonfire_alliance.has_sprite_construction = false;
bonfire_alliance.upgrade_to = "bonfire_alliance";
AssetManager.buildings.add(bonfire_alliance);
AssetManager.buildings.loadSprites(bonfire_alliance);


BuildingAsset Temple_rain_alliance = AssetManager.buildings.clone("Temple_rain_alliance", "$building_civ_human$");
Temple_rain_alliance.storage = true;
Temple_rain_alliance.book_slots = 15;
Temple_rain_alliance.draw_light_area = true;
Temple_rain_alliance.draw_light_size = 0.3f;
Temple_rain_alliance.draw_light_area_offset_y = 3f;
Temple_rain_alliance.priority = 100;
Temple_rain_alliance.type = "type_temple";
Temple_rain_alliance.fundament = new BuildingFundament(2, 2, 3, 0);
Temple_rain_alliance.cost = new ConstructionCost(0, 0, 0, 1);
Temple_rain_alliance.group = "human";
Temple_rain_alliance.max_houses = 1;
Temple_rain_alliance.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Temple_rain_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Temple_rain_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Temple_rain_alliance.base_stats["health"] = 2500f;
Temple_rain_alliance.burnable = false;
Temple_rain_alliance.can_be_upgraded = true;
Temple_rain_alliance.sprite_path = "buildings/Temple_rain_alliance";
Temple_rain_alliance.has_sprites_main_disabled = false;
Temple_rain_alliance.has_sprites_main = true;
Temple_rain_alliance.has_sprites_ruin = true;
Temple_rain_alliance.shadow = false;
Temple_rain_alliance.upgrade_level = 1;
Temple_rain_alliance.has_sprite_construction = false;
Temple_rain_alliance.upgrade_to = "Temple_rain_alliance";
Temple_rain_alliance.upgraded_from = "temple_human";
AssetManager.buildings.add(Temple_rain_alliance);
AssetManager.buildings.loadSprites(Temple_rain_alliance);



 BuildingAsset Hall_rain_alliance = AssetManager.buildings.clone("Hall_rain_alliance", "$building_civ_human$");
		Hall_rain_alliance.priority = 100;
		Hall_rain_alliance.storage = true;
		Hall_rain_alliance.type = "type_hall";
		Hall_rain_alliance.fundament = new BuildingFundament(3, 3, 4, 0);
		Hall_rain_alliance.can_be_upgraded = true;
		Hall_rain_alliance.base_stats["health"] = 2500f;
		Hall_rain_alliance.burnable = false;
		Hall_rain_alliance.setHousingSlots(5);
		Hall_rain_alliance.housing_happiness = 10;
		Hall_rain_alliance.loot_generation = 3;
		Hall_rain_alliance.ignore_other_buildings_for_upgrade = true;
		Hall_rain_alliance.build_place_batch = true;
		Hall_rain_alliance.max_houses = 1;
		Hall_rain_alliance.produce_biome_food = true;
		Hall_rain_alliance.setShadow(0.56f, 0.41f, 0.43f);
		Hall_rain_alliance.draw_light_size = 0.3f;
		Hall_rain_alliance.book_slots = 5;
        Hall_rain_alliance.draw_light_area = true;
		Hall_rain_alliance.upgraded_from = "hall_human_0";
		Hall_rain_alliance.sound_hit = "event:/SFX/HIT/HitWood";
		Hall_rain_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		Hall_rain_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        Hall_rain_alliance.cost = new ConstructionCost(0, 0, 0, 1);
        Hall_rain_alliance.group = "human";
        Hall_rain_alliance.sprite_path = "buildings/Hall_rain_alliance";
        Hall_rain_alliance.base_stats["health"] = 4000f;
        Hall_rain_alliance.has_sprites_main_disabled = false;
	    Hall_rain_alliance.has_sprites_main = true;
	    Hall_rain_alliance.has_sprites_ruin = true;
        Hall_rain_alliance.shadow = false;
Hall_rain_alliance.upgrade_level = 1;
Hall_rain_alliance.has_sprite_construction = false;
Hall_rain_alliance.upgrade_to = "Hall_rain_alliance";
AssetManager.buildings.add(Hall_rain_alliance);
AssetManager.buildings.loadSprites(Hall_rain_alliance);



 BuildingAsset House_rain_alliance = AssetManager.buildings.clone("House_rain_alliance", "$building_civ_human$");
		House_rain_alliance.setHousingSlots(4);
		House_rain_alliance.loot_generation = 2;
		House_rain_alliance.housing_happiness = 7;
		House_rain_alliance.type = "type_house";
		House_rain_alliance.sound_hit = "event:/SFX/HIT/HitWood";
		House_rain_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		House_rain_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        House_rain_alliance.draw_light_area = true;
		House_rain_alliance.draw_light_size = 0.2f;
        House_rain_alliance.priority = 100;
        House_rain_alliance.fundament = new BuildingFundament(1, 1, 2, 0);
        House_rain_alliance.cost = new ConstructionCost(0, 0, 0, 1);
        House_rain_alliance.group = "human";
        House_rain_alliance.sprite_path = "buildings/House_rain_alliance";
        House_rain_alliance.base_stats["health"] = 2000f;
        House_rain_alliance.burnable = false;
        House_rain_alliance.has_sprites_main_disabled = false;
	    House_rain_alliance.has_sprites_main = true;
	    House_rain_alliance.has_sprites_ruin = true;
        House_rain_alliance.shadow = false;
House_rain_alliance.upgrade_level = 1;
House_rain_alliance.can_be_upgraded = false;
House_rain_alliance.has_sprite_construction = false;
House_rain_alliance.upgrade_to = "House_rain_alliance";
House_rain_alliance.upgraded_from = "house_human_0";
AssetManager.buildings.add(House_rain_alliance);
AssetManager.buildings.loadSprites(House_rain_alliance);



BuildingAsset Barracks_rain_alliance = AssetManager.buildings.clone("Barracks_rain_alliance", "$building_civ_human$");
Barracks_rain_alliance.draw_light_area = true;
Barracks_rain_alliance.draw_light_size = 0.5f;
Barracks_rain_alliance.type = "type_barracks";
Barracks_rain_alliance.priority = 100;
Barracks_rain_alliance.fundament = new BuildingFundament(3, 3, 4, 0);
Barracks_rain_alliance.cost = new ConstructionCost(0, 0, 0, 1);
Barracks_rain_alliance.group = "human";
Barracks_rain_alliance.sprite_path = "buildings/Barracks_rain_alliance";
Barracks_rain_alliance.base_stats["health"] = 3000f;
Barracks_rain_alliance.burnable = false;
Barracks_rain_alliance.has_sprites_main_disabled = false;
Barracks_rain_alliance.has_sprites_main = true;
Barracks_rain_alliance.has_sprites_ruin = true;
Barracks_rain_alliance.shadow = false;
Barracks_rain_alliance.upgrade_level = 2;
Barracks_rain_alliance.can_be_upgraded = false;
Barracks_rain_alliance.has_sprite_construction = false;
Barracks_rain_alliance.upgrade_to = "Barracks_industrial_alliance";
Barracks_rain_alliance.upgraded_from = "barracks_human";
Barracks_rain_alliance.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBarracks";
Barracks_rain_alliance.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Barracks_rain_alliance.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
AssetManager.buildings.add(Barracks_rain_alliance);
AssetManager.buildings.loadSprites(Barracks_rain_alliance);




CityBuildOrderAsset allianceBuild = new CityBuildOrderAsset();
allianceBuild.id = "build_order_alliance";

BuildOrder allianceorder;

allianceorder = allianceBuild.addBuilding("order_bonfire_alliance", 1);

allianceorder = allianceBuild.addBuilding("order_stockpile", 1);

allianceorder = allianceBuild.addBuilding("order_hall_0", 1);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

allianceorder = allianceBuild.addBuilding("order_house_0", 0, 0, 0, pCheckFullVillage: false, pCheckHouseLimit: true);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

allianceBuild.addUpgrade("order_house_0");
allianceorder = allianceBuild.list.Last();
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

allianceorder = allianceBuild.addBuilding("order_watch_tower", 0, 0, 0);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

allianceorder = allianceBuild.addBuilding("order_temple", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

allianceBuild.addUpgrade("order_temple");
allianceorder = allianceBuild.list.Last();
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

allianceorder = allianceBuild.addBuilding("order_mine", 1, 10, 10);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//allianceorder = allianceBuild.addBuilding("order_market", 1, 10, 10);
//allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

//allianceorder = allianceBuild.addBuilding("order_library", 1, 10, 10);
//allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

allianceorder = allianceBuild.addBuilding("order_docks_0", 5, 0, 2);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

allianceBuild.addUpgrade("order_docks_0");
allianceorder = allianceBuild.list.Last();
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

allianceBuild.addUpgrade("order_docks_1");
allianceorder = allianceBuild.list.Last();
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

allianceorder = allianceBuild.addBuilding("order_windmill_0", 1, 6, 5);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

allianceorder = allianceBuild.addBuilding("order_barracks", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

allianceBuild.addUpgrade("order_barracks");
allianceorder = allianceBuild.list.Last();
allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//allianceorder = allianceBuild.addBuilding("order_training_dummy", 3, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
//allianceorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("order_temple");

AssetManager.city_build_orders.add(allianceBuild);


//////////////////////////////////////// HARDEN RACES //////////////////////////////////




var dwarf = AssetManager.actor_library.get("dwarf");
dwarf.build_order_template_id = "build_order_harden";

var cold_one = AssetManager.actor_library.get("cold_one");
cold_one.build_order_template_id = "build_order_harden";

var snowman = AssetManager.actor_library.get("snowman");
snowman.build_order_template_id = "build_order_harden";

var civ_armadillo = AssetManager.actor_library.get("civ_armadillo");
civ_armadillo.build_order_template_id = "build_order_harden";

var civ_rhino = AssetManager.actor_library.get("civ_rhino");
civ_rhino.build_order_template_id = "build_order_harden";

var civ_crab = AssetManager.actor_library.get("civ_crab");
civ_crab.build_order_template_id = "build_order_harden";

var civ_penguin = AssetManager.actor_library.get("civ_penguin");
civ_penguin.build_order_template_id = "build_order_harden";

var civ_turtle = AssetManager.actor_library.get("civ_turtle");
civ_turtle.build_order_template_id = "build_order_harden";

var civ_crystal_golem = AssetManager.actor_library.get("civ_crystal_golem");
civ_crystal_golem.build_order_template_id = "build_order_harden";

var civ_candy_man = AssetManager.actor_library.get("civ_candy_man");
civ_candy_man.build_order_template_id = "build_order_harden";

var civ_goat = AssetManager.actor_library.get("civ_goat");
civ_goat.build_order_template_id = "build_order_harden";



string[] hardencivs = new string[] { "dwarf", "cold_one", "snowman", "civ_armadillo", "civ_rhino", "civ_crab", "civ_penguin", "civ_turtle", "civ_crystal_golem", "civ_candy_man", "civ_goat" };



foreach (string hardenciv in hardencivs)
{
    string barracksId = $"barracks_{hardenciv}";
    BuildingAsset barracks = AssetManager.buildings.get(barracksId);

    if (barracks != null)
    {
        barracks.priority = 100;
        barracks.fundament = new BuildingFundament(3, 3, 4, 0);
        barracks.cost = new ConstructionCost(0, 0, 0, 1);
        barracks.group = hardenciv;
        barracks.shadow = false;
barracks.upgrade_level = 1;
barracks.build_prefer_replace_house = true;
barracks.can_be_upgraded = true;
barracks.upgrade_to = "Barracks_rain_harden";

        AssetManager.buildings.add(barracks);
    }


    string houseId = $"house_{hardenciv}_0";
    BuildingAsset house = AssetManager.buildings.get(houseId);

    if (house != null)
    {
        house.cost = new ConstructionCost(0, 0, 0, 1);
        house.group = hardenciv;
        house.shadow = false;
house.upgrade_level = 0;
house.can_be_upgraded = true;
house.upgrade_to = "House_rain_harden";

        AssetManager.buildings.add(house);
    }

      string hallId = $"hall_{hardenciv}_0";
    BuildingAsset hall = AssetManager.buildings.get(hallId);

    if (hall != null)
    {
        hall.cost = new ConstructionCost(0, 0, 0, 1);
        hall.group = hardenciv;
        hall.shadow = false;
        hall.max_houses = 1;
hall.upgrade_level = 0;
hall.can_be_upgraded = true;
hall.upgrade_to = "Hall_rain_harden";

        AssetManager.buildings.add(hall);
    }

          string templeId = $"temple_{hardenciv}";
    BuildingAsset temple = AssetManager.buildings.get(templeId);

    if (temple != null)
    {
        temple.cost = new ConstructionCost(0, 0, 0, 1);
        temple.shadow = false;
temple.upgrade_level = 0;
temple.group = hardenciv;
temple.can_be_upgraded = true;
temple.max_houses = 1;
temple.storage = true;
temple.book_slots = 10;
temple.build_prefer_replace_house = true;
temple.upgrade_to = "Temple_rain_harden";

        AssetManager.buildings.add(temple);
    }

      string dockId = $"docks_{hardenciv}";
    BuildingAsset docks = AssetManager.buildings.get(dockId);

    if (docks != null)
    {
docks.cost = new ConstructionCost(0, 0, 0, 1);
docks.shadow = false;
docks.upgrade_level = 2;
docks.can_be_upgraded = true;
docks.build_prefer_replace_house = true;
docks.upgrade_to = "Docks_rain_harden";
docks.group = hardenciv;
docks.civ_kingdom = hardenciv;

        AssetManager.buildings.add(docks);
    }

}


BuildingAsset Docks_rain_harden = AssetManager.buildings.clone("Docks_rain_harden", "docks_human");
Docks_rain_harden.boat_types = new string[6] { "cargo_harden_boat", "destroyer_a_harden_boat", "destroyer_b_harden_boat", "carrier_harden_boat", "submarine_harden_boat", "fishing_harden_boat" };
Docks_rain_harden.priority = 100;
Docks_rain_harden.group = "human";
Docks_rain_harden.civ_kingdom = "human";
Docks_rain_harden.cost = new ConstructionCost(0, 0, 0, 1);
Docks_rain_harden.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Docks_rain_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Docks_rain_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Docks_rain_harden.base_stats["health"] = 2500f;
Docks_rain_harden.burnable = false;
Docks_rain_harden.can_be_upgraded = true;
Docks_rain_harden.sprite_path = "buildings/dock_rain_universalWIP";
Docks_rain_harden.has_sprites_main_disabled = false;
Docks_rain_harden.has_sprites_main = true;
Docks_rain_harden.has_sprites_ruin = true;
Docks_rain_harden.shadow = false;
Docks_rain_harden.upgrade_level = 3;
Docks_rain_harden.has_sprite_construction = false;
Docks_rain_harden.upgrade_to = "Docks_rain_harden";
Docks_rain_harden.upgraded_from = "docks_human";
AssetManager.buildings.add(Docks_rain_harden);
AssetManager.buildings.loadSprites(Docks_rain_harden);


BuildingAsset bonfire_harden = AssetManager.buildings.clone("bonfire_harden", "$city_building$");
bonfire_harden.draw_light_area = true;
bonfire_harden.draw_light_size = 0.8f;
bonfire_harden.can_be_abandoned = false;
bonfire_harden.priority = 120;
bonfire_harden.type = "type_bonfire";
bonfire_harden.fundament = new BuildingFundament(2, 2, 2, 0);
bonfire_harden.construction_progress_needed = 30;
bonfire_harden.cost = new ConstructionCost();
bonfire_harden.smoke = true;
bonfire_harden.smoke_interval = 2.5f;
bonfire_harden.smoke_offset = new Vector2Int(2, 3);
bonfire_harden.can_be_living_house = false;
bonfire_harden.build_place_batch = false;
bonfire_harden.build_prefer_replace_house = true;
bonfire_harden.check_for_close_building = false;
bonfire_harden.produce_biome_food = true;
bonfire_harden.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBonfire";
bonfire_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
bonfire_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingGeneric";
bonfire_harden.check_for_adaptation_tags = false;
bonfire_harden.max_houses = 1;
bonfire_harden.base_stats["health"] = 1500f;
bonfire_harden.burnable = false;
bonfire_harden.can_be_upgraded = true;
bonfire_harden.sprite_path = "buildings/bonfire_harden";
bonfire_harden.has_sprites_main_disabled = false;
bonfire_harden.has_sprites_main = true;
bonfire_harden.has_sprites_ruin = true;
bonfire_harden.shadow = false;
bonfire_harden.upgrade_level = 0;
bonfire_harden.has_sprite_construction = false;
bonfire_harden.upgrade_to = "bonfire_harden";
AssetManager.buildings.add(bonfire_harden);
AssetManager.buildings.loadSprites(bonfire_harden);


BuildingAsset Temple_rain_harden = AssetManager.buildings.clone("Temple_rain_harden", "$building_civ_human$");
Temple_rain_harden.storage = true;
Temple_rain_harden.book_slots = 15;
Temple_rain_harden.draw_light_area = true;
Temple_rain_harden.draw_light_size = 0.3f;
Temple_rain_harden.draw_light_area_offset_y = 3f;
Temple_rain_harden.priority = 100;
Temple_rain_harden.type = "type_temple";
Temple_rain_harden.fundament = new BuildingFundament(2, 2, 3, 0);
Temple_rain_harden.cost = new ConstructionCost(0, 0, 0, 1);
Temple_rain_harden.group = "human";
Temple_rain_harden.max_houses = 1;
Temple_rain_harden.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Temple_rain_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Temple_rain_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Temple_rain_harden.base_stats["health"] = 2500f;
Temple_rain_harden.burnable = false;
Temple_rain_harden.can_be_upgraded = true;
Temple_rain_harden.sprite_path = "buildings/Temple_rain_harden";
Temple_rain_harden.has_sprites_main_disabled = false;
Temple_rain_harden.has_sprites_main = true;
Temple_rain_harden.has_sprites_ruin = true;
Temple_rain_harden.shadow = false;
Temple_rain_harden.upgrade_level = 1;
Temple_rain_harden.has_sprite_construction = false;
Temple_rain_harden.upgrade_to = "Temple_rain_harden";
Temple_rain_harden.upgraded_from = "temple_human";
AssetManager.buildings.add(Temple_rain_harden);
AssetManager.buildings.loadSprites(Temple_rain_harden);



 BuildingAsset Hall_rain_harden = AssetManager.buildings.clone("Hall_rain_harden", "$building_civ_human$");
		Hall_rain_harden.priority = 100;
		Hall_rain_harden.storage = true;
		Hall_rain_harden.type = "type_hall";
		Hall_rain_harden.fundament = new BuildingFundament(3, 3, 4, 0);
		Hall_rain_harden.can_be_upgraded = true;
		Hall_rain_harden.base_stats["health"] = 2500f;
		Hall_rain_harden.burnable = false;
		Hall_rain_harden.setHousingSlots(5);
		Hall_rain_harden.housing_happiness = 10;
		Hall_rain_harden.loot_generation = 3;
		Hall_rain_harden.ignore_other_buildings_for_upgrade = true;
		Hall_rain_harden.build_place_batch = true;
		Hall_rain_harden.max_houses = 1;
		Hall_rain_harden.produce_biome_food = true;
		Hall_rain_harden.setShadow(0.56f, 0.41f, 0.43f);
		Hall_rain_harden.draw_light_size = 0.3f;
		Hall_rain_harden.book_slots = 5;
        Hall_rain_harden.draw_light_area = true;
		Hall_rain_harden.upgraded_from = "hall_human_0";
		Hall_rain_harden.sound_hit = "event:/SFX/HIT/HitWood";
		Hall_rain_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		Hall_rain_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        Hall_rain_harden.cost = new ConstructionCost(0, 0, 0, 1);
        Hall_rain_harden.group = "human";
        Hall_rain_harden.sprite_path = "buildings/Hall_rain_harden";
        Hall_rain_harden.base_stats["health"] = 4000f;
        Hall_rain_harden.has_sprites_main_disabled = false;
	    Hall_rain_harden.has_sprites_main = true;
	    Hall_rain_harden.has_sprites_ruin = true;
        Hall_rain_harden.shadow = false;
Hall_rain_harden.upgrade_level = 1;
Hall_rain_harden.has_sprite_construction = false;
Hall_rain_harden.upgrade_to = "Hall_rain_harden";
AssetManager.buildings.add(Hall_rain_harden);
AssetManager.buildings.loadSprites(Hall_rain_harden);



 BuildingAsset House_rain_harden = AssetManager.buildings.clone("House_rain_harden", "$building_civ_human$");
		House_rain_harden.setHousingSlots(4);
		House_rain_harden.loot_generation = 2;
		House_rain_harden.housing_happiness = 7;
		House_rain_harden.type = "type_house";
		House_rain_harden.sound_hit = "event:/SFX/HIT/HitWood";
		House_rain_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		House_rain_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        House_rain_harden.draw_light_area = true;
		House_rain_harden.draw_light_size = 0.2f;
        House_rain_harden.priority = 100;
        House_rain_harden.fundament = new BuildingFundament(1, 1, 2, 0);
        House_rain_harden.cost = new ConstructionCost(0, 0, 0, 1);
        House_rain_harden.group = "human";
        House_rain_harden.sprite_path = "buildings/House_rain_harden";
        House_rain_harden.base_stats["health"] = 2000f;
        House_rain_harden.burnable = false;
        House_rain_harden.has_sprites_main_disabled = false;
	    House_rain_harden.has_sprites_main = true;
	    House_rain_harden.has_sprites_ruin = true;
        House_rain_harden.shadow = false;
House_rain_harden.upgrade_level = 1;
House_rain_harden.can_be_upgraded = false;
House_rain_harden.has_sprite_construction = false;
House_rain_harden.upgrade_to = "House_rain_harden";
House_rain_harden.upgraded_from = "house_human_0";
AssetManager.buildings.add(House_rain_harden);
AssetManager.buildings.loadSprites(House_rain_harden);



BuildingAsset Barracks_rain_harden = AssetManager.buildings.clone("Barracks_rain_harden", "$building_civ_human$");
Barracks_rain_harden.draw_light_area = true;
Barracks_rain_harden.draw_light_size = 0.5f;
Barracks_rain_harden.type = "type_barracks";
Barracks_rain_harden.priority = 100;
Barracks_rain_harden.fundament = new BuildingFundament(3, 3, 4, 0);
Barracks_rain_harden.cost = new ConstructionCost(0, 0, 0, 1);
Barracks_rain_harden.group = "human";
Barracks_rain_harden.sprite_path = "buildings/Barracks_rain_harden";
Barracks_rain_harden.base_stats["health"] = 3000f;
Barracks_rain_harden.burnable = false;
Barracks_rain_harden.has_sprites_main_disabled = false;
Barracks_rain_harden.has_sprites_main = true;
Barracks_rain_harden.has_sprites_ruin = true;
Barracks_rain_harden.shadow = false;
Barracks_rain_harden.upgrade_level = 2;
Barracks_rain_harden.can_be_upgraded = false;
Barracks_rain_harden.has_sprite_construction = false;
Barracks_rain_harden.upgrade_to = "Barracks_industrial_harden";
Barracks_rain_harden.upgraded_from = "barracks_human";
Barracks_rain_harden.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBarracks";
Barracks_rain_harden.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Barracks_rain_harden.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
AssetManager.buildings.add(Barracks_rain_harden);
AssetManager.buildings.loadSprites(Barracks_rain_harden);




CityBuildOrderAsset hardenBuild = new CityBuildOrderAsset();
hardenBuild.id = "build_order_harden";

BuildOrder hardenorder;

hardenorder = hardenBuild.addBuilding("order_bonfire_harden", 1);

hardenorder = hardenBuild.addBuilding("order_stockpile", 1);

hardenorder = hardenBuild.addBuilding("order_hall_0", 1);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hardenorder = hardenBuild.addBuilding("order_house_0", 0, 0, 0, pCheckFullVillage: false, pCheckHouseLimit: true);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hardenBuild.addUpgrade("order_house_0");
hardenorder = hardenBuild.list.Last();
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hardenorder = hardenBuild.addBuilding("order_watch_tower", 0, 0, 0);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hardenorder = hardenBuild.addBuilding("order_temple", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

hardenBuild.addUpgrade("order_temple");
hardenorder = hardenBuild.list.Last();
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hardenorder = hardenBuild.addBuilding("order_mine", 1, 10, 10);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//hardenorder = hardenBuild.addBuilding("order_market", 1, 10, 10);
//hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

//hardenorder = hardenBuild.addBuilding("order_library", 1, 10, 10);
//hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

hardenorder = hardenBuild.addBuilding("order_docks_0", 5, 0, 2);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hardenBuild.addUpgrade("order_docks_0");
hardenorder = hardenBuild.list.Last();
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hardenBuild.addUpgrade("order_docks_1");
hardenorder = hardenBuild.list.Last();
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hardenorder = hardenBuild.addBuilding("order_windmill_0", 1, 6, 5);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hardenorder = hardenBuild.addBuilding("order_barracks", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hardenBuild.addUpgrade("order_barracks");
hardenorder = hardenBuild.list.Last();
hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//hardenorder = hardenBuild.addBuilding("order_training_dummy", 3, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
//hardenorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("order_temple");

AssetManager.city_build_orders.add(hardenBuild);






//////////////////////////////////////// GAIA RACES //////////////////////////////////


var elf = AssetManager.actor_library.get("elf");
elf.build_order_template_id = "build_order_gaia";

var civ_rabbit = AssetManager.actor_library.get("civ_rabbit");
civ_rabbit.build_order_template_id = "build_order_gaia";

var civ_cow = AssetManager.actor_library.get("civ_cow");
civ_cow.build_order_template_id = "build_order_gaia";

var civ_monkey = AssetManager.actor_library.get("civ_monkey");
civ_monkey.build_order_template_id = "build_order_gaia";

var civ_buffalo = AssetManager.actor_library.get("civ_buffalo");
civ_buffalo.build_order_template_id = "build_order_gaia";

var civ_alpaca = AssetManager.actor_library.get("civ_alpaca");
civ_alpaca.build_order_template_id = "build_order_gaia";

var civ_capybara = AssetManager.actor_library.get("civ_capybara");
civ_capybara.build_order_template_id = "build_order_gaia";

var civ_liliar = AssetManager.actor_library.get("civ_liliar");
civ_liliar.build_order_template_id = "build_order_gaia";

var druid = AssetManager.actor_library.get("druid");
druid.build_order_template_id = "build_order_gaia";

var civ_frog = AssetManager.actor_library.get("civ_frog");
civ_frog.build_order_template_id = "build_order_gaia";

var fairy = AssetManager.actor_library.get("fairy");
fairy.build_order_template_id = "build_order_gaia";


string[] gaiacivs = new string[] { "elf", "civ_rabbit", "civ_monkey", "civ_cow", "civ_buffalo", "civ_alpaca", "civ_capybara", "civ_frog", "civ_liliar", "druid", "fairy" };


foreach (string gaiaciv in gaiacivs)
{
    string barracksId = $"barracks_{gaiaciv}";
    BuildingAsset barracks = AssetManager.buildings.get(barracksId);

    if (barracks != null)
    {
        barracks.priority = 100;
        barracks.fundament = new BuildingFundament(3, 3, 4, 0);
        barracks.cost = new ConstructionCost(0, 0, 0, 1);
        barracks.group = gaiaciv;
        barracks.shadow = false;
barracks.upgrade_level = 1;
barracks.build_prefer_replace_house = true;
barracks.can_be_upgraded = true;
barracks.upgrade_to = "Barracks_rain_gaia";

        AssetManager.buildings.add(barracks);
    }


    string houseId = $"house_{gaiaciv}_0";
    BuildingAsset house = AssetManager.buildings.get(houseId);

    if (house != null)
    {
        house.cost = new ConstructionCost(0, 0, 0, 1);
        house.group = gaiaciv;
        house.shadow = false;
house.upgrade_level = 0;
house.can_be_upgraded = true;
house.upgrade_to = "House_rain_gaia";

        AssetManager.buildings.add(house);
    }

      string hallId = $"hall_{gaiaciv}_0";
    BuildingAsset hall = AssetManager.buildings.get(hallId);

    if (hall != null)
    {
        hall.cost = new ConstructionCost(0, 0, 0, 1);
        hall.group = gaiaciv;
        hall.shadow = false;
        hall.max_houses = 1;
hall.upgrade_level = 0;
hall.can_be_upgraded = true;
hall.upgrade_to = "Hall_rain_gaia";

        AssetManager.buildings.add(hall);
    }

          string templeId = $"temple_{gaiaciv}";
    BuildingAsset temple = AssetManager.buildings.get(templeId);

    if (temple != null)
    {
        temple.cost = new ConstructionCost(0, 0, 0, 1);
        temple.shadow = false;
temple.upgrade_level = 0;
temple.group = gaiaciv;
temple.can_be_upgraded = true;
temple.max_houses = 1;
temple.storage = true;
temple.book_slots = 10;
temple.build_prefer_replace_house = true;
temple.upgrade_to = "Temple_rain_gaia";

        AssetManager.buildings.add(temple);
    }

      string dockId = $"docks_{gaiaciv}";
    BuildingAsset docks = AssetManager.buildings.get(dockId);

    if (docks != null)
    {
docks.cost = new ConstructionCost(0, 0, 0, 1);
docks.shadow = false;
docks.upgrade_level = 2;
docks.can_be_upgraded = true;
docks.build_prefer_replace_house = true;
docks.upgrade_to = "Docks_rain_gaia";
docks.group = gaiaciv;
docks.civ_kingdom = gaiaciv;

        AssetManager.buildings.add(docks);
    }

}


BuildingAsset Docks_rain_gaia = AssetManager.buildings.clone("Docks_rain_gaia", "docks_human");
Docks_rain_gaia.boat_types = new string[6] { "cargo_gaia_boat", "destroyer_a_gaia_boat", "destroyer_b_gaia_boat", "carrier_gaia_boat", "submarine_gaia_boat", "fishing_gaia_boat" };
Docks_rain_gaia.priority = 100;
Docks_rain_gaia.group = "human";
Docks_rain_gaia.civ_kingdom = "human";
Docks_rain_gaia.cost = new ConstructionCost(0, 0, 0, 1);
Docks_rain_gaia.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Docks_rain_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Docks_rain_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Docks_rain_gaia.base_stats["health"] = 2500f;
Docks_rain_gaia.burnable = false;
Docks_rain_gaia.can_be_upgraded = true;
Docks_rain_gaia.sprite_path = "buildings/dock_rain_universalWIP";
Docks_rain_gaia.has_sprites_main_disabled = false;
Docks_rain_gaia.has_sprites_main = true;
Docks_rain_gaia.has_sprites_ruin = true;
Docks_rain_gaia.shadow = false;
Docks_rain_gaia.upgrade_level = 3;
Docks_rain_gaia.has_sprite_construction = false;
Docks_rain_gaia.upgrade_to = "Docks_rain_gaia";
Docks_rain_gaia.upgraded_from = "docks_human";
AssetManager.buildings.add(Docks_rain_gaia);
AssetManager.buildings.loadSprites(Docks_rain_gaia);


BuildingAsset bonfire_gaia = AssetManager.buildings.clone("bonfire_gaia", "$city_building$");
bonfire_gaia.draw_light_area = true;
bonfire_gaia.draw_light_size = 0.8f;
bonfire_gaia.can_be_abandoned = false;
bonfire_gaia.priority = 120;
bonfire_gaia.type = "type_bonfire";
bonfire_gaia.fundament = new BuildingFundament(2, 2, 2, 0);
bonfire_gaia.construction_progress_needed = 30;
bonfire_gaia.cost = new ConstructionCost();
bonfire_gaia.smoke = true;
bonfire_gaia.smoke_interval = 2.5f;
bonfire_gaia.smoke_offset = new Vector2Int(2, 3);
bonfire_gaia.can_be_living_house = false;
bonfire_gaia.build_place_batch = false;
bonfire_gaia.build_prefer_replace_house = true;
bonfire_gaia.check_for_close_building = false;
bonfire_gaia.produce_biome_food = true;
bonfire_gaia.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBonfire";
bonfire_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
bonfire_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingGeneric";
bonfire_gaia.check_for_adaptation_tags = false;
bonfire_gaia.max_houses = 1;
bonfire_gaia.base_stats["health"] = 1500f;
bonfire_gaia.burnable = false;
bonfire_gaia.can_be_upgraded = true;
bonfire_gaia.sprite_path = "buildings/bonfire_gaia";
bonfire_gaia.has_sprites_main_disabled = false;
bonfire_gaia.has_sprites_main = true;
bonfire_gaia.has_sprites_ruin = true;
bonfire_gaia.shadow = false;
bonfire_gaia.upgrade_level = 0;
bonfire_gaia.has_sprite_construction = false;
bonfire_gaia.upgrade_to = "bonfire_gaia";
AssetManager.buildings.add(bonfire_gaia);
AssetManager.buildings.loadSprites(bonfire_gaia);


BuildingAsset Temple_rain_gaia = AssetManager.buildings.clone("Temple_rain_gaia", "$building_civ_human$");
Temple_rain_gaia.storage = true;
Temple_rain_gaia.book_slots = 15;
Temple_rain_gaia.draw_light_area = true;
Temple_rain_gaia.draw_light_size = 0.3f;
Temple_rain_gaia.draw_light_area_offset_y = 3f;
Temple_rain_gaia.priority = 100;
Temple_rain_gaia.type = "type_temple";
Temple_rain_gaia.fundament = new BuildingFundament(2, 2, 3, 0);
Temple_rain_gaia.cost = new ConstructionCost(0, 0, 0, 1);
Temple_rain_gaia.group = "human";
Temple_rain_gaia.max_houses = 1;
Temple_rain_gaia.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Temple_rain_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Temple_rain_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Temple_rain_gaia.base_stats["health"] = 2500f;
Temple_rain_gaia.burnable = false;
Temple_rain_gaia.can_be_upgraded = true;
Temple_rain_gaia.sprite_path = "buildings/Temple_rain_gaia";
Temple_rain_gaia.has_sprites_main_disabled = false;
Temple_rain_gaia.has_sprites_main = true;
Temple_rain_gaia.has_sprites_ruin = true;
Temple_rain_gaia.shadow = false;
Temple_rain_gaia.upgrade_level = 1;
Temple_rain_gaia.has_sprite_construction = false;
Temple_rain_gaia.upgrade_to = "Temple_rain_gaia";
Temple_rain_gaia.upgraded_from = "temple_human";
AssetManager.buildings.add(Temple_rain_gaia);
AssetManager.buildings.loadSprites(Temple_rain_gaia);



 BuildingAsset Hall_rain_gaia = AssetManager.buildings.clone("Hall_rain_gaia", "$building_civ_human$");
		Hall_rain_gaia.priority = 100;
		Hall_rain_gaia.storage = true;
		Hall_rain_gaia.type = "type_hall";
		Hall_rain_gaia.fundament = new BuildingFundament(3, 3, 4, 0);
		Hall_rain_gaia.can_be_upgraded = true;
		Hall_rain_gaia.base_stats["health"] = 2500f;
		Hall_rain_gaia.burnable = false;
		Hall_rain_gaia.setHousingSlots(5);
		Hall_rain_gaia.housing_happiness = 10;
		Hall_rain_gaia.loot_generation = 3;
		Hall_rain_gaia.ignore_other_buildings_for_upgrade = true;
		Hall_rain_gaia.build_place_batch = true;
		Hall_rain_gaia.max_houses = 1;
		Hall_rain_gaia.produce_biome_food = true;
		Hall_rain_gaia.setShadow(0.56f, 0.41f, 0.43f);
		Hall_rain_gaia.draw_light_size = 0.3f;
		Hall_rain_gaia.book_slots = 5;
        Hall_rain_gaia.draw_light_area = true;
		Hall_rain_gaia.upgraded_from = "hall_human_0";
		Hall_rain_gaia.sound_hit = "event:/SFX/HIT/HitWood";
		Hall_rain_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		Hall_rain_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        Hall_rain_gaia.cost = new ConstructionCost(0, 0, 0, 1);
        Hall_rain_gaia.group = "human";
        Hall_rain_gaia.sprite_path = "buildings/Hall_rain_gaia";
        Hall_rain_gaia.base_stats["health"] = 4000f;
        Hall_rain_gaia.has_sprites_main_disabled = false;
	    Hall_rain_gaia.has_sprites_main = true;
	    Hall_rain_gaia.has_sprites_ruin = true;
        Hall_rain_gaia.shadow = false;
Hall_rain_gaia.upgrade_level = 1;
Hall_rain_gaia.has_sprite_construction = false;
Hall_rain_gaia.upgrade_to = "Hall_rain_gaia";
AssetManager.buildings.add(Hall_rain_gaia);
AssetManager.buildings.loadSprites(Hall_rain_gaia);



 BuildingAsset House_rain_gaia = AssetManager.buildings.clone("House_rain_gaia", "$building_civ_human$");
		House_rain_gaia.setHousingSlots(4);
		House_rain_gaia.loot_generation = 2;
		House_rain_gaia.housing_happiness = 7;
		House_rain_gaia.type = "type_house";
		House_rain_gaia.sound_hit = "event:/SFX/HIT/HitWood";
		House_rain_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		House_rain_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        House_rain_gaia.draw_light_area = true;
		House_rain_gaia.draw_light_size = 0.2f;
        House_rain_gaia.priority = 100;
        House_rain_gaia.fundament = new BuildingFundament(1, 1, 2, 0);
        House_rain_gaia.cost = new ConstructionCost(0, 0, 0, 1);
        House_rain_gaia.group = "human";
        House_rain_gaia.sprite_path = "buildings/House_rain_gaia";
        House_rain_gaia.base_stats["health"] = 2000f;
        House_rain_gaia.burnable = false;
        House_rain_gaia.has_sprites_main_disabled = false;
	    House_rain_gaia.has_sprites_main = true;
	    House_rain_gaia.has_sprites_ruin = true;
        House_rain_gaia.shadow = false;
House_rain_gaia.upgrade_level = 1;
House_rain_gaia.can_be_upgraded = false;
House_rain_gaia.has_sprite_construction = false;
House_rain_gaia.upgrade_to = "House_rain_gaia";
House_rain_gaia.upgraded_from = "house_human_0";
AssetManager.buildings.add(House_rain_gaia);
AssetManager.buildings.loadSprites(House_rain_gaia);



BuildingAsset Barracks_rain_gaia = AssetManager.buildings.clone("Barracks_rain_gaia", "$building_civ_human$");
Barracks_rain_gaia.draw_light_area = true;
Barracks_rain_gaia.draw_light_size = 0.5f;
Barracks_rain_gaia.type = "type_barracks";
Barracks_rain_gaia.priority = 100;
Barracks_rain_gaia.fundament = new BuildingFundament(3, 3, 4, 0);
Barracks_rain_gaia.cost = new ConstructionCost(0, 0, 0, 1);
Barracks_rain_gaia.group = "human";
Barracks_rain_gaia.sprite_path = "buildings/Barracks_rain_gaia";
Barracks_rain_gaia.base_stats["health"] = 3000f;
Barracks_rain_gaia.burnable = false;
Barracks_rain_gaia.has_sprites_main_disabled = false;
Barracks_rain_gaia.has_sprites_main = true;
Barracks_rain_gaia.has_sprites_ruin = true;
Barracks_rain_gaia.shadow = false;
Barracks_rain_gaia.upgrade_level = 2;
Barracks_rain_gaia.can_be_upgraded = false;
Barracks_rain_gaia.has_sprite_construction = false;
Barracks_rain_gaia.upgrade_to = "Barracks_industrial_gaia";
Barracks_rain_gaia.upgraded_from = "barracks_human";
Barracks_rain_gaia.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBarracks";
Barracks_rain_gaia.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Barracks_rain_gaia.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
AssetManager.buildings.add(Barracks_rain_gaia);
AssetManager.buildings.loadSprites(Barracks_rain_gaia);




CityBuildOrderAsset gaiaBuild = new CityBuildOrderAsset();
gaiaBuild.id = "build_order_gaia";

BuildOrder gaiaorder;

gaiaorder = gaiaBuild.addBuilding("order_bonfire_gaia", 1);

gaiaorder = gaiaBuild.addBuilding("order_stockpile", 1);

gaiaorder = gaiaBuild.addBuilding("order_hall_0", 1);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

gaiaorder = gaiaBuild.addBuilding("order_house_0", 0, 0, 0, pCheckFullVillage: false, pCheckHouseLimit: true);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

gaiaBuild.addUpgrade("order_house_0");
gaiaorder = gaiaBuild.list.Last();
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

gaiaorder = gaiaBuild.addBuilding("order_watch_tower", 0, 0, 0);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

gaiaorder = gaiaBuild.addBuilding("order_temple", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

gaiaBuild.addUpgrade("order_temple");
gaiaorder = gaiaBuild.list.Last();
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

gaiaorder = gaiaBuild.addBuilding("order_mine", 1, 10, 10);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//gaiaorder = gaiaBuild.addBuilding("order_market", 1, 10, 10);
//gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

//gaiaorder = gaiaBuild.addBuilding("order_library", 1, 10, 10);
//gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

gaiaorder = gaiaBuild.addBuilding("order_docks_0", 5, 0, 2);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

gaiaBuild.addUpgrade("order_docks_0");
gaiaorder = gaiaBuild.list.Last();
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

gaiaBuild.addUpgrade("order_docks_1");
gaiaorder = gaiaBuild.list.Last();
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

gaiaorder = gaiaBuild.addBuilding("order_windmill_0", 1, 6, 5);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

gaiaorder = gaiaBuild.addBuilding("order_barracks", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

gaiaBuild.addUpgrade("order_barracks");
gaiaorder = gaiaBuild.list.Last();
gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//gaiaorder = gaiaBuild.addBuilding("order_training_dummy", 3, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
//gaiaorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("order_temple");

AssetManager.city_build_orders.add(gaiaBuild);



//////////////////////////////////////// HORDE RACES //////////////////////////////////


var orc = AssetManager.actor_library.get("orc");
orc.build_order_template_id = "build_order_horde";

var necromancer = AssetManager.actor_library.get("necromancer");
necromancer.build_order_template_id = "build_order_horde";

var civ_fox = AssetManager.actor_library.get("civ_fox");
civ_fox.build_order_template_id = "build_order_horde";

var civ_wolf = AssetManager.actor_library.get("civ_wolf");
civ_wolf.build_order_template_id = "build_order_horde";

var civ_bear = AssetManager.actor_library.get("civ_bear");
civ_bear.build_order_template_id = "build_order_horde";

var civ_hyena = AssetManager.actor_library.get("civ_hyena");
civ_hyena.build_order_template_id = "build_order_horde";

var civ_rat = AssetManager.actor_library.get("civ_rat");
civ_rat.build_order_template_id = "build_order_horde";

var civ_scorpion = AssetManager.actor_library.get("civ_scorpion");
civ_scorpion.build_order_template_id = "build_order_horde";

var civ_crocodile = AssetManager.actor_library.get("civ_crocodile");
civ_crocodile.build_order_template_id = "build_order_horde";

var civ_snake = AssetManager.actor_library.get("civ_snake");
civ_snake.build_order_template_id = "build_order_horde";

var civ_piranha = AssetManager.actor_library.get("civ_piranha");
civ_piranha.build_order_template_id = "build_order_horde";

var greg = AssetManager.actor_library.get("greg");
greg.build_order_template_id = "build_order_horde";

var jumpy_skull = AssetManager.actor_library.get("jumpy_skull");
jumpy_skull.build_order_template_id = "build_order_horde";


string[] hordecivs = new string[] { "orc", "necromancer", "fire_skull", "civ_fox", "civ_wolf", "civ_bear", "civ_hyena", "civ_rat", "civ_scorpion", "civ_crocodile", "civ_snake", "civ_piranha", "greg", "jumpy_skull" };



foreach (string hordeciv in hordecivs)
{
    string barracksId = $"barracks_{hordeciv}";
    BuildingAsset barracks = AssetManager.buildings.get(barracksId);

    if (barracks != null)
    {
        barracks.priority = 100;
        barracks.fundament = new BuildingFundament(3, 3, 4, 0);
        barracks.cost = new ConstructionCost(0, 0, 0, 1);
        barracks.group = hordeciv;
        barracks.shadow = false;
barracks.upgrade_level = 1;
barracks.build_prefer_replace_house = true;
barracks.can_be_upgraded = true;
barracks.upgrade_to = "Barracks_rain_horde";

        AssetManager.buildings.add(barracks);
    }


    string houseId = $"house_{hordeciv}_0";
    BuildingAsset house = AssetManager.buildings.get(houseId);

    if (house != null)
    {
        house.cost = new ConstructionCost(0, 0, 0, 1);
        house.group = hordeciv;
        house.shadow = false;
house.upgrade_level = 0;
house.can_be_upgraded = true;
house.upgrade_to = "House_rain_horde";

        AssetManager.buildings.add(house);
    }

      string hallId = $"hall_{hordeciv}_0";
    BuildingAsset hall = AssetManager.buildings.get(hallId);

    if (hall != null)
    {
        hall.cost = new ConstructionCost(0, 0, 0, 1);
        hall.group = hordeciv;
        hall.shadow = false;
        hall.max_houses = 1;
hall.upgrade_level = 0;
hall.can_be_upgraded = true;
hall.upgrade_to = "Hall_rain_horde";

        AssetManager.buildings.add(hall);
    }

          string templeId = $"temple_{hordeciv}";
    BuildingAsset temple = AssetManager.buildings.get(templeId);

    if (temple != null)
    {
        temple.cost = new ConstructionCost(0, 0, 0, 1);
        temple.shadow = false;
temple.upgrade_level = 0;
temple.group = hordeciv;
temple.can_be_upgraded = true;
temple.max_houses = 1;
temple.storage = true;
temple.book_slots = 10;
temple.build_prefer_replace_house = true;
temple.upgrade_to = "Temple_rain_horde";

        AssetManager.buildings.add(temple);
    }

      string dockId = $"docks_{hordeciv}";
    BuildingAsset docks = AssetManager.buildings.get(dockId);

    if (docks != null)
    {
docks.cost = new ConstructionCost(0, 0, 0, 1);
docks.shadow = false;
docks.upgrade_level = 2;
docks.can_be_upgraded = true;
docks.build_prefer_replace_house = true;
docks.upgrade_to = "Docks_rain_horde";
docks.group = hordeciv;
docks.civ_kingdom = hordeciv;

        AssetManager.buildings.add(docks);
    }

}


BuildingAsset Docks_rain_horde = AssetManager.buildings.clone("Docks_rain_horde", "docks_human");
Docks_rain_horde.boat_types = new string[6] { "cargo_horde_boat", "destroyer_a_horde_boat", "destroyer_b_horde_boat", "carrier_horde_boat", "submarine_horde_boat", "fishing_horde_boat" };
Docks_rain_horde.priority = 100;
Docks_rain_horde.group = "human";
Docks_rain_horde.civ_kingdom = "human";
Docks_rain_horde.cost = new ConstructionCost(0, 0, 0, 1);
Docks_rain_horde.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Docks_rain_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Docks_rain_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Docks_rain_horde.base_stats["health"] = 2500f;
Docks_rain_horde.burnable = false;
Docks_rain_horde.can_be_upgraded = true;
Docks_rain_horde.sprite_path = "buildings/dock_rain_universalWIP";
Docks_rain_horde.has_sprites_main_disabled = false;
Docks_rain_horde.has_sprites_main = true;
Docks_rain_horde.has_sprites_ruin = true;
Docks_rain_horde.shadow = false;
Docks_rain_horde.upgrade_level = 3;
Docks_rain_horde.has_sprite_construction = false;
Docks_rain_horde.upgrade_to = "Docks_rain_horde";
Docks_rain_horde.upgraded_from = "docks_human";
AssetManager.buildings.add(Docks_rain_horde);
AssetManager.buildings.loadSprites(Docks_rain_horde);


BuildingAsset bonfire_horde = AssetManager.buildings.clone("bonfire_horde", "$city_building$");
bonfire_horde.draw_light_area = true;
bonfire_horde.draw_light_size = 0.8f;
bonfire_horde.can_be_abandoned = false;
bonfire_horde.priority = 120;
bonfire_horde.type = "type_bonfire";
bonfire_horde.fundament = new BuildingFundament(2, 2, 2, 0);
bonfire_horde.construction_progress_needed = 30;
bonfire_horde.cost = new ConstructionCost();
bonfire_horde.smoke = true;
bonfire_horde.smoke_interval = 2.5f;
bonfire_horde.smoke_offset = new Vector2Int(2, 3);
bonfire_horde.can_be_living_house = false;
bonfire_horde.build_place_batch = false;
bonfire_horde.build_prefer_replace_house = true;
bonfire_horde.check_for_close_building = false;
bonfire_horde.produce_biome_food = true;
bonfire_horde.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBonfire";
bonfire_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
bonfire_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingGeneric";
bonfire_horde.check_for_adaptation_tags = false;
bonfire_horde.max_houses = 1;
bonfire_horde.base_stats["health"] = 1500f;
bonfire_horde.burnable = false;
bonfire_horde.can_be_upgraded = true;
bonfire_horde.sprite_path = "buildings/bonfire_horde";
bonfire_horde.has_sprites_main_disabled = false;
bonfire_horde.has_sprites_main = true;
bonfire_horde.has_sprites_ruin = true;
bonfire_horde.shadow = false;
bonfire_horde.upgrade_level = 0;
bonfire_horde.has_sprite_construction = false;
bonfire_horde.upgrade_to = "bonfire_horde";
AssetManager.buildings.add(bonfire_horde);
AssetManager.buildings.loadSprites(bonfire_horde);


BuildingAsset Temple_rain_horde = AssetManager.buildings.clone("Temple_rain_horde", "$building_civ_human$");
Temple_rain_horde.storage = true;
Temple_rain_horde.book_slots = 15;
Temple_rain_horde.draw_light_area = true;
Temple_rain_horde.draw_light_size = 0.3f;
Temple_rain_horde.draw_light_area_offset_y = 3f;
Temple_rain_horde.priority = 100;
Temple_rain_horde.type = "type_temple";
Temple_rain_horde.fundament = new BuildingFundament(2, 2, 3, 0);
Temple_rain_horde.cost = new ConstructionCost(0, 0, 0, 1);
Temple_rain_horde.group = "human";
Temple_rain_horde.max_houses = 1;
Temple_rain_horde.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleTemple";
Temple_rain_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Temple_rain_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
Temple_rain_horde.base_stats["health"] = 2500f;
Temple_rain_horde.burnable = false;
Temple_rain_horde.can_be_upgraded = true;
Temple_rain_horde.sprite_path = "buildings/Temple_rain_horde";
Temple_rain_horde.has_sprites_main_disabled = false;
Temple_rain_horde.has_sprites_main = true;
Temple_rain_horde.has_sprites_ruin = true;
Temple_rain_horde.shadow = false;
Temple_rain_horde.upgrade_level = 1;
Temple_rain_horde.has_sprite_construction = false;
Temple_rain_horde.upgrade_to = "Temple_rain_horde";
Temple_rain_horde.upgraded_from = "temple_human";
AssetManager.buildings.add(Temple_rain_horde);
AssetManager.buildings.loadSprites(Temple_rain_horde);



 BuildingAsset Hall_rain_horde = AssetManager.buildings.clone("Hall_rain_horde", "$building_civ_human$");
		Hall_rain_horde.priority = 100;
		Hall_rain_horde.storage = true;
		Hall_rain_horde.type = "type_hall";
		Hall_rain_horde.fundament = new BuildingFundament(3, 3, 4, 0);
		Hall_rain_horde.can_be_upgraded = true;
		Hall_rain_horde.base_stats["health"] = 2500f;
		Hall_rain_horde.burnable = false;
		Hall_rain_horde.setHousingSlots(5);
		Hall_rain_horde.housing_happiness = 10;
		Hall_rain_horde.loot_generation = 3;
		Hall_rain_horde.ignore_other_buildings_for_upgrade = true;
		Hall_rain_horde.build_place_batch = true;
		Hall_rain_horde.max_houses = 1;
		Hall_rain_horde.produce_biome_food = true;
		Hall_rain_horde.setShadow(0.56f, 0.41f, 0.43f);
		Hall_rain_horde.draw_light_size = 0.3f;
		Hall_rain_horde.book_slots = 5;
        Hall_rain_horde.draw_light_area = true;
		Hall_rain_horde.upgraded_from = "hall_human_0";
		Hall_rain_horde.sound_hit = "event:/SFX/HIT/HitWood";
		Hall_rain_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		Hall_rain_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        Hall_rain_horde.cost = new ConstructionCost(0, 0, 0, 1);
        Hall_rain_horde.group = "human";
        Hall_rain_horde.sprite_path = "buildings/Hall_rain_horde";
        Hall_rain_horde.base_stats["health"] = 4000f;
        Hall_rain_horde.has_sprites_main_disabled = false;
	    Hall_rain_horde.has_sprites_main = true;
	    Hall_rain_horde.has_sprites_ruin = true;
        Hall_rain_horde.shadow = false;
Hall_rain_horde.upgrade_level = 1;
Hall_rain_horde.has_sprite_construction = false;
Hall_rain_horde.upgrade_to = "Hall_rain_horde";
AssetManager.buildings.add(Hall_rain_horde);
AssetManager.buildings.loadSprites(Hall_rain_horde);



 BuildingAsset House_rain_horde = AssetManager.buildings.clone("House_rain_horde", "$building_civ_human$");
		House_rain_horde.setHousingSlots(4);
		House_rain_horde.loot_generation = 2;
		House_rain_horde.housing_happiness = 7;
		House_rain_horde.type = "type_house";
		House_rain_horde.sound_hit = "event:/SFX/HIT/HitWood";
		House_rain_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingWood";
		House_rain_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingWood";
        House_rain_horde.draw_light_area = true;
		House_rain_horde.draw_light_size = 0.2f;
        House_rain_horde.priority = 100;
        House_rain_horde.fundament = new BuildingFundament(1, 1, 2, 0);
        House_rain_horde.cost = new ConstructionCost(0, 0, 0, 1);
        House_rain_horde.group = "human";
        House_rain_horde.sprite_path = "buildings/House_rain_horde";
        House_rain_horde.base_stats["health"] = 2000f;
        House_rain_horde.burnable = false;
        House_rain_horde.has_sprites_main_disabled = false;
	    House_rain_horde.has_sprites_main = true;
	    House_rain_horde.has_sprites_ruin = true;
        House_rain_horde.shadow = false;
House_rain_horde.upgrade_level = 1;
House_rain_horde.can_be_upgraded = false;
House_rain_horde.has_sprite_construction = false;
House_rain_horde.upgrade_to = "House_rain_horde";
House_rain_horde.upgraded_from = "house_human_0";
AssetManager.buildings.add(House_rain_horde);
AssetManager.buildings.loadSprites(House_rain_horde);



BuildingAsset Barracks_rain_horde = AssetManager.buildings.clone("Barracks_rain_horde", "$building_civ_human$");
Barracks_rain_horde.draw_light_area = true;
Barracks_rain_horde.draw_light_size = 0.5f;
Barracks_rain_horde.type = "type_barracks";
Barracks_rain_horde.priority = 100;
Barracks_rain_horde.fundament = new BuildingFundament(3, 3, 4, 0);
Barracks_rain_horde.cost = new ConstructionCost(0, 0, 0, 1);
Barracks_rain_horde.group = "human";
Barracks_rain_horde.sprite_path = "buildings/Barracks_rain_horde";
Barracks_rain_horde.base_stats["health"] = 3000f;
Barracks_rain_horde.burnable = false;
Barracks_rain_horde.has_sprites_main_disabled = false;
Barracks_rain_horde.has_sprites_main = true;
Barracks_rain_horde.has_sprites_ruin = true;
Barracks_rain_horde.shadow = false;
Barracks_rain_horde.upgrade_level = 2;
Barracks_rain_horde.can_be_upgraded = false;
Barracks_rain_horde.has_sprite_construction = false;
Barracks_rain_horde.upgrade_to = "Barracks_industrial_horde";
Barracks_rain_horde.upgraded_from = "barracks_human";
Barracks_rain_horde.sound_idle = "event:/SFX/BUILDINGS_IDLE/IdleBarracks";
Barracks_rain_horde.sound_built = "event:/SFX/BUILDINGS/SpawnBuildingStone";
Barracks_rain_horde.sound_destroyed = "event:/SFX/BUILDINGS/DestroyBuildingStone";
AssetManager.buildings.add(Barracks_rain_horde);
AssetManager.buildings.loadSprites(Barracks_rain_horde);




CityBuildOrderAsset hordeBuild = new CityBuildOrderAsset();
hordeBuild.id = "build_order_horde";

BuildOrder hordeorder;

hordeorder = hordeBuild.addBuilding("order_bonfire_horde", 1);

hordeorder = hordeBuild.addBuilding("order_stockpile", 1);

hordeorder = hordeBuild.addBuilding("order_hall_0", 1);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hordeorder = hordeBuild.addBuilding("order_house_0", 0, 0, 0, pCheckFullVillage: false, pCheckHouseLimit: true);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hordeBuild.addUpgrade("order_house_0");
hordeorder = hordeBuild.list.Last();
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hordeorder = hordeBuild.addBuilding("order_watch_tower", 0, 0, 0);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hordeorder = hordeBuild.addBuilding("order_temple", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

hordeBuild.addUpgrade("order_temple");
hordeorder = hordeBuild.list.Last();
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hordeorder = hordeBuild.addBuilding("order_mine", 1, 10, 10);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//hordeorder = hordeBuild.addBuilding("order_market", 1, 10, 10);
//hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

//hordeorder = hordeBuild.addBuilding("order_library", 1, 10, 10);
//hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_barracks");

hordeorder = hordeBuild.addBuilding("order_docks_0", 5, 0, 2);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hordeBuild.addUpgrade("order_docks_0");
hordeorder = hordeBuild.list.Last();
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hordeBuild.addUpgrade("order_docks_1");
hordeorder = hordeBuild.list.Last();
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hordeorder = hordeBuild.addBuilding("order_windmill_0", 1, 6, 5);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_bonfire");

hordeorder = hordeBuild.addBuilding("order_barracks", 1, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

hordeBuild.addUpgrade("order_barracks");
hordeorder = hordeBuild.list.Last();
hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("type_hall");

//hordeorder = hordeBuild.addBuilding("order_training_dummy", 3, 10, 10, pCheckFullVillage: false, pCheckHouseLimit: false, 10);
//hordeorder.requirements_types = AssetLibrary<CityBuildOrderAsset>.a<string>("order_temple");

AssetManager.city_build_orders.add(hordeBuild);



        }



[HarmonyPatch(typeof(BuildOrder), nameof(BuildOrder.getBuildingAsset))]
public static class Patch_CustomBuildOrder
{
    public static bool Prefix(BuildOrder __instance, City pCity, string pOrderID, ref BuildingAsset __result)
    {
        string order = string.IsNullOrEmpty(pOrderID) ? __instance.id : pOrderID;

        if (order == "order_bonfire_alliance")
        {
            __result = AssetManager.buildings.get("bonfire_alliance");
            return false;
        }
        else if (order == "order_bonfire_horde")
        {
            __result = AssetManager.buildings.get("bonfire_horde");
            return false;
        }
        else if (order == "order_bonfire_gaia")
        {
            __result = AssetManager.buildings.get("bonfire_gaia");
            return false;
        }
        else if (order == "order_bonfire_harden")
        {
            __result = AssetManager.buildings.get("bonfire_harden");
            return false;
        }
        return true;
    }
}

private static void AddBuildingOrderlol(string architectureID, string orderKey, string buildingID)
{
    ArchitectureAsset architecture = AssetManager.architecture_library.get(architectureID);
    if (architecture != null)
    {
        architecture.addBuildingOrderKey(orderKey, buildingID);
    }
}



     [HarmonyPatch(typeof(Docks), "buildBoatFromHere")]
        public static class Patch_Docks_BuildBoatFromHere
        {
            static bool Prefix(Docks __instance, City pCity, ref Actor __result)
            {
                if (__instance.building.asset.id == "Docks_rain_alliance")
                {
                    int totalAllianceBoats =
                        __instance.countBoatTypes("cargo_alliance_boat") +
                        __instance.countBoatTypes("destroyer_a_alliance_boat") +
                        __instance.countBoatTypes("destroyer_b_alliance_boat") +
                        __instance.countBoatTypes("carrier_alliance_boat") +
                        __instance.countBoatTypes("submarine_alliance_boat") +
                        __instance.countBoatTypes("fishing_alliance_boat");

                    if (totalAllianceBoats >= 6)
                    {
                        __result = null;
                        return false;
                    }

                    if (!pCity.hasEnoughResourcesFor(new ConstructionCost(0, 0, 0, 1)))
                    {
                        __result = null;
                        return false;
                    }

                    if (__instance.tiles_ocean.Count == 0)
                    {
                        __instance.recalculateOceanTiles();
                        __result = null;
                        return false;
                    }

                    WorldTile tTile = __instance.tiles_ocean.GetRandom();
                    if (!tTile.region.island.goodForDocks())
                    {
                        __result = null;
                        return false;
                    }

                    string[] boatAssetIds = new string[] {
                        "CargoShip_alliance",
                        "aDestroyer_alliance",
                        "bDestroyer_alliance",
                        "CarrierVessel_alliance",
                        "Submarine_alliance",
                        "FishingBoat_alliance"
                    };

                    string selectedBoatAssetId = boatAssetIds[Randy.randomInt(0, boatAssetIds.Length)];
                    Actor tNewBoat = World.world.units.createNewUnit(selectedBoatAssetId, tTile);

                    if (tNewBoat == null)
                    {
                        __result = null;
                        return false;
                    }

                    __instance.addBoatToDock(tNewBoat);

                    tNewBoat.setKingdom(pCity.kingdom);
                    tNewBoat.setCity(pCity);

                    pCity.spendResourcesForBuildingAsset(new ConstructionCost(0, 0, 0, 1));

                    __result = tNewBoat;
                    return false;
                }
                 else if (__instance.building.asset.id == "Docks_rain_gaia")
                {
                    int totalgaiaBoats =
                        __instance.countBoatTypes("cargo_gaia_boat") +
                        __instance.countBoatTypes("destroyer_a_gaia_boat") +
                        __instance.countBoatTypes("destroyer_b_gaia_boat") +
                        __instance.countBoatTypes("carrier_gaia_boat") +
                        __instance.countBoatTypes("submarine_gaia_boat") +
                        __instance.countBoatTypes("fishing_gaia_boat");

                    if (totalgaiaBoats >= 6)
                    {
                        __result = null;
                        return false;
                    }

                    if (!pCity.hasEnoughResourcesFor(new ConstructionCost(0, 0, 0, 1)))
                    {
                        __result = null;
                        return false;
                    }

                    if (__instance.tiles_ocean.Count == 0)
                    {
                        __instance.recalculateOceanTiles();
                        __result = null;
                        return false;
                    }

                    WorldTile tTile = __instance.tiles_ocean.GetRandom();
                    if (!tTile.region.island.goodForDocks())
                    {
                        __result = null;
                        return false;
                    }

                    string[] boatAssetgaiaIds = new string[] {
                        "CargoShip_gaia",
                        "aDestroyer_gaia",
                        "bDestroyer_gaia",
                        "CarrierVessel_gaia",
                        "Submarine_gaia",
                        "FishingBoat_gaia"
                    };

                    string selectedBoatgaiaAssetId = boatAssetgaiaIds[Randy.randomInt(0, boatAssetgaiaIds.Length)];
                    Actor tNewBoat = World.world.units.createNewUnit(selectedBoatgaiaAssetId, tTile);

                    if (tNewBoat == null)
                    {
                        __result = null;
                        return false;
                    }

                    __instance.addBoatToDock(tNewBoat);

                    tNewBoat.setKingdom(pCity.kingdom);
                    tNewBoat.setCity(pCity);

                    pCity.spendResourcesForBuildingAsset(new ConstructionCost(0, 0, 0, 1));

                    __result = tNewBoat;
                    return false;
                }
                                else if (__instance.building.asset.id == "Docks_rain_horde")
                {
                    int totalhordeBoats =
                        __instance.countBoatTypes("cargo_horde_boat") +
                        __instance.countBoatTypes("destroyer_a_horde_boat") +
                        __instance.countBoatTypes("destroyer_b_horde_boat") +
                        __instance.countBoatTypes("carrier_horde_boat") +
                        __instance.countBoatTypes("submarine_horde_boat") +
                        __instance.countBoatTypes("fishing_horde_boat");

                    if (totalhordeBoats >= 6)
                    {
                        __result = null;
                        return false;
                    }

                    if (!pCity.hasEnoughResourcesFor(new ConstructionCost(0, 0, 0, 1)))
                    {
                        __result = null;
                        return false;
                    }

                    if (__instance.tiles_ocean.Count == 0)
                    {
                        __instance.recalculateOceanTiles();
                        __result = null;
                        return false;
                    }

                    WorldTile tTile = __instance.tiles_ocean.GetRandom();
                    if (!tTile.region.island.goodForDocks())
                    {
                        __result = null;
                        return false;
                    }

                    string[] boatAssethordeIds = new string[] {
                        "CargoShip_horde",
                        "aDestroyer_horde",
                        "bDestroyer_horde",
                        "CarrierVessel_horde",
                        "Submarine_horde",
                        "FishingBoat_horde"
                    };

                    string selectedBoathordeAssetId = boatAssethordeIds[Randy.randomInt(0, boatAssethordeIds.Length)];
                    Actor tNewBoat = World.world.units.createNewUnit(selectedBoathordeAssetId, tTile);

                    if (tNewBoat == null)
                    {
                        __result = null;
                        return false;
                    }

                    __instance.addBoatToDock(tNewBoat);

                    tNewBoat.setKingdom(pCity.kingdom);
                    tNewBoat.setCity(pCity);

                    pCity.spendResourcesForBuildingAsset(new ConstructionCost(0, 0, 0, 1));

                    __result = tNewBoat;
                    return false;
                }
                 else if (__instance.building.asset.id == "Docks_rain_harden")
                {
                    int totalhardenBoats =
                        __instance.countBoatTypes("cargo_harden_boat") +
                        __instance.countBoatTypes("destroyer_a_harden_boat") +
                        __instance.countBoatTypes("destroyer_b_harden_boat") +
                        __instance.countBoatTypes("carrier_harden_boat") +
                        __instance.countBoatTypes("submarine_harden_boat") +
                        __instance.countBoatTypes("fishing_harden_boat");

                    if (totalhardenBoats >= 6)
                    {
                        __result = null;
                        return false;
                    }

                    if (!pCity.hasEnoughResourcesFor(new ConstructionCost(0, 0, 0, 1)))
                    {
                        __result = null;
                        return false;
                    }

                    if (__instance.tiles_ocean.Count == 0)
                    {
                        __instance.recalculateOceanTiles();
                        __result = null;
                        return false;
                    }

                    WorldTile tTile = __instance.tiles_ocean.GetRandom();
                    if (!tTile.region.island.goodForDocks())
                    {
                        __result = null;
                        return false;
                    }

                    string[] boatAssethardenIds = new string[] {
                        "CargoShip_harden",
                        "aDestroyer_harden",
                        "bDestroyer_harden",
                        "CarrierVessel_harden",
                        "Submarine_harden",
                        "FishingBoat_harden"
                    };

                    string selectedBoathardenAssetId = boatAssethardenIds[Randy.randomInt(0, boatAssethardenIds.Length)];
                    Actor tNewBoat = World.world.units.createNewUnit(selectedBoathardenAssetId, tTile);

                    if (tNewBoat == null)
                    {
                        __result = null;
                        return false;
                    }

                    __instance.addBoatToDock(tNewBoat);

                    tNewBoat.setKingdom(pCity.kingdom);
                    tNewBoat.setCity(pCity);

                    pCity.spendResourcesForBuildingAsset(new ConstructionCost(0, 0, 0, 1));

                    __result = tNewBoat;
                    return false;
                }

                return true;
            }
        }

        [HarmonyPatch(typeof(BuildingAsset), "getRandomBoatAssetToBuild")]
        public static class Patch_BuildingAsset_GetRandomBoatAssetToBuild
        {
            static bool Prefix(BuildingAsset __instance, City pCity, ref ActorAsset __result)
            {
                if (__instance.id == "Docks_rain_alliance")
                {
                    string[] boatAssetIds = new string[] {
                        "CargoShip_alliance",
                        "aDestroyer_alliance",
                        "bDestroyer_alliance",
                        "CarrierVessel_alliance",
                        "Submarine_alliance",
                        "FishingBoat_alliance"
                    };
                    string selectedBoatAssetId = boatAssetIds[Randy.randomInt(0, boatAssetIds.Length)];
                    __result = AssetManager.actor_library.get(selectedBoatAssetId);
                    return false;
                }
                    else if (__instance.id == "Docks_rain_harden")
                {
                    string[] boatAssetIds = new string[] {
                        "CargoShip_harden",
                        "aDestroyer_harden",
                        "bDestroyer_harden",
                        "CarrierVessel_harden",
                        "Submarine_harden",
                        "FishingBoat_harden"
                    };
                    string selectedBoatAssetId = boatAssetIds[Randy.randomInt(0, boatAssetIds.Length)];
                    __result = AssetManager.actor_library.get(selectedBoatAssetId);
                    return false;
                    }
               else if (__instance.id == "Docks_rain_horde")
                {
                    string[] boatAssetIds = new string[] {
                        "CargoShip_horde",
                        "aDestroyer_horde",
                        "bDestroyer_horde",
                        "CarrierVessel_horde",
                        "Submarine_horde",
                        "FishingBoat_horde"
                    };
                    string selectedBoatAssetId = boatAssetIds[Randy.randomInt(0, boatAssetIds.Length)];
                    __result = AssetManager.actor_library.get(selectedBoatAssetId);
                    return false;
                }
                 else if (__instance.id == "Docks_rain_gaia")
                {
                    string[] boatAssetIds = new string[] {
                        "CargoShip_gaia",
                        "aDestroyer_gaia",
                        "bDestroyer_gaia",
                        "CarrierVessel_gaia",
                        "Submarine_gaia",
                        "FishingBoat_gaia"
                    };
                    string selectedBoatAssetId = boatAssetIds[Randy.randomInt(0, boatAssetIds.Length)];
                    __result = AssetManager.actor_library.get(selectedBoatAssetId);
                    return false;
                }

                return true;
            }
        }

        [HarmonyPatch(typeof(BuildingAsset), "getBoatAssetIDFromType")]
        public static class Patch_BuildingAsset_GetBoatAssetIDFromType
        {
            static bool Prefix(string pSpeciesBoat, City pCity, ref string __result)
            {
                switch (pSpeciesBoat)
                {
                    case "cargo_alliance_boat":
                        __result = "CargoShip_alliance";
                        return false;
                    case "destroyer_a_alliance_boat":
                        __result = "aDestroyer_alliance";
                        return false;
                    case "destroyer_b_alliance_boat":
                        __result = "bDestroyer_alliance";
                        return false;
                    case "carrier_alliance_boat":
                        __result = "CarrierVessel_alliance";
                        return false;
                    case "submarine_alliance_boat":
                        __result = "Submarine_alliance";
                        return false;
                    case "fishing_alliance_boat":
                        __result = "FishingBoat_alliance";
                        return false;
                    case "boat_type_alliance":
                        __result = "CargoShip_alliance";
                        return false;
                        case "cargo_horde_boat":
                        __result = "CargoShip_horde";
                        return false;
                    case "destroyer_a_horde_boat":
                        __result = "aDestroyer_horde";
                        return false;
                    case "destroyer_b_horde_boat":
                        __result = "bDestroyer_horde";
                        return false;
                    case "carrier_horde_boat":
                        __result = "CarrierVessel_horde";
                        return false;
                    case "submarine_horde_boat":
                        __result = "Submarine_horde";
                        return false;
                    case "fishing_horde_boat":
                        __result = "FishingBoat_horde";
                        return false;
                    case "boat_type_horde":
                        __result = "CargoShip_horde";
                        return false;
                        case "cargo_gaia_boat":
                        __result = "CargoShip_gaia";
                        return false;
                    case "destroyer_a_gaia_boat":
                        __result = "aDestroyer_gaia";
                        return false;
                    case "destroyer_b_gaia_boat":
                        __result = "bDestroyer_gaia";
                        return false;
                    case "carrier_gaia_boat":
                        __result = "CarrierVessel_gaia";
                        return false;
                    case "submarine_gaia_boat":
                        __result = "Submarine_gaia";
                        return false;
                    case "fishing_gaia_boat":
                        __result = "FishingBoat_gaia";
                        return false;
                    case "boat_type_gaia":
                        __result = "CargoShip_gaia";
                        return false;
                        case "cargo_harden_boat":
                        __result = "CargoShip_harden";
                        return false;
                    case "destroyer_a_harden_boat":
                        __result = "aDestroyer_harden";
                        return false;
                    case "destroyer_b_harden_boat":
                        __result = "bDestroyer_harden";
                        return false;
                    case "carrier_harden_boat":
                        __result = "CarrierVessel_harden";
                        return false;
                    case "submarine_harden_boat":
                        __result = "Submarine_harden";
                        return false;
                    case "fishing_harden_boat":
                        __result = "FishingBoat_harden";
                        return false;
                    case "boat_type_harden":
                        __result = "CargoShip_harden";
                        return false;
                }

                return true;
            }
        }





        }

        }

