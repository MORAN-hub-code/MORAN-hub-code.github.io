//========= MODERNBOX 2.1.0.1 ============//
//
// Made by Tuxxego
//
//=============================================================================//
using System;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using System.Text.RegularExpressions;
using Beebyte.Obfuscator;
using ai;
using ai.behaviours;


namespace M3
{
    class Vehicles : MonoBehaviour
    {

        public static void init()
        {
            baseVehicle();

        }

        private static void baseVehicle()
        {

            // Attacks
            //
            //=============================================================================//

			////////atttack with high recoil for artillery and low attack speed, tanks should have a pause too between attacks, and attacks for vehicles should consume different levels of stamina and if stamina depleted then give status to actor that recovers stamina while stunning vehicle/makewait, trait for heli for rockets similar to bomberman, attacks for land vehicles made so they cannot hurt flying vehicles
			////////each attack based on vehicle will consume different amounts of mana  (like bullets consuming 1 per shot, artillery shells consuming 20 per shot or more) , if cannot draw more mana vehicle will get stunned and recharge for a while and fuel "system" were movement = stamina depleted , to not expend it or to recharge it, vehicle will need to be in border of their own kingdom, if out of stamina vehicle will get stun until stamina is recovered by being on kingdom border
			////////
			////////spawn of vehicles based on what upgrade level the hall has and unitpotential should erase vehicles if they are below the corresponding tier of hall by ID

            ItemAsset mountedmachinegun = AssetManager.items.clone("mountedmachinegun", "$range");
            mountedmachinegun.has_locales = false;
            mountedmachinegun.projectile = "shotgun_bullet";
            mountedmachinegun.base_stats["projectiles"] = 1f;
            mountedmachinegun.path_slash_animation = "effects/slashes/slash_cannonball";
            mountedmachinegun.show_in_meta_editor = false;
            mountedmachinegun.show_in_knowledge_window = false;

			ItemAsset hordemachinegun = AssetManager.items.clone("hordemachinegun", "$range");
            hordemachinegun.has_locales = false;
            hordemachinegun.projectile = "bone";
            hordemachinegun.base_stats["projectiles"] = 1f;
            hordemachinegun.path_slash_animation = "effects/slashes/slash_cannonball";
            hordemachinegun.show_in_meta_editor = false;
            hordemachinegun.show_in_knowledge_window = false;

			ItemAsset icemachinegun = AssetManager.items.clone("icemachinegun", "$range");
            icemachinegun.has_locales = false;
            icemachinegun.projectile = "freeze_orb";
            icemachinegun.base_stats["projectiles"] = 1f;
            icemachinegun.item_modifier_ids = AssetLibrary<ItemAsset>.a<string>("ice");
            icemachinegun.path_slash_animation = "effects/slashes/slash_cannonball";
            icemachinegun.show_in_meta_editor = false;
            icemachinegun.show_in_knowledge_window = false;

			ItemAsset gaiamachinegun = AssetManager.items.clone("gaiamachinegun", "$range");
            gaiamachinegun.has_locales = false;
            gaiamachinegun.projectile = "green_orb";
            gaiamachinegun.base_stats["projectiles"] = 1f;
            gaiamachinegun.path_slash_animation = "effects/slashes/slash_cannonball";
            gaiamachinegun.show_in_meta_editor = false;
            gaiamachinegun.item_modifier_ids = AssetLibrary<ItemAsset>.a<string>("slowness");
            gaiamachinegun.show_in_knowledge_window = false;


			ProjectileAsset artilleryshell = new ProjectileAsset();
            artilleryshell.id = "artilleryshell";
            artilleryshell.speed = 15f;
			artilleryshell.texture = "artilleryshell";
			artilleryshell.texture_shadow = "shadows/projectiles/shadow_ball";
			artilleryshell.terraform_option = "cannonball";
			artilleryshell.terraform_range = 2;
			artilleryshell.sound_launch = "event:/SFX/WEAPONS/WeaponShotgunStart";
			artilleryshell.sound_impact = "event:/SFX/WEAPONS/WeaponShotgunLand";
			artilleryshell.end_effect = "fx_firebomb_explosion";
			artilleryshell.scale_start = 0.2f;
			artilleryshell.scale_target = 0.2f;
          artilleryshell.can_be_left_on_ground = false;
          artilleryshell.can_be_blocked = false;
          AssetManager.projectiles.add(artilleryshell);

            ItemAsset artilleryattack = AssetManager.items.clone("artilleryattack", "$range");
            artilleryattack.has_locales = false;
            artilleryattack.projectile = "artilleryshell";
            artilleryattack.base_stats["recoil"] = 2f;
            artilleryattack.base_stats["projectiles"] = 1f;
            artilleryattack.path_slash_animation = "effects/slashes/slash_cannonball";
            artilleryattack.show_in_meta_editor = false;
            artilleryattack.show_in_knowledge_window = false;

			ItemAsset gaiaartilleryshell = AssetManager.items.clone("gaiaartilleryshell", "$range");
            gaiaartilleryshell.has_locales = false;
            gaiaartilleryshell.projectile = "green_orb";
            gaiaartilleryshell.base_stats["recoil"] = 2f;
            gaiaartilleryshell.base_stats["projectiles"] = 1f;
            gaiaartilleryshell.item_modifier_ids = AssetLibrary<ItemAsset>.a<string>("slowness");
            gaiaartilleryshell.path_slash_animation = "effects/slashes/slash_cannonball";
            gaiaartilleryshell.show_in_meta_editor = false;
            gaiaartilleryshell.show_in_knowledge_window = false;

			ItemAsset iceartilleryshell = AssetManager.items.clone("iceartilleryshell", "$range");
            iceartilleryshell.has_locales = false;
            iceartilleryshell.projectile = "snowball";
            iceartilleryshell.base_stats["recoil"] = 2f;
            iceartilleryshell.base_stats["projectiles"] = 1f;
            iceartilleryshell.item_modifier_ids = AssetLibrary<ItemAsset>.a<string>("ice");
            iceartilleryshell.path_slash_animation = "effects/slashes/slash_cannonball";
            iceartilleryshell.show_in_meta_editor = false;
            iceartilleryshell.show_in_knowledge_window = false;

			ItemAsset hordeartilleryshell = AssetManager.items.clone("hordeartilleryshell", "$range");
            hordeartilleryshell.has_locales = false;
            hordeartilleryshell.projectile = "skull";
            hordeartilleryshell.base_stats["recoil"] = 2f;
            hordeartilleryshell.base_stats["projectiles"] = 1f;
            hordeartilleryshell.path_slash_animation = "effects/slashes/slash_cannonball";
            hordeartilleryshell.show_in_meta_editor = false;
            hordeartilleryshell.show_in_knowledge_window = false;


		    ProjectileAsset tankshell = new ProjectileAsset();
            tankshell.id = "tankshell";
            tankshell.speed = 20f;
			tankshell.texture = "artilleryshell";
			tankshell.texture_shadow = "shadows/projectiles/shadow_ball";
			tankshell.terraform_option = "cannonball";
			tankshell.terraform_range = 2;
			tankshell.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			tankshell.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			tankshell.end_effect = "fx_firebomb_explosion";
			tankshell.scale_start = 0.2f;
			tankshell.scale_target = 0.2f;
          tankshell.can_be_left_on_ground = true;
          tankshell.can_be_blocked = true;
          AssetManager.projectiles.add(tankshell);

            ItemAsset tankpew = AssetManager.items.clone("tankpew", "$range");
            tankpew.has_locales = false;
            tankpew.projectile = "tankshell";
            tankpew.base_stats["projectiles"] = 1f;
            tankpew.path_slash_animation = "effects/slashes/slash_cannonball";
            tankpew.show_in_meta_editor = false;
            tankpew.show_in_knowledge_window = false;

			ItemAsset hordetankpew = AssetManager.items.clone("hordetankpew", "$range");
            hordetankpew.has_locales = false;
            hordetankpew.projectile = "fireball";
            hordetankpew.base_stats["projectiles"] = 1f;
            hordetankpew.path_slash_animation = "effects/slashes/slash_cannonball";
            hordetankpew.show_in_meta_editor = false;
            hordetankpew.show_in_knowledge_window = false;

			ProjectileAsset grassshell = new ProjectileAsset();
            grassshell.id = "grassshell";
            grassshell.speed = 20f;
			grassshell.texture = "pr_green_orb";
			grassshell.texture_shadow = "shadows/projectiles/shadow_ball";
			grassshell.sound_launch = "event:/SFX/WEAPONS/WeaponGreenOrbStart";
			grassshell.sound_impact = "event:/SFX/WEAPONS/WeaponGreenOrbLand";
			grassshell.end_effect = "fx_cast_top_green";
			grassshell.scale_start = 0.2f;
			grassshell.scale_target = 0.2f;
          grassshell.can_be_left_on_ground = true;
          grassshell.can_be_blocked = true;
          AssetManager.projectiles.add(grassshell);

		    ItemAsset gaiatankpew = AssetManager.items.clone("gaiatankpew", "$range");
            gaiatankpew.has_locales = false;
            gaiatankpew.projectile = "grassshell";
            gaiatankpew.base_stats["projectiles"] = 1f;
            gaiatankpew.path_slash_animation = "effects/slashes/slash_cannonball";
            gaiatankpew.show_in_meta_editor = false;
            gaiatankpew.show_in_knowledge_window = false;

			ProjectileAsset iceshell = new ProjectileAsset();
            iceshell.id = "iceshell";
            iceshell.speed = 20f;
			iceshell.texture = "dark_orb";
			iceshell.texture_shadow = "shadows/projectiles/shadow_ball";
			iceshell.sound_launch = "event:/SFX/WEAPONS/WeaponFreezeOrbStart";
			iceshell.sound_impact = "event:/SFX/WEAPONS/WeaponFreezeOrbLand";
			iceshell.scale_start = 0.2f;
			iceshell.scale_target = 0.2f;
			iceshell.hit_freeze = true;
          iceshell.can_be_left_on_ground = true;
          iceshell.can_be_blocked = true;
          AssetManager.projectiles.add(iceshell);

			ItemAsset crystaltankpew = AssetManager.items.clone("crystaltankpew", "$range");
            crystaltankpew.has_locales = false;
            crystaltankpew.projectile = "iceshell";
            crystaltankpew.base_stats["projectiles"] = 1f;
            crystaltankpew.path_slash_animation = "effects/slashes/slash_cannonball";
            crystaltankpew.show_in_meta_editor = false;
            crystaltankpew.show_in_knowledge_window = false;

			ProjectileAsset missileartillery = new ProjectileAsset();
            missileartillery.id = "missileartillery";
            missileartillery.speed = 15f;
			missileartillery.texture = "MIRVartillery";
			missileartillery.texture_shadow = "shadows/projectiles/shadow_ball";
			missileartillery.terraform_option = "cannonball";
			missileartillery.terraform_range = 4;
			missileartillery.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			missileartillery.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			missileartillery.end_effect = "fx_firebomb_explosion";
			missileartillery.scale_start = 0.15f;
			missileartillery.scale_target = 0.15f;
          missileartillery.can_be_left_on_ground = false;
          missileartillery.can_be_blocked = false;
          AssetManager.projectiles.add(missileartillery);

            ItemAsset MissileSystemmissile = AssetManager.items.clone("MissileSystemmissile", "$range");
            MissileSystemmissile.has_locales = false;
            MissileSystemmissile.projectile = "missileartillery";
            MissileSystemmissile.base_stats["projectiles"] = 1f;
            MissileSystemmissile.path_slash_animation = "effects/slashes/slash_cannonball";
            MissileSystemmissile.show_in_meta_editor = false;
            MissileSystemmissile.show_in_knowledge_window = false;

			ProjectileAsset fireboneartillery = new ProjectileAsset();
            fireboneartillery.id = "fireboneartillery";
            fireboneartillery.speed = 15f;
			fireboneartillery.texture = "fireboneartillery";
			fireboneartillery.texture_shadow = "shadows/projectiles/shadow_ball";
			fireboneartillery.terraform_option = "cannonball";
			fireboneartillery.terraform_range = 4;
			fireboneartillery.sound_launch = "event:/SFX/WEAPONS/WeaponBoneProjectileStart";
			fireboneartillery.sound_impact = "event:/SFX/WEAPONS/WeaponBoneProjectileLand";
			fireboneartillery.end_effect = "fx_firebomb_explosion";
			fireboneartillery.scale_start = 0.15f;
			fireboneartillery.scale_target = 0.15f;
          fireboneartillery.can_be_left_on_ground = false;
          fireboneartillery.can_be_blocked = false;
          AssetManager.projectiles.add(fireboneartillery);

            ItemAsset MissileSystemHorde = AssetManager.items.clone("MissileSystemHorde", "$range");
            MissileSystemHorde.has_locales = false;
            MissileSystemHorde.projectile = "fireboneartillery";
            MissileSystemHorde.base_stats["projectiles"] = 1f;
            MissileSystemHorde.path_slash_animation = "effects/slashes/slash_cannonball";
            MissileSystemHorde.show_in_meta_editor = false;
            MissileSystemHorde.show_in_knowledge_window = false;

			ProjectileAsset frostmissileartillery = new ProjectileAsset();
            frostmissileartillery.id = "frostmissileartillery";
            frostmissileartillery.speed = 15f;
			frostmissileartillery.texture = "frostmissileartillery";
			frostmissileartillery.texture_shadow = "shadows/projectiles/shadow_ball";
			frostmissileartillery.terraform_option = "cannonball";
			frostmissileartillery.terraform_range = 4;
			frostmissileartillery.sound_launch = "event:/SFX/WEAPONS/WeaponFreezeOrbStart";
			frostmissileartillery.sound_impact = "event:/SFX/WEAPONS/WeaponFreezeOrbLand";
			frostmissileartillery.end_effect = "fx_firebomb_explosion";
			frostmissileartillery.scale_start = 0.15f;
			frostmissileartillery.scale_target = 0.15f;
			frostmissileartillery.hit_freeze = true;
          frostmissileartillery.can_be_left_on_ground = false;
          frostmissileartillery.can_be_blocked = false;
          AssetManager.projectiles.add(frostmissileartillery);

            ItemAsset MissileSystemHarden = AssetManager.items.clone("MissileSystemHarden", "$range");
            MissileSystemHarden.has_locales = false;
            MissileSystemHarden.projectile = "frostmissileartillery";
            MissileSystemHarden.base_stats["projectiles"] = 1f;
            MissileSystemHarden.path_slash_animation = "effects/slashes/slash_cannonball";
            MissileSystemHarden.show_in_meta_editor = false;
            MissileSystemHarden.show_in_knowledge_window = false;

			ProjectileAsset plantmissileartillery = new ProjectileAsset();
            plantmissileartillery.id = "plantmissileartillery";
            plantmissileartillery.speed = 15f;
			plantmissileartillery.texture = "plantmissileartillery";
			plantmissileartillery.texture_shadow = "shadows/projectiles/shadow_ball";
			plantmissileartillery.terraform_range = 4;
			plantmissileartillery.sound_launch = "event:/SFX/WEAPONS/WeaponGreenOrbStart";
			plantmissileartillery.sound_impact = "event:/SFX/WEAPONS/WeaponGreenOrbLand";
			plantmissileartillery.end_effect = "fx_cast_top_green";
			plantmissileartillery.scale_start = 0.15f;
			plantmissileartillery.scale_target = 0.15f;
          plantmissileartillery.can_be_left_on_ground = false;
          plantmissileartillery.can_be_blocked = false;
          AssetManager.projectiles.add(plantmissileartillery);

            ItemAsset MissileSystemGaia = AssetManager.items.clone("MissileSystemGaia", "$range");
            MissileSystemGaia.has_locales = false;
            MissileSystemGaia.projectile = "plantmissileartillery";
            MissileSystemGaia.base_stats["projectiles"] = 1f;
            MissileSystemGaia.path_slash_animation = "effects/slashes/slash_cannonball";
            MissileSystemGaia.show_in_meta_editor = false;
            MissileSystemGaia.show_in_knowledge_window = false;





			ProjectileAsset jetrocketprojectile = new ProjectileAsset();
            jetrocketprojectile.id = "jetrocketprojectile";
            jetrocketprojectile.speed = 20f;
			jetrocketprojectile.texture = "jetrocketprojectile";
			jetrocketprojectile.texture_shadow = "shadows/projectiles/shadow_ball";
			jetrocketprojectile.terraform_option = "cannonball";
			jetrocketprojectile.terraform_range = 1;
			jetrocketprojectile.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetrocketprojectile.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetrocketprojectile.end_effect = "fx_firebomb_explosion";
			jetrocketprojectile.scale_start = 0.2f;
			jetrocketprojectile.scale_target = 0.2f;
          jetrocketprojectile.can_be_left_on_ground = true;
          jetrocketprojectile.can_be_blocked = true;
          AssetManager.projectiles.add(jetrocketprojectile);

            ItemAsset fighterattack = AssetManager.items.clone("fighterattack", "$range");
            fighterattack.has_locales = false;
            fighterattack.projectile = "jetrocketprojectile";
            fighterattack.base_stats["projectiles"] = 2f;
            fighterattack.path_slash_animation = "effects/slashes/slash_cannonball";
            fighterattack.show_in_meta_editor = false;
            fighterattack.show_in_knowledge_window = false;

			ProjectileAsset jetrocketprojectileHorde = new ProjectileAsset();
            jetrocketprojectileHorde.id = "jetrocketprojectileHorde";
            jetrocketprojectileHorde.speed = 20f;
			jetrocketprojectileHorde.texture = "jetrocketprojectileHorde";
			jetrocketprojectileHorde.texture_shadow = "shadows/projectiles/shadow_ball";
			jetrocketprojectileHorde.terraform_option = "cannonball";
			jetrocketprojectileHorde.terraform_range = 1;
			jetrocketprojectileHorde.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetrocketprojectileHorde.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetrocketprojectileHorde.end_effect = "fx_firebomb_explosion";
			jetrocketprojectileHorde.scale_start = 0.2f;
			jetrocketprojectileHorde.scale_target = 0.2f;
          jetrocketprojectileHorde.can_be_left_on_ground = true;
          jetrocketprojectileHorde.can_be_blocked = true;
          AssetManager.projectiles.add(jetrocketprojectileHorde);

            ItemAsset fighterattackHorde = AssetManager.items.clone("fighterattackHorde", "$range");
            fighterattackHorde.has_locales = false;
            fighterattackHorde.projectile = "jetrocketprojectileHorde";
            fighterattackHorde.base_stats["projectiles"] = 2f;
            fighterattackHorde.path_slash_animation = "effects/slashes/slash_cannonball";
            fighterattackHorde.show_in_meta_editor = false;
            fighterattackHorde.show_in_knowledge_window = false;


			ProjectileAsset jetrocketprojectileHarden = new ProjectileAsset();
            jetrocketprojectileHarden.id = "jetrocketprojectileHarden";
            jetrocketprojectileHarden.speed = 20f;
			jetrocketprojectileHarden.texture = "jetrocketprojectileHarden";
			jetrocketprojectileHarden.texture_shadow = "shadows/projectiles/shadow_ball";
			jetrocketprojectileHarden.terraform_option = "cannonball";
			jetrocketprojectileHarden.terraform_range = 1;
			jetrocketprojectileHarden.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetrocketprojectileHarden.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetrocketprojectileHarden.end_effect = "fx_firebomb_explosion";
			jetrocketprojectileHarden.scale_start = 0.2f;
			jetrocketprojectileHarden.scale_target = 0.2f;
          jetrocketprojectileHarden.can_be_left_on_ground = true;
          jetrocketprojectileHarden.can_be_blocked = true;
          AssetManager.projectiles.add(jetrocketprojectileHarden);

            ItemAsset fighterattackHarden = AssetManager.items.clone("fighterattackHarden", "$range");
            fighterattackHarden.has_locales = false;
            fighterattackHarden.projectile = "jetrocketprojectileHarden";
            fighterattackHarden.base_stats["projectiles"] = 2f;
            fighterattackHarden.path_slash_animation = "effects/slashes/slash_cannonball";
            fighterattackHarden.show_in_meta_editor = false;
            fighterattackHarden.show_in_knowledge_window = false;

            ProjectileAsset jetrocketprojectileGaia = new ProjectileAsset();
            jetrocketprojectileGaia.id = "jetrocketprojectileGaia";
            jetrocketprojectileGaia.speed = 20f;
			jetrocketprojectileGaia.texture = "jetrocketprojectileGaia";
			jetrocketprojectileGaia.texture_shadow = "shadows/projectiles/shadow_ball";
			jetrocketprojectileGaia.terraform_option = "cannonball";
			jetrocketprojectileGaia.terraform_range = 1;
			jetrocketprojectileGaia.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetrocketprojectileGaia.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetrocketprojectileGaia.end_effect = "fx_firebomb_explosion";
			jetrocketprojectileGaia.scale_start = 0.2f;
			jetrocketprojectileGaia.scale_target = 0.2f;
          jetrocketprojectileGaia.can_be_left_on_ground = true;
          jetrocketprojectileGaia.can_be_blocked = true;
          AssetManager.projectiles.add(jetrocketprojectileGaia);

            ItemAsset fighterattackGaia = AssetManager.items.clone("fighterattackGaia", "$range");
            fighterattackGaia.has_locales = false;
            fighterattackGaia.projectile = "jetrocketprojectileGaia";
            fighterattackGaia.base_stats["projectiles"] = 2f;
            fighterattackGaia.path_slash_animation = "effects/slashes/slash_cannonball";
            fighterattackGaia.show_in_meta_editor = false;
            fighterattackGaia.show_in_knowledge_window = false;



			ProjectileAsset bigbomb = new ProjectileAsset();
            bigbomb.id = "bigbomb";
            bigbomb.speed = 10f;
			bigbomb.texture = "bigbomb";
			bigbomb.texture_shadow = "shadows/projectiles/shadow_ball";
			bigbomb.terraform_option = "cannonball";
			bigbomb.terraform_range = 6;
			bigbomb.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			bigbomb.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			bigbomb.end_effect = "fx_firebomb_explosion";
			bigbomb.scale_start = 0.2f;
			bigbomb.scale_target = 0.2f;
          bigbomb.can_be_left_on_ground = true;
          bigbomb.can_be_blocked = true;
          AssetManager.projectiles.add(bigbomb);

            ItemAsset BomberAttack = AssetManager.items.clone("BomberAttack", "$range");
            BomberAttack.has_locales = false;
            BomberAttack.projectile = "bigbomb";
            BomberAttack.base_stats["projectiles"] = 4f;
            BomberAttack.path_slash_animation = "effects/slashes/slash_cannonball";
            BomberAttack.show_in_meta_editor = false;
            BomberAttack.show_in_knowledge_window = false;

			ProjectileAsset bigbombGaia = new ProjectileAsset();
            bigbombGaia.id = "bigbombGaia";
            bigbombGaia.speed = 10f;
			bigbombGaia.texture = "bigbombGaia";
			bigbombGaia.texture_shadow = "shadows/projectiles/shadow_ball";
			bigbombGaia.terraform_option = "cannonball";
			bigbombGaia.terraform_range = 6;
			bigbombGaia.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			bigbombGaia.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			bigbombGaia.end_effect = "fx_firebomb_explosion";
			bigbombGaia.scale_start = 0.2f;
			bigbombGaia.scale_target = 0.2f;
          bigbombGaia.can_be_left_on_ground = true;
          bigbombGaia.can_be_blocked = true;
          AssetManager.projectiles.add(bigbombGaia);

            ItemAsset BomberAttackGaia = AssetManager.items.clone("BomberAttackGaia", "$range");
            BomberAttackGaia.has_locales = false;
            BomberAttackGaia.projectile = "bigbombGaia";
            BomberAttackGaia.base_stats["projectiles"] = 4f;
            BomberAttackGaia.path_slash_animation = "effects/slashes/slash_cannonball";
            BomberAttackGaia.show_in_meta_editor = false;
            BomberAttackGaia.show_in_knowledge_window = false;

			ProjectileAsset bigbombHarden = new ProjectileAsset();
            bigbombHarden.id = "bigbombHarden";
            bigbombHarden.speed = 10f;
			bigbombHarden.texture = "bigbombHarden";
			bigbombHarden.texture_shadow = "shadows/projectiles/shadow_ball";
			bigbombHarden.terraform_option = "cannonball";
			bigbombHarden.terraform_range = 6;
			bigbombHarden.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			bigbombHarden.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			bigbombHarden.end_effect = "fx_firebomb_explosion";
			bigbombHarden.scale_start = 0.2f;
			bigbombHarden.scale_target = 0.2f;
          bigbombHarden.can_be_left_on_ground = true;
          bigbombHarden.can_be_blocked = true;
          AssetManager.projectiles.add(bigbombHarden);

            ItemAsset BomberAttackHarden = AssetManager.items.clone("BomberAttackHarden", "$range");
            BomberAttackHarden.has_locales = false;
            BomberAttackHarden.projectile = "bigbombHarden";
            BomberAttackHarden.base_stats["projectiles"] = 4f;
            BomberAttackHarden.path_slash_animation = "effects/slashes/slash_cannonball";
            BomberAttackHarden.show_in_meta_editor = false;
            BomberAttackHarden.show_in_knowledge_window = false;

			ProjectileAsset bigbombHorde = new ProjectileAsset();
            bigbombHorde.id = "bigbombHorde";
            bigbombHorde.speed = 10f;
			bigbombHorde.texture = "bigbombHorde";
			bigbombHorde.texture_shadow = "shadows/projectiles/shadow_ball";
			bigbombHorde.terraform_option = "cannonball";
			bigbombHorde.terraform_range = 6;
			bigbombHorde.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			bigbombHorde.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			bigbombHorde.end_effect = "fx_firebomb_explosion";
			bigbombHorde.scale_start = 0.2f;
			bigbombHorde.scale_target = 0.2f;
          bigbombHorde.can_be_left_on_ground = true;
          bigbombHorde.can_be_blocked = true;
          AssetManager.projectiles.add(bigbombHorde);

            ItemAsset BomberAttackHorde = AssetManager.items.clone("BomberAttackHorde", "$range");
            BomberAttackHorde.has_locales = false;
            BomberAttackHorde.projectile = "bigbombHorde";
            BomberAttackHorde.base_stats["projectiles"] = 4f;
            BomberAttackHorde.path_slash_animation = "effects/slashes/slash_cannonball";
            BomberAttackHorde.show_in_meta_editor = false;
            BomberAttackHorde.show_in_knowledge_window = false;


EffectAsset jetdropbomb_alliance = new EffectAsset();
jetdropbomb_alliance.id = "jetdropbomb_alliance";
jetdropbomb_alliance.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionSmall";
jetdropbomb_alliance.use_basic_prefab = true;
jetdropbomb_alliance.sorting_layer_id = "EffectsTop";
jetdropbomb_alliance.sprite_path = "effects/jetdropbomb_alliance";
jetdropbomb_alliance.draw_light_area = true;
AssetManager.effects_library.add(jetdropbomb_alliance);


  		ProjectileAsset jetprojectile_alliance = new ProjectileAsset();
            jetprojectile_alliance.id = "jetprojectile_alliance";
            jetprojectile_alliance.speed = 15f;
			jetprojectile_alliance.texture = "jetprojectile_alliance";
			jetprojectile_alliance.texture_shadow = "shadows/projectiles/shadow_ball";
			jetprojectile_alliance.terraform_option = "cannonball";
			jetprojectile_alliance.terraform_range = 4;
			jetprojectile_alliance.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetprojectile_alliance.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetprojectile_alliance.end_effect = "jetdropbomb_alliance";
			jetprojectile_alliance.scale_start = 0.15f;
			jetprojectile_alliance.scale_target = 0.15f;
          jetprojectile_alliance.can_be_left_on_ground = false;
          jetprojectile_alliance.can_be_blocked = false;
          AssetManager.projectiles.add(jetprojectile_alliance);

            ItemAsset AirstrikejetAttack_alliance = AssetManager.items.clone("AirstrikejetAttack_alliance", "$range");
            AirstrikejetAttack_alliance.has_locales = false;
            AirstrikejetAttack_alliance.projectile = "jetprojectile_alliance";
            AirstrikejetAttack_alliance.base_stats["projectiles"] = 1f;
            AirstrikejetAttack_alliance.path_slash_animation = "effects/slashes/slash_cannonball";
            AirstrikejetAttack_alliance.show_in_meta_editor = false;
            AirstrikejetAttack_alliance.show_in_knowledge_window = false;


EffectAsset jetdropbomb_horde = new EffectAsset();
jetdropbomb_horde.id = "jetdropbomb_horde";
jetdropbomb_horde.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionSmall";
jetdropbomb_horde.use_basic_prefab = true;
jetdropbomb_horde.sorting_layer_id = "EffectsTop";
jetdropbomb_horde.sprite_path = "effects/jetdropbomb_horde";
jetdropbomb_horde.draw_light_area = true;
AssetManager.effects_library.add(jetdropbomb_horde);

  		ProjectileAsset jetprojectile_horde = new ProjectileAsset();
            jetprojectile_horde.id = "jetprojectile_horde";
            jetprojectile_horde.speed = 15f;
			jetprojectile_horde.texture = "jetprojectile_horde";
			jetprojectile_horde.texture_shadow = "shadows/projectiles/shadow_ball";
			jetprojectile_horde.terraform_option = "cannonball";
			jetprojectile_horde.terraform_range = 4;
			jetprojectile_horde.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetprojectile_horde.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetprojectile_horde.end_effect = "jetdropbomb_horde";
			jetprojectile_horde.scale_start = 0.15f;
			jetprojectile_horde.scale_target = 0.15f;
          jetprojectile_horde.can_be_left_on_ground = false;
          jetprojectile_horde.can_be_blocked = false;
          AssetManager.projectiles.add(jetprojectile_horde);

            ItemAsset AirstrikejetAttack_horde = AssetManager.items.clone("AirstrikejetAttack_horde", "$range");
            AirstrikejetAttack_horde.has_locales = false;
            AirstrikejetAttack_horde.projectile = "jetprojectile_horde";
            AirstrikejetAttack_horde.base_stats["projectiles"] = 1f;
            AirstrikejetAttack_horde.path_slash_animation = "effects/slashes/slash_cannonball";
            AirstrikejetAttack_horde.show_in_meta_editor = false;
            AirstrikejetAttack_horde.show_in_knowledge_window = false;


EffectAsset jetdropbomb_gaia = new EffectAsset();
jetdropbomb_gaia.id = "jetdropbomb_gaia";
jetdropbomb_gaia.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionSmall";
jetdropbomb_gaia.use_basic_prefab = true;
jetdropbomb_gaia.sorting_layer_id = "EffectsTop";
jetdropbomb_gaia.sprite_path = "effects/jetdropbomb_gaia";
jetdropbomb_gaia.draw_light_area = true;
AssetManager.effects_library.add(jetdropbomb_gaia);

  		ProjectileAsset jetprojectile_gaia = new ProjectileAsset();
            jetprojectile_gaia.id = "jetprojectile_gaia";
            jetprojectile_gaia.speed = 15f;
			jetprojectile_gaia.texture = "jetprojectile_gaia";
			jetprojectile_gaia.texture_shadow = "shadows/projectiles/shadow_ball";
			jetprojectile_gaia.terraform_option = "cannonball";
			jetprojectile_gaia.terraform_range = 4;
			jetprojectile_gaia.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetprojectile_gaia.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetprojectile_gaia.end_effect = "jetdropbomb_gaia";
			jetprojectile_gaia.scale_start = 0.15f;
			jetprojectile_gaia.scale_target = 0.15f;
          jetprojectile_gaia.can_be_left_on_ground = false;
          jetprojectile_gaia.can_be_blocked = false;
          AssetManager.projectiles.add(jetprojectile_gaia);

            ItemAsset AirstrikejetAttack_gaia = AssetManager.items.clone("AirstrikejetAttack_gaia", "$range");
            AirstrikejetAttack_gaia.has_locales = false;
            AirstrikejetAttack_gaia.projectile = "jetprojectile_gaia";
            AirstrikejetAttack_gaia.base_stats["projectiles"] = 1f;
            AirstrikejetAttack_gaia.path_slash_animation = "effects/slashes/slash_cannonball";
            AirstrikejetAttack_gaia.show_in_meta_editor = false;
            AirstrikejetAttack_gaia.show_in_knowledge_window = false;


EffectAsset jetdropbomb_harden = new EffectAsset();
jetdropbomb_harden.id = "jetdropbomb_harden";
jetdropbomb_harden.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionSmall";
jetdropbomb_harden.use_basic_prefab = true;
jetdropbomb_harden.sorting_layer_id = "EffectsTop";
jetdropbomb_harden.sprite_path = "effects/jetdropbomb_harden";
jetdropbomb_harden.draw_light_area = true;
AssetManager.effects_library.add(jetdropbomb_harden);

  		ProjectileAsset jetprojectile_harden = new ProjectileAsset();
            jetprojectile_harden.id = "jetprojectile_harden";
            jetprojectile_harden.speed = 15f;
			jetprojectile_harden.texture = "jetprojectile_harden";
			jetprojectile_harden.texture_shadow = "shadows/projectiles/shadow_ball";
			jetprojectile_harden.terraform_option = "cannonball";
			jetprojectile_harden.terraform_range = 4;
			jetprojectile_harden.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			jetprojectile_harden.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			jetprojectile_harden.end_effect = "jetdropbomb_harden";
			jetprojectile_harden.scale_start = 0.15f;
			jetprojectile_harden.scale_target = 0.15f;
          jetprojectile_harden.can_be_left_on_ground = false;
          jetprojectile_harden.can_be_blocked = false;
          AssetManager.projectiles.add(jetprojectile_harden);

            ItemAsset AirstrikejetAttack_harden = AssetManager.items.clone("AirstrikejetAttack_harden", "$range");
            AirstrikejetAttack_harden.has_locales = false;
            AirstrikejetAttack_harden.projectile = "jetprojectile_harden";
            AirstrikejetAttack_harden.base_stats["projectiles"] = 1f;
            AirstrikejetAttack_harden.path_slash_animation = "effects/slashes/slash_cannonball";
            AirstrikejetAttack_harden.show_in_meta_editor = false;
            AirstrikejetAttack_harden.show_in_knowledge_window = false;


            EffectAsset hyperboom = new EffectAsset();
hyperboom.id = "hyperboom";
hyperboom.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionAntimatterBomb";
hyperboom.use_basic_prefab = true;
hyperboom.sorting_layer_id = "EffectsTop";
hyperboom.sprite_path = "effects/hyperboom";
hyperboom.draw_light_area = true;
AssetManager.effects_library.add(hyperboom);

  		ProjectileAsset hyperkame = new ProjectileAsset();
            hyperkame.id = "hyperkame";
            hyperkame.speed = 20f;
			hyperkame.texture = "hyperkame";
			hyperkame.texture_shadow = "shadows/projectiles/shadow_ball";
			hyperkame.terraform_option = "cannonball";
			hyperkame.terraform_range = 8;
			hyperkame.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			hyperkame.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			hyperkame.end_effect = "hyperboom";
			hyperkame.scale_start = 0.05f;
			hyperkame.scale_target = 0.4f;
          hyperkame.can_be_left_on_ground = false;
          hyperkame.can_be_blocked = false;
          AssetManager.projectiles.add(hyperkame);

            ItemAsset XenoMegaBomb = AssetManager.items.clone("XenoMegaBomb", "$range");
            XenoMegaBomb.has_locales = false;
            XenoMegaBomb.projectile = "hyperkame";
            XenoMegaBomb.base_stats["projectiles"] = 1f;
            XenoMegaBomb.path_slash_animation = "effects/slashes/slash_cannonball";
            XenoMegaBomb.show_in_meta_editor = false;
            XenoMegaBomb.show_in_knowledge_window = false;

                        EffectAsset kameboomtest = new EffectAsset();
kameboomtest.id = "kameboomtest";
kameboomtest.sound_launch = "event:/SFX/EXPLOSIONS/ExplosionAntimatterBomb";
kameboomtest.use_basic_prefab = true;
kameboomtest.sorting_layer_id = "EffectsTop";
kameboomtest.sprite_path = "effects/kameboomtest";
kameboomtest.draw_light_area = true;
AssetManager.effects_library.add(kameboomtest);

            EffectAsset fx_trail_kame_t = new EffectAsset();
fx_trail_kame_t.id = "fx_trail_kame_t";
fx_trail_kame_t.use_basic_prefab = true;
fx_trail_kame_t.sorting_layer_id = "EffectsTop";
fx_trail_kame_t.sprite_path = "effects/fx_trail_kame_t";
fx_trail_kame_t.draw_light_area = true;
AssetManager.effects_library.add(fx_trail_kame_t);

  		ProjectileAsset thunderplasma = new ProjectileAsset();
            thunderplasma.id = "thunderplasma";
            thunderplasma.speed = 16f;
			thunderplasma.texture = "thunderplasma";
			thunderplasma.trail_effect_id = "fx_trail_kame_t";
            thunderplasma.trail_effect_scale = 0.1f;
			thunderplasma.trail_effect_timer = 0.1f;
			thunderplasma.texture_shadow = "shadows/projectiles/shadow_ball";
			thunderplasma.terraform_option = "cannonball";
			thunderplasma.terraform_range = 4;
			thunderplasma.sound_launch = "event:/SFX/WEAPONS/WeaponFireballStart";
			thunderplasma.sound_impact = "event:/SFX/WEAPONS/WeaponFireballLand";
			thunderplasma.end_effect = "kameboomtest";
			thunderplasma.scale_start = 0.4f;
			thunderplasma.scale_target = 0.4f;
          thunderplasma.can_be_left_on_ground = false;
          thunderplasma.can_be_blocked = false;
          AssetManager.projectiles.add(thunderplasma);

            ItemAsset XenoBeam = AssetManager.items.clone("XenoBeam", "$range");
            XenoBeam.has_locales = false;
            XenoBeam.projectile = "thunderplasma";
            XenoBeam.base_stats["projectiles"] = 1f;
            XenoBeam.path_slash_animation = "effects/slashes/slash_cannonball";
            XenoBeam.show_in_meta_editor = false;
            XenoBeam.show_in_knowledge_window = false;

            ItemAsset XenoPew = AssetManager.items.clone("XenoPew", "$range");
            XenoPew.has_locales = false;
            XenoPew.projectile = "plasma_ball";
            XenoPew.base_stats["projectiles"] = 1f;
            XenoPew.path_slash_animation = "effects/slashes/slash_cannonball";
            XenoPew.show_in_meta_editor = false;
            XenoPew.show_in_knowledge_window = false;



// BASE UNITS
//
//=============================================================================//


	var baseWarUnit = AssetManager.actor_library.clone("baseWarUnit","$basic_unit$");
	baseWarUnit.is_humanoid = false;
	baseWarUnit.civ = false;
	baseWarUnit.actor_size = ActorSize.S13_Human;
	baseWarUnit.die_in_lava = true;
		baseWarUnit.can_have_subspecies = false;
        baseWarUnit.base_stats["mass_2"] = 600f;
        baseWarUnit.base_stats["stamina"] = 500f;
		baseWarUnit.base_stats["stamina"] = 300f;
		baseWarUnit.base_stats["lifespan"] = 60f;
        baseWarUnit.base_stats["scale"] = 0.2f;
        baseWarUnit.base_stats["size"] = 1f;
		baseWarUnit.base_stats["mass"] = 1000f;
        baseWarUnit.base_stats["health"] = 300f;
		baseWarUnit.base_stats["speed"] = 10f;
		baseWarUnit.base_stats["armor"] = 20f;
		baseWarUnit.base_stats["attack_speed"] = 1f;
		baseWarUnit.base_stats["damage"] = 30f;
		baseWarUnit.base_stats["knockback"] = 2f;
		baseWarUnit.base_stats["accuracy"] = 1f;
		baseWarUnit.base_stats["targets"] = 1f;
		baseWarUnit.base_stats["area_of_effect"] = 0.5f;
		baseWarUnit.base_stats["range"] = 1f;
		baseWarUnit.base_stats["critical_damage_multiplier"] = 2f;
		baseWarUnit.base_stats["multiplier_supply_timer"] = 1f;
        baseWarUnit.sound_hit = "event:/SFX/HIT/HitWood";
        baseWarUnit.base_throwing_range = 7f;
		baseWarUnit.affected_by_dust = false;
        baseWarUnit.inspect_children = false;
        baseWarUnit.default_attack = "base_attack";
        baseWarUnit.icon = "iconBoat";
        baseWarUnit.shadow_texture = "unitShadow_6";
        baseWarUnit.texture_asset = new ActorTextureSubAsset("actors/baseWarUnit/");
        baseWarUnit.special = true;
        baseWarUnit.has_advanced_textures = false;
        baseWarUnit.cost = new ConstructionCost(1, 0, 0, 1);
        baseWarUnit.animation_walk = ActorAnimationSequences.walk_0_3;
        baseWarUnit.animation_idle = ActorAnimationSequences.walk_0;
		baseWarUnit.animation_swim = ActorAnimationSequences.swim_0_3;
		baseWarUnit.name_template_sets = AssetLibrary<ActorAsset>.a<string>("assimilator_set");
		baseWarUnit.kingdom_id_civilization = string.Empty;
		baseWarUnit.build_order_template_id = string.Empty;
		baseWarUnit.disable_jump_animation = true;
		baseWarUnit.inspect_sex = false;
		baseWarUnit.inspect_show_species = false;
		baseWarUnit.inspect_generation = false;
		baseWarUnit.immune_to_injuries = true;
		baseWarUnit.show_on_meta_layer = false;
		baseWarUnit.show_in_knowledge_window = false;
		baseWarUnit.show_in_taxonomy_tooltip = false;
		baseWarUnit.needs_to_be_explored = false;
		baseWarUnit.need_colored_sprite = true;
        baseWarUnit.allowed_status_tiers = StatusTier.Basic;
		baseWarUnit.render_status_effects = false;
        baseWarUnit.inspect_avatar_scale = 3f;
		baseWarUnit.color_hex = "#EE3A42";
			baseWarUnit.force_land_creature = true;
			baseWarUnit.inspect_home = true;
			baseWarUnit.visible_on_minimap = true;
			baseWarUnit.can_edit_traits = true;
            baseWarUnit.disable_jump_animation = true;
			baseWarUnit.can_receive_traits = true;
			baseWarUnit.flying = false;
			//baseoffensiveunit.tech = "baseoffensiveunits";
			baseWarUnit.very_high_flyer = false;
			baseWarUnit.die_on_blocks = true;
			baseWarUnit.ignore_blocks = false;
            baseWarUnit.inspect_experience = true;
            baseWarUnit.inspect_kills = true;
            baseWarUnit.use_items = false;
			baseWarUnit.has_baby_form = false;
            baseWarUnit.take_items = false;
            baseWarUnit.name_locale = "baseWarUnit";
            baseWarUnit.job_citizen = Toolbox.a<string>("attacker");
		baseWarUnit.job_kingdom = Toolbox.a<string>("attacker");
		baseWarUnit.job_attacker = Toolbox.a<string>("attacker");
		   baseWarUnit.job = AssetLibrary<ActorAsset>.a<string>("decision");
           baseWarUnit.addDecision("check_swearing");
baseWarUnit.addDecision("warrior_try_join_army_group");
baseWarUnit.addDecision("city_walking_to_danger_zone");
baseWarUnit.addDecision("warrior_army_captain_idle_walking_city");
baseWarUnit.addDecision("warrior_army_captain_waiting");
baseWarUnit.addDecision("warrior_army_leader_move_random");
baseWarUnit.addDecision("warrior_army_leader_move_to_attack_target");
baseWarUnit.addDecision("warrior_army_follow_leader");
baseWarUnit.addDecision("warrior_random_move");
baseWarUnit.addDecision("check_warrior_transport");
baseWarUnit.addDecision("swim_to_island");
        baseWarUnit.collective_term = "group_gang";
        baseWarUnit.prevent_unconscious_rotation = true;
        baseWarUnit.use_phenotypes = false;
		baseWarUnit.unit_other = true;
		baseWarUnit.can_be_surprised = false;
        baseWarUnit.has_skin = false;
        baseWarUnit.disable_jump_animation = true;
		baseWarUnit.can_turn_into_mush = false;
		baseWarUnit.can_turn_into_tumor = false;
		baseWarUnit.can_turn_into_zombie = false;
		baseWarUnit.use_tool_items = false;
            baseWarUnit.kingdom_id_wild = "neutral_animals";
            baseWarUnit.can_flip = true;
            baseWarUnit.check_flip = (BaseSimObject _, WorldTile _) => true;
            //baseWarUnit.split_ai_update = false;
			baseWarUnit.allow_possession = true;
            baseWarUnit.can_talk_with = false;
			baseWarUnit.control_can_backstep = true;
			baseWarUnit.control_can_jump = true;
			baseWarUnit.control_can_kick = true;
			baseWarUnit.control_can_dash = true;
			baseWarUnit.control_can_talk = false;
			baseWarUnit.control_can_swear = true;
			baseWarUnit.control_can_steal = true;
			baseWarUnit.show_controllable_tip = true;
        baseWarUnit.update_z = true;
		baseWarUnit.can_be_killed_by_stuff = true;
		baseWarUnit.can_be_killed_by_life_eraser = true;
		baseWarUnit.can_attack_buildings = true;
		baseWarUnit.can_be_moved_by_powers = true;
		baseWarUnit.can_be_hurt_by_powers = true;
		baseWarUnit.effect_damage = true;
		baseWarUnit.immune_to_slowness = true;
		//baseWarUnit.can_flip = true;
		baseWarUnit.death_animation_angle = true;
		baseWarUnit.can_be_inspected = true;
		baseWarUnit.addTrait("Unitpotential");
		baseWarUnit.addTrait("immune");
		//baseWarUnit.addTrait("strong_minded");
		baseWarUnit.addTrait("light_lamp");
            AssetManager.actor_library.add(baseWarUnit);
			Localization.addLocalization(baseWarUnit.name_locale, baseWarUnit.name_locale);


	var modernhumvee_Human = AssetManager.actor_library.clone("modernhumvee_Human","baseWarUnit");
	modernhumvee_Human.die_in_lava = false;
        modernhumvee_Human.base_stats["mass_2"] = 600f;
        modernhumvee_Human.base_stats["stamina"] = 500f;
        modernhumvee_Human.base_stats["scale"] = 0.2f;
        modernhumvee_Human.base_stats["size"] = 1f;
		modernhumvee_Human.base_stats["mass"] = 1000f;
        modernhumvee_Human.base_stats["health"] = 300f;
		modernhumvee_Human.base_stats["speed"] = 70f;
		modernhumvee_Human.base_stats["armor"] = 20f;
		modernhumvee_Human.base_stats["attack_speed"] = 10000f;
		modernhumvee_Human.base_stats["damage"] = 10f;
		modernhumvee_Human.base_stats["knockback"] = 0.01f;
		modernhumvee_Human.base_stats["accuracy"] = 0.5f;
		modernhumvee_Human.base_stats["targets"] = 1f;
		modernhumvee_Human.base_stats["area_of_effect"] = 0.5f;
		modernhumvee_Human.base_stats["range"] = 14f;
        modernhumvee_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        modernhumvee_Human.default_attack = "mountedmachinegun";
        modernhumvee_Human.icon = "iconBoat";
        modernhumvee_Human.shadow_texture = "unitShadow_6";
        modernhumvee_Human.texture_asset = new ActorTextureSubAsset("actors/modernhumvee_Human/");
        modernhumvee_Human.special = true;
        modernhumvee_Human.has_advanced_textures = false;
        modernhumvee_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        modernhumvee_Human.animation_idle = ActorAnimationSequences.walk_0;
		modernhumvee_Human.animation_swim = ActorAnimationSequences.swim_0_3;
            modernhumvee_Human.name_locale = "Light Vehicle";
			modernhumvee_Human.addTrait("dodge");
			modernhumvee_Human.addTrait("dash");
			modernhumvee_Human.addTrait("fire_proof");
            AssetManager.actor_library.add(modernhumvee_Human);
			Localization.addLocalization(modernhumvee_Human.name_locale, modernhumvee_Human.name_locale);



	var howitzer_Human = AssetManager.actor_library.clone("howitzer_Human","baseWarUnit");
	howitzer_Human.die_in_lava = false;
        howitzer_Human.base_stats["mass_2"] = 600f;
        howitzer_Human.base_stats["stamina"] = 500f;
        howitzer_Human.base_stats["scale"] = 0.2f;
        howitzer_Human.base_stats["size"] = 1f;
		howitzer_Human.base_stats["mass"] = 1000f;
        howitzer_Human.base_stats["health"] = 200f;
		howitzer_Human.base_stats["speed"] = 20f;
		howitzer_Human.base_stats["armor"] = 20f;
		howitzer_Human.base_stats["attack_speed"] = -10f;
		howitzer_Human.base_stats["damage"] = 100f;
		howitzer_Human.base_stats["knockback"] = 3f;
		howitzer_Human.base_stats["accuracy"] = 0.3f;
		howitzer_Human.base_stats["targets"] = 3f;
		howitzer_Human.base_stats["area_of_effect"] = 4f;
		howitzer_Human.base_stats["range"] = 30f;
        howitzer_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        howitzer_Human.default_attack = "artilleryattack";
        howitzer_Human.icon = "iconBoat";
		howitzer_Human.inspect_avatar_scale = 2f;
        howitzer_Human.shadow_texture = "unitShadow_6";
        howitzer_Human.texture_asset = new ActorTextureSubAsset("actors/howitzer_Human/");
        howitzer_Human.special = true;
        howitzer_Human.has_advanced_textures = false;
        howitzer_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        howitzer_Human.animation_idle = ActorAnimationSequences.walk_0;
		howitzer_Human.animation_swim = ActorAnimationSequences.swim_0_3;
            howitzer_Human.name_locale = "Artillery";
			howitzer_Human.addTrait("fire_proof");
            AssetManager.actor_library.add(howitzer_Human);
			Localization.addLocalization(howitzer_Human.name_locale, howitzer_Human.name_locale);



	var Tank_Human = AssetManager.actor_library.clone("Tank_Human","baseWarUnit");
	Tank_Human.die_in_lava = false;
        Tank_Human.base_stats["mass_2"] = 600f;
        Tank_Human.base_stats["stamina"] = 500f;
        Tank_Human.base_stats["scale"] = 0.2f;
        Tank_Human.base_stats["size"] = 1f;
		Tank_Human.base_stats["mass"] = 1000f;
        Tank_Human.base_stats["health"] = 800f;
		Tank_Human.base_stats["speed"] = 40f;
		Tank_Human.base_stats["armor"] = 40f;
		Tank_Human.base_stats["attack_speed"] = 0.1f;
		Tank_Human.base_stats["damage"] = 50f;
		Tank_Human.base_stats["knockback"] = 4f;
		Tank_Human.base_stats["accuracy"] = 0.8f;
		Tank_Human.base_stats["targets"] = 2f;
		Tank_Human.base_stats["area_of_effect"] = 2f;
		Tank_Human.base_stats["range"] = 20f;
        Tank_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        Tank_Human.default_attack = "tankpew";
        Tank_Human.icon = "iconBoat";
        Tank_Human.shadow_texture = "unitShadow_6";
        Tank_Human.texture_asset = new ActorTextureSubAsset("actors/Tank_Human/");
        Tank_Human.special = true;
		Tank_Human.inspect_avatar_scale = 2f;
        Tank_Human.has_advanced_textures = false;
        Tank_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        Tank_Human.animation_idle = Vehicles.idle_0_2;
		Tank_Human.animation_swim = ActorAnimationSequences.swim_0_2;
            Tank_Human.name_locale = "Tank";
			Tank_Human.addTrait("fire_proof");
			Tank_Human.addTrait("block");
			Tank_Human.addTrait("deflect_projectile");
            AssetManager.actor_library.add(Tank_Human);
			Localization.addLocalization(Tank_Human.name_locale, Tank_Human.name_locale);


	var wheeledtank_Human = AssetManager.actor_library.clone("wheeledtank_Human","baseWarUnit");
	wheeledtank_Human.die_in_lava = false;
        wheeledtank_Human.base_stats["mass_2"] = 600f;
        wheeledtank_Human.base_stats["stamina"] = 500f;
        wheeledtank_Human.base_stats["scale"] = 0.2f;
        wheeledtank_Human.base_stats["size"] = 1f;
		wheeledtank_Human.base_stats["mass"] = 1000f;
        wheeledtank_Human.base_stats["health"] = 800f;
		wheeledtank_Human.base_stats["speed"] = 70f;
		wheeledtank_Human.base_stats["armor"] = 30f;
		wheeledtank_Human.base_stats["attack_speed"] = 10f;
		wheeledtank_Human.base_stats["damage"] = 40f;
		wheeledtank_Human.base_stats["knockback"] = 0.01f;
		wheeledtank_Human.base_stats["accuracy"] = 0.5f;
		wheeledtank_Human.base_stats["targets"] = 1f;
		wheeledtank_Human.base_stats["area_of_effect"] = 0.5f;
		wheeledtank_Human.base_stats["range"] = 14f;
        wheeledtank_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        wheeledtank_Human.default_attack = "tankpew";
        wheeledtank_Human.icon = "iconBoat";
		wheeledtank_Human.inspect_avatar_scale = 2f;
        wheeledtank_Human.shadow_texture = "unitShadow_6";
        wheeledtank_Human.texture_asset = new ActorTextureSubAsset("actors/wheeledtank_Human/");
        wheeledtank_Human.special = true;
        wheeledtank_Human.has_advanced_textures = false;
        wheeledtank_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        wheeledtank_Human.animation_idle = ActorAnimationSequences.walk_0;
		wheeledtank_Human.animation_swim = ActorAnimationSequences.swim_0_3;
            wheeledtank_Human.name_locale = "Armored Car";
			wheeledtank_Human.addTrait("dodge");
			wheeledtank_Human.addTrait("dash");
			wheeledtank_Human.addTrait("fire_proof");
            AssetManager.actor_library.add(wheeledtank_Human);
			Localization.addLocalization(wheeledtank_Human.name_locale, wheeledtank_Human.name_locale);



	var MissileSystem_Human = AssetManager.actor_library.clone("MissileSystem_Human","baseWarUnit");
	MissileSystem_Human.die_in_lava = false;
        MissileSystem_Human.base_stats["mass_2"] = 600f;
        MissileSystem_Human.base_stats["stamina"] = 500f;
        MissileSystem_Human.base_stats["scale"] = 0.2f;
        MissileSystem_Human.base_stats["size"] = 1f;
		MissileSystem_Human.base_stats["mass"] = 1000f;
        MissileSystem_Human.base_stats["health"] = 300f;
		MissileSystem_Human.base_stats["speed"] = 20f;
		MissileSystem_Human.base_stats["armor"] = 10f;
		MissileSystem_Human.base_stats["attack_speed"] = 0.1f;
		MissileSystem_Human.base_stats["damage"] = 30f;
		MissileSystem_Human.base_stats["knockback"] = 4f;
		MissileSystem_Human.base_stats["accuracy"] = 0.1f;
		MissileSystem_Human.base_stats["targets"] = 2f;
		MissileSystem_Human.base_stats["area_of_effect"] = 4f;
		MissileSystem_Human.base_stats["range"] = 100f;
		MissileSystem_Human.inspect_avatar_scale = 2f;
        MissileSystem_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        MissileSystem_Human.default_attack = "MissileSystemmissile";
        MissileSystem_Human.icon = "iconBoat";
        MissileSystem_Human.shadow_texture = "unitShadow_6";
        MissileSystem_Human.texture_asset = new ActorTextureSubAsset("actors/MissileSystem_Human/");
        MissileSystem_Human.special = true;
        MissileSystem_Human.has_advanced_textures = false;
        MissileSystem_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        MissileSystem_Human.animation_idle = Vehicles.idle_0;
		MissileSystem_Human.animation_swim = ActorAnimationSequences.swim_0_3;
            MissileSystem_Human.name_locale = "Missile System";
			MissileSystem_Human.addTrait("fire_proof");
            AssetManager.actor_library.add(MissileSystem_Human);
			Localization.addLocalization(MissileSystem_Human.name_locale, MissileSystem_Human.name_locale);

	var supporttruck_Human = AssetManager.actor_library.clone("supporttruck_Human","baseWarUnit");
	supporttruck_Human.die_in_lava = false;
        supporttruck_Human.base_stats["mass_2"] = 600f;
        supporttruck_Human.base_stats["stamina"] = 500f;
        supporttruck_Human.base_stats["scale"] = 0.2f;
        supporttruck_Human.base_stats["size"] = 1f;
		supporttruck_Human.base_stats["mass"] = 1000f;
        supporttruck_Human.base_stats["health"] = 300f;
		supporttruck_Human.base_stats["speed"] = 20f;
		supporttruck_Human.base_stats["armor"] = 10f;
		supporttruck_Human.base_stats["attack_speed"] = 0.1f;
		supporttruck_Human.base_stats["damage"] = 30f;
		supporttruck_Human.base_stats["knockback"] = 4f;
		supporttruck_Human.base_stats["accuracy"] = 0.1f;
		supporttruck_Human.base_stats["targets"] = 2f;
		supporttruck_Human.base_stats["area_of_effect"] = 4f;
		supporttruck_Human.base_stats["range"] = 100f;
        supporttruck_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        supporttruck_Human.default_attack = "base_attack";
        supporttruck_Human.icon = "iconBoat";
        supporttruck_Human.shadow_texture = "unitShadow_6";
		supporttruck_Human.inspect_avatar_scale = 1f;
        supporttruck_Human.texture_asset = new ActorTextureSubAsset("actors/supporttruck_Human/");
        supporttruck_Human.special = true;
        supporttruck_Human.has_advanced_textures = false;
        supporttruck_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        supporttruck_Human.animation_idle = ActorAnimationSequences.walk_0;
		supporttruck_Human.animation_swim = ActorAnimationSequences.swim_0_3;
            supporttruck_Human.name_locale = "Support Unit";
            supporttruck_Human.skip_fight_logic = true;
			supporttruck_Human.addTrait("fire_proof");
			   supporttruck_Human.job = AssetLibrary<ActorAsset>.a<string>("decision");
           supporttruck_Human.addDecision("check_swearing");
supporttruck_Human.addDecision("warrior_try_join_army_group");
supporttruck_Human.addDecision("city_walking_to_danger_zone");
supporttruck_Human.addDecision("check_cure");
supporttruck_Human.addDecision("warrior_army_leader_move_random");
supporttruck_Human.addDecision("check_heal");
supporttruck_Human.addDecision("warrior_army_follow_leader");
supporttruck_Human.addDecision("warrior_random_move");
supporttruck_Human.addDecision("check_warrior_transport");
supporttruck_Human.addDecision("swim_to_island");
            AssetManager.actor_library.add(supporttruck_Human);
			Localization.addLocalization(supporttruck_Human.name_locale, supporttruck_Human.name_locale);

/////give it cast heal trait




		var Heli_Human = AssetManager.actor_library.clone("Heli_Human","baseWarUnit");
	Heli_Human.die_in_lava = false;
	Heli_Human.animation_speed_based_on_walk_speed = false;
        Heli_Human.base_stats["mass_2"] = 600f;
        Heli_Human.base_stats["stamina"] = 1000f;
        Heli_Human.base_stats["scale"] = 0.2f;
        Heli_Human.base_stats["size"] = 1f;
		Heli_Human.base_stats["mass"] = 1000f;
        Heli_Human.base_stats["health"] = 200f;
		Heli_Human.base_stats["speed"] = 60f;
		Heli_Human.base_stats["armor"] = 0f;
		Heli_Human.base_stats["attack_speed"] = 10000f;
		Heli_Human.base_stats["damage"] = 20f;
		Heli_Human.base_stats["knockback"] = 0.01f;
		Heli_Human.base_stats["accuracy"] = 0.7f;
		Heli_Human.base_stats["targets"] = 1f;
		Heli_Human.base_stats["area_of_effect"] = 0.5f;
		Heli_Human.base_stats["range"] = 14f;
        Heli_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        Heli_Human.default_attack = "mountedmachinegun";
        Heli_Human.icon = "iconBoat";
        Heli_Human.shadow_texture = "unitShadow_6";
        Heli_Human.texture_asset = new ActorTextureSubAsset("actors/Heli_Human/");
        Heli_Human.special = true;
        Heli_Human.has_advanced_textures = false;
        Heli_Human.animation_walk = ActorAnimationSequences.walk_0_3;
        Heli_Human.animation_idle = ActorAnimationSequences.walk_0_3;
		Heli_Human.animation_swim = ActorAnimationSequences.walk_0_3;
            Heli_Human.name_locale = "Helicopter";
			Heli_Human.addTrait("fire_proof");
            Heli_Human.addTrait("freeze_proof");
			Heli_Human.flying = true;
			Heli_Human.very_high_flyer = true;
			Heli_Human.die_on_blocks = false;
			Heli_Human.inspect_avatar_scale = 0.5f;
			Heli_Human.ignore_blocks = true;
            AssetManager.actor_library.add(Heli_Human);
			Localization.addLocalization(Heli_Human.name_locale, Heli_Human.name_locale);


		var Bomber_Human = AssetManager.actor_library.clone("Bomber_Human","baseWarUnit");
	Bomber_Human.die_in_lava = false;
	Bomber_Human.animation_speed_based_on_walk_speed = false;
        Bomber_Human.base_stats["mass_2"] = 600f;
        Bomber_Human.base_stats["stamina"] = 1000f;
        Bomber_Human.base_stats["scale"] = 0.2f;
        Bomber_Human.base_stats["size"] = 1f;
		Bomber_Human.base_stats["mass"] = 1000f;
        Bomber_Human.base_stats["health"] = 400f;
		Bomber_Human.base_stats["speed"] = 30f;
		Bomber_Human.base_stats["armor"] = 0f;
		Bomber_Human.base_stats["attack_speed"] = 0.3f;
		Bomber_Human.base_stats["damage"] = 200f;
		Bomber_Human.base_stats["knockback"] = 2f;
		Bomber_Human.base_stats["accuracy"] = 0.7f;
		Bomber_Human.base_stats["targets"] = 5f;
		Bomber_Human.base_stats["area_of_effect"] = 0.5f;
		Bomber_Human.base_stats["range"] = 1f;
        Bomber_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        Bomber_Human.default_attack = "BomberAttack";
        Bomber_Human.icon = "iconBoat";
        Bomber_Human.shadow_texture = "unitShadow_6";
        Bomber_Human.texture_asset = new ActorTextureSubAsset("actors/Bomber_Human/");
        Bomber_Human.special = true;
        Bomber_Human.can_flip = false;
        Bomber_Human.has_advanced_textures = false;
        Bomber_Human.animation_walk = Vehicles.idle_0_19;
        Bomber_Human.animation_idle = Vehicles.idle_0_19;
		Bomber_Human.animation_swim = Vehicles.idle_0_19;
            Bomber_Human.name_locale = "Bomber";
			Bomber_Human.addTrait("fire_proof");
            Bomber_Human.addTrait("freeze_proof");
			Bomber_Human.flying = true;
			Bomber_Human.very_high_flyer = true;
			Bomber_Human.die_on_blocks = false;
			Bomber_Human.ignore_blocks = true;
			Bomber_Human.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(Bomber_Human);
			Localization.addLocalization(Bomber_Human.name_locale, Bomber_Human.name_locale);

	var FighterJet_Human = AssetManager.actor_library.clone("FighterJet_Human","baseWarUnit");
	FighterJet_Human.die_in_lava = false;
	FighterJet_Human.animation_speed_based_on_walk_speed = false;
        FighterJet_Human.base_stats["mass_2"] = 600f;
        FighterJet_Human.base_stats["stamina"] = 1000f;
        FighterJet_Human.base_stats["scale"] = 0.2f;
        FighterJet_Human.base_stats["size"] = 1f;
		FighterJet_Human.base_stats["mass"] = 1000f;
        FighterJet_Human.base_stats["health"] = 400f;
		FighterJet_Human.base_stats["speed"] = 30f;
		FighterJet_Human.base_stats["armor"] = 0f;
		FighterJet_Human.base_stats["attack_speed"] = 0.3f;
		FighterJet_Human.base_stats["damage"] = 100f;
		FighterJet_Human.base_stats["knockback"] = 2f;
		FighterJet_Human.base_stats["accuracy"] = 0.7f;
		FighterJet_Human.base_stats["targets"] = 1f;
		FighterJet_Human.base_stats["area_of_effect"] = 0.5f;
		FighterJet_Human.base_stats["range"] = 6f;
		FighterJet_Human.inspect_avatar_scale = 0.5f;
        FighterJet_Human.sound_hit = "event:/SFX/HIT/HitMetal";
        FighterJet_Human.default_attack = "fighterattack";
        FighterJet_Human.icon = "iconBoat";
        FighterJet_Human.shadow_texture = "unitShadow_6";
        FighterJet_Human.texture_asset = new ActorTextureSubAsset("actors/FighterJet_Human/");
        FighterJet_Human.special = true;
        FighterJet_Human.can_flip = false;
        FighterJet_Human.has_advanced_textures = false;
        FighterJet_Human.animation_walk = Vehicles.idle_0_9;
        FighterJet_Human.animation_idle = Vehicles.idle_0_9;
		FighterJet_Human.animation_swim = Vehicles.idle_0_9;
            FighterJet_Human.name_locale = "Fighter Jet";
			FighterJet_Human.addTrait("fire_proof");
            FighterJet_Human.addTrait("freeze_proof");
			FighterJet_Human.flying = true;
			FighterJet_Human.very_high_flyer = true;
			FighterJet_Human.die_on_blocks = false;
			FighterJet_Human.ignore_blocks = true;
            AssetManager.actor_library.add(FighterJet_Human);
			Localization.addLocalization(FighterJet_Human.name_locale, FighterJet_Human.name_locale);


	var F55FighterJet = AssetManager.actor_library.clone("F55FighterJet","baseWarUnit");
	F55FighterJet.die_in_lava = false;
	F55FighterJet.animation_speed_based_on_walk_speed = false;
        F55FighterJet.base_stats["mass_2"] = 600f;
        F55FighterJet.base_stats["stamina"] = 1000f;
        F55FighterJet.base_stats["scale"] = 0.2f;
        F55FighterJet.base_stats["size"] = 1f;
		F55FighterJet.base_stats["mass"] = 1000f;
        F55FighterJet.base_stats["health"] = 400f;
		F55FighterJet.base_stats["speed"] = 30f;
		F55FighterJet.base_stats["armor"] = 0f;
		F55FighterJet.base_stats["attack_speed"] = 0.3f;
		F55FighterJet.base_stats["damage"] = 200f;
		F55FighterJet.base_stats["knockback"] = 2f;
		F55FighterJet.base_stats["accuracy"] = 0.7f;
		F55FighterJet.base_stats["targets"] = 1f;
		F55FighterJet.base_stats["area_of_effect"] = 0.5f;
		F55FighterJet.base_stats["range"] = 1f;
        F55FighterJet.sound_hit = "event:/SFX/HIT/HitMetal";
        F55FighterJet.default_attack = "fighterattack";
        F55FighterJet.icon = "iconBoat";
        F55FighterJet.can_flip = false;
        F55FighterJet.shadow_texture = "unitShadow_6";
        F55FighterJet.texture_asset = new ActorTextureSubAsset("actors/F55FighterJet/");
        F55FighterJet.special = true;
		F55FighterJet.inspect_avatar_scale = 0.5f;
        F55FighterJet.has_advanced_textures = false;
        F55FighterJet.animation_walk = Vehicles.idle_0_9;
        F55FighterJet.animation_idle = Vehicles.idle_0_9;
		F55FighterJet.animation_swim = Vehicles.idle_0_9;
            F55FighterJet.name_locale = "F55FighterJet";
			F55FighterJet.addTrait("fire_proof");
            F55FighterJet.addTrait("freeze_proof");
			F55FighterJet.flying = true;
			F55FighterJet.very_high_flyer = true;
			F55FighterJet.die_on_blocks = false;
			F55FighterJet.ignore_blocks = true;
            AssetManager.actor_library.add(F55FighterJet);
			Localization.addLocalization(F55FighterJet.name_locale, F55FighterJet.name_locale);



	var modernhumvee_Ork = AssetManager.actor_library.clone("modernhumvee_Ork","baseWarUnit");
	modernhumvee_Ork.die_in_lava = false;
        modernhumvee_Ork.base_stats["mass_2"] = 600f;
        modernhumvee_Ork.base_stats["stamina"] = 500f;
        modernhumvee_Ork.base_stats["scale"] = 0.2f;
        modernhumvee_Ork.base_stats["size"] = 1f;
		modernhumvee_Ork.base_stats["mass"] = 1000f;
        modernhumvee_Ork.base_stats["health"] = 300f;
		modernhumvee_Ork.base_stats["speed"] = 70f;
		modernhumvee_Ork.base_stats["armor"] = 20f;
		modernhumvee_Ork.base_stats["attack_speed"] = 10000f;
		modernhumvee_Ork.base_stats["damage"] = 10f;
		modernhumvee_Ork.base_stats["knockback"] = 0.01f;
		modernhumvee_Ork.base_stats["accuracy"] = 0.5f;
		modernhumvee_Ork.base_stats["targets"] = 1f;
		modernhumvee_Ork.base_stats["area_of_effect"] = 0.5f;
		modernhumvee_Ork.base_stats["range"] = 14f;
        modernhumvee_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        modernhumvee_Ork.default_attack = "hordemachinegun";
        modernhumvee_Ork.icon = "iconBoat";
        modernhumvee_Ork.shadow_texture = "unitShadow_6";
        modernhumvee_Ork.texture_asset = new ActorTextureSubAsset("actors/modernhumvee_Ork/");
        modernhumvee_Ork.special = true;
        modernhumvee_Ork.has_advanced_textures = false;
        modernhumvee_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        modernhumvee_Ork.animation_idle = ActorAnimationSequences.walk_0;
		modernhumvee_Ork.animation_swim = ActorAnimationSequences.swim_0_3;
            modernhumvee_Ork.name_locale = "Light Vehicle";
			modernhumvee_Ork.addTrait("dodge");
			modernhumvee_Ork.addTrait("dash");
			modernhumvee_Ork.addTrait("fire_proof");
            AssetManager.actor_library.add(modernhumvee_Ork);
			Localization.addLocalization(modernhumvee_Ork.name_locale, modernhumvee_Ork.name_locale);

	var howitzer_Ork = AssetManager.actor_library.clone("howitzer_Ork","baseWarUnit");
	howitzer_Ork.die_in_lava = false;
        howitzer_Ork.base_stats["mass_2"] = 600f;
        howitzer_Ork.base_stats["stamina"] = 500f;
        howitzer_Ork.base_stats["scale"] = 0.2f;
        howitzer_Ork.base_stats["size"] = 1f;
		howitzer_Ork.base_stats["mass"] = 1000f;
        howitzer_Ork.base_stats["health"] = 200f;
		howitzer_Ork.base_stats["speed"] = 20f;
		howitzer_Ork.base_stats["armor"] = 20f;
		howitzer_Ork.base_stats["attack_speed"] = 0.1f;
		howitzer_Ork.base_stats["damage"] = 100f;
		howitzer_Ork.base_stats["knockback"] = 3f;
		howitzer_Ork.base_stats["accuracy"] = 0.3f;
		howitzer_Ork.base_stats["targets"] = 3f;
		howitzer_Ork.base_stats["area_of_effect"] = 4f;
		howitzer_Ork.base_stats["range"] = 30f;
        howitzer_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        howitzer_Ork.default_attack = "hordeartilleryshell";
        howitzer_Ork.icon = "iconBoat";
		howitzer_Ork.inspect_avatar_scale = 2f;
        howitzer_Ork.shadow_texture = "unitShadow_6";
        howitzer_Ork.texture_asset = new ActorTextureSubAsset("actors/howitzer_Ork/");
        howitzer_Ork.special = true;
        howitzer_Ork.has_advanced_textures = false;
        howitzer_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        howitzer_Ork.animation_idle = ActorAnimationSequences.walk_0;
		howitzer_Ork.animation_swim = ActorAnimationSequences.swim_0_3;
            howitzer_Ork.name_locale = "Artillery";
			howitzer_Ork.addTrait("fire_proof");
            AssetManager.actor_library.add(howitzer_Ork);
			Localization.addLocalization(howitzer_Ork.name_locale, howitzer_Ork.name_locale);

	var Tank_Ork = AssetManager.actor_library.clone("Tank_Ork","baseWarUnit");
	Tank_Ork.die_in_lava = false;
        Tank_Ork.base_stats["mass_2"] = 600f;
        Tank_Ork.base_stats["stamina"] = 500f;
        Tank_Ork.base_stats["scale"] = 0.2f;
        Tank_Ork.base_stats["size"] = 1f;
		Tank_Ork.base_stats["mass"] = 1000f;
        Tank_Ork.base_stats["health"] = 800f;
		Tank_Ork.base_stats["speed"] = 40f;
		Tank_Ork.base_stats["armor"] = 40f;
		Tank_Ork.base_stats["attack_speed"] = 0.1f;
		Tank_Ork.base_stats["damage"] = 50f;
		Tank_Ork.base_stats["knockback"] = 4f;
		Tank_Ork.base_stats["accuracy"] = 0.8f;
		Tank_Ork.base_stats["targets"] = 2f;
		Tank_Ork.base_stats["area_of_effect"] = 2f;
		Tank_Ork.base_stats["range"] = 20f;
        Tank_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        Tank_Ork.default_attack = "hordetankpew";
        Tank_Ork.icon = "iconBoat";
        Tank_Ork.shadow_texture = "unitShadow_6";
        Tank_Ork.texture_asset = new ActorTextureSubAsset("actors/Tank_Ork/");
        Tank_Ork.special = true;
		Tank_Ork.inspect_avatar_scale = 2f;
        Tank_Ork.has_advanced_textures = false;
        Tank_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        Tank_Ork.animation_idle = Vehicles.idle_0_2;
		Tank_Ork.animation_swim = ActorAnimationSequences.swim_0_2;
            Tank_Ork.name_locale = "Tank";
			Tank_Ork.addTrait("fire_proof");
			Tank_Ork.addTrait("block");
			Tank_Ork.addTrait("deflect_projectile");
            AssetManager.actor_library.add(Tank_Ork);
			Localization.addLocalization(Tank_Ork.name_locale, Tank_Ork.name_locale);

	var wheeledtank_Ork = AssetManager.actor_library.clone("wheeledtank_Ork","baseWarUnit");
	wheeledtank_Ork.die_in_lava = false;
        wheeledtank_Ork.base_stats["mass_2"] = 600f;
        wheeledtank_Ork.base_stats["stamina"] = 500f;
        wheeledtank_Ork.base_stats["scale"] = 0.2f;
        wheeledtank_Ork.base_stats["size"] = 1f;
		wheeledtank_Ork.base_stats["mass"] = 1000f;
        wheeledtank_Ork.base_stats["health"] = 800f;
		wheeledtank_Ork.base_stats["speed"] = 70f;
		wheeledtank_Ork.base_stats["armor"] = 30f;
		wheeledtank_Ork.base_stats["attack_speed"] = 10f;
		wheeledtank_Ork.base_stats["damage"] = 40f;
		wheeledtank_Ork.base_stats["knockback"] = 0.01f;
		wheeledtank_Ork.base_stats["accuracy"] = 0.5f;
		wheeledtank_Ork.base_stats["targets"] = 1f;
		wheeledtank_Ork.base_stats["area_of_effect"] = 0.5f;
		wheeledtank_Ork.base_stats["range"] = 14f;
        wheeledtank_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        wheeledtank_Ork.default_attack = "hordetankpew";
        wheeledtank_Ork.icon = "iconBoat";
		wheeledtank_Ork.inspect_avatar_scale = 2f;
        wheeledtank_Ork.shadow_texture = "unitShadow_6";
        wheeledtank_Ork.texture_asset = new ActorTextureSubAsset("actors/wheeledtank_Ork/");
        wheeledtank_Ork.special = true;
        wheeledtank_Ork.has_advanced_textures = false;
        wheeledtank_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        wheeledtank_Ork.animation_idle = ActorAnimationSequences.walk_0;
		wheeledtank_Ork.animation_swim = ActorAnimationSequences.swim_0_3;
            wheeledtank_Ork.name_locale = "Armored Car";
			wheeledtank_Ork.addTrait("dodge");
			wheeledtank_Ork.addTrait("dash");
			wheeledtank_Ork.addTrait("fire_proof");
            AssetManager.actor_library.add(wheeledtank_Ork);
			Localization.addLocalization(wheeledtank_Ork.name_locale, wheeledtank_Ork.name_locale);

	var MissileSystem_Ork = AssetManager.actor_library.clone("MissileSystem_Ork","baseWarUnit");
	MissileSystem_Ork.die_in_lava = false;
        MissileSystem_Ork.base_stats["mass_2"] = 600f;
        MissileSystem_Ork.base_stats["stamina"] = 500f;
        MissileSystem_Ork.base_stats["scale"] = 0.2f;
        MissileSystem_Ork.base_stats["size"] = 1f;
		MissileSystem_Ork.base_stats["mass"] = 1000f;
        MissileSystem_Ork.base_stats["health"] = 300f;
		MissileSystem_Ork.base_stats["speed"] = 20f;
		MissileSystem_Ork.base_stats["armor"] = 10f;
		MissileSystem_Ork.base_stats["attack_speed"] = 0.1f;
		MissileSystem_Ork.base_stats["damage"] = 30f;
		MissileSystem_Ork.base_stats["knockback"] = 4f;
		MissileSystem_Ork.base_stats["accuracy"] = 0.1f;
		MissileSystem_Ork.base_stats["targets"] = 3f;
		MissileSystem_Ork.base_stats["area_of_effect"] = 4f;
		MissileSystem_Ork.base_stats["range"] = 100f;
		MissileSystem_Ork.inspect_avatar_scale = 2f;
        MissileSystem_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        MissileSystem_Ork.default_attack = "MissileSystemHorde";
        MissileSystem_Ork.icon = "iconBoat";
        MissileSystem_Ork.shadow_texture = "unitShadow_6";
        MissileSystem_Ork.texture_asset = new ActorTextureSubAsset("actors/MissileSystem_Ork/");
        MissileSystem_Ork.special = true;
        MissileSystem_Ork.has_advanced_textures = false;
        MissileSystem_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        MissileSystem_Ork.animation_idle = Vehicles.idle_0;
		MissileSystem_Ork.animation_swim = ActorAnimationSequences.swim_0_3;
            MissileSystem_Ork.name_locale = "Missile System";
			MissileSystem_Ork.addTrait("fire_proof");
            AssetManager.actor_library.add(MissileSystem_Ork);
			Localization.addLocalization(MissileSystem_Ork.name_locale, MissileSystem_Ork.name_locale);

	var supporttruck_Ork = AssetManager.actor_library.clone("supporttruck_Ork","baseWarUnit");
	supporttruck_Ork.die_in_lava = false;
        supporttruck_Ork.base_stats["mass_2"] = 600f;
        supporttruck_Ork.base_stats["stamina"] = 500f;
        supporttruck_Ork.base_stats["scale"] = 0.2f;
        supporttruck_Ork.base_stats["size"] = 1f;
		supporttruck_Ork.base_stats["mass"] = 1000f;
        supporttruck_Ork.base_stats["health"] = 300f;
		supporttruck_Ork.base_stats["speed"] = 20f;
		supporttruck_Ork.base_stats["armor"] = 10f;
		supporttruck_Ork.base_stats["attack_speed"] = 0.1f;
		supporttruck_Ork.base_stats["damage"] = 30f;
		supporttruck_Ork.base_stats["knockback"] = 4f;
		supporttruck_Ork.base_stats["accuracy"] = 0.1f;
		supporttruck_Ork.base_stats["targets"] = 2f;
		supporttruck_Ork.base_stats["area_of_effect"] = 4f;
		supporttruck_Ork.base_stats["range"] = 100f;
        supporttruck_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        supporttruck_Ork.default_attack = "base_attack";
        supporttruck_Ork.icon = "iconBoat";
        supporttruck_Ork.shadow_texture = "unitShadow_6";
		supporttruck_Ork.inspect_avatar_scale = 1f;
        supporttruck_Ork.texture_asset = new ActorTextureSubAsset("actors/supporttruck_Ork/");
        supporttruck_Ork.special = true;
        supporttruck_Ork.has_advanced_textures = false;
        supporttruck_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        supporttruck_Ork.animation_idle = ActorAnimationSequences.walk_0;
		supporttruck_Ork.animation_swim = ActorAnimationSequences.swim_0_3;
            supporttruck_Ork.name_locale = "Support Unit";
            supporttruck_Ork.skip_fight_logic = true;
			supporttruck_Ork.addTrait("fire_proof");
			   supporttruck_Ork.job = AssetLibrary<ActorAsset>.a<string>("decision");
           supporttruck_Ork.addDecision("check_swearing");
supporttruck_Ork.addDecision("warrior_try_join_army_group");
supporttruck_Ork.addDecision("city_walking_to_danger_zone");
supporttruck_Ork.addDecision("check_cure");
supporttruck_Ork.addDecision("warrior_army_leader_move_random");
supporttruck_Ork.addDecision("check_heal");
supporttruck_Ork.addDecision("warrior_army_follow_leader");
supporttruck_Ork.addDecision("warrior_random_move");
supporttruck_Ork.addDecision("check_warrior_transport");
supporttruck_Ork.addDecision("swim_to_island");
            AssetManager.actor_library.add(supporttruck_Ork);
			Localization.addLocalization(supporttruck_Ork.name_locale, supporttruck_Ork.name_locale);

		var Heli_Ork = AssetManager.actor_library.clone("Heli_Ork","baseWarUnit");
	Heli_Ork.die_in_lava = false;
	Heli_Ork.animation_speed_based_on_walk_speed = false;
        Heli_Ork.base_stats["mass_2"] = 600f;
        Heli_Ork.base_stats["stamina"] = 1000f;
        Heli_Ork.base_stats["scale"] = 0.2f;
        Heli_Ork.base_stats["size"] = 1f;
		Heli_Ork.base_stats["mass"] = 1000f;
        Heli_Ork.base_stats["health"] = 200f;
		Heli_Ork.base_stats["speed"] = 60f;
		Heli_Ork.base_stats["armor"] = 0f;
		Heli_Ork.base_stats["attack_speed"] = 10000f;
		Heli_Ork.base_stats["damage"] = 20f;
		Heli_Ork.base_stats["knockback"] = 0.01f;
		Heli_Ork.base_stats["accuracy"] = 0.7f;
		Heli_Ork.base_stats["targets"] = 1f;
		Heli_Ork.base_stats["area_of_effect"] = 0.5f;
		Heli_Ork.base_stats["range"] = 14f;
        Heli_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        Heli_Ork.default_attack = "hordemachinegun";
        Heli_Ork.icon = "iconBoat";
        Heli_Ork.shadow_texture = "unitShadow_6";
        Heli_Ork.texture_asset = new ActorTextureSubAsset("actors/Heli_Ork/");
        Heli_Ork.special = true;
        Heli_Ork.has_advanced_textures = false;
        Heli_Ork.animation_walk = ActorAnimationSequences.walk_0_3;
        Heli_Ork.animation_idle = ActorAnimationSequences.walk_0_3;
		Heli_Ork.animation_swim = ActorAnimationSequences.walk_0_3;
            Heli_Ork.name_locale = "Helicopter";
			Heli_Ork.addTrait("fire_proof");
            Heli_Ork.addTrait("freeze_proof");
			Heli_Ork.flying = true;
			Heli_Ork.very_high_flyer = true;
			Heli_Ork.die_on_blocks = false;
			Heli_Ork.inspect_avatar_scale = 0.5f;
			Heli_Ork.ignore_blocks = true;
            AssetManager.actor_library.add(Heli_Ork);
			Localization.addLocalization(Heli_Ork.name_locale, Heli_Ork.name_locale);

		var Bomber_Ork = AssetManager.actor_library.clone("Bomber_Ork","baseWarUnit");
	Bomber_Ork.die_in_lava = false;
	Bomber_Ork.animation_speed_based_on_walk_speed = false;
        Bomber_Ork.base_stats["mass_2"] = 600f;
        Bomber_Ork.base_stats["stamina"] = 1000f;
        Bomber_Ork.base_stats["scale"] = 0.2f;
        Bomber_Ork.base_stats["size"] = 1f;
		Bomber_Ork.base_stats["mass"] = 1000f;
        Bomber_Ork.base_stats["health"] = 400f;
		Bomber_Ork.base_stats["speed"] = 30f;
		Bomber_Ork.base_stats["armor"] = 0f;
		Bomber_Ork.base_stats["attack_speed"] = 0.3f;
		Bomber_Ork.base_stats["damage"] = 200f;
		Bomber_Ork.base_stats["knockback"] = 2f;
		Bomber_Ork.base_stats["accuracy"] = 0.7f;
		Bomber_Ork.base_stats["targets"] = 5f;
		Bomber_Ork.base_stats["area_of_effect"] = 0.5f;
		Bomber_Ork.base_stats["range"] = 1f;
        Bomber_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        Bomber_Ork.default_attack = "BomberAttackHorde";
        Bomber_Ork.icon = "iconBoat";
        Bomber_Ork.shadow_texture = "unitShadow_6";
        Bomber_Ork.texture_asset = new ActorTextureSubAsset("actors/Bomber_Ork/");
        Bomber_Ork.special = true;
        Bomber_Ork.can_flip = false;
        Bomber_Ork.has_advanced_textures = false;
        Bomber_Ork.animation_walk = Vehicles.idle_0_15;
        Bomber_Ork.animation_idle = Vehicles.idle_0_15;
		Bomber_Ork.animation_swim = Vehicles.idle_0_15;
            Bomber_Ork.name_locale = "Bomber";
			Bomber_Ork.addTrait("fire_proof");
            Bomber_Ork.addTrait("freeze_proof");
			Bomber_Ork.flying = true;
			Bomber_Ork.very_high_flyer = true;
			Bomber_Ork.die_on_blocks = false;
			Bomber_Ork.ignore_blocks = true;
			Bomber_Ork.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(Bomber_Ork);
			Localization.addLocalization(Bomber_Ork.name_locale, Bomber_Ork.name_locale);

	var FighterJet_Ork = AssetManager.actor_library.clone("FighterJet_Ork","baseWarUnit");
	FighterJet_Ork.die_in_lava = false;
	FighterJet_Ork.animation_speed_based_on_walk_speed = false;
        FighterJet_Ork.base_stats["mass_2"] = 600f;
        FighterJet_Ork.base_stats["stamina"] = 1000f;
        FighterJet_Ork.base_stats["scale"] = 0.2f;
        FighterJet_Ork.base_stats["size"] = 1f;
		FighterJet_Ork.base_stats["mass"] = 1000f;
        FighterJet_Ork.base_stats["health"] = 400f;
		FighterJet_Ork.base_stats["speed"] = 30f;
		FighterJet_Ork.base_stats["armor"] = 0f;
		FighterJet_Ork.base_stats["attack_speed"] = 0.3f;
		FighterJet_Ork.base_stats["damage"] = 100f;
		FighterJet_Ork.base_stats["knockback"] = 2f;
		FighterJet_Ork.base_stats["accuracy"] = 0.7f;
		FighterJet_Ork.base_stats["targets"] = 1f;
		FighterJet_Ork.base_stats["area_of_effect"] = 0.5f;
		FighterJet_Ork.base_stats["range"] = 6f;
		FighterJet_Ork.inspect_avatar_scale = 0.5f;
        FighterJet_Ork.sound_hit = "event:/SFX/HIT/HitMetal";
        FighterJet_Ork.default_attack = "fighterattackHorde";
        FighterJet_Ork.icon = "iconBoat";
        FighterJet_Ork.shadow_texture = "unitShadow_6";
        FighterJet_Ork.texture_asset = new ActorTextureSubAsset("actors/FighterJet_Ork/");
        FighterJet_Ork.special = true;
        FighterJet_Ork.can_flip = false;
        FighterJet_Ork.has_advanced_textures = false;
        FighterJet_Ork.animation_walk = Vehicles.idle_0_7;
        FighterJet_Ork.animation_idle = Vehicles.idle_0_7;
		FighterJet_Ork.animation_swim = Vehicles.idle_0_7;
            FighterJet_Ork.name_locale = "Fighter Jet";
			FighterJet_Ork.addTrait("fire_proof");
            FighterJet_Ork.addTrait("freeze_proof");
			FighterJet_Ork.flying = true;
			FighterJet_Ork.very_high_flyer = true;
			FighterJet_Ork.die_on_blocks = false;
			FighterJet_Ork.ignore_blocks = true;
            AssetManager.actor_library.add(FighterJet_Ork);
			Localization.addLocalization(FighterJet_Ork.name_locale, FighterJet_Ork.name_locale);



	var modernhumvee_Dwarf = AssetManager.actor_library.clone("modernhumvee_Dwarf","baseWarUnit");
	modernhumvee_Dwarf.die_in_lava = false;
        modernhumvee_Dwarf.base_stats["mass_2"] = 600f;
        modernhumvee_Dwarf.base_stats["stamina"] = 500f;
        modernhumvee_Dwarf.base_stats["scale"] = 0.2f;
        modernhumvee_Dwarf.base_stats["size"] = 1f;
		modernhumvee_Dwarf.base_stats["mass"] = 1000f;
        modernhumvee_Dwarf.base_stats["health"] = 300f;
		modernhumvee_Dwarf.base_stats["speed"] = 70f;
		modernhumvee_Dwarf.base_stats["armor"] = 20f;
		modernhumvee_Dwarf.base_stats["attack_speed"] = 10000f;
		modernhumvee_Dwarf.base_stats["damage"] = 10f;
		modernhumvee_Dwarf.base_stats["knockback"] = 0.01f;
		modernhumvee_Dwarf.base_stats["accuracy"] = 0.5f;
		modernhumvee_Dwarf.base_stats["targets"] = 1f;
		modernhumvee_Dwarf.base_stats["area_of_effect"] = 0.5f;
		modernhumvee_Dwarf.base_stats["range"] = 14f;
        modernhumvee_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        modernhumvee_Dwarf.default_attack = "icemachinegun";
        modernhumvee_Dwarf.icon = "iconBoat";
        modernhumvee_Dwarf.shadow_texture = "unitShadow_6";
        modernhumvee_Dwarf.texture_asset = new ActorTextureSubAsset("actors/modernhumvee_Dwarf/");
        modernhumvee_Dwarf.special = true;
        modernhumvee_Dwarf.has_advanced_textures = false;
        modernhumvee_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        modernhumvee_Dwarf.animation_idle = ActorAnimationSequences.walk_0;
		modernhumvee_Dwarf.animation_swim = ActorAnimationSequences.swim_0_3;
            modernhumvee_Dwarf.name_locale = "Light Vehicle";
			modernhumvee_Dwarf.addTrait("dodge");
			modernhumvee_Dwarf.addTrait("dash");
			modernhumvee_Dwarf.addTrait("fire_proof");
            AssetManager.actor_library.add(modernhumvee_Dwarf);
			Localization.addLocalization(modernhumvee_Dwarf.name_locale, modernhumvee_Dwarf.name_locale);

	var Tank_Dwarf = AssetManager.actor_library.clone("Tank_Dwarf","baseWarUnit");
	Tank_Dwarf.die_in_lava = false;
        Tank_Dwarf.base_stats["mass_2"] = 600f;
        Tank_Dwarf.base_stats["stamina"] = 500f;
        Tank_Dwarf.base_stats["scale"] = 0.2f;
        Tank_Dwarf.base_stats["size"] = 1f;
		Tank_Dwarf.base_stats["mass"] = 1000f;
        Tank_Dwarf.base_stats["health"] = 800f;
		Tank_Dwarf.base_stats["speed"] = 40f;
		Tank_Dwarf.base_stats["armor"] = 40f;
		Tank_Dwarf.base_stats["attack_speed"] = 0.1f;
		Tank_Dwarf.base_stats["damage"] = 50f;
		Tank_Dwarf.base_stats["knockback"] = 4f;
		Tank_Dwarf.base_stats["accuracy"] = 0.8f;
		Tank_Dwarf.base_stats["targets"] = 2f;
		Tank_Dwarf.base_stats["area_of_effect"] = 2f;
		Tank_Dwarf.base_stats["range"] = 20f;
        Tank_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        Tank_Dwarf.default_attack = "crystaltankpew";
        Tank_Dwarf.icon = "iconBoat";
        Tank_Dwarf.shadow_texture = "unitShadow_6";
        Tank_Dwarf.texture_asset = new ActorTextureSubAsset("actors/Tank_Dwarf/");
        Tank_Dwarf.special = true;
		Tank_Dwarf.inspect_avatar_scale = 2f;
        Tank_Dwarf.has_advanced_textures = false;
        Tank_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        Tank_Dwarf.animation_idle = Vehicles.idle_0_2;
		Tank_Dwarf.animation_swim = ActorAnimationSequences.swim_0_2;
            Tank_Dwarf.name_locale = "Tank";
			Tank_Dwarf.addTrait("fire_proof");
			Tank_Dwarf.addTrait("block");
			Tank_Dwarf.addTrait("deflect_projectile");
            AssetManager.actor_library.add(Tank_Dwarf);
			Localization.addLocalization(Tank_Dwarf.name_locale, Tank_Dwarf.name_locale);

	var MissileSystem_Dwarf = AssetManager.actor_library.clone("MissileSystem_Dwarf","baseWarUnit");
	MissileSystem_Dwarf.die_in_lava = false;
        MissileSystem_Dwarf.base_stats["mass_2"] = 600f;
        MissileSystem_Dwarf.base_stats["stamina"] = 500f;
        MissileSystem_Dwarf.base_stats["scale"] = 0.2f;
        MissileSystem_Dwarf.base_stats["size"] = 1f;
		MissileSystem_Dwarf.base_stats["mass"] = 1000f;
        MissileSystem_Dwarf.base_stats["health"] = 300f;
		MissileSystem_Dwarf.base_stats["speed"] = 20f;
		MissileSystem_Dwarf.base_stats["armor"] = 10f;
		MissileSystem_Dwarf.base_stats["attack_speed"] = 0.1f;
		MissileSystem_Dwarf.base_stats["damage"] = 30f;
		MissileSystem_Dwarf.base_stats["knockback"] = 4f;
		MissileSystem_Dwarf.base_stats["accuracy"] = 0.1f;
		MissileSystem_Dwarf.base_stats["targets"] = 2f;
		MissileSystem_Dwarf.base_stats["area_of_effect"] = 4f;
		MissileSystem_Dwarf.base_stats["range"] = 100f;
		MissileSystem_Dwarf.inspect_avatar_scale = 2f;
        MissileSystem_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        MissileSystem_Dwarf.default_attack = "MissileSystemHarden";
        MissileSystem_Dwarf.icon = "iconBoat";
        MissileSystem_Dwarf.shadow_texture = "unitShadow_6";
        MissileSystem_Dwarf.texture_asset = new ActorTextureSubAsset("actors/MissileSystem_Dwarf/");
        MissileSystem_Dwarf.special = true;
        MissileSystem_Dwarf.has_advanced_textures = false;
        MissileSystem_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        MissileSystem_Dwarf.animation_idle = Vehicles.idle_0;
		MissileSystem_Dwarf.animation_swim = ActorAnimationSequences.swim_0_3;
            MissileSystem_Dwarf.name_locale = "Missile System";
			MissileSystem_Dwarf.addTrait("fire_proof");
            AssetManager.actor_library.add(MissileSystem_Dwarf);
			Localization.addLocalization(MissileSystem_Dwarf.name_locale, MissileSystem_Dwarf.name_locale);

	var supporttruck_Dwarf = AssetManager.actor_library.clone("supporttruck_Dwarf","baseWarUnit");
	supporttruck_Dwarf.die_in_lava = false;
        supporttruck_Dwarf.base_stats["mass_2"] = 600f;
        supporttruck_Dwarf.base_stats["stamina"] = 500f;
        supporttruck_Dwarf.base_stats["scale"] = 0.2f;
        supporttruck_Dwarf.base_stats["size"] = 1f;
		supporttruck_Dwarf.base_stats["mass"] = 1000f;
        supporttruck_Dwarf.base_stats["health"] = 300f;
		supporttruck_Dwarf.base_stats["speed"] = 20f;
		supporttruck_Dwarf.base_stats["armor"] = 10f;
		supporttruck_Dwarf.base_stats["attack_speed"] = 0.1f;
		supporttruck_Dwarf.base_stats["damage"] = 30f;
		supporttruck_Dwarf.base_stats["knockback"] = 4f;
		supporttruck_Dwarf.base_stats["accuracy"] = 0.1f;
		supporttruck_Dwarf.base_stats["targets"] = 3f;
		supporttruck_Dwarf.base_stats["area_of_effect"] = 4f;
		supporttruck_Dwarf.base_stats["range"] = 100f;
        supporttruck_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        supporttruck_Dwarf.default_attack = "base_attack";
        supporttruck_Dwarf.icon = "iconBoat";
        supporttruck_Dwarf.shadow_texture = "unitShadow_6";
		supporttruck_Dwarf.inspect_avatar_scale = 1f;
        supporttruck_Dwarf.texture_asset = new ActorTextureSubAsset("actors/supporttruck_Dwarf/");
        supporttruck_Dwarf.special = true;
        supporttruck_Dwarf.has_advanced_textures = false;
        supporttruck_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        supporttruck_Dwarf.animation_idle = ActorAnimationSequences.walk_0;
		supporttruck_Dwarf.animation_swim = ActorAnimationSequences.swim_0_3;
            supporttruck_Dwarf.name_locale = "Support Unit";
            supporttruck_Dwarf.skip_fight_logic = true;
			supporttruck_Dwarf.addTrait("fire_proof");
			   supporttruck_Dwarf.job = AssetLibrary<ActorAsset>.a<string>("decision");
           supporttruck_Dwarf.addDecision("check_swearing");
supporttruck_Dwarf.addDecision("warrior_try_join_army_group");
supporttruck_Dwarf.addDecision("city_walking_to_danger_zone");
supporttruck_Dwarf.addDecision("check_cure");
supporttruck_Dwarf.addDecision("warrior_army_leader_move_random");
supporttruck_Dwarf.addDecision("check_heal");
supporttruck_Dwarf.addDecision("warrior_army_follow_leader");
supporttruck_Dwarf.addDecision("warrior_random_move");
supporttruck_Dwarf.addDecision("check_warrior_transport");
supporttruck_Dwarf.addDecision("swim_to_island");
            AssetManager.actor_library.add(supporttruck_Dwarf);
			Localization.addLocalization(supporttruck_Dwarf.name_locale, supporttruck_Dwarf.name_locale);

		var Heli_Dwarf = AssetManager.actor_library.clone("Heli_Dwarf","baseWarUnit");
	Heli_Dwarf.die_in_lava = false;
	Heli_Dwarf.animation_speed_based_on_walk_speed = false;
        Heli_Dwarf.base_stats["mass_2"] = 600f;
        Heli_Dwarf.base_stats["stamina"] = 1000f;
        Heli_Dwarf.base_stats["scale"] = 0.2f;
        Heli_Dwarf.base_stats["size"] = 1f;
		Heli_Dwarf.base_stats["mass"] = 1000f;
        Heli_Dwarf.base_stats["health"] = 200f;
		Heli_Dwarf.base_stats["speed"] = 60f;
		Heli_Dwarf.base_stats["armor"] = 0f;
		Heli_Dwarf.base_stats["attack_speed"] = 10000f;
		Heli_Dwarf.base_stats["damage"] = 20f;
		Heli_Dwarf.base_stats["knockback"] = 0.01f;
		Heli_Dwarf.base_stats["accuracy"] = 0.7f;
		Heli_Dwarf.base_stats["targets"] = 1f;
		Heli_Dwarf.base_stats["area_of_effect"] = 0.5f;
		Heli_Dwarf.base_stats["range"] = 14f;
        Heli_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        Heli_Dwarf.default_attack = "icemachinegun";
        Heli_Dwarf.icon = "iconBoat";
        Heli_Dwarf.shadow_texture = "unitShadow_6";
        Heli_Dwarf.texture_asset = new ActorTextureSubAsset("actors/Heli_Dwarf/");
        Heli_Dwarf.special = true;
        Heli_Dwarf.has_advanced_textures = false;
        Heli_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        Heli_Dwarf.animation_idle = ActorAnimationSequences.walk_0_3;
		Heli_Dwarf.animation_swim = ActorAnimationSequences.walk_0_3;
            Heli_Dwarf.name_locale = "Helicopter";
			Heli_Dwarf.addTrait("fire_proof");
            Heli_Dwarf.addTrait("freeze_proof");
			Heli_Dwarf.flying = true;
			Heli_Dwarf.very_high_flyer = true;
			Heli_Dwarf.die_on_blocks = false;
			Heli_Dwarf.inspect_avatar_scale = 0.5f;
			Heli_Dwarf.ignore_blocks = true;
            AssetManager.actor_library.add(Heli_Dwarf);
			Localization.addLocalization(Heli_Dwarf.name_locale, Heli_Dwarf.name_locale);

		var Bomber_Dwarf = AssetManager.actor_library.clone("Bomber_Dwarf","baseWarUnit");
	Bomber_Dwarf.die_in_lava = false;
	Bomber_Dwarf.animation_speed_based_on_walk_speed = false;
        Bomber_Dwarf.base_stats["mass_2"] = 600f;
        Bomber_Dwarf.base_stats["stamina"] = 1000f;
        Bomber_Dwarf.base_stats["scale"] = 0.2f;
        Bomber_Dwarf.base_stats["size"] = 1f;
		Bomber_Dwarf.base_stats["mass"] = 1000f;
        Bomber_Dwarf.base_stats["health"] = 400f;
		Bomber_Dwarf.base_stats["speed"] = 30f;
		Bomber_Dwarf.base_stats["armor"] = 0f;
		Bomber_Dwarf.base_stats["attack_speed"] = 0.3f;
		Bomber_Dwarf.base_stats["damage"] = 200f;
		Bomber_Dwarf.base_stats["knockback"] = 2f;
		Bomber_Dwarf.base_stats["accuracy"] = 0.7f;
		Bomber_Dwarf.base_stats["targets"] = 5f;
		Bomber_Dwarf.base_stats["area_of_effect"] = 0.5f;
		Bomber_Dwarf.base_stats["range"] = 1f;
        Bomber_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        Bomber_Dwarf.default_attack = "BomberAttackHarden";
        Bomber_Dwarf.icon = "iconBoat";
        Bomber_Dwarf.shadow_texture = "unitShadow_6";
        Bomber_Dwarf.texture_asset = new ActorTextureSubAsset("actors/Bomber_Dwarf/");
        Bomber_Dwarf.special = true;
        Bomber_Dwarf.can_flip = false;
        Bomber_Dwarf.has_advanced_textures = false;
        Bomber_Dwarf.animation_walk = Vehicles.idle_0_7;
        Bomber_Dwarf.animation_idle = Vehicles.idle_0_7;
		Bomber_Dwarf.animation_swim = Vehicles.idle_0_7;
            Bomber_Dwarf.name_locale = "Bomber";
			Bomber_Dwarf.addTrait("fire_proof");
            Bomber_Dwarf.addTrait("freeze_proof");
			Bomber_Dwarf.flying = true;
			Bomber_Dwarf.very_high_flyer = true;
			Bomber_Dwarf.die_on_blocks = false;
			Bomber_Dwarf.ignore_blocks = true;
			Bomber_Dwarf.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(Bomber_Dwarf);
			Localization.addLocalization(Bomber_Dwarf.name_locale, Bomber_Dwarf.name_locale);

	var FighterJet_Dwarf = AssetManager.actor_library.clone("FighterJet_Dwarf","baseWarUnit");
	FighterJet_Dwarf.die_in_lava = false;
	FighterJet_Dwarf.animation_speed_based_on_walk_speed = false;
        FighterJet_Dwarf.base_stats["mass_2"] = 600f;
        FighterJet_Dwarf.base_stats["stamina"] = 1000f;
        FighterJet_Dwarf.base_stats["scale"] = 0.2f;
        FighterJet_Dwarf.base_stats["size"] = 1f;
		FighterJet_Dwarf.base_stats["mass"] = 1000f;
        FighterJet_Dwarf.base_stats["health"] = 400f;
		FighterJet_Dwarf.base_stats["speed"] = 30f;
		FighterJet_Dwarf.base_stats["armor"] = 0f;
		FighterJet_Dwarf.base_stats["attack_speed"] = 0.3f;
		FighterJet_Dwarf.base_stats["damage"] = 100f;
		FighterJet_Dwarf.base_stats["knockback"] = 2f;
		FighterJet_Dwarf.base_stats["accuracy"] = 0.7f;
		FighterJet_Dwarf.base_stats["targets"] = 1f;
		FighterJet_Dwarf.base_stats["area_of_effect"] = 0.5f;
		FighterJet_Dwarf.base_stats["range"] = 6f;
		FighterJet_Dwarf.inspect_avatar_scale = 0.5f;
        FighterJet_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        FighterJet_Dwarf.default_attack = "fighterattackHarden";
        FighterJet_Dwarf.icon = "iconBoat";
        FighterJet_Dwarf.shadow_texture = "unitShadow_6";
        FighterJet_Dwarf.texture_asset = new ActorTextureSubAsset("actors/FighterJet_Dwarf/");
        FighterJet_Dwarf.special = true;
        FighterJet_Dwarf.can_flip = false;
        FighterJet_Dwarf.has_advanced_textures = false;
        FighterJet_Dwarf.animation_walk = Vehicles.idle_0_9;
        FighterJet_Dwarf.animation_idle = Vehicles.idle_0_9;
		FighterJet_Dwarf.animation_swim = Vehicles.idle_0_9;
            FighterJet_Dwarf.name_locale = "Fighter Jet";
			FighterJet_Dwarf.addTrait("fire_proof");
            FighterJet_Dwarf.addTrait("freeze_proof");
			FighterJet_Dwarf.flying = true;
			FighterJet_Dwarf.very_high_flyer = true;
			FighterJet_Dwarf.die_on_blocks = false;
			FighterJet_Dwarf.ignore_blocks = true;
            AssetManager.actor_library.add(FighterJet_Dwarf);
			Localization.addLocalization(FighterJet_Dwarf.name_locale, FighterJet_Dwarf.name_locale);

var howitzer_Dwarf = AssetManager.actor_library.clone("howitzer_Dwarf","baseWarUnit");
	howitzer_Dwarf.die_in_lava = false;
        howitzer_Dwarf.base_stats["mass_2"] = 600f;
        howitzer_Dwarf.base_stats["stamina"] = 500f;
        howitzer_Dwarf.base_stats["scale"] = 0.2f;
        howitzer_Dwarf.base_stats["size"] = 1f;
		howitzer_Dwarf.base_stats["mass"] = 1000f;
        howitzer_Dwarf.base_stats["health"] = 200f;
		howitzer_Dwarf.base_stats["speed"] = 20f;
		howitzer_Dwarf.base_stats["armor"] = 20f;
		howitzer_Dwarf.base_stats["attack_speed"] = 0.1f;
		howitzer_Dwarf.base_stats["damage"] = 100f;
		howitzer_Dwarf.base_stats["knockback"] = 3f;
		howitzer_Dwarf.base_stats["accuracy"] = 0.3f;
		howitzer_Dwarf.base_stats["targets"] = 3f;
		howitzer_Dwarf.base_stats["area_of_effect"] = 4f;
		howitzer_Dwarf.base_stats["range"] = 30f;
        howitzer_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        howitzer_Dwarf.default_attack = "iceartilleryshell";
        howitzer_Dwarf.icon = "iconBoat";
		howitzer_Dwarf.inspect_avatar_scale = 2f;
        howitzer_Dwarf.shadow_texture = "unitShadow_6";
        howitzer_Dwarf.texture_asset = new ActorTextureSubAsset("actors/howitzer_Dwarf/");
        howitzer_Dwarf.special = true;
        howitzer_Dwarf.has_advanced_textures = false;
        howitzer_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        howitzer_Dwarf.animation_idle = ActorAnimationSequences.walk_0;
		howitzer_Dwarf.animation_swim = ActorAnimationSequences.swim_0_3;
            howitzer_Dwarf.name_locale = "Artillery";
			howitzer_Dwarf.addTrait("fire_proof");
            AssetManager.actor_library.add(howitzer_Dwarf);
			Localization.addLocalization(howitzer_Dwarf.name_locale, howitzer_Dwarf.name_locale);

			var wheeledtank_Dwarf = AssetManager.actor_library.clone("wheeledtank_Dwarf","baseWarUnit");
	wheeledtank_Dwarf.die_in_lava = false;
        wheeledtank_Dwarf.base_stats["mass_2"] = 600f;
        wheeledtank_Dwarf.base_stats["stamina"] = 500f;
        wheeledtank_Dwarf.base_stats["scale"] = 0.2f;
        wheeledtank_Dwarf.base_stats["size"] = 1f;
		wheeledtank_Dwarf.base_stats["mass"] = 1000f;
        wheeledtank_Dwarf.base_stats["health"] = 800f;
		wheeledtank_Dwarf.base_stats["speed"] = 70f;
		wheeledtank_Dwarf.base_stats["armor"] = 30f;
		wheeledtank_Dwarf.base_stats["attack_speed"] = 10f;
		wheeledtank_Dwarf.base_stats["damage"] = 40f;
		wheeledtank_Dwarf.base_stats["knockback"] = 0.01f;
		wheeledtank_Dwarf.base_stats["accuracy"] = 0.5f;
		wheeledtank_Dwarf.base_stats["targets"] = 1f;
		wheeledtank_Dwarf.base_stats["area_of_effect"] = 0.5f;
		wheeledtank_Dwarf.base_stats["range"] = 14f;
        wheeledtank_Dwarf.sound_hit = "event:/SFX/HIT/HitMetal";
        wheeledtank_Dwarf.default_attack = "crystaltankpew";
        wheeledtank_Dwarf.icon = "iconBoat";
		wheeledtank_Dwarf.inspect_avatar_scale = 2f;
        wheeledtank_Dwarf.shadow_texture = "unitShadow_6";
        wheeledtank_Dwarf.texture_asset = new ActorTextureSubAsset("actors/wheeledtank_Dwarf/");
        wheeledtank_Dwarf.special = true;
        wheeledtank_Dwarf.has_advanced_textures = false;
        wheeledtank_Dwarf.animation_walk = ActorAnimationSequences.walk_0_3;
        wheeledtank_Dwarf.animation_idle = ActorAnimationSequences.walk_0;
		wheeledtank_Dwarf.animation_swim = ActorAnimationSequences.swim_0_3;
            wheeledtank_Dwarf.name_locale = "Armored Car";
			wheeledtank_Dwarf.addTrait("dodge");
			wheeledtank_Dwarf.addTrait("dash");
			wheeledtank_Dwarf.addTrait("fire_proof");
            AssetManager.actor_library.add(wheeledtank_Dwarf);
			Localization.addLocalization(wheeledtank_Dwarf.name_locale, wheeledtank_Dwarf.name_locale);



	var modernhumvee_Gaia = AssetManager.actor_library.clone("modernhumvee_Gaia","baseWarUnit");
	modernhumvee_Gaia.die_in_lava = false;
        modernhumvee_Gaia.base_stats["mass_2"] = 200f;
        modernhumvee_Gaia.base_stats["stamina"] = 500f;
        modernhumvee_Gaia.base_stats["scale"] = 0.2f;
        modernhumvee_Gaia.base_stats["size"] = 1f;
		modernhumvee_Gaia.base_stats["mass"] = 1000f;
        modernhumvee_Gaia.base_stats["health"] = 300f;
		modernhumvee_Gaia.base_stats["speed"] = 70f;
		modernhumvee_Gaia.base_stats["armor"] = 20f;
		modernhumvee_Gaia.base_stats["attack_speed"] = 10000f;
		modernhumvee_Gaia.base_stats["damage"] = 10f;
		modernhumvee_Gaia.base_stats["knockback"] = 0.01f;
		modernhumvee_Gaia.base_stats["accuracy"] = 0.5f;
		modernhumvee_Gaia.base_stats["targets"] = 1f;
		modernhumvee_Gaia.base_stats["area_of_effect"] = 0.5f;
		modernhumvee_Gaia.base_stats["range"] = 14f;
        modernhumvee_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        modernhumvee_Gaia.default_attack = "gaiamachinegun";
        modernhumvee_Gaia.icon = "iconBoat";
        modernhumvee_Gaia.shadow_texture = "unitShadow_6";
        modernhumvee_Gaia.texture_asset = new ActorTextureSubAsset("actors/modernhumvee_Gaia/");
        modernhumvee_Gaia.special = true;
        modernhumvee_Gaia.has_advanced_textures = false;
        modernhumvee_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        modernhumvee_Gaia.animation_idle = ActorAnimationSequences.walk_0;
		modernhumvee_Gaia.animation_swim = ActorAnimationSequences.swim_0_3;
            modernhumvee_Gaia.name_locale = "Light Vehicle";
			modernhumvee_Gaia.addTrait("dodge");
			modernhumvee_Gaia.addTrait("dash");
			modernhumvee_Gaia.addTrait("fire_proof");
            AssetManager.actor_library.add(modernhumvee_Gaia);
			Localization.addLocalization(modernhumvee_Gaia.name_locale, modernhumvee_Gaia.name_locale);

	var howitzer_Gaia = AssetManager.actor_library.clone("howitzer_Gaia","baseWarUnit");
	howitzer_Gaia.die_in_lava = false;
        howitzer_Gaia.base_stats["mass_2"] = 200f;
        howitzer_Gaia.base_stats["stamina"] = 500f;
        howitzer_Gaia.base_stats["scale"] = 0.2f;
        howitzer_Gaia.base_stats["size"] = 1f;
		howitzer_Gaia.base_stats["mass"] = 1000f;
        howitzer_Gaia.base_stats["health"] = 200f;
		howitzer_Gaia.base_stats["speed"] = 20f;
		howitzer_Gaia.base_stats["armor"] = 20f;
		howitzer_Gaia.base_stats["attack_speed"] = 0.1f;
		howitzer_Gaia.base_stats["damage"] = 100f;
		howitzer_Gaia.base_stats["knockback"] = 3f;
		howitzer_Gaia.base_stats["accuracy"] = 0.3f;
		howitzer_Gaia.base_stats["targets"] = 3f;
		howitzer_Gaia.base_stats["area_of_effect"] = 4f;
		howitzer_Gaia.base_stats["range"] = 30f;
        howitzer_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        howitzer_Gaia.default_attack = "gaiaartilleryshell";
        howitzer_Gaia.icon = "iconBoat";
		howitzer_Gaia.inspect_avatar_scale = 2f;
        howitzer_Gaia.shadow_texture = "unitShadow_6";
        howitzer_Gaia.texture_asset = new ActorTextureSubAsset("actors/howitzer_Gaia/");
        howitzer_Gaia.special = true;
        howitzer_Gaia.has_advanced_textures = false;
        howitzer_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        howitzer_Gaia.animation_idle = ActorAnimationSequences.walk_0;
		howitzer_Gaia.animation_swim = ActorAnimationSequences.swim_0_3;
            howitzer_Gaia.name_locale = "Artillery";
			howitzer_Gaia.addTrait("fire_proof");
            AssetManager.actor_library.add(howitzer_Gaia);
			Localization.addLocalization(howitzer_Gaia.name_locale, howitzer_Gaia.name_locale);

	var Tank_Gaia = AssetManager.actor_library.clone("Tank_Gaia","baseWarUnit");
	Tank_Gaia.die_in_lava = false;
        Tank_Gaia.base_stats["mass_2"] = 200f;
        Tank_Gaia.base_stats["stamina"] = 500f;
        Tank_Gaia.base_stats["scale"] = 0.2f;
        Tank_Gaia.base_stats["size"] = 1f;
		Tank_Gaia.base_stats["mass"] = 1000f;
        Tank_Gaia.base_stats["health"] = 800f;
		Tank_Gaia.base_stats["speed"] = 40f;
		Tank_Gaia.base_stats["armor"] = 40f;
		Tank_Gaia.base_stats["attack_speed"] = 0.1f;
		Tank_Gaia.base_stats["damage"] = 50f;
		Tank_Gaia.base_stats["knockback"] = 4f;
		Tank_Gaia.base_stats["accuracy"] = 0.8f;
		Tank_Gaia.base_stats["targets"] = 2f;
		Tank_Gaia.base_stats["area_of_effect"] = 2f;
		Tank_Gaia.base_stats["range"] = 20f;
        Tank_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        Tank_Gaia.default_attack = "gaiatankpew";
        Tank_Gaia.icon = "iconBoat";
        Tank_Gaia.shadow_texture = "unitShadow_6";
        Tank_Gaia.texture_asset = new ActorTextureSubAsset("actors/Tank_Gaia/");
        Tank_Gaia.special = true;
		Tank_Gaia.inspect_avatar_scale = 2f;
        Tank_Gaia.has_advanced_textures = false;
        Tank_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        Tank_Gaia.animation_idle = ActorAnimationSequences.walk_0;
		Tank_Gaia.animation_swim = ActorAnimationSequences.swim_0_2;
            Tank_Gaia.name_locale = "Tank";
			Tank_Gaia.addTrait("fire_proof");
			Tank_Gaia.addTrait("block");
			Tank_Gaia.addTrait("deflect_projectile");
            AssetManager.actor_library.add(Tank_Gaia);
			Localization.addLocalization(Tank_Gaia.name_locale, Tank_Gaia.name_locale);

	var wheeledtank_Gaia = AssetManager.actor_library.clone("wheeledtank_Gaia","baseWarUnit");
	wheeledtank_Gaia.die_in_lava = false;
        wheeledtank_Gaia.base_stats["mass_2"] = 200f;
        wheeledtank_Gaia.base_stats["stamina"] = 500f;
        wheeledtank_Gaia.base_stats["scale"] = 0.2f;
        wheeledtank_Gaia.base_stats["size"] = 1f;
		wheeledtank_Gaia.base_stats["mass"] = 1000f;
        wheeledtank_Gaia.base_stats["health"] = 800f;
		wheeledtank_Gaia.base_stats["speed"] = 70f;
		wheeledtank_Gaia.base_stats["armor"] = 30f;
		wheeledtank_Gaia.base_stats["attack_speed"] = 10f;
		wheeledtank_Gaia.base_stats["damage"] = 40f;
		wheeledtank_Gaia.base_stats["knockback"] = 0.01f;
		wheeledtank_Gaia.base_stats["accuracy"] = 0.5f;
		wheeledtank_Gaia.base_stats["targets"] = 1f;
		wheeledtank_Gaia.base_stats["area_of_effect"] = 0.5f;
		wheeledtank_Gaia.base_stats["range"] = 14f;
        wheeledtank_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        wheeledtank_Gaia.default_attack = "gaiatankpew";
        wheeledtank_Gaia.icon = "iconBoat";
		wheeledtank_Gaia.inspect_avatar_scale = 2f;
        wheeledtank_Gaia.shadow_texture = "unitShadow_6";
        wheeledtank_Gaia.texture_asset = new ActorTextureSubAsset("actors/wheeledtank_Gaia/");
        wheeledtank_Gaia.special = true;
        wheeledtank_Gaia.has_advanced_textures = false;
        wheeledtank_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        wheeledtank_Gaia.animation_idle = ActorAnimationSequences.walk_0;
		wheeledtank_Gaia.animation_swim = ActorAnimationSequences.swim_0_3;
            wheeledtank_Gaia.name_locale = "Armored Car";
			wheeledtank_Gaia.addTrait("dodge");
			wheeledtank_Gaia.addTrait("dash");
			wheeledtank_Gaia.addTrait("fire_proof");
            AssetManager.actor_library.add(wheeledtank_Gaia);
			Localization.addLocalization(wheeledtank_Gaia.name_locale, wheeledtank_Gaia.name_locale);

	var MissileSystem_Gaia = AssetManager.actor_library.clone("MissileSystem_Gaia","baseWarUnit");
	MissileSystem_Gaia.die_in_lava = false;
        MissileSystem_Gaia.base_stats["mass_2"] = 200f;
        MissileSystem_Gaia.base_stats["stamina"] = 500f;
        MissileSystem_Gaia.base_stats["scale"] = 0.2f;
        MissileSystem_Gaia.base_stats["size"] = 1f;
		MissileSystem_Gaia.base_stats["mass"] = 1000f;
        MissileSystem_Gaia.base_stats["health"] = 300f;
		MissileSystem_Gaia.base_stats["speed"] = 20f;
		MissileSystem_Gaia.base_stats["armor"] = 10f;
		MissileSystem_Gaia.base_stats["attack_speed"] = 0.1f;
		MissileSystem_Gaia.base_stats["damage"] = 30f;
		MissileSystem_Gaia.base_stats["knockback"] = 4f;
		MissileSystem_Gaia.base_stats["accuracy"] = 0.1f;
		MissileSystem_Gaia.base_stats["targets"] = 3f;
		MissileSystem_Gaia.base_stats["area_of_effect"] = 4f;
		MissileSystem_Gaia.base_stats["range"] = 100f;
		MissileSystem_Gaia.inspect_avatar_scale = 2f;
        MissileSystem_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        MissileSystem_Gaia.default_attack = "MissileSystemGaia";
        MissileSystem_Gaia.icon = "iconBoat";
        MissileSystem_Gaia.shadow_texture = "unitShadow_6";
        MissileSystem_Gaia.texture_asset = new ActorTextureSubAsset("actors/MissileSystem_Gaia/");
        MissileSystem_Gaia.special = true;
        MissileSystem_Gaia.has_advanced_textures = false;
        MissileSystem_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        MissileSystem_Gaia.animation_idle = Vehicles.idle_0;
		MissileSystem_Gaia.animation_swim = ActorAnimationSequences.swim_0_3;
            MissileSystem_Gaia.name_locale = "Missile System";
			MissileSystem_Gaia.addTrait("fire_proof");
            AssetManager.actor_library.add(MissileSystem_Gaia);
			Localization.addLocalization(MissileSystem_Gaia.name_locale, MissileSystem_Gaia.name_locale);

	var supporttruck_Gaia = AssetManager.actor_library.clone("supporttruck_Gaia","baseWarUnit");
	supporttruck_Gaia.die_in_lava = false;
        supporttruck_Gaia.base_stats["mass_2"] = 200f;
        supporttruck_Gaia.base_stats["stamina"] = 500f;
        supporttruck_Gaia.base_stats["scale"] = 0.2f;
        supporttruck_Gaia.base_stats["size"] = 1f;
		supporttruck_Gaia.base_stats["mass"] = 1000f;
        supporttruck_Gaia.base_stats["health"] = 300f;
		supporttruck_Gaia.base_stats["speed"] = 20f;
		supporttruck_Gaia.base_stats["armor"] = 10f;
		supporttruck_Gaia.base_stats["attack_speed"] = 0.1f;
		supporttruck_Gaia.base_stats["damage"] = 30f;
		supporttruck_Gaia.base_stats["knockback"] = 4f;
		supporttruck_Gaia.base_stats["accuracy"] = 0.1f;
		supporttruck_Gaia.base_stats["targets"] = 3f;
		supporttruck_Gaia.base_stats["area_of_effect"] = 4f;
		supporttruck_Gaia.base_stats["range"] = 100f;
        supporttruck_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        supporttruck_Gaia.default_attack = "base_attack";
        supporttruck_Gaia.icon = "iconBoat";
        supporttruck_Gaia.shadow_texture = "unitShadow_6";
		supporttruck_Gaia.inspect_avatar_scale = 1f;
        supporttruck_Gaia.texture_asset = new ActorTextureSubAsset("actors/supporttruck_Gaia/");
        supporttruck_Gaia.special = true;
        supporttruck_Gaia.has_advanced_textures = false;
        supporttruck_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        supporttruck_Gaia.animation_idle = ActorAnimationSequences.walk_0;
		supporttruck_Gaia.animation_swim = ActorAnimationSequences.swim_0_3;
            supporttruck_Gaia.name_locale = "Support Unit";
            supporttruck_Gaia.skip_fight_logic = true;
			supporttruck_Gaia.addTrait("fire_proof");
			   supporttruck_Gaia.job = AssetLibrary<ActorAsset>.a<string>("decision");
           supporttruck_Gaia.addDecision("check_swearing");
supporttruck_Gaia.addDecision("warrior_try_join_army_group");
supporttruck_Gaia.addDecision("city_walking_to_danger_zone");
supporttruck_Gaia.addDecision("check_cure");
supporttruck_Gaia.addDecision("warrior_army_leader_move_random");
supporttruck_Gaia.addDecision("check_heal");
supporttruck_Gaia.addDecision("warrior_army_follow_leader");
supporttruck_Gaia.addDecision("warrior_random_move");
supporttruck_Gaia.addDecision("check_warrior_transport");
supporttruck_Gaia.addDecision("swim_to_island");
            AssetManager.actor_library.add(supporttruck_Gaia);
			Localization.addLocalization(supporttruck_Gaia.name_locale, supporttruck_Gaia.name_locale);

		var Heli_Gaia = AssetManager.actor_library.clone("Heli_Gaia","baseWarUnit");
	Heli_Gaia.die_in_lava = false;
	Heli_Gaia.animation_speed_based_on_walk_speed = false;
        Heli_Gaia.base_stats["mass_2"] = 200f;
        Heli_Gaia.base_stats["stamina"] = 1000f;
        Heli_Gaia.base_stats["scale"] = 0.2f;
        Heli_Gaia.base_stats["size"] = 1f;
		Heli_Gaia.base_stats["mass"] = 1000f;
        Heli_Gaia.base_stats["health"] = 200f;
		Heli_Gaia.base_stats["speed"] = 60f;
		Heli_Gaia.base_stats["armor"] = 0f;
		Heli_Gaia.base_stats["attack_speed"] = 10000f;
		Heli_Gaia.base_stats["damage"] = 20f;
		Heli_Gaia.base_stats["knockback"] = 0.01f;
		Heli_Gaia.base_stats["accuracy"] = 0.7f;
		Heli_Gaia.base_stats["targets"] = 1f;
		Heli_Gaia.base_stats["area_of_effect"] = 0.5f;
		Heli_Gaia.base_stats["range"] = 14f;
        Heli_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        Heli_Gaia.default_attack = "gaiamachinegun";
        Heli_Gaia.icon = "iconBoat";
        Heli_Gaia.shadow_texture = "unitShadow_6";
        Heli_Gaia.texture_asset = new ActorTextureSubAsset("actors/Heli_Gaia/");
        Heli_Gaia.special = true;
        Heli_Gaia.has_advanced_textures = false;
        Heli_Gaia.animation_walk = ActorAnimationSequences.walk_0_3;
        Heli_Gaia.animation_idle = ActorAnimationSequences.walk_0_3;
		Heli_Gaia.animation_swim = ActorAnimationSequences.walk_0_3;
            Heli_Gaia.name_locale = "Helicopter";
			Heli_Gaia.addTrait("fire_proof");
            Heli_Gaia.addTrait("freeze_proof");
			Heli_Gaia.flying = true;
			Heli_Gaia.very_high_flyer = true;
			Heli_Gaia.die_on_blocks = false;
			Heli_Gaia.inspect_avatar_scale = 0.5f;
			Heli_Gaia.ignore_blocks = true;
            AssetManager.actor_library.add(Heli_Gaia);
			Localization.addLocalization(Heli_Gaia.name_locale, Heli_Gaia.name_locale);

		var Bomber_Gaia = AssetManager.actor_library.clone("Bomber_Gaia","baseWarUnit");
	Bomber_Gaia.die_in_lava = false;
	Bomber_Gaia.animation_speed_based_on_walk_speed = false;
        Bomber_Gaia.base_stats["mass_2"] = 200f;
        Bomber_Gaia.base_stats["stamina"] = 1000f;
        Bomber_Gaia.base_stats["scale"] = 0.2f;
        Bomber_Gaia.base_stats["size"] = 1f;
		Bomber_Gaia.base_stats["mass"] = 1000f;
        Bomber_Gaia.base_stats["health"] = 400f;
		Bomber_Gaia.base_stats["speed"] = 30f;
		Bomber_Gaia.base_stats["armor"] = 0f;
		Bomber_Gaia.base_stats["attack_speed"] = 0.3f;
		Bomber_Gaia.base_stats["damage"] = 200f;
		Bomber_Gaia.base_stats["knockback"] = 2f;
		Bomber_Gaia.base_stats["accuracy"] = 0.7f;
		Bomber_Gaia.base_stats["targets"] = 5f;
		Bomber_Gaia.base_stats["area_of_effect"] = 0.5f;
		Bomber_Gaia.base_stats["range"] = 1f;
        Bomber_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        Bomber_Gaia.default_attack = "BomberAttackGaia";
        Bomber_Gaia.icon = "iconBoat";
        Bomber_Gaia.shadow_texture = "unitShadow_6";
        Bomber_Gaia.texture_asset = new ActorTextureSubAsset("actors/Bomber_Gaia/");
        Bomber_Gaia.special = true;
        Bomber_Gaia.can_flip = false;
        Bomber_Gaia.has_advanced_textures = false;
        Bomber_Gaia.animation_walk = Vehicles.idle_0_19;
        Bomber_Gaia.animation_idle = Vehicles.idle_0_19;
		Bomber_Gaia.animation_swim = Vehicles.idle_0_19;
            Bomber_Gaia.name_locale = "Bomber";
			Bomber_Gaia.addTrait("fire_proof");
            Bomber_Gaia.addTrait("freeze_proof");
			Bomber_Gaia.flying = true;
			Bomber_Gaia.very_high_flyer = true;
			Bomber_Gaia.die_on_blocks = false;
			Bomber_Gaia.ignore_blocks = true;
			Bomber_Gaia.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(Bomber_Gaia);
			Localization.addLocalization(Bomber_Gaia.name_locale, Bomber_Gaia.name_locale);

	var FighterJet_Gaia = AssetManager.actor_library.clone("FighterJet_Gaia","baseWarUnit");
	FighterJet_Gaia.die_in_lava = false;
	FighterJet_Gaia.animation_speed_based_on_walk_speed = false;
        FighterJet_Gaia.base_stats["mass_2"] = 200f;
        FighterJet_Gaia.base_stats["stamina"] = 1000f;
        FighterJet_Gaia.base_stats["scale"] = 0.2f;
        FighterJet_Gaia.base_stats["size"] = 1f;
		FighterJet_Gaia.base_stats["mass"] = 1000f;
        FighterJet_Gaia.base_stats["health"] = 400f;
		FighterJet_Gaia.base_stats["speed"] = 30f;
		FighterJet_Gaia.base_stats["armor"] = 0f;
		FighterJet_Gaia.base_stats["attack_speed"] = 0.3f;
		FighterJet_Gaia.base_stats["damage"] = 100f;
		FighterJet_Gaia.base_stats["knockback"] = 2f;
		FighterJet_Gaia.base_stats["accuracy"] = 0.7f;
		FighterJet_Gaia.base_stats["targets"] = 1f;
		FighterJet_Gaia.base_stats["area_of_effect"] = 0.5f;
		FighterJet_Gaia.base_stats["range"] = 6f;
		FighterJet_Gaia.inspect_avatar_scale = 0.5f;
        FighterJet_Gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        FighterJet_Gaia.default_attack = "fighterattackGaia";
        FighterJet_Gaia.icon = "iconBoat";
        FighterJet_Gaia.shadow_texture = "unitShadow_6";
        FighterJet_Gaia.texture_asset = new ActorTextureSubAsset("actors/FighterJet_Gaia/");
        FighterJet_Gaia.special = true;
        FighterJet_Gaia.can_flip = false;
        FighterJet_Gaia.has_advanced_textures = false;
        FighterJet_Gaia.animation_walk = Vehicles.idle_0_7;
        FighterJet_Gaia.animation_idle = Vehicles.idle_0_7;
		FighterJet_Gaia.animation_swim = Vehicles.idle_0_7;
            FighterJet_Gaia.name_locale = "Fighter Jet";
			FighterJet_Gaia.addTrait("fire_proof");
            FighterJet_Gaia.addTrait("freeze_proof");
			FighterJet_Gaia.flying = true;
			FighterJet_Gaia.very_high_flyer = true;
			FighterJet_Gaia.die_on_blocks = false;
			FighterJet_Gaia.ignore_blocks = true;
            AssetManager.actor_library.add(FighterJet_Gaia);
			Localization.addLocalization(FighterJet_Gaia.name_locale, FighterJet_Gaia.name_locale);


            ////////////////////////////Special Races/////////////////////////////////
            	var demonscorpion = AssetManager.actor_library.clone("demonscorpion","baseWarUnit");
	demonscorpion.die_in_lava = false;
        demonscorpion.base_stats["mass_2"] = 600f;
        demonscorpion.base_stats["stamina"] = 500f;
        demonscorpion.base_stats["scale"] = 0.2f;
        demonscorpion.base_stats["size"] = 1f;
		demonscorpion.base_stats["mass"] = 1000f;
        demonscorpion.base_stats["health"] = 300f;
		demonscorpion.base_stats["speed"] = 60f;
		demonscorpion.base_stats["armor"] = 20f;
		demonscorpion.base_stats["attack_speed"] = 10f;
		demonscorpion.base_stats["damage"] = 30f;
		demonscorpion.base_stats["knockback"] = 0.01f;
		demonscorpion.base_stats["accuracy"] = 0.5f;
		demonscorpion.base_stats["targets"] = 1f;
		demonscorpion.base_stats["area_of_effect"] = 0.5f;
		demonscorpion.base_stats["range"] = 1f;
        demonscorpion.sound_hit = "event:/SFX/HIT/HitFlesh";
        demonscorpion.default_attack = "fire_hands";
        demonscorpion.icon = "iconBoat";
        demonscorpion.shadow_texture = "unitShadow_6";
        demonscorpion.texture_asset = new ActorTextureSubAsset("actors/demonscorpion/");
        demonscorpion.special = true;
        demonscorpion.has_advanced_textures = false;
        demonscorpion.animation_walk = ActorAnimationSequences.walk_0_2;
        demonscorpion.animation_idle = Vehicles.idle_0_2;
		demonscorpion.animation_swim = ActorAnimationSequences.swim_0_2;
            demonscorpion.name_locale = "Demon Scorpion";
			demonscorpion.addTrait("poisonous");
			demonscorpion.addTrait("dash");
			demonscorpion.addTrait("fire_proof");
            demonscorpion.addTrait("burning_feet");
            demonscorpion.addTrait("evil");
            AssetManager.actor_library.add(demonscorpion);
			Localization.addLocalization(demonscorpion.name_locale, demonscorpion.name_locale);

	var demoncroc = AssetManager.actor_library.clone("demoncroc","baseWarUnit");
	demoncroc.die_in_lava = false;
        demoncroc.base_stats["mass_2"] = 600f;
        demoncroc.base_stats["stamina"] = 500f;
        demoncroc.base_stats["scale"] = 0.2f;
        demoncroc.base_stats["size"] = 1f;
		demoncroc.base_stats["mass"] = 1000f;
        demoncroc.base_stats["health"] = 300f;
		demoncroc.base_stats["speed"] = 40f;
		demoncroc.base_stats["armor"] = 40f;
		demoncroc.base_stats["attack_speed"] = 0.1f;
		demoncroc.base_stats["damage"] = 300f;
		demoncroc.base_stats["knockback"] = 4f;
		demoncroc.base_stats["accuracy"] = 0.8f;
		demoncroc.base_stats["targets"] = 2f;
		demoncroc.base_stats["area_of_effect"] = 2f;
		demoncroc.base_stats["range"] = 20f;
        demoncroc.sound_hit = "event:/SFX/HIT/HitFlesh";
        demoncroc.default_attack = "hordetankpew";
        demoncroc.icon = "iconBoat";
        demoncroc.shadow_texture = "unitShadow_6";
        demoncroc.texture_asset = new ActorTextureSubAsset("actors/demoncroc/");
        demoncroc.special = true;
		demoncroc.inspect_avatar_scale = 2f;
        demoncroc.has_advanced_textures = false;
        demoncroc.animation_walk = ActorAnimationSequences.walk_0_3;
        demoncroc.animation_idle = ActorAnimationSequences.walk_0;
		demoncroc.animation_swim = ActorAnimationSequences.swim_0_3;
            demoncroc.name_locale = "Demon Crocodile";
			demoncroc.addTrait("fire_proof");
			demoncroc.addTrait("block");
			demoncroc.addTrait("deflect_projectile");
            demoncroc.addTrait("dash");
            demoncroc.addTrait("burning_feet");
            demoncroc.addTrait("evil");
            AssetManager.actor_library.add(demoncroc);
			Localization.addLocalization(demoncroc.name_locale, demoncroc.name_locale);

	var demongolem = AssetManager.actor_library.clone("demongolem","baseWarUnit");
	demongolem.die_in_lava = false;
        demongolem.base_stats["mass_2"] = 600f;
        demongolem.base_stats["stamina"] = 500f;
        demongolem.base_stats["scale"] = 0.2f;
        demongolem.base_stats["size"] = 1f;
		demongolem.base_stats["mass"] = 1000f;
        demongolem.base_stats["health"] = 666f;
		demongolem.base_stats["speed"] = 30f;
		demongolem.base_stats["armor"] = 50f;
		demongolem.base_stats["attack_speed"] = 0.1f;
		demongolem.base_stats["damage"] = 230f;
		demongolem.base_stats["knockback"] = 4f;
		demongolem.base_stats["accuracy"] = 0.1f;
		demongolem.base_stats["targets"] = 2f;
		demongolem.base_stats["area_of_effect"] = 4f;
		demongolem.base_stats["range"] = 1f;
		demongolem.inspect_avatar_scale = 2f;
        demongolem.sound_hit = "event:/SFX/HIT/HitFlesh";
        demongolem.default_attack = "fire_hands";
        demongolem.icon = "iconBoat";
        demongolem.shadow_texture = "unitShadow_6";
        demongolem.texture_asset = new ActorTextureSubAsset("actors/demongolem/");
        demongolem.special = true;
        demongolem.has_advanced_textures = false;
        demongolem.animation_walk = ActorAnimationSequences.walk_0_3;
        demongolem.animation_idle = ActorAnimationSequences.walk_0;
		demongolem.animation_swim = ActorAnimationSequences.swim_0_3;
            demongolem.name_locale = "Demon Golem";
			demongolem.addTrait("fire_proof");
            demongolem.addTrait("block");
			demongolem.addTrait("deflect_projectile");
            demongolem.addTrait("dash");
            demongolem.addTrait("burning_feet");
            demongolem.addTrait("evil");
            AssetManager.actor_library.add(demongolem);
			Localization.addLocalization(demongolem.name_locale, demongolem.name_locale);

		var demonwyvern = AssetManager.actor_library.clone("demonwyvern","baseWarUnit");
	demonwyvern.die_in_lava = false;
	demonwyvern.animation_speed_based_on_walk_speed = false;
        demonwyvern.base_stats["mass_2"] = 600f;
        demonwyvern.base_stats["stamina"] = 1000f;
        demonwyvern.base_stats["scale"] = 0.2f;
        demonwyvern.base_stats["size"] = 1f;
		demonwyvern.base_stats["mass"] = 1000f;
        demonwyvern.base_stats["health"] = 100f;
		demonwyvern.base_stats["speed"] = 60f;
		demonwyvern.base_stats["armor"] = 0f;
		demonwyvern.base_stats["attack_speed"] = 10f;
		demonwyvern.base_stats["damage"] = 30f;
		demonwyvern.base_stats["knockback"] = 2f;
		demonwyvern.base_stats["accuracy"] = 0.7f;
		demonwyvern.base_stats["targets"] = 1f;
		demonwyvern.base_stats["area_of_effect"] = 0.5f;
		demonwyvern.base_stats["range"] = 20f;
        demonwyvern.sound_hit = "event:/SFX/HIT/HitFlesh";
        demonwyvern.default_attack = "hordetankpew";
        demonwyvern.icon = "iconBoat";
        demonwyvern.shadow_texture = "unitShadow_6";
        demonwyvern.texture_asset = new ActorTextureSubAsset("actors/demonwyvern/");
        demonwyvern.special = true;
        demonwyvern.has_advanced_textures = false;
        demonwyvern.animation_walk = Vehicles.walk_0_5;
        demonwyvern.animation_idle = Vehicles.idle_0_5;
		demonwyvern.animation_swim = Vehicles.walk_0_5;
            demonwyvern.name_locale = "Wyvern";
			demonwyvern.addTrait("fire_proof");
            demonwyvern.addTrait("freeze_proof");
            demonwyvern.addTrait("block");
			demonwyvern.addTrait("deflect_projectile");
            demonwyvern.addTrait("dash");
            demonwyvern.addTrait("burning_feet");
            demonwyvern.addTrait("evil");
			demonwyvern.flying = true;
			demonwyvern.very_high_flyer = true;
			demonwyvern.die_on_blocks = false;
			demonwyvern.inspect_avatar_scale = 0.5f;
			demonwyvern.ignore_blocks = true;
            AssetManager.actor_library.add(demonwyvern);
			Localization.addLocalization(demonwyvern.name_locale, demonwyvern.name_locale);

		var Bomber_Demon = AssetManager.actor_library.clone("Bomber_Demon","baseWarUnit");
	Bomber_Demon.die_in_lava = false;
	Bomber_Demon.animation_speed_based_on_walk_speed = false;
        Bomber_Demon.base_stats["mass_2"] = 600f;
        Bomber_Demon.base_stats["stamina"] = 1000f;
        Bomber_Demon.base_stats["scale"] = 0.2f;
        Bomber_Demon.base_stats["size"] = 1f;
		Bomber_Demon.base_stats["mass"] = 1000f;
        Bomber_Demon.base_stats["health"] = 400f;
		Bomber_Demon.base_stats["speed"] = 30f;
		Bomber_Demon.base_stats["armor"] = 0f;
		Bomber_Demon.base_stats["attack_speed"] = 0.3f;
		Bomber_Demon.base_stats["damage"] = 100f;
		Bomber_Demon.base_stats["knockback"] = 4f;
		Bomber_Demon.base_stats["accuracy"] = 0.7f;
		Bomber_Demon.base_stats["targets"] = 10f;
		Bomber_Demon.base_stats["area_of_effect"] = 5f;
		Bomber_Demon.base_stats["range"] = 10f;
        Bomber_Demon.sound_hit = "event:/SFX/HIT/HitFlesh";
        Bomber_Demon.default_attack = "hordetankpew";
        Bomber_Demon.icon = "iconBoat";
        Bomber_Demon.shadow_texture = "unitShadow_6";
        Bomber_Demon.texture_asset = new ActorTextureSubAsset("actors/Bomber_Demon/");
        Bomber_Demon.special = true;
        Bomber_Demon.can_flip = false;
        Bomber_Demon.has_advanced_textures = false;
        Bomber_Demon.animation_walk = Vehicles.idle_0_13;
        Bomber_Demon.animation_idle = Vehicles.idle_0_13;
		Bomber_Demon.animation_swim = Vehicles.idle_0_13;
            Bomber_Demon.name_locale = "Dragon";
			Bomber_Demon.addTrait("fire_proof");
            Bomber_Demon.addTrait("freeze_proof");
            Bomber_Demon.addTrait("block");
			Bomber_Demon.addTrait("deflect_projectile");
            Bomber_Demon.addTrait("dash");
            Bomber_Demon.addTrait("burning_feet");
            Bomber_Demon.addTrait("evil");
			Bomber_Demon.flying = true;
			Bomber_Demon.very_high_flyer = true;
			Bomber_Demon.die_on_blocks = false;
			Bomber_Demon.ignore_blocks = true;
			Bomber_Demon.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(Bomber_Demon);
			Localization.addLocalization(Bomber_Demon.name_locale, Bomber_Demon.name_locale);

var demonreaver = AssetManager.actor_library.clone("demonreaver","baseWarUnit");
	demonreaver.die_in_lava = false;
        demonreaver.base_stats["mass_2"] = 600f;
        demonreaver.base_stats["stamina"] = 500f;
        demonreaver.base_stats["scale"] = 0.3f;
        demonreaver.base_stats["size"] = 1f;
		demonreaver.base_stats["mass"] = 1000f;
        demonreaver.base_stats["health"] = 666f;
		demonreaver.base_stats["speed"] = 20f;
		demonreaver.base_stats["armor"] = 20f;
		demonreaver.base_stats["attack_speed"] = 0.1f;
		demonreaver.base_stats["damage"] = 100f;
		demonreaver.base_stats["knockback"] = 3f;
		demonreaver.base_stats["accuracy"] = 0.3f;
		demonreaver.base_stats["targets"] = 3f;
		demonreaver.base_stats["area_of_effect"] = 4f;
		demonreaver.base_stats["range"] = 1f;
        demonreaver.sound_hit = "event:/SFX/HIT/HitFlesh";
        demonreaver.default_attack = "iceartilleryshell";
        demonreaver.icon = "iconBoat";
		demonreaver.inspect_avatar_scale = 2f;
        demonreaver.shadow_texture = "unitShadow_6";
        demonreaver.texture_asset = new ActorTextureSubAsset("actors/demonreaver/");
        demonreaver.special = true;
        demonreaver.has_advanced_textures = false;
        demonreaver.animation_walk = ActorAnimationSequences.walk_0_3;
        demonreaver.animation_idle = ActorAnimationSequences.walk_0;
		demonreaver.animation_swim = ActorAnimationSequences.swim_0_3;
            demonreaver.name_locale = "Demon Reaver";
			demonreaver.addTrait("fire_proof");
            demonreaver.addTrait("block");
			demonreaver.addTrait("deflect_projectile");
            demonreaver.addTrait("dash");
            demonreaver.addTrait("burning_feet");
            demonreaver.addTrait("evil");
            AssetManager.actor_library.add(demonreaver);
			Localization.addLocalization(demonreaver.name_locale, demonreaver.name_locale);


	var xenorailgun = AssetManager.actor_library.clone("xenorailgun","baseWarUnit");
	xenorailgun.die_in_lava = false;
        xenorailgun.base_stats["mass_2"] = 200f;
        xenorailgun.base_stats["stamina"] = 500f;
        xenorailgun.base_stats["scale"] = 0.2f;
        xenorailgun.base_stats["size"] = 1f;
		xenorailgun.base_stats["mass"] = 1000f;
        xenorailgun.base_stats["health"] = 1000f;
		xenorailgun.base_stats["speed"] = 40f;
		xenorailgun.base_stats["armor"] = 40f;
		xenorailgun.base_stats["attack_speed"] = 0.1f;
		xenorailgun.base_stats["damage"] = 100f;
		xenorailgun.base_stats["knockback"] = 4f;
		xenorailgun.base_stats["accuracy"] = 0.8f;
		xenorailgun.base_stats["targets"] = 2f;
		xenorailgun.base_stats["area_of_effect"] = 2f;
		xenorailgun.base_stats["range"] = 20f;
        xenorailgun.sound_hit = "event:/SFX/HIT/HitMetal";
        xenorailgun.default_attack = "XenoPew";
        xenorailgun.icon = "iconBoat";
        xenorailgun.shadow_texture = "unitShadow_6";
        xenorailgun.texture_asset = new ActorTextureSubAsset("actors/xenorailgun/");
        xenorailgun.special = true;
		xenorailgun.inspect_avatar_scale = 2f;
        xenorailgun.has_advanced_textures = false;
        xenorailgun.animation_walk = ActorAnimationSequences.walk_0_2;
        xenorailgun.animation_idle = ActorAnimationSequences.walk_0;
		xenorailgun.animation_swim = ActorAnimationSequences.swim_0_2;
            xenorailgun.name_locale = "Tank";
			xenorailgun.addTrait("fire_proof");
			xenorailgun.addTrait("block");
			xenorailgun.addTrait("deflect_projectile");
            xenorailgun.actor_size = ActorSize.S17_Dragon;
            xenorailgun.addTrait("fat");
            xenorailgun.addTrait("acid_blood");
            xenorailgun.addTrait("acid_proof");
            AssetManager.actor_library.add(xenorailgun);
			Localization.addLocalization(xenorailgun.name_locale, xenorailgun.name_locale);

	var xenolevitank = AssetManager.actor_library.clone("xenolevitank","baseWarUnit");
	xenolevitank.die_in_lava = false;
        xenolevitank.base_stats["mass_2"] = 200f;
        xenolevitank.base_stats["stamina"] = 500f;
        xenolevitank.base_stats["scale"] = 0.2f;
        xenolevitank.base_stats["size"] = 1f;
		xenolevitank.base_stats["mass"] = 1000f;
        xenolevitank.base_stats["health"] = 800f;
		xenolevitank.base_stats["speed"] = 70f;
		xenolevitank.base_stats["armor"] = 30f;
		xenolevitank.base_stats["attack_speed"] = 10f;
		xenolevitank.base_stats["damage"] = 40f;
		xenolevitank.base_stats["knockback"] = 0.01f;
		xenolevitank.base_stats["accuracy"] = 0.5f;
		xenolevitank.base_stats["targets"] = 1f;
		xenolevitank.base_stats["area_of_effect"] = 0.5f;
		xenolevitank.base_stats["range"] = 14f;
        xenolevitank.sound_hit = "event:/SFX/HIT/HitMetal";
        xenolevitank.default_attack = "XenoPew";
        xenolevitank.icon = "iconBoat";
		xenolevitank.inspect_avatar_scale = 2f;
        xenolevitank.shadow_texture = "unitShadow_6";
        xenolevitank.texture_asset = new ActorTextureSubAsset("actors/xenolevitank/");
        xenolevitank.special = true;
        xenolevitank.has_advanced_textures = false;
        xenolevitank.animation_walk = ActorAnimationSequences.idle_0_3;
        xenolevitank.animation_idle = ActorAnimationSequences.idle_0_3;
		xenolevitank.animation_swim = ActorAnimationSequences.idle_0_3;
            xenolevitank.name_locale = "Armored Car";
			xenolevitank.addTrait("dodge");
			xenolevitank.addTrait("dash");
			xenolevitank.addTrait("fire_proof");
            xenolevitank.actor_size = ActorSize.S17_Dragon;
            xenolevitank.addTrait("fat");
            xenolevitank.addTrait("acid_blood");
            xenolevitank.addTrait("acid_proof");
            AssetManager.actor_library.add(xenolevitank);
			Localization.addLocalization(xenolevitank.name_locale, xenolevitank.name_locale);

				var xenotripod = AssetManager.actor_library.clone("xenotripod","baseWarUnit");
	xenotripod.die_in_lava = false;
        xenotripod.base_stats["mass_2"] = 200f;
        xenotripod.base_stats["stamina"] = 500f;
        xenotripod.base_stats["scale"] = 0.2f;
        xenotripod.base_stats["size"] = 1f;
		xenotripod.base_stats["mass"] = 1000f;
        xenotripod.base_stats["health"] = 2000f;
		xenotripod.base_stats["speed"] = 20f;
		xenotripod.base_stats["armor"] = 10f;
		xenotripod.base_stats["attack_speed"] = 0.1f;
		xenotripod.base_stats["damage"] = 300f;
		xenotripod.base_stats["knockback"] = 4f;
		xenotripod.base_stats["accuracy"] = 0.1f;
		xenotripod.base_stats["targets"] = 3f;
		xenotripod.base_stats["area_of_effect"] = 4f;
		xenotripod.base_stats["range"] = 8f;
		xenotripod.inspect_avatar_scale = 2f;
        xenotripod.sound_hit = "event:/SFX/HIT/HitMetal";
        xenotripod.default_attack = "XenoBeam";
        xenotripod.icon = "iconBoat";
        xenotripod.shadow_texture = "unitShadow_6";
        xenotripod.texture_asset = new ActorTextureSubAsset("actors/xenotripod/");
        xenotripod.special = true;
        xenotripod.has_advanced_textures = false;
        xenotripod.animation_walk = Vehicles.walk_0_5;
        xenotripod.animation_idle = Vehicles.idle_0;
		xenotripod.animation_swim = Vehicles.swim_0_5;
            xenotripod.name_locale = "Missile System";
			xenotripod.addTrait("fire_proof");
            xenotripod.actor_size = ActorSize.S17_Dragon;
            xenotripod.addTrait("fat");
            xenotripod.addTrait("acid_blood");
            xenotripod.addTrait("acid_proof");
            xenotripod.addTrait("bubble_defense");
            AssetManager.actor_library.add(xenotripod);
			Localization.addLocalization(xenotripod.name_locale, xenotripod.name_locale);

			var xenoUFO = AssetManager.actor_library.clone("xenoUFO","baseWarUnit");
	xenoUFO.die_in_lava = false;
	xenoUFO.animation_speed_based_on_walk_speed = false;
        xenoUFO.base_stats["mass_2"] = 200f;
        xenoUFO.base_stats["stamina"] = 1000f;
        xenoUFO.base_stats["scale"] = 0.2f;
        xenoUFO.base_stats["size"] = 1f;
		xenoUFO.base_stats["mass"] = 1000f;
        xenoUFO.base_stats["health"] = 200f;
		xenoUFO.base_stats["speed"] = 60f;
		xenoUFO.base_stats["armor"] = 0f;
		xenoUFO.base_stats["attack_speed"] = 100f;
		xenoUFO.base_stats["damage"] = 40f;
		xenoUFO.base_stats["knockback"] = 0.01f;
		xenoUFO.base_stats["accuracy"] = 0.7f;
		xenoUFO.base_stats["targets"] = 1f;
		xenoUFO.base_stats["area_of_effect"] = 0.5f;
		xenoUFO.base_stats["range"] = 14f;
        xenoUFO.sound_hit = "event:/SFX/HIT/HitMetal";
        xenoUFO.default_attack = "XenoPew";
        xenoUFO.icon = "iconBoat";
        xenoUFO.shadow_texture = "unitShadow_6";
        xenoUFO.texture_asset = new ActorTextureSubAsset("actors/xenoUFO/");
        xenoUFO.special = true;
        xenoUFO.has_advanced_textures = false;
        xenoUFO.animation_walk = ActorAnimationSequences.idle_0_3;
        xenoUFO.animation_idle = ActorAnimationSequences.idle_0_3;
		xenoUFO.animation_swim = ActorAnimationSequences.idle_0_3;
            xenoUFO.name_locale = "Helicopter";
			xenoUFO.addTrait("fire_proof");
            xenoUFO.addTrait("freeze_proof");
            xenoUFO.actor_size = ActorSize.S17_Dragon;
            xenoUFO.addTrait("fat");
            xenoUFO.addTrait("acid_blood");
            xenoUFO.addTrait("acid_proof");
			xenoUFO.flying = true;
			xenoUFO.very_high_flyer = true;
			xenoUFO.die_on_blocks = false;
			xenoUFO.inspect_avatar_scale = 0.5f;
			xenoUFO.ignore_blocks = true;
            AssetManager.actor_library.add(xenoUFO);
			Localization.addLocalization(xenoUFO.name_locale, xenoUFO.name_locale);

		var xenoUFObomber = AssetManager.actor_library.clone("xenoUFObomber","baseWarUnit");
	xenoUFObomber.die_in_lava = false;
	xenoUFObomber.animation_speed_based_on_walk_speed = false;
        xenoUFObomber.base_stats["mass_2"] = 200f;
        xenoUFObomber.base_stats["stamina"] = 1000f;
        xenoUFObomber.base_stats["scale"] = 0.2f;
        xenoUFObomber.base_stats["size"] = 1f;
		xenoUFObomber.base_stats["mass"] = 1000f;
        xenoUFObomber.base_stats["health"] = 400f;
		xenoUFObomber.base_stats["speed"] = 30f;
		xenoUFObomber.base_stats["armor"] = 0f;
		xenoUFObomber.base_stats["attack_speed"] = 0.3f;
		xenoUFObomber.base_stats["damage"] = 200f;
		xenoUFObomber.base_stats["knockback"] = 2f;
		xenoUFObomber.base_stats["accuracy"] = 0.7f;
		xenoUFObomber.base_stats["targets"] = 5f;
		xenoUFObomber.base_stats["area_of_effect"] = 0.5f;
		xenoUFObomber.base_stats["range"] = 1f;
        xenoUFObomber.sound_hit = "event:/SFX/HIT/HitMetal";
        xenoUFObomber.default_attack = "XenoMegaBomb";
        xenoUFObomber.icon = "iconBoat";
        xenoUFObomber.shadow_texture = "unitShadow_6";
        xenoUFObomber.texture_asset = new ActorTextureSubAsset("actors/xenoUFObomber/");
        xenoUFObomber.special = true;
        xenoUFObomber.can_flip = false;
        xenoUFObomber.has_advanced_textures = false;
        xenoUFObomber.animation_walk = Vehicles.idle_0_8;
        xenoUFObomber.animation_idle = Vehicles.idle_0_8;
		xenoUFObomber.animation_swim = Vehicles.idle_0_8;
            xenoUFObomber.name_locale = "Bomber";
			xenoUFObomber.addTrait("fire_proof");
            xenoUFObomber.addTrait("freeze_proof");
            xenoUFObomber.actor_size = ActorSize.S17_Dragon;
            xenoUFObomber.addTrait("fat");
            xenoUFObomber.addTrait("acid_blood");
            xenoUFObomber.addTrait("acid_proof");
			xenoUFObomber.flying = true;
			xenoUFObomber.very_high_flyer = true;
			xenoUFObomber.die_on_blocks = false;
			xenoUFObomber.ignore_blocks = true;
			xenoUFObomber.inspect_avatar_scale = 0.5f;
            AssetManager.actor_library.add(xenoUFObomber);
			Localization.addLocalization(xenoUFObomber.name_locale, xenoUFObomber.name_locale);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////NAVAL UNITS FOR DOCKS :DDDDDDDDDDDD//////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	var CargoShip_alliance = AssetManager.actor_library.clone("CargoShip_alliance","$boat$");
	    CargoShip_alliance.id = "CargoShip_alliance";
		CargoShip_alliance.boat_type = "cargo_alliance_boat";
		CargoShip_alliance.can_be_inspected = false;
        CargoShip_alliance.skip_fight_logic = true;
		CargoShip_alliance.name_locale = "Cargo Ship";
		CargoShip_alliance.addDecision("boat_trading");
		CargoShip_alliance.addDecision("boat_transport_check");
		CargoShip_alliance.has_avatar_prefab = false;
		CargoShip_alliance.animation_speed_based_on_walk_speed = false;
		CargoShip_alliance.can_flip = true;
        CargoShip_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CargoShip_alliance.is_boat = true;
		CargoShip_alliance.die_in_lava = false;
		CargoShip_alliance.has_override_sprite = false;
	    CargoShip_alliance.has_override_avatar_frames = false;
		CargoShip_alliance.base_stats["mass_2"] = 3000f;
		CargoShip_alliance.base_stats["stamina"] = 1000f;
		CargoShip_alliance.base_stats["scale"] = 0.25f;
		CargoShip_alliance.base_stats["health"] = 2000f;
		CargoShip_alliance.base_stats["speed"] = 20f;
		CargoShip_alliance.base_stats["armor"] = 30f;
		CargoShip_alliance.base_stats["attack_speed"] = 0.3f;
		CargoShip_alliance.base_stats["damage"] = 100f;
		CargoShip_alliance.base_stats["knockback"] = 2f;
		CargoShip_alliance.base_stats["accuracy"] = 0.7f;
		CargoShip_alliance.base_stats["targets"] = 1f;
		CargoShip_alliance.base_stats["area_of_effect"] = 0.5f;
		CargoShip_alliance.base_stats["range"] = 6f;
		CargoShip_alliance.inspect_avatar_scale = 0.4f;
		CargoShip_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
		CargoShip_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingSpawn";
		CargoShip_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingIdleLoop";
		CargoShip_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingDeath";
		CargoShip_alliance.default_attack = "boat_cannonball";
		CargoShip_alliance.icon = "iconBoat";
		CargoShip_alliance.shadow_texture = "unitShadow_6";
		CargoShip_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		CargoShip_alliance.texture_asset = new ActorTextureSubAsset("actors/CargoShip_alliance/");
		CargoShip_alliance.special = true;
		CargoShip_alliance.has_advanced_textures = false;
		CargoShip_alliance.draw_boat_mark = true;
		CargoShip_alliance.actor_size = ActorSize.S16_Buffalo;
		CargoShip_alliance.animation_walk = ActorAnimationSequences.walk_0;
		CargoShip_alliance.animation_idle = ActorAnimationSequences.walk_0;
		CargoShip_alliance.animation_swim = ActorAnimationSequences.swim_0_2;
		CargoShip_alliance.addTrait("boat");
		CargoShip_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(CargoShip_alliance);
		Localization.addLocalization(CargoShip_alliance.name_locale, CargoShip_alliance.name_locale);


	var aDestroyer_alliance = AssetManager.actor_library.clone("aDestroyer_alliance","$boat$");
	    aDestroyer_alliance.id = "aDestroyer_alliance";
	    aDestroyer_alliance.can_be_inspected = false;
		aDestroyer_alliance.boat_type = "destroyer_a_alliance_boat";
		aDestroyer_alliance.name_locale = "Destroyer Ship";
		aDestroyer_alliance.addDecision("boat_transport_check");
		aDestroyer_alliance.has_avatar_prefab = false;
		aDestroyer_alliance.animation_speed_based_on_walk_speed = false;
		aDestroyer_alliance.can_flip = true;
        aDestroyer_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    aDestroyer_alliance.is_boat = true;
		aDestroyer_alliance.die_in_lava = false;
		aDestroyer_alliance.has_override_sprite = false;
	    aDestroyer_alliance.has_override_avatar_frames = false;
		aDestroyer_alliance.base_stats["mass_2"] = 3000f;
		aDestroyer_alliance.base_stats["stamina"] = 1000f;
		aDestroyer_alliance.base_stats["scale"] = 0.25f;
		aDestroyer_alliance.base_stats["health"] = 2000f;
		aDestroyer_alliance.base_stats["speed"] = 40f;
		aDestroyer_alliance.base_stats["armor"] = 30f;
		aDestroyer_alliance.base_stats["attack_speed"] = 0.3f;
		aDestroyer_alliance.base_stats["damage"] = 100f;
		aDestroyer_alliance.base_stats["knockback"] = 2f;
		aDestroyer_alliance.base_stats["accuracy"] = 0.7f;
		aDestroyer_alliance.base_stats["targets"] = 1f;
		aDestroyer_alliance.base_stats["area_of_effect"] = 0.5f;
		aDestroyer_alliance.base_stats["range"] = 20f;
		aDestroyer_alliance.inspect_avatar_scale = 0.4f;
		aDestroyer_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
        aDestroyer_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		aDestroyer_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		aDestroyer_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		aDestroyer_alliance.default_attack = "fighterattack";
		aDestroyer_alliance.icon = "iconBoat";
		aDestroyer_alliance.shadow_texture = "unitShadow_6";
		aDestroyer_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		aDestroyer_alliance.texture_asset = new ActorTextureSubAsset("actors/Destroyer_alliance/");
		aDestroyer_alliance.special = true;
		aDestroyer_alliance.has_advanced_textures = false;
		aDestroyer_alliance.draw_boat_mark = true;
		aDestroyer_alliance.actor_size = ActorSize.S16_Buffalo;
		aDestroyer_alliance.animation_walk = ActorAnimationSequences.walk_0;
		aDestroyer_alliance.animation_idle = ActorAnimationSequences.walk_0;
		aDestroyer_alliance.animation_swim = ActorAnimationSequences.swim_0_3;
		aDestroyer_alliance.addTrait("boat");
		aDestroyer_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(aDestroyer_alliance);
		Localization.addLocalization(aDestroyer_alliance.name_locale, aDestroyer_alliance.name_locale);

	var bDestroyer_alliance = AssetManager.actor_library.clone("bDestroyer_alliance","$boat$");
	    bDestroyer_alliance.id = "bDestroyer_alliance";
		bDestroyer_alliance.boat_type = "destroyer_b_alliance_boat";
		bDestroyer_alliance.can_be_inspected = false;
		bDestroyer_alliance.name_locale = "Destroyer Ship";
		bDestroyer_alliance.addDecision("boat_transport_check");
		bDestroyer_alliance.has_avatar_prefab = false;
		bDestroyer_alliance.animation_speed_based_on_walk_speed = false;
		bDestroyer_alliance.can_flip = true;
        bDestroyer_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    bDestroyer_alliance.is_boat = true;
		bDestroyer_alliance.die_in_lava = false;
		bDestroyer_alliance.has_override_sprite = false;
	    bDestroyer_alliance.has_override_avatar_frames = false;
		bDestroyer_alliance.base_stats["mass_2"] = 3000f;
		bDestroyer_alliance.base_stats["stamina"] = 1000f;
		bDestroyer_alliance.base_stats["scale"] = 0.25f;
		bDestroyer_alliance.base_stats["health"] = 2000f;
		bDestroyer_alliance.base_stats["speed"] = 40f;
		bDestroyer_alliance.base_stats["armor"] = 30f;
		bDestroyer_alliance.base_stats["attack_speed"] = 0.3f;
		bDestroyer_alliance.base_stats["damage"] = 100f;
		bDestroyer_alliance.base_stats["knockback"] = 2f;
		bDestroyer_alliance.base_stats["accuracy"] = 0.7f;
		bDestroyer_alliance.base_stats["targets"] = 1f;
		bDestroyer_alliance.base_stats["area_of_effect"] = 0.5f;
		bDestroyer_alliance.base_stats["range"] = 20f;
		bDestroyer_alliance.inspect_avatar_scale = 0.4f;
		bDestroyer_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
        bDestroyer_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		bDestroyer_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		bDestroyer_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		bDestroyer_alliance.default_attack = "fighterattack";
		bDestroyer_alliance.icon = "iconBoat";
		bDestroyer_alliance.shadow_texture = "unitShadow_6";
		bDestroyer_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		bDestroyer_alliance.texture_asset = new ActorTextureSubAsset("actors/Destroyer_alliance/");
		bDestroyer_alliance.special = true;
		bDestroyer_alliance.has_advanced_textures = false;
		bDestroyer_alliance.draw_boat_mark = true;
		bDestroyer_alliance.actor_size = ActorSize.S16_Buffalo;
		bDestroyer_alliance.animation_walk = ActorAnimationSequences.walk_0;
		bDestroyer_alliance.animation_idle = ActorAnimationSequences.walk_0;
		bDestroyer_alliance.animation_swim = ActorAnimationSequences.swim_0_3;
		bDestroyer_alliance.addTrait("boat");
		bDestroyer_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(bDestroyer_alliance);
		Localization.addLocalization(bDestroyer_alliance.name_locale, bDestroyer_alliance.name_locale);

        ///////jet attack for carrier/no spawn

	var CarrierVessel_alliance = AssetManager.actor_library.clone("CarrierVessel_alliance","$boat$");
	    CarrierVessel_alliance.id = "CarrierVessel_alliance";
		CarrierVessel_alliance.boat_type = "carrier_alliance_boat";
		CarrierVessel_alliance.name_locale = "Cargo Ship";
		CarrierVessel_alliance.can_be_inspected = false;
		CarrierVessel_alliance.addDecision("boat_trading");
		CarrierVessel_alliance.addDecision("boat_transport_check");
		CarrierVessel_alliance.has_avatar_prefab = false;
		CarrierVessel_alliance.animation_speed_based_on_walk_speed = false;
		CarrierVessel_alliance.can_flip = true;
        CarrierVessel_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CarrierVessel_alliance.is_boat = true;
		CarrierVessel_alliance.die_in_lava = false;
		CarrierVessel_alliance.has_override_sprite = false;
	    CarrierVessel_alliance.has_override_avatar_frames = false;
		CarrierVessel_alliance.base_stats["mass_2"] = 3000f;
		CarrierVessel_alliance.base_stats["stamina"] = 1000f;
		CarrierVessel_alliance.base_stats["scale"] = 0.25f;
		CarrierVessel_alliance.base_stats["health"] = 2000f;
		CarrierVessel_alliance.base_stats["speed"] = 20f;
		CarrierVessel_alliance.base_stats["armor"] = 30f;
		CarrierVessel_alliance.base_stats["attack_speed"] = 0.3f;
		CarrierVessel_alliance.base_stats["damage"] = 200f;
		CarrierVessel_alliance.base_stats["knockback"] = 2f;
		CarrierVessel_alliance.base_stats["accuracy"] = 0.7f;
		CarrierVessel_alliance.base_stats["targets"] = 1f;
		CarrierVessel_alliance.base_stats["area_of_effect"] = 0.5f;
		CarrierVessel_alliance.base_stats["range"] = 16f;
		CarrierVessel_alliance.inspect_avatar_scale = 0.4f;
		CarrierVessel_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
        CarrierVessel_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		CarrierVessel_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		CarrierVessel_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		CarrierVessel_alliance.default_attack = "AirstrikejetAttack_alliance";
		CarrierVessel_alliance.icon = "iconBoat";
		CarrierVessel_alliance.shadow_texture = "unitShadow_6";
		CarrierVessel_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		CarrierVessel_alliance.texture_asset = new ActorTextureSubAsset("actors/CarrierVessel_alliance/");
		CarrierVessel_alliance.special = true;
		CarrierVessel_alliance.has_advanced_textures = false;
		CarrierVessel_alliance.draw_boat_mark = true;
		CarrierVessel_alliance.actor_size = ActorSize.S16_Buffalo;
		CarrierVessel_alliance.animation_walk = ActorAnimationSequences.walk_0;
		CarrierVessel_alliance.animation_idle = ActorAnimationSequences.walk_0;
		CarrierVessel_alliance.animation_swim = ActorAnimationSequences.swim_0_3;
		CarrierVessel_alliance.addTrait("boat");
		CarrierVessel_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(CarrierVessel_alliance);
		Localization.addLocalization(CarrierVessel_alliance.name_locale, CarrierVessel_alliance.name_locale);

	var Submarine_alliance = AssetManager.actor_library.clone("Submarine_alliance","$boat$");
	    Submarine_alliance.id = "Submarine_alliance";
		Submarine_alliance.boat_type = "submarine_alliance_boat";
		Submarine_alliance.name_locale = "Cargo Ship";
		Submarine_alliance.can_be_inspected = false;
		Submarine_alliance.addDecision("boat_trading");
		Submarine_alliance.addDecision("boat_transport_check");
		Submarine_alliance.has_avatar_prefab = false;
		Submarine_alliance.animation_speed_based_on_walk_speed = false;
		Submarine_alliance.can_flip = true;
        Submarine_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    Submarine_alliance.is_boat = true;
		Submarine_alliance.die_in_lava = false;
		Submarine_alliance.has_override_sprite = false;
	    Submarine_alliance.has_override_avatar_frames = false;
		Submarine_alliance.base_stats["mass_2"] = 3000f;
		Submarine_alliance.base_stats["stamina"] = 1000f;
		Submarine_alliance.base_stats["scale"] = 0.25f;
		Submarine_alliance.base_stats["health"] = 2000f;
		Submarine_alliance.base_stats["speed"] = 60f;
		Submarine_alliance.base_stats["armor"] = 30f;
		Submarine_alliance.base_stats["attack_speed"] = 0.3f;
		Submarine_alliance.base_stats["damage"] = 300f;
		Submarine_alliance.base_stats["knockback"] = 2f;
		Submarine_alliance.base_stats["accuracy"] = 0.7f;
		Submarine_alliance.base_stats["targets"] = 1f;
		Submarine_alliance.base_stats["area_of_effect"] = 0.5f;
		Submarine_alliance.base_stats["range"] = 200f;
		Submarine_alliance.inspect_avatar_scale = 0.4f;
		Submarine_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
		Submarine_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		Submarine_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		Submarine_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		Submarine_alliance.default_attack = "MissileSystemmissile";
		Submarine_alliance.icon = "iconBoat";
		Submarine_alliance.shadow_texture = "unitShadow_6";
		Submarine_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		Submarine_alliance.texture_asset = new ActorTextureSubAsset("actors/Submarine_alliance/");
		Submarine_alliance.special = true;
		Submarine_alliance.has_advanced_textures = false;
		Submarine_alliance.draw_boat_mark = true;
		Submarine_alliance.actor_size = ActorSize.S16_Buffalo;
		Submarine_alliance.animation_walk = ActorAnimationSequences.walk_0;
		Submarine_alliance.animation_idle = ActorAnimationSequences.walk_0;
		Submarine_alliance.animation_swim = ActorAnimationSequences.swim_0_3;
		Submarine_alliance.addTrait("boat");
		Submarine_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(Submarine_alliance);
		Localization.addLocalization(Submarine_alliance.name_locale, Submarine_alliance.name_locale);

	var FishingBoat_alliance = AssetManager.actor_library.clone("FishingBoat_alliance","$boat$");
	    FishingBoat_alliance.id = "FishingBoat_alliance";
		FishingBoat_alliance.boat_type = "fishing_alliance_boat";
        FishingBoat_alliance.skip_fight_logic = true;
        FishingBoat_alliance.can_be_inspected = false;
		FishingBoat_alliance.name_locale = "Cargo Ship";
		FishingBoat_alliance.addDecision("boat_fishing");
		FishingBoat_alliance.has_avatar_prefab = false;
		FishingBoat_alliance.animation_speed_based_on_walk_speed = false;
		FishingBoat_alliance.can_flip = true;
        FishingBoat_alliance.check_flip = (BaseSimObject _, WorldTile _) => true;
	    FishingBoat_alliance.is_boat = true;
		FishingBoat_alliance.die_in_lava = false;
		FishingBoat_alliance.has_override_sprite = false;
	    FishingBoat_alliance.has_override_avatar_frames = false;
		FishingBoat_alliance.base_stats["mass_2"] = 3000f;
		FishingBoat_alliance.base_stats["stamina"] = 1000f;
		FishingBoat_alliance.base_stats["scale"] = 0.25f;
		FishingBoat_alliance.base_stats["health"] = 2000f;
		FishingBoat_alliance.base_stats["speed"] = 60f;
		FishingBoat_alliance.base_stats["armor"] = 30f;
		FishingBoat_alliance.base_stats["attack_speed"] = 0.3f;
		FishingBoat_alliance.base_stats["damage"] = 100f;
		FishingBoat_alliance.base_stats["knockback"] = 2f;
		FishingBoat_alliance.base_stats["accuracy"] = 0.7f;
		FishingBoat_alliance.base_stats["targets"] = 1f;
		FishingBoat_alliance.base_stats["area_of_effect"] = 0.5f;
		FishingBoat_alliance.base_stats["range"] = 6f;
		FishingBoat_alliance.inspect_avatar_scale = 0.4f;
		FishingBoat_alliance.sound_hit = "event:/SFX/HIT/HitMetal";
		FishingBoat_alliance.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingSpawn";
		FishingBoat_alliance.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingIdleLoop";
		FishingBoat_alliance.sound_death = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingDeath";
		FishingBoat_alliance.default_attack = "boat_cannonball";
		FishingBoat_alliance.icon = "iconBoat";
		FishingBoat_alliance.shadow_texture = "unitShadow_6";
		FishingBoat_alliance.cost = new ConstructionCost(1, 0, 0, 1);
		FishingBoat_alliance.texture_asset = new ActorTextureSubAsset("actors/FishingBoat_alliance/");
		FishingBoat_alliance.special = true;
		FishingBoat_alliance.has_advanced_textures = false;
		FishingBoat_alliance.draw_boat_mark = true;
		FishingBoat_alliance.actor_size = ActorSize.S16_Buffalo;
		FishingBoat_alliance.animation_walk = ActorAnimationSequences.walk_0;
		FishingBoat_alliance.animation_idle = ActorAnimationSequences.walk_0;
		FishingBoat_alliance.animation_swim = ActorAnimationSequences.swim_0_3;
		FishingBoat_alliance.addTrait("boat");
		FishingBoat_alliance.addTrait("light_lamp");
		AssetManager.actor_library.add(FishingBoat_alliance);
		Localization.addLocalization(FishingBoat_alliance.name_locale, FishingBoat_alliance.name_locale);


	var CargoShip_horde = AssetManager.actor_library.clone("CargoShip_horde","$boat$");
	    CargoShip_horde.id = "CargoShip_horde";
		CargoShip_horde.boat_type = "cargo_horde_boat";
		CargoShip_horde.can_be_inspected = false;
        CargoShip_horde.skip_fight_logic = true;
		CargoShip_horde.name_locale = "Cargo Ship";
		CargoShip_horde.addDecision("boat_trading");
		CargoShip_horde.addDecision("boat_transport_check");
		CargoShip_horde.has_avatar_prefab = false;
		CargoShip_horde.animation_speed_based_on_walk_speed = false;
		CargoShip_horde.can_flip = true;
        CargoShip_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CargoShip_horde.is_boat = true;
		CargoShip_horde.die_in_lava = false;
		CargoShip_horde.has_override_sprite = false;
	    CargoShip_horde.has_override_avatar_frames = false;
		CargoShip_horde.base_stats["mass_2"] = 3000f;
		CargoShip_horde.base_stats["stamina"] = 1000f;
		CargoShip_horde.base_stats["scale"] = 0.25f;
		CargoShip_horde.base_stats["health"] = 2000f;
		CargoShip_horde.base_stats["speed"] = 20f;
		CargoShip_horde.base_stats["armor"] = 30f;
		CargoShip_horde.base_stats["attack_speed"] = 0.3f;
		CargoShip_horde.base_stats["damage"] = 100f;
		CargoShip_horde.base_stats["knockback"] = 2f;
		CargoShip_horde.base_stats["accuracy"] = 0.7f;
		CargoShip_horde.base_stats["targets"] = 1f;
		CargoShip_horde.base_stats["area_of_effect"] = 0.5f;
		CargoShip_horde.base_stats["range"] = 6f;
		CargoShip_horde.inspect_avatar_scale = 0.4f;
		CargoShip_horde.sound_hit = "event:/SFX/HIT/HitMetal";
		CargoShip_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingSpawn";
		CargoShip_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingIdleLoop";
		CargoShip_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingDeath";
		CargoShip_horde.default_attack = "boat_cannonball";
		CargoShip_horde.icon = "iconBoat";
		CargoShip_horde.shadow_texture = "unitShadow_6";
		CargoShip_horde.cost = new ConstructionCost(1, 0, 0, 1);
		CargoShip_horde.texture_asset = new ActorTextureSubAsset("actors/CargoShip_horde/");
		CargoShip_horde.special = true;
		CargoShip_horde.has_advanced_textures = false;
		CargoShip_horde.draw_boat_mark = true;
		CargoShip_horde.actor_size = ActorSize.S16_Buffalo;
		CargoShip_horde.animation_walk = ActorAnimationSequences.walk_0;
		CargoShip_horde.animation_idle = ActorAnimationSequences.walk_0;
		CargoShip_horde.animation_swim = ActorAnimationSequences.swim_0_2;
		CargoShip_horde.addTrait("boat");
		CargoShip_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(CargoShip_horde);
		Localization.addLocalization(CargoShip_horde.name_locale, CargoShip_horde.name_locale);


	var aDestroyer_horde = AssetManager.actor_library.clone("aDestroyer_horde","$boat$");
	    aDestroyer_horde.id = "aDestroyer_horde";
	    aDestroyer_horde.can_be_inspected = false;
		aDestroyer_horde.boat_type = "destroyer_a_horde_boat";
		aDestroyer_horde.name_locale = "Destroyer Ship";
		aDestroyer_horde.addDecision("boat_transport_check");
		aDestroyer_horde.has_avatar_prefab = false;
		aDestroyer_horde.animation_speed_based_on_walk_speed = false;
		aDestroyer_horde.can_flip = true;
        aDestroyer_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    aDestroyer_horde.is_boat = true;
		aDestroyer_horde.die_in_lava = false;
		aDestroyer_horde.has_override_sprite = false;
	    aDestroyer_horde.has_override_avatar_frames = false;
		aDestroyer_horde.base_stats["mass_2"] = 3000f;
		aDestroyer_horde.base_stats["stamina"] = 1000f;
		aDestroyer_horde.base_stats["scale"] = 0.25f;
		aDestroyer_horde.base_stats["health"] = 2000f;
		aDestroyer_horde.base_stats["speed"] = 40f;
		aDestroyer_horde.base_stats["armor"] = 30f;
		aDestroyer_horde.base_stats["attack_speed"] = 0.3f;
		aDestroyer_horde.base_stats["damage"] = 100f;
		aDestroyer_horde.base_stats["knockback"] = 2f;
		aDestroyer_horde.base_stats["accuracy"] = 0.7f;
		aDestroyer_horde.base_stats["targets"] = 1f;
		aDestroyer_horde.base_stats["area_of_effect"] = 0.5f;
		aDestroyer_horde.base_stats["range"] = 20f;
		aDestroyer_horde.inspect_avatar_scale = 0.4f;
		aDestroyer_horde.sound_hit = "event:/SFX/HIT/HitMetal";
        aDestroyer_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		aDestroyer_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		aDestroyer_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		aDestroyer_horde.default_attack = "fighterattackHorde";
		aDestroyer_horde.icon = "iconBoat";
		aDestroyer_horde.shadow_texture = "unitShadow_6";
		aDestroyer_horde.cost = new ConstructionCost(1, 0, 0, 1);
		aDestroyer_horde.texture_asset = new ActorTextureSubAsset("actors/Destroyer_horde/");
		aDestroyer_horde.special = true;
		aDestroyer_horde.has_advanced_textures = false;
		aDestroyer_horde.draw_boat_mark = true;
		aDestroyer_horde.actor_size = ActorSize.S16_Buffalo;
		aDestroyer_horde.animation_walk = ActorAnimationSequences.walk_0;
		aDestroyer_horde.animation_idle = ActorAnimationSequences.walk_0;
		aDestroyer_horde.animation_swim = ActorAnimationSequences.swim_0_3;
		aDestroyer_horde.addTrait("boat");
		aDestroyer_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(aDestroyer_horde);
		Localization.addLocalization(aDestroyer_horde.name_locale, aDestroyer_horde.name_locale);

	var bDestroyer_horde = AssetManager.actor_library.clone("bDestroyer_horde","$boat$");
	    bDestroyer_horde.id = "bDestroyer_horde";
		bDestroyer_horde.boat_type = "destroyer_b_horde_boat";
		bDestroyer_horde.can_be_inspected = false;
		bDestroyer_horde.name_locale = "Destroyer Ship";
		bDestroyer_horde.addDecision("boat_transport_check");
		bDestroyer_horde.has_avatar_prefab = false;
		bDestroyer_horde.animation_speed_based_on_walk_speed = false;
		bDestroyer_horde.can_flip = true;
        bDestroyer_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    bDestroyer_horde.is_boat = true;
		bDestroyer_horde.die_in_lava = false;
		bDestroyer_horde.has_override_sprite = false;
	    bDestroyer_horde.has_override_avatar_frames = false;
		bDestroyer_horde.base_stats["mass_2"] = 3000f;
		bDestroyer_horde.base_stats["stamina"] = 1000f;
		bDestroyer_horde.base_stats["scale"] = 0.25f;
		bDestroyer_horde.base_stats["health"] = 2000f;
		bDestroyer_horde.base_stats["speed"] = 40f;
		bDestroyer_horde.base_stats["armor"] = 30f;
		bDestroyer_horde.base_stats["attack_speed"] = 0.3f;
		bDestroyer_horde.base_stats["damage"] = 100f;
		bDestroyer_horde.base_stats["knockback"] = 2f;
		bDestroyer_horde.base_stats["accuracy"] = 0.7f;
		bDestroyer_horde.base_stats["targets"] = 1f;
		bDestroyer_horde.base_stats["area_of_effect"] = 0.5f;
		bDestroyer_horde.base_stats["range"] = 20f;
		bDestroyer_horde.inspect_avatar_scale = 0.4f;
		bDestroyer_horde.sound_hit = "event:/SFX/HIT/HitMetal";
        bDestroyer_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		bDestroyer_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		bDestroyer_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		bDestroyer_horde.default_attack = "fighterattackHorde";
		bDestroyer_horde.icon = "iconBoat";
		bDestroyer_horde.shadow_texture = "unitShadow_6";
		bDestroyer_horde.cost = new ConstructionCost(1, 0, 0, 1);
		bDestroyer_horde.texture_asset = new ActorTextureSubAsset("actors/Destroyer_horde/");
		bDestroyer_horde.special = true;
		bDestroyer_horde.has_advanced_textures = false;
		bDestroyer_horde.draw_boat_mark = true;
		bDestroyer_horde.actor_size = ActorSize.S16_Buffalo;
		bDestroyer_horde.animation_walk = ActorAnimationSequences.walk_0;
		bDestroyer_horde.animation_idle = ActorAnimationSequences.walk_0;
		bDestroyer_horde.animation_swim = ActorAnimationSequences.swim_0_3;
		bDestroyer_horde.addTrait("boat");
		bDestroyer_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(bDestroyer_horde);
		Localization.addLocalization(bDestroyer_horde.name_locale, bDestroyer_horde.name_locale);

        ///////jet attack for carrier/no spawn

	var CarrierVessel_horde = AssetManager.actor_library.clone("CarrierVessel_horde","$boat$");
	    CarrierVessel_horde.id = "CarrierVessel_horde";
		CarrierVessel_horde.boat_type = "carrier_horde_boat";
		CarrierVessel_horde.name_locale = "Cargo Ship";
		CarrierVessel_horde.can_be_inspected = false;
		CarrierVessel_horde.addDecision("boat_trading");
		CarrierVessel_horde.addDecision("boat_transport_check");
		CarrierVessel_horde.has_avatar_prefab = false;
		CarrierVessel_horde.animation_speed_based_on_walk_speed = false;
		CarrierVessel_horde.can_flip = true;
        CarrierVessel_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CarrierVessel_horde.is_boat = true;
		CarrierVessel_horde.die_in_lava = false;
		CarrierVessel_horde.has_override_sprite = false;
	    CarrierVessel_horde.has_override_avatar_frames = false;
		CarrierVessel_horde.base_stats["mass_2"] = 3000f;
		CarrierVessel_horde.base_stats["stamina"] = 1000f;
		CarrierVessel_horde.base_stats["scale"] = 0.25f;
		CarrierVessel_horde.base_stats["health"] = 2000f;
		CarrierVessel_horde.base_stats["speed"] = 20f;
		CarrierVessel_horde.base_stats["armor"] = 30f;
		CarrierVessel_horde.base_stats["attack_speed"] = 0.3f;
		CarrierVessel_horde.base_stats["damage"] = 200f;
		CarrierVessel_horde.base_stats["knockback"] = 2f;
		CarrierVessel_horde.base_stats["accuracy"] = 0.7f;
		CarrierVessel_horde.base_stats["targets"] = 1f;
		CarrierVessel_horde.base_stats["area_of_effect"] = 0.5f;
		CarrierVessel_horde.base_stats["range"] = 16f;
		CarrierVessel_horde.inspect_avatar_scale = 0.4f;
		CarrierVessel_horde.sound_hit = "event:/SFX/HIT/HitMetal";
        CarrierVessel_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		CarrierVessel_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		CarrierVessel_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		CarrierVessel_horde.default_attack = "AirstrikejetAttack_horde";
		CarrierVessel_horde.icon = "iconBoat";
		CarrierVessel_horde.shadow_texture = "unitShadow_6";
		CarrierVessel_horde.cost = new ConstructionCost(1, 0, 0, 1);
		CarrierVessel_horde.texture_asset = new ActorTextureSubAsset("actors/CarrierVessel_horde/");
		CarrierVessel_horde.special = true;
		CarrierVessel_horde.has_advanced_textures = false;
		CarrierVessel_horde.draw_boat_mark = true;
		CarrierVessel_horde.actor_size = ActorSize.S16_Buffalo;
		CarrierVessel_horde.animation_walk = ActorAnimationSequences.walk_0;
		CarrierVessel_horde.animation_idle = ActorAnimationSequences.walk_0;
		CarrierVessel_horde.animation_swim = ActorAnimationSequences.swim_0_3;
		CarrierVessel_horde.addTrait("boat");
		CarrierVessel_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(CarrierVessel_horde);
		Localization.addLocalization(CarrierVessel_horde.name_locale, CarrierVessel_horde.name_locale);

	var Submarine_horde = AssetManager.actor_library.clone("Submarine_horde","$boat$");
	    Submarine_horde.id = "Submarine_horde";
		Submarine_horde.boat_type = "submarine_horde_boat";
		Submarine_horde.name_locale = "Cargo Ship";
		Submarine_horde.can_be_inspected = false;
		Submarine_horde.addDecision("boat_trading");
		Submarine_horde.addDecision("boat_transport_check");
		Submarine_horde.has_avatar_prefab = false;
		Submarine_horde.animation_speed_based_on_walk_speed = false;
		Submarine_horde.can_flip = true;
        Submarine_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    Submarine_horde.is_boat = true;
		Submarine_horde.die_in_lava = false;
		Submarine_horde.has_override_sprite = false;
	    Submarine_horde.has_override_avatar_frames = false;
		Submarine_horde.base_stats["mass_2"] = 3000f;
		Submarine_horde.base_stats["stamina"] = 1000f;
		Submarine_horde.base_stats["scale"] = 0.25f;
		Submarine_horde.base_stats["health"] = 2000f;
		Submarine_horde.base_stats["speed"] = 60f;
		Submarine_horde.base_stats["armor"] = 30f;
		Submarine_horde.base_stats["attack_speed"] = 0.3f;
		Submarine_horde.base_stats["damage"] = 300f;
		Submarine_horde.base_stats["knockback"] = 2f;
		Submarine_horde.base_stats["accuracy"] = 0.7f;
		Submarine_horde.base_stats["targets"] = 1f;
		Submarine_horde.base_stats["area_of_effect"] = 0.5f;
		Submarine_horde.base_stats["range"] = 200f;
		Submarine_horde.inspect_avatar_scale = 0.4f;
		Submarine_horde.sound_hit = "event:/SFX/HIT/HitMetal";
		Submarine_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		Submarine_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		Submarine_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		Submarine_horde.default_attack = "MissileSystemHorde";
		Submarine_horde.icon = "iconBoat";
		Submarine_horde.shadow_texture = "unitShadow_6";
		Submarine_horde.cost = new ConstructionCost(1, 0, 0, 1);
		Submarine_horde.texture_asset = new ActorTextureSubAsset("actors/Submarine_horde/");
		Submarine_horde.special = true;
		Submarine_horde.has_advanced_textures = false;
		Submarine_horde.draw_boat_mark = true;
		Submarine_horde.actor_size = ActorSize.S16_Buffalo;
		Submarine_horde.animation_walk = ActorAnimationSequences.walk_0;
		Submarine_horde.animation_idle = ActorAnimationSequences.walk_0;
		Submarine_horde.animation_swim = ActorAnimationSequences.swim_0_3;
		Submarine_horde.addTrait("boat");
		Submarine_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(Submarine_horde);
		Localization.addLocalization(Submarine_horde.name_locale, Submarine_horde.name_locale);

	var FishingBoat_horde = AssetManager.actor_library.clone("FishingBoat_horde","$boat$");
	    FishingBoat_horde.id = "FishingBoat_horde";
		FishingBoat_horde.boat_type = "fishing_horde_boat";
        FishingBoat_horde.skip_fight_logic = true;
        FishingBoat_horde.can_be_inspected = false;
		FishingBoat_horde.name_locale = "Cargo Ship";
		FishingBoat_horde.addDecision("boat_fishing");
		FishingBoat_horde.has_avatar_prefab = false;
		FishingBoat_horde.animation_speed_based_on_walk_speed = false;
		FishingBoat_horde.can_flip = true;
        FishingBoat_horde.check_flip = (BaseSimObject _, WorldTile _) => true;
	    FishingBoat_horde.is_boat = true;
		FishingBoat_horde.die_in_lava = false;
		FishingBoat_horde.has_override_sprite = false;
	    FishingBoat_horde.has_override_avatar_frames = false;
		FishingBoat_horde.base_stats["mass_2"] = 3000f;
		FishingBoat_horde.base_stats["stamina"] = 1000f;
		FishingBoat_horde.base_stats["scale"] = 0.25f;
		FishingBoat_horde.base_stats["health"] = 2000f;
		FishingBoat_horde.base_stats["speed"] = 60f;
		FishingBoat_horde.base_stats["armor"] = 30f;
		FishingBoat_horde.base_stats["attack_speed"] = 0.3f;
		FishingBoat_horde.base_stats["damage"] = 100f;
		FishingBoat_horde.base_stats["knockback"] = 2f;
		FishingBoat_horde.base_stats["accuracy"] = 0.7f;
		FishingBoat_horde.base_stats["targets"] = 1f;
		FishingBoat_horde.base_stats["area_of_effect"] = 0.5f;
		FishingBoat_horde.base_stats["range"] = 6f;
		FishingBoat_horde.inspect_avatar_scale = 0.4f;
		FishingBoat_horde.sound_hit = "event:/SFX/HIT/HitMetal";
		FishingBoat_horde.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingSpawn";
		FishingBoat_horde.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingIdleLoop";
		FishingBoat_horde.sound_death = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingDeath";
		FishingBoat_horde.default_attack = "boat_cannonball";
		FishingBoat_horde.icon = "iconBoat";
		FishingBoat_horde.shadow_texture = "unitShadow_6";
		FishingBoat_horde.cost = new ConstructionCost(1, 0, 0, 1);
		FishingBoat_horde.texture_asset = new ActorTextureSubAsset("actors/FishingBoat_horde/");
		FishingBoat_horde.special = true;
		FishingBoat_horde.has_advanced_textures = false;
		FishingBoat_horde.draw_boat_mark = true;
		FishingBoat_horde.actor_size = ActorSize.S16_Buffalo;
		FishingBoat_horde.animation_walk = ActorAnimationSequences.walk_0;
		FishingBoat_horde.animation_idle = ActorAnimationSequences.walk_0;
		FishingBoat_horde.animation_swim = ActorAnimationSequences.swim_0_3;
		FishingBoat_horde.addTrait("boat");
		FishingBoat_horde.addTrait("light_lamp");
		AssetManager.actor_library.add(FishingBoat_horde);
		Localization.addLocalization(FishingBoat_horde.name_locale, FishingBoat_horde.name_locale);

        	var CargoShip_gaia = AssetManager.actor_library.clone("CargoShip_gaia","$boat$");
	    CargoShip_gaia.id = "CargoShip_gaia";
		CargoShip_gaia.boat_type = "cargo_gaia_boat";
		CargoShip_gaia.can_be_inspected = false;
        CargoShip_gaia.skip_fight_logic = true;
		CargoShip_gaia.name_locale = "Cargo Ship";
		CargoShip_gaia.addDecision("boat_trading");
		CargoShip_gaia.addDecision("boat_transport_check");
		CargoShip_gaia.has_avatar_prefab = false;
		CargoShip_gaia.animation_speed_based_on_walk_speed = false;
		CargoShip_gaia.can_flip = true;
        CargoShip_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CargoShip_gaia.is_boat = true;
		CargoShip_gaia.die_in_lava = false;
		CargoShip_gaia.has_override_sprite = false;
	    CargoShip_gaia.has_override_avatar_frames = false;
		CargoShip_gaia.base_stats["mass_2"] = 3000f;
		CargoShip_gaia.base_stats["stamina"] = 1000f;
		CargoShip_gaia.base_stats["scale"] = 0.25f;
		CargoShip_gaia.base_stats["health"] = 2000f;
		CargoShip_gaia.base_stats["speed"] = 20f;
		CargoShip_gaia.base_stats["armor"] = 30f;
		CargoShip_gaia.base_stats["attack_speed"] = 0.3f;
		CargoShip_gaia.base_stats["damage"] = 100f;
		CargoShip_gaia.base_stats["knockback"] = 2f;
		CargoShip_gaia.base_stats["accuracy"] = 0.7f;
		CargoShip_gaia.base_stats["targets"] = 1f;
		CargoShip_gaia.base_stats["area_of_effect"] = 0.5f;
		CargoShip_gaia.base_stats["range"] = 6f;
		CargoShip_gaia.inspect_avatar_scale = 0.4f;
		CargoShip_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
		CargoShip_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingSpawn";
		CargoShip_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingIdleLoop";
		CargoShip_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingDeath";
		CargoShip_gaia.default_attack = "boat_cannonball";
		CargoShip_gaia.icon = "iconBoat";
		CargoShip_gaia.shadow_texture = "unitShadow_6";
		CargoShip_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		CargoShip_gaia.texture_asset = new ActorTextureSubAsset("actors/CargoShip_gaia/");
		CargoShip_gaia.special = true;
		CargoShip_gaia.has_advanced_textures = false;
		CargoShip_gaia.draw_boat_mark = true;
		CargoShip_gaia.actor_size = ActorSize.S16_Buffalo;
		CargoShip_gaia.animation_walk = ActorAnimationSequences.walk_0;
		CargoShip_gaia.animation_idle = ActorAnimationSequences.walk_0;
		CargoShip_gaia.animation_swim = ActorAnimationSequences.swim_0_2;
		CargoShip_gaia.addTrait("boat");
		CargoShip_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(CargoShip_gaia);
		Localization.addLocalization(CargoShip_gaia.name_locale, CargoShip_gaia.name_locale);


	var aDestroyer_gaia = AssetManager.actor_library.clone("aDestroyer_gaia","$boat$");
	    aDestroyer_gaia.id = "aDestroyer_gaia";
	    aDestroyer_gaia.can_be_inspected = false;
		aDestroyer_gaia.boat_type = "destroyer_a_gaia_boat";
		aDestroyer_gaia.name_locale = "Destroyer Ship";
		aDestroyer_gaia.addDecision("boat_transport_check");
		aDestroyer_gaia.has_avatar_prefab = false;
		aDestroyer_gaia.animation_speed_based_on_walk_speed = false;
		aDestroyer_gaia.can_flip = true;
        aDestroyer_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    aDestroyer_gaia.is_boat = true;
		aDestroyer_gaia.die_in_lava = false;
		aDestroyer_gaia.has_override_sprite = false;
	    aDestroyer_gaia.has_override_avatar_frames = false;
		aDestroyer_gaia.base_stats["mass_2"] = 3000f;
		aDestroyer_gaia.base_stats["stamina"] = 1000f;
		aDestroyer_gaia.base_stats["scale"] = 0.25f;
		aDestroyer_gaia.base_stats["health"] = 2000f;
		aDestroyer_gaia.base_stats["speed"] = 40f;
		aDestroyer_gaia.base_stats["armor"] = 30f;
		aDestroyer_gaia.base_stats["attack_speed"] = 0.3f;
		aDestroyer_gaia.base_stats["damage"] = 100f;
		aDestroyer_gaia.base_stats["knockback"] = 2f;
		aDestroyer_gaia.base_stats["accuracy"] = 0.7f;
		aDestroyer_gaia.base_stats["targets"] = 1f;
		aDestroyer_gaia.base_stats["area_of_effect"] = 0.5f;
		aDestroyer_gaia.base_stats["range"] = 20f;
		aDestroyer_gaia.inspect_avatar_scale = 0.4f;
		aDestroyer_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        aDestroyer_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		aDestroyer_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		aDestroyer_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		aDestroyer_gaia.default_attack = "fighterattackGaia";
		aDestroyer_gaia.icon = "iconBoat";
		aDestroyer_gaia.shadow_texture = "unitShadow_6";
		aDestroyer_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		aDestroyer_gaia.texture_asset = new ActorTextureSubAsset("actors/Destroyer_gaia/");
		aDestroyer_gaia.special = true;
		aDestroyer_gaia.has_advanced_textures = false;
		aDestroyer_gaia.draw_boat_mark = true;
		aDestroyer_gaia.actor_size = ActorSize.S16_Buffalo;
		aDestroyer_gaia.animation_walk = ActorAnimationSequences.walk_0;
		aDestroyer_gaia.animation_idle = ActorAnimationSequences.walk_0;
		aDestroyer_gaia.animation_swim = ActorAnimationSequences.swim_0_3;
		aDestroyer_gaia.addTrait("boat");
		aDestroyer_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(aDestroyer_gaia);
		Localization.addLocalization(aDestroyer_gaia.name_locale, aDestroyer_gaia.name_locale);

	var bDestroyer_gaia = AssetManager.actor_library.clone("bDestroyer_gaia","$boat$");
	    bDestroyer_gaia.id = "bDestroyer_gaia";
		bDestroyer_gaia.boat_type = "destroyer_b_gaia_boat";
		bDestroyer_gaia.can_be_inspected = false;
		bDestroyer_gaia.name_locale = "Destroyer Ship";
		bDestroyer_gaia.addDecision("boat_transport_check");
		bDestroyer_gaia.has_avatar_prefab = false;
		bDestroyer_gaia.animation_speed_based_on_walk_speed = false;
		bDestroyer_gaia.can_flip = true;
        bDestroyer_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    bDestroyer_gaia.is_boat = true;
		bDestroyer_gaia.die_in_lava = false;
		bDestroyer_gaia.has_override_sprite = false;
	    bDestroyer_gaia.has_override_avatar_frames = false;
		bDestroyer_gaia.base_stats["mass_2"] = 3000f;
		bDestroyer_gaia.base_stats["stamina"] = 1000f;
		bDestroyer_gaia.base_stats["scale"] = 0.25f;
		bDestroyer_gaia.base_stats["health"] = 2000f;
		bDestroyer_gaia.base_stats["speed"] = 40f;
		bDestroyer_gaia.base_stats["armor"] = 30f;
		bDestroyer_gaia.base_stats["attack_speed"] = 0.3f;
		bDestroyer_gaia.base_stats["damage"] = 100f;
		bDestroyer_gaia.base_stats["knockback"] = 2f;
		bDestroyer_gaia.base_stats["accuracy"] = 0.7f;
		bDestroyer_gaia.base_stats["targets"] = 1f;
		bDestroyer_gaia.base_stats["area_of_effect"] = 0.5f;
		bDestroyer_gaia.base_stats["range"] = 20f;
		bDestroyer_gaia.inspect_avatar_scale = 0.4f;
		bDestroyer_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        bDestroyer_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		bDestroyer_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		bDestroyer_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		bDestroyer_gaia.default_attack = "fighterattackGaia";
		bDestroyer_gaia.icon = "iconBoat";
		bDestroyer_gaia.shadow_texture = "unitShadow_6";
		bDestroyer_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		bDestroyer_gaia.texture_asset = new ActorTextureSubAsset("actors/Destroyer_gaia/");
		bDestroyer_gaia.special = true;
		bDestroyer_gaia.has_advanced_textures = false;
		bDestroyer_gaia.draw_boat_mark = true;
		bDestroyer_gaia.actor_size = ActorSize.S16_Buffalo;
		bDestroyer_gaia.animation_walk = ActorAnimationSequences.walk_0;
		bDestroyer_gaia.animation_idle = ActorAnimationSequences.walk_0;
		bDestroyer_gaia.animation_swim = ActorAnimationSequences.swim_0_3;
		bDestroyer_gaia.addTrait("boat");
		bDestroyer_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(bDestroyer_gaia);
		Localization.addLocalization(bDestroyer_gaia.name_locale, bDestroyer_gaia.name_locale);

        ///////jet attack for carrier/no spawn

	var CarrierVessel_gaia = AssetManager.actor_library.clone("CarrierVessel_gaia","$boat$");
	    CarrierVessel_gaia.id = "CarrierVessel_gaia";
		CarrierVessel_gaia.boat_type = "carrier_gaia_boat";
		CarrierVessel_gaia.name_locale = "Cargo Ship";
		CarrierVessel_gaia.can_be_inspected = false;
		CarrierVessel_gaia.addDecision("boat_trading");
		CarrierVessel_gaia.addDecision("boat_transport_check");
		CarrierVessel_gaia.has_avatar_prefab = false;
		CarrierVessel_gaia.animation_speed_based_on_walk_speed = false;
		CarrierVessel_gaia.can_flip = true;
        CarrierVessel_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CarrierVessel_gaia.is_boat = true;
		CarrierVessel_gaia.die_in_lava = false;
		CarrierVessel_gaia.has_override_sprite = false;
	    CarrierVessel_gaia.has_override_avatar_frames = false;
		CarrierVessel_gaia.base_stats["mass_2"] = 3000f;
		CarrierVessel_gaia.base_stats["stamina"] = 1000f;
		CarrierVessel_gaia.base_stats["scale"] = 0.25f;
		CarrierVessel_gaia.base_stats["health"] = 2000f;
		CarrierVessel_gaia.base_stats["speed"] = 20f;
		CarrierVessel_gaia.base_stats["armor"] = 30f;
		CarrierVessel_gaia.base_stats["attack_speed"] = 0.3f;
		CarrierVessel_gaia.base_stats["damage"] = 200f;
		CarrierVessel_gaia.base_stats["knockback"] = 2f;
		CarrierVessel_gaia.base_stats["accuracy"] = 0.7f;
		CarrierVessel_gaia.base_stats["targets"] = 1f;
		CarrierVessel_gaia.base_stats["area_of_effect"] = 0.5f;
		CarrierVessel_gaia.base_stats["range"] = 16f;
		CarrierVessel_gaia.inspect_avatar_scale = 0.4f;
		CarrierVessel_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
        CarrierVessel_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		CarrierVessel_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		CarrierVessel_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		CarrierVessel_gaia.default_attack = "AirstrikejetAttack_gaia";
		CarrierVessel_gaia.icon = "iconBoat";
		CarrierVessel_gaia.shadow_texture = "unitShadow_6";
		CarrierVessel_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		CarrierVessel_gaia.texture_asset = new ActorTextureSubAsset("actors/CarrierVessel_gaia/");
		CarrierVessel_gaia.special = true;
		CarrierVessel_gaia.has_advanced_textures = false;
		CarrierVessel_gaia.draw_boat_mark = true;
		CarrierVessel_gaia.actor_size = ActorSize.S16_Buffalo;
		CarrierVessel_gaia.animation_walk = ActorAnimationSequences.walk_0;
		CarrierVessel_gaia.animation_idle = ActorAnimationSequences.walk_0;
		CarrierVessel_gaia.animation_swim = ActorAnimationSequences.swim_0_3;
		CarrierVessel_gaia.addTrait("boat");
		CarrierVessel_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(CarrierVessel_gaia);
		Localization.addLocalization(CarrierVessel_gaia.name_locale, CarrierVessel_gaia.name_locale);

	var Submarine_gaia = AssetManager.actor_library.clone("Submarine_gaia","$boat$");
	    Submarine_gaia.id = "Submarine_gaia";
		Submarine_gaia.boat_type = "submarine_gaia_boat";
		Submarine_gaia.name_locale = "Cargo Ship";
		Submarine_gaia.can_be_inspected = false;
		Submarine_gaia.addDecision("boat_trading");
		Submarine_gaia.addDecision("boat_transport_check");
		Submarine_gaia.has_avatar_prefab = false;
		Submarine_gaia.animation_speed_based_on_walk_speed = false;
		Submarine_gaia.can_flip = true;
        Submarine_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    Submarine_gaia.is_boat = true;
		Submarine_gaia.die_in_lava = false;
		Submarine_gaia.has_override_sprite = false;
	    Submarine_gaia.has_override_avatar_frames = false;
		Submarine_gaia.base_stats["mass_2"] = 3000f;
		Submarine_gaia.base_stats["stamina"] = 1000f;
		Submarine_gaia.base_stats["scale"] = 0.25f;
		Submarine_gaia.base_stats["health"] = 2000f;
		Submarine_gaia.base_stats["speed"] = 60f;
		Submarine_gaia.base_stats["armor"] = 30f;
		Submarine_gaia.base_stats["attack_speed"] = 0.3f;
		Submarine_gaia.base_stats["damage"] = 300f;
		Submarine_gaia.base_stats["knockback"] = 2f;
		Submarine_gaia.base_stats["accuracy"] = 0.7f;
		Submarine_gaia.base_stats["targets"] = 1f;
		Submarine_gaia.base_stats["area_of_effect"] = 0.5f;
		Submarine_gaia.base_stats["range"] = 200f;
		Submarine_gaia.inspect_avatar_scale = 0.4f;
		Submarine_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
		Submarine_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		Submarine_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		Submarine_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		Submarine_gaia.default_attack = "MissileSystemGaia";
		Submarine_gaia.icon = "iconBoat";
		Submarine_gaia.shadow_texture = "unitShadow_6";
		Submarine_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		Submarine_gaia.texture_asset = new ActorTextureSubAsset("actors/Submarine_gaia/");
		Submarine_gaia.special = true;
		Submarine_gaia.has_advanced_textures = false;
		Submarine_gaia.draw_boat_mark = true;
		Submarine_gaia.actor_size = ActorSize.S16_Buffalo;
		Submarine_gaia.animation_walk = ActorAnimationSequences.walk_0;
		Submarine_gaia.animation_idle = ActorAnimationSequences.walk_0;
		Submarine_gaia.animation_swim = ActorAnimationSequences.swim_0_3;
		Submarine_gaia.addTrait("boat");
		Submarine_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(Submarine_gaia);
		Localization.addLocalization(Submarine_gaia.name_locale, Submarine_gaia.name_locale);

	var FishingBoat_gaia = AssetManager.actor_library.clone("FishingBoat_gaia","$boat$");
	    FishingBoat_gaia.id = "FishingBoat_gaia";
		FishingBoat_gaia.boat_type = "fishing_gaia_boat";
        FishingBoat_gaia.skip_fight_logic = true;
        FishingBoat_gaia.can_be_inspected = false;
		FishingBoat_gaia.name_locale = "Cargo Ship";
		FishingBoat_gaia.addDecision("boat_fishing");
		FishingBoat_gaia.has_avatar_prefab = false;
		FishingBoat_gaia.animation_speed_based_on_walk_speed = false;
		FishingBoat_gaia.can_flip = true;
        FishingBoat_gaia.check_flip = (BaseSimObject _, WorldTile _) => true;
	    FishingBoat_gaia.is_boat = true;
		FishingBoat_gaia.die_in_lava = false;
		FishingBoat_gaia.has_override_sprite = false;
	    FishingBoat_gaia.has_override_avatar_frames = false;
		FishingBoat_gaia.base_stats["mass_2"] = 3000f;
		FishingBoat_gaia.base_stats["stamina"] = 1000f;
		FishingBoat_gaia.base_stats["scale"] = 0.25f;
		FishingBoat_gaia.base_stats["health"] = 2000f;
		FishingBoat_gaia.base_stats["speed"] = 60f;
		FishingBoat_gaia.base_stats["armor"] = 30f;
		FishingBoat_gaia.base_stats["attack_speed"] = 0.3f;
		FishingBoat_gaia.base_stats["damage"] = 100f;
		FishingBoat_gaia.base_stats["knockback"] = 2f;
		FishingBoat_gaia.base_stats["accuracy"] = 0.7f;
		FishingBoat_gaia.base_stats["targets"] = 1f;
		FishingBoat_gaia.base_stats["area_of_effect"] = 0.5f;
		FishingBoat_gaia.base_stats["range"] = 6f;
		FishingBoat_gaia.inspect_avatar_scale = 0.4f;
		FishingBoat_gaia.sound_hit = "event:/SFX/HIT/HitMetal";
		FishingBoat_gaia.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingSpawn";
		FishingBoat_gaia.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingIdleLoop";
		FishingBoat_gaia.sound_death = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingDeath";
		FishingBoat_gaia.default_attack = "boat_cannonball";
		FishingBoat_gaia.icon = "iconBoat";
		FishingBoat_gaia.shadow_texture = "unitShadow_6";
		FishingBoat_gaia.cost = new ConstructionCost(1, 0, 0, 1);
		FishingBoat_gaia.texture_asset = new ActorTextureSubAsset("actors/FishingBoat_gaia/");
		FishingBoat_gaia.special = true;
		FishingBoat_gaia.has_advanced_textures = false;
		FishingBoat_gaia.draw_boat_mark = true;
		FishingBoat_gaia.actor_size = ActorSize.S16_Buffalo;
		FishingBoat_gaia.animation_walk = ActorAnimationSequences.walk_0;
		FishingBoat_gaia.animation_idle = ActorAnimationSequences.walk_0;
		FishingBoat_gaia.animation_swim = ActorAnimationSequences.swim_0_3;
		FishingBoat_gaia.addTrait("boat");
		FishingBoat_gaia.addTrait("light_lamp");
		AssetManager.actor_library.add(FishingBoat_gaia);
		Localization.addLocalization(FishingBoat_gaia.name_locale, FishingBoat_gaia.name_locale);


	var CargoShip_harden = AssetManager.actor_library.clone("CargoShip_harden","$boat$");
	    CargoShip_harden.id = "CargoShip_harden";
		CargoShip_harden.boat_type = "cargo_harden_boat";
		CargoShip_harden.can_be_inspected = false;
        CargoShip_harden.skip_fight_logic = true;
		CargoShip_harden.name_locale = "Cargo Ship";
		CargoShip_harden.addDecision("boat_trading");
		CargoShip_harden.addDecision("boat_transport_check");
		CargoShip_harden.has_avatar_prefab = false;
		CargoShip_harden.animation_speed_based_on_walk_speed = false;
		CargoShip_harden.can_flip = true;
        CargoShip_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CargoShip_harden.is_boat = true;
		CargoShip_harden.die_in_lava = false;
		CargoShip_harden.has_override_sprite = false;
	    CargoShip_harden.has_override_avatar_frames = false;
		CargoShip_harden.base_stats["mass_2"] = 3000f;
		CargoShip_harden.base_stats["stamina"] = 1000f;
		CargoShip_harden.base_stats["scale"] = 0.25f;
		CargoShip_harden.base_stats["health"] = 2000f;
		CargoShip_harden.base_stats["speed"] = 20f;
		CargoShip_harden.base_stats["armor"] = 30f;
		CargoShip_harden.base_stats["attack_speed"] = 0.3f;
		CargoShip_harden.base_stats["damage"] = 100f;
		CargoShip_harden.base_stats["knockback"] = 2f;
		CargoShip_harden.base_stats["accuracy"] = 0.7f;
		CargoShip_harden.base_stats["targets"] = 1f;
		CargoShip_harden.base_stats["area_of_effect"] = 0.5f;
		CargoShip_harden.base_stats["range"] = 6f;
		CargoShip_harden.inspect_avatar_scale = 0.4f;
		CargoShip_harden.sound_hit = "event:/SFX/HIT/HitMetal";
		CargoShip_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingSpawn";
		CargoShip_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingIdleLoop";
		CargoShip_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTrading/BoatTradingDeath";
		CargoShip_harden.default_attack = "boat_cannonball";
		CargoShip_harden.icon = "iconBoat";
		CargoShip_harden.shadow_texture = "unitShadow_6";
		CargoShip_harden.cost = new ConstructionCost(1, 0, 0, 1);
		CargoShip_harden.texture_asset = new ActorTextureSubAsset("actors/CargoShip_harden/");
		CargoShip_harden.special = true;
		CargoShip_harden.has_advanced_textures = false;
		CargoShip_harden.draw_boat_mark = true;
		CargoShip_harden.actor_size = ActorSize.S16_Buffalo;
		CargoShip_harden.animation_walk = ActorAnimationSequences.walk_0;
		CargoShip_harden.animation_idle = ActorAnimationSequences.walk_0;
		CargoShip_harden.animation_swim = ActorAnimationSequences.swim_0_2;
		CargoShip_harden.addTrait("boat");
		CargoShip_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(CargoShip_harden);
		Localization.addLocalization(CargoShip_harden.name_locale, CargoShip_harden.name_locale);


	var aDestroyer_harden = AssetManager.actor_library.clone("aDestroyer_harden","$boat$");
	    aDestroyer_harden.id = "aDestroyer_harden";
	    aDestroyer_harden.can_be_inspected = false;
		aDestroyer_harden.boat_type = "destroyer_a_harden_boat";
		aDestroyer_harden.name_locale = "Destroyer Ship";
		aDestroyer_harden.addDecision("boat_transport_check");
		aDestroyer_harden.has_avatar_prefab = false;
		aDestroyer_harden.animation_speed_based_on_walk_speed = false;
		aDestroyer_harden.can_flip = true;
        aDestroyer_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    aDestroyer_harden.is_boat = true;
		aDestroyer_harden.die_in_lava = false;
		aDestroyer_harden.has_override_sprite = false;
	    aDestroyer_harden.has_override_avatar_frames = false;
		aDestroyer_harden.base_stats["mass_2"] = 3000f;
		aDestroyer_harden.base_stats["stamina"] = 1000f;
		aDestroyer_harden.base_stats["scale"] = 0.25f;
		aDestroyer_harden.base_stats["health"] = 2000f;
		aDestroyer_harden.base_stats["speed"] = 40f;
		aDestroyer_harden.base_stats["armor"] = 30f;
		aDestroyer_harden.base_stats["attack_speed"] = 0.3f;
		aDestroyer_harden.base_stats["damage"] = 100f;
		aDestroyer_harden.base_stats["knockback"] = 2f;
		aDestroyer_harden.base_stats["accuracy"] = 0.7f;
		aDestroyer_harden.base_stats["targets"] = 1f;
		aDestroyer_harden.base_stats["area_of_effect"] = 0.5f;
		aDestroyer_harden.base_stats["range"] = 20f;
		aDestroyer_harden.inspect_avatar_scale = 0.4f;
		aDestroyer_harden.sound_hit = "event:/SFX/HIT/HitMetal";
        aDestroyer_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		aDestroyer_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		aDestroyer_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		aDestroyer_harden.default_attack = "fighterattackHarden";
		aDestroyer_harden.icon = "iconBoat";
		aDestroyer_harden.shadow_texture = "unitShadow_6";
		aDestroyer_harden.cost = new ConstructionCost(1, 0, 0, 1);
		aDestroyer_harden.texture_asset = new ActorTextureSubAsset("actors/Destroyer_harden/");
		aDestroyer_harden.special = true;
		aDestroyer_harden.has_advanced_textures = false;
		aDestroyer_harden.draw_boat_mark = true;
		aDestroyer_harden.actor_size = ActorSize.S16_Buffalo;
		aDestroyer_harden.animation_walk = ActorAnimationSequences.walk_0;
		aDestroyer_harden.animation_idle = ActorAnimationSequences.walk_0;
		aDestroyer_harden.animation_swim = ActorAnimationSequences.swim_0_3;
		aDestroyer_harden.addTrait("boat");
		aDestroyer_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(aDestroyer_harden);
		Localization.addLocalization(aDestroyer_harden.name_locale, aDestroyer_harden.name_locale);

	var bDestroyer_harden = AssetManager.actor_library.clone("bDestroyer_harden","$boat$");
	    bDestroyer_harden.id = "bDestroyer_harden";
		bDestroyer_harden.boat_type = "destroyer_b_harden_boat";
		bDestroyer_harden.can_be_inspected = false;
		bDestroyer_harden.name_locale = "Destroyer Ship";
		bDestroyer_harden.addDecision("boat_transport_check");
		bDestroyer_harden.has_avatar_prefab = false;
		bDestroyer_harden.animation_speed_based_on_walk_speed = false;
		bDestroyer_harden.can_flip = true;
        bDestroyer_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    bDestroyer_harden.is_boat = true;
		bDestroyer_harden.die_in_lava = false;
		bDestroyer_harden.has_override_sprite = false;
	    bDestroyer_harden.has_override_avatar_frames = false;
		bDestroyer_harden.base_stats["mass_2"] = 3000f;
		bDestroyer_harden.base_stats["stamina"] = 1000f;
		bDestroyer_harden.base_stats["scale"] = 0.25f;
		bDestroyer_harden.base_stats["health"] = 2000f;
		bDestroyer_harden.base_stats["speed"] = 40f;
		bDestroyer_harden.base_stats["armor"] = 30f;
		bDestroyer_harden.base_stats["attack_speed"] = 0.3f;
		bDestroyer_harden.base_stats["damage"] = 100f;
		bDestroyer_harden.base_stats["knockback"] = 2f;
		bDestroyer_harden.base_stats["accuracy"] = 0.7f;
		bDestroyer_harden.base_stats["targets"] = 1f;
		bDestroyer_harden.base_stats["area_of_effect"] = 0.5f;
		bDestroyer_harden.base_stats["range"] = 20f;
		bDestroyer_harden.inspect_avatar_scale = 0.4f;
		bDestroyer_harden.sound_hit = "event:/SFX/HIT/HitMetal";
        bDestroyer_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		bDestroyer_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		bDestroyer_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		bDestroyer_harden.default_attack = "fighterattackHarden";
		bDestroyer_harden.icon = "iconBoat";
		bDestroyer_harden.shadow_texture = "unitShadow_6";
		bDestroyer_harden.cost = new ConstructionCost(1, 0, 0, 1);
		bDestroyer_harden.texture_asset = new ActorTextureSubAsset("actors/Destroyer_harden/");
		bDestroyer_harden.special = true;
		bDestroyer_harden.has_advanced_textures = false;
		bDestroyer_harden.draw_boat_mark = true;
		bDestroyer_harden.actor_size = ActorSize.S16_Buffalo;
		bDestroyer_harden.animation_walk = ActorAnimationSequences.walk_0;
		bDestroyer_harden.animation_idle = ActorAnimationSequences.walk_0;
		bDestroyer_harden.animation_swim = ActorAnimationSequences.swim_0_3;
		bDestroyer_harden.addTrait("boat");
		bDestroyer_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(bDestroyer_harden);
		Localization.addLocalization(bDestroyer_harden.name_locale, bDestroyer_harden.name_locale);

        ///////jet attack for carrier/no spawn

	var CarrierVessel_harden = AssetManager.actor_library.clone("CarrierVessel_harden","$boat$");
	    CarrierVessel_harden.id = "CarrierVessel_harden";
		CarrierVessel_harden.boat_type = "carrier_harden_boat";
		CarrierVessel_harden.name_locale = "Cargo Ship";
		CarrierVessel_harden.can_be_inspected = false;
		CarrierVessel_harden.addDecision("boat_trading");
		CarrierVessel_harden.addDecision("boat_transport_check");
		CarrierVessel_harden.has_avatar_prefab = false;
		CarrierVessel_harden.animation_speed_based_on_walk_speed = false;
		CarrierVessel_harden.can_flip = true;
        CarrierVessel_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    CarrierVessel_harden.is_boat = true;
		CarrierVessel_harden.die_in_lava = false;
		CarrierVessel_harden.has_override_sprite = false;
	    CarrierVessel_harden.has_override_avatar_frames = false;
		CarrierVessel_harden.base_stats["mass_2"] = 3000f;
		CarrierVessel_harden.base_stats["stamina"] = 1000f;
		CarrierVessel_harden.base_stats["scale"] = 0.25f;
		CarrierVessel_harden.base_stats["health"] = 2000f;
		CarrierVessel_harden.base_stats["speed"] = 20f;
		CarrierVessel_harden.base_stats["armor"] = 30f;
		CarrierVessel_harden.base_stats["attack_speed"] = 0.3f;
		CarrierVessel_harden.base_stats["damage"] = 200f;
		CarrierVessel_harden.base_stats["knockback"] = 2f;
		CarrierVessel_harden.base_stats["accuracy"] = 0.7f;
		CarrierVessel_harden.base_stats["targets"] = 1f;
		CarrierVessel_harden.base_stats["area_of_effect"] = 0.5f;
		CarrierVessel_harden.base_stats["range"] = 16f;
		CarrierVessel_harden.inspect_avatar_scale = 0.4f;
		CarrierVessel_harden.sound_hit = "event:/SFX/HIT/HitMetal";
        CarrierVessel_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		CarrierVessel_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		CarrierVessel_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		CarrierVessel_harden.default_attack = "AirstrikejetAttack_harden";
		CarrierVessel_harden.icon = "iconBoat";
		CarrierVessel_harden.shadow_texture = "unitShadow_6";
		CarrierVessel_harden.cost = new ConstructionCost(1, 0, 0, 1);
		CarrierVessel_harden.texture_asset = new ActorTextureSubAsset("actors/CarrierVessel_harden/");
		CarrierVessel_harden.special = true;
		CarrierVessel_harden.has_advanced_textures = false;
		CarrierVessel_harden.draw_boat_mark = true;
		CarrierVessel_harden.actor_size = ActorSize.S16_Buffalo;
		CarrierVessel_harden.animation_walk = ActorAnimationSequences.walk_0;
		CarrierVessel_harden.animation_idle = ActorAnimationSequences.walk_0;
		CarrierVessel_harden.animation_swim = ActorAnimationSequences.swim_0_3;
		CarrierVessel_harden.addTrait("boat");
		CarrierVessel_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(CarrierVessel_harden);
		Localization.addLocalization(CarrierVessel_harden.name_locale, CarrierVessel_harden.name_locale);

	var Submarine_harden = AssetManager.actor_library.clone("Submarine_harden","$boat$");
	    Submarine_harden.id = "Submarine_harden";
		Submarine_harden.boat_type = "submarine_harden_boat";
		Submarine_harden.name_locale = "Cargo Ship";
		Submarine_harden.can_be_inspected = false;
		Submarine_harden.addDecision("boat_trading");
		Submarine_harden.addDecision("boat_transport_check");
		Submarine_harden.has_avatar_prefab = false;
		Submarine_harden.animation_speed_based_on_walk_speed = false;
		Submarine_harden.can_flip = true;
        Submarine_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    Submarine_harden.is_boat = true;
		Submarine_harden.die_in_lava = false;
		Submarine_harden.has_override_sprite = false;
	    Submarine_harden.has_override_avatar_frames = false;
		Submarine_harden.base_stats["mass_2"] = 3000f;
		Submarine_harden.base_stats["stamina"] = 1000f;
		Submarine_harden.base_stats["scale"] = 0.25f;
		Submarine_harden.base_stats["health"] = 2000f;
		Submarine_harden.base_stats["speed"] = 60f;
		Submarine_harden.base_stats["armor"] = 30f;
		Submarine_harden.base_stats["attack_speed"] = 0.3f;
		Submarine_harden.base_stats["damage"] = 300f;
		Submarine_harden.base_stats["knockback"] = 2f;
		Submarine_harden.base_stats["accuracy"] = 0.7f;
		Submarine_harden.base_stats["targets"] = 1f;
		Submarine_harden.base_stats["area_of_effect"] = 0.5f;
		Submarine_harden.base_stats["range"] = 200f;
		Submarine_harden.inspect_avatar_scale = 0.4f;
		Submarine_harden.sound_hit = "event:/SFX/HIT/HitMetal";
		Submarine_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportSpawn";
		Submarine_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportIdleLoop";
		Submarine_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatTransport/BoatTransportDeath";
		Submarine_harden.default_attack = "MissileSystemGaia";
		Submarine_harden.icon = "iconBoat";
		Submarine_harden.shadow_texture = "unitShadow_6";
		Submarine_harden.cost = new ConstructionCost(1, 0, 0, 1);
		Submarine_harden.texture_asset = new ActorTextureSubAsset("actors/Submarine_harden/");
		Submarine_harden.special = true;
		Submarine_harden.has_advanced_textures = false;
		Submarine_harden.draw_boat_mark = true;
		Submarine_harden.actor_size = ActorSize.S16_Buffalo;
		Submarine_harden.animation_walk = ActorAnimationSequences.walk_0;
		Submarine_harden.animation_idle = ActorAnimationSequences.walk_0;
		Submarine_harden.animation_swim = ActorAnimationSequences.swim_0_3;
		Submarine_harden.addTrait("boat");
		Submarine_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(Submarine_harden);
		Localization.addLocalization(Submarine_harden.name_locale, Submarine_harden.name_locale);

	var FishingBoat_harden = AssetManager.actor_library.clone("FishingBoat_harden","$boat$");
	    FishingBoat_harden.id = "FishingBoat_harden";
		FishingBoat_harden.boat_type = "fishing_harden_boat";
        FishingBoat_harden.skip_fight_logic = true;
        FishingBoat_harden.can_be_inspected = false;
		FishingBoat_harden.name_locale = "Cargo Ship";
		FishingBoat_harden.addDecision("boat_fishing");
		FishingBoat_harden.has_avatar_prefab = false;
		FishingBoat_harden.animation_speed_based_on_walk_speed = false;
		FishingBoat_harden.can_flip = true;
        FishingBoat_harden.check_flip = (BaseSimObject _, WorldTile _) => true;
	    FishingBoat_harden.is_boat = true;
		FishingBoat_harden.die_in_lava = false;
		FishingBoat_harden.has_override_sprite = false;
	    FishingBoat_harden.has_override_avatar_frames = false;
		FishingBoat_harden.base_stats["mass_2"] = 3000f;
		FishingBoat_harden.base_stats["stamina"] = 1000f;
		FishingBoat_harden.base_stats["scale"] = 0.25f;
		FishingBoat_harden.base_stats["health"] = 2000f;
		FishingBoat_harden.base_stats["speed"] = 60f;
		FishingBoat_harden.base_stats["armor"] = 30f;
		FishingBoat_harden.base_stats["attack_speed"] = 0.3f;
		FishingBoat_harden.base_stats["damage"] = 100f;
		FishingBoat_harden.base_stats["knockback"] = 2f;
		FishingBoat_harden.base_stats["accuracy"] = 0.7f;
		FishingBoat_harden.base_stats["targets"] = 1f;
		FishingBoat_harden.base_stats["area_of_effect"] = 0.5f;
		FishingBoat_harden.base_stats["range"] = 6f;
		FishingBoat_harden.inspect_avatar_scale = 0.4f;
		FishingBoat_harden.sound_hit = "event:/SFX/HIT/HitMetal";
		FishingBoat_harden.sound_spawn = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingSpawn";
		FishingBoat_harden.sound_idle_loop = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingIdleLoop";
		FishingBoat_harden.sound_death = "event:/SFX/UNITS/UNIQUE/BoatFishing/BoatFishingDeath";
		FishingBoat_harden.default_attack = "boat_cannonball";
		FishingBoat_harden.icon = "iconBoat";
		FishingBoat_harden.shadow_texture = "unitShadow_6";
		FishingBoat_harden.cost = new ConstructionCost(1, 0, 0, 1);
		FishingBoat_harden.texture_asset = new ActorTextureSubAsset("actors/FishingBoat_harden/");
		FishingBoat_harden.special = true;
		FishingBoat_harden.has_advanced_textures = false;
		FishingBoat_harden.draw_boat_mark = true;
		FishingBoat_harden.actor_size = ActorSize.S16_Buffalo;
		FishingBoat_harden.animation_walk = ActorAnimationSequences.walk_0;
		FishingBoat_harden.animation_idle = ActorAnimationSequences.walk_0;
		FishingBoat_harden.animation_swim = ActorAnimationSequences.swim_0_3;
		FishingBoat_harden.addTrait("boat");
		FishingBoat_harden.addTrait("light_lamp");
		AssetManager.actor_library.add(FishingBoat_harden);
		Localization.addLocalization(FishingBoat_harden.name_locale, FishingBoat_harden.name_locale);
















        }

public static readonly string[] idle_0 = Toolbox.a<string>("idle_0");

public static readonly string[] idle_0_2 = Toolbox.a<string>("idle_0", "idle_1", "idle_2");

public static readonly string[] idle_0_5 = Toolbox.a<string>("idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5" );

public static readonly string[] idle_0_7 = Toolbox.a<string>("idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7");

public static readonly string[] idle_0_8 = Toolbox.a<string>("idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7", "idle_8");

public static readonly string[] idle_0_9 = Toolbox.a<string>("idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7", "idle_8", "idle_9");

public static readonly string[] idle_0_13 = Toolbox.a<string>( "idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7", "idle_8", "idle_9", "idle_10", "idle_11", "idle_12", "idle_13" );

public static readonly string[] idle_0_15 = Toolbox.a<string>( "idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7", "idle_8", "idle_9", "idle_10", "idle_11", "idle_12", "idle_13", "idle_14", "idle_15" );

public static readonly string[] idle_0_19 = Toolbox.a<string>( "idle_0", "idle_1", "idle_2", "idle_3", "idle_4", "idle_5", "idle_6", "idle_7", "idle_8", "idle_9", "idle_10", "idle_11", "idle_12", "idle_13", "idle_14", "idle_15", "idle_16", "idle_17", "idle_18", "idle_19" );


public static readonly string[] walk_0_5 = Toolbox.a<string>("walk_0", "walk_1", "walk_2", "walk_3", "walk_4", "walk_5" );


public static readonly string[] swim_0_5 = Toolbox.a<string>("swim_0", "swim_1", "swim_2", "swim_3", "swim_4", "swim_5" );




       [HarmonyPatch(typeof(Actor), "setFamily")]
public static class Patch_Actor_Exclude_Unitpotential_Family
{
    static bool Prefix(Actor __instance, Family pObject)
    {
        if (__instance.hasTrait("Unitpotential"))
            return false;
        return true;
    }
}


[HarmonyPatch(typeof(Kingdom), "setKing")]
public static class Patch_Kingdom_Exclude_Unitpotential_King
{
    static bool Prefix(Kingdom __instance, Actor pActor, bool pNewKing)
    {
        if (pActor.hasTrait("Unitpotential"))
            return false;
        return true;
    }
}



[HarmonyPatch(typeof(City), "setLeader")]
public static class Patch_City_Exclude_Unitpotential_Leader
{
    static bool Prefix(City __instance, Actor pActor, bool pNew)
    {
        if (pActor.hasTrait("Unitpotential"))
            return false;
        return true;
    }
}



[HarmonyPatch(typeof(TileZone), nameof(TileZone.canBeClaimedByCity))]
public static class Patch_TileZone_CanBeClaimedByCity_Unitpotential
{
    static bool Prefix(TileZone __instance, City pCity, ref bool __result)
    {
        if (pCity != null && pCity.leader != null && pCity.leader.hasTrait("Unitpotential"))
        {
            __result = false;
            return false;
        }
        return true;
    }
}


[HarmonyPatch(typeof(TileZone), "isGoodForNewCity", new[] { typeof(Actor) })]
public static class Patch_TileZone_IsGoodForNewCity_Unitpotential
{
    static bool Prefix(TileZone __instance, Actor pActor, ref bool __result)
    {
        if (pActor != null && pActor.hasTrait("Unitpotential"))
        {
            __result = false;
            return false;
        }

        return true;
    }
}



[HarmonyPatch(typeof(Clan), "newClan")]
public static class Patch_Clan_NewClan
{
    static bool Prefix(Actor pFounder, bool pAddDefaultTraits)
    {
        return pFounder != null && !pFounder.hasTrait("Unitpotential");
    }
}


[HarmonyPatch(typeof(ai.behaviours.BehFightCheckEnemyIsOk), "execute")]
public static class BehFightCheckEnemyIsOk_Patch
{
    static bool Prefix(Actor pActor, ref BehResult __result)
    {
        if (!pActor.has_attack_target || !pActor.isEnemyTargetAlive())
        {
            __result = BehResult.Stop;
            return false;
        }

        Actor tTarget = pActor.attack_target as Actor;
        if (tTarget == null)
        {
            __result = BehResult.Stop;
            return false;
        }

        bool isValidMilitaryTarget = tTarget.isWarrior()
            || (tTarget.profession_asset != null && (
                tTarget.profession_asset.profession_id == UnitProfession.King ||
                tTarget.profession_asset.profession_id == UnitProfession.Leader))
            || tTarget.hasTrait("Unitpotential")
            || tTarget.hasTrait("boat")
            || tTarget.asset.is_boat;

        if (pActor.hasTrait("Unitpotential") && !isValidMilitaryTarget)
        {
            pActor.ignoreTarget(tTarget);
            pActor.clearAttackTarget();
            __result = BehResult.Stop;
            return false;
        }

        if (tTarget.isKingdomCiv() && tTarget.hasCity() && !isValidMilitaryTarget)
        {
            pActor.ignoreTarget(tTarget);
            pActor.clearAttackTarget();
            __result = BehResult.Stop;
            return false;
        }

        Kingdom actorKingdom = pActor.kingdom;
        if (pActor.hasTrait("UnitPotential") && pActor.city != null)
        {
            actorKingdom = pActor.city.kingdom;
        }

        if (!actorKingdom.isEnemy(tTarget.kingdom))
        {
            pActor.clearAttackTarget();
            __result = BehResult.Stop;
            return false;
        }

        if (!pActor.canAttackTarget(tTarget))
        {
            pActor.ignoreTarget(tTarget);
            pActor.clearAttackTarget();
            __result = BehResult.Stop;
            return false;
        }

        if (!pActor.isInAttackRange(tTarget))
        {
            if ((pActor.isWaterCreature() && (!tTarget.isInLiquid() && !pActor.asset.force_land_creature)) || tTarget.isFlying() ||
                (!pActor.isWaterCreature() && tTarget.isInLiquid()))
            {
                pActor.ignoreTarget(tTarget);
                pActor.clearAttackTarget();
                __result = BehResult.Stop;
                return false;
            }
        }

        if (Toolbox.Dist(pActor.chunk.x, pActor.chunk.y, tTarget.chunk.x, tTarget.chunk.y) >= SimGlobals.m.unit_chunk_sight_range + 1f)
        {
            pActor.clearAttackTarget();
            __result = BehResult.Stop;
            return false;
        }

        pActor.beh_actor_target = tTarget;
        __result = BehResult.Continue;
        return false;
    }
}



[HarmonyPatch(typeof(UtilityBasedDecisionSystem), "registerBasicDecisionLists")]
public static class Patch_UtilityBasedDecisionSystem_RegisterBasicDecisionLists
{
    static bool Prefix(Actor pActor, bool pGameplay)
    {
        if (pActor.asset.is_boat || pActor.hasTrait("Unitpotential"))
        {
            return false;
        }
        return true;
    }
}

[HarmonyPatch(typeof(ItemCrafting), nameof(ItemCrafting.tryToCraftRandomWeapon))]
public class Patch_TryToCraftRandomWeapon
{
    static bool Prefix(Actor pActor, City pCity)
    {
        if (pActor.hasTrait("Unitpotential"))
        {
            return false;
        }

        if (pActor.equipment?.getSlot(EquipmentType.Weapon) == null)
        {
            return false;
        }

        return true;
    }
}


[HarmonyPatch]
public static class Patch_ItemCrafting_ExcludeUnitpotential
{
    [HarmonyPrefix]
    [HarmonyPatch(typeof(ItemCrafting), nameof(ItemCrafting.tryToCraftRandomWeapon))]
    public static bool Prefix_Weapon(Actor pActor, City pCity)
    {
        return isSafeToCraft(pActor, EquipmentType.Weapon);
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(ItemCrafting), nameof(ItemCrafting.tryToCraftRandomArmor))]
    public static bool Prefix_Armor(Actor pActor, City pCity)
    {
        return isSafeToCraft(pActor, EquipmentType.Armor);
    }

    private static bool isSafeToCraft(Actor pActor, EquipmentType type)
    {
        if (pActor == null || pActor.hasTrait("Unitpotential"))
            return false;

        if (pActor.equipment == null)
            return false;

        if (pActor.equipment.getSlot(type) == null)
            return false;

        return true;
    }
}



        }
        }
