using HarmonyLib;

using ChivalryZhanXun.code;

using NeoModLoader.api;

namespace ChivalryZhanXun
{
    internal class ChivalryZhanXunClass : BasicMod<ChivalryZhanXunClass>
    {
        public static string id = "shiyue.worldbox.mod.ChivalryZhanXun";
        protected override void OnModLoad()
        {
            traitGroup.Init();
            traits.Init();
            SorceryEffect.Init();
            new Harmony(id).PatchAll(typeof(patch));
            new Harmony(id).PatchAll(typeof(ZhanXunConfig));
        }

    }

}
