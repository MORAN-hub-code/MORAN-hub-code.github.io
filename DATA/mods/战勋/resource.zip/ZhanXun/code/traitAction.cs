﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using ai.behaviours;
using UnityEngine;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool ZhanXun2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool ZhanXun3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(5);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(7);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(75);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun92_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(119);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun93_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun94_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(400);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun95_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(900);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun96_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun97_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4900);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool ZhanXun98_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        // 猎王者特殊效果 - 每120秒查找敌对国王并传送
        public static bool HunterKing_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return true;

            Actor actor = pTarget.a;
            if (actor == null || !actor.isAlive()) return true;
            
            // 检查冷却时间（120秒）
            int lastTeleportTime;
            actor.data.get("kingSlayerMasterTeleportTimer", out lastTeleportTime, 0);
            int currentTime = (int)BehaviourActionBase<Actor>.world.getCurWorldTime();
            
            if (currentTime - lastTeleportTime < 120) // 120秒冷却
            {
                return true;
            }

            // 查找所有国王并检查是否敌对
            foreach (var otherActor in World.world.units)
            {
                if (otherActor == null || !otherActor.isAlive() || otherActor == actor) continue;
                
                // 检查是否是国王
                if (otherActor.isKing())
                {
                    // 检查是否敌对
                    if (actor.areFoes(otherActor))
                    {
                        // 传送到敌对国王身边
                        if (otherActor.current_tile != null)
                        {
                        // 播放邪恶法师的红色传送特效
                        EffectsLibrary.spawnAt("fx_teleport_red", actor.current_position, actor.stats["scale"]);
                        BaseEffect tEffect = EffectsLibrary.spawnAt("fx_teleport_red", otherActor.current_tile.posV3, actor.stats["scale"]);
                        if (tEffect != null)
                        {
                            tEffect.sprite_animation.setFrameIndex(9);
                        }
                            
                            // 取消所有行为并传送到目标位置
                            actor.cancelAllBeh();
                            actor.spawnOn(otherActor.current_tile, 0f);
                            
                            // 播放红色粒子效果
                            actor.spawnParticle(Toolbox.color_red);
                            
                            // 记录传送时间
                            actor.data.set("kingSlayerMasterTeleportTimer", currentTime);
                            
                            // 只传送到第一个敌对国王，然后退出
                            break;
                        }
                    }
                }
            }

            return true;
        }
    }
}