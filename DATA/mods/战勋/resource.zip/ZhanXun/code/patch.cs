﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using UnityEngine;
using ai;
using ai.behaviours;
using EpPathFinding.cs;
using life.taxi;
using NeoModLoader.api.attributes;
using NeoModLoader.General;

namespace ChivalryZhanXun.code
{
    internal static class patch
    {
        // =============================
        // 基础映射与常量
        // =============================

        // 按阈值从小到大有序，使用时从后往前扫描，避免 Dictionary.Reverse 的不确定性
        private static readonly (int threshold, string traitId)[] KillRewardThresholdsAsc =
        {
            (1, "ZhanXun1"),
            (10, "ZhanXun2"),
            (20, "ZhanXun3"),
            (30, "ZhanXun4"),
            (50, "ZhanXun5"),
            (70, "ZhanXun6"),
            (100, "ZhanXun7"),
            (200, "ZhanXun8"),
            (300, "ZhanXun9"),
            (500, "ZhanXun91"),
            (700, "ZhanXun92"),
            (1000, "ZhanXun93"),
            (2000, "ZhanXun94"),
            (3000, "ZhanXun95"),
            (5000, "ZhanXun96"),
            (7000, "ZhanXun97"),
            (10000, "ZhanXun98")
        };

        private static string GetKillRewardTrait(int kills)
        {
            for (int i = KillRewardThresholdsAsc.Length - 1; i >= 0; --i)
            {
                if (kills >= KillRewardThresholdsAsc[i].threshold)
                    return KillRewardThresholdsAsc[i].traitId;
            }
            return null;
        }

        private static readonly Dictionary<string, int> ZhanXunLevels = new()
        {
            {"ZhanXun1", 1}, {"ZhanXun2", 2}, {"ZhanXun3", 3}, {"ZhanXun4", 4},
            {"ZhanXun5", 5}, {"ZhanXun6", 6}, {"ZhanXun7", 7}, {"ZhanXun8", 8},
            {"ZhanXun9", 9}, {"ZhanXun91", 10}, {"ZhanXun92", 11}, {"ZhanXun93", 12},
            {"ZhanXun94", 13}, {"ZhanXun95", 14}, {"ZhanXun96", 15}, {"ZhanXun97", 16},
            {"ZhanXun98", 17}
        };

        // >= 7 即原「受保护」段
        private static bool HasProtectedTrait(Actor actor) => GetZhanXunLevel(actor) >= 7 || actor.hasStatus("TheUnmovingWiseKing");

        private static readonly Dictionary<long, int> KingKillCounts = new();

        private static readonly Dictionary<long, Dictionary<string, float>> armySpellCooldowns = new();
        private static readonly Dictionary<long, Dictionary<string, float>> countrySpellCooldowns = new();

        private static readonly HashSet<string> MilitarismTraits = new()
        {
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97", "ZhanXun98"
        };

        private const string MilitarismKingdomTrait = "militarism";

        // 供 City.setCitizenJob 反射用：缓存字段信息，避免每次反射
        private static readonly System.Reflection.FieldInfo TimerWarriorField =
            AccessTools.Field(typeof(City), "_timer_warrior");
        private static readonly System.Reflection.FieldInfo LastCheckedJobIdField =
            AccessTools.Field(typeof(City), "_last_checked_job_id");

        // Army 队长反射缓存
        private static readonly System.Reflection.MethodInfo ArmyGetCaptainMI =
            AccessTools.Method(typeof(Army), "getCaptain");
        private static readonly System.Reflection.FieldInfo ArmyCaptainFI =
            AccessTools.Field(typeof(Army), "captain")
            ?? AccessTools.Field(typeof(Army), "leader")
            ?? AccessTools.Field(typeof(Army), "_captain");

        // 反射：行为目标 actor（供 BehGoToActorTarget / city_actor_attack_* 使用）
        private static readonly System.Reflection.FieldInfo BehActorTargetField =
            AccessTools.Field(typeof(Actor), "beh_actor_target");

        // 允许的 AI 任务白名单，静态缓存
        private static readonly HashSet<string> AllowedTasks = new()
        {
            "fighting",
            "warrior_army_follow_leader",
            "force_into_a_boat",
            "embark_into_boat",
            "sit_inside_boat",
            "taxi_check",
            "taxi_embark",
            "taxi_sit_inside",
            "taxi_find_ship_tile",
            "city_actor_warrior_taxi_check",
            "city_actor_attack_zone",
            "city_actor_attack_target",
            "city_actor_attack_building",
            "city_actor_attack_enemy_unit",
            "city_actor_attack_enemy_army",
            "city_actor_attack_enemy_city",
            "city_actor_attack_enemy_king",
            "city_actor_attack_enemy_leader",
            "check_warrior_transport",
            "boat_transport_check_taxi",
            "boat_transport_check",
            "boat_transport_go_load",
            "boat_transport_go_unload",
            "try_to_return_to_home_city",
            "warrior_try_join_army_group",
            "BehGoToActorTarget",
            "BehFightCheckEnemyIsOk"
        };

        private static readonly Dictionary<KingdomData, bool> MilitarismField = new();
        public static bool GetMilitarism(KingdomData data) => MilitarismField.TryGetValue(data, out var v) && v;
        public static void SetMilitarism(KingdomData data, bool value) => MilitarismField[data] = value;

        private static float lastForceCheckTime = 0f;
        private const float FORCE_CHECK_INTERVAL = 10f; // 每 10 秒做一次全城强制检查

        private static float lastArmyHeavyUpdate = 0f;
        private const float ARMY_HEAVY_UPDATE_INTERVAL = 0.25f; // 军队重逻辑节流（秒）

        // shareResource 调用保护，避免 StackTrace
        private static bool _inShareResource = false;

        // 主动寻敌节流
        private const float ARMY_SEEK_INTERVAL = 1.5f; // 每支军队寻敌节流秒数
        private const int ARMY_SEEK_RADIUS = 40;       // 寻敌半径（格子）
        private static readonly Dictionary<long, float> _armySeekCD = new();

        // =============================
        // 工具方法
        // =============================
        private static int GetZhanXunLevel(Actor actor)
        {
            if (actor == null) return 0;
            int highestLevel = 0;
            foreach (var trait in actor.getTraits())
            {
                if (trait.group_id == "ZhanXun" && ZhanXunLevels.TryGetValue(trait.id, out int level))
                    if (level > highestLevel) highestLevel = level;
            }
            return highestLevel;
        }

        private static int GetKingKillCount(Actor actor)
        {
            if (actor == null) return 0;
            return KingKillCounts.TryGetValue(actor.getID(), out int count) ? count : 0;
        }

        private static void IncrementKingKillCount(Actor actor)
        {
            if (actor == null) return;
            long id = actor.getID();
            if (KingKillCounts.ContainsKey(id)) KingKillCounts[id]++;
            else KingKillCounts[id] = 1;
        }

        private static Actor FindHighestZhanXunActor(IEnumerable<Actor> actors)
        {
            Actor best = null;
            int bestLevel = -1;
            foreach (var actor in actors)
            {
                if (actor == null || !actor.isAlive()) continue;
                int lv = GetZhanXunLevel(actor);
                if (lv > bestLevel) { bestLevel = lv; best = actor; }
            }
            return best;
        }

        private static bool IsPersonalArmy(Army army) => true;

        // 安全获取队长：先尝试 getCaptain()，再尝试常见私有字段名（已缓存）
        private static Actor CaptainOf(Army army)
        {
            if (army == null) return null;

            if (ArmyGetCaptainMI != null)
            {
                try { return (Actor)ArmyGetCaptainMI.Invoke(army, null); } catch { /* ignore */ }
            }

            if (ArmyCaptainFI != null)
            {
                try { return (Actor)ArmyCaptainFI.GetValue(army); } catch { /* ignore */ }
            }

            return null;
        }

        private static City FindNearestEnemyCity(Actor captain)
        {
            if (captain == null || !captain.hasCity()) return null;
            City myCity = captain.getCity();
            Kingdom myKingdom = myCity?.kingdom;
            if (myCity == null || myKingdom == null) return null;

            City nearest = null;
            float bestDist = float.MaxValue;
            foreach (var city in World.world.cities)
            {
                if (city == null || city == myCity) continue;
                if (city.kingdom != null && myKingdom.isEnemy(city.kingdom))
                {
                    var zone = (city.zones != null && city.zones.Count > 0) ? city.zones[0] : null;
                    var tile = zone?.centerTile;
                    if (tile == null) continue;
                    float d = Toolbox.SquaredDistTile(captain.current_tile, tile);
                    if (d < bestDist) { bestDist = d; nearest = city; }
                }
            }
            return nearest;
        }

        private static City FindEnemyCapital(Kingdom kingdom)
        {
            if (kingdom == null) return null;
            City myCapital = kingdom.capital;
            var myZone = myCapital?.zones != null && myCapital.zones.Count > 0 ? myCapital.zones[0] : null;
            var myTile = myZone?.centerTile;
            if (myTile == null) return null;

            City nearest = null;
            float bestDist = float.MaxValue;
            foreach (var city in World.world.cities)
            {
                if (city?.kingdom == null) continue;
                if (kingdom.isEnemy(city.kingdom) && city.kingdom.capital == city)
                {
                    var zone = (city.zones != null && city.zones.Count > 0) ? city.zones[0] : null;
                    var tile = zone?.centerTile;
                    if (tile == null) continue;
                    float d = Toolbox.SquaredDistTile(myTile, tile);
                    if (d < bestDist) { bestDist = d; nearest = city; }
                }
            }
            return nearest;
        }

        private static void SyncMilitarismLeaders(Kingdom kingdom)
        {
            if (!GetMilitarism(kingdom.data)) return;

            var allUnits = kingdom.getUnits();
            var best = FindHighestZhanXunActor(allUnits);
            var oldKing = kingdom.king;

            if (best != null && best != oldKing &&
                (oldKing == null || GetZhanXunLevel(best) > GetZhanXunLevel(oldKing)))
            {
                if (best.city != null && best.city.leader == best)
                {
                    best.city.removeLeader();
                    best.setProfession(UnitProfession.Unit, true);
                }
                if (best.isWarrior()) best.stopBeingWarrior();
                best.setProfession(UnitProfession.Unit, true);

                if (oldKing != null)
                {
                    int year = Date.getYear(World.world.getCurWorldTime());
                    new WorldLogMessage(
                        WorldLogLibrary.king_new,
                        kingdom.name,
                        $"{kingdom.name}：{oldKing.getName()}于{year}年将王位传位于{best.getName()}",
                        year.ToString()
                    ).add();

                    kingdom.removeKing();

                    if (oldKing.city != null && oldKing.city.leader == oldKing)
                    {
                        oldKing.city.removeLeader();
                        oldKing.setProfession(UnitProfession.Unit, true);
                    }
                    if (oldKing.isWarrior()) oldKing.stopBeingWarrior();
                    if (oldKing.isKing()) oldKing.setProfession(UnitProfession.Unit, true);
                }

                kingdom.setKing(best, true);
                best.startShake();
                best.startColorEffect();
            }
        }

        private static Actor SelectBestCaptainFromArmy(Army army, City armyCity, WorldTile prevCaptainPos)
        {
            Actor best = null;
            int bestLevel = -1;
            int bestDist = int.MaxValue;

            foreach (var u in army.units)
            {
                if (u == null || !u.isAlive() || u.army != army) continue;
                if (armyCity != null)
                {
                    if (u.city != armyCity) continue;
                    if (u.city.kingdom != null && armyCity.kingdom != null && u.city.kingdom != armyCity.kingdom) continue;
                }

                int level = GetZhanXunLevel(u);
                if (level <= 0) continue;

                int dist = int.MaxValue;
                if (prevCaptainPos != null) dist = Toolbox.SquaredDistTile(u.current_tile, prevCaptainPos);

                if (level > bestLevel || (level == bestLevel && dist < bestDist))
                {
                    best = u;
                    bestLevel = level;
                    bestDist = dist;
                }
            }

            // 没有战勋则选战士
            if (best == null)
            {
                Actor nearestWarrior = null;
                int nearestDist = int.MaxValue;
                foreach (var u in army.units)
                {
                    if (u == null || !u.isAlive() || u.army != army || !u.isWarrior()) continue;
                    if (armyCity != null)
                    {
                        if (u.city != armyCity) continue;
                        if (u.city.kingdom != null && armyCity.kingdom != null && u.city.kingdom != armyCity.kingdom) continue;
                    }
                    int dist = prevCaptainPos == null ? 0 : Toolbox.SquaredDistTile(u.current_tile, prevCaptainPos);
                    if (nearestWarrior == null || dist < nearestDist)
                    {
                        nearestWarrior = u;
                        nearestDist = dist;
                    }
                }
                best = nearestWarrior;
            }

            // 仍没有则找最近的任意单位
            if (best == null)
            {
                Actor nearest = null;
                int nearestDist = int.MaxValue;
                foreach (var u in army.units)
                {
                    if (u == null || !u.isAlive() || u.army != army) continue;
                    if (armyCity != null)
                    {
                        if (u.city != armyCity) continue;
                        if (u.city.kingdom != null && armyCity.kingdom != null && u.city.kingdom != armyCity.kingdom) continue;
                    }
                    int dist = prevCaptainPos == null ? 0 : Toolbox.SquaredDistTile(u.current_tile, prevCaptainPos);
                    if (nearest == null || dist < nearestDist)
                    {
                        nearest = u;
                        nearestDist = dist;
                    }
                }
                best = nearest;
            }

            // 兜底
            if (best == null)
            {
                foreach (var u in army.units)
                {
                    if (u != null && u.isAlive()) { best = u; break; }
                }
            }

            return best;
        }

        private static bool IsKingdomInWar(Kingdom kingdom)
        {
            if (kingdom == null) return false;

            foreach (var war in World.world.wars.getWars(kingdom))
                if (war != null && !war.hasEnded()) return true;

            foreach (var other in World.world.kingdoms)
                if (other != null && other != kingdom && kingdom.isEnemy(other)) return true;

            return false;
        }

        private static bool IsSpellRequireWar(string spellId)
        {
            // 战时限定的法术
            return spellId is "Johnson" or "Selfde" or "Ironarmor" or "TheUnmovingWiseKing" or
                   "Accelerate" or "Strongwind"  or "Yufeng" or "enhancement" or "andblood" or "Overload" or "evilenergy_aura" or "teleport";
        }

        // 新增：统一判断是否应屏蔽「占领」
        private static bool ShouldBlockCapture(City city)
        {
            if (city == null) return false;
            // 全局开关 或 军国化国家
            if (ZhanXunConfig.AutoCollectCity) return true;
            if (city.kingdom == null) return false;
            return GetMilitarism(city.kingdom.data);
        }

        private static void CheckAndUpdateCaptain(Army army)
        {
            if (army == null || army.units.Count == 0) return;
            City city = army.getCity();
            var best = SelectBestCaptainFromArmy(army, city, CaptainOf(army)?.current_tile);

            var current = CaptainOf(army);
            if (best != null && (current == null || best != current))
            {
                if (current == null || GetZhanXunLevel(best) > GetZhanXunLevel(current))
                    army.setCaptain(best);
            }
        }

        private static void CreateArmyForCity(City city)
        {
            var list = city.units;
            Actor best = null;
            int bestLv = -1;
            foreach (var u in list)
            {
                if (u == null || !u.isAlive() || u.city != city || u.army != null || u.isKing() || u.isCityLeader()) continue;
                if (u.city.kingdom != null && city.kingdom != null && u.city.kingdom != city.kingdom) continue;
                int lv = GetZhanXunLevel(u);
                if (lv > bestLv) { bestLv = lv; best = u; }
            }
            if (best != null)
            {
                var newArmy = World.world.armies.newArmy(best, city);
                newArmy?.setCaptain(best);
            }
        }

        private static void FixArmyCaptain(Army army, City city)
        {
            if (army.units.Count > 0)
            {
                army.findCaptain();
                return;
            }

            // 先找战士
            Actor best = null;
            int bestLv = -1;
            foreach (var u in city.units)
            {
                if (u == null || !u.isAlive() || u.city != city || u.army != null) continue;
                if (u.city.kingdom != null && city.kingdom != null && u.city.kingdom != city.kingdom) continue;
                if (!u.isWarrior()) continue;
                int lv = GetZhanXunLevel(u);
                if (lv > bestLv) { bestLv = lv; best = u; }
            }
            if (best != null)
            {
                best.setArmy(army);
                army.setCaptain(best);
                return;
            }

            // 任意合适单位
            best = null; bestLv = -1;
            foreach (var u in city.units)
            {
                if (u == null || !u.isAlive() || u.city != city || u.army != null || u.isKing() || u.isCityLeader()) continue;
                if (u.city.kingdom != null && city.kingdom != null && u.city.kingdom != city.kingdom) continue;
                int lv = GetZhanXunLevel(u);
                if (lv > bestLv) { bestLv = lv; best = u; }
            }
            if (best != null)
            {
                best.setArmy(army);
                army.setCaptain(best);
            }
        }

        // City 私有字段访问封装
        private static float GetTimerWarrior(City c)
        {
            if (TimerWarriorField == null) return 0f;
            var v = TimerWarriorField.GetValue(c);
            return v is float f ? f : 0f;
        }
        private static void SetTimerWarrior(City c, float v)
        {
            TimerWarriorField?.SetValue(c, v);
        }
        private static int IncAndGetLastCheckedJobId(City c, int max)
        {
            if (LastCheckedJobIdField == null || max <= 0) return 0;
            int cur = 0;
            var v = LastCheckedJobIdField.GetValue(c);
            if (v is int i) cur = i;
            cur++;
            if (cur > max - 1) cur = 0;
            LastCheckedJobIdField.SetValue(c, cur);
            return cur;
        }

        // =============================
        // 法术定义
        // =============================
        private class ArmySpell
        {
            public string id;
            public string statusId;
            public float duration;
            public float cooldown;
            public int minZhanXunLevel;
            public int maxZhanXunLevel;
            public string displayName;
        }

        private static readonly ArmySpell[] ArmySpells =
        {
            new() { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new() { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new() { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new() { id = "TheUnmovingWiseKing", statusId = "TheUnmovingWiseKing", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "不动明王" },
            new() { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new() { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new() { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new() { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new() { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new() { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new() { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new() { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 17, displayName = "御风术" },
            new() { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new() { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new() { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new() { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new() { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" }
        };

        private class CountrySpell
        {
            public string id;
            public string statusId;
            public float duration;
            public float cooldown;
            public int minZhanXunLevel;
            public int maxZhanXunLevel;
            public string displayName;
        }

        private static readonly CountrySpell[] CountrySpells =
        {
            new() { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new() { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new() { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new() { id = "TheUnmovingWiseKing", statusId = "TheUnmovingWiseKing", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "不动明王" },
            new() { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new() { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new() { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new() { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new() { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new() { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new() { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new() { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 17, displayName = "御风术" },
            new() { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new() { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new() { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new() { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new() { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" }
        };

        // =============================
        // Patch：击杀/战勋/王杀
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance, Actor pDeadUnit)
        {
            if (__instance == null || !__instance.isAlive()) return;

            // 直接用 0~1 的滑条作为掠夺比例
            float ratio = Mathf.Clamp01(ZhanXunConfig.AutoCollectPlunder);
            if (pDeadUnit != null && pDeadUnit.data != null && ratio > 0f)
            {
                int victimKills = pDeadUnit.data.kills;
                if (victimKills > 0)
                {
                    long add = (long)Mathf.Round(victimKills * ratio); // 需要向下取整可用 Mathf.Floor
                    if (add > 0)
                    {
                        long total = (long)__instance.data.kills + add; // 原方法已 +1，这里是额外叠加
                        if (total > int.MaxValue) total = int.MaxValue;  // 防溢出
                        __instance.data.kills = (int)total;
                    }
                }
            }

            // 王杀统计（原逻辑）
            if (pDeadUnit != null && pDeadUnit.isKing())
            {
                IncrementKingKillCount(__instance);
                if (GetKingKillCount(__instance) >= 10 && !__instance.hasTrait("HunterKing"))
                    __instance.addTrait("HunterKing", false);
            }

            // 战勋奖励（基于叠加后的最终击杀数）
            string highestTraitId = GetKillRewardTrait(__instance.data.kills);
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                var toRemove = new List<ActorTrait>();
                foreach (var t in __instance.getTraits())
                    if (t.group_id == "ZhanXun") toRemove.Add(t);
                if (toRemove.Count > 0) __instance.removeTraits(toRemove);

                __instance.addTrait(highestTraitId, false);

                if (__instance.data.kills >= 1 && !__instance.hasTrait("fire_proof"))
                    __instance.addTrait("fire_proof", false);
                if (__instance.data.kills >= 100 && !__instance.hasTrait("freeze_proof"))
                    __instance.addTrait("freeze_proof", false);
                if (__instance.data.kills >= 100 && !__instance.hasTrait("immune"))
                    __instance.addTrait("immune", false);
                if (__instance.data.kills >= 100 && !__instance.hasTrait("strong_minded"))
                    __instance.addTrait("strong_minded", false);
            }
        }

        // =============================
        // Patch：市民分工/招募（只在接管时拦截）
        // =============================
        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "setCitizenJob")]
        public static bool City_setCitizenJob_Prefix(City __instance, Actor pActor)
        {
            if (pActor == null || pActor.city != __instance || pActor.city == null || pActor.city.kingdom != __instance.kingdom)
                return true;
            if (pActor.isKing() || pActor.isCityLeader())
                return true;
            if (pActor.getCity() != __instance)
                return true;
            if (pActor.army != null && pActor.army.getCity() != __instance)
                return true;
            if (pActor.city != null && pActor.city.kingdom != __instance.kingdom)
                return true;

            bool handled = false;
            bool hasZhanXun = pActor.getTraits().Any(trait => trait.group_id == "ZhanXun");
            if (hasZhanXun && __instance.checkCanMakeWarrior(pActor))
            {
                __instance.makeWarrior(pActor);
                SetTimerWarrior(__instance, 15f);
                handled = true;
            }
            else if (!__instance.isGettingCaptured() &&
                     GetTimerWarrior(__instance) <= 0f &&
                     pActor.isProfession(UnitProfession.Unit) &&
                     __instance.getResourcesAmount("gold") > 10 &&
                     __instance.hasEnoughFoodForArmy() &&
                     __instance.tryToMakeWarrior(pActor))
            {
                handled = true;
            }
            else if (__instance.checkCitizenJobList(AssetManager.citizen_job_library.list_priority_high, pActor))
            {
                handled = true;
            }
            else if (!__instance.hasAnyFood() &&
                     __instance.checkCitizenJobList(AssetManager.citizen_job_library.list_priority_high_food, pActor))
            {
                handled = true;
            }
            else
            {
                List<CitizenJobAsset> tJobList = AssetManager.citizen_job_library.list_priority_normal;
                for (int i = 0; i < tJobList.Count; i++)
                {
                    int idx = IncAndGetLastCheckedJobId(__instance, tJobList.Count);
                    var job = tJobList[idx];
                    if ((job.ok_for_king || !pActor.isKing()) && (job.ok_for_leader || !pActor.isCityLeader()) &&
                        __instance.checkCitizenJob(job, __instance, pActor))
                    {
                        handled = true;
                        break;
                    }
                }
            }
            return handled ? false : true;
        }

        // =============================
        // Patch：军队-队长设置限制
        // =============================
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), nameof(Army.setCaptain))]
        public static bool Army_setCaptain_Prefix(Army __instance, Actor pActor)
        {
            if (pActor != null)
            {
                var armyCity = __instance.getCity();
                if (armyCity != null)
                {
                    if (pActor.city == null || pActor.city != armyCity)
                        return false;
                    if (pActor.city.kingdom != null && armyCity.kingdom != null &&
                        pActor.city.kingdom != armyCity.kingdom)
                        return false;
                }
            }
            return true;
        }

        // =============================
        // Patch：军队-选择队长（改良）
        // =============================
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), "findCaptain")]
        public static bool Army_findCaptain_Prefix(Army __instance)
        {
            if (__instance == null) return true;

            var curCap = CaptainOf(__instance);
            if (__instance.hasCaptain() && (curCap == null || curCap.isRekt() || !curCap.isAlive()))
                __instance.setCaptain(null);

            curCap = CaptainOf(__instance);
            if (__instance.hasCaptain() && curCap != null && curCap.isKingdomCiv())
                return true;

            if (__instance.hasCaptain()) __instance.setCaptain(null);
            if (__instance.units.Count == 0) return true;

            City armyCity = __instance.getCity();
            var best = SelectBestCaptainFromArmy(__instance, armyCity, curCap?.current_tile);
            if (best != null) __instance.setCaptain(best);
            return false;
        }

        // =============================
        // Patch：控制免击飞/免控
        // =============================
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
        public static bool applyForceToUnit_Protection(AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
            => !(pTargetToCheck.isActor() && HasProtectedTrait(pTargetToCheck.a));

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
            => !HasProtectedTrait(__instance);

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
            => !HasProtectedTrait(__instance);

        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
            => !HasProtectedTrait(__instance);

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
                return !HasProtectedTrait(__instance);
            return true;
        }

        // =============================
        // Patch：军队 units 清理
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.updateDirtyUnits))]
        public static void ArmyManager_updateDirtyUnits_Postfix(ArmyManager __instance)
        {
            foreach (var army in World.world.armies)
            {
                if (army == null) continue;
                var armyCity = army.getCity();
                if (armyCity == null || army.units == null) continue;

                var toRemove = new List<Actor>();
                foreach (var unit in army.units)
                {
                    if (unit == null || unit.army != army || unit.city == null || unit.city != armyCity)
                        toRemove.Add(unit);
                }

                if (toRemove.Count > 0 && toRemove.Count < army.units.Count)
                {
                    foreach (var u in toRemove)
                        u?.removeFromArmy();
                }
            }
        }

        // =============================
        // 主动寻敌工具
        // =============================
        private static Actor FindNearestEnemyUnit(WorldTile center, Kingdom myKingdom, int radius)
        {
            if (center == null || myKingdom == null) return null;
            float radius2 = radius * radius;
            Actor best = null;
            float bestDist = float.MaxValue;

            foreach (var k in World.world.kingdoms)
            {
                if (k == null || !myKingdom.isEnemy(k)) continue;

                foreach (var u in k.getUnits())
                {
                    if (u == null || !u.isAlive()) continue;
                    if (u.current_tile == null || !u.current_tile.isSameIsland(center)) continue;

                    float d = Toolbox.SquaredDistTile(center, u.current_tile);
                    if (d > radius2) continue;

                    int prio = (u.isKing() ? 3 : (u.isCityLeader() ? 2 : (u.isWarrior() ? 1 : 0)));
                    int bestPrio = (best == null ? -1 : (best.isKing() ? 3 : (best.isCityLeader() ? 2 : (best.isWarrior() ? 1 : 0))));

                    if (prio > bestPrio || (prio == bestPrio && d < bestDist))
                    {
                        best = u;
                        bestDist = d;
                    }
                }
            }
            return best;
        }

        // 安全封装，避免 AiSystem.setTask 引发 NRE
        private static bool SafeSetTask(Actor actor, string taskId, bool clean = true, bool cleanJob = false, bool forceAction = true)
        {
            if (actor == null || !actor.isAlive() || actor.ai == null) return false;
            try
            {
                actor.setTask(taskId, clean, cleanJob, forceAction);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static void OrderArmyAttackTarget(List<Actor> units, Actor target)
        {
            if (target == null || !target.isAlive()) return;

            foreach (var m in units)
            {
                if (m == null || !m.isAlive() || m.ai == null) continue;

                // 尝试设置行为目标引用（非必须）
                try { BehActorTargetField?.SetValue(m, target); } catch { /* ignore */ }

                bool assigned = false;

                // 优先使用已有的“城市攻击单位/目标”任务；切换 job 以保证可用
                if (m.city != null)
                {
                    assigned = SafeSetTask(m, "city_actor_attack_enemy_unit", clean: true, cleanJob: true, forceAction: true)
                            || SafeSetTask(m, "city_actor_attack_target", clean: true, cleanJob: true, forceAction: true);
                }

                // 回退：直接战斗
                if (!assigned)
                {
                    assigned = SafeSetTask(m, "fighting", clean: true, cleanJob: false, forceAction: true);
                }
                // 再回退：跟随队长
                if (!assigned)
                {
                    SafeSetTask(m, "warrior_army_follow_leader", clean: true, cleanJob: false, forceAction: true);
                }
            }
        }

        // =============================
        // Patch：军队 AI + 军队法术（合并并节流 + 主动寻敌）
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.update))]
        public static void ArmyManager_update_Postfix(ArmyManager __instance, float pElapsed)
        {
            lastArmyHeavyUpdate += pElapsed;
            if (lastArmyHeavyUpdate < ARMY_HEAVY_UPDATE_INTERVAL) return;
            float dt = lastArmyHeavyUpdate;
            lastArmyHeavyUpdate = 0f;

            foreach (var army in World.world.armies)
            {
                var armyCity = army.getCity();

                // 队长城市一致性检查
                var captain = CaptainOf(army);
                if (armyCity != null && captain != null)
                {
                    if (captain.city == null ||
                        captain.city != armyCity ||
                        (captain.city.kingdom != null && armyCity.kingdom != null &&
                         captain.city.kingdom != armyCity.kingdom))
                    {
                        army.setCaptain(null);
                        captain = null;
                    }
                }

                if (!IsPersonalArmy(army)) continue;
                if (captain == null || !captain.isAlive()) { CheckAndUpdateCaptain(army); captain = CaptainOf(army); }
                if (captain == null || !captain.isAlive() || captain.current_tile == null) continue;

                // 军队成员集合（去重）
                var allMembers = new List<Actor>(army.units.Count + 1);
                allMembers.Add(captain);
                foreach (var u in army.units)
                {
                    if (u != null && u.isAlive() && u != captain) allMembers.Add(u);
                }

                // 清理携带资源、情感、饱食、心情、去负面等（保留原有玩法）
                foreach (var member in allMembers)
                {
                    if (member == null || !member.isAlive()) continue;

                    if (member.isCarryingResources()) member.giveInventoryResourcesToCity();
                    if (member.loot > 0) member.takeAllOwnLoot();

                    var lover = member.lover;
                    if (lover != null && lover != member && !member.isClonedFrom(lover) && !member.isChildOf(lover) && !member.isParentOf(lover))
                    {
                        if (!(member.hasLover() && member.lover == lover)) member.becomeLoversWith(lover);
                    }

                    if (lover != null &&
                        member.isSexFemale() && member.canBreed() && lover.canBreed() &&
                        member.isAdult() && lover.isAdult() &&
                        !member.hasReachedOffspringLimit() &&
                        !member.hasStatus("afterglow") && !lover.hasStatus("afterglow") &&
                        !member.hasStatus("pregnant") &&
                        member.city != null &&
                        member.city.getPopulationPeople() < member.city.getPopulationMaximum() * 2)
                    {
                        float maturationTime = member.getMaturationTimeSeconds();
                        member.addStatusEffect("pregnant", maturationTime, true);
                        float afterglowTime = maturationTime + 60f;
                        member.addStatusEffect("afterglow", afterglowTime, true);
                        lover.addStatusEffect("afterglow", afterglowTime, true);
                    }

                    if (member.isHungry())
                    {
                        member.addNutritionFromEating(member.getMaxNutrition(), false, true);
                        member.countConsumed();
                    }

                    if (member.isWarrior() && member.getHappiness() < 50)
                    {
                        int newHappy = Mathf.Min(member.getHappiness() + 20, member.getMaxHappiness());
                        member.setHappiness(newHappy, true);
                    }

                    if (member.hasStatus("burning")) member.finishStatusEffect("burning");
                    if (member.hasTrait("crippled")) member.removeTrait("crippled");
                    if (member.hasTrait("eyepatch")) member.removeTrait("eyepatch");
                    if (member.hasTrait("skin_burns")) member.removeTrait("skin_burns");

                    if (member.city != null && member.city.hasAttackZoneOrder())
                    {
                        var targetTile = member.city.target_attack_zone.centerTile;
                        if (targetTile != null && member.current_tile != null && !targetTile.isSameIsland(member.current_tile))
                            TaxiManager.newRequest(member, targetTile);
                    }

                    // 非队长才做跟随与脱困
                    if (member == captain) continue;

                    var curTask = member.ai?.task?.id;
                    if (string.IsNullOrEmpty(curTask) || !AllowedTasks.Contains(curTask))
                    {
                        member.cancelAllBeh();
                        SafeSetTask(member, "warrior_army_follow_leader", true, false, true);
                    }

                    // 简单“卡路检测”与救援
                    if (member.ai?.task?.id == "warrior_army_follow_leader")
                    {
                        bool isStuck = false;

                        if (member.current_path == null || member.current_path.Count == 0)
                        {
                            var testPath = new List<WorldTile>();
                            var param = World.world.pathfinding_param;
                            param.resetParam();
                            param.block = false;
                            param.lava = !member.asset.die_in_lava;
                            param.ocean = member.isWaterCreature();
                            param.ground = (!member.isWaterCreature() || member.asset.force_land_creature);

                            if (!PathfinderTools.tryToGetSimplePath(member.current_tile, captain.current_tile, testPath, member.asset, param))
                                isStuck = true;
                        }
                        else if (member.beh_tile_target != null)
                        {
                            var testPath = new List<WorldTile>();
                            var param = World.world.pathfinding_param;
                            param.resetParam();
                            param.block = false;
                            param.lava = !member.asset.die_in_lava;
                            param.ocean = member.isWaterCreature();
                            param.ground = (!member.isWaterCreature() || member.asset.force_land_creature);

                            if (!PathfinderTools.tryToGetSimplePath(member.current_tile, member.beh_tile_target, testPath, member.asset, param))
                                isStuck = true;
                        }

                        if (isStuck)
                        {
                            WorldTile targetTile = captain.current_tile;
                            if (targetTile != null)
                            {
                                var nearbyTiles = new List<WorldTile>();
                                for (int dx = -3; dx <= 3; dx++)
                                {
                                    for (int dy = -3; dy <= 3; dy++)
                                    {
                                        var tile = World.world.GetTile(targetTile.pos.x + dx, targetTile.pos.y + dy);
                                        if (tile != null && !tile.Type.block && !tile.Type.lava &&
                                            (member.isWaterCreature() ? tile.Type.ocean : tile.Type.ground))
                                        {
                                            nearbyTiles.Add(tile);
                                        }
                                    }
                                }

                                if (nearbyTiles.Count > 0)
                                {
                                    WorldTile bestTile = nearbyTiles[0];
                                    float bestScore = float.MaxValue;
                                    foreach (var tile in nearbyTiles)
                                    {
                                        float d = Toolbox.SquaredDistTile(tile, captain.current_tile);
                                        if (d >= 4f && d <= 16f && d < bestScore)
                                        {
                                            bestScore = d;
                                            bestTile = tile;
                                        }
                                    }

                                    if (bestScore == float.MaxValue)
                                    {
                                        float bestDist = float.MaxValue;
                                        foreach (var tile in nearbyTiles)
                                        {
                                            float d = Toolbox.SquaredDistTile(tile, captain.current_tile);
                                            if (d < bestDist)
                                            {
                                                bestDist = d;
                                                bestTile = tile;
                                            }
                                        }
                                    }

                                    member.cancelAllBeh();
                                    member.spawnOn(bestTile, 0f);
                                    SafeSetTask(member, "warrior_army_follow_leader", true, false, true);
                                }
                            }
                        }
                    }
                }

                // 判断是否有人在战斗
                bool anyFighting = false;
                foreach (var m in allMembers) { if (m != null && m.isAlive() && m.isFighting()) { anyFighting = true; break; } }

                // 主动寻敌：当没人战斗时，按节流寻找附近敌方单位并下达攻击
                long armyId = army.data.id;
                if (!anyFighting)
                {
                    float seekCd = 0f;
                    _armySeekCD.TryGetValue(armyId, out seekCd);
                    seekCd -= dt;

                    if (seekCd <= 0f)
                    {
                        _armySeekCD[armyId] = ARMY_SEEK_INTERVAL;

                        var centerTile = captain.current_tile;
                        var myKingdom = armyCity?.kingdom ?? captain.kingdom;
                        if (centerTile != null && myKingdom != null)
                        {
                            var enemy = FindNearestEnemyUnit(centerTile, myKingdom, ARMY_SEEK_RADIUS);
                            if (enemy != null)
                            {
                                OrderArmyAttackTarget(allMembers, enemy);
                                // 可选：提前认为进入战斗态，从而触发“战斗限定法术”
                                // anyFighting = true;
                            }
                        }
                    }
                    else
                    {
                        _armySeekCD[armyId] = seekCd;
                    }
                }

                // 军队法术（以队长战勋为门槛）
                int captainZhanXunLevel = GetZhanXunLevel(captain);
                if (!armySpellCooldowns.ContainsKey(armyId))
                    armySpellCooldowns[armyId] = new Dictionary<string, float>();
                var cooldownDict = armySpellCooldowns[armyId];

                if (ZhanXunConfig.AutoCollectMilitarymagic)
                {
                    foreach (var spell in ArmySpells)
                    {
                        if (captainZhanXunLevel < spell.minZhanXunLevel || captainZhanXunLevel > spell.maxZhanXunLevel)
                            continue;

                        cooldownDict.TryGetValue(spell.id, out float cd);
                        cd = Mathf.Max(0f, cd - dt);
                        cooldownDict[spell.id] = cd;
                        if (cd > 0f) continue;

                        // 部分法术仅在战斗时释放
                        if (spell.id is "Johnson" or "Selfde" or "Ironarmor" or "TheUnmovingWiseKing" or
                            "enhancement" or "andblood" or "Overload" or "evilenergy_aura")
                        {
                            if (!anyFighting) continue;
                        }

                        bool ok = false;
                        if (spell.id == "teleport")
                        {
                            if (!ZhanXunConfig.AutoCollectMilitaryteleportation)
                            {
                                continue;
                            }
                            City targetCity = FindNearestEnemyCity(captain);
                            if (targetCity != null)
                            {
                                var zone = targetCity.zones.GetRandom<TileZone>();
                                var tile = zone?.centerTile;
                                if (tile != null)
                                {
                                    foreach (var m in allMembers)
                                    {
                                        if (m != null && m.isAlive())
                                        {
                                            ActionLibrary.teleportEffect(m, tile);
                                            m.cancelAllBeh();
                                            m.spawnOn(tile, 0f);
                                        }
                                    }
                                    ok = true;
                                }
                            }
                        }
                        else
                        {
                            foreach (var m in allMembers)
                            {
                                if (m == null || !m.isAlive()) continue;

                                switch (spell.id)
                                {
                                    case "heal_small":
                                        m.restoreHealth(m.getMaxHealthPercent(0.1f)); ok = true; break;
                                    case "heal_medium":
                                        m.restoreHealth(m.getMaxHealthPercent(0.2f)); ok = true; break;
                                    case "heal_large":
                                        m.restoreHealth(m.getMaxHealthPercent(0.5f)); ok = true; break;
                                    case "heal_Super":
                                        m.restoreHealth(m.getMaxHealthPercent(0.7f)); ok = true; break;
                                    case "heal_Ultimate":
                                        m.restoreHealth(m.getMaxHealthPercent(1f)); ok = true; break;
                                    default:
                                        m.addStatusEffect(spell.statusId, spell.duration, true); ok = true; break;
                                }
                            }
                        }

                        if (ok) cooldownDict[spell.id] = spell.cooldown;
                    }
                }
            }

            // 定期强制检查所有城市
            lastForceCheckTime += dt;
            if (lastForceCheckTime >= FORCE_CHECK_INTERVAL)
            {
                lastForceCheckTime = 0f;
                ForceCheckAllCities();
            }
        }

        private static void ForceCheckAllCities()
        {
            foreach (var city in World.world.cities)
            {
                if (city == null) continue;

                if (!city.hasArmy())
                {
                    CreateArmyForCity(city);
                    continue;
                }

                if (city.army != null && !city.army.hasCaptain())
                {
                    FixArmyCaptain(city.army, city);
                }
            }
        }

        // =============================
        // Patch：城市状态（军国）
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "updateCityStatus")]
        public static void City_updateCityStatus_MilitarismPatch(City __instance)
        {
            if (__instance.kingdom == null) return;
            var kingdom = __instance.kingdom;

            bool shouldBeMilitarism = GetMilitarism(kingdom.data);
            if (!shouldBeMilitarism)
            {
                foreach (var actor in kingdom.getUnits())
                {
                    if (actor == null) continue;
                    foreach (var trait in MilitarismTraits)
                    {
                        if (actor.hasTrait(trait)) { shouldBeMilitarism = true; break; }
                    }
                    if (shouldBeMilitarism) break;
                }
            }

            if (shouldBeMilitarism && !GetMilitarism(kingdom.data))
            {
                SetMilitarism(kingdom.data, true);
                foreach (var city in kingdom.cities)
                    city?.updateCityStatus();
            }

            if (GetMilitarism(kingdom.data))
            {
                SyncMilitarismLeaders(kingdom);
                int adultPop = 0;
                foreach (var actor in __instance.units)
                    if (actor != null && actor.isAlive() && actor.isAdult()) adultPop++;
                __instance.status.warrior_slots = (int)(adultPop * 0.9f);
            }
        }

        // =============================
        // Patch：国家法术（首都城市更新处，修正传送只执行一次）
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "update")]
        public static void City_update_CountrySpell_Postfix(City __instance, float pElapsed)
        {
            if (__instance == null || __instance.kingdom == null) return;

            if (GetMilitarism(__instance.kingdom.data))
            {
                int currentWarriors = __instance.countWarriors();
                int maxWarriors = __instance.getMaxWarriors();
                if (currentWarriors < maxWarriors)
                {
                    int need = maxWarriors - currentWarriors;
                    foreach (var a in __instance.units)
                    {
                        if (need <= 0) break;
                        if (a == null || !a.isAlive() || !a.isAdult() || a.city != __instance) continue;
                        if (a.city.kingdom != __instance.kingdom || a.isWarrior() || a.isCityLeader() || a.isKing()) continue;
                        if (__instance.checkCanMakeWarrior(a))
                        {
                            __instance.makeWarrior(a);
                            need--;
                        }
                    }
                }
            }

            var kingdom = __instance.kingdom;
            if (kingdom.capital != __instance) return;

            var king = kingdom.king;
            if (king == null || !king.isAlive()) return;

            int kingLv = GetZhanXunLevel(king);
            long kingdomId = kingdom.data.id;
            if (!countrySpellCooldowns.ContainsKey(kingdomId))
                countrySpellCooldowns[kingdomId] = new Dictionary<string, float>();
            var cdDict = countrySpellCooldowns[kingdomId];

            if (!ZhanXunConfig.AutoCollectMilitarystatemagic) return;

            foreach (var spell in CountrySpells)
            {
                if (kingLv < spell.minZhanXunLevel || kingLv > spell.maxZhanXunLevel) continue;
                if (IsSpellRequireWar(spell.id) && !IsKingdomInWar(kingdom)) continue;

                cdDict.TryGetValue(spell.id, out float cd);
                cd = Mathf.Max(0f, cd - pElapsed);
                cdDict[spell.id] = cd;
                if (cd > 0f) continue;

                bool ok = false;

                if (spell.id == "teleport")
                {
                    if (!ZhanXunConfig.AutoCollectMilitarystateteleportation)
                    {
                        continue;
                    }
                    City targetCapital = FindEnemyCapital(kingdom);
                    if (targetCapital != null)
                    {
                        var zone = targetCapital.zones.GetRandom<TileZone>();
                        var tile = zone?.centerTile;
                        if (tile != null)
                        {
                            var teleported = new HashSet<Actor>();

                            if (king != null && king.isAlive())
                            {
                                ActionLibrary.teleportEffect(king, tile);
                                king.cancelAllBeh();
                                king.spawnOn(tile, 0f);
                                teleported.Add(king);
                            }

                            foreach (var army in World.world.armies)
                            {
                                if (army?.getCity()?.kingdom != kingdom) continue;

                                var ac = CaptainOf(army);
                                if (ac != null && ac.isAlive() && teleported.Add(ac))
                                {
                                    ActionLibrary.teleportEffect(ac, tile);
                                    ac.cancelAllBeh();
                                    ac.spawnOn(tile, 0f);
                                }

                                foreach (var u in army.units)
                                {
                                    if (u != null && u.isAlive() && teleported.Add(u))
                                    {
                                        ActionLibrary.teleportEffect(u, tile);
                                        u.cancelAllBeh();
                                        u.spawnOn(tile, 0f);
                                    }
                                }
                            }

                            ok = teleported.Count > 0;
                        }
                    }
                }
                else
                {
                    foreach (var u in kingdom.getUnits())
                    {
                        if (u == null || !u.isAlive()) continue;
                        switch (spell.id)
                        {
                            case "heal_small": u.restoreHealth(u.getMaxHealthPercent(0.1f)); ok = true; break;
                            case "heal_medium": u.restoreHealth(u.getMaxHealthPercent(0.2f)); ok = true; break;
                            case "heal_large": u.restoreHealth(u.getMaxHealthPercent(0.5f)); ok = true; break;
                            case "heal_Super": u.restoreHealth(u.getMaxHealthPercent(0.7f)); ok = true; break;
                            case "heal_Ultimate": u.restoreHealth(u.getMaxHealthPercent(1f)); ok = true; break;
                            default: u.addStatusEffect(spell.statusId, spell.duration, true); ok = true; break;
                        }
                    }
                }

                if (ok) cdDict[spell.id] = spell.cooldown;
            }
        }

        // =============================
        // Patch：城市扩张/建筑/补给/产出
        // =============================
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), nameof(City.addZone))]
        public static void MilitarismExpandNeighboursPatch(City __instance, TileZone pZone)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                bool changed = false;
                foreach (var neighbour in pZone.neighbours_all)
                {
                    if (neighbour != null && neighbour.city == null)
                    {
                        neighbour.setCity(__instance);
                        __instance.zones.Add(neighbour);
                        changed = true;
                    }
                }
                if (changed)
                {
                    __instance.updateCityCenter();
                    __instance.setStatusDirty();
                }
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.getConstructionSpeed))]
        public static void GetConstructionSpeed_MilitarismPatch(Actor __instance, ref int __result)
        {
            if (__instance.city?.kingdom != null && GetMilitarism(__instance.city.kingdom.data))
                __result *= 10;
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(CityBehBuild), "execute")]
        public static void CityBehBuild_execute_MilitarismPatch(City pCity)
        {
            if (pCity.kingdom != null && GetMilitarism(pCity.kingdom.data))
                pCity.timer_build = 0.5f;
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(CityBehSupplyKingdomCities), "updateSupplyTimer")]
        public static void CityBehSupplyKingdomCities_updateSupplyTimer_Postfix(City pCity)
        {
            if (pCity.kingdom != null && GetMilitarism(pCity.kingdom.data))
                pCity.data.timer_supply = 0f;
        }

        // 性能优化：通过 shareResource 打补丁的标志避免 StackTrace
        [HarmonyPrefix]
        [HarmonyPatch(typeof(CityBehSupplyKingdomCities), "shareResource")]
        public static void CityBehSupplyKingdomCities_shareResource_Prefix() => _inShareResource = true;

        [HarmonyFinalizer]
        [HarmonyPatch(typeof(CityBehSupplyKingdomCities), "shareResource")]
        public static void CityBehSupplyKingdomCities_shareResource_Finalizer() => _inShareResource = false;

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "addResourcesToRandomStockpile")]
        public static void City_addResourcesToRandomStockpile_Prefix(City __instance, string pResourceID, ref int pAmount)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                if (_inShareResource) return; // 城际分享时不加速
                long v = (long)pAmount * 999L; // 可改为配置
                pAmount = v >= int.MaxValue ? int.MaxValue : (int)v;
            }
        }

        // =============================
        // Patch：占领流程屏蔽（军国 + 全局开关）
        // =============================
        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "addCapturePoints", new Type[] { typeof(Kingdom), typeof(int) })]
        public static bool City_addCapturePoints_Kingdom_Prefix(City __instance, Kingdom pKingdom, int pValue)
            => !ShouldBlockCapture(__instance);

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "addCapturePoints", new Type[] { typeof(BaseSimObject), typeof(int) })]
        public static bool City_addCapturePoints_BaseSimObject_Prefix(City __instance, BaseSimObject pObject, int pValue)
            => !ShouldBlockCapture(__instance);

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "finishCapture")]
        public static bool City_finishCapture_Prefix(City __instance, Kingdom pNewKingdom)
            => !ShouldBlockCapture(__instance);

        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "updateCapture", new Type[] { typeof(float) })]
        public static void City_updateCapture_Postfix(City __instance, float pElapsed)
        {
            if (ShouldBlockCapture(__instance))
                __instance.clearCapture();
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "isGettingCaptured")]
        public static bool City_isGettingCaptured_Prefix(City __instance, ref bool __result)
        {
            if (ShouldBlockCapture(__instance))
            {
                __result = false;
                return false;
            }
            return true;
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "isGettingCapturedBy")]
        public static bool City_isGettingCapturedBy_Prefix(City __instance, Kingdom pKingdom, ref bool __result)
        {
            if (ShouldBlockCapture(__instance))
            {
                __result = false;
                return false;
            }
            return true;
        }

        // =============================
        // Patch：装备耐久免损
        // =============================
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Item), "getDamaged")]
        public static bool Item_getDamaged_Prefix(Item __instance, int pDamage) => false;

        // 受击前置：优先触发“佛神七”真伤（不阻断原 getHit）
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        [HarmonyPriority(Priority.First)]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            if (pAttacker != null && pAttacker.isActor() && __instance != null && __instance.isAlive())
            {
                var attacker = pAttacker.a;
                // 触发条件：拥有对应特性或状态（按你的实际设计调整判断）
                if (attacker.hasStatus("evilenergy_aura"))
                {
                    damage_evilenergy_aura(pAttacker, __instance);
                }
            }
            return true; // 不拦截原 getHit
        }

        // 真实伤害：对目标直接扣血，不走减伤
        public static bool damage_evilenergy_aura(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf != null && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;

                float attackDamage = 0f;
                try { attackDamage = attacker.stats["damage"]; } catch { /* 某些版本用 get 取值 */ }

                int trueDamage = (int)(attackDamage * 1f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);


                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }
    }
}