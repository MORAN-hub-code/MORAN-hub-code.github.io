﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        // 添加击杀数阈值常量
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {1, "ZhanXun1"},
            {10, "ZhanXun2"},
            {20, "ZhanXun3"},
            {30, "ZhanXun4"},
            {50, "ZhanXun5"},
            {70, "ZhanXun6"},
            {100, "ZhanXun7"},
            {200, "ZhanXun8"},
            {300, "ZhanXun9"},
            {500, "ZhanXun91"},
            {700, "ZhanXun92"},
            {1000, "ZhanXun93"},
            {2000, "ZhanXun94"},
            {3000, "ZhanXun95"},
            {5000, "ZhanXun96"},
            {7000, "ZhanXun97"},
            {10000, "ZhanXun98"}
        };

        // 添加击杀奖励，同组特质唯一
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance)
        {
            if (__instance == null || !__instance.isAlive()) return;

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.kills >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanXun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanXun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);
            }
        }

        // Harmony 前缀补丁：拥有战勋特质的单位优先被招募为军人
        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "setCitizenJob")]
        public static bool City_setCitizenJob_Prefix(City __instance, Actor pActor)
        {
            // 判断是否拥有任意战勋特质
            bool hasZhanXun = pActor.getTraits().Any(trait => trait.group_id == "ZhanXun");
            if (hasZhanXun && __instance.checkCanMakeWarrior(pActor))
            {
                __instance.makeWarrior(pActor);
                // 设置冷却
                var timerField = typeof(City).GetField("_timer_warrior", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (timerField != null)
                {
                    timerField.SetValue(__instance, 15f);
                }
                return false; // 阻止原方法
            }
            return true; // 继续原方法
        }

        // Harmony 前缀补丁：军队领袖优先选择战勋等级最高的单位
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), "findCaptain")]
        public static bool Army_findCaptain_Prefix(Army __instance)
        {
            var units = Traverse.Create(__instance).Field("units").GetValue<List<Actor>>();
            if (units == null || units.Count == 0)
                return false;

            // 找到拥有最高战勋等级的单位
            Actor best = null;
            int bestLevel = -1;
            foreach (var actor in units)
            {
                if (!actor.isAlive()) continue;
                // 查找最高等级的 ZhanXun 特质
                int level = -1;
                foreach (var trait in actor.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        // 解析等级
                        string id = trait.id;
                        if (id.StartsWith("ZhanXun"))
                        {
                            if (int.TryParse(id.Substring(7), out int parsed))
                            {
                                level = parsed;
                                break;
                            }
                        }
                    }
                }
                if (level > bestLevel)
                {
                    bestLevel = level;
                    best = actor;
                }
            }
            if (best != null && bestLevel >= 0)
            {
                __instance.setCaptain(best);
                return false; // 阻止原方法
            }
            // 没有战勋单位则继续原方法
            return true;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
        public static bool applyForceToUnit_Protection(AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            // 如果目标是Actor且有保护特质，则不被击退，阻止原方法
            if (pTargetToCheck.isActor() && HasProtectedTrait(pTargetToCheck.a))
            {
                return false; // 阻止原方法
            }
            // 允许原方法继续执行
            return true;
        }

        // 防止龙卷风效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止随机力效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
        {
            return !HasProtectedTrait(__instance);
        }

         // 拦截 makeStunned，拥有保护特质则不被眩晕
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止获得震惊状态
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
            {
                return !HasProtectedTrait(__instance);
            }
            return true;
        }

        private static readonly HashSet<string> ProtectedTraits = new()
        {
            "ZhanXun7", "ZhanXun8", "ZhanXun9", "ZhanXun91", "ZhanXun92",
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97",
            "ZhanXun98"
        };

        private static bool HasProtectedTrait(Actor actor)
        {
            if (actor == null) return false;
            return ProtectedTraits.Any(trait => actor.hasTrait(trait));
        }
    }
}