﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using ai.behaviours;
using life.taxi;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        // 添加击杀数阈值常量
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {1, "ZhanXun1"},
            {10, "ZhanXun2"},
            {20, "ZhanXun3"},
            {30, "ZhanXun4"},
            {50, "ZhanXun5"},
            {70, "ZhanXun6"},
            {100, "ZhanXun7"},
            {200, "ZhanXun8"},
            {300, "ZhanXun9"},
            {500, "ZhanXun91"},
            {700, "ZhanXun92"},
            {1000, "ZhanXun93"},
            {2000, "ZhanXun94"},
            {3000, "ZhanXun95"},
            {5000, "ZhanXun96"},
            {7000, "ZhanXun97"},
            {10000, "ZhanXun98"}
        };

        // 战勋等级映射表（从低到高）
        private static readonly Dictionary<string, int> ZhanXunLevels = new()
        {
            {"ZhanXun1", 1},
            {"ZhanXun2", 2},
            {"ZhanXun3", 3},
            {"ZhanXun4", 4},
            {"ZhanXun5", 5},
            {"ZhanXun6", 6},
            {"ZhanXun7", 7},
            {"ZhanXun8", 8},
            {"ZhanXun9", 9},
            {"ZhanXun91", 10},
            {"ZhanXun92", 11},
            {"ZhanXun93", 12},
            {"ZhanXun94", 13},
            {"ZhanXun95", 14},
            {"ZhanXun96", 15},
            {"ZhanXun97", 16},
            {"ZhanXun98", 17}
        };

        // 存储每个单位击杀国王数量的字典
        private static readonly Dictionary<long, int> KingKillCounts = new();

        // 获取单位的战勋等级
        private static int GetZhanXunLevel(Actor actor)
        {
            if (actor == null) return 0;

            int highestLevel = 0;
            foreach (var trait in actor.getTraits())
            {
                if (trait.group_id == "ZhanXun" && ZhanXunLevels.ContainsKey(trait.id))
                {
                    int level = ZhanXunLevels[trait.id];
                    if (level > highestLevel)
                    {
                        highestLevel = level;
                    }
                }
            }
            return highestLevel;
        }

        // 获取单位击杀国王数量
        private static int GetKingKillCount(Actor actor)
        {
            if (actor == null) return 0;
            return KingKillCounts.TryGetValue(actor.getID(), out int count) ? count : 0;
        }

        // 增加单位击杀国王数量
        private static void IncrementKingKillCount(Actor actor)
        {
            if (actor == null) return;
            long actorId = actor.getID();
            if (KingKillCounts.ContainsKey(actorId))
            {
                KingKillCounts[actorId]++;
            }
            else
            {
                KingKillCounts[actorId] = 1;
            }
        }

        // 添加击杀奖励，同组特质唯一
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance, Actor pDeadUnit)
        {
            if (__instance == null || !__instance.isAlive()) return;

            // 检查是否击杀了国王
            if (pDeadUnit != null && pDeadUnit.isKing())
            {
                IncrementKingKillCount(__instance);
                int kingKillCount = GetKingKillCount(__instance);

                // 如果击杀国王数量达到10个，给予额外特质
                if (kingKillCount >= 10 && !__instance.hasTrait("king_slayer_master"))
                {
                    __instance.addTrait("king_slayer_master", false);
                }
            }

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.kills >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanXun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanXun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);

                // 击杀数达到1时，赋予额外特质
                if (__instance.data.kills >= 1 && !__instance.hasTrait("fire_proof"))
                {
                    __instance.addTrait("fire_proof", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("freeze_proof"))
                {
                    __instance.addTrait("freeze_proof", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("immune"))
                {
                    __instance.addTrait("immune", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("strong_minded"))
                {
                    __instance.addTrait("strong_minded", false);
                }
            }
        }

        // Harmony 前缀补丁：拥有战勋特质的单位优先被招募为军人
        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "setCitizenJob")]
        public static bool City_setCitizenJob_Prefix(City __instance, Actor pActor)
        {
            // 国王和领主不会被招募为军人
            if (pActor.isKing() || pActor.isCityLeader())
            {
                return true; // 跳过招募逻辑，继续原方法
            }
            // 判断是否拥有任意战勋特质
            bool hasZhanXun = pActor.getTraits().Any(trait => trait.group_id == "ZhanXun");
            if (hasZhanXun && __instance.checkCanMakeWarrior(pActor))
            {
                __instance.makeWarrior(pActor);
                // 设置冷却
                var timerField = typeof(City).GetField("_timer_warrior", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (timerField != null)
                {
                    timerField.SetValue(__instance, 15f);
                }
                return false; // 阻止原方法
            }
            return true; // 继续原方法
        }

        // Harmony 前缀补丁：军队领袖选择时优先选择战勋等级最高的
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), "findCaptain")]
        public static bool Army_findCaptain_Prefix(Army __instance)
        {
            // 如果已经有队长且是文明单位，保持不变
            if (__instance.hasCaptain() && __instance.captain.isKingdomCiv())
            {
                return true; // 继续原方法
            }

            // 清除无效队长
            if (__instance.hasCaptain())
            {
                __instance.setCaptain(null);
            }

            // 如果没有军队成员，无法选择队长
            if (__instance.units.Count == 0)
            {
                return true; // 继续原方法
            }

            // 寻找战勋等级最高的单位
            Actor bestCandidate = null;
            int highestZhanXunLevel = -1;
            int bestDistance = int.MaxValue;

            foreach (var unit in __instance.units)
            {
                if (!unit.isAlive()) continue;

                int zhanXunLevel = GetZhanXunLevel(unit);

                // 如果有战勋特质，优先选择
                if (zhanXunLevel > 0)
                {
                    // 如果有原队长位置记录，计算距离
                    int distance = int.MaxValue;
                    if (__instance._prev_captain_position != null)
                    {
                        distance = Toolbox.SquaredDistTile(unit.current_tile, __instance._prev_captain_position);
                    }

                    // 选择战勋等级最高的，如果等级相同则选择距离 最近的
                    if (zhanXunLevel > highestZhanXunLevel ||
                        (zhanXunLevel == highestZhanXunLevel && distance < bestDistance))
                    {
                        bestCandidate = unit;
                        highestZhanXunLevel = zhanXunLevel;
                        bestDistance = distance;
                    }
                }
            }

            // 如果找到了有战勋特质的单位，设置为队长
            if (bestCandidate != null)
            {
                __instance.setCaptain(bestCandidate);
                return false; // 阻止原方法执行
            }

            // 如果没有找到有战勋特质的单位，按原方法执行
            return true; // 继续原方法
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
        public static bool applyForceToUnit_Protection(AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            // 如果目标是Actor且有保护特质，则不被击退，阻止原方法
            if (pTargetToCheck.isActor() && HasProtectedTrait(pTargetToCheck.a))
            {
                return false; // 阻止原方法
            }
            // 允许原方法继续执行
            return true;
        }

        // 防止龙卷风效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止随机力效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
        {
            return !HasProtectedTrait(__instance);
        }

        // 拦截 makeStunned，拥有保护特质则不被眩晕
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止获得震惊状态
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
            {
                return !HasProtectedTrait(__instance);
            }
            return true;
        }

        private static readonly HashSet<string> ProtectedTraits = new()
        {
            "ZhanXun7", "ZhanXun8", "ZhanXun9", "ZhanXun91", "ZhanXun92",
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97",
            "ZhanXun98"
        };

        private static bool HasProtectedTrait(Actor actor)
        {
            if (actor == null) return false;
            return ProtectedTraits.Any(trait => actor.hasTrait(trait));
        }

        // 只允许"战斗"、"跟随队长"以及上船/坐船相关AI，其它AI全部强制切到跟随
        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.update))]
        public static void ForceOnlyFollowOrFightOrBoatAI(ArmyManager __instance, float pElapsed)
        {
            HashSet<string> allowedTasks = new HashSet<string>
            {
                "fighting",
                "warrior_army_follow_leader",
                "force_into_a_boat",
                "embark_into_boat",
                "sit_inside_boat",
                "taxi_check",
                "taxi_embark",
                "taxi_sit_inside",
                "taxi_find_ship_tile",
                "city_actor_warrior_taxi_check",
                // ====== 军事目标作战相关 ======
                "city_actor_attack_zone",
                "city_actor_attack_target",
                "city_actor_attack_building",
                "city_actor_attack_enemy_unit",
                "city_actor_attack_enemy_army",
                "city_actor_attack_enemy_city",
                "city_actor_attack_enemy_king",
                "city_actor_attack_enemy_leader",
                // ====== 船运相关 ======
                "check_warrior_transport",
                "boat_transport_check_taxi",
                "boat_transport_check",
                "boat_transport_go_load",
                "boat_transport_go_unload",
                // ====== 和平时期回家相关 ======
                "try_to_return_to_home_city"
                // 如有其它与作战/进攻/船运/回家相关的AI任务可补充，直接在这里添加
            };
            foreach (var army in World.world.armies)
            {
                if (!IsPersonalArmy(army)) continue;
                var captain = army.captain;
                if (captain == null || !captain.isAlive()) continue;
                // 处理队长和军队成员
                var allMembers = new List<Actor> { captain };
                allMembers.AddRange(army.units);
                foreach (var member in allMembers)
                {
                    if (member == null || !member.isAlive()) continue;
                    // ======自动存仓 ======
                    if (member.isCarryingResources())
                    {
                        member.giveInventoryResourcesToCity();
                    }
                    // ======自动将战利品转化为金币 ======
                    if (member.loot > 0)
                    {
                        member.takeAllOwnLoot();
                    }
                    // ====== 自动原地完成恋爱、结婚、生育 ======
                    var lover = member.lover;
                    if (lover != null && lover != member && !member.isClonedFrom(lover) && !member.isChildOf(lover) && !member.isParentOf(lover))
                    {
                        if (!(member.hasLover() && member.lover == lover))
                        {
                            member.becomeLoversWith(lover);
                        }
                    }
                    if (
                        lover != null &&
                        member.isSexFemale() &&
                        member.canBreed() &&
                        lover.canBreed() &&
                        member.isAdult() &&
                        lover.isAdult() &&
                        !member.hasReachedOffspringLimit() &&
                        !member.hasStatus("afterglow") &&
                        !lover.hasStatus("afterglow") &&
                        !member.hasStatus("pregnant") &&
                        member.city != null &&
                        member.city.getPopulationPeople() < member.city.getPopulationMaximum() * 2
                        )
                    {
                        float maturationTime = member.getMaturationTimeSeconds();
                        member.addStatusEffect("pregnant", maturationTime, true);
                        float afterglowTime = maturationTime + 60f; // 余晖冷却为怀孕时间加60秒
                        member.addStatusEffect("afterglow", afterglowTime, true);
                        lover.addStatusEffect("afterglow", afterglowTime, true);
                    }
                    // ====== 自动原地完成进食 ======
                    if (member.isHungry())
                    {
                        member.addNutritionFromEating(member.getMaxNutrition(), false, true);
                        member.countConsumed();
                    }
                    // ====== 军人着火时原地灭火 ======
                    if (member.hasStatus("burning"))
                    {
                        member.finishStatusEffect("burning");
                    }
                    // ====== 自动移除残疾和眼瞎和烧伤特质 ======
                    if (member.hasTrait("crippled"))
                    {
                        member.removeTrait("crippled");
                    }
                    if (member.hasTrait("eyepatch"))
                    {
                        member.removeTrait("eyepatch");
                    }
                    if (member.hasTrait("skin_burns"))
                    {
                        member.removeTrait("skin_burns");
                    }
                    // ====== 自动触发跨岛上船请求 ======
                    if (member.city != null && member.city.hasAttackZoneOrder())
                    {
                        var targetTile = member.city.target_attack_zone.centerTile;
                        if (targetTile != null && !targetTile.isSameIsland(member.current_tile))
                        {
                            TaxiManager.newRequest(member, targetTile);
                        }
                    }
                    // 只允许上述AI，其它全部强制切到跟随（队长除外）
                    if (member != captain)
                    {
                        var curTask = member.ai?.task?.id;
                        if (string.IsNullOrEmpty(curTask) || !allowedTasks.Contains(curTask))
                        {
                            member.cancelAllBeh();
                            member.setTask("warrior_army_follow_leader", true, false, true);
                        }
                    }
                }
                // ====== 军队法术施放（多法术支持） ======
                if (captain != null && captain.isAlive())
                {
                    int captainZhanXunLevel = GetZhanXunLevel(captain); // 获取队长战勋等级
                    long armyId = army.data.id;
                    if (!armySpellCooldowns.ContainsKey(armyId))
                        armySpellCooldowns[armyId] = new Dictionary<string, float>();
                    var cooldownDict = armySpellCooldowns[armyId];
                    foreach (var spell in ArmySpells)
                    {
                        // 战勋等级不在区间，不能释放该法术
                        if (captainZhanXunLevel < spell.minZhanXunLevel || captainZhanXunLevel > spell.maxZhanXunLevel)
                        {
                            continue;
                        }
                        // 只让"煞气"和"护盾"在战斗时施放
                        if ((spell.id == "shield" || spell.id == "evilenergy_aura" || spell.id == "heal_National"))
                        {
                            // 检查是否有成员处于战斗状态
                            bool anyFighting = allMembers.Exists(m => m != null && m.isAlive() && m.isFighting());
                            if (!anyFighting)
                            {
                                continue; // 没有成员在战斗，跳过施放
                            }
                        }
                        float cooldown = 0f;
                        cooldownDict.TryGetValue(spell.id, out cooldown);
                        if (cooldown <= 0f)
                        {
                            // 给队长和所有军队成员施加buff
                            var allMembersForSpell = new List<Actor> { captain };
                            allMembersForSpell.AddRange(army.units);
                            // 特殊处理传送术
                            if (spell.id == "teleport")
                            {
                                // 传送术：找到目标城市并传送整个军队
                                City targetCity = FindNearestEnemyCity(captain);
                                bool teleportSuccess = false; // 标记传送是否成功
                                if (targetCity != null)
                                {
                                    // 找到目标城市的中心区域
                                    TileZone targetZone = targetCity.zones.GetRandom<TileZone>();
                                    if (targetZone != null)
                                    {
                                        WorldTile targetTile = targetZone.centerTile;
                                        if (targetTile != null)
                                        {
                                            // 传送整个军队到目标城市
                                            foreach (var member2 in allMembersForSpell)
                                            {
                                                if (member2 != null && member2.isAlive())
                                                {
                                                    // 播放传送特效
                                                    ActionLibrary.teleportEffect(member2, targetTile);
                                                    // 传送到目标位置
                                                    member2.cancelAllBeh();
                                                    member2.spawnOn(targetTile, 0f);
                                                }
                                            }
                                            teleportSuccess = true; // 标记传送成功
                                        }
                                    }
                                }
                                // 只有传送成功时才重置冷却时间
                                if (teleportSuccess)
                                {
                                    cooldownDict[spell.id] = spell.cooldown;
                                }
                            }
                            else
                            {
                                // 其他法术的处理
                                bool spellSuccess = false; // 标记法术是否成功施放
                                foreach (var member2 in allMembersForSpell)
                                {
                                    if (member2 != null && member2.isAlive())
                                    {
                                        // 分级治疗术：根据id精确判断
                                        if (spell.id == "heal_small")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.1f); // 小治疗术10%
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_medium")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.2f); // 中治疗术20%
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_large")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.5f); // 大治疗术50%
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_Super")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(0.7f); // 超级治疗术70%
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else if (spell.id == "heal_Ultimate")
                                        {
                                            int healAmount = member2.getMaxHealthPercent(1f); // 究极治疗术100%
                                            member2.restoreHealth(healAmount);
                                            spellSuccess = true;
                                        }
                                        else
                                        {
                                            // 其他法术：添加状态效果
                                            member2.addStatusEffect(spell.statusId, spell.duration, true);
                                            spellSuccess = true;
                                        }
                                    }
                                }
                                // 只有法术成功施放时才重置冷却时间
                                if (spellSuccess)
                                {
                                    cooldownDict[spell.id] = spell.cooldown;
                                }
                            }
                        }
                        else
                        {
                            // 用pElapsed递减，确保随游戏加速/减速同步
                            cooldownDict[spell.id] = cooldown - pElapsed;
                        }
                    }
                }
                // ======================================
            }
        }
        private static bool IsPersonalArmy(Army army)
        {
            // 如果Army没有hasTrait方法，则默认所有军队都应用跟随逻辑
            // 如需只对特定军队生效，可在此自定义判断条件
            return true;
        }

        // ================== 军队法术系统（多法术支持） ==================
        // 法术配置结构
        private class ArmySpell
        {
            public string id;           // 法术唯一id
            public string statusId;     // 施加的buff状态id
            public float duration;      // buff持续时间
            public float cooldown;      // 冷却时间
            public int minZhanXunLevel; // 最低战勋等级
            public int maxZhanXunLevel; // 最高战勋等级
            public string displayName;  // 法术名（可选）
        }

        // 多法术配置（分级限制，区间）
        private static readonly ArmySpell[] ArmySpells = new ArmySpell[]
        {
            new ArmySpell { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new ArmySpell { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new ArmySpell { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new ArmySpell { id = "shield", statusId = "shield", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "护盾术" },
            new ArmySpell { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new ArmySpell { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new ArmySpell { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new ArmySpell { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new ArmySpell { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new ArmySpell { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new ArmySpell { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new ArmySpell { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "御风术" },
            new ArmySpell { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new ArmySpell { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new ArmySpell { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new ArmySpell { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new ArmySpell { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" },
            // 可继续添加更多法术
        };

        // 冷却字典：armyId -> (spellId -> cooldown)
        private static readonly Dictionary<long, Dictionary<string, float>> armySpellCooldowns = new();

        // 找到最近的敌方城市
        private static City FindNearestEnemyCity(Actor captain)
        {
            if (captain == null || !captain.hasCity()) return null;

            City captainCity = captain.getCity();
            if (captainCity == null) return null;

            Kingdom captainKingdom = captainCity.kingdom;
            if (captainKingdom == null) return null;

            City nearestEnemyCity = null;
            float nearestDistance = float.MaxValue;

            // 遍历所有城市
            foreach (var city in World.world.cities)
            {
                if (city == null || city == captainCity) continue;

                // 检查是否是敌方城市 - 使用正确的敌对判断方法
                if (city.kingdom != null && captainKingdom.isEnemy(city.kingdom))
                {
                    // 计算距离（使用城市的第一个区域中心）
                    float distance = float.MaxValue;
                    if (city.zones != null && city.zones.Count > 0)
                    {
                        TileZone firstZone = city.zones[0];
                        if (firstZone != null && firstZone.centerTile != null)
                        {
                            distance = Toolbox.SquaredDistTile(captain.current_tile, firstZone.centerTile);
                        }
                    }
                    if (distance < nearestDistance)
                    {
                        nearestDistance = distance;
                        nearestEnemyCity = city;
                    }
                }
            }

            return nearestEnemyCity;
        }

        // 找到敌方首都
        private static City FindEnemyCapital(Kingdom kingdom)
        {
            if (kingdom == null) return null;

            City nearestEnemyCapital = null;
            float nearestDistance = float.MaxValue;

            // 遍历所有城市
            foreach (var city in World.world.cities)
            {
                if (city == null) continue;

                // 检查是否是敌方首都
                if (city.kingdom != null && kingdom.isEnemy(city.kingdom) && city.kingdom.capital == city)
                {
                    // 计算距离（使用城市的第一个区域中心）
                    float distance = float.MaxValue;
                    if (city.zones != null && city.zones.Count > 0)
                    {
                        TileZone firstZone = city.zones[0];
                        if (firstZone != null && firstZone.centerTile != null)
                        {
                            // 使用王国首都作为参考点计算距离
                            if (kingdom.capital != null && kingdom.capital.zones != null && kingdom.capital.zones.Count > 0)
                            {
                                TileZone kingdomZone = kingdom.capital.zones[0];
                                if (kingdomZone != null && kingdomZone.centerTile != null)
                                {
                                    distance = Toolbox.SquaredDistTile(kingdomZone.centerTile, firstZone.centerTile);
                                }
                            }
                        }
                    }
                    if (distance < nearestDistance)
                    {
                        nearestDistance = distance;
                        nearestEnemyCapital = city;
                    }
                }
            }

            return nearestEnemyCapital;
        }

                // ================== 军国判定与城市军队上限调整 ==================
        private static readonly HashSet<string> MilitarismTraits = new()
        {
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97", "ZhanXun98"
        };
        private const string MilitarismKingdomTrait = "militarism";

        // ========== KingdomData军国字段补丁 ===========
        private static readonly Dictionary<KingdomData, bool> MilitarismField = new();
        public static bool GetMilitarism(KingdomData data) => MilitarismField.TryGetValue(data, out var v) && v;
        public static void SetMilitarism(KingdomData data, bool value) => MilitarismField[data] = value;

        // ========== 自动指定军国国王/领主/队长 ===========
        private static Actor FindHighestZhanXunActor(IEnumerable<Actor> actors)
        {
            Actor best = null;
            int bestLevel = -1;
            foreach (var actor in actors)
            {
                if (!actor.isAlive()) continue;
                int level = GetZhanXunLevel(actor);
                if (level > bestLevel)
                {
                    best = actor;
                    bestLevel = level;
                }
            }
            return best;
        }

        // 修正：确保强行设定的国王能够完全行使国王能力
        private static void SyncMilitarismLeaders(Kingdom kingdom)
        {
            if (!GetMilitarism(kingdom.data)) return;
            // 1. 国王 = 全体军勋最高者
            var allUnits = kingdom.getUnits();
            var king = FindHighestZhanXunActor(allUnits);
            var oldKing = kingdom.king;
            if (king != null && king != oldKing)
            {
                // 先让新国王卸任所有职业
                if (king.city != null && king.city.leader == king)
                {
                    king.city.removeLeader();
                    king.setProfession(UnitProfession.Unit, true);
                }
                if (king.isWarrior())
                    king.stopBeingWarrior();
                king.setProfession(UnitProfession.Unit, true);

                // 让旧国王彻底卸任
                if (oldKing != null)
                {
                    // 增加世界历史记录：原国王于某年将王位传位于新国王
                    int year = Date.getYear(World.world.getCurWorldTime());
                    new WorldLogMessage(
                        WorldLogLibrary.king_new,
                        kingdom.name,
                        $"{kingdom.name}：{oldKing.getName()}于{year}年将王位传位于{king.getName()}",
                        year.ToString()
                    ).add();
                    kingdom.removeKing(); // 官方方法，确保元数据同步
                    if (oldKing.city != null && oldKing.city.leader == oldKing)
                    {
                        oldKing.city.removeLeader();
                        oldKing.setProfession(UnitProfession.Unit, true);
                    }
                    if (oldKing.isWarrior())
                        oldKing.stopBeingWarrior();
                    if (oldKing.isKing())
                        oldKing.setProfession(UnitProfession.Unit, true);
                }
                kingdom.setKing(king, true); // 官方方法，确保所有元数据同步
                king.startShake();
                king.startColorEffect();
            }
        }

        // Harmony补丁：城市状态刷新时自动判定军国并调整军队上限
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "updateCityStatus")]
        public static void City_updateCityStatus_MilitarismPatch(City __instance)
        {
            if (__instance.kingdom == null) return;
            var kingdom = __instance.kingdom;
            // 判定是否应为军国（只升不降）
            bool shouldBeMilitarism = GetMilitarism(kingdom.data);
            if (!shouldBeMilitarism) // 只在未成为军国时判定
            {
                foreach (var actor in kingdom.getUnits())
                {
                    foreach (var trait in MilitarismTraits)
                    {
                        if (actor.hasTrait(trait))
                        {
                            shouldBeMilitarism = true;
                            break;
                        }
                    }
                    if (shouldBeMilitarism) break;
                }
            }
            // 字段式同步（只升不降）
            if (shouldBeMilitarism && !GetMilitarism(kingdom.data))
            {
                SetMilitarism(kingdom.data, true);
                foreach (var city in kingdom.cities)
                {
                    if (city != null) city.updateCityStatus();
                }
            }
            // 军国时自动同步国王/领主/队长
            if (GetMilitarism(kingdom.data))
            {
                SyncMilitarismLeaders(kingdom);
                // 统计非小孩人口
                int adultPop = 0;
                foreach (var actor in __instance.units)
                {
                    if (actor != null && actor.isAlive() && actor.isAdult())
                        adultPop++;
                }
                __instance.status.warrior_slots = (int)(adultPop * 0.9f);
            }
        }

        // ========== 军国批量招募士兵排除小孩补丁 ========== 
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "update")]
        public static void City_update_MilitarismRecruitPatch(City __instance, float pElapsed)
        {
            if (__instance.kingdom == null || !GetMilitarism(__instance.kingdom.data))
                return;
            int currentWarriors = __instance.countWarriors();
            int maxWarriors = __instance.getMaxWarriors();
            if (currentWarriors >= maxWarriors)
                return;
            // 只招募已成年的单位，且必须是本城市的单位
            var candidates = __instance.units.Where(a =>
                a != null &&
                a.isAlive() &&
                a.isAdult() &&
                a.city == __instance &&
                !a.isWarrior() &&
                !a.isCityLeader() &&
                !a.isKing() && // 新增：排除国王
                __instance.checkCanMakeWarrior(a)
            ).ToList();
            int need = maxWarriors - currentWarriors;
            foreach (var actor in candidates.Take(need))
            {
                __instance.makeWarrior(actor);
            }
        }

        // ========== 国家级法术系统 ========== 
        private class CountrySpell
        {
            public string id;
            public string statusId;
            public float duration;
            public float cooldown;
            public int minZhanXunLevel;
            public int maxZhanXunLevel;
            public string displayName;
        }
        
        private static readonly CountrySpell[] CountrySpells = new CountrySpell[]
        {
            new CountrySpell { id = "Johnson", statusId = "Johnson", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "强身术" },
            new CountrySpell { id = "Selfde", statusId = "Selfde", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "护身术" },
            new CountrySpell { id = "Ironarmor", statusId = "Ironarmor", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "铁甲术" },
            new CountrySpell { id = "shield", statusId = "shield", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "护盾术" },
            new CountrySpell { id = "heal_small", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "小治疗术" },
            new CountrySpell { id = "heal_medium", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "中治疗术" },
            new CountrySpell { id = "heal_large", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "大治疗术" },
            new CountrySpell { id = "heal_Super", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 10, maxZhanXunLevel = 11, displayName = "超级治疗术" },
            new CountrySpell { id = "heal_Ultimate", statusId = "heal", duration = 0f, cooldown = 60f, minZhanXunLevel = 12, maxZhanXunLevel = 17, displayName = "究极治疗术" },
            new CountrySpell { id = "Accelerate", statusId = "Accelerate", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "加速术" },
            new CountrySpell { id = "Strongwind", statusId = "Strongwind", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "疾风术" },
            new CountrySpell { id = "Yufeng", statusId = "Yufeng", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "御风术" },
            new CountrySpell { id = "teleport", statusId = "teleport", duration = 60f, cooldown = 240f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "传送术" },
            new CountrySpell { id = "enhancement", statusId = "enhancement", duration = 30f, cooldown = 60f, minZhanXunLevel = 1, maxZhanXunLevel = 4, displayName = "力量强化" },
            new CountrySpell { id = "andblood", statusId = "andblood", duration = 30f, cooldown = 60f, minZhanXunLevel = 5, maxZhanXunLevel = 6, displayName = "气血澎湃" },
            new CountrySpell { id = "Overload", statusId = "Overload", duration = 30f, cooldown = 60f, minZhanXunLevel = 7, maxZhanXunLevel = 9, displayName = "超载爆发" },
            new CountrySpell { id = "evilenergy_aura", statusId = "evilenergy_aura", duration = 60f, cooldown = 120f, minZhanXunLevel = 10, maxZhanXunLevel = 17, displayName = "煞气" },
            // 可继续添加更多国家级法术
        };
        // 冷却字典：kingdomId -> (spellId -> cooldown)
        private static readonly Dictionary<long, Dictionary<string, float>> countrySpellCooldowns = new();

        // 检查王国是否处于战争状态
        private static bool IsKingdomInWar(Kingdom kingdom)
        {
            if (kingdom == null) return false;
            
            // 检查是否有任何战争
            foreach (var war in World.world.wars.getWars(kingdom))
            {
                if (war != null && !war.hasEnded())
                {
                    return true;
                }
            }
            
            // 检查是否有任何敌人（包括非文明敌对）
            foreach (var otherKingdom in World.world.kingdoms)
            {
                if (otherKingdom != null && otherKingdom != kingdom && kingdom.isEnemy(otherKingdom))
                {
                    return true;
                }
            }
            
            return false;
        }

        // 检查法术是否需要在战争状态下才能使用
        private static bool IsSpellRequireWar(string spellId)
        {
            // 定义需要在战争状态下才能使用的法术
            HashSet<string> warRequiredSpells = new HashSet<string>
            {
                "Johnson",      // 强身术
                "Selfde",       // 护身术
                "Ironarmor",    // 铁甲术
                "shield",       // 护盾术
                "Accelerate",
                "enhancement",  // 力量强化
                "andblood",     // 气血澎湃
                "Overload",     // 超载爆发
                "evilenergy_aura", // 煞气
                "teleport"      // 传送术
            };
            
            return warRequiredSpells.Contains(spellId);
        }

        // 在City.update中处理国家级法术释放（每城只需处理一次即可）
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), "update")]
        public static void City_update_CountrySpell_Postfix(City __instance, float pElapsed)
        {
            if (__instance == null || __instance.kingdom == null) return;
            var kingdom = __instance.kingdom;
            var king = kingdom.king;
            if (king == null || !king.isAlive()) return;
            
            int kingZhanXunLevel = GetZhanXunLevel(king);
            long kingdomId = kingdom.data.id;
            if (!countrySpellCooldowns.ContainsKey(kingdomId))
                countrySpellCooldowns[kingdomId] = new Dictionary<string, float>();
            var cooldownDict = countrySpellCooldowns[kingdomId];
            foreach (var spell in CountrySpells)
            {
                // 战勋等级不在区间，不能释放该法术
                if (kingZhanXunLevel < spell.minZhanXunLevel || kingZhanXunLevel > spell.maxZhanXunLevel)
                    continue;
                    
                // 检查是否需要战争状态
                if (IsSpellRequireWar(spell.id) && !IsKingdomInWar(kingdom))
                    continue;
                    
                float cooldown = 0f;
                cooldownDict.TryGetValue(spell.id, out cooldown);
                if (cooldown <= 0f)
                {
                    bool spellSuccess = false;
                    // 给所有本国单位施加buff或治疗
                    foreach (var unit in kingdom.getUnits())
                    {
                        if (unit != null && unit.isAlive())
                        {
                            // 分级治疗术：根据id精确判断
                            if (spell.id == "heal_small")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.1f); // 小治疗术10%
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_medium")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.2f); // 中治疗术20%
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_large")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.5f); // 大治疗术50%
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_Super")
                            {
                                int healAmount = unit.getMaxHealthPercent(0.7f); // 超级治疗术70%
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "heal_Ultimate")
                            {
                                int healAmount = unit.getMaxHealthPercent(1f); // 究极治疗术100%
                                unit.restoreHealth(healAmount);
                                spellSuccess = true;
                            }
                            else if (spell.id == "teleport")
                            {
                                // 传送术：找到敌方首都并传送所有军队和国王
                                City targetCapital = FindEnemyCapital(kingdom);
                                if (targetCapital != null)
                                {
                                    // 找到目标首都的中心区域
                                    TileZone targetZone = targetCapital.zones.GetRandom<TileZone>();
                                    if (targetZone != null)
                                    {
                                        WorldTile targetTile = targetZone.centerTile;
                                        if (targetTile != null)
                                        {
                                            // 传送国王
                                            ActionLibrary.teleportEffect(unit, targetTile);
                                            unit.cancelAllBeh();
                                            unit.spawnOn(targetTile, 0f);
                                            
                                            // 传送所有军队
                                            foreach (var army in World.world.armies)
                                            {
                                                if (army != null && army.getCity() != null && army.getCity().kingdom == kingdom)
                                                {
                                                    foreach (var armyUnit in army.units)
                                                    {
                                                        if (armyUnit != null && armyUnit.isAlive())
                                                        {
                                                            ActionLibrary.teleportEffect(armyUnit, targetTile);
                                                            armyUnit.cancelAllBeh();
                                                            armyUnit.spawnOn(targetTile, 0f);
                                                        }
                                                    }
                                                    // 传送队长
                                                    if (army.captain != null && army.captain.isAlive())
                                                    {
                                                        ActionLibrary.teleportEffect(army.captain, targetTile);
                                                        army.captain.cancelAllBeh();
                                                        army.captain.spawnOn(targetTile, 0f);
                                                    }
                                                }
                                            }
                                            spellSuccess = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                // 其他法术：添加状态效果
                                unit.addStatusEffect(spell.statusId, spell.duration, true);
                                spellSuccess = true;
                            }
                        }
                    }
                    if (spellSuccess)
                    {
                        cooldownDict[spell.id] = spell.cooldown;
                    }
                }
                else
                {
                    cooldownDict[spell.id] = cooldown - pElapsed;
                }
            }
        }

        // ========== 军国扩展城市区域邻居 ========== 
        // 使得军国城市的区域能够扩展到所有相邻的“空地”区域
        [HarmonyPostfix]
        [HarmonyPatch(typeof(City), nameof(City.addZone))]
        public static void MilitarismExpandNeighboursPatch(City __instance, TileZone pZone)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                foreach (var neighbour in pZone.neighbours_all)
                {
                    // 只扩张空地，绝不侵占任何已有城市（包括同国其它城市）
                    if (neighbour != null && neighbour.city == null)
                    {
                        // 只扩张一次，不递归调用 addZone
                        neighbour.setCity(__instance);
                        __instance.zones.Add(neighbour);
                        __instance.updateCityCenter();
                        __instance.setStatusDirty();
                    }
                }
            }
        }

        // ========== 军国建筑建造速度提升 ==========
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.getConstructionSpeed))]
        public static void GetConstructionSpeed_MilitarismPatch(Actor __instance, ref int __result)
        {
            if (__instance.city != null && __instance.city.kingdom != null && GetMilitarism(__instance.city.kingdom.data))
            {
                __result *= 10;
            }
        }

        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "addResourcesToRandomStockpile")]
        public static void City_addResourcesToRandomStockpile_Prefix(City __instance, string pResourceID, ref int pAmount)
        {
            if (__instance.kingdom != null && GetMilitarism(__instance.kingdom.data))
            {
                // 检查是否为城市补给/交换调用
                var stack = new System.Diagnostics.StackTrace();
                for (int i = 0; i < stack.FrameCount; i++)
                {
                    var method = stack.GetFrame(i).GetMethod();
                    if (method.DeclaringType != null && method.DeclaringType.FullName == "ai.behaviours.CityBehSupplyKingdomCities" && method.Name == "shareResource")
                    {
                        return; // 补给/交换不乘以999
                    }
                }
                pAmount *= 999;
            }
        }
    }
}