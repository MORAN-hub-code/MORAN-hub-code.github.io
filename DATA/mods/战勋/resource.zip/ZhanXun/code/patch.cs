﻿using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using HarmonyLib;
using ai.behaviours;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        // 添加击杀数阈值常量
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {1, "ZhanXun1"},
            {10, "ZhanXun2"},
            {20, "ZhanXun3"},
            {30, "ZhanXun4"},
            {50, "ZhanXun5"},
            {70, "ZhanXun6"},
            {100, "ZhanXun7"},
            {200, "ZhanXun8"},
            {300, "ZhanXun9"},
            {500, "ZhanXun91"},
            {700, "ZhanXun92"},
            {1000, "ZhanXun93"},
            {2000, "ZhanXun94"},
            {3000, "ZhanXun95"},
            {5000, "ZhanXun96"},
            {7000, "ZhanXun97"},
            {10000, "ZhanXun98"}
        };

        // 战勋等级映射表（从低到高）
        private static readonly Dictionary<string, int> ZhanXunLevels = new()
        {
            {"ZhanXun1", 1},
            {"ZhanXun2", 2},
            {"ZhanXun3", 3},
            {"ZhanXun4", 4},
            {"ZhanXun5", 5},
            {"ZhanXun6", 6},
            {"ZhanXun7", 7},
            {"ZhanXun8", 8},
            {"ZhanXun9", 9},
            {"ZhanXun91", 10},
            {"ZhanXun92", 11},
            {"ZhanXun93", 12},
            {"ZhanXun94", 13},
            {"ZhanXun95", 14},
            {"ZhanXun96", 15},
            {"ZhanXun97", 16},
            {"ZhanXun98", 17}
        };

        // 存储每个单位击杀国王数量的字典
        private static readonly Dictionary<long, int> KingKillCounts = new();

        // 获取单位的战勋等级
        private static int GetZhanXunLevel(Actor actor)
        {
            if (actor == null) return 0;

            int highestLevel = 0;
            foreach (var trait in actor.getTraits())
            {
                if (trait.group_id == "ZhanXun" && ZhanXunLevels.ContainsKey(trait.id))
                {
                    int level = ZhanXunLevels[trait.id];
                    if (level > highestLevel)
                    {
                        highestLevel = level;
                    }
                }
            }
            return highestLevel;
        }

        // 获取单位击杀国王数量
        private static int GetKingKillCount(Actor actor)
        {
            if (actor == null) return 0;
            return KingKillCounts.TryGetValue(actor.getID(), out int count) ? count : 0;
        }

        // 增加单位击杀国王数量
        private static void IncrementKingKillCount(Actor actor)
        {
            if (actor == null) return;
            long actorId = actor.getID();
            if (KingKillCounts.ContainsKey(actorId))
            {
                KingKillCounts[actorId]++;
            }
            else
            {
                KingKillCounts[actorId] = 1;
            }
        }

        // 添加击杀奖励，同组特质唯一
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance, Actor pDeadUnit)
        {
            if (__instance == null || !__instance.isAlive()) return;

            // 检查是否击杀了国王
            if (pDeadUnit != null && pDeadUnit.isKing())
            {
                IncrementKingKillCount(__instance);
                int kingKillCount = GetKingKillCount(__instance);

                // 如果击杀国王数量达到10个，给予额外特质
                if (kingKillCount >= 10 && !__instance.hasTrait("king_slayer_master"))
                {
                    __instance.addTrait("king_slayer_master", false);
                }
            }

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.kills >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanXun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanXun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);

                // 击杀数达到1时，赋予额外特质
                if (__instance.data.kills >= 1 && !__instance.hasTrait("fire_proof"))
                {
                    __instance.addTrait("fire_proof", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("freeze_proof"))
                {
                    __instance.addTrait("freeze_proof", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("immune"))
                {
                    __instance.addTrait("immune", false);
                }

                // 击杀数达到100时，赋予额外特质
                if (__instance.data.kills >= 100 && !__instance.hasTrait("strong_minded"))
                {
                    __instance.addTrait("strong_minded", false);
                }
            }
        }

        // Harmony 前缀补丁：拥有战勋特质的单位优先被招募为军人
        [HarmonyPrefix]
        [HarmonyPatch(typeof(City), "setCitizenJob")]
        public static bool City_setCitizenJob_Prefix(City __instance, Actor pActor)
        {
            // 国王和领主不会被招募为军人
            if (pActor.isKing() || pActor.isCityLeader())
            {
                return true; // 跳过招募逻辑，继续原方法
            }
            // 判断是否拥有任意战勋特质
            bool hasZhanXun = pActor.getTraits().Any(trait => trait.group_id == "ZhanXun");
            if (hasZhanXun && __instance.checkCanMakeWarrior(pActor))
            {
                __instance.makeWarrior(pActor);
                // 设置冷却
                var timerField = typeof(City).GetField("_timer_warrior", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (timerField != null)
                {
                    timerField.SetValue(__instance, 15f);
                }
                return false; // 阻止原方法
            }
            return true; // 继续原方法
        }

        // Harmony 前缀补丁：军队领袖选择时优先选择战勋等级最高的
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Army), "findCaptain")]
        public static bool Army_findCaptain_Prefix(Army __instance)
        {
            // 如果已经有队长且是文明单位，保持不变
            if (__instance.hasCaptain() && __instance.captain.isKingdomCiv())
            {
                return true; // 继续原方法
            }

            // 清除无效队长
            if (__instance.hasCaptain())
            {
                __instance.setCaptain(null);
            }

            // 如果没有军队成员，无法选择队长
            if (__instance.units.Count == 0)
            {
                return true; // 继续原方法
            }

            // 寻找战勋等级最高的单位
            Actor bestCandidate = null;
            int highestZhanXunLevel = -1;
            int bestDistance = int.MaxValue;

            foreach (var unit in __instance.units)
            {
                if (!unit.isAlive()) continue;

                int zhanXunLevel = GetZhanXunLevel(unit);

                // 如果有战勋特质，优先选择
                if (zhanXunLevel > 0)
                {
                    // 如果有原队长位置记录，计算距离
                    int distance = int.MaxValue;
                    if (__instance._prev_captain_position != null)
                    {
                        distance = Toolbox.SquaredDistTile(unit.current_tile, __instance._prev_captain_position);
                    }

                    // 选择战勋等级最高的，如果等级相同则选择距离 最近的
                    if (zhanXunLevel > highestZhanXunLevel ||
                        (zhanXunLevel == highestZhanXunLevel && distance < bestDistance))
                    {
                        bestCandidate = unit;
                        highestZhanXunLevel = zhanXunLevel;
                        bestDistance = distance;
                    }
                }
            }

            // 如果找到了有战勋特质的单位，设置为队长
            if (bestCandidate != null)
            {
                __instance.setCaptain(bestCandidate);
                return false; // 阻止原方法执行
            }

            // 如果没有找到有战勋特质的单位，按原方法执行
            return true; // 继续原方法
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), nameof(ActorTool.applyForceToUnit))]
        public static bool applyForceToUnit_Protection(AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            // 如果目标是Actor且有保护特质，则不被击退，阻止原方法
            if (pTargetToCheck.isActor() && HasProtectedTrait(pTargetToCheck.a))
            {
                return false; // 阻止原方法
            }
            // 允许原方法继续执行
            return true;
        }

        // 防止龙卷风效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止随机力效果
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
        {
            return !HasProtectedTrait(__instance);
        }

        // 拦截 makeStunned，拥有保护特质则不被眩晕
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
        {
            return !HasProtectedTrait(__instance);
        }

        // 防止获得震惊状态
        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
            {
                return !HasProtectedTrait(__instance);
            }
            return true;
        }

        private static readonly HashSet<string> ProtectedTraits = new()
        {
            "ZhanXun7", "ZhanXun8", "ZhanXun9", "ZhanXun91", "ZhanXun92",
            "ZhanXun93", "ZhanXun94", "ZhanXun95", "ZhanXun96", "ZhanXun97",
            "ZhanXun98"
        };

        private static bool HasProtectedTrait(Actor actor)
        {
            if (actor == null) return false;
            return ProtectedTraits.Any(trait => actor.hasTrait(trait));
        }

        // 只允许“战斗”、“跟随队长”以及上船/坐船相关AI，其它AI全部强制切到跟随
        [HarmonyPostfix]
        [HarmonyPatch(typeof(ArmyManager), nameof(ArmyManager.update))]
        public static void ForceOnlyFollowOrFightOrBoatAI()
        {
            // 允许的AI任务ID
            HashSet<string> allowedTasks = new HashSet<string>
            {
                "fighting",
                "warrior_army_follow_leader",
                "force_into_a_boat",
                "embark_into_boat",
                "sit_inside_boat"
                // 如有其它与跟随相关的AI任务可补充
            };

            foreach (var army in World.world.armies)
            {
                if (!IsPersonalArmy(army)) continue;
                var captain = army.captain;
                if (captain == null || !captain.isAlive()) continue;
                foreach (var member in army.units)
                {
                    if (member == null || member == captain || !member.isAlive()) continue;

                    // ======自动存仓 ======
                    if (member.isCarryingResources())
                    {
                        member.giveInventoryResourcesToCity();
                    }

                    // ======自动将战利品转化为金币 ======
                    if (member.loot > 0)
                    {
                        member.takeAllOwnLoot();
                    }

                    // ====== 自动原地完成恋爱、结婚、生育 ======
                    // 1. 恋爱：如果有恋爱对象且未成为恋人，直接成为恋人
                    var lover = member.lover;
                    if (lover != null && lover != member && !member.isClonedFrom(lover) && !member.isChildOf(lover) && !member.isParentOf(lover))
                    {
                        if (!(member.hasLover() && member.lover == lover))
                        {
                            member.becomeLoversWith(lover);
                        }
                    }
                    // 2. 生育：如果有恋人且能生育，直接触发原版怀孕流程（用状态）
                    if (lover != null && member.canBreed() && lover.canBreed() && member.isAdult() && lover.isAdult())
                    {
                        if (
                            lover != null &&
                            member.isSexFemale() &&
                            member.canBreed() &&
                            lover.canBreed() &&
                            !member.hasReachedOffspringLimit() // 新增：母体未超生
                        )
                        {
                            float maturationTime = member.getMaturationTimeSeconds();
                            member.addStatusEffect("pregnant", maturationTime, true);
                            member.addAfterglowStatus();
                            lover.addAfterglowStatus();
                        }
                        // ======================================
                    }
                    // ======================================

                    // ====== 自动原地完成进食 ======
                    if (member.isHungry())
                    {
                        member.addNutritionFromEating(member.getMaxNutrition(), false, true);
                        member.countConsumed();
                    }
                    // ======================================

                    // ====== 军人着火时原地灭火 ======
                    if (member.hasStatus("burning"))
                    {
                        member.finishStatusEffect("burning");
                    }

                    // ======================================

                    // ====== 自动移除残疾和眼瞎和烧伤特质 ======
                    if (member.hasTrait("crippled"))
                    {
                        member.removeTrait("crippled");
                    }
                    if (member.hasTrait("eyepatch"))
                    {
                        member.removeTrait("eyepatch");
                    }
                    if (member.hasTrait("skin_burns"))
                    {
                        member.removeTrait("skin_burns");
                    }
                    // ======================================

                    // 只允许上述AI，其它全部强制切到跟随
                    var curTask = member.ai?.task?.id;
                    if (string.IsNullOrEmpty(curTask) || !allowedTasks.Contains(curTask))
                    {
                        member.cancelAllBeh();
                        member.setTask("warrior_army_follow_leader", true, false, true);
                    }
                }
            }
        }
        private static bool IsPersonalArmy(Army army)
        {
            // 如果Army没有hasTrait方法，则默认所有军队都应用跟随逻辑
            // 如需只对特定军队生效，可在此自定义判断条件
            return true;
        }
    }
}