﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChivalryWizardingWorld.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset ZhanXun = new ActorTraitGroupAsset();
            ZhanXun.id = "ZhanXun";
            ZhanXun.name = "战勋";
            ZhanXun.color = "#FFFF00";
            AssetManager.trait_groups.add(ZhanXun);
        }
    }
}
