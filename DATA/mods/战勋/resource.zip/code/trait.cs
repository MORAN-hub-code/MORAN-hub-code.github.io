﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using strings;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        public static void Init()
        {
            ActorTrait ZhanXun1 = new ActorTrait();
            ZhanXun1.id = "ZhanXun1";
            ZhanXun1.path_icon = "trait/ZhanXun1";
            ZhanXun1.needs_to_be_explored = false;
            ZhanXun1.group_id = "ZhanXun";
            ZhanXun1.base_stats = new BaseStats();
            ZhanXun1.base_stats[strings.S.damage] = 1f;
            ZhanXun1.base_stats[strings.S.health] = 10f;
            AssetManager.traits.add(ZhanXun1);

            ActorTrait ZhanXun2 = new ActorTrait();
            ZhanXun2.id = "ZhanXun2";
            ZhanXun2.path_icon = "trait/ZhanXun2";
            ZhanXun2.needs_to_be_explored = false;
            ZhanXun2.group_id = "ZhanXun";
            ZhanXun2.base_stats = new BaseStats();
            ZhanXun2.base_stats[strings.S.damage] = 10f;
            ZhanXun2.base_stats[strings.S.health] = 100f;
            AssetManager.traits.add(ZhanXun2);

            ActorTrait ZhanXun3 = new ActorTrait();
            ZhanXun3.id = "ZhanXun3";
            ZhanXun3.path_icon = "trait/ZhanXun3";
            ZhanXun3.needs_to_be_explored = false;
            ZhanXun3.group_id = "ZhanXun";
            ZhanXun3.base_stats = new BaseStats();
            ZhanXun3.base_stats[strings.S.damage] = 20f;
            ZhanXun3.base_stats[strings.S.health] = 200f;
            AssetManager.traits.add(ZhanXun3);

            ActorTrait ZhanXun4 = new ActorTrait();
            ZhanXun4.id = "ZhanXun4";
            ZhanXun4.path_icon = "trait/ZhanXun4";
            ZhanXun4.needs_to_be_explored = false;
            ZhanXun4.group_id = "ZhanXun";
            ZhanXun4.base_stats = new BaseStats();
            ZhanXun4.base_stats[strings.S.damage] = 30f;
            ZhanXun4.base_stats[strings.S.health] = 300f;
            AssetManager.traits.add(ZhanXun4);

            ActorTrait ZhanXun5 = new ActorTrait();
            ZhanXun5.id = "ZhanXun5";
            ZhanXun5.path_icon = "trait/ZhanXun5";
            ZhanXun5.needs_to_be_explored = false;
            ZhanXun5.group_id = "ZhanXun";
            ZhanXun5.base_stats = new BaseStats();
            ZhanXun5.base_stats[strings.S.damage] = 50f;
            ZhanXun5.base_stats[strings.S.health] = 500f;
            AssetManager.traits.add(ZhanXun5);

            ActorTrait ZhanXun6 = new ActorTrait();
            ZhanXun6.id = "ZhanXun6";
            ZhanXun6.path_icon = "trait/ZhanXun6";
            ZhanXun6.needs_to_be_explored = false;
            ZhanXun6.group_id = "ZhanXun";
            ZhanXun6.base_stats = new BaseStats();
            ZhanXun6.base_stats[strings.S.damage] = 70f;
            ZhanXun6.base_stats[strings.S.health] = 700f;
            AssetManager.traits.add(ZhanXun6);

            ActorTrait ZhanXun7 = new ActorTrait();
            ZhanXun7.id = "ZhanXun7";
            ZhanXun7.path_icon = "trait/ZhanXun7";
            ZhanXun7.needs_to_be_explored = false;
            ZhanXun7.group_id = "ZhanXun";
            ZhanXun7.base_stats = new BaseStats();
            ZhanXun7.base_stats[strings.S.damage] = 100f;
            ZhanXun7.base_stats[strings.S.health] = 1000f;
            ZhanXun7.base_stats[strings.S.targets] = 1f;
            AssetManager.traits.add(ZhanXun7);

            ActorTrait ZhanXun8 = new ActorTrait();
            ZhanXun8.id = "ZhanXun8";
            ZhanXun8.path_icon = "trait/ZhanXun8";
            ZhanXun8.needs_to_be_explored = false;
            ZhanXun8.group_id = "ZhanXun";
            ZhanXun8.base_stats = new BaseStats();
            ZhanXun8.base_stats[strings.S.damage] = 200f;
            ZhanXun8.base_stats[strings.S.health] = 2000f;
            ZhanXun8.base_stats[strings.S.targets] = 2f;
            AssetManager.traits.add(ZhanXun8);

            ActorTrait ZhanXun9 = new ActorTrait();
            ZhanXun9.id = "ZhanXun9";
            ZhanXun9.path_icon = "trait/ZhanXun9";
            ZhanXun9.needs_to_be_explored = false;
            ZhanXun9.group_id = "ZhanXun";
            ZhanXun9.base_stats = new BaseStats();
            ZhanXun9.base_stats[strings.S.damage] = 300f;
            ZhanXun9.base_stats[strings.S.health] = 300f;
            ZhanXun9.base_stats[strings.S.targets] = 3f;
            AssetManager.traits.add(ZhanXun9);

            ActorTrait ZhanXun91 = new ActorTrait();
            ZhanXun91.id = "ZhanXun91";
            ZhanXun91.path_icon = "trait/ZhanXun91";
            ZhanXun91.needs_to_be_explored = false;
            ZhanXun91.group_id = "ZhanXun";
            ZhanXun91.base_stats = new BaseStats();
            ZhanXun91.base_stats[strings.S.damage] = 500f;
            ZhanXun91.base_stats[strings.S.health] = 5000f;
            ZhanXun91.base_stats[strings.S.targets] = 4f;
            ZhanXun91.base_stats[strings.S.multiplier_damage] = 0.5f;
            ZhanXun91.base_stats[strings.S.multiplier_health] = 0.5f;
            AssetManager.traits.add(ZhanXun91);

            ActorTrait ZhanXun92 = new ActorTrait();
            ZhanXun92.id = "ZhanXun92";
            ZhanXun92.path_icon = "trait/ZhanXun92";
            ZhanXun92.needs_to_be_explored = false;
            ZhanXun92.group_id = "ZhanXun";
            ZhanXun92.base_stats = new BaseStats();
            ZhanXun92.base_stats[strings.S.damage] = 700f;
            ZhanXun92.base_stats[strings.S.health] = 7000f;
            ZhanXun92.base_stats[strings.S.targets] = 5f;
            ZhanXun92.base_stats[strings.S.multiplier_damage] = 0.7f;
            ZhanXun92.base_stats[strings.S.multiplier_health] = 0.7f;
            AssetManager.traits.add(ZhanXun92);

            ActorTrait ZhanXun93 = new ActorTrait();
            ZhanXun93.id = "ZhanXun93";
            ZhanXun93.path_icon = "trait/ZhanXun93";
            ZhanXun93.needs_to_be_explored = false;
            ZhanXun93.group_id = "ZhanXun";
            ZhanXun93.base_stats = new BaseStats();
            ZhanXun93.base_stats[strings.S.damage] = 1000f;
            ZhanXun93.base_stats[strings.S.health] = 10000f;
            ZhanXun93.base_stats[strings.S.targets] = 6f;
            ZhanXun93.base_stats[strings.S.multiplier_damage] = 1f;
            ZhanXun93.base_stats[strings.S.multiplier_health] = 1f;
            AssetManager.traits.add(ZhanXun93);

            ActorTrait ZhanXun94 = new ActorTrait();
            ZhanXun94.id = "ZhanXun94";
            ZhanXun94.path_icon = "trait/ZhanXun94";
            ZhanXun94.needs_to_be_explored = false;
            ZhanXun94.group_id = "ZhanXun";
            ZhanXun94.base_stats = new BaseStats();
            ZhanXun94.base_stats[strings.S.damage] = 2000f;
            ZhanXun94.base_stats[strings.S.health] = 20000f;
            ZhanXun94.base_stats[strings.S.targets] = 7f;
            ZhanXun94.base_stats[strings.S.multiplier_damage] = 2f;
            ZhanXun94.base_stats[strings.S.multiplier_health] = 2f;
            AssetManager.traits.add(ZhanXun94);

            ActorTrait ZhanXun95 = new ActorTrait();
            ZhanXun95.id = "ZhanXun95";
            ZhanXun95.path_icon = "trait/ZhanXun95";
            ZhanXun95.needs_to_be_explored = false;
            ZhanXun95.group_id = "ZhanXun";
            ZhanXun95.base_stats = new BaseStats();
            ZhanXun95.base_stats[strings.S.damage] = 3000f;
            ZhanXun95.base_stats[strings.S.health] = 30000f;
            ZhanXun95.base_stats[strings.S.targets] = 8f;
            ZhanXun95.base_stats[strings.S.multiplier_damage] = 3f;
            ZhanXun95.base_stats[strings.S.multiplier_health] = 3f;
            AssetManager.traits.add(ZhanXun95);

            ActorTrait ZhanXun96 = new ActorTrait();
            ZhanXun96.id = "ZhanXun96";
            ZhanXun96.path_icon = "trait/ZhanXun96";
            ZhanXun96.needs_to_be_explored = false;
            ZhanXun96.group_id = "ZhanXun";
            ZhanXun96.base_stats = new BaseStats();
            ZhanXun96.base_stats[strings.S.damage] = 5000f;
            ZhanXun96.base_stats[strings.S.health] = 50000f;
            ZhanXun96.base_stats[strings.S.targets] = 9f;
            ZhanXun96.base_stats[strings.S.multiplier_damage] = 5f;
            ZhanXun96.base_stats[strings.S.multiplier_health] = 5f;
            AssetManager.traits.add(ZhanXun96);

            ActorTrait ZhanXun97 = new ActorTrait();
            ZhanXun97.id = "ZhanXun97";
            ZhanXun97.path_icon = "trait/ZhanXun97";
            ZhanXun97.needs_to_be_explored = false;
            ZhanXun97.group_id = "ZhanXun";
            ZhanXun97.base_stats = new BaseStats();
            ZhanXun97.base_stats[strings.S.damage] = 7000f;
            ZhanXun97.base_stats[strings.S.health] = 70000f;
            ZhanXun97.base_stats[strings.S.targets] = 10f;
            ZhanXun97.base_stats[strings.S.multiplier_damage] = 7f;
            ZhanXun97.base_stats[strings.S.multiplier_health] = 7f;
            AssetManager.traits.add(ZhanXun97);

            ActorTrait ZhanXun98 = new ActorTrait();
            ZhanXun98.id = "ZhanXun98";
            ZhanXun98.path_icon = "trait/ZhanXun98";
            ZhanXun98.needs_to_be_explored = false;
            ZhanXun98.group_id = "ZhanXun";
            ZhanXun98.base_stats = new BaseStats();
            ZhanXun98.base_stats[strings.S.damage] = 10000f;
            ZhanXun98.base_stats[strings.S.health] = 100000f;
            ZhanXun98.base_stats[strings.S.targets] = 11f;
            ZhanXun98.base_stats[strings.S.multiplier_damage] = 10f;
            ZhanXun98.base_stats[strings.S.multiplier_health] = 10f;
            AssetManager.traits.add(ZhanXun98);
        }
    }
}