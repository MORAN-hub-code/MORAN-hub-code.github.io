﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        // 添加击杀数阈值常量
        private static readonly Dictionary<int, string> KillRewardTraits = new()
        {
            {1, "ZhanXun1"},
            {10, "ZhanXun2"},
            {20, "ZhanXun3"},
            {30, "ZhanXun4"},
            {50, "ZhanXun5"},
            {70, "ZhanXun6"},
            {100, "ZhanXun7"},
            {200, "ZhanXun8"},
            {300, "ZhanXun9"},
            {500, "ZhanXun91"},
            {700, "ZhanXun92"},
            {1000, "ZhanXun93"},
            {2000, "ZhanXun94"},
            {3000, "ZhanXun95"},
            {5000, "ZhanXun96"},
            {7000, "ZhanXun97"},
            {10000, "ZhanXun98"}
        };

        // 添加击杀奖励，同组特质唯一
        [HarmonyPostfix]
        [HarmonyPatch(typeof(Actor), "newKillAction")]
        public static void Actor_newKillAction_Postfix(Actor __instance)
        {
            if (__instance == null || !__instance.isAlive()) return;

            string highestTraitId = null;
            // 从高到低遍历，找到单位当前击杀数能获得的最高级特质
            foreach (var killReward in KillRewardTraits.Reverse())
            {
                if (__instance.data.kills >= killReward.Key)
                {
                    highestTraitId = killReward.Value;
                    break;
                }
            }

            // 如果找到了应该有的特质，并且单位还没有这个特质
            if (highestTraitId != null && !__instance.hasTrait(highestTraitId))
            {
                // 找到所有已有的"ZhanXun"特质
                var traitsToRemove = new List<ActorTrait>();
                foreach (var trait in __instance.getTraits())
                {
                    if (trait.group_id == "ZhanXun")
                    {
                        traitsToRemove.Add(trait);
                    }
                }

                // 移除所有旧的"ZhanXun"特质
                if (traitsToRemove.Count > 0)
                {
                    __instance.removeTraits(traitsToRemove);
                }

                // 添加新的、最高级的特质
                __instance.addTrait(highestTraitId, false);
            }
        }

        private static bool IsBasicRaceOrCiv(string assetId)
        {
            // ... existing code ...
            return false; // Placeholder return, actual implementation needed
        }
    }
}