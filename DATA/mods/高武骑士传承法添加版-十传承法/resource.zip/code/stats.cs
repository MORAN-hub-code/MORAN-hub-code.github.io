﻿namespace Chevalier.code
{
    internal class stats
    {
        public static BaseStatAsset knockback_reduction;

        public static void Init()
        {
            BaseStatAsset Chevalier = new BaseStatAsset();
            Chevalier.id = "Chevalier";
            Chevalier.normalize = true;
            Chevalier.normalize_min = -999999;
            Chevalier.normalize_max = 999999;
            //Chevalier.multiplier = true;
            Chevalier.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Chevalier);

            // 定义 knockback_reduction 属性
            knockback_reduction = new BaseStatAsset();
            knockback_reduction.id = "knockback_reduction";
            knockback_reduction.normalize = true;
            knockback_reduction.normalize_min = 0;
            knockback_reduction.normalize_max = 999999;
            knockback_reduction.used_only_for_civs = false;
            AssetManager.base_stats_library.add(knockback_reduction);

            BaseStatAsset Shan = new BaseStatAsset();
            Shan.id = "Shan";// 闪避率
            Shan.normalize = true;
            Shan.normalize_min = 0;
            Shan.normalize_max = 99999;
            Shan.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Shan);

            BaseStatAsset Ming = new BaseStatAsset();
            Ming.id = "Ming";// 命中率
            Ming.normalize = true;
            Ming.normalize_min = 0;
            Ming.normalize_max = 99999;
            Ming.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Ming);
        }
    }
}