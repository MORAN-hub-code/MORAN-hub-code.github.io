﻿namespace Chevalier.code
{
    internal class stats
    {
        public static BaseStatAsset knockback_reduction;

        public static void Init()
        {
            BaseStatAsset Chevalier = new BaseStatAsset();
            Chevalier.id = "Chevalier";
            Chevalier.normalize = true;
            Chevalier.normalize_min = -999999;
            Chevalier.normalize_max = 999999;
            //Chevalier.multiplier = true;
            Chevalier.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Chevalier);

            // 定义 knockback_reduction 属性
            knockback_reduction = new BaseStatAsset();
            knockback_reduction.id = "knockback_reduction";
            knockback_reduction.normalize = true;
            knockback_reduction.normalize_min = 0;
            knockback_reduction.normalize_max = 999999;
            knockback_reduction.used_only_for_civs = false;
            AssetManager.base_stats_library.add(knockback_reduction);

            BaseStatAsset Shanbi = new BaseStatAsset();
            Shanbi.id = "Shanbi";// 闪避率
            Shanbi.normalize = true;
            Shanbi.normalize_min = 0;
            Shanbi.normalize_max = 99999;
            Shanbi.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Shanbi);

            BaseStatAsset Mingzhong = new BaseStatAsset();
            Mingzhong.id = "Mingzhong";// 命中率
            Mingzhong.normalize = true;
            Mingzhong.normalize_min = 0;
            Mingzhong.normalize_max = 99999;
            Mingzhong.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Mingzhong);
        }
    }
}