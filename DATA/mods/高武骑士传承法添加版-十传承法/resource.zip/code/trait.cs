﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using strings;

namespace Chevalier.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        public static ActorTrait GermofLife_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait GermofLife = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "ChivalricFoundations",
                needs_to_be_explored = false
            };
            GermofLife.action_special_effect += traitAction.Chevalier1_effectAction;
            AssetManager.traits.add(GermofLife);
            return GermofLife;
        }
        public static void Init()
        {
            ActorTrait GermofLife4 = GermofLife_AddActorTrait("GermofLife4", "trait/GermofLife4");
            GermofLife4.rarity = Rarity.R2_Epic;

            ActorTrait GermofLife7 = GermofLife_AddActorTrait("GermofLife7", "trait/GermofLife7");
            GermofLife7.rarity = Rarity.R2_Epic;
        
            ActorTrait GermofLife8 = GermofLife_AddActorTrait("GermofLife8", "trait/GermofLife8");
            GermofLife8.rarity = Rarity.R3_Legendary;

            _=GermofLife_AddActorTrait("GermofLife1", "trait/GermofLife1");
            _=GermofLife_AddActorTrait("GermofLife2", "trait/GermofLife2");
            _=GermofLife_AddActorTrait("GermofLife3", "trait/GermofLife3");

            ActorTrait GermofLife9 = CreateTrait("GermofLife9", "trait/GermofLife9", "ChivalricFoundations");
            GermofLife9.rate_inherit = 100;
            AssetManager.traits.add(GermofLife9);

            ActorTrait GermofLife10 = CreateTrait("GermofLife10", "trait/GermofLife10", "ChivalricFoundations");
            AssetManager.traits.add(GermofLife10);

            ActorTrait Chevalier02 = CreateTrait("Chevalier2+", "trait/Chevalier2+", "Chevalier");
            SafeSetStat(Chevalier02.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(Chevalier02.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(Chevalier02.base_stats, strings.S.loyalty_traits, -1f);
            AssetManager.traits.add(Chevalier02);

            ActorTrait Chevalier03 = CreateTrait("Chevalier3+", "trait/Chevalier3+", "Chevalier");
            SafeSetStat(Chevalier03.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(Chevalier03.base_stats, strings.S.skill_combat, 0.2f);
            SafeSetStat(Chevalier03.base_stats, strings.S.loyalty_traits, -5f);
            AssetManager.traits.add(Chevalier03);

            ActorTrait Chevalier04 = CreateTrait("Chevalier4+", "trait/Chevalier4+", "Chevalier");
            SafeSetStat(Chevalier04.base_stats , strings.S.lifespan, 30f);
            SafeSetStat(Chevalier04.base_stats , strings.S.skill_combat, 0.3f);
            SafeSetStat(Chevalier04.base_stats, strings.S.loyalty_traits, -10f);
            AssetManager.traits.add(Chevalier04);

            ActorTrait Chevalier05 = CreateTrait("Chevalier5+", "trait/Chevalier5+", "Chevalier");
            SafeSetStat(Chevalier05.base_stats , strings.S.lifespan, 50f);
            SafeSetStat(Chevalier05.base_stats , strings.S.skill_combat, 0.4f);
            SafeSetStat(Chevalier05.base_stats, strings.S.loyalty_traits, -20f);
            AssetManager.traits.add(Chevalier05);

            ActorTrait Chevalier06 = CreateTrait("Chevalier6+", "trait/Chevalier6+", "Chevalier");
            SafeSetStat(Chevalier06.base_stats , strings.S.lifespan, 80f);
            SafeSetStat(Chevalier06.base_stats , strings.S.skill_combat, 0.5f);
            SafeSetStat(Chevalier06.base_stats, strings.S.loyalty_traits, -30f);
            AssetManager.traits.add(Chevalier06);

            ActorTrait Chevalier07 = CreateTrait("Chevalier7+", "trait/Chevalier7+", "Chevalier");
            SafeSetStat(Chevalier07.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(Chevalier07.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(Chevalier07.base_stats, strings.S.loyalty_traits, -40f);
            AssetManager.traits.add(Chevalier07);

            ActorTrait Chevalier08 = CreateTrait("Chevalier8+", "trait/Chevalier8+", "Chevalier");
            SafeSetStat(Chevalier08.base_stats, strings.S.lifespan, 150f);
            SafeSetStat(Chevalier08.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(Chevalier08.base_stats, strings.S.loyalty_traits, -60f);
            AssetManager.traits.add(Chevalier08);

            ActorTrait Chevalier09 = CreateTrait("Chevalier9+", "trait/Chevalier9+", "Chevalier");
            SafeSetStat(Chevalier09.base_stats, strings.S.lifespan, 240f);
            SafeSetStat(Chevalier09.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(Chevalier09.base_stats, strings.S.loyalty_traits, -80f);
            AssetManager.traits.add(Chevalier09);

            ActorTrait Chevalier091 = CreateTrait("Chevalier91+", "trait/Chevalier91+", "Chevalier");
            SafeSetStat(Chevalier091.base_stats, strings.S.lifespan, 400f);
            SafeSetStat(Chevalier091.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(Chevalier091.base_stats, strings.S.loyalty_traits, -120f);
            AssetManager.traits.add(Chevalier091);

            ActorTrait Chevalier092 = CreateTrait("Chevalier92+", "trait/Chevalier92+", "Chevalier");
            SafeSetStat(Chevalier092.base_stats, strings.S.lifespan, 800f);
            SafeSetStat(Chevalier092.base_stats, strings.S.skill_combat, 0.7f);
            SafeSetStat(Chevalier092.base_stats, strings.S.loyalty_traits, -300f);
            AssetManager.traits.add(Chevalier092);

            ActorTrait Chevalier093 = CreateTrait("Chevalier93+", "trait/Chevalier93+", "Chevalier");
            SafeSetStat(Chevalier093.base_stats, strings.S.lifespan, 10000f);
            SafeSetStat(Chevalier093.base_stats, strings.S.skill_combat, 0.8f);
            SafeSetStat(Chevalier093.base_stats, strings.S.loyalty_traits, -500f);
            AssetManager.traits.add(Chevalier093);

            ActorTrait Chevalier1 = CreateTrait("Chevalier1", "trait/Chevalier1", "Chevalier");
            SafeSetStat(Chevalier1.base_stats, stats.knockback_reduction.id, 0.5f);
            SafeSetStat(Chevalier1.base_stats, strings.S.damage, 60f);
            SafeSetStat(Chevalier1.base_stats, strings.S.mass, 5.0f);
            SafeSetStat(Chevalier1.base_stats, strings.S.health, 200f);
            SafeSetStat(Chevalier1.base_stats, strings.S.stamina, 10f);
            SafeSetStat(Chevalier1.base_stats, "Shan", 120f);
            SafeSetStat(Chevalier1.base_stats, "Ming", 110f);
            Chevalier1.action_special_effect += traitAction.Chevalier2_effectAction;
            Chevalier1.action_special_effect += traitAction.Chevalier1_Regen;
            AssetManager.traits.add(Chevalier1);

            ActorTrait Chevalier2 = CreateTrait("Chevalier2", "trait/Chevalier2", "Chevalier");
            SafeSetStat(Chevalier2.base_stats, stats.knockback_reduction.id, 1.0f);
            SafeSetStat(Chevalier2.base_stats , strings.S.damage, 120f);
            SafeSetStat(Chevalier2.base_stats, strings.S.mass, 10f);
            SafeSetStat(Chevalier2.base_stats , strings.S.health, 400f);
            SafeSetStat(Chevalier2.base_stats , strings.S.accuracy, 2f);
            SafeSetStat(Chevalier2.base_stats , strings.S.multiplier_speed, 0.1f);
            SafeSetStat(Chevalier2.base_stats , strings.S.stamina, 20f);
            SafeSetStat(Chevalier2.base_stats, "Shan", 130f);
            SafeSetStat(Chevalier2.base_stats, "Ming", 110f);
            Chevalier2.action_special_effect += traitAction.Chevalier3_effectAction;
            Chevalier2.action_special_effect += traitAction.Chevalier2_Regen;
            AssetManager.traits.add(Chevalier2);

            ActorTrait Chevalier3 = CreateTrait("Chevalier3", "trait/Chevalier3", "Chevalier");
            SafeSetStat(Chevalier3.base_stats, stats.knockback_reduction.id, 2.0f);
            SafeSetStat(Chevalier3.base_stats , strings.S.damage, 240f);
            SafeSetStat(Chevalier3.base_stats, strings.S.mass, 10f);
            SafeSetStat(Chevalier3.base_stats , strings.S.health, 800f);
            SafeSetStat(Chevalier3.base_stats , strings.S.armor, 5f);
            SafeSetStat(Chevalier3.base_stats , strings.S.targets, 0.1f);
            SafeSetStat(Chevalier3.base_stats , strings.S.accuracy, 5f);
            SafeSetStat(Chevalier3.base_stats , strings.S.multiplier_speed, 0.2f);
            SafeSetStat(Chevalier3.base_stats , strings.S.stamina, 30f);
            SafeSetStat(Chevalier3.base_stats, "Shan", 140f);
            SafeSetStat(Chevalier3.base_stats, "Ming", 110f);
            Chevalier3.action_special_effect += traitAction.Chevalier4_effectAction;
            Chevalier3.action_special_effect += traitAction.Chevalier3_Regen;
            AssetManager.traits.add(Chevalier3);

            ActorTrait Chevalier4 = CreateTrait("Chevalier4", "trait/Chevalier4", "Chevalier");
            SafeSetStat(Chevalier4.base_stats, stats.knockback_reduction.id, 4.0f);
            SafeSetStat(Chevalier4.base_stats , strings.S.damage, 300f);
            SafeSetStat(Chevalier4.base_stats, strings.S.mass, 10f);
            SafeSetStat(Chevalier4.base_stats , strings.S.health, 1600f);
            SafeSetStat(Chevalier4.base_stats , strings.S.speed, 5f);
            SafeSetStat(Chevalier4.base_stats , strings.S.armor, 10f);
            SafeSetStat(Chevalier4.base_stats , strings.S.targets, 1f);
            SafeSetStat(Chevalier4.base_stats , strings.S.critical_chance, 0.2f);
            SafeSetStat(Chevalier4.base_stats , strings.S.accuracy, 10f);
            SafeSetStat(Chevalier4.base_stats , strings.S.multiplier_speed, 0.3f);
            SafeSetStat(Chevalier4.base_stats , strings.S.stamina, 40f);
            SafeSetStat(Chevalier4.base_stats, "Shan", 150f);
            SafeSetStat(Chevalier4.base_stats, "Ming", 110f);
            Chevalier4.action_special_effect += traitAction.Chevalier5_effectAction;
            Chevalier4.action_special_effect += traitAction.Chevalier4_Regen;
            AssetManager.traits.add(Chevalier4);

            ActorTrait Chevalier5 = CreateTrait("Chevalier5", "trait/Chevalier5", "Chevalier");
            SafeSetStat(Chevalier5.base_stats, stats.knockback_reduction.id, 8.0f);
            SafeSetStat(Chevalier5.base_stats , strings.S.warfare, 10f);
            SafeSetStat(Chevalier5.base_stats, strings.S.mass, 15f);
            SafeSetStat(Chevalier5.base_stats , strings.S.damage, 600f);
            SafeSetStat(Chevalier5.base_stats , strings.S.health, 3200f);
            SafeSetStat(Chevalier5.base_stats , strings.S.speed, 10f);
            SafeSetStat(Chevalier5.base_stats , strings.S.armor, 15f);
            SafeSetStat(Chevalier5.base_stats , strings.S.targets, 2f);
            SafeSetStat(Chevalier5.base_stats , strings.S.critical_chance, 0.3f);
            SafeSetStat(Chevalier5.base_stats , strings.S.accuracy, 20f);
            SafeSetStat(Chevalier5.base_stats , strings.S.multiplier_speed, 0.4f);
            SafeSetStat(Chevalier5.base_stats , strings.S.stamina, 50f);
            SafeSetStat(Chevalier5.base_stats, "Shan", 180f);
            SafeSetStat(Chevalier5.base_stats, "Ming", 140f);
            Chevalier5.action_special_effect += traitAction.Chevalier6_effectAction;
            Chevalier5.action_special_effect += traitAction.Chevalier5_Regen;
            AssetManager.traits.add(Chevalier5);

            ActorTrait Chevalier6 = CreateTrait("Chevalier6", "trait/Chevalier6", "Chevalier");
            Chevalier6.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier6.base_stats, stats.knockback_reduction.id, 16.0f);
            SafeSetStat(Chevalier6.base_stats , strings.S.warfare, 20f);
            SafeSetStat(Chevalier6.base_stats, strings.S.mass, 20f);
            SafeSetStat(Chevalier6.base_stats , strings.S.damage, 1200f);
            SafeSetStat(Chevalier6.base_stats , strings.S.armor, 25f);
            SafeSetStat(Chevalier6.base_stats , strings.S.health, 6400f);
            SafeSetStat(Chevalier6.base_stats , strings.S.speed, 15f);
            SafeSetStat(Chevalier6.base_stats , strings.S.area_of_effect, 1f);
            SafeSetStat(Chevalier6.base_stats , strings.S.targets, 5f);
            SafeSetStat(Chevalier6.base_stats , strings.S.critical_chance, 0.5f);
            SafeSetStat(Chevalier6.base_stats , strings.S.accuracy, 30f);
            SafeSetStat(Chevalier6.base_stats , strings.S.multiplier_speed, 0.6f);
            SafeSetStat(Chevalier6.base_stats , strings.S.stamina, 70f);
            SafeSetStat(Chevalier6.base_stats, "Shan", 200f);
            SafeSetStat(Chevalier6.base_stats, "Ming", 160f);
            Chevalier6.action_special_effect += traitAction.Chevalier7_effectAction;
            Chevalier6.action_special_effect += traitAction.Chevalier6_Regen;
            Chevalier6.action_attack_target += traitAction.TrueDamage1_AttackAction;
            AssetManager.traits.add(Chevalier6);

            ActorTrait Chevalier7 = CreateTrait("Chevalier7", "trait/Chevalier7", "Chevalier");
            Chevalier7.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier7.base_stats, stats.knockback_reduction.id, 32.0f);
            SafeSetStat(Chevalier7.base_stats, strings.S.warfare, 30f);
            SafeSetStat(Chevalier7.base_stats, strings.S.damage, 2400f);
            SafeSetStat(Chevalier7.base_stats, strings.S.mass, 25f);
            SafeSetStat(Chevalier7.base_stats, strings.S.armor, 35f);
            SafeSetStat(Chevalier7.base_stats, strings.S.health, 10000f);
            SafeSetStat(Chevalier7.base_stats, strings.S.speed, 20f);
            SafeSetStat(Chevalier7.base_stats, strings.S.area_of_effect, 2f);
            SafeSetStat(Chevalier7.base_stats, strings.S.targets, 7f);
            SafeSetStat(Chevalier7.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(Chevalier7.base_stats, strings.S.accuracy, 40f);
            SafeSetStat(Chevalier7.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(Chevalier7.base_stats, strings.S.stamina, 140f);
            SafeSetStat(Chevalier7.base_stats, strings.S.range, 2f);
            SafeSetStat(Chevalier7.base_stats, strings.S.attack_speed, 2f);
            SafeSetStat(Chevalier7.base_stats, strings.S.scale, 0.04f);
            SafeSetStat(Chevalier7.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(Chevalier7.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(Chevalier7.base_stats, "Shan", 220f);
            SafeSetStat(Chevalier7.base_stats, "Ming", 180f);
            Chevalier7.action_attack_target += traitAction.TrueDamage2_AttackAction;
            Chevalier7.action_special_effect += traitAction.Chevalier8_effectAction;
            Chevalier7.action_special_effect += traitAction.Chevalier7_Regen;
            AssetManager.traits.add(Chevalier7);

            ActorTrait Chevalier8 = CreateTrait("Chevalier8", "trait/Chevalier8", "Chevalier");
            Chevalier8.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier8.base_stats, stats.knockback_reduction.id, 64.0f);
            SafeSetStat(Chevalier8.base_stats, strings.S.warfare, 40f);
            SafeSetStat(Chevalier8.base_stats, strings.S.damage, 4800f);
            SafeSetStat(Chevalier8.base_stats, strings.S.mass, 60f);
            SafeSetStat(Chevalier8.base_stats, strings.S.armor, 45f);
            SafeSetStat(Chevalier8.base_stats, strings.S.health, 24000f);
            SafeSetStat(Chevalier8.base_stats, strings.S.speed, 25f);
            SafeSetStat(Chevalier8.base_stats, strings.S.area_of_effect, 3f);
            SafeSetStat(Chevalier8.base_stats, strings.S.targets, 9f);
            SafeSetStat(Chevalier8.base_stats, strings.S.critical_chance, 0.7f);
            SafeSetStat(Chevalier8.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(Chevalier8.base_stats, strings.S.multiplier_speed, 1.0f);
            SafeSetStat(Chevalier8.base_stats, strings.S.stamina, 240f);
            SafeSetStat(Chevalier8.base_stats, strings.S.range, 4f);
            SafeSetStat(Chevalier8.base_stats, strings.S.attack_speed, 4f);
            SafeSetStat(Chevalier8.base_stats, strings.S.multiplier_health, 0.4f);
            SafeSetStat(Chevalier8.base_stats, strings.S.multiplier_damage, 0.4f);
            SafeSetStat(Chevalier8.base_stats, strings.S.scale, 0.06f);
            SafeSetStat(Chevalier8.base_stats, "Shan", 260f);
            SafeSetStat(Chevalier8.base_stats, "Ming", 220f);
            Chevalier8.action_attack_target += traitAction.TrueDamage3_AttackAction;
            Chevalier8.action_special_effect += traitAction.Chevalier9_effectAction;
            Chevalier8.action_special_effect += traitAction.Chevalier8_Regen;
            AssetManager.traits.add(Chevalier8);

            ActorTrait Chevalier9 = CreateTrait("Chevalier9", "trait/Chevalier9", "Chevalier");
            Chevalier9.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier9.base_stats, stats.knockback_reduction.id, 128.0f);
            SafeSetStat(Chevalier9.base_stats, strings.S.warfare, 50f);
            SafeSetStat(Chevalier9.base_stats, strings.S.damage, 9600f);
            SafeSetStat(Chevalier9.base_stats, strings.S.mass, 140f);
            SafeSetStat(Chevalier9.base_stats, strings.S.armor, 60f);
            SafeSetStat(Chevalier9.base_stats, strings.S.health, 48000f);
            SafeSetStat(Chevalier9.base_stats, strings.S.speed, 30f);
            SafeSetStat(Chevalier9.base_stats, strings.S.area_of_effect, 4f);
            SafeSetStat(Chevalier9.base_stats, strings.S.targets, 12f);
            SafeSetStat(Chevalier9.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(Chevalier9.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(Chevalier9.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(Chevalier9.base_stats, strings.S.stamina, 400f);
            SafeSetStat(Chevalier9.base_stats, strings.S.range, 6f);
            SafeSetStat(Chevalier9.base_stats, strings.S.attack_speed, 6f);
            SafeSetStat(Chevalier9.base_stats, strings.S.scale, 0.08f);
            SafeSetStat(Chevalier9.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(Chevalier9.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(Chevalier9.base_stats, "Shan", 300f);
            SafeSetStat(Chevalier9.base_stats, "Ming", 260f);
            Chevalier9.action_attack_target += traitAction.TrueDamage4_AttackAction;
            Chevalier9.action_special_effect += traitAction.Chevalier91_effectAction;
            Chevalier9.action_special_effect += traitAction.Chevalier9_Regen;
            AssetManager.traits.add(Chevalier9);

            ActorTrait Chevalier91 = CreateTrait("Chevalier91", "trait/Chevalier91", "Chevalier");
            Chevalier91.rarity = Rarity.R3_Legendary;
            SafeSetStat(Chevalier91.base_stats, stats.knockback_reduction.id, 160.0f);
            SafeSetStat(Chevalier91.base_stats, strings.S.warfare, 70f);
            SafeSetStat(Chevalier91.base_stats, strings.S.damage, 19200f);
            SafeSetStat(Chevalier91.base_stats, strings.S.mass, 400f);
            SafeSetStat(Chevalier91.base_stats, strings.S.armor, 80f);
            SafeSetStat(Chevalier91.base_stats, strings.S.health, 96000f);
            SafeSetStat(Chevalier91.base_stats, strings.S.speed, 50f);
            SafeSetStat(Chevalier91.base_stats, strings.S.area_of_effect, 5f);
            SafeSetStat(Chevalier91.base_stats, strings.S.targets, 15f);
            SafeSetStat(Chevalier91.base_stats, strings.S.critical_chance, 0.9f);
            SafeSetStat(Chevalier91.base_stats, strings.S.accuracy, 80f);
            SafeSetStat(Chevalier91.base_stats, strings.S.multiplier_speed, 1.5f);
            SafeSetStat(Chevalier91.base_stats, strings.S.stamina, 600f);
            SafeSetStat(Chevalier91.base_stats, strings.S.range, 12f);
            SafeSetStat(Chevalier91.base_stats, strings.S.attack_speed, 12f);
            SafeSetStat(Chevalier91.base_stats, strings.S.scale, 0.1f);
            SafeSetStat(Chevalier91.base_stats, strings.S.multiplier_health, 1.2f);
            SafeSetStat(Chevalier91.base_stats, strings.S.multiplier_damage, 1.2f);
            SafeSetStat(Chevalier91.base_stats, "Shan", 340f);
            SafeSetStat(Chevalier91.base_stats, "Ming", 300f);
            Chevalier91.action_special_effect += traitAction.Chevalier92_effectAction;
            Chevalier91.action_special_effect += traitAction.Chevalier91_Regen;
            Chevalier91.action_attack_target += traitAction.TrueDamage5_AttackAction;
            Chevalier91.action_attack_target += traitAction.fire1_attackAction;
            AssetManager.traits.add(Chevalier91);

            ActorTrait Chevalier92 = CreateTrait("Chevalier92", "trait/Chevalier92", "Chevalier");
            Chevalier92.rarity = Rarity.R3_Legendary;
            SafeSetStat(Chevalier92.base_stats, stats.knockback_reduction.id, 200.0f);
            SafeSetStat(Chevalier92.base_stats, strings.S.warfare, 100f);
            SafeSetStat(Chevalier92.base_stats, strings.S.damage, 38400f);
            SafeSetStat(Chevalier92.base_stats, strings.S.mass, 1600f);
            SafeSetStat(Chevalier92.base_stats, strings.S.armor, 100f);
            SafeSetStat(Chevalier92.base_stats, strings.S.health, 248000f);
            SafeSetStat(Chevalier92.base_stats, strings.S.speed, 100f);
            SafeSetStat(Chevalier92.base_stats, strings.S.area_of_effect, 7f);
            SafeSetStat(Chevalier92.base_stats, strings.S.targets, 20f);
            SafeSetStat(Chevalier92.base_stats, strings.S.critical_chance, 1.0f);
            SafeSetStat(Chevalier92.base_stats, strings.S.accuracy, 100f);
            SafeSetStat(Chevalier92.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(Chevalier92.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(Chevalier92.base_stats, strings.S.range, 20f);
            SafeSetStat(Chevalier92.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(Chevalier92.base_stats, strings.S.scale, 0.15f);
            SafeSetStat(Chevalier92.base_stats, strings.S.multiplier_health, 2f);
            SafeSetStat(Chevalier92.base_stats, strings.S.multiplier_damage, 2f);
            SafeSetStat(Chevalier92.base_stats, "Shan", 400f);
            SafeSetStat(Chevalier92.base_stats, "Ming", 360f);
            Chevalier92.action_special_effect += traitAction.Chevalier93_effectAction;
            Chevalier92.action_special_effect += traitAction.Chevalier92_Regen;
            Chevalier92.action_attack_target += traitAction.TrueDamage6_AttackAction;
            Chevalier92.action_attack_target += traitAction.fire1_attackAction;
            AssetManager.traits.add(Chevalier92);

            ActorTrait Chevalier93 = CreateTrait("Chevalier93", "trait/Chevalier93", "Chevalier");
            Chevalier93.rarity = Rarity.R3_Legendary;
            SafeSetStat(Chevalier93.base_stats, stats.knockback_reduction.id, 240.0f);
            SafeSetStat(Chevalier93.base_stats, strings.S.warfare, 150f);
            SafeSetStat(Chevalier93.base_stats, strings.S.damage, 80000f);
            SafeSetStat(Chevalier93.base_stats, strings.S.mass, 2400f);
            SafeSetStat(Chevalier93.base_stats, strings.S.armor, 150f);
            SafeSetStat(Chevalier93.base_stats, strings.S.health, 1000000f);
            SafeSetStat(Chevalier93.base_stats, strings.S.speed, 300f);
            SafeSetStat(Chevalier93.base_stats, strings.S.area_of_effect, 10f);
            SafeSetStat(Chevalier93.base_stats, strings.S.targets, 25f);
            SafeSetStat(Chevalier93.base_stats, strings.S.critical_chance, 1.5f);
            SafeSetStat(Chevalier93.base_stats, strings.S.accuracy, 150f);
            SafeSetStat(Chevalier93.base_stats, strings.S.multiplier_speed, 3.0f);
            SafeSetStat(Chevalier93.base_stats, strings.S.stamina, 10000f);
            SafeSetStat(Chevalier93.base_stats, strings.S.range, 30f);
            SafeSetStat(Chevalier93.base_stats, strings.S.attack_speed, 30f);
            SafeSetStat(Chevalier93.base_stats, strings.S.scale, 0.2f);
            SafeSetStat(Chevalier93.base_stats, strings.S.multiplier_health, 3f);
            SafeSetStat(Chevalier93.base_stats, strings.S.multiplier_damage, 3f);    
            SafeSetStat(Chevalier93.base_stats, "Shan", 500f);
            SafeSetStat(Chevalier93.base_stats, "Ming", 470f);
            Chevalier93.action_special_effect += traitAction.Chevalier93_Regen;
            Chevalier93.action_attack_target += traitAction.TrueDamage7_AttackAction;
            Chevalier93.action_attack_target += traitAction.fire2_attackAction;
            AssetManager.traits.add(Chevalier93);

            ActorTrait Chevalier94 = CreateTrait("Chevalier94", "trait/Chevalier94", "Chevalier");
            SafeSetStat(Chevalier94.base_stats, strings.S.multiplier_lifespan, -0.05f);
            SafeSetStat(Chevalier94.base_stats, strings.S.multiplier_health, -0.05f);
            SafeSetStat(Chevalier94.base_stats, strings.S.multiplier_damage, -0.05f);
            AssetManager.traits.add(Chevalier94);

            ActorTrait Chevalier95 = CreateTrait("Chevalier95", "trait/Chevalier95", "Chevalier");
            SafeSetStat(Chevalier95.base_stats, strings.S.multiplier_lifespan, -0.1f);
            SafeSetStat(Chevalier95.base_stats, strings.S.multiplier_health, -0.1f);
            SafeSetStat(Chevalier95.base_stats, strings.S.multiplier_damage, -0.1f);
            AssetManager.traits.add(Chevalier95);

            ActorTrait Chevalier96 = CreateTrait("Chevalier96", "trait/Chevalier96", "Chevalier");
            Chevalier96.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier96.base_stats, strings.S.multiplier_lifespan, -0.15f);
            SafeSetStat(Chevalier96.base_stats, strings.S.multiplier_health, -0.15f);
            SafeSetStat(Chevalier96.base_stats, strings.S.multiplier_damage, -0.15f);
            AssetManager.traits.add(Chevalier96);

            ActorTrait Chevalier97 = CreateTrait("Chevalier97", "trait/Chevalier97", "Chevalier");
            Chevalier97.rarity = Rarity.R2_Epic;
            SafeSetStat(Chevalier97.base_stats, strings.S.multiplier_lifespan, -0.2f);
            SafeSetStat(Chevalier97.base_stats, strings.S.multiplier_health, -0.2f);
            SafeSetStat(Chevalier97.base_stats, strings.S.multiplier_damage, -0.2f);
            AssetManager.traits.add(Chevalier97);

            ActorTrait Chevalier98 = CreateTrait("Chevalier98", "trait/Chevalier98", "Chevalier");
            Chevalier98.rarity = Rarity.R3_Legendary;
            SafeSetStat(Chevalier98.base_stats, strings.S.multiplier_lifespan, -0.25f);
            SafeSetStat(Chevalier98.base_stats, strings.S.multiplier_health, -0.25f);
            SafeSetStat(Chevalier98.base_stats, strings.S.multiplier_damage, -0.25f);
            AssetManager.traits.add(Chevalier98);

            ActorTrait Chevalier99 = CreateTrait("Chevalier99", "trait/Chevalier99", "Chevalier");
            Chevalier99.rarity = Rarity.R3_Legendary;
            SafeSetStat(Chevalier99.base_stats, strings.S.multiplier_lifespan, -0.3f);
            SafeSetStat(Chevalier99.base_stats, strings.S.multiplier_health, -0.3f);
            SafeSetStat(Chevalier99.base_stats, strings.S.multiplier_damage, -0.3f);
            AssetManager.traits.add(Chevalier99);

            ActorTrait LegacyTechnique1 = CreateTrait("LegacyTechnique1", "trait/LegacyTechnique1", "LegacyTechnique");
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.damage, 500f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.health, 500f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.speed, 30f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.armor, 15f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.stamina, 80f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.attack_speed, 80f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique1.base_stats, strings.S.multiplier_damage, 0.1f);
            LegacyTechnique1.rate_inherit = 20;
            AssetManager.traits.add(LegacyTechnique1);

            ActorTrait LegacyTechnique2 = CreateTrait("LegacyTechnique2", "trait/LegacyTechnique2", "LegacyTechnique");
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.speed, 80f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.armor, 20f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.damage, 800f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.health, 400f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.stamina, 50f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(LegacyTechnique2.base_stats, strings.S.multiplier_speed, 0.2f);
            LegacyTechnique2.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique2);

            ActorTrait LegacyTechnique3 = CreateTrait("LegacyTechnique3", "trait/LegacyTechnique3", "LegacyTechnique");
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.damage, 200f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.health, 1000f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.speed, 10f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.armor, 80f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.lifespan, 50f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.stamina, 200f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(LegacyTechnique3.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique3.rate_inherit = 20;
            AssetManager.traits.add(LegacyTechnique3);

            ActorTrait LegacyTechnique4 = CreateTrait("LegacyTechnique4", "trait/LegacyTechnique4", "LegacyTechnique");
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.speed, 60f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.armor, 50f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.damage, 400f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.health, 400f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.stamina, 120f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.attack_speed, 10f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(LegacyTechnique4.base_stats, strings.S.multiplier_speed, 0.3f);
            LegacyTechnique4.rate_inherit = 20;
            AssetManager.traits.add(LegacyTechnique4);

            ActorTrait LegacyTechnique5 = CreateTrait("LegacyTechnique5", "trait/LegacyTechnique5", "LegacyTechnique");
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.speed, 40f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.armor, 60f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.health, 200f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.damage, 300f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.lifespan, 300f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.stamina, 30f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(LegacyTechnique5.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique5.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique5);

            ActorTrait LegacyTechnique6 = CreateTrait("LegacyTechnique6", "trait/LegacyTechnique6", "LegacyTechnique");
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.speed, 50f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.armor, 50f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.health, 100f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.damage, 200f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.stamina, 90f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.attack_speed, 70f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(LegacyTechnique6.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique6.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique6);

            ActorTrait LegacyTechnique7 = CreateTrait("LegacyTechnique7", "trait/LegacyTechnique7", "LegacyTechnique");
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.speed, 60f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.armor, 20f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.health, 180f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.damage, 120f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.lifespan, 50f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.stamina, 40f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.attack_speed, 40f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(LegacyTechnique7.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique7.rate_inherit = 20;
            AssetManager.traits.add(LegacyTechnique7);

            ActorTrait LegacyTechnique8 = CreateTrait("LegacyTechnique8", "trait/LegacyTechnique8", "LegacyTechnique");
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.speed, 45f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.armor, 55f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.health, 600f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.damage, 100f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.lifespan, 40f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.stamina, 70f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.attack_speed, 30f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(LegacyTechnique8.base_stats, strings.S.multiplier_speed, 0.2f);
            LegacyTechnique8.rate_inherit = 20;
            AssetManager.traits.add(LegacyTechnique8);

            ActorTrait LegacyTechnique9 = CreateTrait("LegacyTechnique9", "trait/LegacyTechnique9", "LegacyTechnique");
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.speed, 40f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.armor, 60f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.health, 800f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.damage, 240f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.stamina, 90f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.attack_speed, 60f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(LegacyTechnique9.base_stats, strings.S.multiplier_speed, 0.2f);
            LegacyTechnique9.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique9);

            ActorTrait LegacyTechnique10 = CreateTrait("LegacyTechnique10", "trait/LegacyTechnique10", "LegacyTechnique");
            LegacyTechnique10.rarity = Rarity.R2_Epic;
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.speed, 10f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.armor, 10f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.health, 2000f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.damage, 90f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.lifespan, 500f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.stamina, 60f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.attack_speed, 50f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(LegacyTechnique10.base_stats, strings.S.multiplier_speed, 0.3f);
            LegacyTechnique10.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique10);

            ActorTrait LegacyTechnique11 = CreateTrait("LegacyTechnique11", "trait/LegacyTechnique11", "LegacyTechnique");
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.speed, 10f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.armor, -10f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.health, -50f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.damage, 5000f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.lifespan, -10f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.stamina, -30f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.attack_speed, 100f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(LegacyTechnique11.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique11.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique11);

            ActorTrait LegacyTechnique12 = CreateTrait("LegacyTechnique12", "trait/LegacyTechnique12", "LegacyTechnique");
            LegacyTechnique12.rarity = Rarity.R3_Legendary;
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.speed, 40f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.armor, 1000f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.health, 10000f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.damage, 40f); 
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.lifespan, 1000f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.stamina, 1000f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.attack_speed, 20f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.multiplier_health, 0.5f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.multiplier_damage, 0.5f);
            SafeSetStat(LegacyTechnique12.base_stats, strings.S.multiplier_speed, 0.5f);
            LegacyTechnique12.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique12);

            ActorTrait LegacyTechnique13 = CreateTrait("LegacyTechnique13", "trait/LegacyTechnique13", "LegacyTechnique");
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.speed, 80f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.armor, 80f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.health, 800f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.damage, 800f); 
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.lifespan, 80f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.stamina, 80f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.attack_speed, 80f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(LegacyTechnique13.base_stats, strings.S.multiplier_speed, 0.1f);
            LegacyTechnique13.rate_inherit = 10;
            AssetManager.traits.add(LegacyTechnique13);

            ActorTrait LegacyTechnique91 = CreateTrait("LegacyTechnique91", "trait/LegacyTechnique91", "LegacyTechnique");
            LegacyTechnique91.rarity = Rarity.R3_Legendary;
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.speed, 100f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.armor, 100f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.health, 6000f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.damage, 6000f); 
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.lifespan, 100f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.stamina, 80f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.attack_speed, 600f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.multiplier_health, 9.9f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.multiplier_damage, 9.9f);
            SafeSetStat(LegacyTechnique91.base_stats, strings.S.multiplier_speed, 9.9f);
            AssetManager.traits.add(LegacyTechnique91);

            ActorTrait NineLawsofKnighthood1 = CreateTrait("NineLawsofKnighthood1", "trait/NineLawsofKnighthood1", "NineLawsofKnighthood");
            NineLawsofKnighthood1.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood1.base_stats, strings.S.multiplier_health, 3.0f);
            SafeSetStat(NineLawsofKnighthood1.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineLawsofKnighthood1.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineLawsofKnighthood1.base_stats, strings.S.area_of_effect, 4f);
            AssetManager.traits.add(NineLawsofKnighthood1);

            ActorTrait NineLawsofKnighthood2 = CreateTrait("NineLawsofKnighthood2", "trait/NineLawsofKnighthood2", "NineLawsofKnighthood");
            NineLawsofKnighthood2.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.multiplier_damage, 1.8f);
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.multiplier_health, 1.8f);
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.multiplier_speed, 1.8f);
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.intelligence, 100f);
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.area_of_effect, 8f);
            AssetManager.traits.add(NineLawsofKnighthood2);

            ActorTrait NineLawsofKnighthood3 = CreateTrait("NineLawsofKnighthood3", "trait/NineLawsofKnighthood3", "NineLawsofKnighthood");
            NineLawsofKnighthood3.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood3.base_stats, strings.S.multiplier_speed, 3.2f);
            SafeSetStat(NineLawsofKnighthood2.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineLawsofKnighthood3.base_stats, strings.S.intelligence, 50f);
            SafeSetStat(NineLawsofKnighthood3.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineLawsofKnighthood3.base_stats, strings.S.area_of_effect, 6f);
            AssetManager.traits.add(NineLawsofKnighthood3);

            ActorTrait NineLawsofKnighthood4 = CreateTrait("NineLawsofKnighthood4", "trait/NineLawsofKnighthood4", "NineLawsofKnighthood");
            NineLawsofKnighthood4.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.multiplier_health, 1.0f);
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.knockback, 5f); 
            SafeSetStat(NineLawsofKnighthood4.base_stats, strings.S.area_of_effect, 4f);
            AssetManager.traits.add(NineLawsofKnighthood4);

            ActorTrait NineLawsofKnighthood5 = CreateTrait("NineLawsofKnighthood5", "trait/NineLawsofKnighthood5", "NineLawsofKnighthood");
            NineLawsofKnighthood5.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.intelligence, 60f);
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineLawsofKnighthood5.base_stats, strings.S.area_of_effect, 8f);
            AssetManager.traits.add(NineLawsofKnighthood5);

            ActorTrait NineLawsofKnighthood6 = CreateTrait("NineLawsofKnighthood6", "trait/NineLawsofKnighthood6", "NineLawsofKnighthood");
            NineLawsofKnighthood6.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.multiplier_damage, 2.0f);
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineLawsofKnighthood6.base_stats, strings.S.area_of_effect, 10f);
            AssetManager.traits.add(NineLawsofKnighthood6);

            ActorTrait NineLawsofKnighthood7 = CreateTrait("NineLawsofKnighthood7", "trait/NineLawsofKnighthood7", "NineLawsofKnighthood");
            NineLawsofKnighthood7.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.multiplier_damage, 0.8f);
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.multiplier_health, 0.8f);
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.intelligence, 20f);
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.knockback, 20f); 
            SafeSetStat(NineLawsofKnighthood7.base_stats, strings.S.area_of_effect, 6f);
            AssetManager.traits.add(NineLawsofKnighthood7);

            ActorTrait NineLawsofKnighthood8 = CreateTrait("NineLawsofKnighthood8", "trait/NineLawsofKnighthood8", "NineLawsofKnighthood");
            NineLawsofKnighthood8.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.multiplier_speed, 0.9f);
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.multiplier_damage, 0.9f);
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.multiplier_health, 0.9f);
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.intelligence, 1000f);
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.knockback, 100f); 
            SafeSetStat(NineLawsofKnighthood8.base_stats, strings.S.area_of_effect, 100f);
            AssetManager.traits.add(NineLawsofKnighthood8);

            ActorTrait NineLawsofKnighthood9 = CreateTrait("NineLawsofKnighthood9", "trait/NineLawsofKnighthood9", "NineLawsofKnighthood");
            NineLawsofKnighthood9.rarity = Rarity.R3_Legendary;
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.multiplier_speed, 2.0f);
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.multiplier_damage, 1.0f);
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.multiplier_health, 2.0f);
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.knockback, 10f); 
            SafeSetStat(NineLawsofKnighthood9.base_stats, strings.S.area_of_effect, 10f);
            AssetManager.traits.add(NineLawsofKnighthood9);

            ActorTrait LowFightingTechniqueTrait1 = CreateTrait("LowFightingTechniqueTrait1", "trait/LowFightingTechniqueTrait1", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait1.base_stats, strings.S.multiplier_speed, 0.03f);
            SafeSetStat(LowFightingTechniqueTrait1.base_stats, strings.S.multiplier_damage, 0.07f);
            SafeSetStat(LowFightingTechniqueTrait1.base_stats, strings.S.multiplier_health, 0.04f);
            SafeSetStat(LowFightingTechniqueTrait1.base_stats, strings.S.lifespan, 5f);
            AssetManager.traits.add(LowFightingTechniqueTrait1);

            ActorTrait LowFightingTechniqueTrait2 = CreateTrait("LowFightingTechniqueTrait2", "trait/LowFightingTechniqueTrait2", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait2.base_stats, strings.S.multiplier_speed, 0.03f);
            SafeSetStat(LowFightingTechniqueTrait2.base_stats, strings.S.multiplier_damage, 0.07f);
            SafeSetStat(LowFightingTechniqueTrait2.base_stats, strings.S.multiplier_health, 0.04f);
            SafeSetStat(LowFightingTechniqueTrait2.base_stats, strings.S.lifespan, 8f);
            AssetManager.traits.add(LowFightingTechniqueTrait2);

            ActorTrait LowFightingTechniqueTrait3 = CreateTrait("LowFightingTechniqueTrait3", "trait/LowFightingTechniqueTrait3", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait3.base_stats, strings.S.multiplier_speed, 0.04f);
            SafeSetStat(LowFightingTechniqueTrait3.base_stats, strings.S.multiplier_damage, 0.06f);
            SafeSetStat(LowFightingTechniqueTrait3.base_stats, strings.S.multiplier_health, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait3.base_stats, strings.S.lifespan, 9f);
            AssetManager.traits.add(LowFightingTechniqueTrait3);

            ActorTrait LowFightingTechniqueTrait4 = CreateTrait("LowFightingTechniqueTrait4", "trait/LowFightingTechniqueTrait4", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait4.base_stats, strings.S.multiplier_speed, 0.01f);
            SafeSetStat(LowFightingTechniqueTrait4.base_stats, strings.S.multiplier_damage, 0.08f);
            SafeSetStat(LowFightingTechniqueTrait4.base_stats, strings.S.multiplier_health, 0.06f);
            SafeSetStat(LowFightingTechniqueTrait4.base_stats, strings.S.lifespan, 6f);
            AssetManager.traits.add(LowFightingTechniqueTrait4);

            ActorTrait LowFightingTechniqueTrait5 = CreateTrait("LowFightingTechniqueTrait5", "trait/LowFightingTechniqueTrait5", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait5.base_stats, strings.S.multiplier_speed, 0.03f);
            SafeSetStat(LowFightingTechniqueTrait5.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait5.base_stats, strings.S.multiplier_health, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait5.base_stats, strings.S.lifespan, 16f);
            AssetManager.traits.add(LowFightingTechniqueTrait5);

            ActorTrait LowFightingTechniqueTrait6 = CreateTrait("LowFightingTechniqueTrait6", "trait/LowFightingTechniqueTrait6", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait6.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait6.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait6.base_stats, strings.S.multiplier_health, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait6.base_stats, strings.S.lifespan, 10f);
            AssetManager.traits.add(LowFightingTechniqueTrait6);

            ActorTrait LowFightingTechniqueTrait7 = CreateTrait("LowFightingTechniqueTrait7", "trait/LowFightingTechniqueTrait7", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait7.base_stats, strings.S.multiplier_speed, 0.06f);
            SafeSetStat(LowFightingTechniqueTrait7.base_stats, strings.S.multiplier_damage, 0.03f);
            SafeSetStat(LowFightingTechniqueTrait7.base_stats, strings.S.multiplier_health, 0.07f);
            SafeSetStat(LowFightingTechniqueTrait7.base_stats, strings.S.lifespan, 5f);
            AssetManager.traits.add(LowFightingTechniqueTrait7);

            ActorTrait LowFightingTechniqueTrait8 = CreateTrait("LowFightingTechniqueTrait8", "trait/LowFightingTechniqueTrait8", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait8.base_stats, strings.S.multiplier_speed, 0.05f);
            SafeSetStat(LowFightingTechniqueTrait8.base_stats, strings.S.multiplier_damage, 0.05f);
            SafeSetStat(LowFightingTechniqueTrait8.base_stats, strings.S.multiplier_health, 0.05f);
            SafeSetStat(LowFightingTechniqueTrait8.base_stats, strings.S.lifespan, 12f);
            AssetManager.traits.add(LowFightingTechniqueTrait8);

            ActorTrait LowFightingTechniqueTrait9 = CreateTrait("LowFightingTechniqueTrait9", "trait/LowFightingTechniqueTrait9", "LowFightingTechnique");
            SafeSetStat(LowFightingTechniqueTrait9.base_stats, strings.S.multiplier_speed, 0.08f);
            SafeSetStat(LowFightingTechniqueTrait9.base_stats, strings.S.multiplier_damage, 0.07f);
            SafeSetStat(LowFightingTechniqueTrait9.base_stats, strings.S.multiplier_health, 0.09f);
            SafeSetStat(LowFightingTechniqueTrait9.base_stats, strings.S.lifespan, 7f);
            AssetManager.traits.add(LowFightingTechniqueTrait9);

            ActorTrait FightingTechniqueTrait1 = CreateTrait("FightingTechniqueTrait1", "trait/FightingTechniqueTrait1", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.stamina, 15f);
            SafeSetStat(FightingTechniqueTrait1.base_stats, strings.S.area_of_effect, 10f);
            FightingTechniqueTrait1.rate_inherit = 20;
            AssetManager.traits.add(FightingTechniqueTrait1);

            ActorTrait FightingTechniqueTrait12 = CreateTrait("FightingTechniqueTrait12", "trait/FightingTechniqueTrait12", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.lifespan, 12f);
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.stamina, 10f);
            SafeSetStat(FightingTechniqueTrait12.base_stats, strings.S.area_of_effect, 12f);
            FightingTechniqueTrait12.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait12);

            ActorTrait FightingTechniqueTrait2 = CreateTrait("FightingTechniqueTrait2", "trait/FightingTechniqueTrait2", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.multiplier_speed, 0.15f);
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.stamina, 11f);
            SafeSetStat(FightingTechniqueTrait2.base_stats, strings.S.area_of_effect, 10f);
            FightingTechniqueTrait12.rate_inherit = 20;
            AssetManager.traits.add(FightingTechniqueTrait2);

            ActorTrait FightingTechniqueTrait3 = CreateTrait("FightingTechniqueTrait3", "trait/FightingTechniqueTrait3", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.multiplier_speed, 0.11f);
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.lifespan, 11f);
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.stamina, 19f);
            SafeSetStat(FightingTechniqueTrait3.base_stats, strings.S.area_of_effect, 11f);
            FightingTechniqueTrait3.rate_inherit = 22;
            AssetManager.traits.add(FightingTechniqueTrait3);

            ActorTrait FightingTechniqueTrait4 = CreateTrait("FightingTechniqueTrait4", "trait/FightingTechniqueTrait4", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.multiplier_speed, 0.08f);
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.multiplier_health, 0.19f);
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.stamina, 10f);
            SafeSetStat(FightingTechniqueTrait4.base_stats, strings.S.area_of_effect, 10f);
            FightingTechniqueTrait4.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait4);

            ActorTrait FightingTechniqueTrait5 = CreateTrait("FightingTechniqueTrait5", "trait/FightingTechniqueTrait5", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.multiplier_speed, 0.07f);
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.multiplier_damage, 0.18f);
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.lifespan, 18f);
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.stamina, 12f);
            SafeSetStat(FightingTechniqueTrait5.base_stats, strings.S.area_of_effect, 11f);
            FightingTechniqueTrait5.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait5);

            ActorTrait FightingTechniqueTrait6 = CreateTrait("FightingTechniqueTrait6", "trait/FightingTechniqueTrait6", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.multiplier_speed, 0.11f);
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.multiplier_damage, 0.11f);
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.multiplier_health, 0.15f);
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.stamina, 15f);
            SafeSetStat(FightingTechniqueTrait6.base_stats, strings.S.area_of_effect, 15f);
            FightingTechniqueTrait6.rate_inherit = 15;
            AssetManager.traits.add(FightingTechniqueTrait6);

            ActorTrait FightingTechniqueTrait7 = CreateTrait("FightingTechniqueTrait7", "trait/FightingTechniqueTrait7", "FightingTechnique");
            FightingTechniqueTrait7.rarity = Rarity.R3_Legendary;
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.multiplier_speed, 0.19f);
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.multiplier_damage, 0.19f);
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.multiplier_health, 0.19f);
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.lifespan, 19f);
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.stamina, 19f);
            SafeSetStat(FightingTechniqueTrait7.base_stats, strings.S.area_of_effect, 19f);
            FightingTechniqueTrait7.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait7);

            ActorTrait FightingTechniqueTrait8 = CreateTrait("FightingTechniqueTrait8", "trait/FightingTechniqueTrait8", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.multiplier_damage, 0.13f);
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.multiplier_health, 0.17f);
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.stamina, 13f);
            SafeSetStat(FightingTechniqueTrait8.base_stats, strings.S.area_of_effect, 11f);
            FightingTechniqueTrait8.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait8);

            ActorTrait FightingTechniqueTrait9 = CreateTrait("FightingTechniqueTrait9", "trait/FightingTechniqueTrait9", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.multiplier_speed, 0.16f);
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.multiplier_damage, 0.14f);
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.multiplier_health, 0.12f);
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.stamina, 16f);
            SafeSetStat(FightingTechniqueTrait9.base_stats, strings.S.area_of_effect, 12f);
            FightingTechniqueTrait9.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait9);

            ActorTrait FightingTechniqueTrait10 = CreateTrait("FightingTechniqueTrait10", "trait/FightingTechniqueTrait10", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.multiplier_speed, 0.17f);
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.multiplier_damage, 0.13f);
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.multiplier_health, 0.11f);
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.lifespan, 14f);
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.stamina, 12f);
            SafeSetStat(FightingTechniqueTrait10.base_stats, strings.S.area_of_effect, 11f);
            FightingTechniqueTrait10.rate_inherit = 20;
            AssetManager.traits.add(FightingTechniqueTrait10);

            ActorTrait FightingTechniqueTrait11 = CreateTrait("FightingTechniqueTrait11", "trait/FightingTechniqueTrait11", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.lifespan, 24f);
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.stamina, 40f);
            SafeSetStat(FightingTechniqueTrait11.base_stats, strings.S.area_of_effect, 20f);
            FightingTechniqueTrait11.rate_inherit = 20;
            AssetManager.traits.add(FightingTechniqueTrait11);

            ActorTrait FightingTechniqueTrait13 = CreateTrait("FightingTechniqueTrait13", "trait/FightingTechniqueTrait13", "FightingTechnique");
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.stamina, 90f);
            SafeSetStat(FightingTechniqueTrait13.base_stats, strings.S.area_of_effect, 30f);
            FightingTechniqueTrait13.rate_inherit = 10;
            AssetManager.traits.add(FightingTechniqueTrait13);

            ActorTrait DivineSeal = CreateTrait("DivineSeal", "trait/DivineSeal", "ChivalricFoundations");
            AssetManager.traits.add(DivineSeal);

            // 定义五个等级的血脉特质
            ActorTrait KnightlyBloodline1 = CreateTrait("KnightlyBloodline1", "trait/KnightlyBloodline1", "KnightlyBloodline");
            KnightlyBloodline1.rate_inherit = 15;
            SafeSetStat(KnightlyBloodline1.base_stats, strings.S.multiplier_health, 0.01f);
            SafeSetStat(KnightlyBloodline1.base_stats, strings.S.multiplier_damage, 0.01f);
            SafeSetStat(KnightlyBloodline1.base_stats, strings.S.lifespan, 5f);
            AssetManager.traits.add(KnightlyBloodline1);

            ActorTrait KnightlyBloodline2 = CreateTrait("KnightlyBloodline2", "trait/KnightlyBloodline2", "KnightlyBloodline");
            KnightlyBloodline2.rate_inherit = 14;
            SafeSetStat(KnightlyBloodline2.base_stats, strings.S.multiplier_health, 0.05f);
            SafeSetStat(KnightlyBloodline2.base_stats, strings.S.multiplier_damage, 0.05f);
            SafeSetStat(KnightlyBloodline2.base_stats, strings.S.lifespan, 10f);
            AssetManager.traits.add(KnightlyBloodline2);

            ActorTrait KnightlyBloodline3 = CreateTrait("KnightlyBloodline3", "trait/KnightlyBloodline3", "KnightlyBloodline");
            KnightlyBloodline3.rate_inherit = 13; 
            SafeSetStat(KnightlyBloodline3.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(KnightlyBloodline3.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(KnightlyBloodline3.base_stats, strings.S.lifespan, 15f);
            AssetManager.traits.add(KnightlyBloodline3);

            ActorTrait KnightlyBloodline4 = CreateTrait("KnightlyBloodline4", "trait/KnightlyBloodline4", "KnightlyBloodline");
            KnightlyBloodline4.rarity = Rarity.R2_Epic;
            KnightlyBloodline4.rate_inherit = 12;
            SafeSetStat(KnightlyBloodline4.base_stats, strings.S.multiplier_health, 0.15f);
            SafeSetStat(KnightlyBloodline4.base_stats, strings.S.multiplier_damage, 0.15f);
            SafeSetStat(KnightlyBloodline4.base_stats, strings.S.lifespan, 20f);
            AssetManager.traits.add(KnightlyBloodline4);

            ActorTrait KnightlyBloodline5 = CreateTrait("KnightlyBloodline5", "trait/KnightlyBloodline5", "KnightlyBloodline");
            KnightlyBloodline5.rarity = Rarity.R2_Epic;
            KnightlyBloodline5.rate_inherit = 11; 
            SafeSetStat(KnightlyBloodline5.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(KnightlyBloodline5.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(KnightlyBloodline5.base_stats, strings.S.lifespan, 40f);
            AssetManager.traits.add(KnightlyBloodline5);

            ActorTrait KnightlyBloodline6 = CreateTrait("KnightlyBloodline6", "trait/KnightlyBloodline6", "KnightlyBloodline");
            KnightlyBloodline6.rarity = Rarity.R3_Legendary;
            KnightlyBloodline6.rate_inherit = 10; 
            SafeSetStat(KnightlyBloodline6.base_stats, strings.S.multiplier_health, 0.25f);
            SafeSetStat(KnightlyBloodline6.base_stats, strings.S.multiplier_damage, 0.25f);
            SafeSetStat(KnightlyBloodline6.base_stats, strings.S.lifespan, 80f);
            AssetManager.traits.add(KnightlyBloodline6);

            ActorTrait KnightlyBloodline7 = CreateTrait("KnightlyBloodline7", "trait/KnightlyBloodline7", "KnightlyBloodline");
            KnightlyBloodline7.rarity = Rarity.R3_Legendary;
            KnightlyBloodline7.rate_inherit = 10; 
            SafeSetStat(KnightlyBloodline7.base_stats, strings.S.multiplier_health, 0.3f);
            SafeSetStat(KnightlyBloodline7.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(KnightlyBloodline7.base_stats, strings.S.lifespan, 160f);
            AssetManager.traits.add(KnightlyBloodline7);

            ActorTrait midFightingTechniqueTrait1 = CreateTrait("MidFightingTechniqueTrait1", "trait/MidFightingTechniqueTrait1", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.multiplier_speed, 0.04f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.multiplier_damage, 0.05f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.multiplier_health, 0.06f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.lifespan, 8f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.stamina, 10f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.area_of_effect, 10f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.skill_combat, 1f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.warfare, 6f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.stewardship, 4f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.opinion, 4f);
            SafeSetStat(midFightingTechniqueTrait1.base_stats, strings.S.cities, 5f);
            midFightingTechniqueTrait1.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait1);

            ActorTrait midFightingTechniqueTrait12 = CreateTrait("MidFightingTechniqueTrait12", "trait/MidFightingTechniqueTrait12", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.multiplier_speed, 0.01f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.multiplier_health, 0.04f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.lifespan, 5f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.stamina, 12f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.area_of_effect, 12f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.warfare, 9f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.stewardship, 8f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.opinion, 7f);
            SafeSetStat(midFightingTechniqueTrait12.base_stats, strings.S.cities, 8f);
            midFightingTechniqueTrait12.rate_inherit = 8;
            AssetManager.traits.add(midFightingTechniqueTrait12);

            ActorTrait midFightingTechniqueTrait13 = CreateTrait("MidFightingTechniqueTrait13", "trait/MidFightingTechniqueTrait13", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.multiplier_speed, 0.06f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.multiplier_damage, 0.06f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.multiplier_health, 0.06f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.lifespan, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.stamina, 60f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.area_of_effect, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.warfare, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.diplomacy, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.stewardship, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.opinion, 6f);
            SafeSetStat(midFightingTechniqueTrait13.base_stats, strings.S.cities, 6f);
            midFightingTechniqueTrait13.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait13);

            ActorTrait midFightingTechniqueTrait2 = CreateTrait("MidFightingTechniqueTrait2", "trait/MidFightingTechniqueTrait2", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.multiplier_speed, 0.08f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.lifespan, 15f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.stamina, 20f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.skill_combat, 0.4f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.warfare, 8f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.stewardship, 2f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.opinion, 4f);
            SafeSetStat(midFightingTechniqueTrait2.base_stats, strings.S.cities, 2f);
            midFightingTechniqueTrait2.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait2);

            ActorTrait midFightingTechniqueTrait3 = CreateTrait("MidFightingTechniqueTrait3", "trait/MidFightingTechniqueTrait3", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.multiplier_speed, 0.08f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.multiplier_damage, 0.05f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.lifespan, 16f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.stamina, 12f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.area_of_effect, 18f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.skill_combat, 1f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.warfare, 10f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.stewardship, 2f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.opinion, 8f);
            SafeSetStat(midFightingTechniqueTrait3.base_stats, strings.S.cities, 2f);
            midFightingTechniqueTrait3.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait3);

            ActorTrait midFightingTechniqueTrait4 = CreateTrait("MidFightingTechniqueTrait4", "trait/MidFightingTechniqueTrait4", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.multiplier_speed, 0.3f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.multiplier_damage, 0.04f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.multiplier_health, 0.08f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.lifespan, 6f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.stamina, 10f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.area_of_effect, 16f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.skill_combat, 0.8f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.warfare, 2f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.diplomacy, 8f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.stewardship, 4f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.opinion, 8f);
            SafeSetStat(midFightingTechniqueTrait4.base_stats, strings.S.cities, 2f);
            midFightingTechniqueTrait4.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait4);

            ActorTrait midFightingTechniqueTrait5 = CreateTrait("MidFightingTechniqueTrait5", "trait/MidFightingTechniqueTrait5", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.multiplier_speed, 0.03f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.multiplier_damage, 0.3f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.multiplier_health, 0.04f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.stamina, 50f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.skill_combat, 1f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.warfare, 10f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.diplomacy, 10f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.stewardship, 2f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.opinion, 2f);
            SafeSetStat(midFightingTechniqueTrait5.base_stats, strings.S.cities, 2f);
            midFightingTechniqueTrait5.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait5);

            ActorTrait midFightingTechniqueTrait6 = CreateTrait("MidFightingTechniqueTrait6", "trait/MidFightingTechniqueTrait6", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.multiplier_damage, 0.06f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.multiplier_health, 0.04f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.stamina, 110f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.area_of_effect, 20f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.skill_combat, 1f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.warfare, 6f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.diplomacy, 8f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.stewardship, 2f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.opinion, 8f);
            SafeSetStat(midFightingTechniqueTrait6.base_stats, strings.S.cities, 2f);
            midFightingTechniqueTrait6.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait6);

            ActorTrait midFightingTechniqueTrait7 = CreateTrait("MidFightingTechniqueTrait7", "trait/MidFightingTechniqueTrait7", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.multiplier_speed, 0.09f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.multiplier_damage, 0.09f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.multiplier_health, 0.09f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.lifespan, 4f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.stamina, 60f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.area_of_effect, 18f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.skill_combat, 0.4f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.warfare, 2f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.stewardship, 4f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.opinion, 8f);
            SafeSetStat(midFightingTechniqueTrait7.base_stats, strings.S.cities, 10f);
            midFightingTechniqueTrait7.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait7);

            ActorTrait midFightingTechniqueTrait8 = CreateTrait("MidFightingTechniqueTrait8", "trait/MidFightingTechniqueTrait8", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.multiplier_health, 0.06f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.stamina, 40f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.area_of_effect, 40f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.skill_combat, 2f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.warfare, 10f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.diplomacy, 2f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.stewardship, 6f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.opinion, 8f);
            SafeSetStat(midFightingTechniqueTrait8.base_stats, strings.S.cities, 6f);
            midFightingTechniqueTrait8.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait8);

            ActorTrait midFightingTechniqueTrait9 = CreateTrait("MidFightingTechniqueTrait9", "trait/MidFightingTechniqueTrait9", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.multiplier_speed, 0.01f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.multiplier_damage, 0.25f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.multiplier_health, 0.01f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.lifespan, -10f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.stamina, 10f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.area_of_effect, 1f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.warfare, 12f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.diplomacy, -1f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.stewardship, -1f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.opinion, -1f);
            SafeSetStat(midFightingTechniqueTrait9.base_stats, strings.S.cities, -1f);
            midFightingTechniqueTrait9.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait9);

            ActorTrait midFightingTechniqueTrait10 = CreateTrait("MidFightingTechniqueTrait10", "trait/MidFightingTechniqueTrait10", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.multiplier_speed, 0.01f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.multiplier_damage, 0.01f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.lifespan, 80f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.stamina, 20f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.area_of_effect, 11f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.warfare, 2f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.diplomacy, 4f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.stewardship, 2f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.opinion, -2f);
            SafeSetStat(midFightingTechniqueTrait10.base_stats, strings.S.cities, -2f);
            midFightingTechniqueTrait10.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait10);

            ActorTrait midFightingTechniqueTrait11 = CreateTrait("MidFightingTechniqueTrait11", "trait/MidFightingTechniqueTrait11", "MidFightingTechnique");
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.multiplier_damage, 0.1f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.multiplier_health, 0.1f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.lifespan, 8f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.stamina, 30f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.area_of_effect, 40f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.skill_combat, 1f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.warfare, 4f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.diplomacy, 6f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.stewardship, 8f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.opinion, 2f);
            SafeSetStat(midFightingTechniqueTrait11.base_stats, strings.S.cities, 5f);
            midFightingTechniqueTrait11.rate_inherit = 10;
            AssetManager.traits.add(midFightingTechniqueTrait11);
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}