﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace PeerlessOverpoweringWarrior.code
{
    internal class traitAction
    {
        public static bool IsWarrior1To12(Actor a)
        {
            for (int i = 1; i <= 12; i++)
            {
                if (a.hasTrait($"Warrior{i}") || a.hasTrait($"Warrior{i}+"))
                {
                    return true;
                }
            }
            return false;
        }
        private static readonly Dictionary<string, string> _warriorSuffixMap = new Dictionary<string, string>
{
    {"Warrior1", "骑士侍从"},
    {"Warrior2", "准骑士"},
    {"Warrior3", "正式骑士"},
    {"Warrior4", "守护骑士"},
    {"Warrior5", "方旗骑士"},
    {"Warrior6", "大骑士"},
    {"Warrior7", "称号大骑士"},
    {"Warrior8", "传奇大骑士"},
    {"Warrior9", "神话大骑士"},
    {"Warrior91", "烈日骑士"},
    {"Warrior92", "永耀骑士"},
    {"Warrior93", "不朽骑士"}
};
// 尊号字典（洞虚境、合道境、武极境）
private static readonly Dictionary<string, string[]> _warriorTitlesMap = new Dictionary<string, string[]>
{
    // 洞虚境尊号
    {"Warrior7", new string[] {
        "晨光裁决者", "十字守望者", "风暴撕裂者", "永冻誓约者", "焚城领主","冥河引渡者", "蒸汽齿轮骑", "百战老兵骑", "千军破阵将", "七罪仲裁骑",
        "夜枭刺客", "绿藤裁决者", "潮汐统御者", "岩脉守护者", "天枢骑士","绝境求生骑", "战争机甲士", "永夜独行骑", "天平执法将", "末日守卫骑",
        "亡魂收割者", "暮光侯爵", "纯白守护者", "黄金统帅", "多面猎杀者","丛林猎杀骑", "深海利维坦", "熔岩狂战士", "星界漫游骑", "梦境守护将",
        "堕魔骑士", "怜悯使徒", "齿轮主宰", "维度游侠", "腐坏使者","不死鸟战骑", "石化凝视者", "狮鹫翼骑士", "沙暴烈日骑", "冰原守望将",
        "空域霸主", "雷霆万钧者", "星辰咏叹者", "极寒破坏者", "终焉审判者","神恩使徒骑", "律法骑士长", "秘仪学者骑", "骨镰亡灵使", "黑魔法骑士",
        "黑刃伯爵", "厄运骑士", "重生战魂", "石化裁决者", "苍穹游侠","齿轮机械骑", "虚空漫步者", "疫病净化骑", "龙枪骑士长", "雷锤破阵者",
        "绿洲征服者", "永夜", "野性复仇者", "深渊骑士", "地火君主","秘银剑卫骑", "霜斧破冰将", "光明审判骑", "暗影契约者", "诅咒甲胄骑",
        "宇宙漫游者", "自然祭司", "亡魂引导者", "齿轮战神", "不朽勇者","纯白誓约骑", "狮心冲锋将", "蛇刃猎杀者", "堕魔黑甲骑", "圣手疗愈骑",
        "龙脊枪骑士", "雷霆战锤手", "秘银剑卫", "霜斧破冰者", "光明审判者", "暗影契约者", "诅咒甲胄士", "不死鸟战士", "石化凝视者", "狮鹫骑手",
        "寒星追猎者", "暗影壁垒者", "烈日裁决者", "雷霆践踏者", "极寒冰狩者",
        "救赎使者", "堕魔束缚者", "维度窥视者", "不屈守卫者", "疫病统帅者",
        "天穹射手", "地火锻造者", "自然唤灵者", "暗影收割者", "齿轮战神",
        "风暴切割者", "永冻屠戮者", "秩序维护者", "血月伯爵", "生命守卫者",
        "铁甲元帅", "闪电骑手", "破冰先锋", "焚城守卫", "潮汐掌控者",
        "野性猎手", "星辰使者", "亡骸统帅", "厄运携带者", "腐坏传播者",
        "天空游侠", "烈日行者", "永冻之王", "暗夜刺客", "神恩祭司",
        "维度撕裂者", "齿轮将军", "无畏老兵", "铁血统帅", "灵魂仲裁者",
        "终焉守卫", "律法执行者", "生命祭司", "知识贤者", "契约守护者",
        "风暴骑手", "破浪统帅", "星盾卫队长", "亡骸收割者", "冥河引渡者", "蒸汽齿轮骑", "百战老兵骑", "千军破阵将", "七罪仲裁骑",
        "破晓圣剑", "雷霆战戟", "霜寒刃主", "炽焰龙爵", "暗影契约",
        "圣光铁誓", "血月幽影", "独角兽誓", "狮心战吼", "九头蛇刃",   
        "月影潜锋", "自然之怒", "海洋咆哮", "大地壁垒", "星辉圣盾",
        "深渊凝视", "圣疗之手", "机械之心", "虚空行者", "疫病图腾",
        "破晓圣剑", "圣光铁誓", "雷霆战", "霜寒刃主", "炽焰龙爵","冥河引渡者", "蒸汽齿轮骑", "百战老兵骑", "千军破阵将", "七罪仲裁骑",
        "月影潜锋", "自然之怒", "海洋咆哮", "大地壁垒", "星辉圣盾","绝境求生骑", "战争机甲士", "永夜独行骑", "天平执法将", "末日守卫骑",
        "炼狱魔镰", "血月幽影", "独角兽誓", "狮心战吼", "九头蛇刃","丛林猎杀骑", "深海利维坦", "熔岩狂战士", "星界漫游骑", "梦境守护将",
        "深渊凝视", "圣疗之手", "机械之心", "虚空行者", "疫病图腾","不死鸟战骑", "石化凝视者", "狮鹫翼骑士", "沙暴烈日骑", "冰原守望将",
        "龙脊长枪", "雷神之锤", "秘银圣剑", "霜牙巨斧", "光明天启","神恩使徒骑", "律法骑士长", "秘仪学者骑", "骨镰亡灵使", "黑魔法骑士",
        "暗影契约", "诅咒铠甲", "不死鸟焰", "美杜莎瞳", "格里芬驭","齿轮机械骑", "虚空漫步者", "疫病净化骑", "龙枪骑士长", "雷锤破阵者",
        "沙漠炙阳", "极北冰冠", "丛林巨刃", "深海利维坦", "熔岩之心","秘银剑卫骑", "霜斧破冰将", "光明审判骑", "暗影契约者", "诅咒甲胄骑",
        "星空裂隙", "翡翠梦境", "冥河渡舟", "蒸汽狂徒", "百战血纹","纯白誓约骑", "狮心冲锋将", "蛇刃猎杀者", "堕魔黑甲骑", "圣手疗愈骑",
        "龙脊枪骑士", "雷霆战锤手", "秘银剑卫", "霜斧破冰者", "光明审判者", "暗影契约者", "诅咒甲胄士", "不死鸟战士", "石化凝视者", "狮鹫骑手",
        "极光银枪", "永夜巨盾", "焚天剑刃", "风暴战靴", "霜狼獠牙",
        "圣焰辉光", "深渊锁链", "虚空之眼", "钢铁意志", "毒雾战旗",
        "星坠长弓", "熔岩战锤", "翡翠号角", "暗影收割者", "齿轮战神",
        "风暴切割者", "冰霜之牙", "秩序维护者", "黑暗契约", "神圣庇护",
        "钢铁洪流", "雷鸣战蹄", "寒霜巨刃", "火焰荆棘", "深海巨锚",
        "丛林利爪", "秘银战链", "骨龙驭者", "诅咒战刃", "腐坏传播者",
        "狮鹫之翼", "沙漠狂沙", "冰雪堡垒", "暗影斗篷", "光明权杖",
        "虚空战刃", "蒸汽巨炮", "百战勋章", "千军破阵", "七罪审判",
        "末日战歌", "天平圣印", "圣疗之手", "智慧法典", "守序圣印",
        "风语者", "海怒战戟", "星盾卫队长", "亡骸收割者", "冥河引渡者", "蒸汽齿轮骑", "百战老兵骑", "千军破阵将", "七罪仲裁骑",
        "破晓圣剑", "雷霆战戟", "霜寒刃主", "炽焰龙爵", "黑刃伯爵",
        "不死鸟战骑", "石化凝视者", "狮鹫翼骑士", "沙暴烈日骑", "冰原守望将","七罪审判者", "绝境求生者", "永夜独行侠", "天平执法者", "末日审判者",
        "龙脊长枪・空域霸主", "雷神之锤・雷霆万钧者", "秘银圣剑・星辰咏叹者", "霜牙巨斧・极寒破坏者", "光明天启・终焉审判者",
        "绝境求生骑", "战争机甲士", "永夜独行骑", "天平执法将", "末日守卫骑","神恩使徒骑", "律法骑士长", "秘仪学者骑", "骨镰亡灵使", "黑魔法骑士",
        "丛林猎杀骑", "深海利维坦", "熔岩狂战士", "星界漫游骑", "梦境守护将","星陨之怒", "寒霜战戟", "烈焰焚城者", "风暴践踏者", "深渊屠戮者",    
        "永夜守望者", "光明裁决者", "机械战神", "自然守护者", "疫病净化者","堕魔黑甲", "神恩使者", "律法执行者", "机械统帅", "星界漫游者",
        "虚空漫步者", "雷霆审判者", "冰霜巨刃", "钢铁壁垒", "暗影刺客","风语者", "海怒统帅", "星盾卫士", "亡骸收割者", "血月伯爵",
        "圣疗医师", "血月游侠", "独角兽圣骑士", "狮心元帅", "九头蛇猎手","梦境编织者", "冥河摆渡人", "蒸汽朋克", "百战英雄", "千军破阵",
        "熔岩锻造者", "深海霸主", "丛林追猎者", "沙漠风暴", "冰原守护者","龙血战士", "雷神之锤", "秘银守护者", "霜狼骑士", "末日守卫",
        "千军破阵・无双剑豪", "七罪审判・原罪仲裁者", "九死誓约・绝境守护者", "万夫莫敌・战争化身", "永夜孤影・暗月游侠","沙漠烈日骑士", "冰原守望者", "丛林猎手", "深海利维坦", "熔岩狂战士",
        "天平圣裁・律法骑士", "末日号角・终焉守卫者", "圣言咏叹・神恩使者", "守序圣印・契约维系者", "智慧法典・秘仪骑士","风刃游侠长", "海怒破浪骑", "星盾卫队长", "亡骸收割者", "血月刃骑士",
        "铁刃破甲骑士", "苍狼冲锋者", "风暴长戟手", "霜牙重铠卫", "炽焰斩棘骑士", "堕魔黑骑士", "圣手疗愈者", "齿轮机械师", "虚空漫步者", "疫病净化者",
        "夜影潜行者", "绿林游侠长", "怒海破浪者", "岩岭守护者", "星辉盾卫", "亡骸收割者", "血月游侠", "纯白誓约者", "黄金狮心将", "多头蛇刃使",
        "星界漫游者", "梦境守护者", "冥河引渡者", "蒸汽齿轮骑士", "百战老兵","千军破阵者", "七罪仲裁者", "绝境求生骑士", "战争", "永夜独行侠",
        "天平执法者", "末日守卫", "神恩使徒", "律法骑士", "秘仪学者","赤焰斩骑士", "霜甲重骑将", "雷矛突击者", "影刃潜行者", "岩盾守护者",
        "骨镰亡灵使", "黑魔法士", "血祭契约者", "厄运铠甲骑士", "腐坏净化者","裂空枪骑士", "弑神剑士", "星穹弓手", "齿轮操控者", "生命树守卫"
    }},
  
    // 武域境尊号
    {"Warrior9", new string[] {
        "圣焰裁决大骑士", "神恩庇护大骑士", "福音传播大骑士", "圣骸守护大骑士", "赎罪之剑大骑士", "辉耀晨星大骑士", "银月誓约大骑士", "永昼炽阳大骑士", "星穹引路大骑士", "破晓先驱大骑士", 
        "龙心熔铸大骑士", "狮鹫征服大骑士", "独角圣洁大骑士", "巨狼灾厄大骑士", "凤凰涅槃大骑士", "铁幕壁垒大骑士", "钢锋裂云大骑士", "秘银圣纹大骑士", "精金不破大骑士", "陨星重铸大骑士",
        "禁咒破除大骑士", "邪秽净涤大骑士", "深渊凝视大骑士", "亡灵镇魂大骑士", "混沌裁定大骑士", "誓约胜利大骑士", "断钢裁决大骑士", "湖光守护大骑士", "石中剑主大骑士", "王权天授大骑士",
        "凛冬守望大骑士", "怒涛驾驭大骑士", "裂谷征服大骑士", "绝壁巡疆大骑士", "荒原开拓大骑士", "十诫守序大骑士", "七美德化身大骑士", "三圣颂歌大骑士", "五芒镇封大骑士", "十字指引大骑士",
        "蔷薇铁卫大骑士", "荆棘冠冕大骑士", "橡木图腾大骑士", "紫晶权杖大骑士", "金雀花冠大骑士", "龙眠守望大骑士", "巨人屠戮大骑士", "歌者大骑士", "挚友大骑士", "灾厄大骑士",
        "不灭旌旗大骑士", "万军统御大骑士", "百战归一大骑士", "千堡守护大骑士", "孤城死志大骑士", "圣徒遗志大骑士", "先知之眼大骑士", "神选冠军大骑士", "使徒代行大骑士", "神血继承大骑士",
        "铁骑洪流大骑士", "长枪裂阵大骑士", "重剑开山大骑士", "坚盾永固大骑士", "号角唤醒大骑士", "龙焰抗御大骑士", "巨力摧城大骑士", "魔能反制大骑士", "幻象识破大骑士", "咒法湮灭大骑士",
        "诗篇传颂大骑士", "史诗铭刻大骑士", "丰碑永存大骑士", "赞歌不息大骑士", "传奇具名大骑士", "圣骸重铸大骑士", "神火焚罪大骑士", "福音宣谕大骑士", "圣棺守护大骑士", "天启录主大骑士",
        "千军辟易大骑士", "万刃归宗大骑士", "铁血洪流大骑士", "烽燧永燃大骑士", "战歌不息大骑士", "熔岩之心大骑士", "霜星坠世大骑士", "飓风之眼大骑士", "地核震颤大骑士", "雷暴主宰大骑士",
        "血契烙印大骑士", "古神低语大骑士", "永劫回响大骑士", "冥河引渡大骑士", "深渊凝视大骑士", "龙脊征服大骑士", "狮鹫灾星大骑士", "比蒙撕裂大骑士", "海妖镇魂大骑士", "精灵挽歌大骑士",
        "秘银破法大骑士", "精金不灭大骑士", "星铁熔铸大骑士", "咒刃噬魂大骑士", "圣盾永固大骑士", "时砂溯流大骑士", "空界穿行大骑士", "永夜巡疆大骑士", "晨曦先驱大骑士", "星轨绘师大骑士",
        "誓约永驻大骑士", "荣光不朽大骑士", "铁律法典大骑士", "心火不熄大骑士", "魂印传承大骑士", "赤焰灾变大骑士", "玄冰寂灭大骑士", "裂风之牙大骑士", "震地之锚大骑士", "雷殛天罚大骑士",
        "双生魂寄大骑士", "镜影操纵大骑士", "虚化具现大骑士", "梦魇编织大骑士", "混沌具名大骑士", "洛林铁卫大骑士", "勃艮第坚盾大骑士", "断剑者大骑士", "圣墓守誓大骑士", "金马刺大骑士",
        "重锤碎甲大骑士", "铁蹄踏城大骑士", "苦路巡护大骑士", "狮心再临大骑士", "王旗护卫大骑士", "塔盾壁垒大骑士", "血沙征服大骑士", "圣血持杯大骑士", "黑风大骑士", "城门摧破大骑士"
    }},

    // 合道境尊号
    {"Warrior91", new string[] {
        "焚天业火·炎狱审判者", "寒霜囚笼·永寂裁决者", "雷霆万钧·九霄雷神使", "狂澜怒涛·深海潮汐主", "地脉震颤·裂岩巨擘","原初熵能・混沌裂隙支配者", "亘古冰魄・永劫极寒仲裁者", "星辉源质・银河星轨编织者", "炼狱硫磺・阿格隆炎狱君主", "深渊蠕行・克苏鲁眷族骑士","狼魂咆哮・芬里尔灾厄预兆者", "独角兽泪・卡俄斯纯洁具现体", "凤凰灰烬・不死鸟涅槃重构者", "奇美拉骸・基因畸变统合者", "蝎尾狮毒・沙漠诅咒散播者",
        "暴风漩涡·空域领主", "暗影帷幕·幽夜刺客长", "光明圣焰·晨曦净化者", "混沌熵能·无序操控者", "生命脉动·自然守护者","幽蓝圣骸・骸骨星界漫游者", "翡翠龙髓・世界树根系统御者", "黑曜魔晶・虚空裂隙守望者", "血月棱镜・莉莉丝契约骑士", "雷霆古符・宙斯神谕执行者","颅骨星图・卡俄斯混沌具现体", "神骸巨锚・虚数空间固定者", "血源古咒・该隐血脉复仇者", "星轨断章・罗慕路斯命运切割者", "神谕残页・梵天智慧具现者",
        "三头地狱犬·炼狱守卫", "毒雾缠绕者", "狮鹫领主·天空霸主", "奇美拉之怒·畸变征服者", "凤凰涅槃·重生之焰","暗焰幽纹・萨麦尔焚魂使者", "霜银龙脊・尼德霍格啃世者", "鎏金圣裁・天使长米迦勒之刃", "赤铜血祭・美索不达米亚血裔", "秘银星图・托勒密天球主宰","陨星晶骸・超新星残骸聚合体", "血珊瑚戟・亚特兰蒂斯遗民", "熵化齿轮・机械降神使徒", "幽影织网・阿赖耶识编织者", "光暗熵变・阴阳太极仲裁者",
        "巨龙血脉·鳞甲暴君", "独角兽辉·纯洁化身", "蛇发女妖·石化凝视者", "人马射手·荒野游侠", "石像鬼之翼·暗夜猎手","救赎之剑·赦罪者", "惩戒战锤·异端裁判官", "守护圣盾·壁垒统帅", "希望之弓·黎明守望者", "真理法典·圣言仲裁者","绯红神纹・克苏鲁星象祭司", "墨金符文・北欧古咒缚法者", "青金石誓・埃及九柱神之誓", "琥珀魔典・所罗门七十二柱支配者", "玄铁神谕・德尔斐预言骑士",
        "秩序纹章·律法执行者", "荣耀圣印·誓约守护者", "勇气战旗·冲锋指挥官", "智慧圣杖·秘仪导师", "慈悲圣杯·怜悯使者","百战无伤·不朽战神", "千军辟易·无双勇者", "血债血偿·复仇之矛", "一诺千金·誓约守护者", "七罪审判·原罪仲裁者","格里芬翼・天空法则制定者", "斯芬克斯谜・混沌逻辑破译者", "弥诺陶角・迷宫法则践踏者", "九头蛇鳞・不朽再生实验体", "刻耳柏洛斯链・冥河秩序维持者",
        "亡灵操控·骨镰收割者", "黑魔法阵·暗影召唤师", "血腥契约·血祭执行者", "诅咒铠甲·厄运散播者", "疫病图腾·腐坏传播者","生命树之枝·复苏者", "末日号角·终焉传令官", "审判天平·罪孽衡量者", "时光沙漏·时序守护者", "世界之盾·维度壁垒","贝希摩斯躯・大地原力骑士", "利维坦鳞・海洋熵能骑士", "巴哈姆特爪・多元宇宙仲裁者", "提亚马特鳞・创世原初破坏者", "奥西里斯棺・亡灵秩序统御者",
        "虚空裂隙·维度撕裂者", "机械魔偶·齿轮暴君", "血晶虹吸·生命掠夺者", "梦魇熔炉·恐惧铸造者", "魂器炼造·灵魂囚禁者","永恒之枪·天空撕裂者", "弑神巨刃·神明终结者", "星穹之弓·宇宙射手", "命运齿轮·因果操控者", "虚空法典·混沌主宰","阿努比斯镰・灵魂称量执行官", "荷鲁斯之眼・宇宙真相观测者", "赛特之爪・混沌力量具现者", "伊西斯之泪・生命法则重构者", "拉之翼・太阳熵能支配者",
        "极地冰冠·永夜守望者", "沙漠烈日·黄沙征服者", "丛林毒雾·野性复仇者", "深海幽渊·克苏鲁祭司", "火山熔心·地火暴君","星空漫游·宇宙骑士", "暗影迷宫·迷域探索者", "翡翠梦境·自然守卫者", "蒸汽朋克·齿轮统帅", "亡灵国度·冥府执法官","晨曦半神・赫利俄斯之裔", "雷霆使者・宙斯残魄", "海洋守望・波塞冬血裔", "大地母巢・盖亚分蘖体", "暗夜幽影・厄瑞玻斯碎片","烬光半神・残焰使者", "裂空半神・断界行者", "熵潮半神・碎流守望", "幽影半神・黯翳眷族", "霜烬半神・寒焰祭司",
        "火焰祭司・赫菲斯托斯火种", "狩猎之誓・阿尔忒弥斯箭徒", "智慧之冠・雅典娜残识", "丰收之镰・德墨忒尔眷族", "酒神狂信・狄俄尼索斯回响","战争狂怒・阿瑞斯凶兆", "冥河引路人・赫卡忒仆从", "锻造之魂・伏尔甘碎片", "月亮潮汐・塞勒涅投影", "风语先知・埃俄罗斯气息","战争狂怒・阿瑞斯凶兆", "冥河引路人・赫卡忒仆从", "锻造之魂・伏尔甘碎片", "月亮潮汐・塞勒涅投影", "风语先知・埃俄罗斯气息",
        "瘟疫假面・阿波罗灾厄", "治愈圣手・阿斯克勒庇俄斯微光", "爱欲之链・阿佛洛狄忒涟漪", "睡眠纺锤・修普诺斯残梦", "命运织网・摩伊拉丝线","火焰巨像・伊格尼斯化身", "寒冰女祭司・科瑞俄斯遗脉", "雷霆战隼・珀鲁克斯残影", "海洋巨蛇・刻托鳞裔", "大地守护者・安泰俄斯之躯","暗影刺客・诺克斯刃徒", "光明斥候・赫斯珀洛斯碎片", "风暴骑手・欧洛斯契约者", "地震咆哮・恩塞拉多斯余震", "熔岩行者・埃特纳之血",
        "月光游侠・菲碧之影", "森林低语・德律阿得斯伴生", "河流之主・俄刻阿诺斯分流", "沙漠烈日・拉之残光", "冰雪守望・斯卡蒂寒息","雷电狂战士・因陀罗雷纹", "梵天智慧・婆罗贺摩残页", "湿婆之舞・那塔罗阇残影", "天照巫女・琼琼杵尊末裔", "须佐之男・建速须佐之鳞","罗马战神・玛尔斯凶兆", "巴比伦混沌・提亚马特鳞尘", "北欧雷霆・托尔之锤碎片", "埃及法老・拉神选民", 
        "曦光半神・厄尔庇斯残辉", "裂空使者・卡俄托斯碎片", "熵潮守望・忒修斯之裔", "烬灭母巢・伊格尼斯分蘖", "幽影眷族・墨提斯残识","霜烬祭司・克瑞斯托火种", "狩风之誓・仄费罗斯箭徒", "邃智之冠・菲罗忒斯残魄", "丰壤之镰・盖亚弥尔回响", "狂歌之裔・狄俄尼索斯投影","战衅狂怒・玛尔斯忒凶兆", "冥河引路人・赫卡忒拉仆从", "锻魂之魄・伏尔甘努斯碎片", "月汐之誓・塞勒涅亚投影", "风谕先知・埃俄罗斯忒气息",
        "疫魇假面・阿波罗忒灾厄", "愈光圣手・阿斯克勒庇俄斯微光", "爱欲之链・阿佛洛狄忒涟漪", "寐魇纺锤・修普诺斯残梦", "命轨织网・摩伊拉忒丝线","炎钢巨像・伊格尼索斯化身", "冰渊女祭・科瑞俄涅遗脉", "雷隼战使・珀鲁克斯忒残影", "沧溟巨蛇・刻托尼亚鳞裔", "岩壤守护者・安泰俄涅之躯","影刃刺客・诺克斯忒刃徒", "曦光斥候・赫斯珀里忒碎片", "storm-rider・欧洛斯忒契约者", "震地咆哮・恩塞拉多涅余震", "熔渊行者・埃特纳忒之血",
        "月纱游侠・菲碧忒之影", "森语伴生・德律阿得涅之种", "川流之主・俄刻阿诺斯忒分流", "沙暴烈日・拉米亚残光", "雪境守望・斯卡蒂忒寒息","雷纹狂战士・因陀罗忒雷印", "梵识残页・婆罗贺摩忒遗篇", "舞焰之影・那塔罗阇忒残影", "天照巫女・琼琼杵诺末裔", "刃鳞之裔・建速须佐忒鳞","战衅之兆・玛尔斯忒凶裔", "混沌鳞尘・提亚马特忒遗蜕", "雷锤碎片・托尔诺斯之骸", "法老选民・拉弥亚忒之嗣", 
        "翠森树精・艾奥纳赫忒之种", "霜原碎冰・尤弥尔忒残片", "神火余烬・普罗米修斯忒星火", "冥炙之魂・阿努比斯忒炙魂", "羽蛇鳞粉・库库尔坎忒遗尘","血祭之誓・维齐洛波奇特利忒之裔", "德鲁伊之泪・达努诺斯之种", "炽光之辉・密特拉忒残芒", "业火火种・阿耆尼索斯之火", "雪姬之息・雅玛托忒冰灵","狩风半神・掠风箭徒", "邃智半神・迷踪智者", "丰壤半神・垄亩之裔", "狂歌半神・醉梦回响", "战衅半神・血隙狂徒",
        "凯尔特树精・艾奥纳赫之种", "北欧寒霜・尤弥尔碎冰", "希腊神火・普罗米修斯余烬", "埃及冥火・阿努比斯炙魂", "玛雅预言・库库尔坎鳞粉","阿兹特克血祭・维齐洛波奇特利之誓", "凯尔特德鲁伊・达努之泪", "波斯光明・密特拉之辉", "印度业火・阿耆尼火种", "日本雪女・雪姬之息","冥河半神・渡魂引者", "锻魂半神・熔心匠师", "月汐半神・盈缺誓约", "风谕半神・湍流先知", "疫魇半神・腐面行者",
        "愈光半神・焕肤圣手", "爱欲半神・缠心之链", "寐魇半神・织梦纺锤", "命轨半神・紊线织工", "炎钢半神・灼铠巨像","冰渊半神・寒窟女祭", "雷隼半神・裂空战使", "沧溟半神・鳞渊巨蛇", "岩壤半神・磐岩守护者", "影刃半神・黯锋刺客","曦光半神・碎阳斥候", "风暴半神・涡旋骑手", "震地半神・裂谷咆哮", "熔渊半神・沸流行者", "月纱半神・胧影游侠","森语半神・朽木伴生", "川流半神・断脉之主", "沙暴半神・灼日行者", "雪境半神・霜原守望", "雷纹半神・狂霆战士",
        "梵识半神・残卷智者", "舞焰半神・旋火之影", "天空半神・残阳", "刃鳞半神・裂铠之裔", "翠森半神・枯木树精","霜原半神・碎冰行者", "神火半神・烬余使者", "冥炙半神・幽焰之魂", "羽蛇半神・蜕鳞遗民", "血祭半神・烬誓之裔","德鲁伊半神・朽叶之种", "炽光半神・残芒使者", "业火半神・燃魂火种", "雪姬半神・冰晶之息", "战衅半神・血兆骑士","混沌半神・蜕鳞之裔", "雷锤半神・破山之骸", "法老半神・沙嗣选民", 
        "九死无悔·绝境求生者", "万夫莫敌·战争机器", "永夜独行·暗夜游侠", "众生平等·天平守护者", "末日挽歌·终焉守卫者"
    }},
    
    // 武极境尊号
    {"Warrior93", new string[] {
        "原初熵能・混沌主宰", "亘古星轨・银河织主", "虚数裂隙・维度君王", "以太洪流・空域之主", "量子海渊・概率统御者","原初熵能・混沌织主", "亘古星轨・银河统御者", "虚数裂隙・维度君王", "以太洪流・空域之主", "量子海渊・概率仲裁者","熵变熔炉・造物神匠", "时空褶皱・纪元守望者", "因果织网・命运主宰", "虚实坍缩・量子神谕", "意识海渊・潜识之主","暗物质洪流・暗影君王", "反物质风暴・湮灭之主", "生命源质・世界树母", "死亡熵潮・寂灭君主", "灵魂量子・轮回守望者","元素武圣・冰火剑主", "光暗武尊・阴阳刃君", "雷霆武君・雷耀仲裁者", "自然武圣・草木劲主", "空间武尊・折跃剑君",
        "逻辑奇点・混沌破译者", "情感熵变・七情统御者", "记忆海渊・往事之主", "语言法则・语义支配者", "梦境维度・幻界君王","概率云涡・因果之主", "熵增熔炉・热寂神匠", "维度折叠・空间君主", "时间涟漪・纪元守望者", "信息洪流・数据之主","信仰凝聚・神格塑造者", "情绪风暴・狂乱之主", "知识奇点・全知君主", "遗忘深渊・记忆收割者", "希望熵潮・存续之主","混沌原力・无序君王", "秩序矩阵・规律之主", "物质坍缩・粒子神匠", "能量湍流・质能君主", "空间曲率・折叠之主","岩山之神・峭壁守护者", "森林之神・绿冠庇佑者", "河流之神・川流引导者", "海洋之神・浪涛统御者", "沙漠之神・沙暴君主","拳罡神座・裂地君王", "腿劲神座・踏岳主宰", "弓罡神座・追星统御者", "暗器神座・无影领主", "毒功神座・蚀骨仲裁者",
        "因果律涡・命运之主", "熵减之泉・逆序神匠", "意识海流・集体之主", "潜意识深渊・梦界君王", "元宇宙意识・虚拟之主","星涡神座・旋轨织主", "暗焰神座・烬灭统御者", "虚数神座・折跃君王", "熵流神座・无序仲裁者", "以太神座・空域守望者","晶骸神座・源质塑造者", "时域神座・纪元刻写者", "魂网神座・轮回编织者", "幻界神座・梦境熔铸者", "熵减神座・逆序神匠","创造神座・源点锻造者", "毁灭神座・终焉神匠", "平衡神座・因果调停者", "元宇宙神座・虚拟造物主", "潜意识神座・梦界君王","野火之神・灼原主宰", "霜雪之神・寒原守望者", "雷霆之神・天穹咆哮者", "骤雨之神・云海倾泻者", "狂风之神・峡谷疾驰者","炼体神座・金刚君主", "炼气神座・归元主宰", "炼魂神座・凝识统御者", "炼神神座・通明领主", "炼虚神座・化境仲裁者",
        "晨光之神・曦辉播撒者", "月华之神・银辉编织者", "星辰之神・星轨绘制者", "熔岩之神・地火锻造者", "寒冰之神・冻原塑形者","迷雾之神・幻境制造者", "闪电之神・电光穿刺者", "雷鸣之神・声震仲裁者", "虹光之神・七彩织匠", "暗影之神・幽境潜伏者","种子之神・萌芽催生者", "繁花之神・绽放守护者", "果实之神・丰收赐予者", "草木之神・绿意蔓延者", "谷物之神・麦田守望者","山兽之神・林麓统领者", "海兽之神・深渊主宰者", "飞禽之神・天穹巡逻者", "走兽之神・草原疾驰者", "虫豸之神・腐殖管理者","火焰之神・营火庇护者", "净水之神・泉眼守护者", "沃土之神・耕地滋养者", "风箱之神・锻炉协作者", "织机之神・经纬编织者","武技神座・万式君主", "功法神座・千卷主宰", "兵器神座・百兵统御者", "防具神座・坚甲领主", "灵药神座・回春仲裁者",
        "磨之神・谷物研磨者", "纺之神・纱线缠绕者", "镰之神・麦浪收割者", "犁之神・土地翻耕者", "渔之神・渔获赐予者","商之神・货栈守护者", "桥梁之神・天堑连接者", "道路之神・迷途指引者", "旅舍之神・疲惫抚慰者","锈铁之神・腐纹主宰", "碎瓷之神・裂纹守护者", "齿轮之神・锈痕统御者", "朽木之神・蛀洞塑造者", "残纸之神・咒纹编织者","骨烛之神・髓油燃烧者", "血珊瑚之神・骸礁君王", "墨染之神・晕痕仲裁者", "陶片之神・釉彩织主", "灰烬之神・余火守望者","冰棱之神・裂晶祭司", "腐殖之神・菌毯主宰", "琉璃之神・幻鳞熔铸者", "纸灰之神・咒烬协作者", "漆皮之神・剥落统御者","秘境神座・试炼君主", "宗门神座・万派主宰", "武者神座・百族统御者", "武道神座・归源领主", "武神神座・镇世仲裁者",
        "骨纹之神・髓痕祭司", "腐晶之神・菌簇塑造者", "琉璃蚀之神・幻锈统御者", "纸烬之神・咒涡协作者", "血锈之神・脉蚀仲裁者","时烬神谕・砂蚀君王", "空纹神座・折光熔铸者", "冰锈神谕・裂鳞主宰", "灰烬纹神座・余痕仲裁者", "陶茧神谕・釉丝织主","时烬神谕・砂蚀君王", "空纹神座・折光熔铸者", "冰锈神谕・裂鳞主宰", "灰烬纹神座・余痕仲裁者", "陶茧神谕・釉丝织主","暮烬巫", "月翳司", "风啸君", "雷掣神", "雨幔巫","雪冕主", "沙涡使", "岩脊君", "森魇神", "渊眼司","剑罡神座・裂空领主", "气脉神座・归元君主", "武魄神座・凝魂主宰", "经脉神座・周天统御者", "剑域神座・斩空仲裁者","元素剑主・风雷双绝", "光暗刀君・阴阳归一", "雷霆枪王・雷耀九天", "自然弓圣・草木皆兵", "空间拳尊・折跃千击",
        "纸灰神座・咒烬守望者", "骨烛神谕・髓油燃烧者", "血晶神座・脉礁君王", "漆皮神谕・剥落祭司", "木灵神座・空洞之主","灰烬神谕・余火织主", "冰棱神座・裂晶守望者", "齿轮茧神谕・发条编织者", "陶罐神座・釉彩熔铸者", "锈蚀神谕・熵锈主宰","骨螺神座・墟音吹奏者", "腐殖神谕・菌毯主宰", "琉璃神座・幻鳞熔铸者", "纸符神谕・咒纹编织者", "齿轮熵潮・锈心神匠","星涡织主", "雾境君", "苔痕主", "霜鬃神", "晨霭使","剑罡神座・裂空领主", "气脉神座・归元君主", "武魄神座・凝魂主宰", "经脉神座・周天统御者", "剑域神座・斩空仲裁者","魂脉神座・觉醒主宰", "罡气神座・凝甲君主", "剑意神座・万流统御者", "刀势神座・焚天领主", "枪魂神座・贯日仲裁者",
        "魂脉武君・觉醒万魂", "斗气武圣・凝甲千钧", "剑意战神・万流归宗", "刀势武神・焚天煮海", "枪魂武帝・贯日穿星","裂空剑主・天痕", "焚世刀君・烬灭", "穿云枪圣・破穹", "撼地拳帝・碎岳", "踏风腿尊・掠影","冰魄弓神・霜寂", "雷殛暗器王・瞬闪", "毒影功尊・蚀心", "金刚体神・不朽", "太虚气君・归元","万刃武皇・千锋", "阴阳刃圣・混沌", "星辰剑意神・璇枢", "幽冥刀势主・黄泉", "龙脊枪魂帝・贯日","风卷腿神・岚啸", "炽焰弓尊・燎天", "淬毒功圣・绝命", "不灭体君・涅槃", "周天炼气王・混元","剑域神座・裂空裁决者・天痕之主", "刀魄神庭・焚世收割者・烬灭君王", "枪芒圣殿・穿云破界者・破穹尊者", "拳罡领域・撼地碎岳者・碎岳战神", "飓风圣坛・踏风掠影者・掠影行者",
        "龙脊剑主・霜牙", "巫妖刀君・黯魂", "天使枪圣・光戟", "恶魔拳帝・炎爪", "独角兽尊・幻蹄","九头蛇弓神・毒矢", "狼人暗王・月刃", "魅魔功尊・惑心", "石像鬼体神・岩躯", "元素使气君・涡流","不死鸟武皇・烬羽", "美杜莎刃圣・石化", "精灵剑意神・森语", "幽灵刀势主・幽影", "巨龙枪魂帝・撼天","狮鹫神・翔爪", "凤凰弓尊・炽焰", "吸血鬼功圣・血噬", "树人体君・根甲", "德鲁伊炼气王・蔓藤","巨龙弓主・龙息", "巫妖暗器圣・咒符", "魔像功帝・铁躯", "矮人体神・锻岩", "魔法师炼气尊・奥术","龙脊神座・霜牙裁决者・冰原守护者", "巫妖神庭・黯魂收割者・亡灵君主", "天使圣殿・光戟破界者・天堂卫戍", "恶魔领域・炎爪碎岳者・地狱先锋", "独角兽圣坛・幻蹄掠影者・迷雾指引",
        "九头蛇神龛・毒矢射手・沼泽主宰", "狼人神阁・月刃暗杀者・月夜审判", "魅魔神窟・惑心蛊王・欲望之主", "石像鬼神体・岩躯壁垒・永固帝君", "元素使神脉・涡流引者・四象掌控","不死鸟神庭・烬羽齐鸣者・浴火之王", "美杜莎神刃・石化平衡者・蛇发女帝", "精灵剑阵・森语掌控者・森林先知", "幽灵刀冢・幽影引渡者・冥河向导", "巨龙枪殿・撼天穿星者・苍穹霸主","龙息神・烬炎", "巫妖主・黯咒", "天使皇・圣羽", "恶魔君・邪瞳", "独角兽王・灵辉","九头蛇尊・毒渊", "狼人魁・月噬", "魅魔后・幻惑", "石像鬼帝・岩守", "元素使・紊流","不死鸟尊・浴火", "美杜莎女君・石化", "精灵先知・森语", "幽灵领主・幽影", "巨龙帝王・撼世","狮鹫统领・翔空", "凤凰尊者・炽芒", "吸血鬼公爵・血裔", "树人长老・根脉", "德鲁伊大巫・蔓藤",
        "泰坦巨擘・山峦", "哥布林诡首・穴影", "人马统领・疾锋", "海妖歌姬・音漩", "亡灵君主・骨潮","龙语者・威权", "血祭者・牲祀", "霜语者・寒锋", "暗影潜伏者・匿踪", "光明咏者・辉耀","雷霆掌控者・轰霆", "自然协律者・共生", "灵魂收割者・摄魄", "虚空撕裂者・裂隙", "混沌具象者・无序","龙息神座・烬炎裁决者・焚世之主", "巫妖神庭・黯咒收割者・亡语君主", "天使圣殿・圣羽破界者・天穹卫戍", "恶魔领域・邪瞳碎岳者・深渊先锋", "独角兽圣坛・灵辉掠影者・希望指引","九头蛇神龛・毒渊射手・沼泽暴君", "狼人神阁・月噬暗杀者・永夜审判", "魅魔神窟・幻惑蛊王・欲望暴君", "石像鬼神体・岩守壁垒・亘古帝君", "元素使神脉・紊流引者・四象暴君","不死鸟神庭・浴火涅槃者・重生之王", "美杜莎神刃・石化凝视者・蛇发女帝", "精灵神谕・森语先知者・丛林智者", "幽灵冥府・幽影引渡者・黄泉向导", "巨龙神殿・撼世穿星者・苍穹霸主",
        "狮鹫空域・翔空统领者・云端帝王", "凤凰圣焰・炽芒焚野者・烈日之君", "吸血鬼血裔・血裔淬魂者・暗夜伯爵", "树人根系・根脉重生者・丛林帝君", "德鲁伊自然・蔓藤流转者・绿野之灵","泰坦山峦・巨擘化形者・大地之宗", "哥布林穴巢・诡首夺魄者・洞穴主宰", "人马草原・疾锋裂宇者・绿野统领", "海妖深渊・音漩破敌者・深海暴君", "亡灵冥河・骨潮逝者・幽冥行者","奥术法域・真理探寻者・知识之主", "符文刻痕・法则篆刻者・铭文帝王", "占星星轨・天命观测者・星象先知", "炼金嬗变・物质重塑者・元素君王", "咒缚链锁・命运禁锢者・枷锁主宰","龙语威权・巨龙共鸣者・兽群统领", "血祭牲祀・鲜血奉献者・仪式君主", "霜语寒锋・极冰掌控者・冻原之主", "暗影匿踪・潜行暗杀者・黑夜之刃", "光明辉耀・圣芒普照者・白昼守卫",
        "元素构态・万物塑形者・形态主宰", "时空溯流・命运编织者・纪元掌控者", "梦境织魇・虚幻主宰者・幻梦君王", "深渊窥虚・虚空凝视者・混沌先知", "命运牵线・丝线操纵者・因果君主","雷霆轰霆・天雷引动者・九霄之主", "自然共生・万物协律者・生态守护者", "灵魂摄魄・往生收割者・幽冥摆渡人", "虚空裂隙・维度撕裂者・异界统领", "暗夜魔渊・幽影噬魂者・永夜之君", "星辉圣庭・曜光裁决者・天穹守望者", "翡翠森域・藤蔓囚笼者・绿野仲裁官", "熔火炼狱・炎息焚世者・地脉主宰", "寒冰王座・霜晶封冻者・极北暴君","灵狐幻界・虚影迷惑者・梦境编织官", "骸骨冥河・亡者引路人・幽冥摆渡使", "元素回廊・万象塑形者・四象调和者", "龙脊之巅・龙吟震颤者・空域霸主", "腐坏君王",
        "雷霆穹顶・天雷轰落者・九霄审判使", "月光林地・银辉庇佑者・暗夜守护者", "虚空裂隙・次元撕裂者・异界支配者", "血月祭坛・鲜血献祭者・杀戮执政官", "星陨回廊・陨石坠落者・天象毁灭者","混沌迷窟・乱象具象者・无序支配官", "圣疗神殿・愈光恩泽者・生命重塑师", "符文密境・法则篆刻者・铭文掌控者", "风语峡谷・龙卷席卷者・气流统御者", "深海龙宫・潮汐操纵者・水域霸主","狼人荒原・月噬狂化者・野性统领者", "独角兽圣所・灵辉净化者・希望具象者", "巫妖墓园・黯咒呢喃者・亡语支配者", "美杜莎巢穴・石化凝视者・蛇发女王", "泰坦山脉・山峦化身者・大地守护者","暗影幽巷・潜行暗杀者・黑夜之影", "光明圣城・圣芒普照者・白昼守护者", "炼金工坊・物质嬗变者・元素重构师", "咒缚囚牢・命运禁锢者・枷锁支配者", "龙语高地・巨龙共鸣者・兽群统帅",
        "永夜回廊・幽影织梦者・暗域之主", "星辉穹顶・流光指引者・天穹引路人", "琥珀秘境・时光凝固者・往昔守望者", "毒藤深渊・瘴息蔓延者・腐化支配者", "炽焰熔炉・熔火锻造者・兵器之神","迷雾迷城・幻象操控者・迷途君主", "骸骨堡垒・亡骸重组者・冥土将军", "元素漩涡・四力调和者・混沌平衡官", "巨鲸海域・潮汐歌者・波涛仲裁者", "霜晶冰窟・寒芒冻结者・凛冬之王","灵蝶幻境・幻梦编织者・虚实塑造者", "血月祭坛・猩红赐福者・杀戮祭司", "虚空裂谷・次元修补者・异界调和使", "翡翠圣林・木灵共生者・自然守护者", "雷霆囚笼・天雷禁锢者・天罚执行者","月光高塔・银辉净化者・暗夜净化使", "暗影裂隙・潜行狩猎者・黑夜猎手", "圣泉神殿・圣水恩泽者・生命重塑官", "符文废墟・古咒唤醒者・铭文破坏者", "风蚀峡谷・气流切割者・风暴锻造师",
        "深海迷宫・鱼群统帅者・水域调度官", "狼人丘陵・兽化支配者・野性先知", "独角兽林地・灵角治愈者・伤痛平复者", "巫妖实验室・黯能研究者・禁忌学者", "美杜莎石窟・蛇眸威慑者・石化威慑官","泰坦峭壁・山峦锻打者・大地工匠", "哥布林矿洞・秘宝守护者・财宝支配者", "人马草原・疾风驾驭者・奔雷骑士", "海妖珊瑚礁・音波蛊惑者・海域魅惑者", "亡灵陵墓・魂火引导者・往生引路人","奥术图书馆・知识掠夺者・智慧窃取者", "咒缚囚牢・命运篡改者・枷锁破坏者", "龙语火山・龙威散播者・巨兽统领者", "霜语冰川・寒气凝聚者・冰雪塑造者", "自然原野・生灵共鸣者・生态协调官","灵魂裂隙・魂魄摆渡者・阴阳调解使", "风暴海湾・龙卷驾驭者・狂澜支配者", "星辰观测站・星象解读者・天命先知者", "混沌裂隙・乱象终结者・无序平息者", "光明圣城・黑暗净化者"
    }}
};
private static void UpdateNameSuffix(Actor actor, string newTrait)
{
    if (_warriorSuffixMap.TryGetValue(newTrait, out string suffix))
    {
        string currentName = actor.getName();
        
        // 1. 分离基础名称（包括尊号）和旧境界后缀
        int lastDashIndex = currentName.LastIndexOf('-');
        string basePart = lastDashIndex >= 0 
            ? currentName.Substring(0, lastDashIndex).Trim() 
            : currentName;
        
        // 2. 设置新名称：基础名称 + 新境界后缀
        actor.data.setName($"{basePart}-{suffix}");
    }
}

private static void ApplyWarriorTitle(Actor actor, string newTrait)
{
    if (_warriorTitlesMap.TryGetValue(newTrait, out string[] titles))
    {
        string currentName = actor.getName();
        
        // 1. 分离境界后缀（最后一个连字符后的内容）
        int lastDashIndex = currentName.LastIndexOf('-');
        string suffixPart = lastDashIndex > 0 
            ? currentName.Substring(lastDashIndex)
            : "";
        
        string basePart = lastDashIndex > 0 
            ? currentName.Substring(0, lastDashIndex).Trim()
            : currentName;
        
        // 2. 移除旧尊号（如果有）
        int firstDashIndex = basePart.IndexOf('-');
        if (firstDashIndex > 0)
        {
            basePart = basePart.Substring(firstDashIndex + 1).Trim();
        }
        
        // 3. 随机选择新尊号
        string title = titles[UnityEngine.Random.Range(0, titles.Length)];
        
        // 4. 设置新名称：新尊号 + 基础名称 + 境界后缀
        actor.data.setName($"{title}-{basePart}{suffixPart}");
    }
}

        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 1000 点真伤，可根据需要调整该值
                int trueDamage = 1000;
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 2000 点真伤，可根据需要调整该值
                int trueDamage = 2000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.06f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 4000 点真伤，可根据需要调整该值
                int trueDamage = 4000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.07f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 8000 点真伤，可根据需要调整该值
                int trueDamage = 8000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.08f); 
            }
            return false;
        }
        public static bool TrueDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 16000 点真伤，可根据需要调整该值
                int trueDamage = 16000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 32000 点真伤，可根据需要调整该值
                int trueDamage = 32000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }
        public static bool TrueDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 640000 点真伤，可根据需要调整该值
                int trueDamage = 640000; 
                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }

        public static bool fire1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_bomb_flash", pTile,"Bomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool fire2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile,"NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool Warrior1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Warrior2", "Warrior3", "Warrior4", "Warrior5", "Warrior6", "Warrior7", "Warrior8", "Warrior9", "Warrior91", "Warrior92", "Warrior93" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Warrior1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );
            UpdateNameSuffix(a, "Warrior1");

            return true;
        }

        public static bool Warrior2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetWarrior() <= 9.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.8;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior1",
                "Warrior2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Warrior22" }
            );
            UpdateNameSuffix(a, "Warrior2");

            return true;
        }

        public static bool Warrior3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 8)
            {
                // 添加Warrior1特质
                upTrait("特质", "Warrior1", a, new string[] { "Warrior2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 19.99)
            {
                return false;
            }

            a.ChangeWarrior(-2);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.7;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Warrior2",
                "Warrior3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior22"
                },
                new string[] { "Warrior3+", selectedTrait }
            );
            UpdateNameSuffix(a, "Warrior3");

            // 随机选择一个低级功法特质添加给人物
            string[] LowGongFa = { "LowGongFaTrait1", "LowGongFaTrait2", "LowGongFaTrait9", "LowGongFaTrait3", "LowGongFaTrait4", "LowGongFaTrait5", "LowGongFaTrait6", "LowGongFaTrait7", "LowGongFaTrait8" }; // 根据实际情况添加更多特质
            int randomIndex1 = UnityEngine.Random.Range(0, LowGongFa.Length);
            string selectedLowGongFa = LowGongFa[randomIndex];
            a.addTrait(selectedLowGongFa);

            return true;
        }

        public static bool Warrior4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 18)
            {
                upTrait("特质", "Warrior2", a, new string[] { "Warrior3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 39.99)
            {
                return false;
            }

            a.ChangeWarrior(-3);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Warrior3",
                "Warrior4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior3+"
                },
                new string[] { "Warrior4+" }
            );
            UpdateNameSuffix(a, "Warrior4");

            return true;
        }

        public static bool Warrior5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 37)
            {
                upTrait("特质", "Warrior3", a, new string[] { "Warrior4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 79.99)
            {
                return false;
            }

            a.ChangeWarrior(-4);
            double successRate = 0.6;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.8;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 1.0;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 1.0;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior4",
                "Warrior5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior4+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior5+", selectedTrait } :
                new string[] { "Warrior5+" }
            );
            UpdateNameSuffix(a, "Warrior5");

            return true;
        }

        public static bool Warrior6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 76)
            {
                upTrait("特质", "Warrior4", a, new string[] { "Warrior5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetWarrior() <= 159.99)
            {
                return false;
            }

            a.ChangeWarrior(-5);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Warrior5",
                "Warrior6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Warrior5+"
                },
                (selectedTrait != null) ?
                new string[] { "Warrior6+", "freeze_proof", "fire_proof", "martialBloodline1", selectedTrait } :
                new string[] { "Warrior6+", "freeze_proof", "fire_proof" }
            );
            UpdateNameSuffix(a, "Warrior6");

            string[] midGongFaTraits = {
                "MidGongFaTrait1", "MidGongFaTrait2", "MidGongFaTrait3", "MidGongFaTrait4",
                "MidGongFaTrait5", "MidGongFaTrait6", "MidGongFaTrait7", "MidGongFaTrait8",
                "MidGongFaTrait9", "MidGongFaTrait10", "MidGongFaTrait11", "MidGongFaTrait12",
                "MidGongFaTrait13"
            };

            // 随机决定获得特质的数量（1 - 2 个）
            int traitCount = UnityEngine.Random.Range(1, 3);

            // 随机选择特质
            List<string> selectedTraits = new List<string>();
            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, midGongFaTraits.Length);
                string traitId = midGongFaTraits[randomIndex];
                if (!selectedTraits.Contains(traitId))
                {
                    selectedTraits.Add(traitId);
                    a.addTrait(traitId, false);
                }
            }

            return true;
        }

        public static bool Warrior7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查气血值是否小于x，如果是，则趺落境界
            if (a.GetWarrior() < 155)
            {
                upTrait("特质", "Warrior6", a, new string[] { "Warrior7" }, new string[] { });
                return true;
            }

            if (a.GetWarrior() <= 299.99)
            {
                return false;
            }

            a.ChangeWarrior(-6);
            double successRate = 0.1;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.5;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior6",
                "Warrior7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior6+", "martialBloodline1" },
                new string[] { "Warrior7+", "martialBloodline2" }
            );
            UpdateNameSuffix(a, "Warrior7");
            ApplyWarriorTitle(a, "Warrior7");

            string[] GongFa = { "GongFaTrait1", "GongFaTrait2", "GongFaTrait3", "GongFaTrait4", "GongFaTrait5", "GongFaTrait6", "GongFaTrait7", "GongFaTrait8", "GongFaTrait9", "GongFaTrait10", "GongFaTrait11", "GongFaTrait12", "GongFaTrait13" };
            int randomIndex2 = UnityEngine.Random.Range(0, GongFa.Length);
            string selectedGongFa = GongFa[randomIndex2];
            a.addTrait(selectedGongFa);

            // 检查是否拥有“先天无漏”特质
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior94");
            }

            return true;
        }

        public static bool Warrior8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 499.99)
            {
                return false;
            }

            a.ChangeWarrior(-9);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior94"};
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior7",
                "Warrior8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior7+", "Warrior94", "martialBloodline2" },
                new string[] { "Warrior8+", "strong_minded", "immune", "martialBloodline3" }
            );
            UpdateNameSuffix(a, "Warrior8");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior95");
            }

            return true;
        }

        public static bool Warrior9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 799.99)
            {
                return false;
            }

            a.ChangeWarrior(-15);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.05; 
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.8;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior95" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior8",
                "Warrior9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior8+", "Warrior95", "martialBloodline3" },
                new string[] { "Warrior9+" ,"fire_proof", "regeneration", "martialBloodline4"}
            );
            UpdateNameSuffix(a, "Warrior9");
            ApplyWarriorTitle(a, "Warrior9");
       
            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.2f)
            {
                a.addTrait("Warrior96");
            }

            return true;
        }

        public static bool Warrior91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 1199.99)
            {
                return false;
            }

            a.ChangeWarrior(-20);
            double successRate = 0.08;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.08;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.15;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.3;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior96" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior9",
                "Warrior91",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior9+", "martialBloodline4", "Warrior96" },
                new string[] { "Warrior91+", "martialBloodline5" }
            );
            UpdateNameSuffix(a, "Warrior91");
            ApplyWarriorTitle(a, "Warrior91");

            string[] arcaneTomes = { "arcaneTome1", "arcaneTome2", "arcaneTome3", "arcaneTome4", "arcaneTome5", "arcaneTome6", "arcaneTome7", "arcaneTome8", "arcaneTome9", "arcaneTome10", "arcaneTome11", "arcaneTome12", "arcaneTome13" }; // 可以添加更多传承法特质名
            int randomIndex3 = UnityEngine.Random.Range(0, arcaneTomes.Length);
            string selectedarcaneTome = arcaneTomes[randomIndex3];
            a.addTrait(selectedarcaneTome);

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior97");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior9", "Warrior91");
            a.data.favorite = true;

            return true;
        }

        public static bool Warrior92_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetWarrior() <= 3599.99)
            {
                return false;
            }

            a.ChangeWarrior(-30);
            double successRate = 0.06;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.002;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.3;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior97" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior91",
                "Warrior92",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior91+", "martialBloodline5", "Warrior97" },
                new string[] { "Warrior92+", "martialBloodline6" }
            );
            UpdateNameSuffix(a, "Warrior92");

            if (!a.hasTrait("congenitalPerfection") && UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior98");
            }

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Warrior91", "Warrior92");

            return true;
        }

        public static bool Warrior93_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetWarrior() <= 9999.99)
            {
                return false;
            }

            a.ChangeWarrior(-60);
            double successRate = 0.02;
            if (a.hasTrait("martialAptitude1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("martialAptitude2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("martialAptitude3"))
            {
                successRate = 0.001;
            }
            else if (a.hasTrait("martialAptitude4"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("martialAptitude7"))
            {
                successRate = 0.015;
            }
            else if (a.hasTrait("martialAptitude8"))
            {
                successRate = 0.1;
            }

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Warrior98" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Warrior92",
                "Warrior93",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Warrior92+", "martialBloodline6", "Warrior98" },
                new string[] { "Warrior93+", "immunity", "martialBloodline7" }
            );
            UpdateNameSuffix(a, "Warrior93");
            ApplyWarriorTitle(a, "Warrior93");

            if (UnityEngine.Random.Range(0f, 1f) < 0.25f)
            {
                a.addTrait("Warrior99");
            }

            NotificationHelper.ShowBreakthroughNotification(a, "Warrior92", "Warrior93");

            // 随机获得一到三个九字秘特质
            string[] nineCharacterSecrets = { "NineCharacterSecret1", "NineCharacterSecret2", /* 其他九字秘特质名 */ };
            int traitCount = UnityEngine.Random.Range(1, 4);
            List<string> selectedTraits = new List<string>();

            while (selectedTraits.Count < traitCount)
            {
                int randomIndex = UnityEngine.Random.Range(0, nineCharacterSecrets.Length);
                string selectedTrait = nineCharacterSecrets[randomIndex];
                if (!selectedTraits.Contains(selectedTrait))
                {
                    selectedTraits.Add(selectedTrait);
                    a.addTrait(selectedTrait);
                }
            }

            return true;
        }

        
        //武者的恢复生命值效果
        public static bool Warrior1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior91_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior92_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Warrior93_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);

            return true;
        }
    }
}