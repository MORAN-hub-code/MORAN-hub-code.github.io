﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool lei_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningMedium(pTile, 0.05f);
                if (pTarget.a.data.health > 10)
                {
                    pTarget.a.restoreHealth(-10);
                }
            }

            return false;
        }

        public static bool TrDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 2000 点真伤，可根据需要调整该值
                int trDamage = 30;
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 4000 点真伤，可根据需要调整该值
                int trDamage = 60; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 8000 点真伤，可根据需要调整该值
                int trDamage = 120; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 16000 点真伤，可根据需要调整该值
                int trDamage = 300; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrDamage5_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 32000 点真伤，可根据需要调整该值
                int trDamage = 600; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrDamage6_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 64000 点真伤，可根据需要调整该值
                int trDamage = 1200; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }
        public static bool TrDamage7_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor())
            {
                Actor targetActor = pTarget.a;
                // 假设造成 128000 点真伤，可根据需要调整该值
                int trDamage = 6000; 
                if (targetActor.data.health > trDamage)
                {
                    targetActor.restoreHealth(-trDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f); 
            }
            return false;
        }

        public static bool Knight1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.学徒骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Knight2", "Knight3", "Knight4", "Knight5", "Knight6", "Knight7", "Knight8", "Knight9", "Knight10", "Knight11", "Knight12" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Knight1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );

            return true;
        }

        public static bool Knight2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetKnight() <= 9.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.8;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight1",
                "Knight2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Knight22" }
            );

            return true;
        }

        public static bool Knight3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 8)
            {
                // 添加Knight1特质
                upTrait("特质", "Knight1", a, new string[] { "Knight2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 19.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Knight2",
                "Knight3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight22"
                },
                new string[] { "Knight3+", selectedTrait }
            );

            return true;
        }

        public static bool Knight4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.中级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 18)
            {
                upTrait("特质", "Knight2", a, new string[] { "Knight3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 39.99)
            {
                return false;
            }

            a.ChangeKnight(-3);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight3",
                "Knight4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight3+"
                },
                new string[] { "Knight4+" }
            );

            return true;
        }

        public static bool Knight5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.高骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 37)
            {
                upTrait("特质", "Knight3", a, new string[] { "Knight4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 79.99)
            {
                return false;
            }

            a.ChangeKnight(-4);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Knight4",
                "Knight5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight4+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight5+", selectedTrait } :
                new string[] { "Knight5+" }
            );

            return true;
        }

        public static bool Knight6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 76)
            {
                upTrait("特质", "Knight4", a, new string[] { "Knight5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 99.99)
            {
                return false;
            }

            a.ChangeKnight(-5);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }

            string actorName = a.getName();
            bool hasTitle = _knightTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _knightTitles.Length);
                string selectedTitle = _knightTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Knight5",
                "Knight6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight5+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight6+", "freeze_proof", "fire_proof", selectedTrait } :
                new string[] { "Knight6+", "freeze_proof", "fire_proof" }
            );

            return true;
        }

        public static bool Knight7_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 95)
            {
                upTrait("特质", "Knight6", a, new string[] { "Knight7" }, new string[] { });
                return true;
            }

            if (a.GetKnight() <= 299.99)
            {
                return false;
            }

            a.ChangeKnight(-6);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight6",
                "Knight7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight6+" },
                new string[] { "Knight7+" }
            );

            return true;
        }

        public static bool Knight8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.皇家骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 499.99)
            {
                return false;
            }

            a.ChangeKnight(-9);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight7",
                "Knight8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight7+" },
                new string[] { "Knight8+", "strong_minded", "immune" }
            );

            return true;
        }

        public static bool Knight9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.传奇骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 799.99)
            {
                return false;
            }

            a.ChangeKnight(-15);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight8",
                "Knight9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight8+" },
                new string[] { "Knight9+" }
            );

            // 确保获得防火特质
            a.addTrait("fire_proof");

            return true;
        }

        public static bool Knight10_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣殿骑士长
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 999.99)
            {
                return false;
            }

            a.ChangeKnight(-20);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight9",
                "Knight10",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight9+" },
                new string[] { "Knight10+" }
            );

            string[] inheritanceLaws = { "inheritanceLaw1", "inheritanceLaw2", "inheritanceLaw3", "inheritanceLaw4", "inheritanceLaw5", "inheritanceLaw6", "inheritanceLaw7", "inheritanceLaw8", "inheritanceLaw9", "inheritanceLaw10", "inheritanceLaw11", "inheritanceLaw12", "inheritanceLaw13" }; // 可以添加更多传承法特质名
            int randomIndex = UnityEngine.Random.Range(0, inheritanceLaws.Length);
            string selectedInheritanceLaw = inheritanceLaws[randomIndex];
            a.addTrait(selectedInheritanceLaw);

            NotificationHelper.ShowBreakthroughNotification(a, "Knight9", "Knight10");

            return true;
        }

        public static bool Knight11_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.骑士王
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 2999.99)
            {
                return false;
            }

            a.ChangeKnight(-30);
            double successRate = 0.06;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.03;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight10",
                "Knight11",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight10+" },
                new string[] { "Knight11+" }
            );

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Knight10", "Knight11");

            return true;
        }

        public static bool Knight12_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.天启骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetKnight() <= 8999.99)
            {
                return false;
            }

            a.ChangeKnight(-60);
            double successRate = 0.02;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.001;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight11",
                "Knight12",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight11+" },
                new string[] { "Knight12+" }
            );

            NotificationHelper.ShowBreakthroughNotification(a, "Knight11", "Knight12");

            return true;
        }

        private static readonly string[] _knightTitles = { "「帝国玫瑰」", "「拜伦斯的雄狮」", "「断矛者」", "「宽恕之棘」", "「红隼」", "「白手套」", "「车轮伯爵」"
, "「无鞘」", "「鸦喙」", "「宴会蜘蛛」", "「绯红之冠」", "「赤色黎明」", "「黑桃密使」", "「毒蝎骑士」", "「密语伯爵」", "「黑天鹅之喙」", "「锈冠」", "「影桥」"
, "「白天鹅之翼」", "「哑剧皇冠」", "「黑弥撒」", "「摇篮铁律」", "「绯红安魂曲」", "「黑铁摇篮曲」", "「染血鸢尾」", "「泣铁蔷薇」", "「青铜挽歌」", "「赤红飓风」"
, "「铸铁玫瑰」", "「悼亡晨星」", "「噬魂长枪」", "「白银钢脊」", "「无声坚壁」", "「秘银壁垒」", "「凛冬之剑」", "「寒铁龙骑」", "「碧落剑圣」", "「孤儿院院长」"
, "「石心仲裁者」", "「破晓追猎者」" , "「铁幕游侠」", "「永夜守钟人」" , "「黑骑士」", "「炽诚之剑」", "「曙光长枪」" , "「慈悲坚盾」", "「黎明破晓者」", "「晨曦之剑」"
, "「影舞之刃」", "「苍穹游侠」" , "「幻影」", "「月影」", "「铁匠」", "「剑心」", "「凡铁」", "「裁决」", "「不落残阳」", "「夜枭巡礼」", "「焦土漫游者」", "「猎鹰」"
, "「雷鸣」", "「毒蛇」", "「巨熊」", "「狮鹫」", "「哭墙铁骑」", "「刽子手」", "「谥号猎犬」", "「铁蒺藜诗人」", "「骨哨牧者」", "「褡裢法典」", "「谵妄画师」", "「白色骑士」"
, "「蓝骑」", "「红骑」", "「紫骑」", "「灰骑」" , "「胜利号角」", "「雾港摆渡人」", "「哑宴鸩使」", "「灰眸裁罚者」", "「锈链仲裁者」", "「哑钟执剑者」", "「雾银裁缝」"
, "「黑天鹅饲官」", "「鸦巢律师」", "「血喙驯鹰人」", "「茧衣蛛爵」", "「黑玫瑰」", "「学士」", "「碎铠者」", "「默誓者」", "「燧心」", "「双刃」", "「暮钟」"
, "「枭羽」", "「圣灰诵者」", "「影语者」" , "「血纹师」", "「骨钟」", "「哑光」", "「烬心」", "「棘吻」", "「慈戮」", "「笑魇」", "「哑歌」", "「悖光」", "「希望」"
, "「狼影」", "「晨星」", "「晨辉」" };

        //骑士的恢复生命值效果
        public static bool Knight1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight10_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight11_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight12_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
