﻿﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using System.Reflection;
using System.Reflection.Emit;
using VideoCopilot.code.utils;

namespace Chevalier.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }


        [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
        public static bool checkLightningAction(Vector2Int pPos, int pRad)
        {
            bool flag = false;
            List<Actor> simpleList = World.world.units.getSimpleList();
            for (int i = 0; i < simpleList.Count; i++)
            {
                Actor actor = simpleList[i];
                if (Toolbox.DistVec2(actor.current_tile.pos, pPos) <= (float)pRad)
                {
                    if (actor.asset.flag_finger)
                    {
                        actor.getActorComponent<GodFinger>().lightAction();
                    }
                    else
                    {
                        if (!flag && !actor.hasTrait("immortal") && Randy.randomChance(0.2f))
                        {
                            flag = true;
                        }

                        SignalAsset check_achievement_may_i_interrupt = SignalLibrary.check_achievement_may_i_interrupt;
                        BehaviourTaskActor task = actor.ai.task;
                        SignalManager.add(check_achievement_may_i_interrupt, (task != null) ? task.id : null);
                    }
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "makeStunned")]
        public static bool makeStunned(Actor __instance, float pTime = 5f)
        {
            pTime += Randy.randomFloat(0f, pTime * 0.1f);
            __instance.cancelAllBeh();
            __instance.makeWait(pTime);
            // 如果没有防火特质，则添加眩晕状态效果，否则不添加眩晕状态效果
            if (!__instance.hasTrait("fire_proof"))
            {
                if (__instance.addStatusEffect("stunned", pTime, true))
                {
                    __instance.finishAngryStatus();
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "addStunnedEffectOnTarget20")]
        // 添加眩晕效果到目标（20%概率）
        public static bool addStunnedEffectOnTarget20_Patch(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 检查目标是否有效（未死亡、非建筑）
            if (pTarget.isRekt() || pTarget.isBuilding()) 
            {
                return false;
            }

            // 检查随机概率（20%）
            if (!Randy.randomChance(0.2f))
            {
                return false;
            }

            // 检查目标是否具有防火特质
            if (pTarget.isActor() && pTarget.a.hasTrait("fire_proof"))
            {
                return false;
            }

            // 调用眩晕方法
            return ActionLibrary.addStunnedEffectOnTarget(pSelf, pTarget, pTile);
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
            Actor __instance,
            ref float pDamage,
            bool pFlash,
            AttackType pAttackType,
            BaseSimObject pAttacker,
            bool pSkipIfShake,
            bool pMetallicWeapon,
            bool pCheckDamageReduction = true)
        {
            __instance._last_attack_type = pAttackType;
            // 闪避机制
            if (pAttacker is Actor attackerActor && __instance.isAlive())
            {
                float attackerMingzhong = attackerActor.stats["Mingzhong"];
                float targetShanbi = __instance.stats["Shanbi"];
                float effectiveShanbi = Mathf.Clamp(targetShanbi - attackerMingzhong, 0f, 100f);

                if (Randy.randomChance(effectiveShanbi / 100f))
                {
                    __instance.startColorEffect(ActorColorEffect.White);
                    return false;
                }
            }
            return true;
        }
        
        [HarmonyPrefix, HarmonyPatch(typeof(ActorTool), "applyForceToUnit")]
        public static bool ApplyForceToUnit_Postfix(Actor __instance, AttackData pData, BaseSimObject pTargetToCheck, float pMod = 1f, bool pCheckCancelJobOnLand = false)
        {
            float tForce = pData.knockback * pMod;

            if (tForce > 0f && pTargetToCheck.isActor())
            {
                float resistValue = pTargetToCheck.a.stats["knockback_reduction"];
                tForce = Mathf.Max(tForce - resistValue, 0);

                if (tForce > 0f)
                {
                    Vector2 tPosStart = pTargetToCheck.cur_transform_position;
                    Vector2 tAttackVec = pData.hit_position;
                    pTargetToCheck.a.calculateForce(
                        tPosStart.x, tPosStart.y,
                        tAttackVec.x, tAttackVec.y,
                        tForce,
                        0f,
                        pCheckCancelJobOnLand
                    );
                }
            }
            return false;
        }
    
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_ChevalierPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasGermofLife10 = __instance.hasTrait("GermofLife10");// 检查是否具有特质
            bool hasGermofLife9 = __instance.hasTrait("GermofLife9");
            bool hasDivineSeal = __instance.hasTrait("DivineSeal"); // 检查是否拥有“先天圆满”特质

            bool hasObtainedLegacyTechnique = false;

            // 检查是否拥有“武祖赐福”特质
            bool hasGermofLife8 = __instance.hasTrait("GermofLife8");
            if (hasGermofLife8)
            {
                if (!hasObtainedLegacyTechnique)
                {
                    string[] LegacyTechnique = {
                        "LegacyTechnique91"
                    };

                    int randomIndex = UnityEngine.Random.Range(0, LegacyTechnique.Length);
                    string selectedLegacyTechnique = LegacyTechnique[randomIndex];

                    if (!__instance.hasTrait(selectedLegacyTechnique))
                    {
                        __instance.addTrait(selectedLegacyTechnique);
                        hasObtainedLegacyTechnique = true;
                    }
                }
                
                __instance.data.favorite = true;

            }

            // 检查是否拥有混沌帝血特质
            bool hasKnightlyBloodline7 = __instance.hasTrait("KnightlyBloodline7");
            if (hasKnightlyBloodline7)
            {
                // 直接觉醒玄玉根骨
                string GermofLife4Trait = "GermofLife4";
                // 定义根骨特质数组
                string[] GermofLifeTraits = {
                    "GermofLife1",
                    "GermofLife2",
                    "GermofLife3",
                    "GermofLife4",
                    "GermofLife7",
                    "GermofLife8",
                    "GermofLife9",
                    "GermofLife10"
                };

                // 检查是否已拥有任何根骨特质
                bool hasAnyGermofLife = false;
                foreach (string trait in GermofLifeTraits)
                {
                    if (__instance.hasTrait(trait))
                    {
                        hasAnyGermofLife = true;
                        break;
                    }
                }

                // 只有在未拥有任何根骨特质时才觉醒玄玉根骨
                if (!hasAnyGermofLife && !__instance.hasTrait("GermofLife4"))
                {
                    __instance.addTrait("GermofLife4");
                }
            }

            // 出生时（年龄为1）有一定概率获得“先天圆满”特质
            if (Mathf.FloorToInt(age) == 1 && !hasDivineSeal && Randy.randomChance(0.03f)) // 3% 的概率
            {
                __instance.addTrait("DivineSeal", false);
            }

            // 定义特定种族数组
            string[] basicRaces = { "orc", "human", "elf", "dwarf" };

            // 4岁时获得GermofLife1 - GermofLife10的随机特质
            if (Mathf.FloorToInt(age) == 4 && !hasGermofLife9 && !hasGermofLife10 &&
                !HasAnyFlairTalen(__instance) &&
                (basicRaces.Contains(__instance.asset.id) || __instance.asset.id.StartsWith("civ_")))
            {

                // 如果已经拥有玄玉根骨（因混沌帝血获得），则跳过此次随机根骨觉醒
                if (__instance.hasTrait("GermofLife4"))
                {
                    return;
                }

                float bloodlineBonus = 0f;
                if (__instance.hasTrait("KnightlyBloodline1"))
                {
                    bloodlineBonus = 0.2f; // 一级血脉提高20%的概率
                }
                else if (__instance.hasTrait("KnightlyBloodline2"))
                {
                    bloodlineBonus = 0.3f; // 二级血脉提高30%的概率
                }
                else if (__instance.hasTrait("KnightlyBloodline3"))
                {
                    bloodlineBonus = 0.4f; // 三级血脉提高40%的概率
                }
                else if (__instance.hasTrait("KnightlyBloodline4"))
                {
                    bloodlineBonus = 0.5f; // 四级血脉提高50%的概率
                }
                else if (__instance.hasTrait("KnightlyBloodline5"))
                {
                    bloodlineBonus = 0.6f; // 五级血脉提高60%的概率
                }
                else if (__instance.hasTrait("KnightlyBloodline6"))
                {
                    bloodlineBonus = 0.7f; // 六级血脉提高70%的概率
                }

                if (Randy.randomChance(0.2f + bloodlineBonus))
                {
                    var GermofLifeWeights = new (string traitId, float weight)[]
                    {
                        ("GermofLife1", 64f),
                        ("GermofLife2", 31f),
                        ("GermofLife3", 4.58f),
                        ("GermofLife4", 0.33f),
                        ("GermofLife7", 0.076f),
                        ("GermofLife8", 0.014f),
                    };

                    // 计算总权重
                    float totalWeight = GermofLifeWeights.Sum(t => t.weight);

                    // 生成随机浮点数
                    float randomValue = UnityEngine.Random.Range(0f, totalWeight);

                    // 遍历权重选择特质
                    string selectedGermofLife = "GermofLife1"; // 默认值
                    foreach (var GermofLife in GermofLifeWeights)
                    {
                        if (randomValue < GermofLife.weight)
                        {
                            selectedGermofLife = GermofLife.traitId;
                            break;
                        }
                        randomValue -= GermofLife.weight;
                    }

                    __instance.addTrait(selectedGermofLife, false);
                }
            }

            // 特质增加武者气血的处理
            var GermofLifeChevalierChanges = new Dictionary<string, (float, float)>
            {
                { "GermofLife1", (1.0f, 2.0f) },//下
                { "GermofLife2", (2.0f, 4.0f) },//中
                { "GermofLife3", (4.0f, 7.0f) },//上
                { "GermofLife4", (7.0f, 10.0f) },//龙筋虎骨
                { "GermofLife10", (-1.0f, -2.0f) },//英雄迟暮
                { "GermofLife7", (10.0f, 14.0f) },//真武转世
                { "GermofLife8", (14.0f, 18.0f) },//天生至尊
            };

            foreach (var change in GermofLifeChevalierChanges)
            {
                // 如果具有GermofLife10特质，并且当前特质是GermofLife1到GermofLife4，则跳过
                if ((hasGermofLife10 || hasGermofLife9) && (change.Key == "GermofLife1" || change.Key == "GermofLife2" || change.Key == "GermofLife3" || change.Key == "GermofLife4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomChevalierIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeChevalier(randomChevalierIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var ChevalierTraitThresholds = new Dictionary<string, float>
            {
                { "Chevalier1", 40f },
                { "Chevalier2", 50f },
                { "Chevalier3", 50f },
                { "Chevalier4", 65f },
                { "Chevalier5", 70f },
                { "Chevalier6", 100f },
                { "Chevalier7", 150f },
                { "Chevalier8", 220f },
                { "Chevalier9", 400f },
                { "Chevalier91", 600f },
                { "Chevalier92", 1000f },
                { "Chevalier93", 2000f }
            };
            const float GermofLife10Chance = 0.1f;
            foreach (var threshold in ChevalierTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(GermofLife10Chance) && !hasDivineSeal)
                {
                    __instance.addTrait("GermofLife10", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Chevalier1", 10f },
                { "Chevalier2", 20f },
                { "Chevalier3", 40f },
                { "Chevalier4", 80f },
                { "Chevalier5", 160f },
                { "Chevalier6", 300f },
                { "Chevalier7", 500f },
                { "Chevalier8", 800f },
                { "Chevalier9", 1200f },
                { "Chevalier91", 3600f },
                { "Chevalier92", 10000f },
                { "Chevalier93", 18000f },
            };
            foreach (var grade in grades)
            {
                UpdateChevalierBasedOnGrade(__instance, grade.Key, grade.Value);
            }
        }

        private static void UpdateChevalierBasedOnGrade(Actor actor, string traitName, float maxChevalier)
        {
            if (actor.hasTrait(traitName))
            {
                float currentChevalier = actor.GetChevalier();
                float newValue = Mathf.Min(maxChevalier, currentChevalier);
                actor.SetChevalier(newValue);
            }
        }

        private static readonly string[] FlairGermofLifeTraits = new[] { "GermofLife1", "GermofLife2", "GermofLife3", "GermofLife4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairGermofLifeTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}    