﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArcaneTrait.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset interseting = new ActorTraitGroupAsset();
            interseting.id = "interseting";
            interseting.name = "trait_group_interseting";
            interseting.color = "#FF66CC";
            AssetManager.trait_groups.add(interseting);
        }
    }
}
