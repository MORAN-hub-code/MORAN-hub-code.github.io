﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;
using System.Diagnostics;

namespace ArcaneTrait.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = CreateBaseStats();
            
            return trait;
        }

        private static BaseStats CreateBaseStats()
        {
            try 
            {
                BaseStats baseStats = new BaseStats();
                Type baseStatsType = typeof(BaseStats);
                var fields = baseStatsType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                
                foreach (var field in fields)
                {
                    if (field.Name.Contains("dict") || field.Name.Contains("_stats"))
                    {
                        if (field.GetValue(baseStats) == null)
                        {
                            var dictType = typeof(Dictionary<string, float>);
                            var dict = Activator.CreateInstance(dictType);
                            field.SetValue(baseStats, dict);
                        }
                    }
                }
                
                return baseStats;
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Failed to create BaseStats: {ex.Message}");
                return null;
            }
        }

        public static void Init()
        {
            try 
            {
                ActorTrait interbook7 = CreateTrait("interbook7", "trait/interbook7", "interseting"); //狙击镜
                SafeSetStat(interbook7.base_stats, S.range, 99f);
                SafeSetStat(interbook7.base_stats, S.area_of_effect, 99f);
                AssetManager.traits.add(interbook7);

                ActorTrait interbook8 = CreateTrait("interbook8", "trait/interbook8", "interseting"); //全知之眼
                SafeSetStat(interbook8.base_stats, S.intelligence, 99f);
                SafeSetStat(interbook8.base_stats, S.warfare, 99f);
                SafeSetStat(interbook8.base_stats, S.stewardship, 99f);
                AssetManager.traits.add(interbook8);

                ActorTrait interbook4 = CreateTrait("interbook4", "trait/interbook4", "interseting"); //致命一击
                SafeSetStat(interbook4.base_stats, S.damage, 999f);
                SafeSetStat(interbook4.base_stats, S.critical_chance, 0.99f);
                AssetManager.traits.add(interbook4);

                ActorTrait interbook6 = CreateTrait("interbook6", "trait/interbook6", "interseting"); //超速
                SafeSetStat(interbook6.base_stats, S.speed, 666f);
                AssetManager.traits.add(interbook6);

                ActorTrait interbook5 = CreateTrait("interbook5", "trait/interbook5", "interseting"); //守护者
                SafeSetStat(interbook5.base_stats, S.armor, 99f);
                AssetManager.traits.add(interbook5);

                ActorTrait interseting1 = CreateTrait("interseting1", "trait/interseting1", "interseting");
                SafeSetStat(interseting1.base_stats, S.mana, 200f);
                SafeSetStat(interseting1.base_stats, S.lifespan, 120f);
                SafeSetStat(interseting1.base_stats, S.health, 2000f);
                SafeSetStat(interseting1.base_stats, S.speed, 11f);
                SafeSetStat(interseting1.base_stats, S.attack_speed, 1f);
                SafeSetStat(interseting1.base_stats, S.damage, 200f);
                SafeSetStat(interseting1.base_stats, S.armor, 1f);
                SafeSetStat(interseting1.base_stats, S.stamina, 100f);
                interseting1.action_special_effect += (WorldAction)Delegate.Combine(interseting1.action_special_effect,
                    new WorldAction(traitAction.interseting20_effectAction));
                AssetManager.traits.add(interseting1);

                ActorTrait interseting2 = CreateTrait("interseting2", "trait/interseting2", "interseting");
                SafeSetStat(interseting2.base_stats, S.mana, 300f);
                SafeSetStat(interseting2.base_stats, S.lifespan, 200f);
                SafeSetStat(interseting2.base_stats, S.health, 3000f);
                SafeSetStat(interseting2.base_stats, S.speed, 22f);
                SafeSetStat(interseting2.base_stats, S.attack_speed, 2f);
                SafeSetStat(interseting2.base_stats, S.damage, 300f);
                SafeSetStat(interseting2.base_stats, S.armor, 22f);
                SafeSetStat(interseting2.base_stats, S.stamina, 150f);
                interseting2.action_special_effect += (WorldAction)Delegate.Combine(interseting2.action_special_effect,
                    new WorldAction(traitAction.interseting30_effectAction));
                AssetManager.traits.add(interseting2);

                ActorTrait interseting3 = CreateTrait("interseting3", "trait/interseting3", "interseting");
                SafeSetStat(interseting3.base_stats, S.mana, 500f);
                SafeSetStat(interseting3.base_stats, S.lifespan, 500f);
                SafeSetStat(interseting3.base_stats, S.health, 5000f);
                SafeSetStat(interseting3.base_stats, S.speed, 33f);
                SafeSetStat(interseting3.base_stats, S.attack_speed, 3f);
                SafeSetStat(interseting3.base_stats, S.damage, 500f);
                SafeSetStat(interseting3.base_stats, S.armor, 33f);
                SafeSetStat(interseting3.base_stats, S.stamina,250f);
                interseting3.action_special_effect += (WorldAction)Delegate.Combine(interseting3.action_special_effect,
                    new WorldAction(traitAction.interseting50_effectAction));
                AssetManager.traits.add(interseting3);

                ActorTrait interseting4 = CreateTrait("interseting4", "trait/interseting4", "interseting");
                SafeSetStat(interseting4.base_stats, S.mana, 800f);
                SafeSetStat(interseting4.base_stats, S.lifespan, 1000f);
                SafeSetStat(interseting4.base_stats, S.health, 8000f);
                SafeSetStat(interseting4.base_stats, S.speed, 44f);
                SafeSetStat(interseting4.base_stats, S.attack_speed, 4f);
                SafeSetStat(interseting4.base_stats, S.damage, 800f);
                SafeSetStat(interseting4.base_stats, S.armor, 44f);
                SafeSetStat(interseting4.base_stats, S.stamina, 400f);
                interseting4.action_special_effect += (WorldAction)Delegate.Combine(interseting4.action_special_effect,
                    new WorldAction(traitAction.interseting80_effectAction));
                AssetManager.traits.add(interseting4);

                ActorTrait interseting5 = CreateTrait("interseting5", "trait/interseting5", "interseting");
                SafeSetStat(interseting5.base_stats, S.mana, 1000f);
                SafeSetStat(interseting5.base_stats, S.lifespan, 2000f);
                SafeSetStat(interseting5.base_stats, S.health, 10000f);
                SafeSetStat(interseting5.base_stats, S.speed, 55f);
                SafeSetStat(interseting5.base_stats, S.attack_speed, 5f);
                SafeSetStat(interseting5.base_stats, S.damage, 1000f);
                SafeSetStat(interseting5.base_stats, S.armor, 55f);
                SafeSetStat(interseting5.base_stats, S.stamina, 500f);
                interseting5.action_special_effect += (WorldAction)Delegate.Combine(interseting5.action_special_effect,
                    new WorldAction(traitAction.interseting100_effectAction));
                AssetManager.traits.add(interseting5);

                ActorTrait interseting6 = CreateTrait("interseting6", "trait/interseting6", "interseting");
                SafeSetStat(interseting6.base_stats, S.mana, 2000f);
                SafeSetStat(interseting6.base_stats, S.lifespan, 5000f);
                SafeSetStat(interseting6.base_stats, S.health, 20000f);
                SafeSetStat(interseting6.base_stats, S.speed, 66f);
                SafeSetStat(interseting6.base_stats, S.attack_speed, 6f);
                SafeSetStat(interseting6.base_stats, S.damage, 2000f);
                SafeSetStat(interseting6.base_stats, S.armor, 66f);
                SafeSetStat(interseting6.base_stats, S.stamina, 1000f);
                interseting6.action_special_effect += (WorldAction)Delegate.Combine(interseting6.action_special_effect,
                    new WorldAction(traitAction.interseting200_effectAction));
                AssetManager.traits.add(interseting6);

                ActorTrait interseting7 = CreateTrait("interseting7", "trait/interseting7", "interseting");
                SafeSetStat(interseting7.base_stats, S.mana, 3000f);
                SafeSetStat(interseting7.base_stats, S.lifespan, 10000f);
                SafeSetStat(interseting7.base_stats, S.health, 37500f);
                SafeSetStat(interseting7.base_stats, S.speed, 77f);
                SafeSetStat(interseting7.base_stats, S.attack_speed, 7f);
                SafeSetStat(interseting7.base_stats, S.damage, 3750f);
                SafeSetStat(interseting7.base_stats, S.armor, 77f);
                SafeSetStat(interseting7.base_stats, S.stamina, 1500f);
                interseting7.action_special_effect += (WorldAction)Delegate.Combine(interseting7.action_special_effect,
                    new WorldAction(traitAction.interseting300_effectAction));
                AssetManager.traits.add(interseting7);

                ActorTrait interseting8 = CreateTrait("interseting8", "trait/interseting8", "interseting");
                SafeSetStat(interseting8.base_stats, S.mana, 7777f);
                SafeSetStat(interseting8.base_stats, S.lifespan, 30000f);
                SafeSetStat(interseting8.base_stats, S.health, 75000f);
                SafeSetStat(interseting8.base_stats, S.speed, 88f);
                SafeSetStat(interseting8.base_stats, S.attack_speed, 8f);
                SafeSetStat(interseting8.base_stats, S.damage, 7500f);
                SafeSetStat(interseting8.base_stats, S.armor, 88f);
                SafeSetStat(interseting8.base_stats, S.stamina, 3888f);
                interseting8.action_special_effect += (WorldAction)Delegate.Combine(interseting8.action_special_effect,
                    new WorldAction(traitAction.interseting777_effectAction));
                AssetManager.traits.add(interseting8);

                ActorTrait interseting9 = CreateTrait("interseting9", "trait/interseting9", "interseting");
                SafeSetStat(interseting9.base_stats, S.mana, 10000f);
                SafeSetStat(interseting9.base_stats, S.lifespan, 50000f);
                SafeSetStat(interseting9.base_stats, S.health, 100000f);
                SafeSetStat(interseting9.base_stats, S.speed, 99f);
                SafeSetStat(interseting9.base_stats, S.attack_speed, 9f);
                SafeSetStat(interseting9.base_stats, S.damage, 10000f);
                SafeSetStat(interseting9.base_stats, S.armor, 99f);
                SafeSetStat(interseting9.base_stats, S.stamina, 8888f);
                interseting9.action_special_effect += (WorldAction)Delegate.Combine(interseting9.action_special_effect,
                    new WorldAction(traitAction.interseting1000_effectAction));
                AssetManager.traits.add(interseting9);

                ActorTrait interbook3 = CreateTrait("interbook3", "trait/interbook3", "interseting");
                SafeSetStat(interbook3.base_stats, S.mana, 100f);
                SafeSetStat(interbook3.base_stats, S.stamina, 50f);
                interbook3.action_special_effect += (WorldAction)Delegate.Combine(interbook3.action_special_effect,
                    new WorldAction(traitAction.interseting10_effectAction));
                AssetManager.traits.add(interbook3);

                ActorTrait interbook9 = CreateTrait("interbook9", "trait/interbook9", "interseting"); //稻草人
                SafeSetStat(interbook9.base_stats, S.lifespan, 999f);
                SafeSetStat(interbook9.base_stats, S.health, 9999f);
                SafeSetStat(interbook9.base_stats, S.speed, 99f);
                SafeSetStat(interbook9.base_stats, S.attack_speed, 9f);
                SafeSetStat(interbook9.base_stats, S.damage, 99f);
                SafeSetStat(interbook9.base_stats, S.armor, 99f);
                interbook9.action_special_effect += traitAction.brokenProof; //防火与防冻
                AssetManager.traits.add(interbook9);

                ActorTrait interbook1 = CreateTrait("interbook1", "trait/interbook1", "interseting"); //天命之王
                SafeSetStat(interbook1.base_stats, S.diplomacy, 10f);
                SafeSetStat(interbook1.base_stats, S.warfare, 20f);
                SafeSetStat(interbook1.base_stats, S.stewardship, 20f);
                SafeSetStat(interbook1.base_stats, S.cities, 20f);
                AssetManager.traits.add(interbook1);

                ActorTrait interbook2 = CreateTrait("interbook2", "trait/interbook2", "interseting"); //我要打十个！
                SafeSetStat(interbook2.base_stats, S.targets, 10f);
                interbook2.action_special_effect += traitAction.brokenProof; //防火与防冻
                AssetManager.traits.add(interbook2);

                ActorTrait Combskill1 = CreateTrait("Combskill1", "trait/Combskill1", "interseting"); //技法之心
                SafeSetStat(Combskill1.base_stats, S.stamina, 50f);
                Combskill1.action_special_effect = traitAction.brokenProof;
                AssetManager.traits.add(Combskill1);

                ActorTrait Combskill2 = CreateTrait("Combskill2", "trait/Combskill2", "interseting"); //生命之叶-百寿叶
                SafeSetStat(Combskill2.base_stats, S.stamina, 100f);
                SafeSetStat(Combskill2.base_stats, S.targets, 1f);
                SafeSetStat(Combskill2.base_stats, S.skill_combat, 0.1f);
                SafeSetStat(Combskill2.base_stats, S.health, 10f);
                SafeSetStat(Combskill2.base_stats, S.speed, 5f);
                SafeSetStat(Combskill2.base_stats, S.attack_speed, 1f);
                SafeSetStat(Combskill2.base_stats, S.damage, 10f);
                SafeSetStat(Combskill2.base_stats, S.armor, 5f);
                AssetManager.traits.add(Combskill2);

                ActorTrait Combskill3 = CreateTrait("Combskill3", "trait/Combskill3", "interseting"); //生命之叶-千寿叶
                SafeSetStat(Combskill3.base_stats, S.stamina, 150f);
                SafeSetStat(Combskill3.base_stats, S.targets, 2f);
                SafeSetStat(Combskill3.base_stats, S.skill_combat, 0.2f);
                SafeSetStat(Combskill3.base_stats, S.health, 50f);
                SafeSetStat(Combskill3.base_stats, S.speed, 10f);
                SafeSetStat(Combskill3.base_stats, S.attack_speed, 2f);
                SafeSetStat(Combskill3.base_stats, S.damage, 15f);
                SafeSetStat(Combskill3.base_stats, S.armor, 15f);
                AssetManager.traits.add(Combskill3);

                ActorTrait bomb0 = CreateTrait("bomb0", "trait/bomb0", "interseting"); //湮灭之力
                SafeSetStat(bomb0.base_stats, S.damage, 100f);
                SafeSetStat(bomb0.base_stats, S.critical_chance, 0.3f);
                bomb0.action_special_effect += traitAction.brokenProof; //湮灭之力的攻击效果
                AssetManager.traits.add(bomb0);

                ActorTrait bomb5 = CreateTrait("bomb5", "trait/bomb5", "interseting"); //大蘑菇云!
                SafeSetStat(bomb5.base_stats, S.damage, 100f);
                SafeSetStat(bomb5.base_stats, S.critical_chance, 0.3f);
                bomb5.action_special_effect += traitAction.brokenProof; //大蘑菇云的攻击效果
                AssetManager.traits.add(bomb5);

                ActorTrait bomb6 = CreateTrait("bomb6", "trait/bomb6", "interseting"); //流星坠落
                SafeSetStat(bomb6.base_stats, S.damage, 100f);
                SafeSetStat(bomb6.base_stats, S.critical_chance, 0.3f);
                bomb6.action_special_effect += traitAction.brokenProof; //流星坠落的攻击效果
                AssetManager.traits.add(bomb6);

                ActorTrait bomb7 = CreateTrait("bomb7", "trait/bomb7", "interseting"); //烈燚冲击
                SafeSetStat(bomb7.base_stats, S.damage, 100f);
                SafeSetStat(bomb7.base_stats, S.critical_chance, 0.3f);
                bomb7.action_special_effect += traitAction.brokenProof; //烈燚冲击的攻击效果
                AssetManager.traits.add(bomb7);

                ActorTrait element2 = CreateTrait("element2", "trait/element2", "interseting");//炽焰旅者
                SafeSetStat(element2.base_stats, S.damage, 100f);
                SafeSetStat(element2.base_stats, S.range, 10f);
                SafeSetStat(element2.base_stats, S.area_of_effect, 25f);
                SafeSetStat(element2.base_stats, S.targets, 15f);
                element2.action_special_effect += traitAction.brokenProof; 
                AssetManager.traits.add(element2);

                ActorTrait element5 = CreateTrait("element5", "trait/element5", "interseting"); //霜月行者
                SafeSetStat(element5.base_stats, S.damage, 80f);
                SafeSetStat(element5.base_stats, S.range, 8f);
                SafeSetStat(element5.base_stats, S.area_of_effect, 20f);
                SafeSetStat(element5.base_stats, S.targets, 12f);
                element5.action_special_effect += traitAction.brokenProof; 
                AssetManager.traits.add(element5);

                ActorTrait element6 = CreateTrait("element6", "trait/element6", "interseting"); //天罡雷使
                SafeSetStat(element6.base_stats, S.damage, 60f);
                SafeSetStat(element6.base_stats, S.range, 6f);
                SafeSetStat(element6.base_stats, S.area_of_effect, 15f);
                SafeSetStat(element6.base_stats, S.targets, 9f);
                element6.action_special_effect += traitAction.brokenProof; 
                AssetManager.traits.add(element6);

                ActorTrait element8 = CreateTrait("element8", "trait/element8", "interseting"); //原力者
                SafeSetStat(element8.base_stats, S.damage, 20f);
                SafeSetStat(element8.base_stats, S.range, 2f);
                SafeSetStat(element8.base_stats, S.area_of_effect, 5f);
                SafeSetStat(element8.base_stats, S.targets, 3f);
                element8.action_special_effect += traitAction.brokenProof; 
                AssetManager.traits.add(element8);

                ActorTrait bomb8 = CreateTrait("bomb8", "trait/bomb8", "interseting"); //不朽不灭
                SafeSetStat(bomb8.base_stats, S.damage, 100f);
                SafeSetStat(bomb8.base_stats, S.critical_chance, 0.3f);
                bomb8.action_special_effect += traitAction.brokenProof;
                AssetManager.traits.add(bomb8);

                ActorTrait bomb9 = CreateTrait("bomb9", "trait/bomb9", "interseting"); //不灭之心
                SafeSetStat(bomb9.base_stats, S.damage, 100f);
                SafeSetStat(bomb9.base_stats, S.critical_chance, 0.3f);
                bomb9.action_special_effect += traitAction.brokenProof;
                AssetManager.traits.add(bomb9);

                ActorTrait element7 = CreateTrait("element7", "trait/element7", "interseting"); //一条命
                SafeSetStat(element7.base_stats, S.damage, 40f);
                SafeSetStat(element7.base_stats, S.range, 4f);
                SafeSetStat(element7.base_stats, S.area_of_effect, 10f);
                SafeSetStat(element7.base_stats, S.targets, 6f);
                element7.action_special_effect += traitAction.brokenProof; 
                AssetManager.traits.add(element7);

                ActorTrait Combskill4 = CreateTrait("Combskill4", "trait/Combskill4", "interseting"); //以身化众（一级）
                SafeSetStat(Combskill4.base_stats, S.stamina, 350f);
                SafeSetStat(Combskill4.base_stats, S.targets, 3f);
                SafeSetStat(Combskill4.base_stats, S.skill_combat, 0.3f);
                SafeSetStat(Combskill4.base_stats, S.critical_chance, 0.1f);
                SafeSetStat(Combskill4.base_stats, S.health, 100f);
                SafeSetStat(Combskill4.base_stats, S.speed, 30f);
                SafeSetStat(Combskill4.base_stats, S.attack_speed, 4f);
                SafeSetStat(Combskill4.base_stats, S.damage, 30f);
                SafeSetStat(Combskill4.base_stats, S.armor, 30f);
                AssetManager.traits.add(Combskill4);

                ActorTrait Combskill5 = CreateTrait("Combskill5", "trait/Combskill5", "interseting"); //以身化众（二级）
                SafeSetStat(Combskill5.base_stats, S.stamina, 450f);
                SafeSetStat(Combskill5.base_stats, S.targets, 7f);
                SafeSetStat(Combskill5.base_stats, S.skill_combat, 0.4f);
                SafeSetStat(Combskill5.base_stats, S.critical_chance, 0.2f);
                SafeSetStat(Combskill5.base_stats, S.health, 150f);
                SafeSetStat(Combskill5.base_stats, S.speed, 30f);
                SafeSetStat(Combskill5.base_stats, S.attack_speed, 6f);
                SafeSetStat(Combskill5.base_stats, S.damage, 50f);
                SafeSetStat(Combskill5.base_stats, S.armor, 50f);
                AssetManager.traits.add(Combskill5);

                ActorTrait Combskill6 = CreateTrait("Combskill6", "trait/Combskill6", "interseting"); //以身化众（三级）
                SafeSetStat(Combskill6.base_stats, S.stamina, 850f);
                SafeSetStat(Combskill6.base_stats, S.targets, 9f);
                SafeSetStat(Combskill6.base_stats, S.skill_combat, 0.5f);
                SafeSetStat(Combskill6.base_stats, S.critical_chance, 0.4f);
                SafeSetStat(Combskill6.base_stats, S.health, 250f);
                SafeSetStat(Combskill6.base_stats, S.speed, 50f);
                SafeSetStat(Combskill6.base_stats, S.attack_speed, 9f);
                SafeSetStat(Combskill6.base_stats, S.damage, 100f);
                SafeSetStat(Combskill6.base_stats, S.armor, 70f);
                AssetManager.traits.add(Combskill6);

                ActorTrait element9 = CreateTrait("element9", "trait/element9", "interseting"); //众身之一
                SafeSetStat(element9.base_stats, S.damage, 200f);
                SafeSetStat(element9.base_stats, S.range, 20f);
                SafeSetStat(element9.base_stats, S.area_of_effect, 50f);
                SafeSetStat(element9.base_stats, S.targets, 30f);
                element9.action_special_effect = traitAction.brokenProof;
                AssetManager.traits.add(element9);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Error in traits initialization: {ex.Message}");
            }
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            try 
            {
                if (baseStats == null)
                {
                    UnityEngine.Debug.LogError($"BaseStats is null when trying to set {statKey}");
                    return;
                }
                Type baseStatsType = baseStats.GetType();
                var method = baseStatsType.GetMethod("set_Item", 
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.NonPublic);
                
                if (method != null)
                {
                    method.Invoke(baseStats, new object[] { statKey, value });
                }
                else 
                {
                    var field = baseStatsType.GetField("_stats", BindingFlags.NonPublic | BindingFlags.Instance);
                    if (field != null)
                    {
                        var dict = field.GetValue(baseStats) as Dictionary<string, float>;
                        if (dict != null)
                        {
                            dict[statKey] = value;
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError($"Could not find method or field to set {statKey}");
                    }
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError($"Error setting stat {statKey}: {ex.Message}");
            }
        }
    }
}