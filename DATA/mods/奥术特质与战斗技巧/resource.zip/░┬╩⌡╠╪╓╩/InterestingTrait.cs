﻿using HarmonyLib;

using ArcaneTrait.code;

using NeoModLoader.api;

namespace ArcaneTrait
{
    internal class ArcaneTraitClass : BasicMod<ArcaneTraitClass>
    {
        public static string id = "shiyue.worldbox.mod.Arcanetrait";
        protected override void OnModLoad()
        {
            traitGroup.Init();
            traits.Init();
        }

    }

}
