using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;

namespace A

{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
            human_settlers.init();
        }
    }
}
