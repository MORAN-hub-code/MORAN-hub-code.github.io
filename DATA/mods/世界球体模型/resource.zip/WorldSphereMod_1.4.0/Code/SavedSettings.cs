﻿using System;
namespace WorldSphereMod
{
    [Serializable]
    public class SavedSettings
    {
        public string Version = "1.3";
        public bool Is3D = true;
        public bool InvertedCameraMovement = true;
        public bool RotateStuffToCamera = true;
        public bool RotateStuffToCameraAdvanced = true;
        public bool CameraRotatesWithWorld = true;
        public bool FirstPerson = true;
        public float RenderRange = 2;
        public float TileHeight = 1;
        public float BuildingSize = 0.5f;
        public int CurrentShape = 1;
    }
}
