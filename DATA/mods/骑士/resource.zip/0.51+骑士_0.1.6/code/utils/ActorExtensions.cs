using System;
using System.Collections.Generic;
using UnityEngine;

namespace ChivalryWizardingWorld.code.utils
{
    public static class ActorExtensions
    {
        private const string title_guid_key = "attribute.title_guid";
        public static float GetKnight(this Actor actor)
        {
            return actor.data["Knight"];
        }

        public static void ChangeKnight(this Actor actor, float value)
        {
            actor.data["Knight"] += value;
        }

        public static void SetKnight(this Actor actor, float value)
        {
            actor.data["Knight"] = value;
        }
        // 头衔管理扩展方法
        public static string GetTitle(this Actor actor, string title_guid)
        {
            actor.data.get(title_guid, out string title, "头衔");
            return title;
        }

        public static List<string> GetTitleGuids(this Actor actor)
        {
            actor.data.get(title_guid_key, out string title_guids_str);
            if (string.IsNullOrEmpty(title_guids_str))
            {
                return new List<string>();
            }
            return new List<string>(title_guids_str.Split(','));
        }

        public static void AddTitleGuid(this Actor actor, string title_guid)
        {
            var title_guids = actor.GetTitleGuids();
            if (!title_guids.Contains(title_guid))
            {
                title_guids.Add(title_guid);
                actor.data.set(title_guid_key, string.Join(",", title_guids));
            }
        }

        public static void RemoveTitleGuid(this Actor actor, string title_guid)
        {
            var title_guids = actor.GetTitleGuids();
            if (title_guids.Contains(title_guid))
            {
                title_guids.Remove(title_guid);
                actor.data.set(title_guid_key, string.Join(",", title_guids));
            }
        }
        
        // 设置头衔的方法
        public static void SetTitle(this Actor actor, string title_guid, string title_text, Color title_color)
        {
            actor.data.set(title_guid, title_text);
            actor.AddTitleGuid(title_guid);
            string colorHex = ColorUtility.ToHtmlStringRGBA(title_color);
            actor.data.set("attribute.title_color_" + title_guid, colorHex);
        }
        
        // 骑士血脉头衔管理方法
        public static void SetClanTalentTitle(this Actor actor, string clanTalentId)
        {
            switch (clanTalentId)
            {
                case "ClanTalent1": // 骑士血脉·初誓
                    SetTitle(actor, "clantalent1_title", "骑士血脉·初誓", new Color(0.5f, 1f, 0.5f, 1f)); //#80FF80
                    break;
                case "ClanTalent2": // 骑士血脉·铁徽
                    SetTitle(actor, "clantalent2_title", "骑士血脉·铁徽", new Color(0.2f, 0.8f, 0.2f, 1f)); //#33CC33
                    break;
                case "ClanTalent3": // 骑士血脉·战痕
                    SetTitle(actor, "clantalent3_title", "骑士血脉·战痕", new Color(0f, 0.6f, 0f, 1f)); //#009900
                    break;
            }
        }
    }
}