using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChivalryWizardingWorld.code.Config
{
    public class KnightConfig
    {
        /// <summary>
        /// 是否启用自动收藏功能
        public static bool EnableAutoFavorite { get; set; } = false;
        
        /// <summary>
        /// 天赋随机概率（默认0.3 = 30%）
        public static float TalentRandomChance { get; set; } = 0.3f;
        
        /// <summary>
        /// talent1权重（默认617）
        public static float Talent1Weight { get; set; } = 617f;
        
        /// <summary>
        /// talent2权重（默认300）
        public static float Talent2Weight { get; set; } = 300f;
        
        /// <summary>
        /// talent3权重（默认80）
        public static float Talent3Weight { get; set; } = 80f;
        
        /// <summary>
        /// talent4权重（默认3）
        public static float Talent4Weight { get; set; } = 3f;
        
        /// <summary>
        /// 自动收藏功能开关回调
        /// <param name="pCurrentValue">当前值</param>
        public static void AutoFavoriteEnableSwitchConfigCallBack(bool pCurrentValue)
        {
            EnableAutoFavorite = pCurrentValue;
        }
        
        /// <summary>
        /// 天赋随机概率配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void TalentRandomChanceConfigCallBack(float pCurrentValue)
        {
            TalentRandomChance = pCurrentValue;
        }
        
        /// <summary>
        /// talent1权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void Talent1WeightConfigCallBack(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Talent1Weight = 617f;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Talent1Weight = value;
            }
        }
        
        /// <summary>
        /// talent2权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void Talent2WeightConfigCallBack(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Talent2Weight = 300f;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Talent2Weight = value;
            }
        }
        
        /// <summary>
        /// talent3权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void Talent3WeightConfigCallBack(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Talent3Weight = 80f;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Talent3Weight = value;
            }
        }
        
        /// <summary>
        /// talent4权重配置回调
        /// <param name="pCurrentValue">当前值</param>
        public static void Talent4WeightConfigCallBack(string pCurrentValue)
        {
            if (string.IsNullOrEmpty(pCurrentValue))
            {
                // 如果输入为空，则使用默认值
                Talent4Weight = 3f;
            }
            else if (float.TryParse(pCurrentValue, out float value))
            {
                Talent4Weight = value;
            }
        }
    }
}