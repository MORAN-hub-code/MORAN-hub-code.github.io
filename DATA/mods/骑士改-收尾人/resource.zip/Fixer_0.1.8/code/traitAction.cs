﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool TrueDamage1_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;

                // 获取攻击者的攻击力
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.1f); 

                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.05f);
            }
            return false;
        }
        public static bool TrueDamage2_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.2f); 

                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.16f); 
            }
            return false;
        }
        public static bool TrueDamage3_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.3f); 

                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.32f); 
            }
            return false;
        }
        public static bool TrueDamage4_AttackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.4f); 

                if (targetActor.data.health > trueDamage)
                {
                    targetActor.restoreHealth(-trueDamage);
                }
                // 可以添加一些视觉效果，例如粒子效果
                MapBox.spawnLightningMedium(pTile, 0.64f); 
            }
            return false;
        }
        public static bool Fixer1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.学徒骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Fixer2", "Fixer3", "Fixer4", "Fixer5", "Fixer6","Fixer7", "Fixer8", "Fixer9"};
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Fixer1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );

            return true;
        }

        public static bool Fixer2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetFixer() <= 9.99)
            {
                return false;
            }

            a.ChangeFixer(-2);
            double successRate = 0.8;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Fixer1",
                "Fixer2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Fixer22" }
            );

            return true;
        }

        public static bool Fixer3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 17.99)
            {
                return false;
            }

            a.ChangeFixer(-2);
            double successRate = 0.6;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Fixer2",
                "Fixer3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Fixer22"
                },
                new string[] { "Fixer3+", selectedTrait }
            );

            return true;
        }

        public static bool Fixer4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.中级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 31.99)
            {
                return false;
            }

            a.ChangeFixer(-3);
            double successRate = 0.6;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Fixer3",
                "Fixer4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Fixer3+"
                },
                new string[] { "Fixer4+" }
            );

            return true;
        }

        public static bool Fixer5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.高骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 52.99)
            {
                return false;
            }

            a.ChangeFixer(-4);
            double successRate = 0.6;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Fixer4",
                "Fixer5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Fixer4+"
                }, 
                new string[] { "Fixer5+", "freeze_proof", "fire_proof" }
            );

            return true;
        }

        public static bool Fixer6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 67.99)
            {
                return false;
            }

            a.ChangeFixer(-5);
            double successRate = 0.1;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.4;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            a.data.favorite = true;
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }

            string actorName = a.getName();
            bool hasTitle = _FixerTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _FixerTitles.Length);
                string selectedTitle = _FixerTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Fixer5",
                "Fixer6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Fixer5+"
                },
                new string[] { "Fixer6+" }
            );

            return true;
        }

        public static bool Fixer7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 149.99)
            {
                return false;
            }

            a.ChangeFixer(-6);
            double successRate = 0.1;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.3;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Fixer6",
                "Fixer7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Fixer6+" },
                new string[] { "Fixer7+", "tough" }
            );

            return true;
        }

        public static bool Fixer8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 299.99)
            {
                return false;
            }

            a.ChangeFixer(-9);
            double successRate = 0.08;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.1;
            }

            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.25;
            }


            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Fixer7",
                "Fixer8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Fixer7+" },
                new string[] { "Fixer8+", "strong_minded", "immune" }
            );

            return true;
        }

        public static bool Fixer9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) 
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetFixer() <= 499.99)
            {
                return false;
            }

            a.ChangeFixer(-15);
            double successRate = 0.08;
            if (a.hasTrait("gifted1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("gifted2"))
            {
                successRate = 0.1;
            }
            else if (a.hasTrait("gifted3"))
            {
                successRate = 0.15;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            string actorName = a.getName();
            bool hasTitle = _FixerTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _FixerTitles.Length);
                string selectedTitle = _FixerTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Fixer8",
                "Fixer9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Fixer8+" },
                new string[] { "Fixer9+" ,"fire_proof", "regeneration"}
            );

            return true;
        }

        public static bool Fixer91_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.level > 63)
            {
                a.data.favorite = true;// 取消收藏（移除favorite状态）
                upTrait("特质", "Fixcolor", a, new string[] { "Fixer9+" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            return true;
        }
        private static readonly string[] _FixerTitles = { "「殷红迷雾」", "「堇紫泪滴」", "「苍蓝残响」", "「朱红十字」", "「冬红布袋」", "「靛蓝老者」", "「缃碧少女」"
, "「蔚蓝天堂」", "「白月骑士」", "「银红凝视」", "「绯红之冠」", "「赤色黎明」", "「黑桃魅影」", "「粉红军备」", "「闪金冲锋」", "「黑天鹅之梦」", "「余香」", "「伪善」"
, "「白天鹅之翼」", "「数据删除」", "「黑弥撒」", "「穿刺乐园」", "「绯红安魂曲」", "「黑铁摇篮曲」", "「染血鸢尾」", "「泣铁蔷薇」", "「青铜挽歌」", "「赤红飓风」"
, "「绿色枝干」", "「新星之声」", "「郁蓝创痕」", "「猩红创痕」", "「决死之心」", "「秘银壁垒」", "「盈泪之剑」", "「寒铁龙骑」", "「碧落剑圣」", "「爱与憎之名」"
, "「正义裁决者」", "「破晓追猎者」" , "「铁幕游侠」", "「次元撕裂者」" , "「黑骑士」", "「荣耀之羽」", "「曙光长枪」" , "「慈悲坚盾」", "「品红妖姬」", "「晨曦之剑」"
, "「影舞之刃」", "「苍穹游侠」" , "「拟态」", "「薄暝」", "「爱慕」", "「落樱」", "「返始」", "「沉醉」", "「不落残阳」", "「夜枭巡礼」", "「焦土漫游者」", "「不和」"
, "「伪善」", "「月光」", "「渴望」", "「狐雨」", "「深渊之物」", "「失乐园」", "「一无所有」", "「噬梦的浊流」", "「消逝之日」", "「指定审判」", "「荆棘花园」", "「白色骑士」"
, "「蓝骑」", "「红骑」", "「紫骑」", "「灰骑」" , "「胜利号角」", "「雾港摆渡人」", "「庄严哀悼」", "「灰眸裁罚者」", "「锈链仲裁者」", "「梦中的洋流」", "「雾银裁缝」"
, "「表象放出仪」", "「污血泣泪」", "「他人之锁」", "「荆棘花园」", "「黑玫瑰」", "「忏悔」", "「碎铠者」", "「默誓者」", "「燧心」", "「双刃」", "「暮钟」"
, "「渴望」", "「圣灰诵者」", "「影语者」" , "「血纹师」", "「无量」", "「黄蜂」", "「烬心」", "「轻蔑」", "「敬畏」", "「笑魇」", "「朱符」", "「赤瞳」", "「希望」"
, "「盲目」", "「晨星」", "「晨辉」" };

        //骑士的恢复生命值效果
        public static bool Fixer1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Fixer9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
