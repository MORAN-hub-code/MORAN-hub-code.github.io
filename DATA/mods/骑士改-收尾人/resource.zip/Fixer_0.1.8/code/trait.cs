﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();
            
            return trait;
        }
        private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
        public static ActorTrait gifted_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait gifted = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "Egolight",
                needs_to_be_explored = false
            };
            gifted.action_special_effect += traitAction.Fixer1_effectAction;
            AssetManager.traits.add(gifted);
            return gifted;
        }
        public static bool ClanGiftedMethod(BaseSimObject pTarget, WorldTile pTile = null, int minGiftedLevel = 1)
        {
            if (!(pTarget is Actor actor)) return false;
            
            float age = actor.getAge();
            if (Mathf.FloorToInt(age) != 9) return true;
            
            // 定义需要检查的特质列表
            string[] traitsToCheck = 
            {
                "gifted1", "gifted2", "gifted3", "gifted4",
                "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7"
            };
            
            // 使用 Any 方法高效检查是否存在任一特质
            if (traitsToCheck.Any(actor.hasTrait)) return true;
            
            // 定义天赋权重
            var giftedWeights = new List<(string traitId, int weight)>();
            if (minGiftedLevel <= 1) giftedWeights.Add(("gifted1", 604));
            if (minGiftedLevel <= 2) giftedWeights.Add(("gifted2", 300));
            if (minGiftedLevel <= 3) giftedWeights.Add(("gifted3", 90));
            if (minGiftedLevel <= 4) giftedWeights.Add(("gifted4", 6));
            
            if (giftedWeights.Count == 0) return true;
            
            // 计算总权重并随机选择
            int totalWeight = giftedWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);
            
            foreach (var gifted in giftedWeights)
            {
                if (randomValue < gifted.weight)
                {
                    actor.addTrait(gifted.traitId, false);
                    break;
                }
                randomValue -= gifted.weight;
            }
            
            return true;
        }
        public static void Init()
        {
            _ = gifted_AddActorTrait("gifted1", "trait/gifted1");//骑士天赋•下
            _ = gifted_AddActorTrait("gifted2", "trait/gifted2");//骑士天赋•中
            _ = gifted_AddActorTrait("gifted3", "trait/gifted3");//骑士天赋•上
            _ = gifted_AddActorTrait("gifted4", "trait/gifted4");//骑士天赋•完美

            // 定义氏族特质配置（包含图标路径）
            var clanTraits = new List<(string id, string iconPath, int minLevel)>
            {
                ("ClanGifted1", "trait/gifted1", 1),
                ("ClanGifted2", "trait/gifted2", 2),
                ("ClanGifted3", "trait/gifted3", 3)
            };

            // 批量创建并添加氏族特质
            foreach (var (id, iconPath, minLevel) in clanTraits)
            {
                ClanTrait clanTrait = CclanTrait(
                    id: id,
                    path_icon: iconPath, // 使用指定的图标路径
                    group_id: "spirit"
                );
                
                clanTrait.action_special_effect += (target, tile) => 
                    ClanGiftedMethod(target, tile, minLevel);
                
                AssetManager.clan_traits.add(clanTrait);
            }

            ActorTrait gifted5 = CreateTrait("gifted5", "trait/gifted5", "Egolight");
            gifted5.rate_inherit = 100;
            AssetManager.traits.add(gifted5);

            ActorTrait gifted6 = CreateTrait("gifted6", "trait/gifted6", "Egolight");
            AssetManager.traits.add(gifted6);

            ActorTrait gifted7 = CreateTrait("gifted7", "trait/gifted7", "Egolight");
            AssetManager.traits.add(gifted7);

            ActorTrait gifted8 = CreateTrait("gifted8", "trait/gifted8", "Egolight");
            AssetManager.traits.add(gifted8);

            ActorTrait gifted9 = CreateTrait("gifted9", "trait/gifted9", "Egolight");
            AssetManager.traits.add(gifted9);

            ActorTrait fixer02 = CreateTrait("Fixer22", "trait/Fixer2+", "Fixer");
            SafeSetStat(fixer02.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(fixer02.base_stats, strings.S.skill_combat, 0.1f);
            SafeSetStat(fixer02.base_stats, strings.S.accuracy, 1f);
            AssetManager.traits.add(fixer02);

            ActorTrait fixer03 = CreateTrait("Fixer3+", "trait/fixer3+", "Fixer");
            SafeSetStat(fixer03.base_stats, strings.S.lifespan, 20f);
            SafeSetStat(fixer03.base_stats, strings.S.skill_combat, 0.2f);
            SafeSetStat(fixer03.base_stats, strings.S.accuracy, 3f);
            AssetManager.traits.add(fixer03);

            ActorTrait Fixer04 = CreateTrait("Fixer4+", "trait/Fixer4+", "Fixer");
            SafeSetStat(Fixer04.base_stats, strings.S.lifespan, 25f);
            SafeSetStat(Fixer04.base_stats, strings.S.skill_combat, 0.3f);
            SafeSetStat(Fixer04.base_stats, strings.S.accuracy, 5f);
            SafeSetStat(Fixer04.base_stats, strings.S.knockback, 1f);
            AssetManager.traits.add(Fixer04);

            ActorTrait Fixer05 = CreateTrait("Fixer5+", "trait/Fixer5+", "Fixer");
            SafeSetStat(Fixer05.base_stats, strings.S.warfare, 7f);
            SafeSetStat(Fixer05.base_stats, strings.S.lifespan, 30f);
            SafeSetStat(Fixer05.base_stats, strings.S.skill_combat, 0.4f);
            SafeSetStat(Fixer05.base_stats, strings.S.accuracy, 10f);
            SafeSetStat(Fixer05.base_stats, strings.S.critical_chance, 0.1f);
            SafeSetStat(Fixer05.base_stats, strings.S.knockback, 1f);
            SafeSetStat(Fixer05.base_stats, "Resist", 1f);
            AssetManager.traits.add(Fixer05);

            ActorTrait Fixer06 = CreateTrait("Fixer6+", "trait/Fixer6+", "Fixer");
            SafeSetStat(Fixer06.base_stats, strings.S.warfare, 15f);
            SafeSetStat(Fixer06.base_stats, strings.S.lifespan, 60f);
            SafeSetStat(Fixer06.base_stats, strings.S.skill_combat, 0.5f);
            SafeSetStat(Fixer06.base_stats, strings.S.accuracy, 15f);
            SafeSetStat(Fixer06.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(Fixer06.base_stats, strings.S.knockback, 2f);
            SafeSetStat(Fixer06.base_stats, "Resist", 2f);
            AssetManager.traits.add(Fixer06);

            ActorTrait Fixer07 = CreateTrait("Fixer7+", "trait/Fixer7+", "Fixer");
            SafeSetStat(Fixer07.base_stats, strings.S.warfare, 30f);
            SafeSetStat(Fixer07.base_stats, strings.S.lifespan, 75f);
            SafeSetStat(Fixer07.base_stats, strings.S.skill_combat, 0.6f);
            SafeSetStat(Fixer07.base_stats, strings.S.accuracy, 18f);
            SafeSetStat(Fixer07.base_stats, strings.S.critical_chance, 0.4f);
            SafeSetStat(Fixer07.base_stats, strings.S.knockback, 3f);
            SafeSetStat(Fixer07.base_stats, "Resist", 3f);
            AssetManager.traits.add(Fixer07);

            ActorTrait Fixer08 = CreateTrait("Fixer8+", "trait/Fixer8+", "Fixer");
            SafeSetStat(Fixer08.base_stats, strings.S.warfare, 45f);
            SafeSetStat(Fixer08.base_stats, strings.S.lifespan, 90f);
            SafeSetStat(Fixer08.base_stats, strings.S.skill_combat, 0.7f);
            SafeSetStat(Fixer08.base_stats, strings.S.accuracy, 25f);
            SafeSetStat(Fixer08.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(Fixer08.base_stats, strings.S.knockback, 5f);
            SafeSetStat(Fixer08.base_stats, "Resist", 5f);
            AssetManager.traits.add(Fixer08);

            ActorTrait Fixer09 = CreateTrait("Fixer9+", "trait/Fixer9+", "Fixer");
            SafeSetStat(Fixer09.base_stats, strings.S.warfare, 90f);
            SafeSetStat(Fixer09.base_stats, strings.S.lifespan, 120f);
            SafeSetStat(Fixer09.base_stats, strings.S.skill_combat, 0.8f);
            SafeSetStat(Fixer09.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(Fixer09.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(Fixer09.base_stats, strings.S.knockback, 9f);
            SafeSetStat(Fixer09.base_stats, "Resist", 9f);
            AssetManager.traits.add(Fixer09);

            ActorTrait Fixcolor = CreateTrait("Fixcolor", "trait/Fixcolor", "Fixer");
            SafeSetStat(Fixcolor.base_stats, strings.S.warfare, 150f);
            SafeSetStat(Fixcolor.base_stats, strings.S.lifespan, 150f);
            SafeSetStat(Fixcolor.base_stats, strings.S.skill_combat, 0.9f);
            SafeSetStat(Fixcolor.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(Fixcolor.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(Fixcolor.base_stats, strings.S.multiplier_damage, 3f);
            SafeSetStat(Fixcolor.base_stats, strings.S.multiplier_health, 3f);
            SafeSetStat(Fixcolor.base_stats, strings.S.knockback, 15f);
            SafeSetStat(Fixcolor.base_stats, "Resist", 15f);
            AssetManager.traits.add(Fixcolor);

            ActorTrait Fixer1 = CreateTrait("Fixer1", "trait/Fixer1", "Fixer");
            SafeSetStat(Fixer1.base_stats, "Resist", 1.0f);
            SafeSetStat(Fixer1.base_stats, strings.S.damage, 60f);
            SafeSetStat(Fixer1.base_stats, strings.S.targets, 5.0f);
            SafeSetStat(Fixer1.base_stats, strings.S.health, 200f);
            SafeSetStat(Fixer1.base_stats, strings.S.stamina, 10f);
            SafeSetStat(Fixer1.base_stats, "Dodge", 120f);
            SafeSetStat(Fixer1.base_stats, "Accuracy", 110f);
            Fixer1.action_special_effect += traitAction.Fixer2_effectAction;
            Fixer1.action_special_effect += traitAction.Fixer1_Regen;
            AssetManager.traits.add(Fixer1);

            ActorTrait Fixer2 = CreateTrait("Fixer2", "trait/Fixer2", "Fixer");
            SafeSetStat(Fixer2.base_stats, "Resist", 1.0f);
            SafeSetStat(Fixer2.base_stats, strings.S.damage, 120f);
            SafeSetStat(Fixer2.base_stats, strings.S.targets, 10f);
            SafeSetStat(Fixer2.base_stats, strings.S.health, 400f);
            SafeSetStat(Fixer2.base_stats, strings.S.accuracy, 2f);
            SafeSetStat(Fixer2.base_stats, strings.S.multiplier_speed, 0.1f);
            SafeSetStat(Fixer2.base_stats, strings.S.stamina, 20f);
            SafeSetStat(Fixer2.base_stats, "Dodge", 130f);
            SafeSetStat(Fixer2.base_stats, "Accuracy", 110f);
            Fixer2.action_special_effect += traitAction.Fixer3_effectAction;
            Fixer2.action_special_effect += traitAction.Fixer2_Regen;
            AssetManager.traits.add(Fixer2);

            ActorTrait Fixer3 = CreateTrait("Fixer3", "trait/Fixer3", "Fixer");
            SafeSetStat(Fixer3.base_stats, "Resist", 2.0f);
            SafeSetStat(Fixer3.base_stats, strings.S.damage, 240f);
            SafeSetStat(Fixer3.base_stats, strings.S.targets, 10f);
            SafeSetStat(Fixer3.base_stats, strings.S.health, 800f);
            SafeSetStat(Fixer3.base_stats, strings.S.armor, 5f);
            SafeSetStat(Fixer3.base_stats, strings.S.targets, 0.1f);
            SafeSetStat(Fixer3.base_stats, strings.S.accuracy, 5f);
            SafeSetStat(Fixer3.base_stats, strings.S.multiplier_speed, 0.2f);
            SafeSetStat(Fixer3.base_stats, strings.S.stamina, 30f);
            SafeSetStat(Fixer3.base_stats, "Dodge", 140f);
            SafeSetStat(Fixer3.base_stats, "Accuracy", 110f);
            Fixer3.action_special_effect += traitAction.Fixer4_effectAction;
            Fixer3.action_special_effect += traitAction.Fixer3_Regen;
            AssetManager.traits.add(Fixer3);

            ActorTrait Fixer4 = CreateTrait("Fixer4", "trait/Fixer4", "Fixer");
            SafeSetStat(Fixer4.base_stats, "Resist", 4.0f);
            SafeSetStat(Fixer4.base_stats, strings.S.damage, 300f);
            SafeSetStat(Fixer4.base_stats, strings.S.targets, 10f);
            SafeSetStat(Fixer4.base_stats, strings.S.health, 1600f);
            SafeSetStat(Fixer4.base_stats, strings.S.speed, 5f);
            SafeSetStat(Fixer4.base_stats, strings.S.armor, 10f);
            SafeSetStat(Fixer4.base_stats, strings.S.area_of_effect, 1f);
            SafeSetStat(Fixer4.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(Fixer4.base_stats, strings.S.accuracy, 10f);
            SafeSetStat(Fixer4.base_stats, strings.S.multiplier_speed, 0.3f);
            SafeSetStat(Fixer4.base_stats, strings.S.stamina, 40f);
            SafeSetStat(Fixer4.base_stats, "Dodge", 150f);
            SafeSetStat(Fixer4.base_stats, "Accuracy", 110f);
            Fixer4.action_special_effect += traitAction.Fixer5_effectAction;
            Fixer4.action_special_effect += traitAction.Fixer4_Regen;
            AssetManager.traits.add(Fixer4);

            ActorTrait Fixer5 = CreateTrait("Fixer5", "trait/Fixer5", "Fixer");
            SafeSetStat(Fixer5.base_stats, "Resist", 8.0f);
            SafeSetStat(Fixer5.base_stats, strings.S.warfare, 10f);
            SafeSetStat(Fixer5.base_stats, strings.S.targets, 15f);
            SafeSetStat(Fixer5.base_stats, strings.S.damage, 600f);
            SafeSetStat(Fixer5.base_stats, strings.S.health, 3200f);
            SafeSetStat(Fixer5.base_stats, strings.S.speed, 10f);
            SafeSetStat(Fixer5.base_stats, strings.S.armor, 15f);
            SafeSetStat(Fixer5.base_stats, strings.S.area_of_effect, 2f);
            SafeSetStat(Fixer5.base_stats, strings.S.critical_chance, 0.3f);
            SafeSetStat(Fixer5.base_stats, strings.S.accuracy, 20f);
            SafeSetStat(Fixer5.base_stats, strings.S.multiplier_speed, 0.4f);
            SafeSetStat(Fixer5.base_stats, strings.S.stamina, 50f);
            SafeSetStat(Fixer5.base_stats, "Dodge", 180f);
            SafeSetStat(Fixer5.base_stats, "Accuracy", 140f);
            Fixer5.action_special_effect += traitAction.Fixer6_effectAction;
            Fixer5.action_special_effect += traitAction.Fixer5_Regen;
            AssetManager.traits.add(Fixer5);

            ActorTrait Fixer6 = CreateTrait("Fixer6", "trait/Fixer6", "Fixer");
            Fixer6.rarity = Rarity.R2_Epic;
            SafeSetStat(Fixer6.base_stats, "Resist", 16.0f);
            SafeSetStat(Fixer6.base_stats, strings.S.warfare, 20f);
            SafeSetStat(Fixer6.base_stats, strings.S.targets, 20f);
            SafeSetStat(Fixer6.base_stats, strings.S.damage, 1200f);
            SafeSetStat(Fixer6.base_stats, strings.S.armor, 25f);
            SafeSetStat(Fixer6.base_stats, strings.S.health, 6400f);
            SafeSetStat(Fixer6.base_stats, strings.S.speed, 15f);
            SafeSetStat(Fixer6.base_stats, strings.S.area_of_effect, 5f);
            SafeSetStat(Fixer6.base_stats, strings.S.mana, 50f);
            SafeSetStat(Fixer6.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(Fixer6.base_stats, strings.S.accuracy, 30f);
            SafeSetStat(Fixer6.base_stats, strings.S.multiplier_speed, 0.6f);
            SafeSetStat(Fixer6.base_stats, strings.S.stamina, 70f);
            SafeSetStat(Fixer6.base_stats, "Dodge", 200f);
            SafeSetStat(Fixer6.base_stats, "Accuracy", 160f);
            Fixer6.action_special_effect += traitAction.Fixer7_effectAction;
            Fixer6.action_special_effect += traitAction.Fixer6_Regen;
            Fixer6.action_attack_target += traitAction.TrueDamage1_AttackAction;
            AssetManager.traits.add(Fixer6);

            ActorTrait Fixer7 = CreateTrait("Fixer7", "trait/Fixer7", "Fixer");
            Fixer7.rarity = Rarity.R2_Epic;
            SafeSetStat(Fixer7.base_stats, "Resist", 32.0f);
            SafeSetStat(Fixer7.base_stats, strings.S.warfare, 30f);
            SafeSetStat(Fixer7.base_stats, strings.S.damage, 2400f);
            SafeSetStat(Fixer7.base_stats, strings.S.targets, 25f);
            SafeSetStat(Fixer7.base_stats, strings.S.armor, 35f);
            SafeSetStat(Fixer7.base_stats, strings.S.health, 10000f);
            SafeSetStat(Fixer7.base_stats, strings.S.speed, 20f);
            SafeSetStat(Fixer7.base_stats, strings.S.area_of_effect, 7f);
            SafeSetStat(Fixer7.base_stats, strings.S.mana, 70f);
            SafeSetStat(Fixer7.base_stats, strings.S.critical_chance, 0.6f);
            SafeSetStat(Fixer7.base_stats, strings.S.accuracy, 40f);
            SafeSetStat(Fixer7.base_stats, strings.S.multiplier_speed, 0.8f);
            SafeSetStat(Fixer7.base_stats, strings.S.stamina, 140f);
            SafeSetStat(Fixer7.base_stats, strings.S.range, 2f);
            SafeSetStat(Fixer7.base_stats, strings.S.attack_speed, 2f);
            SafeSetStat(Fixer7.base_stats, strings.S.scale, 0.04f);
            SafeSetStat(Fixer7.base_stats, strings.S.multiplier_health, 0.2f);
            SafeSetStat(Fixer7.base_stats, strings.S.multiplier_damage, 0.2f);
            SafeSetStat(Fixer7.base_stats, "Dodge", 220f);
            SafeSetStat(Fixer7.base_stats, "Accuracy", 180f);
            Fixer7.action_attack_target += traitAction.TrueDamage2_AttackAction;
            Fixer7.action_special_effect += traitAction.Fixer8_effectAction;
            Fixer7.action_special_effect += traitAction.Fixer7_Regen;
            AssetManager.traits.add(Fixer7);

            ActorTrait Fixer8 = CreateTrait("Fixer8", "trait/Fixer8", "Fixer");
            Fixer8.rarity = Rarity.R2_Epic;
            SafeSetStat(Fixer8.base_stats, "Resist", 64.0f);
            SafeSetStat(Fixer8.base_stats, strings.S.warfare, 40f);
            SafeSetStat(Fixer8.base_stats, strings.S.damage, 4800f);
            SafeSetStat(Fixer8.base_stats, strings.S.targets, 60f);
            SafeSetStat(Fixer8.base_stats, strings.S.armor, 45f);
            SafeSetStat(Fixer8.base_stats, strings.S.health, 24000f);
            SafeSetStat(Fixer8.base_stats, strings.S.speed, 25f);
            SafeSetStat(Fixer8.base_stats, strings.S.area_of_effect, 9f);
            SafeSetStat(Fixer8.base_stats, strings.S.mana, 90f);
            SafeSetStat(Fixer8.base_stats, strings.S.critical_chance, 0.7f);
            SafeSetStat(Fixer8.base_stats, strings.S.accuracy, 50f);
            SafeSetStat(Fixer8.base_stats, strings.S.multiplier_speed, 1.0f);
            SafeSetStat(Fixer8.base_stats, strings.S.stamina, 240f);
            SafeSetStat(Fixer8.base_stats, strings.S.range, 4f);
            SafeSetStat(Fixer8.base_stats, strings.S.attack_speed, 4f);
            SafeSetStat(Fixer8.base_stats, strings.S.multiplier_health, 0.4f);
            SafeSetStat(Fixer8.base_stats, strings.S.multiplier_damage, 0.4f);
            SafeSetStat(Fixer8.base_stats, strings.S.scale, 0.06f);
            SafeSetStat(Fixer8.base_stats, "Dodge", 260f);
            SafeSetStat(Fixer8.base_stats, "Accuracy", 220f);
            Fixer8.action_attack_target += traitAction.TrueDamage3_AttackAction;
            Fixer8.action_special_effect += traitAction.Fixer9_effectAction;
            Fixer8.action_special_effect += traitAction.Fixer8_Regen;
            AssetManager.traits.add(Fixer8);

            ActorTrait Fixer9 = CreateTrait("Fixer9", "trait/Fixer9", "Fixer");
            Fixer9.rarity = Rarity.R2_Epic;
            SafeSetStat(Fixer9.base_stats, "Resist", 128.0f);
            SafeSetStat(Fixer9.base_stats, strings.S.warfare, 50f);
            SafeSetStat(Fixer9.base_stats, strings.S.damage, 9600f);
            SafeSetStat(Fixer9.base_stats, strings.S.targets, 140f);
            SafeSetStat(Fixer9.base_stats, strings.S.armor, 60f);
            SafeSetStat(Fixer9.base_stats, strings.S.health, 48000f);
            SafeSetStat(Fixer9.base_stats, strings.S.speed, 30f);
            SafeSetStat(Fixer9.base_stats, strings.S.area_of_effect, 12f);
            SafeSetStat(Fixer9.base_stats, strings.S.mana, 120f);
            SafeSetStat(Fixer9.base_stats, strings.S.critical_chance, 0.8f);
            SafeSetStat(Fixer9.base_stats, strings.S.accuracy, 60f);
            SafeSetStat(Fixer9.base_stats, strings.S.multiplier_speed, 1.2f);
            SafeSetStat(Fixer9.base_stats, strings.S.stamina, 400f);
            SafeSetStat(Fixer9.base_stats, strings.S.range, 6f);
            SafeSetStat(Fixer9.base_stats, strings.S.attack_speed, 6f);
            SafeSetStat(Fixer9.base_stats, strings.S.scale, 0.08f);
            SafeSetStat(Fixer9.base_stats, strings.S.multiplier_health, 0.6f);
            SafeSetStat(Fixer9.base_stats, strings.S.multiplier_damage, 0.6f);
            SafeSetStat(Fixer9.base_stats, "Dodge", 300f);
            SafeSetStat(Fixer9.base_stats, "Accuracy", 260f);
            Fixer9.action_attack_target += traitAction.TrueDamage4_AttackAction;
            Fixer9.action_special_effect += traitAction.Fixer91_effectAction;
            Fixer9.action_special_effect += traitAction.Fixer9_Regen;
            AssetManager.traits.add(Fixer9);
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}