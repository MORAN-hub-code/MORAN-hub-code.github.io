﻿namespace ChivalryWizardingWorld.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset Fixer = new BaseStatAsset();
            Fixer.id = "Fixer";
            Fixer.normalize = true;
            Fixer.normalize_min = -999999;
            Fixer.normalize_max = 999999;
            Fixer.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Fixer);
        }
    }
}