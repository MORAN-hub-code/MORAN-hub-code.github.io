using UnityEngine;

namespace VideoCopilot.code.utils;

public static class ActorExtensions
{
    private const string fixer_key = "wushu.fixerNum";

    public static float GetFixer(this Actor actor)
    {
        actor.data.get(fixer_key, out float val, 0);

        return val;
    }

    public static void SetFixer(this Actor actor, float val)
    {
        actor.data.set(fixer_key, val);
    }

    public static void ChangeFixer(this Actor actor, float delta)
    {
        actor.data.get(fixer_key, out float val, 0);
        val += delta;
        actor.data.set(fixer_key, Mathf.Max(0, val));
    }
}