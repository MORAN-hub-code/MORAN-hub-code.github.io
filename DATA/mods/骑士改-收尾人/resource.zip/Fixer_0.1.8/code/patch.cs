﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;
        
        private static readonly HashSet<string> BasicRaces = new() { "orc", "human", "elf", "dwarf" };
        private static readonly HashSet<string> FlairGiftedTraits = new() 
        { 
            "gifted1", "gifted2", "gifted3", "gifted4", 
            "flair1", "flair2", "flair3", "flair4", 
            "flair5", "flair6", "flair7" 
        };
        
        private const float GiftedRandomChance = 0.3f;
        private const float Gifted6Chance = 0.2f;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive()) return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }
        }
        [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
        private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
        {
            var actor = __instance.actor;
            if (actor == null || !actor.isAlive()) return;
            __instance.setIconValue("Fixer", actor.GetFixer());
        }

        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_FixerPostfix(Actor __instance)
        {
            if (__instance == null) return;

            float age = (float)__instance.getAge();
            bool hasGifted5 = __instance.hasTrait("gifted5");
            bool hasGifted6 = __instance.hasTrait("gifted6");
            bool hasGifted7 = __instance.hasTrait("gifted7");
            
            if (IsBasicRaceOrCiv(__instance.asset.id))
            {
                HandleBasicRaceTraits(__instance, age, hasGifted5, hasGifted6);
            }

            ApplyTraitEffects(__instance, hasGifted5, hasGifted6);
            
            ApplyFixerGrades(__instance);
        }
        
        private static bool IsBasicRaceOrCiv(string assetId)
        {
            return BasicRaces.Contains(assetId) || assetId.StartsWith("civ_");
        }

        private static void HandleBasicRaceTraits(Actor actor, float age, bool hasGifted5, bool hasGifted6)
        {
            if (Mathf.FloorToInt(age) == 9 && 
                !hasGifted5 && 
                !hasGifted6 && 
                !HasAnyFlairTalen(actor) && 
                Randy.randomChance(GiftedRandomChance))
            {
                string selectedGifted = SelectRandomGifted();
                actor.addTrait(selectedGifted, false);
            }
        }

        private static string SelectRandomGifted()
        {
            var giftedWeights = new (string traitId, int weight)[]
            {
                ("gifted1", 617),
                ("gifted2", 300),
                ("gifted3", 80),
                ("gifted4", 3)
            };

            int totalWeight = giftedWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);

            foreach (var gifted in giftedWeights)
            {
                if (randomValue < gifted.weight)
                {
                    return gifted.traitId;
                }
                randomValue -= gifted.weight;
            }

            return "gifted1";
        }

        private static void ApplyTraitEffects(Actor actor, bool hasGifted5, bool hasGifted6)
        {
            var giftedEffects = new Dictionary<string, (float min, float max)>
            {
                { "gifted1", (1.5f, 2.5f) },
                { "gifted2", (3.0f, 4.0f) },
                { "gifted3", (4.5f, 5.5f) },
                { "gifted4", (6.0f, 9.5f) },
                { "gifted6", (-0.5f, -1.0f) },
                { "gifted7", (10.0f, 10.0f) },
                { "gifted8", (10.0f, 20.0f) },                
                { "gifted9", (10.0f, 20.0f) }
            };

            foreach (var effect in giftedEffects)
            {
                string traitId = effect.Key;
                
                if ((hasGifted6 || hasGifted5) && 
                    (traitId == "gifted1" || traitId == "gifted2" || traitId == "gifted3" || traitId == "gifted4"))
                {
                    continue;
                }

                if (actor.hasTrait(traitId))
                {
                    (float min, float max) = effect.Value;
                    float fixerChange = UnityEngine.Random.Range(min, max);
                    actor.ChangeFixer(fixerChange);
                }
            }

            if (!actor.hasTrait("gifted7"))
            {
                var fixerThresholds = new Dictionary<string, float>
                {
                    { "Fixer1", 40f },
                    { "Fixer2", 50f },
                    { "Fixer3", 50f },
                    { "Fixer4", 65f },
                    { "Fixer5", 70f },
                    { "Fixer6", 100f }
                };

                foreach (var threshold in fixerThresholds)
                {
                    if (actor.hasTrait(threshold.Key) &&
                        (float)actor.getAge() > threshold.Value &&
                        Randy.randomChance(Gifted6Chance))
                    {
                        actor.addTrait("gifted6", false);
                    }
                }
            }
        }

        private static void ApplyFixerGrades(Actor actor)
        {
            var fixerGrades = new Dictionary<string, float>
            {
                { "Fixer1", 10f },
                { "Fixer2", 18f },
                { "Fixer3", 32f },
                { "Fixer4", 53f },
                { "Fixer5", 68f },
                { "Fixer6", 180f },
                { "Fixer7", 320f },
                { "Fixer8", 530f },                
                { "Fixer9", 800f },
            };

            foreach (var grade in fixerGrades)
            {
                if (actor.hasTrait(grade.Key))
                {
                    float currentFixer = actor.GetFixer();
                    actor.SetFixer(Mathf.Min(grade.Value, currentFixer));
                }
            }
        }

        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (string trait in FlairGiftedTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}