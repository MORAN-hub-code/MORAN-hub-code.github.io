﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChivalryWizardingWorld.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset Fixer = new ActorTraitGroupAsset();
            Fixer.id = "Fixer";
            Fixer.name = "trait_group_Fixer";
            Fixer.color = "#00FFFF";
            AssetManager.trait_groups.add(Fixer);

            ActorTraitGroupAsset Egolight = new ActorTraitGroupAsset();
            Egolight.id = "Egolight";
            Egolight.name = "trait_group_Egolight";
            Egolight.color = "#FF00FF";
            AssetManager.trait_groups.add(Egolight);
        }
    }
}
