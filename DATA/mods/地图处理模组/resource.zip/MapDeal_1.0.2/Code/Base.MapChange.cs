﻿using System;
using System.Collections.Generic;
using System.Text;
using ReflectionUtility;

namespace MapDeal
{
    public class MapChange
    {
        public static int mapSizeX = 1;
        public static int mapSizeY = 1;
        static TileType[,] mainTiles;
        static TopTileType[,] topTiles;

        static WorldTile newTile;

        public static bool dealLimit = false;
        public static int dealSizeX = 1;
        public static int dealSizeY = 1;

        public static WorldTile[,] tiles_map;
        public static void save()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            mainTiles = new TileType[tiles_map.GetLength(0), tiles_map.GetLength(1)];
            topTiles = new TopTileType[tiles_map.GetLength(0), tiles_map.GetLength(1)];
            for (int i = 0; i < tiles_map.GetLength(0); i++)
            {
                for (int j = 0; j < tiles_map.GetLength(1); j++)
                {
                    newTile = tiles_map[i, j];
                    mainTiles[i, j] = newTile.main_type;
                    topTiles[i, j] = newTile.top_type;
                }
            }
        }

        public static void 左下开始布置()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);

            int maxX2 = mainTiles.GetLength(0);
            int maxY2 = mainTiles.GetLength(1);
            for (int i = 0; i < maxX && i<maxX2; i++)
            {
                for (int j = 0; j < maxY && j < maxY2; j++)
                {
                    newTile = tiles_map[i, j];
                    MapAction.terraformTile(newTile, mainTiles[i, j], topTiles[i, j]);
                }
            }
        }
        public static void 左上开始布置()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);

            int maxX2 = mainTiles.GetLength(0);
            int maxY2 = mainTiles.GetLength(1);
            for (int i = 0; i < maxX && i < maxX2; i++)
            {
                for (int j = 1; j <= maxY && j < maxY2; j++)
                {
                    newTile = tiles_map[i, maxX - j];
                    MapAction.terraformTile(newTile, mainTiles[i, j], topTiles[i, j]);
                }
            }
        }
        public static void 右下开始布置()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);

            int maxX2 = mainTiles.GetLength(0);
            int maxY2 = mainTiles.GetLength(1);
            for (int i = 1; i <= maxX && i < maxX2; i++)
            {
                for (int j = 0; j < maxY && j < maxY2; j++)
                {
                    newTile = tiles_map[maxX - i, j];
                    MapAction.terraformTile(newTile, mainTiles[i, j], topTiles[i, j]);
                }
            }
        }
        public static void 右上开始布置()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);

            int maxX2 = mainTiles.GetLength(0);
            int maxY2 = mainTiles.GetLength(1);
            for (int i = 1; i <= maxX && i < maxX2; i++)
            {
                for (int j = 1; j <= maxY && j < maxY2; j++)
                {
                    newTile = tiles_map[maxX - i, maxX - j];
                    MapAction.terraformTile(newTile, mainTiles[i, j], topTiles[i, j]);
                }
            }
        }

        public static void 从中心开始布置()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0) / 2;
            int maxY = tiles_map.GetLength(1) / 2;

            int maxX2 = mainTiles.GetLength(0) / 2;
            int maxY2 = mainTiles.GetLength(1) / 2;

            for (int i = 0; i < maxX && i < maxX2; i++)
            {
                for (int j = 0; j < maxY && j < maxY2; j++)
                {
                    newTile = tiles_map[maxX - i, maxX - j];
                    MapAction.terraformTile(newTile, mainTiles[maxX2 - i, maxY2 - j], topTiles[maxX2 - i, maxY2 - j]);
                    newTile = tiles_map[maxX + i, maxX + j];
                    MapAction.terraformTile(newTile, mainTiles[maxX2 + i, maxY2 + j], topTiles[maxX2 + i, maxY2 + j]);

                    newTile = tiles_map[maxX + i, maxX - j];
                    MapAction.terraformTile(newTile, mainTiles[maxX2 + i, maxY2 - j], topTiles[maxX2 + i, maxY2 - j]);
                    newTile = tiles_map[maxX - i, maxX + j];
                    MapAction.terraformTile(newTile, mainTiles[maxX2 - i, maxY2 + j], topTiles[maxX2 - i, maxY2 + j]);
                }
            }
        }
        static Dictionary<TileType, int> types = new Dictionary<TileType, int>();
        public static void recalcMap()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);
            TileType tileType;
            int typeNum;
            for (int i = 1; i < maxX - 1 && (i < dealSizeX || !dealLimit); i++)
            {
                for (int j = 1; j < maxY - 1 && (j < dealSizeY || !dealLimit); j++)
                {
                    newTile = tiles_map[i, j];
                    types.Clear();
                    foreach (var tile in newTile.neighboursAll)
                    {
                        if (!types.ContainsKey(tile.main_type))
                        {
                            types.Add(tile.main_type, 0);
                        }
                        types[tile.main_type]++;
                    }
                    tileType = null;
                    typeNum = 0;
                    foreach (var type in types)
                    {
                        if (tileType == null || typeNum < type.Value)
                        {
                            tileType = type.Key;
                            typeNum = type.Value;
                        }
                    }
                    if (typeNum > 4 && newTile.main_type != tileType)
                    {
                        MapAction.terraformTile(newTile, tileType, null);
                    }
                    else if (typeNum == 4 && !types.ContainsKey(newTile.main_type))
                    {
                        MapAction.terraformTile(newTile, tileType, null);
                    }
                }
            }
        }

        public static void suoFang()
        {
            tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
            int maxX = tiles_map.GetLength(0);
            int maxY = tiles_map.GetLength(1);
            int oldX = mainTiles.GetLength(0);
            int oldY = mainTiles.GetLength(1);
            float xR = ((float)oldX) / ((float)maxX);
            float yR = ((float)oldY) / ((float)maxY);
            for (int i = 0; i < maxX; i++)
            {
                for (int j = 0; j < maxY; j++)
                {
                    newTile = tiles_map[i, j];
                    oldX = (int)(xR * i);
                    oldY = (int)(yR * j);
                    MapAction.terraformTile(newTile, mainTiles[oldX, oldY], topTiles[oldX, oldY]);
                }
            }
        }

        public static void generateNewMap()
        {
            SmoothLoader.prepare();
            SmoothLoader.add(delegate
            {
                LogText.log("MapBox", "generateNewMap", "st");
                Analytics.worldLoading();
                bool _first_gen = (bool)Reflection.GetField(typeof(MapBox), MapBox.instance, "_first_gen");
                if (_first_gen)
                {
                    Config.customMapSize = Config.customMapSizeDefault;
                }
                if (!_first_gen)
                {
                    AchievementLibrary.achievementCustomWorld.check(null, null, null);
                }
                Reflection.SetField<bool>(MapBox.instance, "_first_gen", false);
                int size = MapSizeLibrary.getSize(Config.customMapSize);
                MapBox.instance.addClearWorld(size, size);
            }, "Generate New Map (1/3)", false, 0.001f);
            SmoothLoader.add(delegate
            {
                Config.ZONE_AMOUNT_X = mapSizeX;
                Config.ZONE_AMOUNT_Y = mapSizeY;
            }, "Generate New Map (2/3)", false, 0.001f);
            SmoothLoader.add(delegate
            {
                MapBox.instance.setMapSize(Config.ZONE_AMOUNT_X, Config.ZONE_AMOUNT_Y);
            }, "Generate New Map (3/3)", false, 0.001f);
            SmoothLoader.add(delegate
            {
                LogText.log("MapBox", "GenerateMap", "st");
                AssetManager.tiles.setListTo(DepthGeneratorType.Generator);
                WorldLaws world_laws = new WorldLaws();
                world_laws.init();
                Reflection.SetField<WorldLaws>(MapBox.instance, "world_laws", world_laws);
            }, "gen: World Laws", false, 0.001f);
            SmoothLoader.add(delegate
            {
                MapStats map_stats = new MapStats();
                map_stats.initNewWorld();
                Reflection.SetField<MapStats>(MapBox.instance, "map_stats", map_stats);
                Randy.resetSeed(Randy.randomInt(1, 555555555));
            }, "gen: Generating Name", false, 0.001f);
            if (!Config.disable_db)
            {
                SmoothLoader.add(delegate
                {
                    DBManager.createDB();
                }, "Creating Stats DB", false, 0.001f);
                DBTables.createOrMigrateTablesLoader(true);
            }
            SmoothLoader.add(delegate
            {
                WorldAgeManager era_manager = Reflection.GetField(typeof(MapBox), MapBox.instance, "era_manager") as WorldAgeManager;
                era_manager.setDefaultAges();
            }, "gen: World Ages", false, 0.001f);
            SmoothLoader.add(delegate
            {
                MapGenerator.prepare();
                LogText.log("MapBox", "GenerateMap", "en");
            }, "Preparing Map", true, 0.001f);
            SmoothLoader.add(delegate
            {
                MapBox.instance.cleanUpWorld(true);
            }, "Cleaning Up The World", true, 0.001f);
            SmoothLoader.add(delegate
            {
                MapBox.instance.redrawTiles();
            }, "Drawing Up The World", true, 0.001f);
            SmoothLoader.add(delegate
            {
                MapBox.instance.finishMakingWorld();
                LogText.log("MapBox", "generateNewMap", "en");
            }, "Tidying Up The World", true, 0.001f);
            SmoothLoader.add(delegate
            {
                MapBox.instance.lastGC();
            }, "Rewriting The World", true, 0.001f);
            MapBox.instance.addLoadAutoTester();
            MapBox.instance.addKillAllUnits();
            MapBox.instance.addLoadWorldCallbacks();
            SmoothLoader.add(delegate
            {
            }, "Finishing up...", false, 0.2f);
        }
    }
}
