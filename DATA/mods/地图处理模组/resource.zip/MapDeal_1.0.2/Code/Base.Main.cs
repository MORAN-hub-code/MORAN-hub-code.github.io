﻿using System;
using System.Collections.Generic;
using System.Text;
using NCMS;
using UnityEngine;
using ReflectionUtility;

namespace MapDeal
{
    [ModEntry]
    public class Main:MonoBehaviour
    {
        void Awake()
        {

        }

        void Update()
        {

        }


        public Rect buRect = new Rect(0, 0, 120f, 30f);
        public Rect windowRect = new Rect(0, 0, 120f, 50f);
        public bool showButton = false;

        public string sizeX = "1";
        public string sizeY = "1";
        public string dealsizeX = "1";
        public string dealsizeY = "1";
        void OnGUI()
        {
            windowRect = GUI.Window(1, windowRect, drawWindow_1, "地图处理");
            if (showButton)
            {
                buRect.x = windowRect.x;
                buRect.y = windowRect.y + windowRect.height;
                if (GUI.Button(buRect, "记录地图"))
                {
                    MapChange.save();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "从左下放置旧地图"))
                {
                    MapChange.左下开始布置();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "从左上放置旧地图"))
                {
                    MapChange.左上开始布置();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "从右下放置旧地图"))
                {
                    MapChange.右下开始布置();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "从右上放置旧地图"))
                {
                    MapChange.右上开始布置();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "从中心放置旧地图"))
                {
                    MapChange.从中心开始布置();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "缩放地图"))
                {
                    MapChange.suoFang();
                }
                buRect.y += buRect.height;

                buRect.width /= 2;
                sizeX = GUI.TextField(buRect, sizeX);
                buRect.x += buRect.width;
                sizeY = GUI.TextField(buRect, sizeY);
                buRect.y += buRect.height;
                buRect.width *= 2;

                buRect.x = windowRect.x;
                if (GUI.Button(buRect, $"X:{MapChange.mapSizeX}-Y:{MapChange.mapSizeY}"))
                {
                    if(!int.TryParse(sizeX,out MapChange.mapSizeX))
                    {
                        MapChange.mapSizeX = 1;
                    }
                    if (!int.TryParse(sizeY, out MapChange.mapSizeY))
                    {
                        MapChange.mapSizeY = 1;
                    }
                }
                buRect.y += buRect.height;

                buRect.x = windowRect.x;
                if (GUI.Button(buRect, "生成地图"))
                {
                    MapChange.generateNewMap();
                }
                buRect.y += buRect.height;

                if (GUI.Button(buRect, "处理噪点"))
                {
                    MapChange.recalcMap();
                }
                buRect.y += buRect.height;

                //if (GUI.Button(buRect, "限制范围"))
                //{
                //    MapChange.dealLimit = !MapChange.dealLimit;
                //    MapChange.tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
                //    MapChange.dealSizeX = MapChange.tiles_map.GetLength(0);
                //    MapChange.dealSizeY = MapChange.tiles_map.GetLength(1);
                //}
                //buRect.y += buRect.height;

                if (GUI.Button(buRect, "全解锁"))
                {
                    WorldLawLibrary.world_law_cursed_world.toggle(true);
                    PowerButton.checkActorSpawnButtons();
                }
                buRect.y += buRect.height;

                if (MapChange.dealLimit)
                {
                    buRect.width /= 2;
                    dealsizeX = GUI.TextField(buRect, dealsizeX);
                    buRect.x += buRect.width;
                    dealsizeY = GUI.TextField(buRect, dealsizeY);
                    buRect.x = windowRect.x;
                    buRect.width *= 2;
                    buRect.y += buRect.height;

                    if (GUI.Button(buRect, $"X:{MapChange.dealSizeX}-Y:{MapChange.dealSizeY}"))
                    {
                        MapChange.tiles_map = (WorldTile[,])Reflection.GetField(typeof(MapBox), MapBox.instance, "tiles_map");
                        if (!int.TryParse(dealsizeX, out MapChange.dealSizeX))
                        {
                            MapChange.dealSizeX = MapChange.tiles_map.GetLength(0);
                        }
                        if (!int.TryParse(dealsizeY, out MapChange.dealSizeY))
                        {
                            MapChange.dealSizeY = MapChange.tiles_map.GetLength(1);
                        }
                    }
                }
            }
        }

        public void drawWindow_1(int id)
        {
            buRect.y = 20;
            buRect.x = 0;
            if (GUI.Button(buRect, "显示按键"))
            {
                showButton = !showButton;
            }
            GUI.DragWindow();
        }
    }
}
