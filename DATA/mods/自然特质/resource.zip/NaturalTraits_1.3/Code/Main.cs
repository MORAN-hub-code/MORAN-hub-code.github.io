using NeoModLoader.api;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Net.Http;

namespace NaturalTraits
{
    [ModEntry]
    class Main : BasicMod<Main>
    {
        #region
        public static Main instance;
        #endregion
        internal static Harmony harmony;
		private static string VER = "10.4.0"; 


        protected override void OnModLoad()
        {
            Traits.init();
			TraitGroup.init();
        }
    }
}