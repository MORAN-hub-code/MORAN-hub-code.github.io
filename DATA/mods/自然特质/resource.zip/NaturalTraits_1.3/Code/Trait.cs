using System;
using System.Collections.Generic;
using NCMS;
using System.ComponentModel;
using UnityEngine;

namespace NaturalTraits
{
    public static class Traits
    {
        public static void init()
        {
            ActorTrait Amoroso = new ActorTrait();
            Amoroso.id = "Amoroso";
            Amoroso.path_icon = "ui/Icons/Amoroso";
            Amoroso.group_id = TraitGroup.NaturalTraits;
            Amoroso.type = TraitType.Positive;
            Amoroso.can_be_given = true;
            Amoroso.can_be_removed = true;
            Amoroso.rate_birth = 1;
			Amoroso.rate_inherit = 1;
            Amoroso.rarity = Rarity.R0_Normal;
			Amoroso.addOpposite("stupid");
			AssetManager.traits.add(Amoroso);
            Amoroso.base_stats.set("offspring", 0.30f);
            Amoroso.base_stats.set("intelligence", 1f);
            Amoroso.base_stats.set("opinion", 15f);
            Amoroso.base_stats.set("birth_rate", 10f);
			Amoroso.base_stats.set("cities", 1);

            ActorTrait Arrogante = new ActorTrait();
            Arrogante.id = "Arrogante";
            Arrogante.path_icon = "ui/Icons/Arrogante";
            Arrogante.group_id = TraitGroup.BadNaturalTraits;
            Arrogante.type = TraitType.Positive;
            Arrogante.can_be_given = true;
            Arrogante.can_be_removed = true;
            Arrogante.rate_birth = 1;
			Arrogante.rate_inherit = 1;
            Arrogante.rarity = Rarity.R0_Normal;          
			Arrogante.addOpposite("Sencillo");
            AssetManager.traits.add(Arrogante);		
            Arrogante.base_stats.set("offspring", -0.10f);
            Arrogante.base_stats.set("intelligence", 1f);
            Arrogante.base_stats.set("accuracy", 0.02f);
            Arrogante.base_stats.set("warfare", 7);
			Arrogante.base_stats.set("diplomacy", -7);
			Arrogante.base_stats.set("stewardship", -5);
			Arrogante.base_stats.set("opinion", -5);
			
            ActorTrait Atento = new ActorTrait();
            Atento.id = "Atento";
            Atento.path_icon = "ui/Icons/Atento";
            Atento.group_id = TraitGroup.NaturalTraits;
            Atento.type = TraitType.Positive;
            Atento.can_be_given = true;
            Atento.can_be_removed = true;
            Atento.rate_birth = 1;
			Atento.rate_inherit = 1;
            Atento.rarity = Rarity.R0_Normal;
            Atento.addOpposite("Descuidado");	
            AssetManager.traits.add(Atento);
			Atento.base_stats.set("attack_speed", 7);
            Atento.base_stats.set("speed", 5f);
			Atento.base_stats.set("range", 0.7f);
			Atento.base_stats.set("skill_combat", 0.60f);
			Atento.base_stats.set("critical_chance", 0.25f);
			Atento.base_stats.set("warfare", 1);
			Atento.base_stats.set("stewardship", 1);
			Atento.base_stats.set("cities", 1);
			
			ActorTrait Carismatico = new ActorTrait();
			Carismatico.id = "Carismatico";
			Carismatico.path_icon = "ui/Icons/Carismatico";
			Carismatico.type = TraitType.Other;
			Carismatico.group_id = TraitGroup.NaturalTraits;
			Carismatico.can_be_given = true;
			Carismatico.can_be_removed = true;
			Carismatico.rate_birth = 1;
			Carismatico.rarity = Rarity.R0_Normal;
			Carismatico.rate_inherit = 1;
			Carismatico.addOpposite("Asocial");
			Carismatico.addOpposite("Conformista");
			Carismatico.addOpposite("Mudo");
			AssetManager.traits.add(Carismatico);
			Carismatico.base_stats.set("offspring", 0.1f);
			Carismatico.base_stats.set("multiplier_lifespan", 20f);
			Carismatico.base_stats.set("intelligence", 2f);
			Carismatico.base_stats.set("warfare", 0f);
			Carismatico.base_stats.set("diplomacy", 5f);
			Carismatico.base_stats.set("opinion", 16f);
			Carismatico.base_stats.set("cities", 2f);

			
			ActorTrait Cicatrizado = new ActorTrait();
			Cicatrizado.id = "Cicatrizado";
			Cicatrizado.path_icon = "ui/Icons/cicatrizado";
			Cicatrizado.type = TraitType.Other;
			Cicatrizado.group_id = TraitGroup.NaturalTraits;
			Cicatrizado.rarity = Rarity.R0_Normal;
			Cicatrizado.can_be_given = true;
			Cicatrizado.can_be_removed = true;
			Cicatrizado.rate_birth = 1;
			Cicatrizado.rate_inherit = 1;
			Cicatrizado.addOpposite("Simetrico");
			Cicatrizado.addOpposite("Formido");
			Cicatrizado.addOpposite("SuperResistente");
			AssetManager.traits.add(Cicatrizado);
			Cicatrizado.base_stats.set("offspring", -0.3f);
			Cicatrizado.base_stats.set("birth_rate", -2f);
			Cicatrizado.base_stats.set("damage", 3f);
			Cicatrizado.base_stats.set("speed", 2f);
			Cicatrizado.base_stats.set("warfare", 2f);
			Cicatrizado.base_stats.set("opinion", -10f);
			Cicatrizado.base_stats.set("cities", -1f);

			ActorTrait Cooperativo = new ActorTrait();
			Cooperativo.id = "Cooperativo";
			Cooperativo.path_icon = "ui/Icons/Cooperativo";
			Cooperativo.type = TraitType.Other;
			Cooperativo.group_id = TraitGroup.NaturalTraits;
			Cooperativo.can_be_given = true;
			Cooperativo.can_be_removed = true;
			Cooperativo.rate_birth = 1;
			Cooperativo.rate_inherit = 1;
			Cooperativo.rarity = Rarity.R0_Normal;
			Cooperativo.addOpposite("Asocial");
			Cooperativo.addOpposite("Solitario");
			AssetManager.traits.add(Cooperativo);
			Cooperativo.base_stats.set("offspring", 0.50f);
			Cooperativo.base_stats.set("multiplier_lifespan", 20f);
			Cooperativo.base_stats.set("attack_speed", 5);
			Cooperativo.base_stats.set("damage", 3.20f);
			Cooperativo.base_stats.set("speed", 8f);
			Cooperativo.base_stats.set("health", 60);
			Cooperativo.base_stats.set("armor", 2);
			Cooperativo.base_stats.set("opinion", 5f);
			Cooperativo.base_stats.set("loyalty_traits", 7f);


			ActorTrait Curioso = new ActorTrait();
			Curioso.id = "Curioso";
			Curioso.path_icon = "ui/Icons/Curioso";
			Curioso.type = TraitType.Other;
			Curioso.group_id = TraitGroup.NaturalTraits;
			Curioso.can_be_given = true;
			Curioso.can_be_removed = true;
			Curioso.rate_birth = 1;
			Curioso.rate_inherit = 1;
			Curioso.rarity = Rarity.R0_Normal;
			AssetManager.traits.add(Curioso);
			Curioso.base_stats.set("speed", 9f);
			Curioso.base_stats.set("warfare", 7);
			Curioso.base_stats.set("diplomacy", 2);
			Curioso.base_stats.set("stewardship", 5);
			Curioso.base_stats.set("opinion", 5f);
			Curioso.base_stats.set("cities", 2);
			Curioso.base_stats.set("area_of_effect", 4);


			ActorTrait Delgado = new ActorTrait();
			Delgado.id = "Delgado";
			Delgado.path_icon = "ui/Icons/Delgado";
			Delgado.type = TraitType.Other;
			Delgado.group_id = TraitGroup.Physicalconditions;
			Delgado.can_be_given = true;
			Delgado.can_be_removed = true;
			Delgado.rate_birth = 1;
			Delgado.rate_inherit = 1;
			Delgado.rarity = Rarity.R0_Normal;
			AssetManager.traits.add(Delgado);
			Delgado.base_stats.set("offspring", -0.10f);
			Delgado.base_stats.set("attack_speed", 5);
			Delgado.base_stats.set("speed", 7f);
			Delgado.base_stats.set("health", -20);
			Delgado.base_stats.set("scale", -0.02f);
			Delgado.base_stats.set("opinion", -6f);


			ActorTrait Determinado = new ActorTrait();
			Determinado.id = "Determinado";
			Determinado.path_icon = "ui/Icons/Determinado";
			Determinado.type = TraitType.Positive;
			Determinado.group_id = TraitGroup.NaturalTraits;
			Determinado.can_be_given = true;
			Determinado.can_be_removed = true;
			Determinado.rate_birth = 1;
			Determinado.rate_inherit = 1;
			Determinado.rarity = Rarity.R0_Normal;
			AssetManager.traits.add(Determinado);
			Determinado.base_stats.set("intelligence", 10);
			Determinado.base_stats.set("warfare", 15);
			Determinado.base_stats.set("diplomacy", 4);
			Determinado.base_stats.set("stewardship", 5);
			Determinado.base_stats.set("opinion", 5f);
			Determinado.base_stats.set("loyalty_traits", 9f);


			ActorTrait EnfermoMental = new ActorTrait();
			EnfermoMental.id = "Enfermo Mental";
			EnfermoMental.path_icon = "ui/Icons/Enfermo Mental";
			EnfermoMental.type = TraitType.Other;
			EnfermoMental.group_id = TraitGroup.MentalDisorders;
			EnfermoMental.can_be_given = true;
			EnfermoMental.can_be_removed = true;
			EnfermoMental.rate_birth = 1;
			EnfermoMental.rate_inherit = 1;
			EnfermoMental.rarity = Rarity.R0_Normal;
			EnfermoMental.addOpposite("genius");
			EnfermoMental.addOpposite("SuperInteligente");
			EnfermoMental.addOpposite("SuperAgil");
			EnfermoMental.addOpposite("SuperRapido");
			EnfermoMental.addOpposite("Talentoso");
			EnfermoMental.addOpposite("Idealista");
			EnfermoMental.addOpposite("Estrategico");
			EnfermoMental.addOpposite("Administrativo");
			EnfermoMental.addOpposite("Diplomatico");
			AssetManager.traits.add(EnfermoMental);
			EnfermoMental.base_stats.set("offspring", -0.6f);
			EnfermoMental.base_stats.set("birth_rate", -5f);
			EnfermoMental.base_stats.set("attack_speed", -10);
			EnfermoMental.base_stats.set("speed", -5f);
			EnfermoMental.base_stats.set("health", -40);
			EnfermoMental.base_stats.set("armor", -20);
			EnfermoMental.base_stats.set("skill_combat", -1000f);
			EnfermoMental.base_stats.set("intelligence", -20);
			EnfermoMental.base_stats.set("warfare", -10);
			EnfermoMental.base_stats.set("diplomacy", -10);
			EnfermoMental.base_stats.set("opinion", -3f);
			EnfermoMental.base_stats.set("loyalty_traits", 5f);
			
         ActorTrait Estrategico= new ActorTrait();
         Estrategico.id = "Estrategico";
         Estrategico.path_icon = "ui/Icons/Estrategico";
         Estrategico.type = TraitType.Other;
         Estrategico.group_id = TraitGroup.NaturalTraits;
         Estrategico.can_be_given = true;
         Estrategico.can_be_removed = true;
		 Estrategico.addOpposite("EnfermoMental");
		 Estrategico.addOpposite("Esquizofrenico");
         AssetManager.traits.add(Estrategico);
         Estrategico.base_stats["birth_rate"] = 5f;
         Estrategico.base_stats["intelligence"] = 2;
         Estrategico.base_stats["warfare"] = 34;
         Estrategico.base_stats["diplomacy"] = 1;
         Estrategico.base_stats["stewardship"] = 1;
         Estrategico.base_stats["cities"] = 4;
         Estrategico.base_stats["area_of_effect"] = 5;


         ActorTrait Explorador= new ActorTrait();
         Explorador.id = "Explorador";
         Explorador.path_icon = "ui/Icons/Explorador";
         Explorador.type = TraitType.Other;
         Explorador.group_id = TraitGroup.NaturalTraits;
         Explorador.can_be_given = true;
         Explorador.can_be_removed = true;
         Explorador.rate_birth = 1;
         Explorador.rate_inherit = 1;
         AssetManager.traits.add(Explorador);
         Explorador.base_stats["multiplier_offspring"] = 0.05f;
         Explorador.base_stats["speed"] = 8f;
         Explorador.base_stats["stewardship"] = 6;
         Explorador.base_stats["cities"] = 10;
         Explorador.base_stats["area_of_effect"] = 15;
////		 Explorador.opposite = "Sidoso,EnfermoMental,Esquizofrenico";
 
  
         ActorTrait Formal= new ActorTrait();
         Formal.id = "Formal";
         Formal.path_icon = "ui/Icons/Formal";
         Formal.type = TraitType.Other;
         Formal.group_id = TraitGroup.NaturalTraits;
         Formal.can_be_given = true;
         Formal.can_be_removed = true;
         Formal.rate_birth = 1;
         Formal.rate_inherit = 1;
         AssetManager.traits.add(Formal);
         Formal.base_stats["multiplier_offspring"] = 0.67f;
         Formal.base_stats["birth_rate"] = 1;
         Formal.base_stats["armor"] = 5;
         Formal.base_stats["skill_combat"] = 0.40f;
         Formal.base_stats["knockback"] = 0.5f;
         Formal.base_stats["intelligence"] = 2;
         Formal.base_stats["diplomacy"] = 6;
         Formal.base_stats["stewardship"] = 5;
         Formal.base_stats["opinion"] = 5f;
         Formal.base_stats["loyalty_traits"] = 5f;
         Formal.base_stats["cities"] = 4;
         Formal.base_stats["area_of_effect"] = 5;
////		 Formal.opposite = "Inmaduro,Esquizofrenico";
 
  
         ActorTrait Miedoso= new ActorTrait();
         Miedoso.id = "Miedoso";
         Miedoso.path_icon = "ui/Icons/Miedoso";
         Miedoso.type = TraitType.Other;
         Miedoso.group_id = TraitGroup.BadNaturalTraits;
         Miedoso.can_be_given = true;
         Miedoso.can_be_removed = true;
         Miedoso.rate_birth = 1;
         Miedoso.rate_inherit = 1;
         AssetManager.traits.add(Miedoso);
         Miedoso.base_stats["multiplier_offspring"] = -0.1f;
         Miedoso.base_stats["damage"] = -10;
         Miedoso.base_stats["speed"] = 5f;
         Miedoso.base_stats["stewardship"] = -1;
         Miedoso.base_stats["opinion"] = 5f;
         Miedoso.base_stats["loyalty_traits"] = -4f;
         Miedoso.base_stats["cities"] = -2;
         Miedoso.base_stats["area_of_effect"] = -6;
////		 Miedoso.opposite = "Valiente,Arriesgado";
 
  
         ActorTrait Mudo= new ActorTrait();
         Mudo.id = "Mudo";
         Mudo.path_icon = "ui/Icons/Mudo";
         Mudo.type = TraitType.Other;
         Mudo.group_id = TraitGroup.BadNaturalTraits;
         Mudo.can_be_given = true;
         Mudo.can_be_removed = true;
         Mudo.rate_birth = 1;
         Mudo.rate_inherit = 1;
         AssetManager.traits.add(Mudo);
         Mudo.base_stats["multiplier_offspring"] = -0.20f;
         Mudo.base_stats["birth_rate"] = 1;
         Mudo.base_stats["attack_speed"] = -4;
         Mudo.base_stats["armor"] = -5;
         Mudo.base_stats["critical_chance"] = -0.5f;
         Mudo.base_stats["stewardship"] = -5;
         Mudo.base_stats["opinion"] = -4f;
         Mudo.base_stats["loyalty_traits"] = -4f;
         Mudo.base_stats["cities"] = -2;
         Mudo.base_stats["area_of_effect"] = -5;
////		 Mudo.opposite = "Sociable,Coherente,Carismatico";
 //Cicatrizado
  
         ActorTrait Optimista= new ActorTrait();
         Optimista.id = "Optimista";
         Optimista.path_icon = "ui/Icons/optimista";
         Optimista.type = TraitType.Other;
         Optimista.group_id = TraitGroup.NaturalTraits;
         Optimista.can_be_given = true;
         Optimista.can_be_removed = true;
         Optimista.rate_birth = 1;
         Optimista.rate_inherit = 1;
         AssetManager.traits.add(Optimista);
         Optimista.base_stats["multiplier_offspring"] = 0.05f;
         Optimista.base_stats["birth_rate"] = 1;
         Optimista.base_stats["damage"] = 2;
         Optimista.base_stats["health"] = 10;
         Optimista.base_stats["accuracy"] = 0.15f;
         Optimista.base_stats["critical_chance"] = 0.1f;
         Optimista.base_stats["opinion"] = 10f;
         Optimista.base_stats["loyalty_traits"] = -1f;
         Optimista.base_stats["cities"] = 2;
         Optimista.base_stats["area_of_effect"] = 1;
////		 Optimista.opposite = "Pesimista";
 
  
         ActorTrait Organizado= new ActorTrait();
         Organizado.id = "Organizado";
         Organizado.path_icon = "ui/Icons/Organizado";
         Organizado.type = TraitType.Other;
         Organizado.group_id = TraitGroup.NaturalTraits;
         Organizado.can_be_given = true;
         Organizado.can_be_removed = true;
         Organizado.rate_birth = 1;
         Organizado.rate_inherit = 1;
         AssetManager.traits.add(Organizado);
         Organizado.base_stats["accuracy"] = 0.2f;
         Organizado.base_stats["targets"] = 0.08f;
         Organizado.base_stats["intelligence"] = 3;
         Organizado.base_stats["stewardship"] = 5;
         Organizado.base_stats["opinion"] = 4f;
         Organizado.base_stats["loyalty_traits"] = 5f;
////		 Organizado.opposite = "Desastroso,Irresponsable";
 
  
         ActorTrait Orgulloso= new ActorTrait();
         Orgulloso.id = "Orgulloso";
         Orgulloso.path_icon = "ui/Icons/Orgulloso";
         Orgulloso.type = TraitType.Other;
         Orgulloso.group_id = TraitGroup.NaturalTraits;
         Orgulloso.can_be_given = true;
         Orgulloso.can_be_removed = true;
         Orgulloso.rate_birth = 1;
         Orgulloso.rate_inherit = 1;
         AssetManager.traits.add(Orgulloso);
         Orgulloso.base_stats["multiplier_offspring"] = 0.05f;
         Orgulloso.base_stats["birth_rate"] = 1;
         Orgulloso.base_stats["multiplier_lifespan"] = 5f;
         Orgulloso.base_stats["attack_speed"] = 4;
         Orgulloso.base_stats["damage"] = 1.3f;
         Orgulloso.base_stats["speed"] = 3f;
         Orgulloso.base_stats["accuracy"] = 0.6f;
         Orgulloso.base_stats["armor"] = 7;
         Orgulloso.base_stats["skill_combat"] = 0.4f;
         Orgulloso.base_stats["opinion"] = -5f;
         Orgulloso.base_stats["cities"] = -1;
         Orgulloso.base_stats["area_of_effect"] = 2;
////		 Orgulloso.opposite = "Timido,Miedoso,Descuidado,Desvergonzado";
 
  
         ActorTrait Resistente= new ActorTrait();
         Resistente.id = "Resistente";
         Resistente.path_icon = "ui/Icons/Resistente";
         Resistente.type = TraitType.Other;
         Resistente.group_id = TraitGroup.Physicalconditions;
         Resistente.can_be_given = true;
         Resistente.can_be_removed = true;
         Resistente.rate_birth = 1;
         Resistente.rate_inherit = 1;
         AssetManager.traits.add(Resistente);
         Resistente.base_stats["multiplier_lifespan"] = 10f;
         Resistente.base_stats["attack_speed"] = 2;
         Resistente.base_stats["damage"] = 1;
         Resistente.base_stats["speed"] = 6f;
         Resistente.base_stats["accuracy"] = 4f;
         Resistente.base_stats["range"] = 1;
         Resistente.base_stats["armor"] = 40;
         Resistente.base_stats["critical_chance"] = 0.5f;
         Resistente.base_stats["knockback"] = 0.12f;
//         Resistente.base_stats["knockback_reduction"] = 1.0f;
         Resistente.base_stats["opinion"] = 7f;
         Resistente.base_stats["loyalty_traits"] = 0.7f;
////		 Resistente.opposite = "Sensible,Cicatrizado,weak,tiny,Delgado,Anorexico";
 
  
         ActorTrait Sociable= new ActorTrait();
         Sociable.id = "Sociable";
         Sociable.path_icon = "ui/Icons/Sociable";
         Sociable.type = TraitType.Other;
         Sociable.group_id = TraitGroup.NaturalTraits;
         Sociable.can_be_given = true;
         Sociable.can_be_removed = true;
         Sociable.rate_birth = 1;
         Sociable.rate_inherit = 1;
         AssetManager.traits.add(Sociable);
         Sociable.base_stats["multiplier_offspring"] = 0.74f;
         Sociable.base_stats["birth_rate"] = 1;
         Sociable.base_stats["speed"] = 2f;
         Sociable.base_stats["accuracy"] = 0.5f;
         Sociable.base_stats["opinion"] = 10f;
         Sociable.base_stats["loyalty_traits"] = 5f;
         Sociable.base_stats["cities"] = 2;
         Sociable.base_stats["area_of_effect"] = 1;
////		 Sociable.opposite = "Mudo,Esquizofrenico";
 
  
         ActorTrait SuperRapido= new ActorTrait();
         SuperRapido.id = "Super Rapido";
         SuperRapido.path_icon = "ui/Icons/Super Rapido";
         SuperRapido.type = TraitType.Other;
         SuperRapido.group_id = TraitGroup.LegendaryTraits;
         SuperRapido.can_be_given = true;
         SuperRapido.can_be_removed = true;
         SuperRapido.rate_birth = 1;
         SuperRapido.rate_inherit = 1;
         AssetManager.traits.add(SuperRapido);
         SuperRapido.base_stats["multiplier_offspring"] = 0.05f;
         SuperRapido.base_stats["attack_speed"] = 170;
         SuperRapido.base_stats["speed"] = 80f;
         SuperRapido.base_stats["scale"] = -0.01f;
         SuperRapido.base_stats["loyalty_traits"] = 5f;
////		 SuperRapido.opposite = "slow,Apatico";
 
  
         ActorTrait SuperFuerte= new ActorTrait();
         SuperFuerte.id = "Super Fuerte";
         SuperFuerte.path_icon = "ui/Icons/Super_Fuerza";
         SuperFuerte.type = TraitType.Other;
         SuperFuerte.group_id = TraitGroup.LegendaryTraits;
         SuperFuerte.can_be_given = true;
         SuperFuerte.can_be_removed = true;
         SuperFuerte.rate_birth = 1;
         SuperFuerte.rate_inherit = 1;
         AssetManager.traits.add(SuperFuerte);
         SuperFuerte.base_stats["damage"] = 90;
         SuperFuerte.base_stats["armor"] = 20;
         SuperFuerte.base_stats["opinion"] = 10f;
////		 SuperFuerte.opposite = "weak,Anorexico,Esquizofrenico,EnfermoMental,Sidoso";
 
  
         ActorTrait Timido= new ActorTrait();
         Timido.id = "Timido";
         Timido.path_icon = "ui/Icons/Timido";
         Timido.type = TraitType.Other;
         Timido.group_id = TraitGroup.NaturalTraits;
         Timido.can_be_given = true;
         Timido.can_be_removed = true;
         Timido.rate_birth = 1;
         Timido.rate_inherit = 1;
         AssetManager.traits.add(Timido);
         Timido.base_stats["multiplier_offspring"] = 0.2f;
         Timido.base_stats["birth_rate"] = 1;
         Timido.base_stats["attack_speed"] = 2;
         Timido.base_stats["damage"] = -5;
         Timido.base_stats["speed"] = 2f;
         Timido.base_stats["skill_combat"] = -0.5f;
         Timido.base_stats["critical_chance"] = -0.2f;
         Timido.base_stats["intelligence"] = -3;
         Timido.base_stats["opinion"] = 9f;
         Timido.base_stats["loyalty_traits"] = 5f;
////		 Timido.opposite = "Orgulloso,Valiente";
 
  
         ActorTrait Adaptable= new ActorTrait();
         Adaptable.id = "Adaptable";
         Adaptable.path_icon = "ui/Icons/Adaptable";
         Adaptable.type = TraitType.Other;
         Adaptable.group_id = TraitGroup.LegendaryTraits;
         Adaptable.can_be_given = true;
         Adaptable.can_be_removed = true;
         Adaptable.rate_birth = 1;
         Adaptable.rate_inherit = 1;
         AssetManager.traits.add(Adaptable);
         Adaptable.base_stats["multiplier_offspring"] = 0.2f;
         Adaptable.base_stats["birth_rate"] = 1;
         Adaptable.base_stats["multiplier_lifespan"] = 3f;
         Adaptable.base_stats["health"] = 5;
         Adaptable.base_stats["accuracy"] = 1f;
         Adaptable.base_stats["range"] = 0.1f;
         Adaptable.base_stats["armor"] = 1;
         Adaptable.base_stats["critical_chance"] = 0.2f;
         Adaptable.base_stats["knockback"] = 0.2f;
//         Adaptable.base_stats["knockback_reduction"] = 0.030f;
         Adaptable.base_stats["intelligence"] = 2;
         Adaptable.base_stats["warfare"] = 2;
         Adaptable.base_stats["diplomacy"] = 2;
         Adaptable.base_stats["stewardship"] = 3;
         Adaptable.base_stats["opinion"] = 10f;
         Adaptable.base_stats["loyalty_traits"] = 5f;
         Adaptable.base_stats["cities"] = 2;
         Adaptable.base_stats["area_of_effect"] = 2;
	 
  
         ActorTrait Traicionero= new ActorTrait();
         Traicionero.id = "Traicionero";
         Traicionero.path_icon = "ui/Icons/Traicionero";
         Traicionero.type = TraitType.Other;
         Traicionero.group_id = TraitGroup.BadNaturalTraits;
         Traicionero.can_be_given = true;
         Traicionero.can_be_removed = true;
         Traicionero.rate_birth = 1;
         Traicionero.rate_inherit = 1;
         AssetManager.traits.add(Traicionero);
         Traicionero.base_stats["multiplier_offspring"] = 0.2f;
         Traicionero.base_stats["birth_rate"] = 1;
         Traicionero.base_stats["accuracy"] = -0.20f;
         Traicionero.base_stats["intelligence"] = 3;
         Traicionero.base_stats["opinion"] = -5f;
         Traicionero.base_stats["loyalty_traits"] = -10f;
////		 Traicionero.opposite = "Leal";
		 	 
  
         ActorTrait Arriesgado= new ActorTrait();
         Arriesgado.id = "Arriesgado";
         Arriesgado.path_icon = "ui/Icons/Arriesgado";
         Arriesgado.type = TraitType.Other;
         Arriesgado.group_id = TraitGroup.NaturalTraits;
         Arriesgado.can_be_given = true;
         Arriesgado.can_be_removed = true;
         Arriesgado.rate_birth = 1;
         Arriesgado.rate_inherit = 1;
         AssetManager.traits.add(Arriesgado);
         Arriesgado.base_stats["birth_rate"] = 1;
         Arriesgado.base_stats["multiplier_lifespan"] = -10f;
         Arriesgado.base_stats["attack_speed"] = 10;
         Arriesgado.base_stats["speed"] = 3f;
         Arriesgado.base_stats["warfare"] = 2;
         Arriesgado.base_stats["opinion"] = 1f;
         Arriesgado.base_stats["cities"] = 5;
         Arriesgado.base_stats["area_of_effect"] = 2;
////		 Arriesgado.opposite = "Timido,Miedoso";
	 
  
         ActorTrait Compasivo= new ActorTrait();
         Compasivo.id = "Compasivo";
         Compasivo.path_icon = "ui/Icons/Compasivo";
         Compasivo.type = TraitType.Other;
         Compasivo.group_id = TraitGroup.NaturalTraits;
         Compasivo.can_be_given = true;
         Compasivo.can_be_removed = true;
         Compasivo.rate_birth = 1;
         Compasivo.rate_inherit = 1;
         AssetManager.traits.add(Compasivo);
         Compasivo.base_stats["multiplier_offspring"] = 0.3f;
         Compasivo.base_stats["birth_rate"] = 1;
         Compasivo.base_stats["multiplier_lifespan"] = 1f;
         Compasivo.base_stats["health"] = 5;
         Compasivo.base_stats["stewardship"] = 10;
         Compasivo.base_stats["opinion"] = 10f;
////		 Compasivo.opposite = "Cruel";
	 
  
         ActorTrait Comprensible= new ActorTrait();
         Comprensible.id = "Comprensible";
         Comprensible.path_icon = "ui/Icons/Comprensible";
         Comprensible.type = TraitType.Other;
         Comprensible.group_id = TraitGroup.NaturalTraits;
         Comprensible.can_be_given = true;
         Comprensible.can_be_removed = true;
         Comprensible.rate_birth = 1;
         Comprensible.rate_inherit = 1;
         AssetManager.traits.add(Comprensible);
         Comprensible.base_stats["multiplier_lifespan"] = 5f;
         Comprensible.base_stats["accuracy"] = 0.50f;
         Comprensible.base_stats["intelligence"] = 1;
         Comprensible.base_stats["diplomacy"] = 5;
         Comprensible.base_stats["opinion"] = 10f;
         Comprensible.base_stats["loyalty_traits"] = 2f;
////		 Comprensible.opposite = "Estupido,Mudo,stupid";
	 
  
         ActorTrait Comprometido= new ActorTrait();
         Comprometido.id = "Comprometido";
         Comprometido.path_icon = "ui/Icons/Comprometido";
         Comprometido.type = TraitType.Other;
         Comprometido.group_id = TraitGroup.NaturalTraits;
         Comprometido.can_be_given = true;
         Comprometido.can_be_removed = true;
         Comprometido.rate_birth = 1;
         Comprometido.rate_inherit = 1;
         AssetManager.traits.add(Comprometido);
         Comprometido.base_stats["multiplier_damage"] = 0.02f;
         Comprometido.base_stats["health"] = 5;
         Comprometido.base_stats["range"] = 0.2f;
         Comprometido.base_stats["skill_combat"] = 0.4f;
         Comprometido.base_stats["critical_chance"] = 0.1f;
         Comprometido.base_stats["knockback"] = 0.2f;
//         Comprometido.base_stats["knockback_reduction"] = 0.01f;
         Comprometido.base_stats["diplomacy"] = 3;
         Comprometido.base_stats["stewardship"] = 4;
         Comprometido.base_stats["opinion"] = 4f;
         Comprometido.base_stats["loyalty_traits"] = 3.40f;
	 
  
         ActorTrait Dotado= new ActorTrait();
         Dotado.id = "Dotado";
         Dotado.path_icon = "ui/Icons/Dotado";
         Dotado.type = TraitType.Other;
         Dotado.group_id = TraitGroup.LegendaryTraits;
         Dotado.can_be_given = true;
         Dotado.can_be_removed = true;
         Dotado.rate_birth = 1;
         Dotado.rate_inherit = 1;
         AssetManager.traits.add(Dotado);
         Dotado.base_stats["multiplier_offspring"] = 0.7f;
         Dotado.base_stats["birth_rate"] = 1;
         Dotado.base_stats["multiplier_lifespan"] = 70f;
         Dotado.base_stats["attack_speed"] = 20;
         Dotado.base_stats["damage"] = 65;
         Dotado.base_stats["speed"] = 20f;
         Dotado.base_stats["health"] = 40;
         Dotado.base_stats["accuracy"] = 50f;
         Dotado.base_stats["range"] = 0.5f;
         Dotado.base_stats["armor"] = 10;
         Dotado.base_stats["skill_combat"] = 10f;
         Dotado.base_stats["critical_chance"] = 0.7f;
         Dotado.base_stats["knockback"] = 0.8f;
//         Dotado.base_stats["knockback_reduction"] = 1.0f;
         Dotado.base_stats["intelligence"] = 15;
         Dotado.base_stats["warfare"] = 10;
         Dotado.base_stats["diplomacy"] = 15;
         Dotado.base_stats["stewardship"] = 20;
         Dotado.base_stats["opinion"] = 50f;
         Dotado.base_stats["loyalty_traits"] = 5f;
         Dotado.base_stats["cities"] = 15;
         Dotado.base_stats["area_of_effect"] = 20;
////		 Dotado.opposite = "EnfermoMental,weak,Anorexico";
	 
  
         ActorTrait Egocentrico= new ActorTrait();
         Egocentrico.id = "Egocentrico";
         Egocentrico.path_icon = "ui/Icons/Egocentrico";
         Egocentrico.type = TraitType.Other;
         Egocentrico.group_id = TraitGroup.BadNaturalTraits;
         Egocentrico.can_be_given = true;
         Egocentrico.can_be_removed = true;
         Egocentrico.rate_birth = 1;
         Egocentrico.rate_inherit = 1;
         AssetManager.traits.add(Egocentrico);
         Egocentrico.base_stats["multiplier_offspring"] = -0.2f;
         Egocentrico.base_stats["birth_rate"] = 1;
         Egocentrico.base_stats["armor"] = 2;
         Egocentrico.base_stats["skill_combat"] = 0.32f;
         Egocentrico.base_stats["knockback"] = 0.2f;
         Egocentrico.base_stats["intelligence"] = -4;
         Egocentrico.base_stats["opinion"] = -18f;
         Egocentrico.base_stats["loyalty_traits"] = -10f;
	 
  
         ActorTrait Empatico= new ActorTrait();
         Empatico.id = "Empatico";
         Empatico.path_icon = "ui/Icons/Empatico";
         Empatico.type = TraitType.Other;
         Empatico.group_id = TraitGroup.NaturalTraits;
         Empatico.can_be_given = true;
         Empatico.can_be_removed = true;
         Empatico.rate_birth = 1;
         Empatico.rate_inherit = 1;
         AssetManager.traits.add(Empatico);
         Empatico.base_stats["multiplier_offspring"] = 0.3f;
         Empatico.base_stats["birth_rate"] = 1;
         Empatico.base_stats["health"] = 12;
         Empatico.base_stats["range"] = 0.5f;
         Empatico.base_stats["armor"] = 6;
         Empatico.base_stats["stewardship"] = 5;
         Empatico.base_stats["opinion"] = 5f;
         Empatico.base_stats["loyalty_traits"] = 6f;
////		 Empatico.opposite = "Cruel";
	 
  
         ActorTrait Entrometido= new ActorTrait();
         Entrometido.id = "Entrometido";
         Entrometido.path_icon = "ui/Icons/Entrometido";
         Entrometido.type = TraitType.Other;
         Entrometido.group_id = TraitGroup.BadNaturalTraits;
         Entrometido.can_be_given = true;
         Entrometido.can_be_removed = true;
         Entrometido.rate_birth = 1;
         Entrometido.rate_inherit = 1;
         AssetManager.traits.add(Entrometido);
         Entrometido.base_stats["opinion"] = -3f;
         Entrometido.base_stats["cities"] = 6;
         Entrometido.base_stats["area_of_effect"] = 6;
		 		 		 		 		 		 		 		 
	 
         ActorTrait Honorable= new ActorTrait();
         Honorable.id = "Honorable";
         Honorable.path_icon = "ui/Icons/Honorable";
         Honorable.type = TraitType.Other;
         Honorable.group_id = TraitGroup.NaturalTraits;
         Honorable.can_be_given = true;
         Honorable.can_be_removed = true;
         Honorable.rate_birth = 1;
         Honorable.rate_inherit = 1;
         AssetManager.traits.add(Honorable);
         Honorable.base_stats["multiplier_offspring"] = 0.3f;
         Honorable.base_stats["birth_rate"] = 1;
         Honorable.base_stats["multiplier_lifespan"] = 12f;
         Honorable.base_stats["stewardship"] = 3;
         Honorable.base_stats["opinion"] = 18f;
         Honorable.base_stats["loyalty_traits"] = 20f;
////		 Honorable.opposite = "Insensato";
		 
  
         ActorTrait Imponente= new ActorTrait();
         Imponente.id = "Imponente";
         Imponente.path_icon = "ui/Icons/Imponente";
         Imponente.type = TraitType.Other;
         Imponente.group_id = TraitGroup.NaturalTraits;
         Imponente.can_be_given = true;
         Imponente.can_be_removed = true;
         Imponente.rate_birth = 1;
         Imponente.rate_inherit = 1;
         AssetManager.traits.add(Imponente);
         Imponente.base_stats["multiplier_offspring"] = 0.3f;
         Imponente.base_stats["birth_rate"] = 1;
         Imponente.base_stats["multiplier_lifespan"] = 10f;
         Imponente.base_stats["attack_speed"] = 15;
         Imponente.base_stats["multiplier_damage"] = 0.25f;
         Imponente.base_stats["scale"] = 0.008f;
         Imponente.base_stats["critical_chance"] = 0.1f;
         Imponente.base_stats["diplomacy"] = -5;
         Imponente.base_stats["opinion"] = 30f;
////		 Imponente.opposite = "paranoid,tiny";
	 
  
         ActorTrait Irresponsable= new ActorTrait();
         Irresponsable.id = "Irresponsable";
         Irresponsable.path_icon = "ui/Icons/Irresponsable";
         Irresponsable.type = TraitType.Other;
         Irresponsable.group_id = TraitGroup.BadNaturalTraits;
         Irresponsable.can_be_given = true;
         Irresponsable.can_be_removed = true;
         Irresponsable.rate_birth = 1;
         Irresponsable.rate_inherit = 1;
         AssetManager.traits.add(Irresponsable);
         Irresponsable.base_stats["skill_combat"] = -0.54f;
         Irresponsable.base_stats["warfare"] = -4;
         Irresponsable.base_stats["diplomacy"] = -3;
         Irresponsable.base_stats["opinion"] = -5f;
         Irresponsable.base_stats["loyalty_traits"] = -4f;
         Irresponsable.base_stats["cities"] = -9;
         Irresponsable.base_stats["area_of_effect"] = -6;
////		 Irresponsable.opposite = "Organizado,Responsable";
	 
  
         ActorTrait Leal= new ActorTrait();
         Leal.id = "Leal";
         Leal.path_icon = "ui/Icons/Leal";
         Leal.type = TraitType.Other;
         Leal.group_id = TraitGroup.NaturalTraits;
         Leal.can_be_given = true;
         Leal.can_be_removed = true;
         Leal.rate_birth = 1;
         Leal.rate_inherit = 1;
         AssetManager.traits.add(Leal);
         Leal.base_stats["birth_rate"] = 1;
         Leal.base_stats["loyalty_traits"] = 40f;
////		 Leal.opposite = "Desleal,Traicionero";
	 
  
         ActorTrait Manipulador= new ActorTrait();
         Manipulador.id = "Manipulador";
         Manipulador.path_icon = "ui/Icons/Manipulador";
         Manipulador.type = TraitType.Other;
         Manipulador.group_id = TraitGroup.BadNaturalTraits;
         Manipulador.can_be_given = true;
         Manipulador.can_be_removed = true;
         Manipulador.rate_birth = 1;
         Manipulador.rate_inherit = 1;
         AssetManager.traits.add(Manipulador);
         Manipulador.base_stats["multiplier_offspring"] = -0.1f;
         Manipulador.base_stats["birth_rate"] = 1;
         Manipulador.base_stats["intelligence"] = 4;
         Manipulador.base_stats["warfare"] = 3.21f;
         Manipulador.base_stats["diplomacy"] = 4.345f;
         Manipulador.base_stats["stewardship"] = 4.34f;
         Manipulador.base_stats["opinion"] = 5.51f;
         Manipulador.base_stats["loyalty_traits"] = 3.221f;
         Manipulador.base_stats["cities"] = 2;
         Manipulador.base_stats["area_of_effect"] = 3;
	 
  
         ActorTrait Paciente= new ActorTrait();
         Paciente.id = "Paciente";
         Paciente.path_icon = "ui/Icons/Paciente";
         Paciente.type = TraitType.Other;
         Paciente.group_id = TraitGroup.NaturalTraits;
         Paciente.can_be_given = true;
         Paciente.can_be_removed = true;
         Paciente.rate_birth = 1;
         Paciente.rate_inherit = 1;
         AssetManager.traits.add(Paciente);
         Paciente.base_stats["warfare"] = 1;
         Paciente.base_stats["multiplier_diplomacy"] = 0.2f;
         Paciente.base_stats["opinion"] = 5f;
////		 Paciente.opposite = "Impaciente";
	 
  
         ActorTrait Raro= new ActorTrait();
         Raro.id = "Raro";
         Raro.path_icon = "ui/Icons/Raro";
         Raro.type = TraitType.Other;
         Raro.group_id = TraitGroup.Physicalconditions;
         Raro.can_be_given = true;
         Raro.can_be_removed = true;
         Raro.rate_birth = 1;
         Raro.rate_inherit = 1;
         AssetManager.traits.add(Raro);
         Raro.base_stats["birth_rate"] = 1;
         Raro.base_stats["range"] = -0.2f;
         Raro.base_stats["warfare"] = -4.4f;
         Raro.base_stats["opinion"] = -7f;
         Raro.base_stats["cities"] = -4;
         Raro.base_stats["area_of_effect"] = -4;
////		 Raro.opposite = "Imponente,Simetrico";
	 
  
         ActorTrait Rechazado= new ActorTrait();
         Rechazado.id = "Rechazado";
         Rechazado.path_icon = "ui/Icons/Rechazado";
         Rechazado.type = TraitType.Other;
         Rechazado.group_id = TraitGroup.BadNaturalTraits;
         Rechazado.can_be_given = true;
         Rechazado.can_be_removed = true;
         Rechazado.rate_birth = 1;
         Rechazado.rate_inherit = 1;
         AssetManager.traits.add(Rechazado);
         Rechazado.base_stats["opinion"] = -100f;
         Rechazado.base_stats["cities"] = -1;
         Rechazado.base_stats["area_of_effect"] = -1;
////		 Rechazado.opposite = "Aceptado";
	 
  
         ActorTrait Reflexivo= new ActorTrait();
         Reflexivo.id = "Reflexivo";
         Reflexivo.path_icon = "ui/Icons/Reflexivo";
         Reflexivo.type = TraitType.Other;
         Reflexivo.group_id = TraitGroup.NaturalTraits;
         Reflexivo.can_be_given = true;
         Reflexivo.can_be_removed = true;
         Reflexivo.rate_birth = 1;
         Reflexivo.rate_inherit = 1;
         AssetManager.traits.add(Reflexivo);
         Reflexivo.base_stats["armor"] = 2;
         Reflexivo.base_stats["warfare"] = -3.70f;
         Reflexivo.base_stats["diplomacy"] = -4;
         Reflexivo.base_stats["opinion"] = 3f;
         Reflexivo.base_stats["loyalty_traits"] = -2f;
         Reflexivo.base_stats["cities"] = -2;
////		 Reflexivo.opposite = "";
	 
  
         ActorTrait Responsable= new ActorTrait();
         Responsable.id = "Responsable";
         Responsable.path_icon = "ui/Icons/Responsable";
         Responsable.type = TraitType.Other;
         Responsable.group_id = TraitGroup.NaturalTraits;
         Responsable.can_be_given = true;
         Responsable.can_be_removed = true;
         Responsable.rate_birth = 1;
         Responsable.rate_inherit = 1;
         AssetManager.traits.add(Responsable);
         Responsable.base_stats["birth_rate"] = 1;
         Responsable.base_stats["intelligence"] = 1;
         Responsable.base_stats["diplomacy"] = 10;
         Responsable.base_stats["stewardship"] = 8;
         Responsable.base_stats["opinion"] = 7f;
         Responsable.base_stats["cities"] = 10;
	 		 		 
					 
         ActorTrait Analitico= new ActorTrait();
         Analitico.id = "Analitico";
         Analitico.path_icon = "ui/Icons/Analitico";
         Analitico.type = TraitType.Other;
         Analitico.group_id = TraitGroup.NaturalTraits;
         Analitico.can_be_given = true;
         Analitico.can_be_removed = true;
         Analitico.rate_birth = 1;
         Analitico.rate_inherit = 1;
         AssetManager.traits.add(Analitico);
         Analitico.base_stats["multiplier_lifespan"] = 2f;
         Analitico.base_stats["speed"] = 2f;
         Analitico.base_stats["intelligence"] = 1;
         Analitico.base_stats["opinion"] = 2f;
         Analitico.base_stats["cities"] = 1;
         Analitico.base_stats["area_of_effect"] = 1;
		 		 		 		 		 		 
					 
         ActorTrait Apasionado= new ActorTrait();
         Apasionado.id = "Apasionado";
         Apasionado.path_icon = "ui/Icons/Apasionado";
         Apasionado.type = TraitType.Other;
         Apasionado.group_id = TraitGroup.NaturalTraits;
         Apasionado.can_be_given = true;
         Apasionado.can_be_removed = true;
         Apasionado.rate_birth = 1;
         Apasionado.rate_inherit = 1;
         AssetManager.traits.add(Apasionado);
         Apasionado.base_stats["multiplier_offspring"] = 0.12f;
         Apasionado.base_stats["birth_rate"] = 1;
         Apasionado.base_stats["multiplier_lifespan"] = 10f;
         Apasionado.base_stats["intelligence"] = 1;
         Apasionado.base_stats["warfare"] = 2;
         Apasionado.base_stats["opinion"] = 3f;
         Apasionado.base_stats["loyalty_traits"] = 4f;
         Apasionado.base_stats["cities"] = 2;
         Apasionado.base_stats["area_of_effect"] = 2;
		 		 		 		 		 		 
					 
         ActorTrait Autocontrolado= new ActorTrait();
         Autocontrolado.id = "Autocontrolado";
         Autocontrolado.path_icon = "ui/Icons/Autocontrolado";
         Autocontrolado.type = TraitType.Other;
         Autocontrolado.group_id = TraitGroup.NaturalTraits;
         Autocontrolado.can_be_given = true;
         Autocontrolado.can_be_removed = true;
         Autocontrolado.rate_birth = 1;
         Autocontrolado.rate_inherit = 1;
         AssetManager.traits.add(Autocontrolado);
         Autocontrolado.base_stats["birth_rate"] = 1;
         Autocontrolado.base_stats["intelligence"] = 1.70f;
         Autocontrolado.base_stats["warfare"] = 5;
         Autocontrolado.base_stats["diplomacy"] = 6;
         Autocontrolado.base_stats["loyalty_traits"] = 4f;
         Autocontrolado.base_stats["cities"] = 4;
         Autocontrolado.base_stats["area_of_effect"] = 2;
////		 Autocontrolado.opposite = "Descontrolado,Cruel,Psicopata";
		 		 		 		 		 		 
					 
         ActorTrait Burlon= new ActorTrait();
         Burlon.id = "Burlon";
         Burlon.path_icon = "ui/Icons/Burlon";
         Burlon.type = TraitType.Other;
         Burlon.group_id = TraitGroup.BadNaturalTraits;
         Burlon.can_be_given = true;
         Burlon.can_be_removed = true;
         Burlon.rate_birth = 1;
         Burlon.rate_inherit = 1;
         AssetManager.traits.add(Burlon);
         Burlon.base_stats["multiplier_offspring"] = -0.05f;
         Burlon.base_stats["birth_rate"] = 1;
         Burlon.base_stats["multiplier_lifespan"] = -7f;
         Burlon.base_stats["scale"] = 0.002f;
         Burlon.base_stats["stewardship"] = -3;
         Burlon.base_stats["opinion"] = -1f;
		 		 		 		 		 		 
					 
         ActorTrait Confiado= new ActorTrait();
         Confiado.id = "Confiado";
         Confiado.path_icon = "ui/Icons/Confiado";
         Confiado.type = TraitType.Other;
         Confiado.group_id = TraitGroup.NaturalTraits;
         Confiado.can_be_given = true;
         Confiado.can_be_removed = true;
         Confiado.rate_birth = 1;
         Confiado.rate_inherit = 1;
         AssetManager.traits.add(Confiado);
         Confiado.base_stats["birth_rate"] = 1;
         Confiado.base_stats["multiplier_lifespan"] = -2f;
         Confiado.base_stats["attack_speed"] = 2;
         Confiado.base_stats["damage"] = 6;
         Confiado.base_stats["intelligence"] = -15;
         Confiado.base_stats["opinion"] = 10f;
         Confiado.base_stats["cities"] = 1;
         Confiado.base_stats["area_of_effect"] = 1;
////		 Confiado.opposite = "Desconfiado";
		 		 		 		 		 		 
					 
         ActorTrait Creativo= new ActorTrait();
         Creativo.id = "Creativo";
         Creativo.path_icon = "ui/Icons/Creativo";
         Creativo.type = TraitType.Other;
         Creativo.group_id = TraitGroup.NaturalTraits;
         Creativo.can_be_given = true;
         Creativo.can_be_removed = true;
         Creativo.rate_birth = 1;
         Creativo.rate_inherit = 1;
         AssetManager.traits.add(Creativo);
         Creativo.base_stats["birth_rate"] = 1;
         Creativo.base_stats["intelligence"] = 4.40f;
         Creativo.base_stats["opinion"] = 3f;
		 		 		 		 		 		 
					 
         ActorTrait disciplinado= new ActorTrait();
         disciplinado.id = "disciplinado";
         disciplinado.path_icon = "ui/Icons/disciplinado";
         disciplinado.type = TraitType.Other;
         disciplinado.group_id = TraitGroup.NaturalTraits;
         disciplinado.can_be_given = true;
         disciplinado.can_be_removed = true;
         disciplinado.rate_birth = 1;
         disciplinado.rate_inherit = 1;
         AssetManager.traits.add(disciplinado);
         disciplinado.base_stats["multiplier_offspring"] = 1.0f;
         disciplinado.base_stats["birth_rate"] = 1;
         disciplinado.base_stats["multiplier_lifespan"] = 2f;
         disciplinado.base_stats["attack_speed"] = 2;
         disciplinado.base_stats["damage"] = 0.40f;
         disciplinado.base_stats["speed"] = 3.80f;
         disciplinado.base_stats["health"] = 23;
         disciplinado.base_stats["range"] = 0.2f;
         disciplinado.base_stats["armor"] = 3;
         disciplinado.base_stats["skill_combat"] = 0.2f;
         disciplinado.base_stats["intelligence"] = -1;
         disciplinado.base_stats["opinion"] = 16f;
         disciplinado.base_stats["cities"] = 5;
         disciplinado.base_stats["area_of_effect"] = 5;
		 		 		 		 		 		 
					 
         ActorTrait Estupido= new ActorTrait();
         Estupido.id = "Estupido";
         Estupido.path_icon = "ui/Icons/Estupido";
         Estupido.type = TraitType.Other;
         Estupido.group_id = TraitGroup.BadNaturalTraits;
         Estupido.can_be_given = true;
         Estupido.can_be_removed = true;
         Estupido.rate_birth = 1;
         Estupido.rate_inherit = 1;
         AssetManager.traits.add(Estupido);
         Estupido.base_stats["multiplier_offspring"] = -1.2f;
         Estupido.base_stats["birth_rate"] = 1;
         Estupido.base_stats["multiplier_lifespan"] = -3f;
         Estupido.base_stats["intelligence"] = -3;
         Estupido.base_stats["opinion"] = -7f;
////		 Estupido.opposite = "SuperInteligente,Creativo,genius,Coherente";
		 		 		 		 		 		 
					 
         ActorTrait Flexible= new ActorTrait();
         Flexible.id = "Flexible";
         Flexible.path_icon = "ui/Icons/Flexible";
         Flexible.type = TraitType.Other;
         Flexible.group_id = TraitGroup.NaturalTraits;
         Flexible.can_be_given = true;
         Flexible.can_be_removed = true;
         Flexible.rate_birth = 1;
         Flexible.rate_inherit = 1;
         AssetManager.traits.add(Flexible);
         Flexible.base_stats["birth_rate"] = 1;
         Flexible.base_stats["diplomacy"] = 13;
         Flexible.base_stats["stewardship"] = 2;
         Flexible.base_stats["opinion"] = 2f;
         Flexible.base_stats["cities"] = -1;
         Flexible.base_stats["area_of_effect"] = -2;
		 		 		 		 		 		 
					 
         ActorTrait Generoso= new ActorTrait();
         Generoso.id = "Generoso";
         Generoso.path_icon = "ui/Icons/Generoso";
         Generoso.type = TraitType.Other;
         Generoso.group_id = TraitGroup.NaturalTraits;
         Generoso.can_be_given = true;
         Generoso.can_be_removed = true;
         Generoso.rate_birth = 1;
         Generoso.rate_inherit = 1;
         AssetManager.traits.add(Generoso);
         Generoso.base_stats["multiplier_offspring"] = 0.2f;
         Generoso.base_stats["birth_rate"] = 1;
         Generoso.base_stats["multiplier_lifespan"] = -2f;
         Generoso.base_stats["accuracy"] = 0.2f;
         Generoso.base_stats["opinion"] = 5f;
         Generoso.base_stats["cities"] = -4;
         Generoso.base_stats["area_of_effect"] = -4;
		 		 		 		 		 		 
					 
         ActorTrait Humilde= new ActorTrait();
         Humilde.id = "Humilde";
         Humilde.path_icon = "ui/Icons/Humilde";
         Humilde.type = TraitType.Other;
         Humilde.group_id = TraitGroup.NaturalTraits;
         Humilde.can_be_given = true;
         Humilde.can_be_removed = true;
         Humilde.rate_birth = 1;
         Humilde.rate_inherit = 1;
         AssetManager.traits.add(Humilde);
         Humilde.base_stats["birth_rate"] = 1;
         Humilde.base_stats["damage"] = -5;
         Humilde.base_stats["intelligence"] = -2;
         Humilde.base_stats["warfare"] = 2;
         Humilde.base_stats["diplomacy"] = 4;
         Humilde.base_stats["loyalty_traits"] = 3f;
         Humilde.base_stats["area_of_effect"] = -7;
		 		 		 		 		 		 
					 
         ActorTrait Iniciativo= new ActorTrait();
         Iniciativo.id = "Iniciativo";
         Iniciativo.path_icon = "ui/Icons/Iniciativo";
         Iniciativo.type = TraitType.Other;
         Iniciativo.group_id = TraitGroup.NaturalTraits;
         Iniciativo.can_be_given = true;
         Iniciativo.can_be_removed = true;
         Iniciativo.rate_birth = 1;
         Iniciativo.rate_inherit = 1;
         AssetManager.traits.add(Iniciativo);
         Iniciativo.base_stats["multiplier_offspring"] = 0.10f;
         Iniciativo.base_stats["birth_rate"] = 1;
         Iniciativo.base_stats["attack_speed"] = 4;
         Iniciativo.base_stats["speed"] = 7f;
         Iniciativo.base_stats["range"] = 1.22f;
         Iniciativo.base_stats["critical_chance"] = 0.20f;
         Iniciativo.base_stats["knockback"] = 0.6f;
//         Iniciativo.base_stats["knockback_reduction"] = 0.23f;
         Iniciativo.base_stats["intelligence"] = 3;
         Iniciativo.base_stats["warfare"] = 10;
         Iniciativo.base_stats["diplomacy"] = -3;
         Iniciativo.base_stats["loyalty_traits"] = 2f;
         Iniciativo.base_stats["cities"] = 6;
         Iniciativo.base_stats["area_of_effect"] = 7;
////		 Iniciativo.opposite = "Apatico,Introvertido";
		 		 		 		 		 		 
					 
         ActorTrait Observador= new ActorTrait();
         Observador.id = "Observador";
         Observador.path_icon = "ui/Icons/Observador";
         Observador.type = TraitType.Other;
         Observador.group_id = TraitGroup.NaturalTraits;
         Observador.can_be_given = true;
         Observador.can_be_removed = true;
         Observador.rate_birth = 1;
         Observador.rate_inherit = 1;
         AssetManager.traits.add(Observador);
         Observador.base_stats["birth_rate"] = 1;
         Observador.base_stats["speed"] = -12.80f;
         Observador.base_stats["armor"] = 5;
         Observador.base_stats["intelligence"] = 4;
         Observador.base_stats["diplomacy"] = 12;
         Observador.base_stats["stewardship"] = -4;
         Observador.base_stats["opinion"] = 4f;
         Observador.base_stats["cities"] = 3;
         Observador.base_stats["area_of_effect"] = 2;
		 		 		 		 		 		 
					 
         ActorTrait Pesimista= new ActorTrait();
         Pesimista.id = "Pesimista";
         Pesimista.path_icon = "ui/Icons/Pesimista";
         Pesimista.type = TraitType.Other;
         Pesimista.group_id = TraitGroup.BadNaturalTraits;
         Pesimista.can_be_given = true;
         Pesimista.can_be_removed = true;
         Pesimista.rate_birth = 1;
         Pesimista.rate_inherit = 1;
         AssetManager.traits.add(Pesimista);
         Pesimista.base_stats["birth_rate"] = 1;
         Pesimista.base_stats["intelligence"] = -3;
         Pesimista.base_stats["diplomacy"] = -10;
         Pesimista.base_stats["opinion"] = -5f;
////		 Pesimista.opposite = "Optimista";
		 		 		 		 		 		 
					 
         ActorTrait Serio= new ActorTrait();
         Serio.id = "Serio";
         Serio.path_icon = "ui/Icons/Serio";
         Serio.type = TraitType.Other;
         Serio.group_id = TraitGroup.NaturalTraits;
         Serio.can_be_given = true;
         Serio.can_be_removed = true;
         Serio.rate_birth = 1;
         Serio.rate_inherit = 1;
         AssetManager.traits.add(Serio);
         Serio.base_stats["birth_rate"] = 1;
         Serio.base_stats["damage"] = 3.70f;
         Serio.base_stats["speed"] = 3f;
         Serio.base_stats["health"] = 1;
         Serio.base_stats["accuracy"] = 0.60f;
         Serio.base_stats["intelligence"] = 2;
         Serio.base_stats["stewardship"] = 10;
         Serio.base_stats["opinion"] = 2f;
         Serio.base_stats["loyalty_traits"] = 4f;
         Serio.base_stats["area_of_effect"] = 10;
////		 Serio.opposite = "Inmaduro";
		 		 		 		 		 		 
					 
         ActorTrait Solitario= new ActorTrait();
         Solitario.id = "Solitario";
         Solitario.path_icon = "ui/Icons/Solitario";
         Solitario.type = TraitType.Other;
         Solitario.group_id = TraitGroup.NaturalTraits;
         Solitario.can_be_given = true;
         Solitario.can_be_removed = true;
         Solitario.rate_birth = 1;
         Solitario.rate_inherit = 1;
         AssetManager.traits.add(Solitario);
         Solitario.base_stats["multiplier_offspring"] = 1.0f;
         Solitario.base_stats["attack_speed"] = 6;
         Solitario.base_stats["speed"] = 6f;
         Solitario.base_stats["health"] = 40;
         Solitario.base_stats["intelligence"] = 10;
         Solitario.base_stats["opinion"] = -5f;
         Solitario.base_stats["loyalty_traits"] = -10f;
////		 Solitario.opposite = "Sociable";
		 
					 
         ActorTrait SuperInteligente= new ActorTrait();
         SuperInteligente.id = "Super Inteligente";
         SuperInteligente.path_icon = "ui/Icons/Super Inteligente";
         SuperInteligente.type = TraitType.Other;
         SuperInteligente.group_id = TraitGroup.LegendaryTraits;
         SuperInteligente.can_be_given = true;
         SuperInteligente.can_be_removed = true;
         SuperInteligente.rate_birth = 1;
         SuperInteligente.rate_inherit = 1;
         AssetManager.traits.add(SuperInteligente);
         SuperInteligente.base_stats["multiplier_offspring"] = 1.0f;
         SuperInteligente.base_stats["intelligence"] = 70;
         SuperInteligente.base_stats["warfare"] = 60;
         SuperInteligente.base_stats["diplomacy"] = 40;
         SuperInteligente.base_stats["stewardship"] = 5;
         SuperInteligente.base_stats["opinion"] = 50f;
         SuperInteligente.base_stats["cities"] = 5;
         SuperInteligente.base_stats["area_of_effect"] = 5;
////		 SuperInteligente.opposite = "stupid,Esquizofrenico,Estupido";
		 		 		 		 		 		 		 		 		 		 		 		 
					 
         ActorTrait Torpe= new ActorTrait();
         Torpe.id = "Torpe";
         Torpe.path_icon = "ui/Icons/Torpe";
         Torpe.type = TraitType.Other;
         Torpe.group_id = TraitGroup.BadNaturalTraits;
         Torpe.can_be_given = true;
         Torpe.can_be_removed = true;
         Torpe.rate_birth = 1;
         Torpe.rate_inherit = 1;
         AssetManager.traits.add(Torpe);
         Torpe.base_stats["multiplier_offspring"] = -0.02f;
         Torpe.base_stats["attack_speed"] = -3;
         Torpe.base_stats["speed"] = -6f;
         Torpe.base_stats["skill_combat"] = -0.20f;
         Torpe.base_stats["intelligence"] = -2;
         Torpe.base_stats["warfare"] = -4;
         Torpe.base_stats["diplomacy"] = -20;
         Torpe.base_stats["opinion"] = 2f;
         Torpe.base_stats["loyalty_traits"] = -3f;
		 
					 
         ActorTrait Trabajador= new ActorTrait();
         Trabajador.id = "Trabajador";
         Trabajador.path_icon = "ui/Icons/Trabajador";
         Trabajador.type = TraitType.Other;
         Trabajador.group_id = TraitGroup.NaturalTraits;
         Trabajador.can_be_given = true;
         Trabajador.can_be_removed = true;
         Trabajador.rate_birth = 1;
         Trabajador.rate_inherit = 1;
         AssetManager.traits.add(Trabajador);
         Trabajador.base_stats["multiplier_offspring"] = 0.21f;
         Trabajador.base_stats["birth_rate"] = 1;
         Trabajador.base_stats["multiplier_lifespan"] = 6f;
         Trabajador.base_stats["attack_speed"] = 5;
         Trabajador.base_stats["damage"] = 0.20f;
         Trabajador.base_stats["speed"] = 2f;
         Trabajador.base_stats["armor"] = 3;
         Trabajador.base_stats["critical_chance"] = 0.5f;
         Trabajador.base_stats["intelligence"] = 10;
         Trabajador.base_stats["opinion"] = 7f;
         Trabajador.base_stats["cities"] = 2;
         Trabajador.base_stats["area_of_effect"] = 2;
		 
					 
         ActorTrait Valiente= new ActorTrait();
         Valiente.id = "Valiente";
         Valiente.path_icon = "ui/Icons/Valiente";
         Valiente.type = TraitType.Other;
         Valiente.group_id = TraitGroup.NaturalTraits;
         Valiente.can_be_given = true;
         Valiente.can_be_removed = true;
         Valiente.rate_birth = 1;
         Valiente.rate_inherit = 1;
         AssetManager.traits.add(Valiente);
         Valiente.base_stats["multiplier_offspring"] = 1.0f;
         Valiente.base_stats["attack_speed"] = 10;
         Valiente.base_stats["speed"] = 9f;
         Valiente.base_stats["health"] = 12;
         Valiente.base_stats["range"] = 0.090f;
         Valiente.base_stats["armor"] = 5;
         Valiente.base_stats["scale"] = 0.001f;
         Valiente.base_stats["skill_combat"] = 0.3f;
         Valiente.base_stats["intelligence"] = 5;
         Valiente.base_stats["warfare"] = 3;
         Valiente.base_stats["diplomacy"] = 2;
         Valiente.base_stats["opinion"] = 3f;
         Valiente.base_stats["cities"] = 2;
         Valiente.base_stats["area_of_effect"] = 2;
		 
					 
         ActorTrait Aceptado= new ActorTrait();
         Aceptado.id = "Aceptado";
         Aceptado.path_icon = "ui/Icons/Aceptado";
         Aceptado.type = TraitType.Other;
         Aceptado.group_id = TraitGroup.NaturalTraits;
         Aceptado.can_be_given = true;
         Aceptado.can_be_removed = true;
         Aceptado.rate_birth = 1;
         Aceptado.rate_inherit = 1;
         AssetManager.traits.add(Aceptado);
         Aceptado.base_stats["opinion"] = 100f;
		 
					 
         ActorTrait Administrativo= new ActorTrait();
         Administrativo.id = "Administrativo";
         Administrativo.path_icon = "ui/Icons/Administrativo";
         Administrativo.type = TraitType.Other;
         Administrativo.group_id = TraitGroup.NaturalTraits;
         Administrativo.can_be_given = true;
         Administrativo.can_be_removed = true;
         Administrativo.rate_birth = 1;
         Administrativo.rate_inherit = 1;
         AssetManager.traits.add(Administrativo);
         Administrativo.base_stats["stewardship"] = 30;
		 
					 
         ActorTrait Asocial= new ActorTrait();
         Asocial.id = "Asocial";
         Asocial.path_icon = "ui/Icons/Asocial";
         Asocial.type = TraitType.Other;
         Asocial.group_id = TraitGroup.BadNaturalTraits;
         Asocial.can_be_given = true;
         Asocial.can_be_removed = true;
         Asocial.rate_birth = 1;
         Asocial.rate_inherit = 1;
         AssetManager.traits.add(Asocial);
         Asocial.base_stats["multiplier_offspring"] = 1.0f;
         Asocial.base_stats["speed"] = -10f;
         Asocial.base_stats["range"] = -0.010f;
         Asocial.base_stats["scale"] = -0.010f;
         Asocial.base_stats["opinion"] = -23f;
		 
					 
         ActorTrait Competitivo= new ActorTrait();
         Competitivo.id = "Competitivo";
         Competitivo.path_icon = "ui/Icons/Competitivo";
         Competitivo.type = TraitType.Other;
         Competitivo.group_id = TraitGroup.NaturalTraits;
         Competitivo.can_be_given = true;
         Competitivo.can_be_removed = true;
         Competitivo.rate_birth = 1;
         Competitivo.rate_inherit = 1;
         AssetManager.traits.add(Competitivo);
         Competitivo.base_stats["multiplier_offspring"] = -0.2f;
         Competitivo.base_stats["attack_speed"] = 8.7007f;
         Competitivo.base_stats["speed"] = 7f;
         Competitivo.base_stats["armor"] = 0.05f;
         Competitivo.base_stats["scale"] = 0.001f;
         Competitivo.base_stats["skill_combat"] = 0.20f;
         Competitivo.base_stats["warfare"] = 3.90f;
         Competitivo.base_stats["diplomacy"] = -2.10f;
         Competitivo.base_stats["opinion"] = -1f;
         Competitivo.base_stats["cities"] = 3;
         Competitivo.base_stats["area_of_effect"] = 3;
		 
					 
         ActorTrait Descuidado= new ActorTrait();
         Descuidado.id = "Descuidado";
         Descuidado.path_icon = "ui/Icons/Descuidado";
         Descuidado.type = TraitType.Other;
         Descuidado.group_id = TraitGroup.BadNaturalTraits;
         Descuidado.can_be_given = true;
         Descuidado.can_be_removed = true;
         Descuidado.rate_birth = 1;
         Descuidado.rate_inherit = 1;
         AssetManager.traits.add(Descuidado);
         Descuidado.base_stats["damage"] = -4.60f;
         Descuidado.base_stats["speed"] = -1.5f;
         Descuidado.base_stats["health"] = -5;
         Descuidado.base_stats["skill_combat"] = -1f;
         Descuidado.base_stats["opinion"] = -9f;
		 
					 
         ActorTrait Diplomatico= new ActorTrait();
         Diplomatico.id = "Diplomatico";
         Diplomatico.path_icon = "ui/Icons/Diplomatico";
         Diplomatico.type = TraitType.Other;
         Diplomatico.group_id = TraitGroup.NaturalTraits;
         Diplomatico.can_be_given = true;
         Diplomatico.can_be_removed = true;
         Diplomatico.rate_birth = 1;
         Diplomatico.rate_inherit = 1;
         AssetManager.traits.add(Diplomatico);
         Diplomatico.base_stats["diplomacy"] = 30;
         Diplomatico.base_stats["opinion"] = 1f;
		 
					 
         ActorTrait Entusiasta= new ActorTrait();
         Entusiasta.id = "Entusiasta";
         Entusiasta.path_icon = "ui/Icons/Entusiasta";
         Entusiasta.type = TraitType.Other;
         Entusiasta.group_id = TraitGroup.NaturalTraits;
         Entusiasta.can_be_given = true;
         Entusiasta.can_be_removed = true;
         Entusiasta.rate_birth = 1;
         Entusiasta.rate_inherit = 1;
         AssetManager.traits.add(Entusiasta);
         Entusiasta.base_stats["birth_rate"] = 1;
         Entusiasta.base_stats["multiplier_lifespan"] = 17f;
         Entusiasta.base_stats["attack_speed"] = 2;
         Entusiasta.base_stats["speed"] = 7f;
         Entusiasta.base_stats["skill_combat"] = 0.10f;
         Entusiasta.base_stats["critical_chance"] = 0.5f;
         Entusiasta.base_stats["intelligence"] = -1;
         Entusiasta.base_stats["warfare"] = 6;
         Entusiasta.base_stats["diplomacy"] = 8;
         Entusiasta.base_stats["opinion"] = 6f;
		 
					 
         ActorTrait Envidioso= new ActorTrait();
         Envidioso.id = "Envidioso";
         Envidioso.path_icon = "ui/Icons/Envidioso";
         Envidioso.type = TraitType.Other;
         Envidioso.group_id = TraitGroup.BadNaturalTraits;
         Envidioso.can_be_given = true;
         Envidioso.can_be_removed = true;
         Envidioso.rate_birth = 1;
         Envidioso.rate_inherit = 1;
         AssetManager.traits.add(Envidioso);
         Envidioso.base_stats["multiplier_offspring"] = -0.89f;
         Envidioso.base_stats["intelligence"] = 3;
         Envidioso.base_stats["warfare"] = 3.80f;
         Envidioso.base_stats["diplomacy"] = -4;
         Envidioso.base_stats["stewardship"] = -4;
         Envidioso.base_stats["opinion"] = -3f;
         Envidioso.base_stats["cities"] = -2;
         Envidioso.base_stats["area_of_effect"] = -2;
		 
					 
         ActorTrait Estudioso= new ActorTrait();
         Estudioso.id = "Estudioso";
         Estudioso.path_icon = "ui/Icons/Estudioso";
         Estudioso.type = TraitType.Other;
         Estudioso.group_id = TraitGroup.NaturalTraits;
         Estudioso.can_be_given = true;
         Estudioso.can_be_removed = true;
         Estudioso.rate_birth = 1;
         Estudioso.rate_inherit = 1;
         AssetManager.traits.add(Estudioso);
         Estudioso.base_stats["multiplier_offspring"] = 0.60f;
         Estudioso.base_stats["birth_rate"] = 1;
         Estudioso.base_stats["multiplier_lifespan"] = 5f;
         Estudioso.base_stats["attack_speed"] = -3.20f;
         Estudioso.base_stats["damage"] = -5;
         Estudioso.base_stats["speed"] = -3f;
         Estudioso.base_stats["range"] = -0.5f;
         Estudioso.base_stats["armor"] = -6;
         Estudioso.base_stats["skill_combat"] = -1f;
         Estudioso.base_stats["intelligence"] = 3.98f;
         Estudioso.base_stats["warfare"] = 15;
         Estudioso.base_stats["diplomacy"] = 10;
         Estudioso.base_stats["stewardship"] = 10;
         Estudioso.base_stats["opinion"] = 20f;
         Estudioso.base_stats["loyalty_traits"] = 1f;
         Estudioso.base_stats["cities"] = 4;
         Estudioso.base_stats["area_of_effect"] = 4;
		 
					 
         ActorTrait Ignorado= new ActorTrait();
         Ignorado.id = "Ignorado";
         Ignorado.path_icon = "ui/Icons/Ignorado";
         Ignorado.type = TraitType.Other;
         Ignorado.group_id = TraitGroup.BadNaturalTraits;
         Ignorado.can_be_given = true;
         Ignorado.can_be_removed = true;
         Ignorado.rate_birth = 1;
         Ignorado.rate_inherit = 1;
         AssetManager.traits.add(Ignorado);
         Ignorado.base_stats["multiplier_offspring"] = -0.50f;
         Ignorado.base_stats["birth_rate"] = 1;
         Ignorado.base_stats["multiplier_lifespan"] = -12f;
         Ignorado.base_stats["speed"] = 10f;
         Ignorado.base_stats["intelligence"] = -1;
         Ignorado.base_stats["diplomacy"] = -5;
         Ignorado.base_stats["opinion"] = -1f;
		 
					 
         ActorTrait Indeciso= new ActorTrait();
         Indeciso.id = "Indeciso";
         Indeciso.path_icon = "ui/Icons/Indeciso";
         Indeciso.type = TraitType.Other;
         Indeciso.group_id = TraitGroup.NaturalTraits;
         Indeciso.can_be_given = true;
         Indeciso.can_be_removed = true;
         Indeciso.rate_birth = 1;
         Indeciso.rate_inherit = 1;
         AssetManager.traits.add(Indeciso);
         Indeciso.base_stats["multiplier_offspring"] = -0.10f;
         Indeciso.base_stats["accuracy"] = -10f;
         Indeciso.base_stats["critical_chance"] = -0.40f;
         Indeciso.base_stats["warfare"] = 1;
         Indeciso.base_stats["diplomacy"] = -3.70f;
         Indeciso.base_stats["stewardship"] = -2;
         Indeciso.base_stats["opinion"] = -1f;
         Indeciso.base_stats["cities"] = -2;
         Indeciso.base_stats["area_of_effect"] = 2;
		 
		 				 				 		
         ActorTrait Justo= new ActorTrait();
         Justo.id = "Justo";
         Justo.path_icon = "ui/Icons/Justo";
         Justo.type = TraitType.Other;
         Justo.group_id = TraitGroup.NaturalTraits;
         Justo.can_be_given = true;
         Justo.can_be_removed = true;
         Justo.rate_birth = 1;
         Justo.rate_inherit = 1;
         AssetManager.traits.add(Justo);
         Justo.base_stats["accuracy"] = 5f;
         Justo.base_stats["intelligence"] = 3;
         Justo.base_stats["diplomacy"] = 12;
         Justo.base_stats["opinion"] = 8f;
////		 Justo.opposite = "Mentiroso,Hipocrita";


         ActorTrait Mentiroso= new ActorTrait();
         Mentiroso.id = "Mentiroso";
         Mentiroso.path_icon = "ui/Icons/Mentiroso";
         Mentiroso.type = TraitType.Other;
         Mentiroso.group_id = TraitGroup.BadNaturalTraits;
         Mentiroso.can_be_given = true;
         Mentiroso.can_be_removed = true;
         Mentiroso.rate_birth = 1;
         Mentiroso.rate_inherit = 1;
         AssetManager.traits.add(Mentiroso);
         Mentiroso.base_stats["birth_rate"] = 1;
         Mentiroso.base_stats["multiplier_lifespan"] = -4f;
         Mentiroso.base_stats["accuracy"] = -3f;
         Mentiroso.base_stats["intelligence"] = 2;
         Mentiroso.base_stats["warfare"] = -3;
         Mentiroso.base_stats["opinion"] = -10f;
         Mentiroso.base_stats["loyalty_traits"] = -10f;
         Mentiroso.base_stats["cities"] = 5;
         Mentiroso.base_stats["area_of_effect"] = -2;
////		 Mentiroso.opposite = "Justo,Sencillo";


         ActorTrait Molestoso= new ActorTrait();
         Molestoso.id = "Molestoso";
         Molestoso.path_icon = "ui/Icons/Molestoso";
         Molestoso.type = TraitType.Other;
         Molestoso.group_id = TraitGroup.BadNaturalTraits;
         Molestoso.can_be_given = true;
         Molestoso.can_be_removed = true;
         Molestoso.rate_birth = 1;
         Molestoso.rate_inherit = 1;
         AssetManager.traits.add(Molestoso);
         Molestoso.base_stats["intelligence"] = 2;
         Molestoso.base_stats["diplomacy"] = 2;
         Molestoso.base_stats["opinion"] = -13f;
         Molestoso.base_stats["loyalty_traits"] = -1f;
         Molestoso.base_stats["cities"] = 2;
         Molestoso.base_stats["area_of_effect"] = 2;


         ActorTrait Neutral= new ActorTrait();
         Neutral.id = "Neutral";
         Neutral.path_icon = "ui/Icons/Neutral";
         Neutral.type = TraitType.Other;
         Neutral.group_id = TraitGroup.NaturalTraits;
         Neutral.can_be_given = true;
         Neutral.can_be_removed = true;
         Neutral.rate_birth = 1;
         Neutral.rate_inherit = 1;
         AssetManager.traits.add(Neutral);
         Neutral.base_stats["birth_rate"] = 1;
         Neutral.base_stats["opinion"] = 5f;
         Neutral.base_stats["loyalty_traits"] = 5f;
////		 Neutral. opposite = "EnfermoMental,Autista";
		 

         ActorTrait Preciso= new ActorTrait();
         Preciso.id = "Preciso";
         Preciso.path_icon = "ui/Icons/Preciso";
         Preciso.type = TraitType.Other;
         Preciso.group_id = TraitGroup.NaturalTraits;
         Preciso.can_be_given = true;
         Preciso.can_be_removed = true;
         Preciso.rate_birth = 1;
         Preciso.rate_inherit = 1;
         AssetManager.traits.add(Preciso);
         Preciso.base_stats["birth_rate"] = 1;
         Preciso.base_stats["multiplier_lifespan"] = 5f;
         Preciso.base_stats["accuracy"] = 20f;
         Preciso.base_stats["critical_chance"] = 0.60f;
         Preciso.base_stats["intelligence"] = 1;
         Preciso.base_stats["warfare"] = 6;
         Preciso.base_stats["diplomacy"] = 4;
         Preciso.base_stats["stewardship"] = 7.80f;
         Preciso.base_stats["cities"] = 8;
         Preciso.base_stats["area_of_effect"] = 9;
		 

         ActorTrait Sencillo= new ActorTrait();
         Sencillo.id = "Sencillo";
         Sencillo.path_icon = "ui/Icons/Sencillo";
         Sencillo.type = TraitType.Other;
         Sencillo.group_id = TraitGroup.NaturalTraits;
         Sencillo.can_be_given = true;
         Sencillo.can_be_removed = true;
         Sencillo.rate_birth = 1;
         Sencillo.rate_inherit = 1;
         AssetManager.traits.add(Sencillo);
         Sencillo.base_stats["multiplier_offspring"] = 0.1f;
         Sencillo.base_stats["birth_rate"] = 1;
         Sencillo.base_stats["multiplier_lifespan"] = 7f;
         Sencillo.base_stats["skill_combat"] = 0.22222f;
         Sencillo.base_stats["opinion"] = 5f;
         Sencillo.base_stats["loyalty_traits"] = 5.2f;
////		 Sencillo.opposite = "Cruel,Extrovertido";
		 

         ActorTrait SuperAgil= new ActorTrait();
         SuperAgil.id = "Super Agil";
         SuperAgil.path_icon = "ui/Icons/SuperAgil";
         SuperAgil.type = TraitType.Positive;
         SuperAgil.group_id = TraitGroup.LegendaryTraits;
         SuperAgil.can_be_given = true;
         SuperAgil.can_be_removed = true;
         SuperAgil.rate_birth = 1;
         SuperAgil.rate_inherit = 1;
         AssetManager.traits.add(SuperAgil);
         SuperAgil.base_stats["attack_speed"] = 5;
         SuperAgil.base_stats["damage"] = 1;
         SuperAgil.base_stats["speed"] = 20f;
         SuperAgil.base_stats["accuracy"] = 0.01f;
         SuperAgil.base_stats["skill_combat"] = 100000f;
         SuperAgil.base_stats["critical_chance"] = 0.4f;
         SuperAgil.base_stats["knockback"] = 0.40f;
//         SuperAgil.base_stats["knockback_reduction"] = 0.3f;
         SuperAgil.base_stats["opinion"] = 10f;
////		 SuperAgil.opposite = "slow,fat,giant,EnfermoMental,Esquizofrenico";


         ActorTrait SuperResistente= new ActorTrait();
         SuperResistente.id = "Super Resistente";
         SuperResistente.path_icon = "ui/Icons/SuperResistente";
         SuperResistente.type = TraitType.Other;
         SuperResistente.group_id = TraitGroup.LegendaryTraits;
         SuperResistente.can_be_given = true;
         SuperResistente.can_be_removed = true;
         SuperResistente.rate_birth = 1;
         SuperResistente.rate_inherit = 1;
         AssetManager.traits.add(SuperResistente);
         SuperResistente.base_stats["health"] = 50;
         SuperResistente.base_stats["armor"] = 90;
         SuperResistente.base_stats["critical_chance"] = 0.40f;
         SuperResistente.base_stats["knockback"] = 0.79f;
//         SuperResistente.base_stats["knockback_reduction"] = 1.0f;
////		 SuperResistente.opposite = "Sensible,Apatico,Cicatrizado,crippled,one_eyed,weak";


         ActorTrait Vulgar= new ActorTrait();
         Vulgar.id = "Vulgar";
         Vulgar.path_icon = "ui/Icons/Vulgar";
         Vulgar.type = TraitType.Other;
         Vulgar.group_id = TraitGroup.BadNaturalTraits;
         Vulgar.can_be_given = true;
         Vulgar.can_be_removed = true;
         Vulgar.rate_birth = 1;
         Vulgar.rate_inherit = 1;
         AssetManager.traits.add(Vulgar);
         Vulgar.base_stats["multiplier_offspring"] = -0.26f;
         Vulgar.base_stats["birth_rate"] = 1;
         Vulgar.base_stats["multiplier_lifespan"] = -5f;
         Vulgar.base_stats["intelligence"] = -4;
         Vulgar.base_stats["opinion"] = -10f;


         ActorTrait Resiliente= new ActorTrait();
         Resiliente.id = "Resiliente";
         Resiliente.path_icon = "ui/Icons/Resiliente";
         Resiliente.type = TraitType.Other;
         Resiliente.group_id = TraitGroup.NaturalTraits;
         Resiliente.can_be_given = true;
         Resiliente.can_be_removed = true;
         Resiliente.rate_birth = 1;
         Resiliente.rate_inherit = 1;
         AssetManager.traits.add(Resiliente);
         Resiliente.base_stats["birth_rate"] = 1;
         Resiliente.base_stats["multiplier_lifespan"] = 5f;
         Resiliente.base_stats["accuracy"] = 0.5f;
         Resiliente.base_stats["armor"] = 5;
         Resiliente.base_stats["critical_chance"] = 0.001f;
         Resiliente.base_stats["intelligence"] = 1;
         Resiliente.base_stats["diplomacy"] = 5;
         Resiliente.base_stats["stewardship"] = 2;
         Resiliente.base_stats["opinion"] = 2f;
////		 Resiliente.opposite = "Presumido";


         ActorTrait Rencoroso= new ActorTrait();
         Rencoroso.id = "Rencoroso";
         Rencoroso.path_icon = "ui/Icons/Rencoroso";
         Rencoroso.type = TraitType.Other;
         Rencoroso.group_id = TraitGroup.BadNaturalTraits;
         Rencoroso.can_be_given = true;
         Rencoroso.can_be_removed = true;
         Rencoroso.rate_birth = 1;
         Rencoroso.rate_inherit = 1;
         AssetManager.traits.add(Rencoroso);
         Rencoroso.base_stats["birth_rate"] = 1;
         Rencoroso.base_stats["multiplier_lifespan"] = -20f;
         Rencoroso.base_stats["damage"] = 2;
////		 Rencoroso.opposite = "Sencillo,Flexible";


         ActorTrait Innovador= new ActorTrait();
         Innovador.id = "Innovador";
         Innovador.path_icon = "ui/Icons/Innovador";
         Innovador.type = TraitType.Other;
         Innovador.group_id = TraitGroup.NaturalTraits;
         Innovador.can_be_given = true;
         Innovador.can_be_removed = true;
         Innovador.rate_birth = 1;
         Innovador.rate_inherit = 1;
         AssetManager.traits.add(Innovador);
         Innovador.base_stats["accuracy"] = 2f;
         Innovador.base_stats["intelligence"] = 5;
         Innovador.base_stats["warfare"] = 2;
         Innovador.base_stats["diplomacy"] = 9;
         Innovador.base_stats["opinion"] = 10f;
////		 Innovador.opposite = "EnfermoMental,Autista,Esquizofrenico";


         ActorTrait Inmaduro= new ActorTrait();
         Inmaduro.id = "Inmaduro";
         Inmaduro.path_icon = "ui/Icons/Inmaduro";
         Inmaduro.type = TraitType.Other;
         Inmaduro.group_id = TraitGroup.BadNaturalTraits;
         Inmaduro.can_be_given = true;
         Inmaduro.can_be_removed = true;
         Inmaduro.rate_birth = 1;
         Inmaduro.rate_inherit = 1;
         AssetManager.traits.add(Inmaduro);
         Inmaduro.base_stats["multiplier_offspring"] = -0.40f;
         Inmaduro.base_stats["birth_rate"] = 1;
         Inmaduro.base_stats["intelligence"] = -8.90f;
         Inmaduro.base_stats["diplomacy"] = -10f;
         Inmaduro.base_stats["opinion"] = -15f;
////		 Inmaduro.opposite = "Serio,Formal,Franco";


         ActorTrait Energético= new ActorTrait();
         Energético.id = "Energético";
         Energético.path_icon = "ui/Icons/Energético";
         Energético.type = TraitType.Other;
         Energético.group_id = TraitGroup.NaturalTraits;
         Energético.can_be_given = true;
         Energético.can_be_removed = true;
         Energético.rate_birth = 1;
         Energético.rate_inherit = 1;
         AssetManager.traits.add(Energético);
         Energético.base_stats["multiplier_offspring"] = 0.60f;
         Energético.base_stats["multiplier_lifespan"] = 2f;
         Energético.base_stats["attack_speed"] = 12;
         Energético.base_stats["speed"] = 12f;
         Energético.base_stats["accuracy"] = 1f;
         Energético.base_stats["critical_chance"] = 0.32f;
         Energético.base_stats["knockback"] = 0.7f;
         Energético.base_stats["intelligence"] = 2;
////		 Energético.opposite = "Apatico,slow,fat";


         ActorTrait Descontrolado= new ActorTrait();
         Descontrolado.id = "Descontrolado";
         Descontrolado.path_icon = "ui/Icons/Descontrolado";
         Descontrolado.type = TraitType.Other;
         Descontrolado.group_id = TraitGroup.BadNaturalTraits;
         Descontrolado.can_be_given = true;
         Descontrolado.can_be_removed = true;
         Descontrolado.rate_birth = 1;
         Descontrolado.rate_inherit = 1;
         AssetManager.traits.add(Descontrolado);
         Descontrolado.base_stats["attack_speed"] = 7;
         Descontrolado.base_stats["damage"] = 2;
         Descontrolado.base_stats["range"] = 0.60f;
         Descontrolado.base_stats["intelligence"] = -5.80f;
         Descontrolado.base_stats["opinion"] = -8f;
         Descontrolado.base_stats["loyalty_traits"] = -9f;
////		 Descontrolado.opposite = "Autocontrolado,Altruista";


         ActorTrait Autentico= new ActorTrait();
         Autentico.id = "Autentico";
         Autentico.path_icon = "ui/Icons/Autentico";
         Autentico.type = TraitType.Other;
         Autentico.group_id = TraitGroup.NaturalTraits;
         Autentico.can_be_given = true;
         Autentico.can_be_removed = true;
         Autentico.rate_birth = 1;
         Autentico.rate_inherit = 1;
         AssetManager.traits.add(Autentico);
         Autentico.base_stats["multiplier_offspring"] = 0.05f;
         Autentico.base_stats["birth_rate"] = 1;
         Autentico.base_stats["multiplier_lifespan"] = 10f;
         Autentico.base_stats["critical_chance"] = 0.1f;
         Autentico.base_stats["intelligence"] = 1;
         Autentico.base_stats["opinion"] = 6f;
         Autentico.base_stats["loyalty_traits"] = 2f;
         Autentico.base_stats["cities"] = 2;
         Autentico.base_stats["area_of_effect"] = 2;
		 

         ActorTrait Autista= new ActorTrait();
         Autista.id = "Autista";
         Autista.path_icon = "ui/Icons/Autista";
         Autista.type = TraitType.Other;
         Autista.group_id = TraitGroup.MentalDisorders;
         Autista.can_be_given = true;
         Autista.can_be_removed = true;
         Autista.rate_birth = 1;
         Autista.rate_inherit = 1;
         AssetManager.traits.add(Autista);
         Autista.base_stats["multiplier_offspring"] = -0.44f;
         Autista.base_stats["birth_rate"] = 1;
         Autista.base_stats["accuracy"] = -15f;
         Autista.base_stats["range"] = 0.3f;
         Autista.base_stats["opinion"] = -5f;
		 

         ActorTrait Cruel= new ActorTrait();
         Cruel.id = "Cruel";
         Cruel.path_icon = "ui/Icons/Cruel";
         Cruel.type = TraitType.Other;
         Cruel.group_id = TraitGroup.BadNaturalTraits;
         Cruel.can_be_given = true;
         Cruel.can_be_removed = true;
         Cruel.rate_birth = 1;
         Cruel.rate_inherit = 1;
         AssetManager.traits.add(Cruel);
         Cruel.base_stats["attack_speed"] = 3;
         Cruel.base_stats["damage"] = 3;
         Cruel.base_stats["health"] = 5;
         Cruel.base_stats["armor"] = 8;
         Cruel.base_stats["warfare"] = -8;
         Cruel.base_stats["diplomacy"] = -8;
         Cruel.base_stats["stewardship"] = -5;
         Cruel.base_stats["opinion"] = -4f;
////		 Cruel.opposite = "Compasivo,Altruista";
		 

         ActorTrait Decepcionante= new ActorTrait();
         Decepcionante.id = "Decepcionante";
         Decepcionante.path_icon = "ui/Icons/Decepcionante";
         Decepcionante.type = TraitType.Other;
         Decepcionante.group_id = TraitGroup.BadNaturalTraits;
         Decepcionante.can_be_given = true;
         Decepcionante.can_be_removed = true;
         Decepcionante.rate_birth = 1;
         Decepcionante.rate_inherit = 1;
         AssetManager.traits.add(Decepcionante);
         Decepcionante.base_stats["attack_speed"] = -7;
         Decepcionante.base_stats["health"] = -24;
         Decepcionante.base_stats["accuracy"] = -20f;
         Decepcionante.base_stats["range"] = -0.20f;
         Decepcionante.base_stats["armor"] = -12;
         Decepcionante.base_stats["critical_chance"] = -0.60f;
         Decepcionante.base_stats["diplomacy"] =-3;
         Decepcionante.base_stats["loyalty_traits"] = -5f;
////		 Decepcionante.opposite = "SuperAgil,SuperFuerte,SuperGrande,SuperVida,SuperResistente,SuperInteligente,Prodigio,Dotado,Adaptable,strong,giant";
		 

         ActorTrait Desconsiderado= new ActorTrait();
         Desconsiderado.id = "Desconsiderado";
         Desconsiderado.path_icon = "ui/Icons/Desconsiderado";
         Desconsiderado.type = TraitType.Other;
         Desconsiderado.group_id = TraitGroup.BadNaturalTraits;
         Desconsiderado.can_be_given = true;
         Desconsiderado.can_be_removed = true;
         Desconsiderado.rate_birth = 1;
         Desconsiderado.rate_inherit = 1;
         AssetManager.traits.add(Desconsiderado);
         Desconsiderado.base_stats["accuracy"] = -4f;
         Desconsiderado.base_stats["intelligence"] = -2;
         Desconsiderado.base_stats["warfare"] = -1;
         Desconsiderado.base_stats["diplomacy"] = -2;
         Desconsiderado.base_stats["stewardship"] = -7;
         Desconsiderado.base_stats["opinion"] = -12f;
		 

         ActorTrait Desleal= new ActorTrait();
         Desleal.id = "Desleal";
         Desleal.path_icon = "ui/Icons/Desleal";
         Desleal.type = TraitType.Other;
         Desleal.group_id = TraitGroup.BadNaturalTraits;
         Desleal.can_be_given = true;
         Desleal.can_be_removed = true;
         Desleal.rate_birth = 1;
         Desleal.rate_inherit = 1;
         AssetManager.traits.add(Desleal);
         Desleal.base_stats["opinion"] = -6.20f;
         Desleal.base_stats["loyalty_traits"] = -30f;
		 

         ActorTrait Desvergonzado= new ActorTrait();
         Desvergonzado.id = "Desvergonzado";
         Desvergonzado.path_icon = "ui/Icons/Desvergonzado";
         Desvergonzado.type = TraitType.Other;
         Desvergonzado.group_id = TraitGroup.BadNaturalTraits;
         Desvergonzado.can_be_given = true;
         Desvergonzado.can_be_removed = true;
         Desvergonzado.rate_birth = 1;
         Desvergonzado.rate_inherit = 1;
         AssetManager.traits.add(Desvergonzado);
         Desvergonzado.base_stats["speed"] = 2f;
         Desvergonzado.base_stats["skill_combat"] = 0.3f;
         Desvergonzado.base_stats["diplomacy"] = -8;
         Desvergonzado.base_stats["opinion"] = -5.87f;
		 

         ActorTrait Insensato= new ActorTrait();
         Insensato.id = "Insensato";
         Insensato.path_icon = "ui/Icons/Insensato";
         Insensato.type = TraitType.Other;
         Insensato.group_id = TraitGroup.BadNaturalTraits;
         Insensato.can_be_given = true;
         Insensato.can_be_removed = true;
         Insensato.rate_birth = 1;
         Insensato.rate_inherit = 1;
         AssetManager.traits.add(Insensato);
         Insensato.base_stats["damage"] = 1;
         Insensato.base_stats["intelligence"] = -4;
         Insensato.base_stats["warfare"] = -5;
         Insensato.base_stats["opinion"] = -5f;
////		 Insensato.opposite = "Sensato";
		 

         ActorTrait Silencioso= new ActorTrait();
         Silencioso.id = "Silencioso";
         Silencioso.path_icon = "ui/Icons/Silencioso";
         Silencioso.type = TraitType.Other;
         Silencioso.group_id = TraitGroup.NaturalTraits;
         Silencioso.can_be_given = true;
         Silencioso.can_be_removed = true;
         Silencioso.rate_birth = 1;
         Silencioso.rate_inherit = 1;
         AssetManager.traits.add(Silencioso);
         Silencioso.base_stats["attack_speed"] = 10;
         Silencioso.base_stats["damage"] = 2;
         Silencioso.base_stats["accuracy"] = 4f;
         Silencioso.base_stats["intelligence"] = 3.40f;
////		 Silencioso.opposite = "Desastroso";
		 

         ActorTrait Vengativo= new ActorTrait();
         Vengativo.id = "Vengativo";
         Vengativo.path_icon = "ui/Icons/Vengativo";
         Vengativo.type = TraitType.Other;
         Vengativo.group_id = TraitGroup.BadNaturalTraits;
         Vengativo.can_be_given = true;
         Vengativo.can_be_removed = true;
         Vengativo.rate_birth = 1;
         Vengativo.rate_inherit = 1;
         AssetManager.traits.add(Vengativo);
         Vengativo.base_stats["attack_speed"] = 3;
         Vengativo.base_stats["damage"] = 2;
         Vengativo.base_stats["speed"] = 3f;
         Vengativo.base_stats["warfare"] = 3;
         Vengativo.base_stats["diplomacy"] = -6.80f;
         Vengativo.base_stats["opinion"] = -8.60f;
         Vengativo.base_stats["loyalty_traits"] = -6f;
////		 Vengativo.opposite = "Neutral,Leal,Sencillo,Tranquilo,Tolerante";
		 

         ActorTrait Sensible= new ActorTrait();
         Sensible.id = "Sensible";
         Sensible.path_icon = "ui/Icons/Sensible";
         Sensible.type = TraitType.Other;
         Sensible.group_id = TraitGroup.BadNaturalTraits;
         Sensible.can_be_given = true;
         Sensible.can_be_removed = true;
         Sensible.rate_birth = 1;
         Sensible.rate_inherit = 1;
         AssetManager.traits.add(Sensible);
         Sensible.base_stats["accuracy"] = 0.05f;
         Sensible.base_stats["stewardship"] = 0.4f;
         Sensible.base_stats["opinion"] = 7f;
         Sensible.base_stats["loyalty_traits"] = 6f;
////         Sensible.opposite = "Resistente,SuperResistente";			
		 
		 
		 ActorTrait Aferrado= new ActorTrait();
         Aferrado.id = "Aferrado";
         Aferrado.path_icon = "ui/Icons/Aferrado";
         Aferrado.type = TraitType.Other;
         Aferrado.group_id = TraitGroup.NaturalTraits;
         Aferrado.can_be_given = true;
         Aferrado.can_be_removed = true;
         Aferrado.rate_birth = 1;
         Aferrado.rate_inherit = 1;
         AssetManager.traits.add(Aferrado);
         Aferrado.base_stats["accuracy"] = 5f;
         Aferrado.base_stats["skill_combat"] = 0.50f;
         Aferrado.base_stats["diplomacy"] = 5;
         Aferrado.base_stats["opinion"] = 6f;
         Aferrado.base_stats["loyalty_traits"] = 6f;
////         Aferrado.opposite = "Distante";			
		 
		 
		 ActorTrait Coherente= new ActorTrait();
         Coherente.id = "Coherente";
         Coherente.path_icon = "ui/Icons/Coherente";
         Coherente.type = TraitType.Other;
         Coherente.group_id = TraitGroup.NaturalTraits;
         Coherente.can_be_given = true;
         Coherente.can_be_removed = true;
         Coherente.rate_birth = 1;
         Coherente.rate_inherit = 1;
         AssetManager.traits.add(Coherente);
         Coherente.base_stats["accuracy"] = 3f;
         Coherente.base_stats["intelligence"] = 1;
         Coherente.base_stats["warfare"] = 4;
         Coherente.base_stats["diplomacy"] = 4;
         Coherente.base_stats["stewardship"] = 4;
         Coherente.base_stats["opinion"] = 7f;
         Coherente.base_stats["loyalty_traits"] = 3f;
////         Coherente.opposite = "Descontrolado,Estupido,stupid,Autista,Esquizofrenico,Psicotico";			
		 
		 
		 ActorTrait Conquistador= new ActorTrait();
         Conquistador.id = "Conquistador";
         Conquistador.path_icon = "ui/Icons/Conquistador";
         Conquistador.type = TraitType.Other;
         Conquistador.group_id = TraitGroup.NaturalTraits;
         Conquistador.can_be_given = true;
         Conquistador.can_be_removed = true;
         Conquistador.rate_birth = 1;
         Conquistador.rate_inherit = 1;
         AssetManager.traits.add(Conquistador);
         Conquistador.base_stats["multiplier_offspring"] = 0.6f;
         Conquistador.base_stats["birth_rate"] = 1;
         Conquistador.base_stats["multiplier_lifespan"] = 5f;
         Conquistador.base_stats["accuracy"] = 5f;
         Conquistador.base_stats["warfare"] = 1;
         Conquistador.base_stats["diplomacy"] = -5;
         Conquistador.base_stats["opinion"] = -5f;
         Conquistador.base_stats["cities"] = 10;
         Conquistador.base_stats["area_of_effect"] = 10;
////         Conquistador.opposite = "Miedoso,Conformista";			
		 
		 
		 ActorTrait Dedicado= new ActorTrait();
         Dedicado.id = "Dedicado";
         Dedicado.path_icon = "ui/Icons/Dedicado";
         Dedicado.type = TraitType.Other;
         Dedicado.group_id = TraitGroup.NaturalTraits;
         Dedicado.can_be_given = true;
         Dedicado.can_be_removed = true;
         Dedicado.rate_birth = 1;
         Dedicado.rate_inherit = 1;
         AssetManager.traits.add(Dedicado);
         Dedicado.base_stats["health"] = 12;
         Dedicado.base_stats["warfare"] = 3;
         Dedicado.base_stats["diplomacy"] = 3;
         Dedicado.base_stats["stewardship"] = 3;
         Dedicado.base_stats["loyalty_traits"] = 3.40f;
         Dedicado.base_stats["cities"] = 3;
////         Dedicado.opposite = "Descuidado,Deprimido";			
		 
		 
		 ActorTrait Deprimido= new ActorTrait();
         Deprimido.id = "Deprimido";
         Deprimido.path_icon = "ui/Icons/Deprimido";
         Deprimido.type = TraitType.Other;
         Deprimido.group_id = TraitGroup.BadNaturalTraits;
         Deprimido.can_be_given = true;
         Deprimido.can_be_removed = true;
         Deprimido.rate_birth = 1;
         Deprimido.rate_inherit = 1;
         AssetManager.traits.add(Deprimido);
         Deprimido.base_stats["multiplier_offspring"] = -0.40f;
         Deprimido.base_stats["birth_rate"] = 1;
         Deprimido.base_stats["armor"] = -12;
         Deprimido.base_stats["knockback"] = -0.2f;
         Deprimido.base_stats["cities"] = -2;
         Deprimido.base_stats["area_of_effect"] = -2;
////         Deprimido.opposite = "Dedicado";			
		 
		 
		 ActorTrait Desastroso= new ActorTrait();
         Desastroso.id = "Desastroso";
         Desastroso.path_icon = "ui/Icons/Desastroso";
         Desastroso.type = TraitType.Positive;
         Desastroso.group_id = TraitGroup.BadNaturalTraits;
         Desastroso.can_be_given = true;
         Desastroso.can_be_removed = true;
         Desastroso.rate_birth = 1;
         Desastroso.rate_inherit = 1;
         AssetManager.traits.add(Desastroso);
         Desastroso.base_stats["multiplier_offspring"] = -0.4333f;
         Desastroso.base_stats["multiplier_lifespan"] = -12f;
         Desastroso.base_stats["attack_speed"] = -4;
         Desastroso.base_stats["damage"] = 1.40f;
         Desastroso.base_stats["speed"] = 5f;
         Desastroso.base_stats["health"] = -10;
         Desastroso.base_stats["accuracy"] = -0.20f;
         Desastroso.base_stats["critical_chance"] = 0.2f;
         Desastroso.base_stats["knockback"] = -0.23f;
//         Desastroso.base_stats["knockback_reduction"] = -0.1f;
         Desastroso.base_stats["opinion"] = -6.80f;
         Desastroso.base_stats["loyalty_traits"] = -9.10f;
         Desastroso.base_stats["cities"] = 2;
         Desastroso.base_stats["area_of_effect"] = -4;
////         Desastroso.opposite = "Discreto,Autocontrolado";			
		 
		 
		 ActorTrait Desconfiado= new ActorTrait();
         Desconfiado.id = "Desconfiado";
         Desconfiado.path_icon = "ui/Icons/Desconfiado";
         Desconfiado.type = TraitType.Other;
         Desconfiado.group_id = TraitGroup.BadNaturalTraits;
         Desconfiado.can_be_given = true;
         Desconfiado.can_be_removed = true;
         Desconfiado.rate_birth = 1;
         Desconfiado.rate_inherit = 1;
         AssetManager.traits.add(Desconfiado);
         Desconfiado.base_stats["damage"] = -1;
         Desconfiado.base_stats["speed"] = 2f;
         Desconfiado.base_stats["critical_chance"] = -0.1f;
         Desconfiado.base_stats["diplomacy"] = -12;
         Desconfiado.base_stats["opinion"] = -5f;
         Desconfiado.base_stats["loyalty_traits"] = -21f;
////         Desconfiado.opposite = "Aferrado,Confiado";			
		 
		 
		 ActorTrait Firme= new ActorTrait();
         Firme.id = "Firme";
         Firme.path_icon = "ui/Icons/Firme";
         Firme.type = TraitType.Other;
         Firme.group_id = TraitGroup.NaturalTraits;
         Firme.can_be_given = true;
         Firme.can_be_removed = true;
         Firme.rate_birth = 1;
         Firme.rate_inherit = 1;
         AssetManager.traits.add(Firme);
         Firme.base_stats["multiplier_lifespan"] = 5f;
         Firme.base_stats["attack_speed"] = 3.25f;
         Firme.base_stats["damage"] = 2;
         Firme.base_stats["speed"] = 4f;
         Firme.base_stats["health"] = 5;
         Firme.base_stats["accuracy"] = 3f;
         Firme.base_stats["diplomacy"] = 8;
         Firme.base_stats["opinion"] = 1f;
         Firme.base_stats["loyalty_traits"] = 3f;
////         Firme.opposite = "Despistado";			
		 
		 
		 ActorTrait Hipocrita= new ActorTrait();
         Hipocrita.id = "Hipocrita";
         Hipocrita.path_icon = "ui/Icons/Hipocrita";
         Hipocrita.type = TraitType.Other;
         Hipocrita.group_id = TraitGroup.BadNaturalTraits;
         Hipocrita.can_be_given = true;
         Hipocrita.can_be_removed = true;
         Hipocrita.rate_birth = 1;
         Hipocrita.rate_inherit = 1;
         AssetManager.traits.add(Hipocrita);
         Hipocrita.base_stats["accuracy"] = 5f;
         Hipocrita.base_stats["opinion"] = -12f;
         Hipocrita.base_stats["loyalty_traits"] = -4f;
////         Hipocrita.opposite = "Sencilla,Leal,honest";			
		 
		 
		 ActorTrait Intuitivo= new ActorTrait();
         Intuitivo.id = "Intuitivo";
         Intuitivo.path_icon = "ui/Icons/Intuitivo";
         Intuitivo.type = TraitType.Other;
         Intuitivo.group_id = TraitGroup.NaturalTraits;
         Intuitivo.can_be_given = true;
         Intuitivo.can_be_removed = true;
         Intuitivo.rate_birth = 1;
         Intuitivo.rate_inherit = 1;
         AssetManager.traits.add(Intuitivo);
         Intuitivo.base_stats["birth_rate"] = 1;
         Intuitivo.base_stats["multiplier_lifespan"] = 15f;
         Intuitivo.base_stats["attack_speed"] = 5;
         Intuitivo.base_stats["health"] = -1;
         Intuitivo.base_stats["accuracy"] = 5f;
         Intuitivo.base_stats["diplomacy"] = 2;
         Intuitivo.base_stats["loyalty_traits"] = 2f;
////         Intuitivo.opposite = "";			
		 

         ActorTrait Impredecible= new ActorTrait();
         Impredecible.id = "Impredecible";
         Impredecible.path_icon = "ui/Icons/Impredecible";
         Impredecible.type = TraitType.Other;
         Impredecible.group_id = TraitGroup.BadNaturalTraits;
         Impredecible.can_be_given = true;
         Impredecible.can_be_removed = true;
         Impredecible.rate_birth = 1;
         Impredecible.rate_inherit = 1;
         AssetManager.traits.add(Impredecible);
         Impredecible.base_stats["multiplier_offspring"] = 0.2f;
         Impredecible.base_stats["birth_rate"] = 1;
         Impredecible.base_stats["multiplier_lifespan"] = 2f;
         Impredecible.base_stats["accuracy"] = -30f;
         Impredecible.base_stats["warfare"] = 2;
         Impredecible.base_stats["diplomacy"] = -12;
         Impredecible.base_stats["stewardship"] = -5.50f;
         Impredecible.base_stats["opinion"] = 3.50f;
         Impredecible.base_stats["loyalty_traits"] = 1f;
         Impredecible.base_stats["cities"] = -1;
////         Impredecible.opposite = "Franco";			


         ActorTrait Visionario= new ActorTrait();
         Visionario.id = "Visionario";
         Visionario.path_icon = "ui/Icons/Visionario";
         Visionario.type = TraitType.Positive;
         Visionario.group_id = TraitGroup.NaturalTraits;
         Visionario.can_be_given = true;
         Visionario.can_be_removed = true;
         Visionario.rate_birth = 1;
         Visionario.rate_inherit = 1;
         AssetManager.traits.add(Visionario);
         Visionario.base_stats["attack_speed"] = 2;
         Visionario.base_stats["accuracy"] = 0.12f;
         Visionario.base_stats["skill_combat"] = 0.3f;
////         Visionario.opposite = "Impredecible,Bipolar,Apatico";			

		 
         ActorTrait Melancólico= new ActorTrait();
         Melancólico.id = "Melancólico";
         Melancólico.path_icon = "ui/Icons/Melancólico";
         Melancólico.type = TraitType.Other;
         Melancólico.group_id = TraitGroup.NaturalTraits;
         Melancólico.can_be_given = true;
         Melancólico.can_be_removed = true;
         Melancólico.rate_birth = 1;
         Melancólico.rate_inherit = 1;
         AssetManager.traits.add(Melancólico);
         Melancólico.base_stats["multiplier_offspring"] = -0.2f;
         Melancólico.base_stats["birth_rate"] = 1;
         Melancólico.base_stats["speed"] = 2f;
         Melancólico.base_stats["health"] = -1;
         Melancólico.base_stats["accuracy"] = 0.44f;
         Melancólico.base_stats["skill_combat"] = -0.70f;
         Melancólico.base_stats["diplomacy"] = -2;
         Melancólico.base_stats["opinion"] = 2f;
         Melancólico.base_stats["loyalty_traits"] = -3f;
////         Melancólico.opposite = "";			


         ActorTrait Despistado= new ActorTrait();
         Despistado.id = "Despistado";
         Despistado.path_icon = "ui/Icons/Despistado";
         Despistado.type = TraitType.Other;
         Despistado.group_id = TraitGroup.BadNaturalTraits;
         Despistado.can_be_given = true;
         Despistado.can_be_removed = true;
         Despistado.rate_birth = 1;
         Despistado.rate_inherit = 1;
         AssetManager.traits.add(Despistado);
         Despistado.base_stats["multiplier_offspring"] = -0.2f;
         Despistado.base_stats["multiplier_lifespan"] = -12f;
         Despistado.base_stats["skill_combat"] = 0.254f;
         Despistado.base_stats["intelligence"] = -7;
         Despistado.base_stats["cities"] = -1;
////         Despistado.opposite = "Atento,Firme";			


         ActorTrait Sereno= new ActorTrait();
         Sereno.id = "Sereno";
         Sereno.path_icon = "ui/Icons/Sereno";
         Sereno.type = TraitType.Other;
         Sereno.group_id = TraitGroup.NaturalTraits;
         Sereno.can_be_given = true;
         Sereno.can_be_removed = true;
         Sereno.rate_birth = 1;
         Sereno.rate_inherit = 1;
         AssetManager.traits.add(Sereno);
         Sereno.base_stats["multiplier_lifespan"] = 4f;
         Sereno.base_stats["range"] = 0.1f;
//         Sereno.base_stats["knockback_reduction"] = 0.21111f;
         Sereno.base_stats["intelligence"] = 1;
         Sereno.base_stats["opinion"] = 10f;
         Sereno.base_stats["loyalty_traits"] = 1f;
////         Sereno.opposite = "Cruel,Antipático,Egoista";			


         ActorTrait Discreto= new ActorTrait();
         Discreto.id = "Discreto";
         Discreto.path_icon = "ui/Icons/Discreto";
         Discreto.type = TraitType.Other;
         Discreto.group_id = TraitGroup.NaturalTraits;
         Discreto.can_be_given = true;
         Discreto.can_be_removed = true;
         Discreto.rate_birth = 1;
         Discreto.rate_inherit = 1;
         AssetManager.traits.add(Discreto);
         Discreto.base_stats["birth_rate"] = 1;
         Discreto.base_stats["multiplier_lifespan"] = 8f;
         Discreto.base_stats["attack_speed"] = 7;
         Discreto.base_stats["damage"] = 3;
         Discreto.base_stats["speed"] = -7f;
         Discreto.base_stats["accuracy"] = 0.4f;
         Discreto.base_stats["skill_combat"] = 0.250f;
         Discreto.base_stats["warfare"] = 4;
         Discreto.base_stats["diplomacy"] = 3;
         Discreto.base_stats["stewardship"] = 4;
         Discreto.base_stats["area_of_effect"] = 1;
////         Discreto.opposite = "Estupido";			


         ActorTrait Inseguro= new ActorTrait();
         Inseguro.id = "Inseguro";
         Inseguro.path_icon = "ui/Icons/Inseguro";
         Inseguro.type = TraitType.Other;
         Inseguro.group_id = TraitGroup.BadNaturalTraits;
         Inseguro.can_be_given = true;
         Inseguro.can_be_removed = true;
         Inseguro.rate_birth = 1;
         Inseguro.rate_inherit = 1;
         AssetManager.traits.add(Inseguro);
         Inseguro.base_stats["birth_rate"] = 1;
         Inseguro.base_stats["multiplier_lifespan"] = -10f;
         Inseguro.base_stats["opinion"] = 1f;
         Inseguro.base_stats["loyalty_traits"] = -4.20f;
         Inseguro.base_stats["cities"] = -5;
////         Inseguro.opposite = "Confiado";			


         ActorTrait Apatico= new ActorTrait();
         Apatico.id = "Apatico";
         Apatico.path_icon = "ui/Icons/Apatico";
         Apatico.type = TraitType.Positive;
         Apatico.group_id = TraitGroup.NaturalTraits;
         Apatico.can_be_given = true;
         Apatico.can_be_removed = true;
         Apatico.rate_birth = 1;
         Apatico.rate_inherit = 1;
         AssetManager.traits.add(Apatico);
         Apatico.base_stats["multiplier_offspring"] = -0.2f;
         Apatico.base_stats["attack_speed"] = -5;
         Apatico.base_stats["damage"] = -5;
         Apatico.base_stats["health"] = -10;
         Apatico.base_stats["critical_chance"] = -0.380f;
////         Apatico.opposite = "Energetico,HiperActivo";			


         ActorTrait Puntual= new ActorTrait();
         Puntual.id = "Puntual";
         Puntual.path_icon = "ui/Icons/Puntual";
         Puntual.type = TraitType.Other;
         Puntual.group_id = TraitGroup.NaturalTraits;
         Puntual.can_be_given = true;
         Puntual.can_be_removed = true;
         Puntual.rate_birth = 1;
         Puntual.rate_inherit = 1;
         AssetManager.traits.add(Puntual);
         Puntual.base_stats["multiplier_offspring"] = 0.2f;
         Puntual.base_stats["birth_rate"] = 1;
         Puntual.base_stats["speed"] = 8f;
         Puntual.base_stats["warfare"] = 3;
         Puntual.base_stats["opinion"] = 4.90f;
         Puntual.base_stats["loyalty_traits"] = 5.40f;
         Puntual.base_stats["cities"] = 2;
         Puntual.base_stats["area_of_effect"] = 2;
////         Puntual.opposite = "Decepcionante";			


         ActorTrait Delicado= new ActorTrait();
         Delicado.id = "Delicado";
         Delicado.path_icon = "ui/Icons/Delicado";
         Delicado.type = TraitType.Other;
         Delicado.group_id = TraitGroup.Physicalconditions;
         Delicado.can_be_given = true;
         Delicado.can_be_removed = true;
         Delicado.rate_birth = 1;
         Delicado.rate_inherit = 1;
         AssetManager.traits.add(Delicado);
         Delicado.base_stats["damage"] = -2;
         Delicado.base_stats["speed"] = -3f;
         Delicado.base_stats["health"] = -5;
         Delicado.base_stats["skill_combat"] = -2f;
         Delicado.base_stats["intelligence"] = -1;
////         Delicado.opposite = "SuperFuerte,Resistente";			


         ActorTrait Esquizofrenico= new ActorTrait();
         Esquizofrenico.id = "Esquizofrenico";
         Esquizofrenico.path_icon = "ui/Icons/Esquizofrenico";
         Esquizofrenico.type = TraitType.Other;
         Esquizofrenico.group_id = TraitGroup.MentalDisorders;
         Esquizofrenico.can_be_given = true;
         Esquizofrenico.can_be_removed = true;
         Esquizofrenico.rate_birth = 1;
         Esquizofrenico.rate_inherit = 1;
         AssetManager.traits.add(Esquizofrenico);
         Esquizofrenico.base_stats["multiplier_offspring"] = -0.68f;
         Esquizofrenico.base_stats["birth_rate"] = 1;
         Esquizofrenico.base_stats["multiplier_lifespan"] = -12f;
         Esquizofrenico.base_stats["attack_speed"] = -10;
         Esquizofrenico.base_stats["health"] = -18;
         Esquizofrenico.base_stats["knockback"] = -0.2f;
         Esquizofrenico.base_stats["warfare"] = -20;
         Esquizofrenico.base_stats["diplomacy"] = -30;
////         Esquizofrenico.opposite = "SuperAgil,SuperInteligente,SuperFuerte,SuperRapido,Discreto,Dotado,Prodigio";			


         ActorTrait Bipolar= new ActorTrait();
         Bipolar.id = "Bipolar";
         Bipolar.path_icon = "ui/Icons/Bipolar";
         Bipolar.type = TraitType.Other;
         Bipolar.group_id = TraitGroup.MentalDisorders;
         Bipolar.can_be_given = true;
         Bipolar.can_be_removed = true;
         Bipolar.rate_birth = 1;
         Bipolar.rate_inherit = 1;
         AssetManager.traits.add(Bipolar);
         Bipolar.base_stats["multiplier_lifespan"] = -1f;
         Bipolar.base_stats["warfare"] = -3;
         Bipolar.base_stats["opinion"] = 1f;
         Bipolar.base_stats["loyalty_traits"] = -3f;
////         Bipolar.opposite = "Confiado,Comprensible";			
		 

         ActorTrait HiperActivo= new ActorTrait();
         HiperActivo.id = "HiperActivo";
         HiperActivo.path_icon = "ui/Icons/HiperActivo";
         HiperActivo.type = TraitType.Other;
         HiperActivo.group_id = TraitGroup.NaturalTraits;
         HiperActivo.can_be_given = true;
         HiperActivo.can_be_removed = true;
         HiperActivo.rate_birth = 1;
         HiperActivo.rate_inherit = 1;
         AssetManager.traits.add(HiperActivo);
         HiperActivo.base_stats["multiplier_offspring"] = 0.12f;
         HiperActivo.base_stats["attack_speed"] = 3;
         HiperActivo.base_stats["speed"] = 3f;
         HiperActivo.base_stats["intelligence"] = 1.20f;
         HiperActivo.base_stats["opinion"] = -1f;
////         HiperActivo.opposite = "Delicado,Apatico,Decepcionante";			
		 

         ActorTrait Narcisista= new ActorTrait();
         Narcisista.id = "Narcisista";
         Narcisista.path_icon = "ui/Icons/Narcisista";
         Narcisista.type = TraitType.Other;
         Narcisista.group_id = TraitGroup.BadNaturalTraits;
         Narcisista.can_be_given = true;
         Narcisista.can_be_removed = true;
         Narcisista.rate_birth = 1;
         Narcisista.rate_inherit = 1;
         AssetManager.traits.add(Narcisista);
         Narcisista.base_stats["intelligence"] = 1;
         Narcisista.base_stats["diplomacy"] = -5.40f;
         Narcisista.base_stats["opinion"] = -6f;
         Narcisista.base_stats["loyalty_traits"] = -3f;
////         Narcisista.opposite = "Honorable,Compasivo";			
		 

         ActorTrait Altruista= new ActorTrait();
         Altruista.id = "Altruista";
         Altruista.path_icon = "ui/Icons/Altruista";
         Altruista.type = TraitType.Other;
         Altruista.group_id = TraitGroup.NaturalTraits;
         Altruista.can_be_given = true;
         Altruista.can_be_removed = true;
         Altruista.rate_birth = 1;
         Altruista.rate_inherit = 1;
         AssetManager.traits.add(Altruista);
         Altruista.base_stats["multiplier_offspring"] = 0.03f;
         Altruista.base_stats["warfare"] = 1;
         Altruista.base_stats["diplomacy"] = 6.70f;
         Altruista.base_stats["stewardship"] = 4;
         Altruista.base_stats["opinion"] = 2f;
         Altruista.base_stats["loyalty_traits"] = 3f;
         Altruista.base_stats["cities"] = 8;
////         Altruista.opposite = "Cruel,Insensato,EnfermoMental,Decepcionante,Egoista";			
		 

         ActorTrait Benevoliente= new ActorTrait();
         Benevoliente.id = "Benevoliente";
         Benevoliente.path_icon = "ui/Icons/Benevoliente";
         Benevoliente.type = TraitType.Other;
         Benevoliente.group_id = TraitGroup.NaturalTraits;
         Benevoliente.can_be_given = true;
         Benevoliente.can_be_removed = true;
         Benevoliente.rate_birth = 1;
         Benevoliente.rate_inherit = 1;
         AssetManager.traits.add(Benevoliente);
         Benevoliente.base_stats["birth_rate"] = 1;
         Benevoliente.base_stats["diplomacy"] = 7;
         Benevoliente.base_stats["opinion"] = 4.50f;
         Benevoliente.base_stats["loyalty_traits"] = 6.5f;
         Benevoliente.base_stats["cities"] = -1;
////         Benevoliente.opposite = "Insensato,Decepcionante";			
		 

         ActorTrait Ignorante= new ActorTrait();
         Ignorante.id = "Ignorante";
         Ignorante.path_icon = "ui/Icons/Ignorante";
         Ignorante.type = TraitType.Other;
         Ignorante.group_id = TraitGroup.BadNaturalTraits;
         Ignorante.can_be_given = true;
         Ignorante.can_be_removed = true;
         Ignorante.rate_birth = 1;
         Ignorante.rate_inherit = 1;
         AssetManager.traits.add(Ignorante);
         Ignorante.base_stats["speed"] = 4.70f;
         Ignorante.base_stats["range"] = 0.20f;
         Ignorante.base_stats["opinion"] = -4f;
         Ignorante.base_stats["loyalty_traits"] = -3f;
         Ignorante.base_stats["cities"] = -2;
////         Ignorante.opposite = "Estudioso,Estrategico,Administrativo,Diplomatico,Decepcionante";			
		 

         ActorTrait Perceptivo= new ActorTrait();
         Perceptivo.id = "Perceptivo";
         Perceptivo.path_icon = "ui/Icons/Perceptivo";
         Perceptivo.type = TraitType.Other;
         Perceptivo.group_id = TraitGroup.NaturalTraits;
         Perceptivo.can_be_given = true;
         Perceptivo.can_be_removed = true;
         Perceptivo.rate_birth = 1;
         Perceptivo.rate_inherit = 1;
         AssetManager.traits.add(Perceptivo);
         Perceptivo.base_stats["damage"] = 1;
         Perceptivo.base_stats["speed"] = 3f;
         Perceptivo.base_stats["range"] = 0.4f;
         Perceptivo.base_stats["skill_combat"] = 0.40f;
         Perceptivo.base_stats["diplomacy"] = 10;
         Perceptivo.base_stats["opinion"] = 1f;
         Perceptivo.base_stats["loyalty_traits"] = 2f;
////         Perceptivo.opposite = "Impredecible,Decepcionante";			
		 

         ActorTrait Franco= new ActorTrait();
         Franco.id = "Franco";
         Franco.path_icon = "ui/Icons/Franco";
         Franco.type = TraitType.Other;
         Franco.group_id = TraitGroup.NaturalTraits;
         Franco.can_be_given = true;
         Franco.can_be_removed = true;
         Franco.rate_birth = 1;
         Franco.rate_inherit = 1;
         AssetManager.traits.add(Franco);
         Franco.base_stats["multiplier_offspring"] = 0.00001f;
         Franco.base_stats["birth_rate"] = 1;
         Franco.base_stats["multiplier_lifespan"] = 3f;
         Franco.base_stats["attack_speed"] = 1;
         Franco.base_stats["accuracy"] = 5f;
         Franco.base_stats["diplomacy"] = 1;
         Franco.base_stats["stewardship"] = 1;
         Franco.base_stats["opinion"] = 1f;
         Franco.base_stats["loyalty_traits"] = 23f;
////         Franco.opposite = "Despistado,Compasivo,Sensible";			
		 

         ActorTrait Conciente= new ActorTrait();
         Conciente.id = "Conciente";
         Conciente.path_icon = "ui/Icons/Conciente";
         Conciente.type = TraitType.Other;
         Conciente.group_id = TraitGroup.NaturalTraits;
         Conciente.can_be_given = true;
         Conciente.can_be_removed = true;
         Conciente.rate_birth = 1;
         Conciente.rate_inherit = 1;
         AssetManager.traits.add(Conciente);
         Conciente.base_stats["skill_combat"] = 1f;
         Conciente.base_stats["diplomacy"] = 5;
         Conciente.base_stats["opinion"] = 15f;
////         Conciente.opposite = "Cruel,Descontrolado";			
		 
		 
		 ActorTrait Psicopata= new ActorTrait();
         Psicopata.id = "Psicopata";
         Psicopata.path_icon = "ui/Icons/Psicopata";
         Psicopata.type = TraitType.Other;
         Psicopata.group_id = TraitGroup.MentalDisorders;
         Psicopata.can_be_given = true;
         Psicopata.can_be_removed = true;
         Psicopata.rate_birth = 1;
         Psicopata.rate_inherit = 1;
         AssetManager.traits.add(Psicopata);
         Psicopata.base_stats["birth_rate"] = 1;
         Psicopata.base_stats["attack_speed"] = 2;
         Psicopata.base_stats["damage"] = 3;
         Psicopata.base_stats["armor"] = 4;
         Psicopata.base_stats["skill_combat"] = 0.4f;
         Psicopata.base_stats["diplomacy"] = -4;
         Psicopata.base_stats["stewardship"] = -3;
         Psicopata.base_stats["opinion"] = -9f;
         Psicopata.base_stats["loyalty_traits"] = -4f;
         Psicopata.base_stats["cities"] = -2;
         Psicopata.base_stats["area_of_effect"] = -2;
////         Psicopata.opposite = "Compasivo,Sencillo,Leal,Altruista";			
		 
		 ActorTrait Prodigio= new ActorTrait();
         Prodigio.id = "Prodigio";
         Prodigio.path_icon = "ui/Icons/Prodigio";
         Prodigio.type = TraitType.Other;
         Prodigio.group_id = TraitGroup.LegendaryTraits;
         Prodigio.can_be_given = true;
         Prodigio.can_be_removed = true;
         Prodigio.rate_birth = 1;
         Prodigio.rate_inherit = 1;
         AssetManager.traits.add(Prodigio);
         Prodigio.base_stats["multiplier_offspring"] = 0.5f;
         Prodigio.base_stats["birth_rate"] = 1;
         Prodigio.base_stats["multiplier_lifespan"] = 25f;
         Prodigio.base_stats["attack_speed"] = 50;
         Prodigio.base_stats["damage"] = 100;
         Prodigio.base_stats["speed"] = 40f;
         Prodigio.base_stats["health"] = 250;
         Prodigio.base_stats["accuracy"] = 0.30f;
         Prodigio.base_stats["range"] = 0.30f;
         Prodigio.base_stats["armor"] = 80;
         Prodigio.base_stats["skill_combat"] = 0.40f;
         Prodigio.base_stats["critical_chance"] = 0.70f;
         Prodigio.base_stats["knockback"] = 0.5f;
//         Prodigio.base_stats["knockback_reduction"] = 1.0f;
         Prodigio.base_stats["intelligence"] = 40;
         Prodigio.base_stats["warfare"] = 40;
         Prodigio.base_stats["diplomacy"] = 20;
         Prodigio.base_stats["stewardship"] = 20;
         Prodigio.base_stats["opinion"] = 20f;
         Prodigio.base_stats["loyalty_traits"] = 20f;
         Prodigio.base_stats["cities"] = 40;
         Prodigio.base_stats["area_of_effect"] = 20;
////         Prodigio.opposite = "EnfermoMental,Autista,weak,fat,slow,Esquizofrenico,sidoso,Decepcionante";			
		 
		 
		 ActorTrait Presumido= new ActorTrait();
         Presumido.id = "Presumido";
         Presumido.path_icon = "ui/Icons/Presumido";
         Presumido.type = TraitType.Negative;
         Presumido.group_id = TraitGroup.BadNaturalTraits;
         Presumido.can_be_given = true;
         Presumido.can_be_removed = true;
         Presumido.rate_birth = 1;
         Presumido.rate_inherit = 1;
         AssetManager.traits.add(Presumido);
         Presumido.base_stats["birth_rate"] = 1;
         Presumido.base_stats["multiplier_lifespan"] = -1f;
         Presumido.base_stats["intelligence"] = -1;
         Presumido.base_stats["warfare"] = -5;
         Presumido.base_stats["diplomacy"] = -13;
         Presumido.base_stats["opinion"] = -10f;
         Presumido.base_stats["loyalty_traits"] = -1f;
////         Presumido.opposite = "EnfermoMental,Sencillo,Sociable,Comprensible,Coherente";			
		 
		 
		 ActorTrait Introvertido= new ActorTrait();
         Introvertido.id = "Introvertido";
         Introvertido.path_icon = "ui/Icons/Introvertido";
         Introvertido.type = TraitType.Other;
         Introvertido.group_id = TraitGroup.NaturalTraits;
         Introvertido.can_be_given = true;
         Introvertido.can_be_removed = true;
         Introvertido.rate_birth = 1;
         Introvertido.rate_inherit = 1;
         AssetManager.traits.add(Introvertido);
         Introvertido.base_stats["birth_rate"] = 1;
         Introvertido.base_stats["multiplier_lifespan"] = 4f;
         Introvertido.base_stats["health"] = 4;
         Introvertido.base_stats["stewardship"] = -7;
         Introvertido.base_stats["loyalty_traits"] = -1f;
////         Introvertido.opposite = "Autista,Sociable,Carismatico,Cooperativo";			
		 
		 
		 
		 ActorTrait SuperVida= new ActorTrait();
         SuperVida.id = "Super Vida";
         SuperVida.path_icon = "ui/Icons/SuperVida";
         SuperVida.type = TraitType.Other;
         SuperVida.group_id = TraitGroup.LegendaryTraits;
         SuperVida.can_be_given = true;
         SuperVida.can_be_removed = true;
         SuperVida.rate_birth = 1;
         SuperVida.rate_inherit = 1;
         AssetManager.traits.add(SuperVida);
         SuperVida.base_stats["multiplier_lifespan"] = 5f;
         SuperVida.base_stats["health"] = 900;
////         SuperVida.opposite = "EnfermoMental,Autista,Anorexico,Esquizofrenico,Decepcionante,sidoso";			
		 
		 
		 ActorTrait Soñador= new ActorTrait();
         Soñador.id = "Soñador";
         Soñador.path_icon = "ui/Icons/Soñador";
         Soñador.type = TraitType.Other;
         Soñador.group_id = TraitGroup.NaturalTraits;
         Soñador.can_be_given = true;
         Soñador.can_be_removed = true;
         Soñador.rate_birth = 1;
         Soñador.rate_inherit = 1;
         AssetManager.traits.add(Soñador);
         Soñador.base_stats["multiplier_offspring"] = 0.5f;
         Soñador.base_stats["birth_rate"] = 1;
         Soñador.base_stats["multiplier_lifespan"] = 5f;
         Soñador.base_stats["accuracy"] = 0.70f;
         Soñador.base_stats["armor"] = 2;
         Soñador.base_stats["intelligence"] = 2;
         Soñador.base_stats["warfare"] = 4;
         Soñador.base_stats["diplomacy"] = 3;
         Soñador.base_stats["stewardship"] = 3;
         Soñador.base_stats["loyalty_traits"] = 2f;
         Soñador.base_stats["cities"] = 4;
         Soñador.base_stats["area_of_effect"] = 4;
////         Soñador.opposite = "EnfermoMental,Autista,Serio,Descontrolado,Decepcionante";			
		 
		 
		 ActorTrait Sidoso= new ActorTrait();
         Sidoso.id = "Sidoso";
         Sidoso.path_icon = "ui/Icons/Sidoso";
         Sidoso.type = TraitType.Other;
         Sidoso.group_id = TraitGroup.BadNaturalTraits;
         Sidoso.can_be_given = true;
         Sidoso.can_be_removed = true;
         Sidoso.rate_birth = 1;
         Sidoso.rate_inherit = 1;
         AssetManager.traits.add(Sidoso);
         Sidoso.base_stats["birth_rate"] = 1;
         Sidoso.base_stats["multiplier_lifespan"] = -10f;
         Sidoso.base_stats["damage"] = -5;
         Sidoso.base_stats["diplomacy"] = -2;
         Sidoso.base_stats["stewardship"] = -3;
         Sidoso.base_stats["opinion"] = -10f;
         Sidoso.base_stats["loyalty_traits"] = 2f;
////         Sidoso.opposite = "SuperFuerte,SuperAgil,SuperResistente,Prodigio,SuperVida";			
		 
		 
		 ActorTrait Extrovertido= new ActorTrait();
         Extrovertido.id = "Extrovertido";
         Extrovertido.path_icon = "ui/Icons/Extrovertido";
         Extrovertido.type = TraitType.Other;
         Extrovertido.group_id = TraitGroup.NaturalTraits;
         Extrovertido.can_be_given = true;
         Extrovertido.can_be_removed = true;
         Extrovertido.rate_birth = 1;
         Extrovertido.rate_inherit = 1;
         AssetManager.traits.add(Extrovertido);
         Extrovertido.base_stats["speed"] = 3f;
         Extrovertido.base_stats["health"] = 5;
         Extrovertido.base_stats["warfare"] = 2;
         Extrovertido.base_stats["diplomacy"] = 2;
         Extrovertido.base_stats["stewardship"] = 2;
         Extrovertido.base_stats["opinion"] = 12f;
         Extrovertido.base_stats["loyalty_traits"] = 4f;
         Extrovertido.base_stats["cities"] = 5;
         Extrovertido.base_stats["area_of_effect"] = 5;
////         Extrovertido.opposite = "Introvertido,Asocial,Solitario,Decepcionante";			
		 
		 
		 ActorTrait Perfeccionista= new ActorTrait();
         Perfeccionista.id = "Perfeccionista";
         Perfeccionista.path_icon = "ui/Icons/Perfeccionista";
         Perfeccionista.type = TraitType.Other;
         Perfeccionista.group_id = TraitGroup.NaturalTraits;
         Perfeccionista.can_be_given = true;
         Perfeccionista.can_be_removed = true;
         Perfeccionista.rate_birth = 1;
         Perfeccionista.rate_inherit = 1;
         AssetManager.traits.add(Perfeccionista);
         Perfeccionista.base_stats["diplomacy"] = 8;
         Perfeccionista.base_stats["stewardship"] = 8;
         Perfeccionista.base_stats["loyalty_traits"] = 8f;
         Perfeccionista.base_stats["cities"] = 8;
         Perfeccionista.base_stats["area_of_effect"] = 8;
////         Perfeccionista.opposite = "Descuidado,Despistado,Miedoso,Decepcionante";			
		 
		 
		 ActorTrait Tranquilo= new ActorTrait();
         Tranquilo.id = "Tranquilo";
         Tranquilo.path_icon = "ui/Icons/Tranquilo";
         Tranquilo.type = TraitType.Other;
         Tranquilo.group_id = TraitGroup.NaturalTraits;
         Tranquilo.can_be_given = true;
         Tranquilo.can_be_removed = true;
         Tranquilo.rate_birth = 1;
         Tranquilo.rate_inherit = 1;
         AssetManager.traits.add(Tranquilo);
         Tranquilo.base_stats["birth_rate"] = 1;
         Tranquilo.base_stats["multiplier_lifespan"] = 4f;
         Tranquilo.base_stats["damage"] = -1;
         Tranquilo.base_stats["intelligence"] = 0.30f;
         Tranquilo.base_stats["warfare"] = 1;
         Tranquilo.base_stats["diplomacy"] = 2;
         Tranquilo.base_stats["stewardship"] = 2;
////         Tranquilo.opposite = "Descontrolado,Cruel,Bipolar,Desastroso";			
		 
		 
		 ActorTrait Respetuoso= new ActorTrait();
         Respetuoso.id = "Respetuoso";
         Respetuoso.path_icon = "ui/Icons/Respetuoso";
         Respetuoso.type = TraitType.Other;
         Respetuoso.group_id = TraitGroup.NaturalTraits;
         Respetuoso.can_be_given = true;
         Respetuoso.can_be_removed = true;
         Respetuoso.rate_birth = 1;
         Respetuoso.rate_inherit = 1;
         AssetManager.traits.add(Respetuoso);
         Respetuoso.base_stats["intelligence"] = 0.30f;
         Respetuoso.base_stats["diplomacy"] = 4;
         Respetuoso.base_stats["stewardship"] = 2;
         Respetuoso.base_stats["opinion"] = 15f;
////         Respetuoso.opposite = "Desconsiderado,Insensato,Narcisista,Egocentrico,Burlon,Decepcionante";			
		 
		 
		 ActorTrait Sensato= new ActorTrait();
         Sensato.id = "Sensato";
         Sensato.path_icon = "ui/Icons/Sensato";
         Sensato.type = TraitType.Other;
         Sensato.group_id = TraitGroup.NaturalTraits;
         Sensato.can_be_given = true;
         Sensato.can_be_removed = true;
         Sensato.rate_birth = 1;
         Sensato.rate_inherit = 1;
         AssetManager.traits.add(Sensato);
         Sensato.base_stats["accuracy"] = 0.1f;
         Sensato.base_stats["diplomacy"] = 4;
         Sensato.base_stats["stewardship"] = 4;
////         Sensato.opposite = "Insensato,Decepcionante";			
		 
		 
		 ActorTrait Acomplejado= new ActorTrait();
         Acomplejado.id = "Acomplejado";
         Acomplejado.path_icon = "ui/Icons/Acomplejado";
         Acomplejado.type = TraitType.Other;
         Acomplejado.group_id = TraitGroup.BadNaturalTraits;
         Acomplejado.can_be_given = true;
         Acomplejado.can_be_removed = true;
         Acomplejado.rate_birth = 1;
         Acomplejado.rate_inherit = 1;
         AssetManager.traits.add(Acomplejado);
         Acomplejado.base_stats["attack_speed"] = -1;
         Acomplejado.base_stats["accuracy"] = -0.2f;
         Acomplejado.base_stats["intelligence"] = -4.50f;
         Acomplejado.base_stats["opinion"] = -1f;
////         Acomplejado.opposite = "Tolerante";			
		 
		 
		 ActorTrait Conciliador= new ActorTrait();
         Conciliador.id = "Conciliador";
         Conciliador.path_icon = "ui/Icons/Conciliador";
         Conciliador.type = TraitType.Other;
         Conciliador.group_id = TraitGroup.NaturalTraits;
         Conciliador.can_be_given = true;
         Conciliador.can_be_removed = true;
         Conciliador.rate_birth = 1;
         Conciliador.rate_inherit = 1;
         AssetManager.traits.add(Conciliador);
         Conciliador.base_stats["attack_speed"] = -1;
         Conciliador.base_stats["accuracy"] = -0.2f;
         Conciliador.base_stats["intelligence"] = -1f;
         Conciliador.base_stats["diplomacy"] = 4;
         Conciliador.base_stats["opinion"] = 12f;
////         Conciliador.opposite = "Confiado";			
		 
		 
		 ActorTrait Oportunista= new ActorTrait();
         Oportunista.id = "Oportunista";
         Oportunista.path_icon = "ui/Icons/Oportunista";
         Oportunista.type = TraitType.Other;
         Oportunista.group_id = TraitGroup.NaturalTraits;
         Oportunista.can_be_given = true;
         Oportunista.can_be_removed = true;
         Oportunista.rate_birth = 1;
         Oportunista.rate_inherit = 1;
         AssetManager.traits.add(Oportunista);
         Oportunista.base_stats["birth_rate"] = 1;
         Oportunista.base_stats["attack_speed"] = 2;
         Oportunista.base_stats["health"] = 1;
         Oportunista.base_stats["accuracy"] = 0.2f;
         Oportunista.base_stats["range"] = 0.3f;
         Oportunista.base_stats["critical_chance"] = 0.3f;
         Oportunista.base_stats["knockback"] = 0.2f;
         Oportunista.base_stats["intelligence"] = 4f;
         Oportunista.base_stats["stewardship"] = 2;
         Oportunista.base_stats["opinion"] = -1f;
         Oportunista.base_stats["area_of_effect"] = 3;
////         Oportunista.opposite = "Acomplejado,Decepcionante";			
		 
		 
		 ActorTrait Asimiladora= new ActorTrait();
         Asimiladora.id = "Asimilador";
         Asimiladora.path_icon = "ui/Icons/Asimiladora";
         Asimiladora.type = TraitType.Other;
         Asimiladora.group_id = TraitGroup.NaturalTraits;
         Asimiladora.can_be_given = true;
         Asimiladora.can_be_removed = true;
         Asimiladora.rate_birth = 1;
         Asimiladora.rate_inherit = 1;
         AssetManager.traits.add(Asimiladora);
         Asimiladora.base_stats["range"] = 0.1f;
         Asimiladora.base_stats["intelligence"] = 1f;
         Asimiladora.base_stats["warfare"] = 4;
         Asimiladora.base_stats["diplomacy"] = 4;
         Asimiladora.base_stats["stewardship"] = 5;
         Asimiladora.base_stats["cities"] = 2;
         Asimiladora.base_stats["area_of_effect"] = 3;
////         Asimiladora.opposite = "Estupido,Descuidado,Despistado,EnfermoMental,Decepcionante";			
		 
		 
		 ActorTrait Amable= new ActorTrait();
         Amable.id = "Amable";
         Amable.path_icon = "ui/Icons/Amable";
         Amable.type = TraitType.Other;
         Amable.group_id = TraitGroup.NaturalTraits;
         Amable.can_be_given = true;
         Amable.can_be_removed = true;
         Amable.rate_birth = 1;
         Amable.rate_inherit = 1;
         AssetManager.traits.add(Amable);
         Amable.base_stats["birth_rate"] = 1;
         Amable.base_stats["multiplier_lifespan"] = 2f;
         Amable.base_stats["diplomacy"] += 5;
         Amable.base_stats["opinion"] = 5f;
         Amable.base_stats["loyalty_traits"] = 6.5f;
////         Amable.opposite = "Cruel,Desconsiderado,Desleal";			
		 
		 
		 ActorTrait Astuto= new ActorTrait();
         Astuto.id = "Astuto";
         Astuto.path_icon = "ui/Icons/Astuto";
         Astuto.type = TraitType.Other;
         Astuto.group_id = TraitGroup.NaturalTraits;
         Astuto.can_be_given = true;
         Astuto.can_be_removed = true;
         Astuto.rate_birth = 1;
         Astuto.rate_inherit = 1;
         AssetManager.traits.add(Astuto);
         Astuto.base_stats["intelligence"] = 5;
         Astuto.base_stats["diplomacy"] = 2;
         Astuto.base_stats["stewardship"] = 4;
////         Astuto.opposite = "Estupido,Decepcionante";			
		 
		 
		 ActorTrait Cínico= new ActorTrait();
         Cínico.id = "Cínico";
         Cínico.path_icon = "ui/Icons/Cínico";
         Cínico.type = TraitType.Other;
         Cínico.group_id = TraitGroup.BadNaturalTraits;
         Cínico.can_be_given = true;
         Cínico.can_be_removed = true;
         Cínico.rate_birth = 1;
         Cínico.rate_inherit = 1;
         AssetManager.traits.add(Cínico);
         Cínico.base_stats["attack_speed"] = 4;
         Cínico.base_stats["damage"] = 2.10f;
         Cínico.base_stats["range"] = 0.1f;
         Cínico.base_stats["armor"] = 5;
         Cínico.base_stats["critical_chance"] = 0.40f;
         Cínico.base_stats["intelligence"] = 1;
         Cínico.base_stats["warfare"] = 5;
         Cínico.base_stats["diplomacy"] = -10;
         Cínico.base_stats["opinion"] = -12f;
////         Cínico.opposite = "Tranquilo,Amable,Flexible";			
		 
		 
		 ActorTrait Conformista= new ActorTrait();
         Conformista.id = "Conformista";
         Conformista.path_icon = "ui/Icons/Conformista";
         Conformista.type = TraitType.Other;
         Conformista.group_id = TraitGroup.NaturalTraits;
         Conformista.can_be_given = true;
         Conformista.can_be_removed = true;
         Conformista.rate_birth = 1;
         Conformista.rate_inherit = 1;
         AssetManager.traits.add(Conformista);
         Conformista.base_stats["diplomacy"] += 15;
         Conformista.base_stats["stewardship"] += 15;
         Conformista.base_stats["loyalty_traits"] = 8f;
////         Conformista.opposite = "Travieso,EnfermoMental";			
		 
		 
		 ActorTrait Corrupto= new ActorTrait();
         Corrupto.id = "Corrupto";
         Corrupto.path_icon = "ui/Icons/Corrupto";
         Corrupto.type = TraitType.Other;
         Corrupto.group_id = TraitGroup.BadNaturalTraits;
         Corrupto.can_be_given = true;
         Corrupto.can_be_removed = true;
         Corrupto.rate_birth = 1;
         Corrupto.rate_inherit = 1;
         AssetManager.traits.add(Corrupto);
         Corrupto.base_stats["intelligence"] = 4;
         Corrupto.base_stats["warfare"] = 4;
         Corrupto.base_stats["diplomacy"] -= 10;
         Corrupto.base_stats["stewardship"] -= 15;
         Corrupto.base_stats["opinion"] -= 10f;
         Corrupto.base_stats["loyalty_traits"] = -4f;
         Corrupto.base_stats["cities"] = 3;
         Corrupto.base_stats["area_of_effect"] = 3;
////         Corrupto.opposite = "Leal,Justo,Honorable";			
		 
		 
		 ActorTrait Detallista= new ActorTrait();
         Detallista.id = "Detallista";
         Detallista.path_icon = "ui/Icons/Detallista";
         Detallista.type = TraitType.Other;
         Detallista.group_id = TraitGroup.NaturalTraits;
         Detallista.can_be_given = true;
         Detallista.can_be_removed = true;
         Detallista.rate_birth = 1;
         Detallista.rate_inherit = 1;
         AssetManager.traits.add(Detallista);
         Detallista.base_stats["multiplier_offspring"] = 0.2f;
         Detallista.base_stats["birth_rate"] = 1;
         Detallista.base_stats["accuracy"] = 0.350f;
         Detallista.base_stats["intelligence"] = 1;
         Detallista.base_stats["diplomacy"] = 4;
         Detallista.base_stats["stewardship"] = 7;
         Detallista.base_stats["opinion"] = 24f;
         Detallista.base_stats["loyalty_traits"] = 8f;
         Detallista.base_stats["cities"] = 1;
         Detallista.base_stats["area_of_effect"] = 1;
////         Detallista.opposite = "Pesimista,Torpe,Estupido,Decepcionante";			
		 
		 
		 ActorTrait Discriminante= new ActorTrait();
         Discriminante.id = "Discriminante";
         Discriminante.path_icon = "ui/Icons/Discriminante";
         Discriminante.type = TraitType.Other;
         Discriminante.group_id = TraitGroup.BadNaturalTraits;
         Discriminante.can_be_given = true;
         Discriminante.can_be_removed = true;
         Discriminante.rate_birth = 1;
         Discriminante.rate_inherit = 1;
         AssetManager.traits.add(Discriminante);
         Discriminante.base_stats["multiplier_damage"] += 0.5f;
         Discriminante.base_stats["diplomacy"] = -7;
         Discriminante.base_stats["stewardship"] = -6;
         Discriminante.base_stats["opinion"] = -20f;
         Discriminante.base_stats["loyalty_traits"] = -4f;
////         Discriminante.opposite = "Amable,Justo,Respetuoso";			
		 
		 
		 ActorTrait Distante= new ActorTrait();
         Distante.id = "Distante";
         Distante.path_icon = "ui/Icons/Distante";
         Distante.type = TraitType.Other;
         Distante.group_id = TraitGroup.NaturalTraits;
         Distante.can_be_given = true;
         Distante.can_be_removed = true;
         Distante.rate_birth = 1;
         Distante.rate_inherit = 1;
         AssetManager.traits.add(Distante);
         Distante.base_stats["range"] = 0.20f;
         Distante.base_stats["skill_combat"] = 0.20f;
         Distante.base_stats["opinion"] = -7f;
         Distante.base_stats["loyalty_traits"] -= 15f;
         Distante.base_stats["cities"] = -2;
         Distante.base_stats["area_of_effect"] = -2;
////         Distante.opposite = "Sociable,Cooperativo";			
		 
		 
		 ActorTrait Escéptico= new ActorTrait();
         Escéptico.id = "Escéptico";
         Escéptico.path_icon = "ui/Icons/Escéptico";
         Escéptico.type = TraitType.Other;
         Escéptico.group_id = TraitGroup.NaturalTraits;
         Escéptico.can_be_given = true;
         Escéptico.can_be_removed = true;
         Escéptico.rate_birth = 1;
         Escéptico.rate_inherit = 1;
         AssetManager.traits.add(Escéptico);
         Escéptico.base_stats["targets"] = 0.2f;
         Escéptico.base_stats["critical_chance"] = 0.01f;
         Escéptico.base_stats["diplomacy"] = 4;
         Escéptico.base_stats["opinion"] += 5f;
         Escéptico.base_stats["loyalty_traits"] += 6f;
////         Escéptico.opposite = "Decepcionante";			
		 
		 
		 ActorTrait Espontaneo= new ActorTrait();
         Espontaneo.id = "Espontaneo";
         Espontaneo.path_icon = "ui/Icons/Espontaneo";
         Espontaneo.type = TraitType.Other;
         Espontaneo.group_id = TraitGroup.NaturalTraits;
         Espontaneo.can_be_given = true;
         Espontaneo.can_be_removed = true;
         Espontaneo.rate_birth = 1;
         Espontaneo.rate_inherit = 1;
         AssetManager.traits.add(Espontaneo);
         Espontaneo.base_stats["skill_combat"] = 0.55f;
         Espontaneo.base_stats["warfare"] = 5;
         Espontaneo.base_stats["diplomacy"] = 12;
         Espontaneo.base_stats["stewardship"] = 6;
         Espontaneo.base_stats["cities"] = 3;
         Espontaneo.base_stats["area_of_effect"] = 3;
////         Espontaneo.opposite = "Decepcionante";			
		 
		 
		 ActorTrait Fogoso= new ActorTrait();
         Fogoso.id = "Fogoso";
         Fogoso.path_icon = "ui/Icons/Fogoso";
         Fogoso.type = TraitType.Other;
         Fogoso.group_id = TraitGroup.NaturalTraits;
         Fogoso.can_be_given = true;
         Fogoso.can_be_removed = true;
         Fogoso.rate_birth = 1;
         Fogoso.rate_inherit = 1;
         AssetManager.traits.add(Fogoso);
         Fogoso.base_stats["multiplier_offspring"] = 0.4f;
         Fogoso.base_stats["birth_rate"] = 1;
         Fogoso.base_stats["opinion"] = -1f;
////         Fogoso.opposite = "Decepcionante";			
		 
		 
		 ActorTrait Frio= new ActorTrait();
         Frio.id = "Frio";
         Frio.path_icon = "ui/Icons/Frio";
         Frio.type = TraitType.Other;
         Frio.group_id = TraitGroup.BadNaturalTraits;
         Frio.can_be_given = true;
         Frio.can_be_removed = true;
         Frio.rate_birth = 1;
         Frio.rate_inherit = 1;
         AssetManager.traits.add(Frio);
         Frio.base_stats["intelligence"] = 1;
         Frio.base_stats["warfare"] = 4;
         Frio.base_stats["diplomacy"] = -7.90f;
         Frio.base_stats["stewardship"] = -3;
         Frio.base_stats["opinion"] = -15f;
////         Frio.opposite = "Amable,Flexible,Empatico";			
		 
		 
		 ActorTrait Honrado= new ActorTrait();
         Honrado.id = "Honrado";
         Honrado.path_icon = "ui/Icons/Honrado";
         Honrado.type = TraitType.Other;
         Honrado.group_id = TraitGroup.NaturalTraits;
         Honrado.can_be_given = true;
         Honrado.can_be_removed = true;
         Honrado.rate_birth = 1;
         Honrado.rate_inherit = 1;
         AssetManager.traits.add(Honrado);
         Honrado.base_stats["accuracy"] = 0.20f;
         Honrado.base_stats["opinion"] += 26f;
         Honrado.base_stats["loyalty_traits"] += 20f;
////         Honrado.opposite = "Cruel,Psicopata,Estupido,Autista,Asocial,Decepcionante";			
		 
		 
		 ActorTrait Impulsivo= new ActorTrait();
         Impulsivo.id = "Impulsivo";
         Impulsivo.path_icon = "ui/Icons/Impulsivo";
         Impulsivo.type = TraitType.Other;
         Impulsivo.group_id = TraitGroup.BadNaturalTraits;
         Impulsivo.can_be_given = true;
         Impulsivo.can_be_removed = true;
         Impulsivo.rate_birth = 1;
         Impulsivo.rate_inherit = 1;
         AssetManager.traits.add(Impulsivo);
         Impulsivo.base_stats["damage"] = 1.40f;
         Impulsivo.base_stats["speed"] += 36f;
         Impulsivo.base_stats["health"] += 12;
         Impulsivo.base_stats["range"] = 0.57f;
         Impulsivo.base_stats["warfare"] = -7;
         Impulsivo.base_stats["opinion"] = 5f;
////         Impulsivo.opposite = "Tranquilo,Decepcionante";			
		 
		 
		 ActorTrait Meticuloso= new ActorTrait();
         Meticuloso.id = "Meticuloso";
         Meticuloso.path_icon = "ui/Icons/Meticuloso";
         Meticuloso.type = TraitType.Other;
         Meticuloso.group_id = TraitGroup.NaturalTraits;
         Meticuloso.can_be_given = true;
         Meticuloso.can_be_removed = true;
         Meticuloso.rate_birth = 1;
         Meticuloso.rate_inherit = 1;
         AssetManager.traits.add(Meticuloso);
         Meticuloso.base_stats["knockback"] = 0.4f;
         Meticuloso.base_stats["intelligence"] = 1;
         Meticuloso.base_stats["warfare"] = 6;
         Meticuloso.base_stats["opinion"] = 5f;
////         Meticuloso.opposite = "Desconfiado,Decepcionante";			
		 
		 
		 ActorTrait Proactivo= new ActorTrait();
         Proactivo.id = "Proactivo";
         Proactivo.path_icon = "ui/Icons/Proactivo";
         Proactivo.type = TraitType.Other;
         Proactivo.group_id = TraitGroup.NaturalTraits;
         Proactivo.can_be_given = true;
         Proactivo.can_be_removed = true;
         Proactivo.rate_birth = 1;
         Proactivo.rate_inherit = 1;
         AssetManager.traits.add(Proactivo);
         Proactivo.base_stats["multiplier_offspring"] = 0.05f;
         Proactivo.base_stats["attack_speed"] = 4;
         Proactivo.base_stats["damage"] += 2;
         Proactivo.base_stats["armor"] += 5;
         Proactivo.base_stats["skill_combat"] += 10f;
         Proactivo.base_stats["knockback"] = 0.10f;
//         Proactivo.base_stats["knockback_reduction"] = 0.21f;
         Proactivo.base_stats["diplomacy"] = 5;
         Proactivo.base_stats["stewardship"] = 5;
         Proactivo.base_stats["loyalty_traits"] = 5f;
////         Proactivo.opposite = "Descuidado,Estupido,Autista,EnfermoMental,Decepcionante";			
		 
		 
		 ActorTrait Romántico= new ActorTrait();
         Romántico.id = "Romántico";
         Romántico.path_icon = "ui/Icons/Romántico";
         Romántico.type = TraitType.Other;
         Romántico.group_id = TraitGroup.NaturalTraits;
         Romántico.can_be_given = true;
         Romántico.can_be_removed = true;
         Romántico.rate_birth = 1;
         Romántico.rate_inherit = 1;
         AssetManager.traits.add(Romántico);
         Romántico.base_stats["targets"] = 0.1f;
         Romántico.base_stats["diplomacy"] += 10;
         Romántico.base_stats["opinion"] = 2f;
         Romántico.base_stats["loyalty_traits"] += 5f;
////         Romántico.opposite = "Cruel,Desvergonzado,Desconsiderado,Decepcionante";			
		 
		 
		 ActorTrait Sobornante= new ActorTrait();
         Sobornante.id = "Sobornante";
         Sobornante.path_icon = "ui/Icons/Sobornante";
         Sobornante.type = TraitType.Other;
         Sobornante.group_id = TraitGroup.NaturalTraits;
         Sobornante.can_be_given = true;
         Sobornante.can_be_removed = true;
         Sobornante.rate_birth = 1;
         Sobornante.rate_inherit = 1;
         AssetManager.traits.add(Sobornante);
         Sobornante.base_stats["armor"] = 5;
         Sobornante.base_stats["intelligence"] = 3;
         Sobornante.base_stats["warfare"] = 1;
         Sobornante.base_stats["diplomacy"] = 15;
         Sobornante.base_stats["stewardship"] = 2;
         Sobornante.base_stats["opinion"] = 1f;
         Sobornante.base_stats["loyalty_traits"] = 3f;
////         Sobornante.opposite = "Justo";			
		 
		 
		 ActorTrait SuperGrande= new ActorTrait();
         SuperGrande.id = "Super Grande";
         SuperGrande.path_icon = "ui/Icons/SuperGrande";
         SuperGrande.type = TraitType.Other;
         SuperGrande.group_id = TraitGroup.LegendaryTraits;
         SuperGrande.can_be_given = true;
         SuperGrande.can_be_removed = true;
         SuperGrande.rate_birth = 1;
         SuperGrande.rate_inherit = 1;
         AssetManager.traits.add(SuperGrande);
         SuperGrande.base_stats["damage"] = 40;
         SuperGrande.base_stats["speed"] = -30f;
         SuperGrande.base_stats["health"] = 120;
         SuperGrande.base_stats["range"] = 1.10f;
         SuperGrande.base_stats["armor"] = 20;
         SuperGrande.base_stats["scale"] = 0.080f;
////         SuperGrande.opposite = "tiny,Anorexico,Decepcionante";			
		 
		 
		 ActorTrait Susceptible= new ActorTrait();
         Susceptible.id = "Susceptible";
         Susceptible.path_icon = "ui/Icons/Susceptible";
         Susceptible.type = TraitType.Other;
         Susceptible.group_id = TraitGroup.BadNaturalTraits;
         Susceptible.can_be_given = true;
         Susceptible.can_be_removed = true;
         Susceptible.rate_birth = 1;
         Susceptible.rate_inherit = 1;
         AssetManager.traits.add(Susceptible);
         Susceptible.base_stats["damage"] = -10;
         Susceptible.base_stats["speed"] = -8f;
         Susceptible.base_stats["health"] = -5;
         Susceptible.base_stats["intelligence"] = -4;
         Susceptible.base_stats["diplomacy"] = -15;
         Susceptible.base_stats["stewardship"] = -5;
         Susceptible.base_stats["opinion"] = -2f;
         Susceptible.base_stats["loyalty_traits"] = 2f;
         Susceptible.base_stats["cities"] = -1;
         Susceptible.base_stats["area_of_effect"] = -1;
////         Susceptible.opposite = "Resiliente,Resistente";			
		 
		 
		 ActorTrait Tacaño= new ActorTrait();
         Tacaño.id = "Tacaño";
         Tacaño.path_icon = "ui/Icons/Tacaño";
         Tacaño.type = TraitType.Other;
         Tacaño.group_id = TraitGroup.BadNaturalTraits;
         Tacaño.can_be_given = true;
         Tacaño.can_be_removed = true;
         Tacaño.rate_birth = 1;
         Tacaño.rate_inherit = 1;
         AssetManager.traits.add(Tacaño);
         Tacaño.base_stats["range"] = 0.05f;
         Tacaño.base_stats["targets"] = 0.5f;
         Tacaño.base_stats["diplomacy"] -= 10.45f;
         Tacaño.base_stats["stewardship"] -= 6;
         Tacaño.base_stats["opinion"] -= 7.65f;
         Tacaño.base_stats["cities"] = 3;
         Tacaño.base_stats["area_of_effect"] = 4;
////         Tacaño.opposite = "Amable,Altruista";			
		 
		 
		 ActorTrait Tirano= new ActorTrait();
         Tirano.id = "Tirano";
         Tirano.path_icon = "ui/Icons/Tirano";
         Tirano.type = TraitType.Other;
         Tirano.group_id = TraitGroup.BadNaturalTraits;
         Tirano.can_be_given = true;
         Tirano.can_be_removed = true;
         Tirano.rate_birth = 1;
         Tirano.rate_inherit = 1;
         AssetManager.traits.add(Tirano);
         Tirano.base_stats["damage"] = 2;
         Tirano.base_stats["multiplier_diplomacy"] -= 0.03f;
         Tirano.base_stats["opinion"] = 6f;
         Tirano.base_stats["loyalty_traits"] = -17.20f;
         Tirano.base_stats["cities"] = 12;
         Tirano.base_stats["area_of_effect"] = 16;
////         Tirano.opposite = "Justo,Amable,Tranquilo,Leal";			
		 
		 
		 ActorTrait Travieso= new ActorTrait();
         Travieso.id = "Travieso";
         Travieso.path_icon = "ui/Icons/Travieso";
         Travieso.type = TraitType.Other;
         Travieso.group_id = TraitGroup.NaturalTraits;
         Travieso.can_be_given = true;
         Travieso.can_be_removed = true;
         Travieso.rate_birth = 1;
         Travieso.rate_inherit = 1;
         AssetManager.traits.add(Travieso);
         Travieso.base_stats["attack_speed"] = 6;
         Travieso.base_stats["multiplier_speed"] = 0.020f;
         Travieso.base_stats["critical_chance"] = 0.23f;
         Travieso.base_stats["warfare"] = -1.20f;
         Travieso.base_stats["diplomacy"] = -7;
         Travieso.base_stats["stewardship"] = 5.40f;
         Travieso.base_stats["opinion"] = 1f;
////         Travieso.opposite = "Formal,Tranquilo,Inseguro";			
		 
		 
		 
		 ActorTrait Vanidoso= new ActorTrait();
         Vanidoso.id = "Vanidoso";
         Vanidoso.path_icon = "ui/Icons/Vanidoso";
         Vanidoso.type = TraitType.Other;
         Vanidoso.group_id = TraitGroup.NaturalTraits;
         Vanidoso.can_be_given = true;
         Vanidoso.can_be_removed = true;
         Vanidoso.rate_birth = 1;
         Vanidoso.rate_inherit = 1;
         AssetManager.traits.add(Vanidoso);
         Vanidoso.base_stats["multiplier_lifespan"] = -7.20f;
         Vanidoso.base_stats["diplomacy"] = -5;
         Vanidoso.base_stats["stewardship"] = 2;
         Vanidoso.base_stats["opinion"] = -10f;
////         Vanidoso.opposite = "Leal,Tranquilo";			
		 
		 
		 ActorTrait Versatil= new ActorTrait();
         Versatil.id = "Versatil";
         Versatil.path_icon = "ui/Icons/Versatil";
         Versatil.type = TraitType.Other;
         Versatil.group_id = TraitGroup.Physicalconditions;
         Versatil.can_be_given = true;
         Versatil.can_be_removed = true;
         Versatil.rate_birth = 1;
         Versatil.rate_inherit = 1;
         AssetManager.traits.add(Versatil);
         Versatil.base_stats["multiplier_offspring"] = 0.05f;
         Versatil.base_stats["multiplier_attack_speed"] += 0.4f;
         Versatil.base_stats["multiplier_damage"] += 0.3f;
         Versatil.base_stats["multiplier_damage"] += 0.50f;
         Versatil.base_stats["armor"] = 5;
         Versatil.base_stats["skill_combat"] = 0.12f;
         Versatil.base_stats["critical_chance"] = 0.012f;
         Versatil.base_stats["warfare"] = 1;
////         Versatil.opposite = "Esquizofrenico,Sidoso,EnfermoMental,Decepcionante";			
		 
		 
		 ActorTrait Obediente= new ActorTrait();
         Obediente.id = "Obediente";
         Obediente.path_icon = "ui/Icons/Obediente";
         Obediente.type = TraitType.Other;
         Obediente.group_id = TraitGroup.NaturalTraits;
         Obediente.can_be_given = true;
         Obediente.can_be_removed = true;
         Obediente.rate_birth = 1;
         Obediente.rate_inherit = 1;
         AssetManager.traits.add(Obediente);
         Obediente.base_stats["attack_speed"] = 1;
         Obediente.base_stats["speed"] = 3f;
         Obediente.base_stats["accuracy"] = 5f;
         Obediente.base_stats["targets"] = 0.2f;
         Obediente.base_stats["diplomacy"] = 2;
         Obediente.base_stats["stewardship"] = 7;
         Obediente.base_stats["opinion"] += 5f;
////         Obediente.opposite = "Decepcionante,Desconsiderado,Traicionero,Despistado";			
		 
		 
		 ActorTrait Sobrio= new ActorTrait();
         Sobrio.id = "Sobrio";
         Sobrio.path_icon = "ui/Icons/Sobrio";
         Sobrio.type = TraitType.Other;
         Sobrio.group_id = TraitGroup.NaturalTraits;
         Sobrio.can_be_given = true;
         Sobrio.can_be_removed = true;
         Sobrio.rate_birth = 1;
         Sobrio.rate_inherit = 1;
         AssetManager.traits.add(Sobrio);
         Sobrio.base_stats["warfare"] = 2;
         Sobrio.base_stats["diplomacy"] = 8;
         Sobrio.base_stats["stewardship"] = 2;
         Sobrio.base_stats["opinion"] = 6f;
         Sobrio.base_stats["loyalty_traits"] += 32f;
         Sobrio.base_stats["cities"] = 1;
////         Sobrio.opposite = "Despistado,Desvergonzado";			
		 
		 
		 ActorTrait Reservado= new ActorTrait();
         Reservado.id = "Reservado";
         Reservado.path_icon = "ui/Icons/Reservado";
         Reservado.type = TraitType.Other;
         Reservado.group_id = TraitGroup.NaturalTraits;
         Reservado.can_be_given = true;
         Reservado.can_be_removed = true;
         Reservado.rate_birth = 124;
		 AssetManager.traits.add(Reservado);
         Reservado.base_stats["diplomacy"] = -5;
         Reservado.base_stats["opinion"] -= 35f;
         Reservado.base_stats["loyalty_traits"] = 2f;
////         Reservado.opposite = "Sociable";			
		 
		 
		 ActorTrait Resolutivo= new ActorTrait();
         Resolutivo.id = "Resolutivo";
         Resolutivo.path_icon = "ui/Icons/Resolutivo";
         Resolutivo.type = TraitType.Other;
         Resolutivo.group_id = TraitGroup.NaturalTraits;
         Resolutivo.can_be_given = true;
         Resolutivo.can_be_removed = true;
         Resolutivo.rate_birth = 1;
         Resolutivo.rate_inherit = 1;
         AssetManager.traits.add(Resolutivo);
         Resolutivo.base_stats["range"] = 0.40f;
         Resolutivo.base_stats["intelligence"] = 5;
         Resolutivo.base_stats["warfare"] = 3;
         Resolutivo.base_stats["diplomacy"] = 6;
         Resolutivo.base_stats["stewardship"] = 3;
         Resolutivo.base_stats["cities"] = 1;
         Resolutivo.base_stats["area_of_effect"] = 1;
////         Resolutivo.opposite = "Desastroso";			
		 
		 
		 ActorTrait Planificador= new ActorTrait();
         Planificador.id = "Planificador";
         Planificador.path_icon = "ui/Icons/Planificador";
         Planificador.type = TraitType.Other;
         Planificador.group_id = TraitGroup.NaturalTraits;
         Planificador.can_be_given = true;
         Planificador.can_be_removed = true;
         Planificador.rate_birth = 1;
         Planificador.rate_inherit = 1;
         AssetManager.traits.add(Planificador);
         Planificador.base_stats["speed"] = 4f;
         Planificador.base_stats["warfare"] += 17;
         Planificador.base_stats["diplomacy"] += 12;
         Planificador.base_stats["loyalty_traits"] = 1f;
////         Planificador.opposite = "Desastroso";			
		 
		 
		 ActorTrait Tolerante= new ActorTrait();
         Tolerante.id = "Tolerante";
         Tolerante.path_icon = "ui/Icons/Tolerante";
         Tolerante.type = TraitType.Other;
         Tolerante.group_id = TraitGroup.NaturalTraits;
         Tolerante.can_be_given = true;
         Tolerante.can_be_removed = true;
         Tolerante.rate_birth = 1;
         Tolerante.rate_inherit = 1;
         AssetManager.traits.add(Tolerante);
         Tolerante.base_stats["armor"] = 32;
         Tolerante.base_stats["warfare"] = 3;
         Tolerante.base_stats["diplomacy"] = 4;
         Tolerante.base_stats["stewardship"] = 5;
         Tolerante.base_stats["opinion"] = 6f;
         Tolerante.base_stats["loyalty_traits"] = 9f;
////         Tolerante.opposite = "Sensible,Cruel,Cínico,Acomplejado";			
		 
		 
		 ActorTrait Masoquista= new ActorTrait();
         Masoquista.id = "Masoquista";
         Masoquista.path_icon = "ui/Icons/Masoquista";
         Masoquista.type = TraitType.Other;
         Masoquista.group_id = TraitGroup.BadNaturalTraits;
         Masoquista.can_be_given = true;
         Masoquista.can_be_removed = true;
         Masoquista.rate_birth = 1;
         Masoquista.rate_inherit = 1;
         AssetManager.traits.add(Masoquista);
         Masoquista.base_stats["multiplier_offspring"] = -0.3f;
         Masoquista.base_stats["birth_rate"] = 1;
         Masoquista.base_stats["accuracy"] = -4f;
         Masoquista.base_stats["armor"] = 0.02f;
         Masoquista.base_stats["knockback"] = 0.3f;
         Masoquista.base_stats["warfare"] = 2;
         Masoquista.base_stats["diplomacy"] = -5;
         Masoquista.base_stats["opinion"] = -50f;
         Masoquista.base_stats["loyalty_traits"] = -5f;
////         Masoquista.opposite = "Compasivo,Reflexivo,Amable";			
		 
		 
		 ActorTrait Egoísta= new ActorTrait();
         Egoísta.id = "Egoísta";
         Egoísta.path_icon = "ui/Icons/Egoista";
         Egoísta.type = TraitType.Other;
         Egoísta.group_id = TraitGroup.BadNaturalTraits;
         Egoísta.can_be_given = true;
         Egoísta.can_be_removed = true;
         Egoísta.rate_birth = 1;
         Egoísta.rate_inherit = 1;
         AssetManager.traits.add(Egoísta);
         Egoísta.base_stats["range"] = 0.21145f;
         Egoísta.base_stats["warfare"] = 3;
         Egoísta.base_stats["diplomacy"] = -5;
         Egoísta.base_stats["stewardship"] = -5;
         Egoísta.base_stats["opinion"] = -7f;
         Egoísta.base_stats["loyalty_traits"] = -2f;
         Egoísta.base_stats["cities"] = 2;
         Egoísta.base_stats["area_of_effect"] = 1;
////         Egoísta.opposite = "Compasivo,Reflexivo,Amable,Altruista";			
		 
		 
		 ActorTrait Antipático= new ActorTrait();
         Antipático.id = "Antipático";
         Antipático.path_icon = "ui/Icons/Antipático";
         Antipático.type = TraitType.Other;
         Antipático.group_id = TraitGroup.BadNaturalTraits;
         Antipático.can_be_given = true;
         Antipático.can_be_removed = true;
         Antipático.rate_birth = 1;
         Antipático.rate_inherit = 1;
         AssetManager.traits.add(Antipático);
         Antipático.base_stats["multiplier_offspring"] = -0.5f;
         Antipático.base_stats["diplomacy"] = -1;
         Antipático.base_stats["stewardship"] = -10;
         Antipático.base_stats["opinion"] = -15f;
         Antipático.base_stats["loyalty_traits"] = -5f;
////         Antipático.opposite = "Compasivo,Reflexivo,Amable";			
		 
		 
		 ActorTrait Cauto= new ActorTrait();
         Cauto.id = "Cauto";
         Cauto.path_icon = "ui/Icons/Cauto";
         Cauto.type = TraitType.Other;
         Cauto.group_id = TraitGroup.NaturalTraits;
         Cauto.can_be_given = true;
         Cauto.can_be_removed = true;
         Cauto.rate_birth = 1;
         Cauto.rate_inherit = 1;
         AssetManager.traits.add(Cauto);
         Cauto.base_stats["speed"] = 3f;
         Cauto.base_stats["accuracy"] = 0.2f;
         Cauto.base_stats["range"] = 0.1f;
         Cauto.base_stats["targets"] = 0.4f;
         Cauto.base_stats["intelligence"] = 1;
         Cauto.base_stats["diplomacy"] = 5;
////         Cauto.opposite = "EnfermoMental";			
		 
		 
		 ActorTrait Perseverante= new ActorTrait();
         Perseverante.id = "Perseverante";
         Perseverante.path_icon = "ui/Icons/Perseverante";
         Perseverante.type = TraitType.Other;
         Perseverante.group_id = TraitGroup.NaturalTraits;
         Perseverante.can_be_given = true;
         Perseverante.can_be_removed = true;
         Perseverante.rate_birth = 1;
         Perseverante.rate_inherit = 1;
         AssetManager.traits.add(Perseverante);
         Perseverante.base_stats["multiplier_lifespan"] = 5f;
         Perseverante.base_stats["multiplier_damage"] += 0.45f;
         Perseverante.base_stats["multiplier_speed"] += 0.30f;
         Perseverante.base_stats["multiplier_damage"] += 0.30f;
         Perseverante.base_stats["critical_chance"] = 0.05f;
         Perseverante.base_stats["knockback"] = 0.05f;
//         Perseverante.base_stats["knockback_reduction"] = 0.05f;
         Perseverante.base_stats["warfare"] += 0.05f;
         Perseverante.base_stats["multiplier_diplomacy"] += 0.40f;
////         Perseverante.opposite = "Apatico,Decepcionante";			
		 
		 
		 ActorTrait Talentoso= new ActorTrait();
         Talentoso.id = "Talentoso";
         Talentoso.path_icon = "ui/Icons/Talentoso";
         Talentoso.type = TraitType.Other;
         Talentoso.group_id = TraitGroup.NaturalTraits;
         Talentoso.can_be_given = true;
         Talentoso.can_be_removed = true;
         Talentoso.rate_birth = 1;
         Talentoso.rate_inherit = 1;
         AssetManager.traits.add(Talentoso);
         Talentoso.base_stats["attack_speed"] = 15;
         Talentoso.base_stats["damage"] = 3f;
         Talentoso.base_stats["multiplier_speed"] += 0.40f;
         Talentoso.base_stats["health"] = 50;
         Talentoso.base_stats["range"] = 0.178777f;
         Talentoso.base_stats["critical_chance"] = 0.3f;
//         Talentoso.base_stats["knockback_reduction"] = 0.2f;
         Talentoso.base_stats["intelligence"] = 8;
         Talentoso.base_stats["warfare"] = 13;
         Talentoso.base_stats["diplomacy"] = 12;
         Talentoso.base_stats["stewardship"] = 12f;
         Talentoso.base_stats["opinion"] = 21f;
////         Talentoso.opposite = "Decepcionante";			
		 
		 
		 ActorTrait Atletico= new ActorTrait();
         Atletico.id = "Atletico";
         Atletico.path_icon = "ui/Icons/Atletico";
         Atletico.type = TraitType.Other;
         Atletico.group_id = TraitGroup.NaturalTraits;
         Atletico.can_be_given = true;
         Atletico.can_be_removed = true;
         Atletico.rate_birth = 1;
         Atletico.rate_inherit = 1;
         AssetManager.traits.add(Atletico);
         Atletico.base_stats["multiplier_attack_speed"] = 0.10f;
         Atletico.base_stats["multiplier_speed"] = 0.50f;
         Atletico.base_stats["skill_combat"] = 0.5f;
         Atletico.base_stats["critical_chance"] = 0.05f;
         Atletico.base_stats["knockback"] = 0.1f;
//         Atletico.base_stats["knockback_reduction"] = 0.2f;
////         Atletico.opposite = "Apatico,slow,Decepcionante";			
		 
		 
		 ActorTrait Idealista= new ActorTrait();
         Idealista.id = "Idealista";
         Idealista.path_icon = "ui/Icons/Idealista";
         Idealista.type = TraitType.Other;
         Idealista.group_id = TraitGroup.NaturalTraits;
         Idealista.can_be_given = true;
         Idealista.can_be_removed = true;
         Idealista.rate_birth = 1;
         Idealista.rate_inherit = 1;
         AssetManager.traits.add(Idealista);
         Idealista.base_stats["birth_rate"] = 1;
         Idealista.base_stats["accuracy"] = 0.1f;
         Idealista.base_stats["range"] = 0.1f;
         Idealista.base_stats["armor"] = -10;
         Idealista.base_stats["knockback"] = 0.01f;
//         Idealista.base_stats["knockback_reduction"] = -0.2f;
         Idealista.base_stats["intelligence"] = 5;
         Idealista.base_stats["warfare"] += 0.50f;
         Idealista.base_stats["diplomacy"] = 2;
         Idealista.base_stats["stewardship"] = 1;
         Idealista.base_stats["cities"] = 3;
         Idealista.base_stats["area_of_effect"] = 3;
////         Idealista.opposite = "EnfermoMental";			
		 
		 
		 ActorTrait Devoto= new ActorTrait();
         Devoto.id = "Devoto";
         Devoto.path_icon = "ui/Icons/Devoto";
         Devoto.type = TraitType.Other;
         Devoto.group_id = TraitGroup.NaturalTraits;
         Devoto.can_be_given = true;
         Devoto.can_be_removed = true;
         Devoto.rate_birth = 1;
         Devoto.rate_inherit = 1;
         AssetManager.traits.add(Devoto);
         Devoto.base_stats["multiplier_offspring"] = -0.20f;
         Devoto.base_stats["birth_rate"] = 1;
         Devoto.base_stats["multiplier_lifespan"] = 7f;
         Devoto.base_stats["targets"] = 0.2f;
         Devoto.base_stats["opinion"] = 10f;
         Devoto.base_stats["loyalty_traits"] = 25f;
////         Devoto.opposite = "Orgulloso,Impulsivo";			
		 
		 
		 ActorTrait Formido= new ActorTrait();
         Formido.id = "Formido";
         Formido.path_icon = "ui/Icons/Formido";
         Formido.type = TraitType.Other;
         Formido.group_id = TraitGroup.Physicalconditions;
         Formido.can_be_given = true;
         Formido.can_be_removed = true;
         Formido.rate_birth = 1;
         Formido.rate_inherit = 1;
         AssetManager.traits.add(Formido);
         Formido.base_stats["armor"] = 19;
//         Formido.base_stats["knockback_reduction"] = 0.4f;
////         Formido.opposite = "Delicado,weak,Cicatrizado";			
		 
		 
		 ActorTrait Simetrico= new ActorTrait();
         Simetrico.id = "Simetrico";
         Simetrico.path_icon = "ui/Icons/Simetrico";
         Simetrico.type = TraitType.Other;
         Simetrico.group_id = TraitGroup.Physicalconditions;
         Simetrico.can_be_given = true;
         Simetrico.can_be_removed = true;
         Simetrico.rate_birth = 1;
         Simetrico.rate_inherit = 1;
         AssetManager.traits.add(Simetrico);
         Simetrico.base_stats["multiplier_offspring"] = 0.2f;
         Simetrico.base_stats["birth_rate"] = 1;
         Simetrico.base_stats["multiplier_lifespan"] = 10f;
         Simetrico.base_stats["health"] = 5;
         Simetrico.base_stats["opinion"] = 10f;
////         Simetrico.opposite = "Asimetrico,Cicatrizado,one_eyed,skin_burns,fat";			
		 
		 
		 ActorTrait Asimetrico= new ActorTrait();
         Asimetrico.id = "Asimetrico";
         Asimetrico.path_icon = "ui/Icons/Asimetrico";
         Asimetrico.type = TraitType.Other;
         Asimetrico.group_id = TraitGroup.Physicalconditions;
         Asimetrico.can_be_given = true;
         Asimetrico.can_be_removed = true;
         Asimetrico.rate_birth = 1;
         Asimetrico.rate_inherit = 1;
         AssetManager.traits.add(Asimetrico);
         Asimetrico.base_stats["multiplier_offspring"] = -0.4f;
         Asimetrico.base_stats["birth_rate"] = 1;
         Asimetrico.base_stats["multiplier_lifespan"] = -10f;
////         Asimetrico.opposite = "Simetrico,attractive";			
		 
		 
		 ActorTrait Anorexico= new ActorTrait();
         Anorexico.id = "Anorexico";
         Anorexico.path_icon = "ui/Icons/Anorexico";
         Anorexico.type = TraitType.Other;
         Anorexico.group_id = TraitGroup.MentalDisorders;
         Anorexico.can_be_given = true;
         Anorexico.can_be_removed = true;
         Anorexico.rate_birth = 1;
         Anorexico.rate_inherit = 1;
         AssetManager.traits.add(Anorexico);
         Anorexico.base_stats["multiplier_offspring"] = -0.8f;
         Anorexico.base_stats["birth_rate"] = 1;
         Anorexico.base_stats["multiplier_lifespan"] = -20f;
         Anorexico.base_stats["accuracy"] = -0.6f;
         Anorexico.base_stats["scale"] = -0.010f;
         Anorexico.base_stats["intelligence"] = -10;
////         Anorexico.opposite = "fat,SuperGrande,giant,attractive,gluttonous";			
		 
		 
		 ActorTrait Patriótico= new ActorTrait();
         Patriótico.id = "Patriótico";
         Patriótico.path_icon = "ui/Icons/Patriótico";
         Patriótico.type = TraitType.Other;
         Patriótico.group_id = TraitGroup.NaturalTraits;
         Patriótico.can_be_given = true;
         Patriótico.can_be_removed = true;
         Patriótico.rate_birth = 1;
         Patriótico.rate_inherit = 1;
         AssetManager.traits.add(Patriótico);
         Patriótico.base_stats["diplomacy"] = -5;
         Patriótico.base_stats["stewardship"] += 0.10f;
         Patriótico.base_stats["loyalty_traits"] = 5000f;
////         Patriótico.opposite = "Traicionero,Antipatriotico,Desleal";			
		 
		 
		 ActorTrait Antipatriotico= new ActorTrait();
         Antipatriotico.id = "Antipatriotico";
         Antipatriotico.path_icon = "ui/Icons/Antipatriotico";
         Antipatriotico.type = TraitType.Other;
         Antipatriotico.group_id = TraitGroup.BadNaturalTraits;
         Antipatriotico.can_be_given = true;
         Antipatriotico.can_be_removed = true;
         Antipatriotico.rate_birth = 1;
         Antipatriotico.rate_inherit = 1;
         AssetManager.traits.add(Antipatriotico);
         Antipatriotico.base_stats["diplomacy"] = 5;
         Antipatriotico.base_stats["stewardship"] -= 0.10f;
         Antipatriotico.base_stats["loyalty_traits"] = -5000f;
////         Antipatriotico.opposite = "Patriótico,Leal";			
		 
		 
		 ActorTrait Opresor= new ActorTrait();
         Opresor.id = "Opresor";
         Opresor.path_icon = "ui/Icons/Opresor";
         Opresor.type = TraitType.Other;
         Opresor.group_id = TraitGroup.BadNaturalTraits;
         Opresor.can_be_given = true;
         Opresor.can_be_removed = true;
         Opresor.rate_birth = 1;
         Opresor.rate_inherit = 1;
         AssetManager.traits.add(Opresor);
         Opresor.base_stats["scale"] = -0.0f;
         Opresor.base_stats["targets"] = -0.05f;
         Opresor.base_stats["intelligence"] = 1;
         Opresor.base_stats["warfare"] += 0.21f;
         Opresor.base_stats["diplomacy"] = -2;
         Opresor.base_stats["cities"] = 1;
////         Opresor.opposite = "Flexible,Tranquilo,Empatico";			
		 
		 
		 ActorTrait Ambidiestro= new ActorTrait();
         Ambidiestro.id = "Ambidiestro";
         Ambidiestro.path_icon = "ui/Icons/Ambidiestro";
         Ambidiestro.type = TraitType.Other;
         Ambidiestro.group_id = TraitGroup.Physicalconditions;
         Ambidiestro.can_be_given = true;
         Ambidiestro.can_be_removed = true;
         Ambidiestro.rate_birth = 1;
         Ambidiestro.rate_inherit = 1;
         AssetManager.traits.add(Ambidiestro);
         Ambidiestro.base_stats["accuracy"] = 0.08f;
         Ambidiestro.base_stats["range"] = 0.005f;
         Ambidiestro.base_stats["targets"] = 0.05f;
         Ambidiestro.base_stats["critical_chance"] = 0.05f;
         Ambidiestro.base_stats["opinion"] = 5f;
////         Ambidiestro.opposite = "Zurdo";			
		 
		 
		 ActorTrait Zurdo= new ActorTrait();
         Zurdo.id = "Zurdo";
         Zurdo.path_icon = "ui/Icons/Zurdo";
         Zurdo.type = TraitType.Other;
         Zurdo.group_id = TraitGroup.Physicalconditions;
         Zurdo.can_be_given = true;
         Zurdo.can_be_removed = true;
         Zurdo.rate_birth = 1;
         Zurdo.rate_inherit = 1;
         AssetManager.traits.add(Zurdo);
         Zurdo.base_stats["attack_speed"] = -10;
         Zurdo.base_stats["speed"] = 0.2f;
         Zurdo.base_stats["targets"] = 0.01f;
         Zurdo.base_stats["opinion"] = -1f;
////         Zurdo.opposite = "Ambidiestro";			
		 
		 
		 ActorTrait Hipertrófico= new ActorTrait();
         Hipertrófico.id = "Hipertrófico";
         Hipertrófico.path_icon = "ui/Icons/Hipertrófico";
         Hipertrófico.type = TraitType.Other;
         Hipertrófico.group_id = TraitGroup.Physicalconditions;
         Hipertrófico.can_be_given = true;
         Hipertrófico.can_be_removed = true;
         Hipertrófico.rate_birth = 1;
         Hipertrófico.rate_inherit = 1;
         AssetManager.traits.add(Hipertrófico);
         Hipertrófico.base_stats["attack_speed"] = -10;
         Hipertrófico.base_stats["multiplier_damage"] = 1;
         Hipertrófico.base_stats["speed"] = -10f;
         Hipertrófico.base_stats["armor"] = 0.01f;
         Hipertrófico.base_stats["scale"] = 0.03f;
////         Hipertrófico.opposite = "tiny";			
		 
		 
		 ActorTrait Tetrachromático= new ActorTrait();
         Tetrachromático.id = "Tetrachromático";
         Tetrachromático.path_icon = "ui/Icons/Tetrachromático";
         Tetrachromático.type = TraitType.Other;
         Tetrachromático.group_id = TraitGroup.Physicalconditions;
         Tetrachromático.can_be_given = true;
         Tetrachromático.can_be_removed = true;
         Tetrachromático.rate_birth = 1;
         Tetrachromático.rate_inherit = 1;
         AssetManager.traits.add(Tetrachromático);
         Tetrachromático.base_stats["multiplier_lifespan"] = -5f;
         Tetrachromático.base_stats["accuracy"] = 0.05f;
         Tetrachromático.base_stats["range"] = 0.05f;
         Tetrachromático.base_stats["targets"] = 0.005f;
         Tetrachromático.base_stats["critical_chance"] = 0.012f;
////         Tetrachromático.opposite = "";			
		 
		 
		 ActorTrait Lucigénico= new ActorTrait();
         Lucigénico.id = "Lucigénico";
         Lucigénico.path_icon = "ui/Icons/Lucigénico";
         Lucigénico.type = TraitType.Other;
         Lucigénico.group_id = TraitGroup.Physicalconditions;
         Lucigénico.can_be_given = true;
         Lucigénico.can_be_removed = true;
         Lucigénico.era_active_night = true;
         Lucigénico.era_active_moon = true;
         Lucigénico.rate_birth = 1;
         Lucigénico.rate_inherit = 1;
////         Lucigénico.opposite = "Apatico";			
		 
		 
		 ActorTrait Sinestésico = new ActorTrait();
         Sinestésico.id = "Sinestésico";
         Sinestésico.path_icon = "ui/Icons/Sinestésico";
         Sinestésico.type = TraitType.Other;
         Sinestésico.group_id = TraitGroup.Physicalconditions;
         Sinestésico.can_be_given = true;
         Sinestésico.can_be_removed = true;
         Sinestésico.rate_birth = 1;
         Sinestésico.rate_inherit = 1;
         AssetManager.traits.add(Sinestésico);
         Sinestésico.base_stats["birth_rate"] = 1;
         Sinestésico.base_stats["accuracy"] = -0.4f;
         Sinestésico.base_stats["range"] = -0.42f;
////         Sinestésico.opposite = "Apatico,EnfermoMental,Sordo";			
		 
		 
		 ActorTrait Sordo= new ActorTrait();
         Sordo.id = "Sordo";
         Sordo.path_icon = "ui/Icons/Sordo";
         Sordo.type = TraitType.Other;
         Sordo.group_id = TraitGroup.BadNaturalTraits;
         Sordo.can_be_given = true;
         Sordo.can_be_removed = true;
         Sordo.rate_birth = 1;
         Sordo.rate_inherit = 1;
         AssetManager.traits.add(Sordo);
         Sordo.base_stats["multiplier_speed"] = 0.25f;
//         Sordo.base_stats["knockback_reduction"] = -0.05f;
         Sordo.base_stats["warfare"] = -10;
         Sordo.base_stats["diplomacy"] = -7;
         Sordo.base_stats["stewardship"] = -13f;
         Sordo.base_stats["opinion"] = -52f;
////         Sordo.opposite = "Atento,Sinestésico,Perceptivo,Discreto";			
		 
		 
		 ActorTrait Dispraxico = new ActorTrait();
         Dispraxico.id = "Dispraxico";
         Dispraxico.path_icon = "ui/Icons/Dispraxico";
         Dispraxico.type = TraitType.Other;
         Dispraxico.group_id = TraitGroup.MentalDisorders;
         Dispraxico.can_be_given = true;
         Dispraxico.can_be_removed = true;
         Dispraxico.rate_birth = 1;
         Dispraxico.rate_inherit = 1;
         AssetManager.traits.add(Dispraxico);
         Dispraxico.base_stats["multiplier_lifespan"] = -1f;
         Dispraxico.base_stats["multiplier_attack_speed"] = -0.50f;
         Dispraxico.base_stats["damage"] = -3;
         Dispraxico.base_stats["multiplier_speed"] = -0.3f;
         Dispraxico.base_stats["multiplier_damage"] = -0.20f;
         Dispraxico.base_stats["skill_combat"] = -0.20f;
         Dispraxico.base_stats["critical_chance"] = -0.1f;
////         Dispraxico.opposite = "agil,SuperAgil,fast,SuperRapido";			
		 
		 ActorTrait Bulimico = new ActorTrait();
         Bulimico.id = "Bulimico";
         Bulimico.path_icon = "ui/Icons/Bulimico";
         Bulimico.type = TraitType.Other;
         Bulimico.group_id = TraitGroup.MentalDisorders;
         Bulimico.can_be_given = true;
         Bulimico.can_be_removed = true;
         Bulimico.rate_birth = 1;
         Bulimico.rate_inherit = 1;
         AssetManager.traits.add(Bulimico);
         Bulimico.base_stats["multiplier_offspring"] = -1.0f;
         Bulimico.base_stats["multiplier_attack_speed"] = -0.34f;
         Bulimico.base_stats["speed"] = -20f;
         Bulimico.base_stats["health"] = -5;
         Bulimico.base_stats["accuracy"] = -0.05f;
         Bulimico.base_stats["range"] = -0.1f;
////         Bulimico.opposite = "fast,SuperAgil,Prodigio,";			
		 
		 		 
		 ActorTrait Narcolepsico= new ActorTrait();
         Narcolepsico.id = "Narcolepsico";
         Narcolepsico.path_icon = "ui/Icons/Narcolepsico";
         Narcolepsico.type = TraitType.Other;
         Narcolepsico.group_id = TraitGroup.MentalDisorders;
         Narcolepsico.can_be_given = true;
         Narcolepsico.can_be_removed = true;
         Narcolepsico.rate_birth = 1;
         Narcolepsico.rate_inherit = 1;
         AssetManager.traits.add(Narcolepsico);
         Narcolepsico.base_stats["multiplier_offspring"] = -0.5f;
         Narcolepsico.base_stats["attack_speed"] = -10;
         Narcolepsico.base_stats["damage"] = -10f;
         Narcolepsico.base_stats["multiplier_speed"] = -0.5f;
         Narcolepsico.base_stats["intelligence"] = -11f;
////         Narcolepsico.opposite = "genius,SuperInteligente,Soñador";			
		 
		 		 
		 ActorTrait Insomne= new ActorTrait();
         Insomne.id = "Insomne";
         Insomne.path_icon = "ui/Icons/Insomne";
         Insomne.type = TraitType.Other;
         Insomne.group_id = TraitGroup.MentalDisorders;
         Insomne.can_be_given = true;
         Insomne.can_be_removed = true;
         Insomne.rate_birth = 1;
         Insomne.rate_inherit = 1;
         AssetManager.traits.add(Insomne);
         Insomne.base_stats["multiplier_offspring"] = -1.0f;
         Insomne.base_stats["birth_rate"] = 1;
         Insomne.base_stats["multiplier_lifespan"] = -60f;
         Insomne.base_stats["damage"] = -20;
         Insomne.base_stats["speed"] = -35f;
         Insomne.base_stats["intelligence"] = -5;
////         Insomne.opposite = "Soñador";			
		 
		 		 
		 ActorTrait Psicotico= new ActorTrait();
         Psicotico.id = "Psicotico";
         Psicotico.path_icon = "ui/Icons/Psicotico";
         Psicotico.type = TraitType.Other;
         Psicotico.group_id = TraitGroup.MentalDisorders;
         Psicotico.can_be_given = true;
         Psicotico.can_be_removed = true;
         Psicotico.rate_birth = 1;
         Psicotico.rate_inherit = 1;
         AssetManager.traits.add(Psicotico);
         Psicotico.base_stats["multiplier_offspring"] = -0.8f;
         Psicotico.base_stats["birth_rate"] = 1;
         Psicotico.base_stats["multiplier_lifespan"] = -20f;
         Psicotico.base_stats["attack_speed"] = -5;
         Psicotico.base_stats["damage"] = -7.3f;
         Psicotico.base_stats["multiplier_speed"] = -0.6f;
         Psicotico.base_stats["health"] = -5;
         Psicotico.base_stats["accuracy"] = -0.2f;
         Psicotico.base_stats["range"] = -0.3f;
         Psicotico.base_stats["critical_chance"] = -0.62f;
         Psicotico.base_stats["area_of_effect"] = -4;
////         Psicotico.opposite = "genius,SuperInteligente,Conciente";			
		 
		 		 
		 ActorTrait Afasico= new ActorTrait();
         Afasico.id = "Afasico";
         Afasico.path_icon = "ui/Icons/Afasico";
         Afasico.type = TraitType.Other;
         Afasico.group_id = TraitGroup.MentalDisorders;
         Afasico.can_be_given = true;
         Afasico.can_be_removed = true;
         Afasico.rate_birth = 1;
         Afasico.rate_inherit = 1;
         AssetManager.traits.add(Afasico);
         Afasico.base_stats["damage"] = -1;
         Afasico.base_stats["multiplier_speed"] = -0.2f;
         Afasico.base_stats["health"] = -5;
         Afasico.base_stats["knockback"] = -0.1f;
//         Afasico.base_stats["knockback_reduction"] = -0.42f;
         Afasico.base_stats["warfare"] = -2;
         Afasico.base_stats["opinion"] = -24.7f;
////         Afasico.opposite = "Sociable,Carismatico";			
		 
		 		 
		 ActorTrait Bizco= new ActorTrait();
         Bizco.id = "Bizco";
         Bizco.path_icon = "ui/Icons/Bizco";
         Bizco.type = TraitType.Other;
         Bizco.group_id = TraitGroup.Physicalconditions;
         Bizco.can_be_given = true;
         Bizco.can_be_removed = true;
         Bizco.rate_birth = 1;
         Bizco.rate_inherit = 1;
         AssetManager.traits.add(Bizco);
         Bizco.base_stats["accuracy"] = -0.05f;
         Bizco.base_stats["armor"] = -20f;
         Bizco.base_stats["opinion"] = -25f;
////         Bizco.opposite = "Simetrico,Heterócromatico";			
		 
		 		 
		 ActorTrait Heterócromatico= new ActorTrait();
         Heterócromatico.id = "Heterócromatico";
         Heterócromatico.path_icon = "ui/Icons/Heterócromatico";
         Heterócromatico.type = TraitType.Other;
         Heterócromatico.group_id = TraitGroup.Physicalconditions;
         Heterócromatico.can_be_given = true;
         Heterócromatico.can_be_removed = true;
         Heterócromatico.rate_birth = 1;
         Heterócromatico.rate_inherit = 1;
         AssetManager.traits.add(Heterócromatico);
         Heterócromatico.base_stats["multiplier_offspring"] = 0.04f;
         Heterócromatico.base_stats["birth_rate"] = 1;
         Heterócromatico.base_stats["opinion"] = 10f;
////         Heterócromatico.opposite = "Bizco";			
		 
		 		 
		 ActorTrait Celoso= new ActorTrait();
         Celoso.id = "Celoso";
         Celoso.path_icon = "ui/Icons/Celoso";
         Celoso.type = TraitType.Other;
         Celoso.group_id = TraitGroup.BadNaturalTraits;
         Celoso.can_be_given = true;
         Celoso.can_be_removed = true;
         Celoso.rate_birth = 1;
         Celoso.rate_inherit = 1;
         AssetManager.traits.add(Celoso);
         Celoso.base_stats["birth_rate"] = 1;
         Celoso.base_stats["opinion"] = -5f;
         Celoso.base_stats["loyalty_traits"] = -18f;
////         Celoso.opposite = "";			
		 
		 		 
		 ActorTrait Insensible= new ActorTrait();
         Insensible.id = "Insensible";
         Insensible.path_icon = "ui/Icons/Insensible";
         Insensible.type = TraitType.Other;
         Insensible.group_id = TraitGroup.BadNaturalTraits;
         Insensible.can_be_given = true;
         Insensible.can_be_removed = true;
         Insensible.rate_birth = 1;
         Insensible.rate_inherit = 1;
         AssetManager.traits.add(Insensible);
         Insensible.base_stats["multiplier_offspring"] = -0.2f;
         Insensible.base_stats["diplomacy"] = -10;
         Insensible.base_stats["opinion"] = -9f;
         Insensible.base_stats["loyalty_traits"] = -6f;
////         Insensible.opposite = "Sensible";			
		 
		 		 
		 ActorTrait Sexista= new ActorTrait();
         Sexista.id = "Sexista";
         Sexista.path_icon = "ui/Icons/Sexista";
         Sexista.type = TraitType.Other;
         Sexista.group_id = TraitGroup.BadNaturalTraits;
         Sexista.can_be_given = true;
         Sexista.can_be_removed = true;
         Sexista.rate_birth = 1;
         Sexista.rate_inherit = 1;
         AssetManager.traits.add(Sexista);
         Sexista.base_stats["multiplier_offspring"] = -0.45f;
         Sexista.base_stats["opinion"] = -10f;
         Sexista.base_stats["loyalty_traits"] = -1f;
////         Sexista.opposite = "Justo";			
		 
		 		 
		 ActorTrait Taciturno= new ActorTrait();
         Taciturno.id = "Taciturno";
         Taciturno.path_icon = "ui/Icons/Taciturno";
         Taciturno.type = TraitType.Other;
         Taciturno.group_id = TraitGroup.BadNaturalTraits;
         Taciturno.can_be_given = true;
         Taciturno.can_be_removed = true;
         Taciturno.rate_birth = 1;
         Taciturno.rate_inherit = 1;
         AssetManager.traits.add(Taciturno);
         Taciturno.base_stats["targets"] = -0.02f;
         Taciturno.base_stats["diplomacy"] = -6.7f;
         Taciturno.base_stats["stewardship"] = -7f;
         Taciturno.base_stats["area_of_effect"] = -3;
////         Taciturno.opposite = "Sociable,Extrovertido";			
		 
		 		 
		 ActorTrait Juzgador= new ActorTrait();
         Juzgador.id = "Juzgador";
         Juzgador.path_icon = "ui/Icons/Juzgador";
         Juzgador.type = TraitType.Other;
         Juzgador.group_id = TraitGroup.BadNaturalTraits;
         Juzgador.can_be_given = true;
         Juzgador.can_be_removed = true;
         Juzgador.rate_birth = 1;
         Juzgador.rate_inherit = 1;
         AssetManager.traits.add(Juzgador);
         Juzgador.base_stats["diplomacy"] = -20f;
         Juzgador.base_stats["opinion"] = -41.5f;
////         Juzgador.opposite = "Justo,Autocontrolado";			
		 
		 		 
		 ActorTrait Impaciente= new ActorTrait();
         Impaciente.id = "Impaciente";
         Impaciente.path_icon = "ui/Icons/Impaciente";
         Impaciente.type = TraitType.Other;
         Impaciente.group_id = TraitGroup.BadNaturalTraits;
         Impaciente.can_be_given = true;
         Impaciente.can_be_removed = true;
         Impaciente.rate_birth = 1;
         Impaciente.rate_inherit = 1;
         AssetManager.traits.add(Impaciente);
         Impaciente.base_stats["damage"] = 1.42f;
         Impaciente.base_stats["multiplier_speed"] = 0.32f;
         Impaciente.base_stats["stewardship"] = -3f;
         Impaciente.base_stats["opinion"] = -4f;
////         Impaciente.opposite = "Paciente";			
		 
		 		 
		 ActorTrait Impuntual= new ActorTrait();
         Impuntual.id = "Impuntual";
         Impuntual.path_icon = "ui/Icons/Impuntual";
         Impuntual.type = TraitType.Other;
         Impuntual.group_id = TraitGroup.BadNaturalTraits;
         Impuntual.can_be_given = true;
         Impuntual.can_be_removed = true;
         Impuntual.rate_birth = 1;
         Impuntual.rate_inherit = 1;
         AssetManager.traits.add(Impuntual);
         Impuntual.base_stats["multiplier_speed"] = -0.27f;
         Impuntual.base_stats["opinion"] = -3f;
         Impuntual.base_stats["loyalty_traits"] = -4f;
////         Impuntual.opposite = "Puntual";			
		 
		 		 
		 ActorTrait Cobarde= new ActorTrait();
         Cobarde.id = "Cobarde";
         Cobarde.path_icon = "ui/Icons/Cobarde";
         Cobarde.type = TraitType.Other;
         Cobarde.group_id = TraitGroup.BadNaturalTraits;
         Cobarde.can_be_given = true;
         Cobarde.can_be_removed = true;
         Cobarde.rate_birth = 1;
         Cobarde.rate_inherit = 1;
         AssetManager.traits.add(Cobarde);
         Cobarde.base_stats["multiplier_speed"] = -0.78f;
         Cobarde.base_stats["critical_chance"] = -0.05f;
         Cobarde.base_stats["opinion"] = -10f;
         Cobarde.base_stats["loyalty_traits"] = -2f;
////         Cobarde.opposite = "";			
		 
		 		 
		 ActorTrait Conflictivo= new ActorTrait();
         Conflictivo.id = "Conflictivo";
         Conflictivo.path_icon = "ui/Icons/Conflictivo";
         Conflictivo.type = TraitType.Other;
         Conflictivo.group_id = TraitGroup.BadNaturalTraits;
         Conflictivo.can_be_given = true;
         Conflictivo.can_be_removed = true;
         Conflictivo.rate_birth = 1;
         Conflictivo.rate_inherit = 1;
         AssetManager.traits.add(Conflictivo);
         Conflictivo.base_stats["accuracy"] = -0.04f;
         Conflictivo.base_stats["warfare"] = 2;
         Conflictivo.base_stats["diplomacy"] = -21;
         Conflictivo.base_stats["stewardship"] = 5f;
         Conflictivo.base_stats["opinion"] = -27.5f;
         Conflictivo.base_stats["loyalty_traits"] = -5f;
////         Conflictivo.opposite = "Neutral";			
		 
		 		 
		 ActorTrait Renegon= new ActorTrait();
         Renegon.id = "Renegon";
         Renegon.path_icon = "ui/Icons/Renegon";
         Renegon.type = TraitType.Other;
         Renegon.group_id = TraitGroup.BadNaturalTraits;
         Renegon.can_be_given = true;
         Renegon.can_be_removed = true;
         Renegon.rate_birth = 1;
         Renegon.rate_inherit = 1;
         AssetManager.traits.add(Renegon);
         Renegon.base_stats["attack_speed"] = 5;
         Renegon.base_stats["multiplier_damage"] = 0.2f;
         Renegon.base_stats["multiplier_speed"] = 0.05f;
         Renegon.base_stats["accuracy"] = 0.03f;
         Renegon.base_stats["warfare"] = 5;
         Renegon.base_stats["diplomacy"] = -10;
         Renegon.base_stats["stewardship"] = -12f;
         Renegon.base_stats["opinion"] = -1f;
////         Renegon.opposite = "Autocontrolado,Tranquilo,Sencillo";			
		 
		 		 
		 ActorTrait Infiel= new ActorTrait();
         Infiel.id = "Infiel";
         Infiel.path_icon = "ui/Icons/Infiel";
         Infiel.type = TraitType.Other;
         Infiel.group_id = TraitGroup.BadNaturalTraits;
         Infiel.can_be_given = true;
         Infiel.can_be_removed = true;
         Infiel.rate_birth = 1;
         Infiel.rate_inherit = 1;
         AssetManager.traits.add(Infiel);
         Infiel.base_stats["multiplier_offspring"] = 0.04f;
         Infiel.base_stats["birth_rate"] = 1;
         Infiel.base_stats["diplomacy"] = -14;
         Infiel.base_stats["opinion"] = -21f;
         Infiel.base_stats["loyalty_traits"] = -6f;
         Infiel.base_stats["cities"] = -1;
////         Infiel.opposite = "Leal";			
		 
		 		 
		 ActorTrait Galante= new ActorTrait();
         Galante.id = "Galante";
         Galante.path_icon = "ui/Icons/Galante";
         Galante.type = TraitType.Other;
         Galante.group_id = TraitGroup.NaturalTraits;
         Galante.can_be_given = true;
         Galante.can_be_removed = true;
         Galante.rate_birth = 1;
         Galante.rate_inherit = 1;
         AssetManager.traits.add(Galante);
         Galante.base_stats["multiplier_offspring"] = 0.10f;
         Galante.base_stats["birth_rate"] = 1;
         Galante.base_stats["accuracy"] = 0.04f;
         Galante.base_stats["targets"] = 0.01f;
         Galante.base_stats["diplomacy"] = 4;
         Galante.base_stats["stewardship"] = 3f;
         Galante.base_stats["opinion"] = 16f;
         Galante.base_stats["loyalty_traits"] = 7f;
////         Galante.opposite = "";			
		 
		 
		 ActorTrait SuperPreciso= new ActorTrait();
         SuperPreciso.id = "SuperPreciso";
         SuperPreciso.path_icon = "ui/Icons/Super Preciso";
         SuperPreciso.type = TraitType.Other;
         SuperPreciso.group_id = TraitGroup.LegendaryTraits;
         SuperPreciso.can_be_given = true;
         SuperPreciso.can_be_removed = true;
         SuperPreciso.rate_birth = 1;
         SuperPreciso.rate_inherit = 1;
         AssetManager.traits.add(SuperPreciso);
         SuperPreciso.base_stats["accuracy"] = 100f;
         SuperPreciso.base_stats["range"] = 0.8f;
         SuperPreciso.base_stats["targets"] = 0.9f;
         SuperPreciso.base_stats["critical_chance"] = 1.0f;
         SuperPreciso.base_stats["knockback"] = 10f;
////         SuperPreciso.opposite = "stupid,Autista,Esquizofrenico";			
		 

        }
    }
}
