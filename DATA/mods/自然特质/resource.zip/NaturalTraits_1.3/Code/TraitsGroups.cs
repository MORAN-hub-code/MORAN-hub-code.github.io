using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReflectionUtility;
 
namespace NaturalTraits
{
    public static class TraitGroup
    {
 
        public static string NaturalTraits = "NaturalTraits";
        public static string LegendaryTraits = "LegendaryTraits";
		public static string MentalDisorders = "MentalDisorders";
		public static string Physicalconditions = "Physicalconditions";
		public static string BadNaturalTraits = "BadNaturalTraits";
 
        public static void init()
        {
         
            var NaturalTraits = new ActorTraitGroupAsset
			{
             id = "NaturalTraits",
             name = "trait_group_NaturalTraits",
             color = "#9EFFFF"
			};
             AssetManager.trait_groups.add(NaturalTraits);

var BadNaturalTraits = new ActorTraitGroupAsset
{
    id = "BadNaturalTraits",
    name = "trait_group_BadNaturalTraits",
    color = "#490000"
};
AssetManager.trait_groups.add(BadNaturalTraits);

var LegendaryTraits = new ActorTraitGroupAsset
{
    id = "LegendaryTraits",
    name = "trait_group_LegendaryTraits",
    color = "#FFF74B"
};
AssetManager.trait_groups.add(LegendaryTraits);

var MentalDisorders = new ActorTraitGroupAsset
{
    id = "MentalDisorders",
    name = "trait_group_MentalDisorders",
    color = "#DD7AFF"
};
AssetManager.trait_groups.add(MentalDisorders);

var Physicalconditions = new ActorTraitGroupAsset
{
    id = "Physicalconditions",
    name = "trait_group_Physicalconditions",
    color = "#66FF70"
};
AssetManager.trait_groups.add(Physicalconditions);
           
           
        }
    }
}
