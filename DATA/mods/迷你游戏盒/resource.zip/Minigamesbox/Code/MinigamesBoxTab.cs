using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using NeoModLoader.General.UI.Tab;
using UnityEngine.Audio;
using Newtonsoft.Json;

namespace MinigamesBox
{
    public static class MinigamesBoxTab
    {
        private static PowersTab tab;
        public static GameObject minigamesUI;
        private static GameObject difficultyUI;
        private static bool isUIActive;
        private static bool isDifficultyUIActive;
        public static GameObject activeGame;
        private static AudioSource musicSource;
        private static GameObject mainMenuUI;
        private static GameObject shopUI;
        private static GameObject settingsUI;
        private static int coins;
        private static string coinsDataPath;
        private static List<string> ownedDogers = new List<string> { "dogerskin1" };
        private static string selectedDoger = "dogerskin1";
        private static GameObject dogerSkinsGrid;
        private static List<string> allDogers = new List<string> { "dogerskin1", "dogerskin2", "dogerskin3", "player3" };
        private static float selectedDifficultySpawnRate = 1.5f;
        private static float selectedDifficultySpeed = 3f;
        private static string shieldKey = "S";
        private static string shootKey = "D";
        private static string ticTacToeScorePath;
        private static string snakeScorePath;
        private static string meteorScorePath;
        private static TicTacToeScoreData ticTacToeScoreData;
        private static SnakeScoreData snakeScoreData;
        private static MeteorScoreData meteorScoreData;

        private class MeteorScoreData
        {
            public int highScore = 0;
        }

        private class SnakeScoreData
        {
            public int highScore = 0;
        }

        private class TicTacToeScoreData
        {
            public int playerWins = 0;
            public int cpuWins = 0;
        }

        public static void Init()
        {
            string scoresDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "minigames", "scores");
            Directory.CreateDirectory(scoresDir);
            coinsDataPath = Path.Combine(scoresDir, "minigamesbox_coins.json");
            ticTacToeScorePath = Path.Combine(scoresDir, "scoretictactoe.json");
            snakeScorePath = Path.Combine(scoresDir, "snakescore.json");
            meteorScorePath = Path.Combine(scoresDir, "meteorscore.json");
            LoadCoins();
            LoadTicTacToeScore();
            LoadSnakeScore();
            LoadMeteorScore();

            Sprite tabIcon = SpriteTextureLoader.getSprite("ui/Icons/tabIconMinigamesBox");
            if (tabIcon == null)
            {
                Texture2D defaultTexture = new Texture2D(2, 2);
                defaultTexture.SetPixel(0, 0, Color.white);
                defaultTexture.Apply();
                tabIcon = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }

            Localization.AddOrSet("Button_Tab_MinigamesBox", "MinigamesBox");
            Localization.AddOrSet("Button_Tab_MinigamesBox Description", "Play Minigames...");
            Localization.AddOrSet("minigamesbox_mod_creator", "ahoyos");
            Localization.AddOrSet("snake_game", "Snake Game");
            Localization.AddOrSet("snake_game_description", "Play the Snake minigame");
            Localization.AddOrSet("meteor_dodge", "Meteor Dodge");
            Localization.AddOrSet("meteor_dodge_description", "Play the Meteor Dodge minigame");
            Localization.AddOrSet("tic_tac_toe", "Tic-Tac-Toe");
            Localization.AddOrSet("tic_tac_toe_description", "Play Tic-Tac-Toe");

            tab = TabManager.CreateTab("MinigamesBox", "Button_Tab_MinigamesBox", "Button_Tab_MinigamesBox Description", tabIcon, "minigamesbox_mod_creator");
            if (tab == null) return;

            CreateMinigamesUI();
            CreateDifficultyUI();
            CreateMainMenuUI();
            CreateShopUI();
            CreateSettingsUI();
            LoadButtons();
            AddLogo();
            AddSectionLabel();

            Sprite discordSprite = SpriteTextureLoader.getSprite("ui/Icons/iconDiscord");
            PowerButtons.CreateButton(
                "OpenDiscord",
                discordSprite,
                "Discord",
                "Join the Isekai mod Discord server PLEASEEEE",
                new Vector2(506f, -18f),
                ButtonType.Click,
                tab.transform,
                () => Application.OpenURL("https://discord.gg/Yq4jUzuExM")
            );

            if (UnityEngine.Object.FindObjectOfType<EventSystem>() == null)
            {
                GameObject eventSystem = new GameObject("EventSystem");
                eventSystem.AddComponent<EventSystem>();
                eventSystem.AddComponent<StandaloneInputModule>();
            }

            GameObject madeByObject = new GameObject("MadeBy");
            madeByObject.transform.SetParent(minigamesUI.transform, false);
            Text madeByText = madeByObject.AddComponent<Text>();
            madeByText.text = "Made by: ahoyos";
            madeByText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            madeByText.fontSize = 12;
            madeByText.color = Color.white;
            madeByText.alignment = TextAnchor.LowerCenter;
            madeByText.rectTransform.sizeDelta = new Vector2(200f, 20f);
            madeByText.rectTransform.anchorMin = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchoredPosition = new Vector2(0f, 10f);
        }

        private static void LoadCoins()
        {
            try
            {
                if (File.Exists(coinsDataPath))
                {
                    var data = JsonConvert.DeserializeObject<CoinsData>(File.ReadAllText(coinsDataPath));
                    coins = data.coins;
                    ownedDogers = data.ownedDogers ?? new List<string> { "dogerskin1" };
                    selectedDoger = string.IsNullOrEmpty(data.selectedDoger) ? "dogerskin1" : data.selectedDoger;
                    PlayerPrefs.SetString("Selected_DogerSkin", selectedDoger);
                }
                else
                {
                    coins = 0;
                    ownedDogers = new List<string> { "dogerskin1" };
                    selectedDoger = "dogerskin1";
                    PlayerPrefs.SetString("Selected_DogerSkin", "dogerskin1");
                    SaveCoins();
                }
            }
            catch
            {
                coins = 0;
                ownedDogers = new List<string> { "dogerskin1" };
                selectedDoger = "dogerskin1";
                PlayerPrefs.SetString("Selected_DogerSkin", "dogerskin1");
            }
        }

        private static void SaveCoins()
        {
            var data = new CoinsData { coins = coins, ownedDogers = ownedDogers, selectedDoger = selectedDoger };
            File.WriteAllText(coinsDataPath, JsonConvert.SerializeObject(data, Formatting.Indented));
            PlayerPrefs.SetString("Selected_DogerSkin", selectedDoger);
        }

        private static void LoadTicTacToeScore()
        {
            if (File.Exists(ticTacToeScorePath))
            {
                ticTacToeScoreData = JsonConvert.DeserializeObject<TicTacToeScoreData>(File.ReadAllText(ticTacToeScorePath));
            }
            else
            {
                ticTacToeScoreData = new TicTacToeScoreData { playerWins = 0, cpuWins = 0 };
                SaveTicTacToeScore();
            }
        }

        private static void SaveTicTacToeScore()
        {
            File.WriteAllText(ticTacToeScorePath, JsonConvert.SerializeObject(ticTacToeScoreData, Formatting.Indented));
        }

        private static void LoadSnakeScore()
        {
            if (File.Exists(snakeScorePath))
            {
                snakeScoreData = JsonConvert.DeserializeObject<SnakeScoreData>(File.ReadAllText(snakeScorePath));
            }
            else
            {
                snakeScoreData = new SnakeScoreData { highScore = 0 };
                SaveSnakeScore();
            }
        }

        private static void SaveSnakeScore()
        {
            File.WriteAllText(snakeScorePath, JsonConvert.SerializeObject(snakeScoreData, Formatting.Indented));
        }

        private static void LoadMeteorScore()
        {
            if (File.Exists(meteorScorePath))
            {
                meteorScoreData = JsonConvert.DeserializeObject<MeteorScoreData>(File.ReadAllText(meteorScorePath));
            }
            else
            {
                meteorScoreData = new MeteorScoreData { highScore = 0 };
                SaveMeteorScore();
            }
        }

        private static void SaveMeteorScore()
        {
            File.WriteAllText(meteorScorePath, JsonConvert.SerializeObject(meteorScoreData, Formatting.Indented));
        }

        private static void CreateMinigamesUI()
        {
            minigamesUI = new GameObject("MinigamesUI");
            Canvas canvas = minigamesUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1000;
            minigamesUI.AddComponent<CanvasScaler>();
            minigamesUI.AddComponent<GraphicRaycaster>();
            minigamesUI.SetActive(false);

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(minigamesUI.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            backgroundImage.type = Image.Type.Sliced;
            backgroundImage.color = Color.black;
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.offsetMin = Vector2.zero;
            backgroundImage.rectTransform.offsetMax = Vector2.zero;

            var minigames = new List<(string spritePath, string name, Action action)>
            {
                ("ui/minigames/snake.png", "Snake Game", StartSnakeGame),
                ("ui/minigames/meteor_dodge.png", "Meteor Dodge", ShowMainMenu),
                ("ui/minigames/tic-tac-toe.png", "Tic-Tac-Toe", StartTicTacToe)
            };

            float spacing = 300f;
            float startX = 0.3f;
            float startY = 0.75f;
            for (int i = 0; i < minigames.Count; i++)
            {
                var game = minigames[i];
                Sprite gameSprite = SpriteTextureLoader.getSprite(game.spritePath);
                if (gameSprite == null)
                {
                    Texture2D defaultTexture = new Texture2D(2, 2);
                    defaultTexture.SetPixel(0, 0, Color.white);
                    defaultTexture.Apply();
                    gameSprite = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }

                GameObject gameObject = new GameObject($"Game_{game.name}");
                gameObject.transform.SetParent(minigamesUI.transform, false);
                Image gameImage = gameObject.AddComponent<Image>();
                gameImage.sprite = gameSprite;
                gameImage.rectTransform.sizeDelta = new Vector2(200f, 150f);
                float x = startX + (i % 2) * spacing / Screen.width;
                float y = startY - (i / 2) * spacing / Screen.height;
                gameImage.rectTransform.anchorMin = new Vector2(x, y);
                gameImage.rectTransform.anchorMax = new Vector2(x, y);
                gameImage.rectTransform.anchoredPosition = Vector2.zero;

                Button gameButton = gameObject.AddComponent<Button>();
                gameButton.onClick.AddListener(() => game.action?.Invoke());

                GameObject labelObject = new GameObject($"Label_{game.name}");
                labelObject.transform.SetParent(gameObject.transform, false);
                Text labelText = labelObject.AddComponent<Text>();
                labelText.text = game.name;
                labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                labelText.fontSize = 14;
                labelText.color = Color.white;
                labelText.alignment = TextAnchor.UpperCenter;
                labelText.rectTransform.sizeDelta = new Vector2(200f, 20f);
                labelText.rectTransform.anchoredPosition = new Vector2(0, -80f);
            }

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(minigamesUI.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            Sprite exitSprite = SpriteTextureLoader.getSprite("ui/exit.png");
            if (exitSprite == null)
            {
                exitButtonImage.color = new Color(1f, 0f, 0f, 0.7f);
            }
            else
            {
                exitButtonImage.sprite = exitSprite;
            }
            exitButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(0f, -10f);

            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(HideMinigamesUI);
        }

        private static void CreateDifficultyUI()
        {
            difficultyUI = new GameObject("DifficultyUI");
            Canvas canvas = difficultyUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1001;
            difficultyUI.AddComponent<CanvasScaler>();
            difficultyUI.AddComponent<GraphicRaycaster>();
            difficultyUI.SetActive(false);

            GameObject panelObject = new GameObject("Panel");
            panelObject.transform.SetParent(difficultyUI.transform, false);
            Image panelImage = panelObject.AddComponent<Image>();
            panelImage.color = new Color(0.1f, 0.1f, 0.1f, 0.9f);
            panelImage.rectTransform.sizeDelta = new Vector2(400f, 360f);
            panelImage.rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            panelImage.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            panelImage.rectTransform.anchoredPosition = Vector2.zero;

            var difficulties = new List<(string name, float spawnRate, float speed)>
            {
                ("Easy", 1.5f, 3f),
                ("Medium", 1f, 5f),
                ("Hard", 0.5f, 7f),
                ("Extreme", 0.3f, 10f)
            };

            float startY = 100f;
            float spacing = 60f;
            for (int i = 0; i < difficulties.Count; i++)
            {
                var difficulty = difficulties[i];
                GameObject buttonObject = new GameObject($"Difficulty_{difficulty.name}");
                buttonObject.transform.SetParent(panelObject.transform, false);
                Image buttonImage = buttonObject.AddComponent<Image>();
                buttonImage.color = new Color(0.2f, 0.2f, 0.2f, 1f);
                buttonImage.rectTransform.sizeDelta = new Vector2(200f, 50f);
                buttonImage.rectTransform.anchoredPosition = new Vector2(0, startY - i * spacing);

                Button button = buttonObject.AddComponent<Button>();
                float spawnRate = difficulty.spawnRate;
                float speed = difficulty.speed;
                button.onClick.AddListener(() => {
                    selectedDifficultySpawnRate = spawnRate;
                    selectedDifficultySpeed = speed;
                    HideDifficultyUI();
                    StartMeteorDodge(selectedDifficultySpawnRate, selectedDifficultySpeed);
                });

                GameObject labelObject = new GameObject($"Label_{difficulty.name}");
                labelObject.transform.SetParent(buttonObject.transform, false);
                Text labelText = labelObject.AddComponent<Text>();
                labelText.text = difficulty.name;
                labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                labelText.fontSize = 20;
                labelText.color = Color.white;
                labelText.alignment = TextAnchor.MiddleCenter;
                labelText.rectTransform.sizeDelta = new Vector2(200f, 50f);
                labelText.rectTransform.anchoredPosition = Vector2.zero;
            }

            GameObject madeByObject = new GameObject("MadeBy");
            madeByObject.transform.SetParent(difficultyUI.transform, false);
            Text madeByText = madeByObject.AddComponent<Text>();
            madeByText.text = "Made by: ahoyos";
            madeByText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            madeByText.fontSize = 12;
            madeByText.color = Color.white;
            madeByText.alignment = TextAnchor.LowerCenter;
            madeByText.rectTransform.sizeDelta = new Vector2(200f, 20f);
            madeByText.rectTransform.anchorMin = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchoredPosition = new Vector2(0f, 10f);
        }

        private static void CreateMainMenuUI()
        {
            mainMenuUI = new GameObject("MainMenuUI");
            Canvas canvas = mainMenuUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1002;
            mainMenuUI.AddComponent<CanvasScaler>();
            mainMenuUI.AddComponent<GraphicRaycaster>();
            mainMenuUI.SetActive(false);

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(mainMenuUI.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            Sprite backgroundSprite = SpriteTextureLoader.getSprite("ui/minigames/mainmenu.png");
            if (backgroundSprite == null)
            {
                backgroundImage.color = Color.black;
            }
            else
            {
                backgroundImage.sprite = backgroundSprite;
            }
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = Vector2.zero;

            float buttonWidth = 200f;
            float buttonHeight = 50f;
            float startY = 0.7f;
            float spacing = 0.1f;

            GameObject playButtonObject = new GameObject("PlayButton");
            playButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image playButtonImage = playButtonObject.AddComponent<Image>();
            playButtonImage.color = new Color(0.2f, 0.6f, 0.2f, 1f);
            playButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            playButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY);
            playButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY);
            playButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button playButton = playButtonObject.AddComponent<Button>();
            playButton.onClick.AddListener(() => {
                HideMainMenuUI();
                StartMeteorDodge(selectedDifficultySpawnRate, selectedDifficultySpeed);
            });

            GameObject playLabelObject = new GameObject("Label_Play");
            playLabelObject.transform.SetParent(playButtonObject.transform, false);
            Text playLabelText = playLabelObject.AddComponent<Text>();
            playLabelText.text = "Play";
            playLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            playLabelText.fontSize = 20;
            playLabelText.color = Color.white;
            playLabelText.alignment = TextAnchor.MiddleCenter;
            playLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            playLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject difficultyButtonObject = new GameObject("DifficultyButton");
            difficultyButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image difficultyButtonImage = difficultyButtonObject.AddComponent<Image>();
            difficultyButtonImage.color = new Color(0.6f, 0.4f, 0.2f, 1f);
            difficultyButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            difficultyButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY - spacing);
            difficultyButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY - spacing);
            difficultyButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button difficultyButton = difficultyButtonObject.AddComponent<Button>();
            difficultyButton.onClick.AddListener(() => {
                HideMainMenuUI();
                ShowDifficultyUI();
            });

            GameObject difficultyLabelObject = new GameObject("Label_Difficulty");
            difficultyLabelObject.transform.SetParent(difficultyButtonObject.transform, false);
            Text difficultyLabelText = difficultyLabelObject.AddComponent<Text>();
            difficultyLabelText.text = "Difficulty";
            difficultyLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            difficultyLabelText.fontSize = 20;
            difficultyLabelText.color = Color.white;
            difficultyLabelText.alignment = TextAnchor.MiddleCenter;
            difficultyLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            difficultyLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject creditsButtonObject = new GameObject("CreditsButton");
            creditsButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image creditsButtonImage = creditsButtonObject.AddComponent<Image>();
            creditsButtonImage.color = new Color(0.2f, 0.2f, 0.6f, 1f);
            creditsButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            creditsButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY - 2 * spacing);
            creditsButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY - 2 * spacing);
            creditsButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button creditsButton = creditsButtonObject.AddComponent<Button>();
            creditsButton.onClick.AddListener(ShowCredits);

            GameObject creditsLabelObject = new GameObject("Label_Credits");
            creditsLabelObject.transform.SetParent(creditsButtonObject.transform, false);
            Text creditsLabelText = creditsLabelObject.AddComponent<Text>();
            creditsLabelText.text = "Credits";
            creditsLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            creditsLabelText.fontSize = 20;
            creditsLabelText.color = Color.white;
            creditsLabelText.alignment = TextAnchor.MiddleCenter;
            creditsLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            creditsLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject shopButtonObject = new GameObject("ShopButton");
            shopButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image shopButtonImage = shopButtonObject.AddComponent<Image>();
            shopButtonImage.color = new Color(0.6f, 0.2f, 0.2f, 1f);
            shopButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shopButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY - 3 * spacing);
            shopButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY - 3 * spacing);
            shopButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button shopButton = shopButtonObject.AddComponent<Button>();
            shopButton.onClick.AddListener(ShowShopUI);

            GameObject shopLabelObject = new GameObject("Label_Shop");
            shopLabelObject.transform.SetParent(shopButtonObject.transform, false);
            Text shopLabelText = shopLabelObject.AddComponent<Text>();
            shopLabelText.text = "Shop";
            shopLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            shopLabelText.fontSize = 20;
            shopLabelText.color = Color.white;
            shopLabelText.alignment = TextAnchor.MiddleCenter;
            shopLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shopLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject settingsButtonObject = new GameObject("SettingsButton");
            settingsButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image settingsButtonImage = settingsButtonObject.AddComponent<Image>();
            settingsButtonImage.color = new Color(0.4f, 0.4f, 0.4f, 1f);
            settingsButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            settingsButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY - 4 * spacing);
            settingsButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY - 4 * spacing);
            settingsButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button settingsButton = settingsButtonObject.AddComponent<Button>();
            settingsButton.onClick.AddListener(ShowSettingsUI);

            GameObject settingsLabelObject = new GameObject("Label_Settings");
            settingsLabelObject.transform.SetParent(settingsButtonObject.transform, false);
            Text settingsLabelText = settingsLabelObject.AddComponent<Text>();
            settingsLabelText.text = "Settings";
            settingsLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            settingsLabelText.fontSize = 20;
            settingsLabelText.color = Color.white;
            settingsLabelText.alignment = TextAnchor.MiddleCenter;
            settingsLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            settingsLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject backButtonObject = new GameObject("BackButton");
            backButtonObject.transform.SetParent(mainMenuUI.transform, false);
            Image backButtonImage = backButtonObject.AddComponent<Image>();
            backButtonImage.color = new Color(0.7f, 0.7f, 0.7f, 1f);
            backButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backButtonImage.rectTransform.anchorMin = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchorMax = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchoredPosition = new Vector2(10f, -10f);

            Button backButton = backButtonObject.AddComponent<Button>();
            backButton.onClick.AddListener(() => {
                HideMainMenuUI();
                ShowMinigamesUI();
            });

            GameObject backLabelObject = new GameObject("Label_Back");
            backLabelObject.transform.SetParent(backButtonObject.transform, false);
            Text backLabelText = backLabelObject.AddComponent<Text>();
            backLabelText.text = "Back";
            backLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            backLabelText.fontSize = 16;
            backLabelText.color = Color.black;
            backLabelText.alignment = TextAnchor.MiddleCenter;
            backLabelText.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backLabelText.rectTransform.anchoredPosition = Vector2.zero;
        }

        private static void CreateShopUI()
        {
            shopUI = new GameObject("ShopUI");
            Canvas canvas = shopUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1003;
            shopUI.AddComponent<CanvasScaler>();
            shopUI.AddComponent<GraphicRaycaster>();
            shopUI.SetActive(false);

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(shopUI.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            backgroundImage.color = new Color(0.1f, 0.1f, 0.1f, 0.9f);
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = Vector2.zero;

            float buttonWidth = 200f;
            float buttonHeight = 50f;
            float startY = 0.7f;
            float spacing = 0.1f;

            GameObject shieldButtonObject = new GameObject("ShieldButton");
            shieldButtonObject.transform.SetParent(shopUI.transform, false);
            Image shieldButtonImage = shieldButtonObject.AddComponent<Image>();
            Sprite shieldSprite = SpriteTextureLoader.getSprite("ui/sprites/sheild.png");
            shieldButtonImage.sprite = shieldSprite;
            shieldButtonImage.color = shieldSprite == null ? new Color(0.0f, 0.8f, 1f, 1f) : Color.white;
            shieldButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shieldButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY);
            shieldButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY);
            shieldButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button shieldButton = shieldButtonObject.AddComponent<Button>();
            shieldButton.onClick.AddListener(() => PurchaseAbility("Shield", 100));

            GameObject shieldLabelObject = new GameObject("Label_Shield");
            shieldLabelObject.transform.SetParent(shieldButtonObject.transform, false);
            Text shieldLabelText = shieldLabelObject.AddComponent<Text>();
            shieldLabelText.text = "Buy Shield (100 Coins)";
            shieldLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            shieldLabelText.fontSize = 20;
            shieldLabelText.color = Color.white;
            shieldLabelText.alignment = TextAnchor.MiddleCenter;
            shieldLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shieldLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject shootButtonObject = new GameObject("ShootButton");
            shootButtonObject.transform.SetParent(shopUI.transform, false);
            Image shootButtonImage = shootButtonObject.AddComponent<Image>();
            Sprite shootSprite = SpriteTextureLoader.getSprite("ui/sprites/shoot.png");
            shootButtonImage.sprite = shootSprite;
            shootButtonImage.color = shootSprite == null ? new Color(1f, 0.5f, 0.0f, 1f) : Color.white;
            shootButtonImage.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shootButtonImage.rectTransform.anchorMin = new Vector2(0.5f, startY - spacing);
            shootButtonImage.rectTransform.anchorMax = new Vector2(0.5f, startY - spacing);
            shootButtonImage.rectTransform.anchoredPosition = Vector2.zero;

            Button shootButton = shootButtonObject.AddComponent<Button>();
            shootButton.onClick.AddListener(() => PurchaseAbility("Shoot", 150));

            GameObject shootLabelObject = new GameObject("Label_Shoot");
            shootLabelObject.transform.SetParent(shootButtonObject.transform, false);
            Text shootLabelText = shootLabelObject.AddComponent<Text>();
            shootLabelText.text = "Buy Shoot (150 Coins)";
            shootLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            shootLabelText.fontSize = 20;
            shootLabelText.color = Color.white;
            shootLabelText.alignment = TextAnchor.MiddleCenter;
            shootLabelText.rectTransform.sizeDelta = new Vector2(buttonWidth, buttonHeight);
            shootLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject dogerLabel = new GameObject("Label_Doger");
            dogerLabel.transform.SetParent(shopUI.transform, false);
            Text dogerLabelText = dogerLabel.AddComponent<Text>();
            dogerLabelText.text = "Doger Skins";
            dogerLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            dogerLabelText.fontSize = 20;
            dogerLabelText.color = Color.yellow;
            dogerLabelText.alignment = TextAnchor.MiddleCenter;
            dogerLabelText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            dogerLabelText.rectTransform.anchorMin = new Vector2(0.5f, startY - 2 * spacing);
            dogerLabelText.rectTransform.anchorMax = new Vector2(0.5f, startY - 2 * spacing);
            dogerLabelText.rectTransform.anchoredPosition = new Vector2(0, -60f);

            dogerSkinsGrid = new GameObject("DogerSkinsGrid");
            dogerSkinsGrid.transform.SetParent(shopUI.transform, false);
            GridLayoutGroup grid = dogerSkinsGrid.AddComponent<GridLayoutGroup>();
            grid.cellSize = new Vector2(70f, 70f);
            grid.spacing = new Vector2(10f, 10f);
            grid.constraint = GridLayoutGroup.Constraint.FixedRowCount;
            grid.constraintCount = 1;
            RectTransform gridRect = dogerSkinsGrid.GetComponent<RectTransform>();
            gridRect.sizeDelta = new Vector2(240f, 80f);
            gridRect.anchorMin = new Vector2(0.5f, 0.5f);
            gridRect.anchorMax = new Vector2(0.5f, 0.5f);
            gridRect.anchoredPosition = new Vector2(0f, -100f);

            ReloadDogerSkins();

            GameObject backButtonObject = new GameObject("BackButton");
            backButtonObject.transform.SetParent(shopUI.transform, false);
            Image backButtonImage = backButtonObject.AddComponent<Image>();
            backButtonImage.color = new Color(0.7f, 0.7f, 0.7f, 1f);
            backButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backButtonImage.rectTransform.anchorMin = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchorMax = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchoredPosition = new Vector2(10f, -10f);

            Button backButton = backButtonObject.AddComponent<Button>();
            backButton.onClick.AddListener(HideShopUI);

            GameObject backLabelObject = new GameObject("Label_Back");
            backLabelObject.transform.SetParent(backButtonObject.transform, false);
            Text backLabelText = backLabelObject.AddComponent<Text>();
            backLabelText.text = "Back";
            backLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            backLabelText.fontSize = 16;
            backLabelText.color = Color.black;
            backLabelText.alignment = TextAnchor.MiddleCenter;
            backLabelText.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backLabelText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject coinCountObject = new GameObject("CoinCount");
            coinCountObject.transform.SetParent(shopUI.transform, false);
            Text coinCountText = coinCountObject.AddComponent<Text>();
            coinCountText.text = $"Coins: {coins}";
            coinCountText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            coinCountText.fontSize = 20;
            coinCountText.color = Color.yellow;
            coinCountText.alignment = TextAnchor.UpperRight;
            coinCountText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            coinCountText.rectTransform.anchorMin = new Vector2(1f, 1f);
            coinCountText.rectTransform.anchorMax = new Vector2(1f, 1f);
            coinCountText.rectTransform.anchoredPosition = new Vector2(-10f, -10f);
        }

        private static void ReloadDogerSkins()
        {
            foreach (Transform child in dogerSkinsGrid.transform)
            {
                UnityEngine.Object.Destroy(child.gameObject);
            }
            foreach (var doger in allDogers)
            {
                GameObject dogerBtnObj = new GameObject($"DogerBtn_{doger}");
                dogerBtnObj.transform.SetParent(dogerSkinsGrid.transform, false);
                Image dogerImage = dogerBtnObj.AddComponent<Image>();
                Sprite spr = SpriteTextureLoader.getSprite($"minigames/{doger}.png");
                if (spr == null)
                {
                    spr = SpriteTextureLoader.getSprite($"ui/minigames/{doger}.png");
                }
                if (spr == null)
                {
                    spr = SpriteTextureLoader.getSprite($"player/{doger}.png");
                }
                if (spr == null)
                {
                    Texture2D t = new Texture2D(2, 2);
                    t.SetPixel(0, 0, Color.magenta);
                    t.Apply();
                    spr = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }
                dogerImage.sprite = spr;
                dogerImage.rectTransform.sizeDelta = new Vector2(70f, 70f);

                Button btn = dogerBtnObj.AddComponent<Button>();
                string d = doger;
                if (ownedDogers.Contains(d))
                {
                    btn.onClick.AddListener(() =>
                    {
                        selectedDoger = d;
                        PlayerPrefs.SetString("Selected_DogerSkin", d);
                        SaveCoins();
                        ReloadDogerSkins();
                    });
                    if (selectedDoger == d)
                        dogerImage.color = Color.green;
                    else
                        dogerImage.color = Color.white;
                }
                else
                {
                    btn.onClick.AddListener(() =>
                    {
                        PurchaseSkin(d, d == "dogerskin1" ? 0 : 250);
                    });
                    dogerImage.color = Color.gray;
                }
            }
        }

        private static void PurchaseSkin(string doger, int cost)
        {
            if (coins >= cost && !ownedDogers.Contains(doger))
            {
                coins -= cost;
                ownedDogers.Add(doger);
                selectedDoger = doger;
                PlayerPrefs.SetString("Selected_DogerSkin", doger);
                SaveCoins();
                ReloadDogerSkins();
                UpdateShopCoinDisplay();
            }
        }

        private static void UpdateShopCoinDisplay()
        {
            var coinCount = shopUI.transform.Find("CoinCount");
            if (coinCount != null)
            {
                coinCount.GetComponent<Text>().text = $"Coins: {coins}";
            }
        }

        private static void CreateSettingsUI()
        {
            if (settingsUI != null)
            {
                UnityEngine.Object.Destroy(settingsUI);
            }
            settingsUI = new GameObject("SettingsUI");
            Canvas canvas = settingsUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1004;
            settingsUI.AddComponent<CanvasScaler>();
            settingsUI.AddComponent<GraphicRaycaster>();
            settingsUI.SetActive(false);

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(settingsUI.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            backgroundImage.color = new Color(0.1f, 0.1f, 0.1f, 0.9f);
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = Vector2.zero;

            AddKeyPicker(settingsUI.transform, "Shield", shieldKey, new Vector2(80f, 130f), "ui/sprites/sheild.png");
            AddKeyPicker(settingsUI.transform, "Shoot", shootKey, new Vector2(80f, 70f), "ui/sprites/shoot.png");

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(settingsUI.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            exitButtonImage.color = new Color(0.7f, 0.7f, 0.7f, 1f);
            exitButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(0f, -10f);

            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(() => {
                SaveSettings();
                HideSettingsUI();
            });

            GameObject exitLabelObject = new GameObject("Label_Exit");
            exitLabelObject.transform.SetParent(exitButtonObject.transform, false);
            Text exitLabelText = exitLabelObject.AddComponent<Text>();
            exitLabelText.text = "Exit";
            exitLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            exitLabelText.fontSize = 16;
            exitLabelText.color = Color.black;
            exitLabelText.alignment = TextAnchor.MiddleCenter;
            exitLabelText.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitLabelText.rectTransform.anchoredPosition = Vector2.zero;
        }

        private static void AddKeyPicker(Transform parent, string ability, string key, Vector2 position, string spritePath)
        {
            GameObject keyPicker = new GameObject($"{ability}KeyPicker");
            keyPicker.transform.SetParent(parent, false);
            Image icon = keyPicker.AddComponent<Image>();
            Sprite iconSprite = SpriteTextureLoader.getSprite(spritePath);
            icon.sprite = iconSprite;
            icon.rectTransform.sizeDelta = new Vector2(64f, 64f);
            icon.rectTransform.anchoredPosition = position;

            GameObject keyInputObject = new GameObject($"{ability}KeyInput");
            keyInputObject.transform.SetParent(keyPicker.transform, false);
            RectTransform inputRect = keyInputObject.AddComponent<RectTransform>();
            inputRect.sizeDelta = new Vector2(40f, 40f);
            inputRect.anchoredPosition = new Vector2(80f, 0f);

            InputField keyInput = keyInputObject.AddComponent<InputField>();
            keyInput.text = key;
            keyInput.characterLimit = 1;
            keyInput.contentType = InputField.ContentType.Alphanumeric;
            keyInput.lineType = InputField.LineType.SingleLine;
            keyInput.keyboardType = TouchScreenKeyboardType.Default;
            keyInput.onValueChanged.AddListener((value) =>
            {
                if (value.Length > 1)
                {
                    value = value.Substring(0, 1);
                    keyInput.text = value;
                }
            });
            keyInput.onEndEdit.AddListener((value) =>
            {
                if (ability == "Shield") shieldKey = value;
                if (ability == "Shoot") shootKey = value;
            });

            GameObject labelObj = new GameObject($"{ability}Label");
            labelObj.transform.SetParent(keyPicker.transform, false);
            Text label = labelObj.AddComponent<Text>();
            label.text = $"{ability} Key";
            label.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            label.fontSize = 16;
            label.color = Color.white;
            label.alignment = TextAnchor.MiddleLeft;
            label.rectTransform.sizeDelta = new Vector2(120f, 40f);
            label.rectTransform.anchoredPosition = new Vector2(140f, 0f);
        }

        private static void SaveSettings()
        {
            PlayerPrefs.SetString("Key_Shield", shieldKey);
            PlayerPrefs.SetString("Key_Shoot", shootKey);
            PlayerPrefs.Save();
        }

        private static void LoadButtons()
        {
            Sprite minigamesSprite = SpriteTextureLoader.getSprite("ui/Icons/iconMinigamesUI");
            if (minigamesSprite == null)
            {
                Texture2D defaultTexture = new Texture2D(2, 2);
                defaultTexture.SetPixel(0, 0, Color.white);
                defaultTexture.Apply();
                minigamesSprite = Sprite.Create(defaultTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }

            PowerButtons.CreateButton("MinigamesUI", minigamesSprite, "Minigames UI", "Play minigames", new Vector2(108f, 48f), ButtonType.Click, tab.transform, ShowMinigamesUI);
        }

        private static void AddLogo()
        {
            Sprite logoSprite = SpriteTextureLoader.getSprite("ui/Icons/iconMinigamesBoxLogo");
            if (logoSprite == null) return;

            GameObject logoObject = new GameObject("MinigamesBoxLogo");
            logoObject.transform.SetParent(tab.transform, false);
            Image logoImage = logoObject.AddComponent<Image>();
            logoImage.sprite = logoSprite;
            logoImage.rectTransform.sizeDelta = new Vector2(81f, 91f);
            logoImage.rectTransform.anchoredPosition = new Vector2(760f, 0f);

            logoObject.AddComponent<LogoSpinner>();

            EventTrigger trigger = logoObject.AddComponent<EventTrigger>();
            EventTrigger.Entry pointerEnter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
            pointerEnter.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = true; });
            trigger.triggers.Add(pointerEnter);

            EventTrigger.Entry pointerExit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            pointerExit.callback.AddListener((data) => { logoObject.GetComponent<LogoSpinner>().isSpinning = false; });
            trigger.triggers.Add(pointerExit);
        }

        private static void AddSectionLabel()
        {
            GameObject labelObject = new GameObject("MinigamesBoxLabel");
            labelObject.transform.SetParent(tab.transform, false);
            Text labelText = labelObject.AddComponent<Text>();
            labelText.text = "Mini Fun! 🎮";
            labelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            labelText.fontSize = 16;
            labelText.color = Color.white;
            labelText.alignment = TextAnchor.MiddleLeft;
            labelText.rectTransform.sizeDelta = new Vector2(100f, 20f);
            labelText.rectTransform.anchoredPosition = new Vector2(72f, 54f);
        }

        public static void ShowMinigamesUI()
        {
            if (!isUIActive)
            {
                minigamesUI.SetActive(true);
                isUIActive = true;
                PlayBackgroundMusic();
            }
        }

        private static void PlayBackgroundMusic()
        {
            if (musicSource != null && musicSource.isPlaying) return;
            if (musicSource != null)
            {
                UnityEngine.Object.Destroy(musicSource.gameObject);
            }
            GameObject musicObject = new GameObject("BackgroundMusic");
            musicSource = musicObject.AddComponent<AudioSource>();
            AudioClip musicClip = Resources.Load<AudioClip>("sounds/music/gamemusic");
            if (musicClip == null)
            {
                WWW www = new WWW("file://" + Path.Combine(Application.streamingAssetsPath, "sounds/music/gamemusic.mp3"));
                musicSource.clip = www.GetAudioClip(false, true, AudioType.MPEG);
                musicSource.loop = true;
                musicSource.volume = 0.5f;
                musicSource.Play();
            }
            else
            {
                musicSource.clip = musicClip;
                musicSource.loop = true;
                musicSource.volume = 0.5f;
                musicSource.Play();
            }
        }

        private static void StopBackgroundMusic()
        {
            if (musicSource != null)
            {
                musicSource.Stop();
                UnityEngine.Object.Destroy(musicSource.gameObject);
                musicSource = null;
            }
        }

        public static void HideMinigamesUI()
        {
            if (isUIActive)
            {
                minigamesUI.SetActive(false);
                isUIActive = false;
                StopBackgroundMusic();
                if (activeGame != null)
                {
                    UnityEngine.Object.Destroy(activeGame);
                    activeGame = null;
                }
            }
        }

        private static void ShowDifficultyUI()
        {
            if (!isDifficultyUIActive)
            {
                if (activeGame != null)
                {
                    UnityEngine.Object.Destroy(activeGame);
                    activeGame = null;
                }
                difficultyUI.SetActive(true);
                isDifficultyUIActive = true;
            }
        }

        private static void HideDifficultyUI()
        {
            if (isDifficultyUIActive)
            {
                difficultyUI.SetActive(false);
                isDifficultyUIActive = false;
            }
        }

        private static void ShowMainMenu()
        {
            if (!mainMenuUI.activeSelf)
            {
                mainMenuUI.SetActive(true);
                minigamesUI.SetActive(false);
                isUIActive = false;
            }
        }

        private static void HideMainMenuUI()
        {
            if (mainMenuUI.activeSelf)
            {
                mainMenuUI.SetActive(false);
            }
        }

        private static void ShowShopUI()
        {
            if (!shopUI.activeSelf)
            {
                shopUI.SetActive(true);
                HideMainMenuUI();
                UpdateShopCoinDisplay();
                ReloadDogerSkins();
            }
        }

        private static void HideShopUI()
        {
            if (shopUI.activeSelf)
            {
                shopUI.SetActive(false);
                ShowMainMenu();
            }
        }

        private static void ShowSettingsUI()
        {
            if (!settingsUI.activeSelf)
            {
                settingsUI.SetActive(true);
                HideMainMenuUI();
            }
        }

        private static void HideSettingsUI()
        {
            if (settingsUI.activeSelf)
            {
                settingsUI.SetActive(false);
                ShowMainMenu();
            }
        }

        private static void ShowCredits()
        {
            GameObject creditsUI = new GameObject("CreditsUI");
            Canvas canvas = creditsUI.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1005;
            creditsUI.AddComponent<CanvasScaler>();
            creditsUI.AddComponent<GraphicRaycaster>();

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(creditsUI.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            backgroundImage.color = new Color(0.1f, 0.1f, 0.1f, 0.9f);
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = Vector2.zero;

            GameObject creditsTextObject = new GameObject("CreditsText");
            creditsTextObject.transform.SetParent(creditsUI.transform, false);
            Text creditsText = creditsTextObject.AddComponent<Text>();
            creditsText.text = "Developed by: ahoyos\nSpecial thanks to the community!";
            creditsText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            creditsText.fontSize = 20;
            creditsText.color = Color.white;
            creditsText.alignment = TextAnchor.MiddleCenter;
            creditsText.rectTransform.sizeDelta = new Vector2(400f, 200f);
            creditsText.rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            creditsText.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            creditsText.rectTransform.anchoredPosition = Vector2.zero;

            GameObject backButtonObject = new GameObject("BackButton");
            backButtonObject.transform.SetParent(creditsUI.transform, false);
            Image backButtonImage = backButtonObject.AddComponent<Image>();
            backButtonImage.color = new Color(0.7f, 0.7f, 0.7f, 1f);
            backButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backButtonImage.rectTransform.anchorMin = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchorMax = new Vector2(0f, 1f);
            backButtonImage.rectTransform.anchoredPosition = new Vector2(10f, -10f);

            Button backButton = backButtonObject.AddComponent<Button>();
            backButton.onClick.AddListener(() => { UnityEngine.Object.Destroy(creditsUI); ShowMainMenu(); });

            GameObject backLabelObject = new GameObject("Label_Back");
            backLabelObject.transform.SetParent(backButtonObject.transform, false);
            Text backLabelText = backLabelObject.AddComponent<Text>();
            backLabelText.text = "Back";
            backLabelText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            backLabelText.fontSize = 16;
            backLabelText.color = Color.black;
            backLabelText.alignment = TextAnchor.MiddleCenter;
            backLabelText.rectTransform.sizeDelta = new Vector2(80f, 40f);
            backLabelText.rectTransform.anchoredPosition = Vector2.zero;
        }

        private static void PurchaseAbility(string ability, int cost)
        {
            if (coins >= cost)
            {
                coins -= cost;
                SaveCoins();
                UpdateShopCoinDisplay();
                if (ability == "Shoot")
                    PlayerPrefs.SetInt("Ability_Shoot_Unlocked", 1);
                if (ability == "Shield")
                    PlayerPrefs.SetInt("Ability_Shield_Unlocked", 1);
            }
        }

        private static void UpdateKeyBinding(string ability, string key)
        {
            PlayerPrefs.SetString($"Key_{ability}", key);
        }

        private static void StartSnakeGame()
        {
            if (activeGame != null)
            {
                UnityEngine.Object.Destroy(activeGame);
                activeGame = null;
            }

            GameObject snakeGameObject = new GameObject("SnakeGame");
            snakeGameObject.transform.SetParent(minigamesUI.transform, false);
            Canvas snakeCanvas = snakeGameObject.AddComponent<Canvas>();
            snakeCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            snakeCanvas.sortingOrder = 1001;
            snakeGameObject.AddComponent<CanvasScaler>();
            snakeGameObject.AddComponent<GraphicRaycaster>();

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(snakeGameObject.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            Sprite backgroundSprite = SpriteTextureLoader.getSprite("ui/minigames/snakebackground.png");
            if (backgroundSprite == null)
            {
                backgroundImage.color = Color.black;
            }
            else
            {
                backgroundImage.sprite = backgroundSprite;
                backgroundImage.type = Image.Type.Sliced;
            }
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = new Vector2(Screen.width, Screen.height);

            GameObject gameAreaObject = new GameObject("GameArea");
            gameAreaObject.transform.SetParent(snakeGameObject.transform, false);
            Image gameAreaImage = gameAreaObject.AddComponent<Image>();
            gameAreaImage.color = new Color(0.1f, 0.1f, 0.1f, 0.5f);
            gameAreaImage.rectTransform.sizeDelta = new Vector2(800f, 600f);
            gameAreaImage.rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            gameAreaImage.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            gameAreaImage.rectTransform.anchoredPosition = Vector2.zero;

            GameObject scoreObject = new GameObject("Score");
            scoreObject.transform.SetParent(snakeGameObject.transform, false);
            Text scoreText = scoreObject.AddComponent<Text>();
            scoreText.text = "Score: 0";
            scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            scoreText.fontSize = 20;
            scoreText.color = Color.white;
            scoreText.alignment = TextAnchor.UpperLeft;
            scoreText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            scoreText.rectTransform.anchorMin = new Vector2(0f, 1f);
            scoreText.rectTransform.anchorMax = new Vector2(0f, 1f);
            scoreText.rectTransform.anchoredPosition = new Vector2(10f, -10f);

            GameObject highScoreObject = new GameObject("HighScore");
            highScoreObject.transform.SetParent(snakeGameObject.transform, false);
            Text highScoreText = highScoreObject.AddComponent<Text>();
            highScoreText.text = $"High Score: {snakeScoreData.highScore}";
            highScoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            highScoreText.fontSize = 20;
            highScoreText.color = Color.yellow;
            highScoreText.alignment = TextAnchor.UpperLeft;
            highScoreText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            highScoreText.rectTransform.anchorMin = new Vector2(0f, 1f);
            highScoreText.rectTransform.anchorMax = new Vector2(0f, 1f);
            highScoreText.rectTransform.anchoredPosition = new Vector2(10f, -50f);

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(snakeGameObject.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            Sprite exitSprite = SpriteTextureLoader.getSprite("ui/exit.png");
            if (exitSprite == null)
            {
                exitButtonImage.color = new Color(1f, 0f, 0f, 0.7f);
            }
            else
            {
                exitButtonImage.sprite = exitSprite;
            }
            exitButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(0f, -10f);

            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(HideMinigamesUI);

            activeGame = snakeGameObject;
            var logic = snakeGameObject.AddComponent<SnakeGameLogic>();
            logic.Setup(scoreObject, highScoreObject, snakeScorePath);

            GameObject madeByObject = new GameObject("MadeBy");
            madeByObject.transform.SetParent(snakeGameObject.transform, false);
            Text madeByText = madeByObject.AddComponent<Text>();
            madeByText.text = "Made by: ahoyos";
            madeByText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            madeByText.fontSize = 12;
            madeByText.color = Color.white;
            madeByText.alignment = TextAnchor.LowerCenter;
            madeByText.rectTransform.sizeDelta = new Vector2(200f, 20f);
            madeByText.rectTransform.anchorMin = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchoredPosition = new Vector2(0f, 10f);
        }

        private static void StartMeteorDodge(float spawnRate, float speed)
        {
            if (activeGame != null)
            {
                UnityEngine.Object.Destroy(activeGame);
                activeGame = null;
            }
            GameObject meteorGameObject = new GameObject("MeteorDodge");
            meteorGameObject.transform.SetParent(minigamesUI.transform, false);
            Canvas meteorCanvas = meteorGameObject.AddComponent<Canvas>();
            meteorCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            meteorCanvas.sortingOrder = 1001;
            meteorGameObject.AddComponent<CanvasScaler>();
            meteorGameObject.AddComponent<GraphicRaycaster>();

            GameObject backgroundObject = new GameObject("Background");
            backgroundObject.transform.SetParent(meteorGameObject.transform, false);
            Image backgroundImage = backgroundObject.AddComponent<Image>();
            Sprite backgroundSprite = SpriteTextureLoader.getSprite("ui/minigames/space.png");
            if (backgroundSprite == null)
            {
                backgroundImage.color = Color.black;
            }
            else
            {
                backgroundImage.sprite = backgroundSprite;
                backgroundImage.type = Image.Type.Sliced;
            }
            backgroundImage.rectTransform.anchorMin = Vector2.zero;
            backgroundImage.rectTransform.anchorMax = Vector2.one;
            backgroundImage.rectTransform.sizeDelta = new Vector2(Screen.width, Screen.height);

            GameObject scoreObject = new GameObject("Score");
            scoreObject.transform.SetParent(meteorGameObject.transform, false);
            Text scoreText = scoreObject.AddComponent<Text>();
            scoreText.text = "Score: 0";
            scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            scoreText.fontSize = 20;
            scoreText.color = Color.white;
            scoreText.alignment = TextAnchor.UpperLeft;
            scoreText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            scoreText.rectTransform.anchorMin = new Vector2(0f, 1f);
            scoreText.rectTransform.anchorMax = new Vector2(0f, 1f);
            scoreText.rectTransform.anchoredPosition = new Vector2(10f, -10f);

            GameObject highScoreObject = new GameObject("HighScore");
            highScoreObject.transform.SetParent(meteorGameObject.transform, false);
            Text highScoreText = highScoreObject.AddComponent<Text>();
            highScoreText.text = $"High Score: {meteorScoreData.highScore}";
            highScoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            highScoreText.fontSize = 20;
            highScoreText.color = Color.yellow;
            highScoreText.alignment = TextAnchor.UpperLeft;
            highScoreText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            highScoreText.rectTransform.anchorMin = new Vector2(0f, 1f);
            highScoreText.rectTransform.anchorMax = new Vector2(0f, 1f);
            highScoreText.rectTransform.anchoredPosition = new Vector2(10f, -50f);

            GameObject coinCountObject = new GameObject("CoinCount");
            coinCountObject.transform.SetParent(meteorGameObject.transform, false);
            Text coinCountText = coinCountObject.AddComponent<Text>();
            coinCountText.text = $"Coins: {coins}";
            coinCountText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            coinCountText.fontSize = 20;
            coinCountText.color = Color.yellow;
            coinCountText.alignment = TextAnchor.UpperRight;
            coinCountText.rectTransform.sizeDelta = new Vector2(200f, 40f);
            coinCountText.rectTransform.anchorMin = new Vector2(1f, 1f);
            coinCountText.rectTransform.anchorMax = new Vector2(1f, 1f);
            coinCountText.rectTransform.anchoredPosition = new Vector2(-10f, -10f);

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(meteorGameObject.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            Sprite exitSprite = SpriteTextureLoader.getSprite("ui/exit.png");
            if (exitSprite == null)
            {
                exitButtonImage.color = new Color(1f, 0f, 0f, 0.7f);
            }
            else
            {
                exitButtonImage.sprite = exitSprite;
            }
            exitButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(0f, -10f);

            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(HideMinigamesUI);

            activeGame = meteorGameObject;
            var meteorLogic = meteorGameObject.AddComponent<MeteorDodgeLogic>();
            meteorLogic.spawnRate = spawnRate;
            meteorLogic.speed = speed;
            meteorLogic.Setup(scoreObject, highScoreObject, coinCountObject, backgroundObject, exitButtonObject, selectedDoger, meteorScorePath, coinsDataPath);

            GameObject madeByObject = new GameObject("MadeBy");
            madeByObject.transform.SetParent(meteorGameObject.transform, false);
            Text madeByText = madeByObject.AddComponent<Text>();
            madeByText.text = "Made by: ahoyos";
            madeByText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            madeByText.fontSize = 12;
            madeByText.color = Color.white;
            madeByText.alignment = TextAnchor.LowerCenter;
            madeByText.rectTransform.sizeDelta = new Vector2(200f, 20f);
            madeByText.rectTransform.anchorMin = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            madeByText.rectTransform.anchoredPosition = new Vector2(0f, 10f);
        }

        private static void StartTicTacToe()
        {
            if (activeGame != null)
            {
                UnityEngine.Object.Destroy(activeGame);
                activeGame = null;
            }

            GameObject ticTacToeGameObject = new GameObject("TicTacToeGame");
            ticTacToeGameObject.transform.SetParent(minigamesUI.transform, false);
            Canvas ticTacToeCanvas = ticTacToeGameObject.AddComponent<Canvas>();
            ticTacToeCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            ticTacToeCanvas.sortingOrder = 1001;
            ticTacToeGameObject.AddComponent<CanvasScaler>();
            ticTacToeGameObject.AddComponent<GraphicRaycaster>();
            TicTacToeUI tttUI = ticTacToeGameObject.AddComponent<TicTacToeUI>();
            activeGame = ticTacToeGameObject;
            tttUI.StartGame();
            tttUI.OnGameEnd += (playerWin) =>
            {
                if (playerWin) ticTacToeScoreData.playerWins++;
                else ticTacToeScoreData.cpuWins++;
                SaveTicTacToeScore();
            };

            GameObject scoreRatioObject = new GameObject("ScoreRatio");
            scoreRatioObject.transform.SetParent(ticTacToeGameObject.transform, false);
            Text scoreRatioText = scoreRatioObject.AddComponent<Text>();
            scoreRatioText.text = $"Player: {ticTacToeScoreData.playerWins} | CPU: {ticTacToeScoreData.cpuWins}";
            scoreRatioText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            scoreRatioText.fontSize = 20;
            scoreRatioText.color = Color.yellow;
            scoreRatioText.alignment = TextAnchor.UpperRight;
            scoreRatioText.rectTransform.sizeDelta = new Vector2(300f, 40f);
            scoreRatioText.rectTransform.anchorMin = new Vector2(1f, 1f);
            scoreRatioText.rectTransform.anchorMax = new Vector2(1f, 1f);
            scoreRatioText.rectTransform.anchoredPosition = new Vector2(-10f, -10f);

            GameObject exitButtonObject = new GameObject("ExitButton");
            exitButtonObject.transform.SetParent(ticTacToeGameObject.transform, false);
            Image exitButtonImage = exitButtonObject.AddComponent<Image>();
            Sprite exitSprite = SpriteTextureLoader.getSprite("ui/exit.png");
            if (exitSprite == null)
            {
                exitButtonImage.color = new Color(1f, 0f, 0f, 0.7f);
            }
            else
            {
                exitButtonImage.sprite = exitSprite;
            }
            exitButtonImage.rectTransform.sizeDelta = new Vector2(80f, 40f);
            exitButtonImage.rectTransform.anchorMin = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchorMax = new Vector2(0.5f, 1f);
            exitButtonImage.rectTransform.anchoredPosition = new Vector2(0f, -10f);

            Button exitButton = exitButtonObject.AddComponent<Button>();
            exitButton.onClick.AddListener(HideMinigamesUI);
        }

        private class CoinsData
        {
            public int coins;
            public List<string> ownedDogers;
            public string selectedDoger;
        }
    }
}