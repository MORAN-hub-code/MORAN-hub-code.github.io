using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

namespace MinigamesBox
{
    public class MeteorDodgeLogic : MonoBehaviour
    {
        public float spawnRate = 1f;
        public float speed = 5f;
        private int score = 0;
        private int highScore = 0;
        private Text scoreText;
        private Text highScoreText;
        private Text coinCountText;
        private float survivalTime;
        private bool shieldActive = false;
        private float shieldTime = 0f;
        private float shieldDuration = 3f;
        private float shieldCooldown = 10f;
        private float lastShieldTime = -10f;
        private GameObject shieldVisual;
        private bool blackholeCutscene = false;
        private bool phase2 = false;
        private int coinsCollected = 0;
        private GameObject playerObject;
        private List<GameObject> meteorObjects = new List<GameObject>();
        private List<GameObject> bullets = new List<GameObject>();
        private List<GameObject> coinObjects = new List<GameObject>();
        private List<GameObject> itemDropObjects = new List<GameObject>();
        private System.Random rng = new System.Random();
        private float timer;
        private Vector2 playerPosition = new Vector2(15f, 1f);
        private float playerSpeed = 8f;
        private string dogerSkin = "dogerskin1";
        private Transform backgroundLayer;
        private string meteorScorePath;
        private string coinsDataPath;
        private Rect gameAreaRect;
        private float gameAreaWidth = 900f;
        private float gameAreaHeight = 550f;
        private Vector2 gameAreaCenter;
        private HashSet<string> unlockedSkins = new HashSet<string>();
        private GameObject restartButton;

        public void Setup(GameObject scoreObj, GameObject highScoreObj, GameObject coinCountObj, GameObject backgroundObj, GameObject exitBtn, string skin, string scorePath, string coinsPath)
        {
            string scoresDir = Path.Combine(Environment.CurrentDirectory, "Mods", "Minigamesbox", "Scores");
            Directory.CreateDirectory(scoresDir);
            meteorScorePath = Path.Combine(scoresDir, "meteorscore.json");
            coinsDataPath = Path.Combine(scoresDir, "minigamesbox_coins.json");
            scoreText = scoreObj?.GetComponent<Text>();
            highScoreText = highScoreObj?.GetComponent<Text>();
            coinCountText = coinCountObj?.GetComponent<Text>();
            backgroundLayer = backgroundObj?.transform;
            dogerSkin = skin;
            LoadHighScore();
            gameAreaCenter = new Vector2(Screen.width / 2f, Screen.height / 2f + 50f);
            gameAreaRect = new Rect(gameAreaCenter.x - gameAreaWidth / 2, gameAreaCenter.y - gameAreaHeight / 2, gameAreaWidth, gameAreaHeight);
            UpdatePlayerVisual();
            CreateRestartButton();
        }

        private void CreateRestartButton()
        {
            if (restartButton != null) Destroy(restartButton);
            restartButton = new GameObject("RestartButton");
            restartButton.transform.SetParent(transform, false);
            Image buttonImage = restartButton.AddComponent<Image>();
            Sprite restartSprite = SpriteTextureLoader.getSprite("ui/restart.png");
            if (restartSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.white);
                t.Apply();
                restartSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            buttonImage.sprite = restartSprite;
            buttonImage.rectTransform.sizeDelta = new Vector2(60f, 60f);
            buttonImage.rectTransform.anchorMin = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchorMax = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchoredPosition = new Vector2(-70f, -70f);

            Button btn = restartButton.AddComponent<Button>();
            btn.onClick.AddListener(RestartGame);
        }

        private void RestartGame()
        {
            survivalTime = 0f;
            score = 0;
            phase2 = false;
            blackholeCutscene = false;
            timer = 0f;
            coinsCollected = 0;
            unlockedSkins.Clear();
            playerPosition = new Vector2(15f, 1f);
            foreach (var o in meteorObjects) Destroy(o);
            meteorObjects.Clear();
            foreach (var o in bullets) Destroy(o);
            bullets.Clear();
            foreach (var o in coinObjects) Destroy(o);
            coinObjects.Clear();
            foreach (var o in itemDropObjects) Destroy(o);
            itemDropObjects.Clear();
            if (shieldVisual != null) Destroy(shieldVisual);
            if (coinCountText != null) coinCountText.text = $"Coins: {coinsCollected}";
            if (scoreText != null) scoreText.text = $"Score: {score}";
            if (backgroundLayer != null)
            {
                Image bgImg = backgroundLayer.GetComponent<Image>();
                bgImg.sprite = SpriteTextureLoader.getSprite("ui/minigames/phase1.png");
            }
            spawnRate = 1f;
            speed = 5f;
            UpdatePlayerVisual();
        }

        void Update()
        {
            string shieldKey = PlayerPrefs.GetString("Key_Shield", "S");
            string shootKey = PlayerPrefs.GetString("Key_Shoot", "D");
            KeyCode shieldKeyCode = ParseKeyCode(shieldKey, KeyCode.S);
            KeyCode shootKeyCode = ParseKeyCode(shootKey, KeyCode.D);

            if (Input.GetKey(KeyCode.LeftArrow)) playerPosition.x = Mathf.Max(0, playerPosition.x - playerSpeed * Time.deltaTime);
            if (Input.GetKey(KeyCode.RightArrow)) playerPosition.x = Mathf.Min((gameAreaWidth / 30f) - 1f, playerPosition.x + playerSpeed * Time.deltaTime);

            UpdatePlayerVisual();

            if (Input.GetKeyDown(shieldKeyCode)) ActivateShield();
            if (Input.GetKeyDown(shootKeyCode)) Shoot();

            survivalTime += Time.deltaTime;
            score = Mathf.FloorToInt(survivalTime * 10);
            if (scoreText != null) scoreText.text = $"Score: {score}";
            if (score > highScore)
            {
                highScore = score;
                if (highScoreText != null) highScoreText.text = $"High Score: {highScore}";
                SaveHighScore();
            }

            if (!blackholeCutscene && score >= 500 && rng.NextDouble() < 0.3 && !phase2)
            {
                blackholeCutscene = true;
                StartCoroutine(BlackholeSequence());
                return;
            }

            timer += Time.deltaTime;
            if (!blackholeCutscene && !phase2)
            {
                if (timer >= spawnRate)
                {
                    timer = 0;
                    for (int i = 0; i < 6; i++)
                    {
                        float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                        SpawnMeteor(x, gameAreaRect.yMax);
                    }
                    for (int i = 0; i < 3; i++)
                    {
                        if (rng.NextDouble() < 0.5f)
                        {
                            float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                            SpawnCoin(x, gameAreaRect.yMax);
                        }
                    }
                    if (rng.NextDouble() < 0.05f)
                    {
                        float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                        SpawnItemDrop(x, gameAreaRect.yMax);
                    }
                }
            }

            if (phase2)
            {
                if (timer >= spawnRate)
                {
                    timer = 0;
                    for (int i = 0; i < 6; i++)
                    {
                        float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                        SpawnStar(x, gameAreaRect.yMax);
                    }
                    for (int i = 0; i < 3; i++)
                    {
                        if (rng.NextDouble() < 0.5f)
                        {
                            float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                            SpawnCoin(x, gameAreaRect.yMax);
                        }
                    }
                    if (rng.NextDouble() < 0.05f)
                    {
                        float x = UnityEngine.Random.Range(gameAreaRect.xMin + 20, gameAreaRect.xMax - 20);
                        SpawnItemDrop(x, gameAreaRect.yMax);
                    }
                }
            }

            UpdateObjects();
            CheckCollisions();
        }

        private KeyCode ParseKeyCode(string key, KeyCode fallback)
        {
            if (string.IsNullOrEmpty(key)) return fallback;
            KeyCode code;
            if (Enum.TryParse(key, true, out code)) return code;
            if (key.Length == 1)
            {
                char c = char.ToUpperInvariant(key[0]);
                KeyCode letterCode = (KeyCode)Enum.Parse(typeof(KeyCode), c.ToString());
                return letterCode;
            }
            return fallback;
        }

        private void ActivateShield()
        {
            if (!shieldActive && Time.time - lastShieldTime >= shieldCooldown)
            {
                shieldActive = true;
                shieldTime = 0f;
                lastShieldTime = Time.time;
                if (shieldVisual != null) Destroy(shieldVisual);
                shieldVisual = new GameObject("ShieldVisual");
                shieldVisual.transform.SetParent(transform, false);
                Image shieldImage = shieldVisual.AddComponent<Image>();
                shieldImage.color = new Color(0f, 1f, 1f, 0.5f);
                shieldImage.rectTransform.sizeDelta = new Vector2(60f, 60f);
                shieldImage.rectTransform.position = GetPlayerScreenPosition();
            }
        }

        private void Shoot()
        {
            if (PlayerPrefs.GetInt("Ability_Shoot_Unlocked", 0) == 1)
            {
                GameObject bulletObject = new GameObject("Bullet");
                bulletObject.transform.SetParent(transform, false);
                Image bulletImage = bulletObject.AddComponent<Image>();
                bulletImage.color = Color.yellow;
                bulletImage.rectTransform.sizeDelta = new Vector2(20f, 20f);
                bulletObject.transform.position = GetPlayerScreenPosition();
                bullets.Add(bulletObject);
            }
        }

        private void SpawnMeteor(float x, float y)
        {
            GameObject meteorObject = new GameObject("Meteor");
            meteorObject.transform.SetParent(transform, false);
            Image meteorImage = meteorObject.AddComponent<Image>();
            Sprite meteorSprite = SpriteTextureLoader.getSprite("ui/minigames/meteor.png");
            if (meteorSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.gray);
                t.Apply();
                meteorSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            meteorImage.sprite = meteorSprite;
            meteorImage.rectTransform.sizeDelta = new Vector2(40f, 40f);
            meteorObject.transform.position = new Vector2(x, y);
            meteorObjects.Add(meteorObject);
        }

        private void SpawnCoin(float x, float y)
        {
            GameObject coinObject = new GameObject("Coin");
            coinObject.transform.SetParent(transform, false);
            Image coinImage = coinObject.AddComponent<Image>();
            Sprite coinSprite = SpriteTextureLoader.getSprite("ui/minigames/coin.png");
            if (coinSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.yellow);
                t.Apply();
                coinSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            coinImage.sprite = coinSprite;
            coinImage.rectTransform.sizeDelta = new Vector2(30f, 30f);
            coinObject.transform.position = new Vector2(x, y);
            coinObjects.Add(coinObject);
        }

        private void SpawnStar(float x, float y)
        {
            GameObject starObject = new GameObject("Star");
            starObject.transform.SetParent(transform, false);
            Image starImage = starObject.AddComponent<Image>();
            Sprite starSprite = SpriteTextureLoader.getSprite("ui/minigames/star.png");
            if (starSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.white);
                t.Apply();
                starSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            starImage.sprite = starSprite;
            starImage.rectTransform.sizeDelta = new Vector2(36f, 36f);
            starObject.transform.position = new Vector2(x, y);
            meteorObjects.Add(starObject);
        }

        private void SpawnItemDrop(float x, float y)
        {
            GameObject itemObject = new GameObject("ItemDrop");
            itemObject.transform.SetParent(transform, false);
            Image itemImage = itemObject.AddComponent<Image>();
            Sprite itemSprite = SpriteTextureLoader.getSprite("ui/minigames/itemdrop.png");
            if (itemSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.magenta);
                t.Apply();
                itemSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            itemImage.sprite = itemSprite;
            itemImage.rectTransform.sizeDelta = new Vector2(35f, 35f);
            itemObject.transform.position = new Vector2(x, y);
            itemDropObjects.Add(itemObject);
        }

        private IEnumerator BlackholeSequence()
        {
            foreach (var m in meteorObjects) Destroy(m);
            meteorObjects.Clear();
            foreach (var c in coinObjects) Destroy(c);
            coinObjects.Clear();
            foreach (var d in itemDropObjects) Destroy(d);
            itemDropObjects.Clear();
            GameObject blackhole = new GameObject("Blackhole");
            blackhole.transform.SetParent(transform, false);
            Image img = blackhole.AddComponent<Image>();
            Sprite bhSprite = SpriteTextureLoader.getSprite("ui/minigames/blackhole.png");
            if (bhSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.black);
                t.Apply();
                bhSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            img.sprite = bhSprite;
            img.rectTransform.sizeDelta = new Vector2(120f, 120f);
            img.rectTransform.position = new Vector2(gameAreaCenter.x, gameAreaRect.yMax + 60f);
            float fallingTime = 2.5f;
            float startY = gameAreaRect.yMax + 60f;
            float endY = gameAreaCenter.y;
            float elapsed = 0f;
            while (elapsed < fallingTime)
            {
                float y = Mathf.Lerp(startY, endY, elapsed / fallingTime);
                img.rectTransform.position = new Vector2(gameAreaCenter.x, y);
                elapsed += Time.deltaTime;
                yield return null;
            }
            img.rectTransform.position = new Vector2(gameAreaCenter.x, endY);
            yield return new WaitForSeconds(0.8f);
            GameObject blackScreen = new GameObject("BlackScreen");
            blackScreen.transform.SetParent(transform, false);
            Image imgBlack = blackScreen.AddComponent<Image>();
            imgBlack.color = Color.black;
            imgBlack.rectTransform.anchorMin = Vector2.zero;
            imgBlack.rectTransform.anchorMax = Vector2.one;
            imgBlack.rectTransform.sizeDelta = Vector2.zero;
            imgBlack.rectTransform.position = Vector2.zero;
            yield return new WaitForSeconds(3f);
            Destroy(blackScreen);
            Destroy(blackhole);
            phase2 = true;
            if (backgroundLayer != null)
            {
                Image bgImg = backgroundLayer.GetComponent<Image>();
                bgImg.sprite = SpriteTextureLoader.getSprite("ui/minigames/phase2.png");
            }
            spawnRate = 0.75f;
            speed += 2f;
        }

        private void UpdatePlayerVisual()
        {
            if (playerObject == null)
            {
                playerObject = new GameObject("Player");
                playerObject.transform.SetParent(transform, false);
                Image playerImage = playerObject.AddComponent<Image>();
                Sprite playerSprite = SpriteTextureLoader.getSprite($"minigames/{dogerSkin}.png");
                if (playerSprite == null)
                {
                    playerSprite = SpriteTextureLoader.getSprite($"ui/minigames/{dogerSkin}.png");
                }
                if (playerSprite == null)
                {
                    playerSprite = SpriteTextureLoader.getSprite($"player/{dogerSkin}.png");
                }
                if (playerSprite == null)
                {
                    Texture2D t = new Texture2D(2, 2);
                    t.SetPixel(0, 0, Color.blue);
                    t.Apply();
                    playerSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }
                playerImage.sprite = playerSprite;
                playerImage.rectTransform.sizeDelta = new Vector2(30f, 30f);
            }
            Image img = playerObject.GetComponent<Image>();
            if (img != null)
                playerObject.transform.position = GetPlayerScreenPosition();
        }

        private Vector2 GetPlayerScreenPosition()
        {
            float x = gameAreaRect.xMin + playerPosition.x * (gameAreaWidth / 30f);
            float y = gameAreaRect.yMin + playerPosition.y * (gameAreaHeight / 20f);
            return new Vector2(x, y);
        }

        private void UpdateObjects()
        {
            foreach (GameObject meteor in meteorObjects)
            {
                meteor.transform.position -= new Vector3(0, speed, 0);
            }
            foreach (GameObject coin in coinObjects)
            {
                coin.transform.position -= new Vector3(0, speed, 0);
            }
            foreach (GameObject item in itemDropObjects)
            {
                item.transform.position -= new Vector3(0, speed, 0);
            }
            foreach (GameObject bullet in bullets)
            {
                bullet.transform.position += new Vector3(0, 300 * Time.deltaTime, 0);
            }
            if (shieldActive)
            {
                shieldTime += Time.deltaTime;
                if (shieldTime >= shieldDuration)
                {
                    shieldActive = false;
                    if (shieldVisual != null) Destroy(shieldVisual);
                }
            }
        }

        private void CheckCollisions()
        {
            Vector2 playerPos = playerObject != null ? playerObject.transform.position : Vector2.zero;

            for (int i = meteorObjects.Count - 1; i >= 0; i--)
            {
                var meteor = meteorObjects[i];
                Vector2 meteorPos = meteor.transform.position;
                if (Vector2.Distance(playerPos, meteorPos) < 30f && !shieldActive)
                {
                    SaveHighScore();
                    UnityEngine.Object.Destroy(gameObject);
                    return;
                }
                if (!gameAreaRect.Contains(meteor.transform.position) && meteor.transform.position.y < gameAreaRect.yMin - 40f)
                {
                    Destroy(meteor);
                    meteorObjects.RemoveAt(i);
                }
            }

            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                GameObject bullet = bullets[i];
                Vector2 bulletPos = bullet.transform.position;
                for (int j = meteorObjects.Count - 1; j >= 0; j--)
                {
                    GameObject meteor = meteorObjects[j];
                    Vector2 meteorPos = meteor.transform.position;
                    if (Vector2.Distance(bulletPos, meteorPos) < 30f)
                    {
                        Destroy(bullet);
                        bullets.RemoveAt(i);
                        Destroy(meteor);
                        meteorObjects.RemoveAt(j);
                        break;
                    }
                }
                if (!gameAreaRect.Contains(bullet.transform.position) && bullet.transform.position.y > gameAreaRect.yMax + 40f)
                {
                    Destroy(bullet);
                    bullets.RemoveAt(i);
                }
            }

            for (int i = coinObjects.Count - 1; i >= 0; i--)
            {
                GameObject coin = coinObjects[i];
                Vector2 coinPos = coin.transform.position;
                if (Vector2.Distance(playerPos, coinPos) < 30f)
                {
                    coinsCollected++;
                    if (coinCountText != null)
                        coinCountText.text = $"Coins: {coinsCollected}";
                    Destroy(coin);
                    coinObjects.RemoveAt(i);
                    SaveCoins();
                }
                else if (!gameAreaRect.Contains(coin.transform.position) && coin.transform.position.y < gameAreaRect.yMin - 40f)
                {
                    Destroy(coin);
                    coinObjects.RemoveAt(i);
                }
            }

            for (int i = itemDropObjects.Count - 1; i >= 0; i--)
            {
                GameObject item = itemDropObjects[i];
                Vector2 itemPos = item.transform.position;
                if (Vector2.Distance(playerPos, itemPos) < 35f)
                {
                    UnlockRandomSkin();
                    Destroy(item);
                    itemDropObjects.RemoveAt(i);
                }
                else if (!gameAreaRect.Contains(item.transform.position) && item.transform.position.y < gameAreaRect.yMin - 40f)
                {
                    Destroy(item);
                    itemDropObjects.RemoveAt(i);
                }
            }
        }

        private void UnlockRandomSkin()
        {
            List<string> possibleSkins = new List<string> { "dogerskin2", "dogerskin3", "player3" };
            List<string> lockedSkins = new List<string>();
            foreach (var skin in possibleSkins)
            {
                if (!unlockedSkins.Contains(skin))
                {
                    lockedSkins.Add(skin);
                }
            }
            if (lockedSkins.Count > 0)
            {
                int idx = rng.Next(lockedSkins.Count);
                unlockedSkins.Add(lockedSkins[idx]);
                SaveUnlockedSkins();
            }
            ShowUnlockedSkinsShop();
        }

        private void ShowUnlockedSkinsShop()
        {
            GameObject shopPanel = GameObject.Find("ShopPanel");
            if (shopPanel == null)
            {
                shopPanel = new GameObject("ShopPanel");
                shopPanel.transform.SetParent(transform.parent, false);
                Image panelImg = shopPanel.AddComponent<Image>();
                panelImg.color = new Color(0.2f, 0.2f, 0.2f, 0.8f);
                panelImg.rectTransform.sizeDelta = new Vector2(250f, 150f);
                panelImg.rectTransform.anchorMin = new Vector2(0f, 1f);
                panelImg.rectTransform.anchorMax = new Vector2(0f, 1f);
                panelImg.rectTransform.anchoredPosition = new Vector2(20f, -20f);
            }
            foreach (Transform child in shopPanel.transform)
                Destroy(child.gameObject);

            int idx = 0;
            foreach (var skin in unlockedSkins)
            {
                GameObject skinBtn = new GameObject($"SkinBtn_{skin}");
                skinBtn.transform.SetParent(shopPanel.transform, false);
                Image img = skinBtn.AddComponent<Image>();
                Sprite spr = SpriteTextureLoader.getSprite($"minigames/{skin}.png");
                if (spr == null)
                    spr = SpriteTextureLoader.getSprite($"ui/minigames/{skin}.png");
                if (spr == null)
                    spr = SpriteTextureLoader.getSprite($"player/{skin}.png");
                if (spr == null)
                {
                    Texture2D t = new Texture2D(2, 2);
                    t.SetPixel(0, 0, Color.blue);
                    t.Apply();
                    spr = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }
                img.sprite = spr;
                img.rectTransform.sizeDelta = new Vector2(48f, 48f);
                img.rectTransform.anchoredPosition = new Vector2(20 + idx * 60, -40);

                Button btn = skinBtn.AddComponent<Button>();
                string eqSkin = skin;
                btn.onClick.AddListener(() =>
                {
                    dogerSkin = eqSkin;
                    UpdatePlayerVisual();
                });

                idx++;
            }
        }

        private void SaveUnlockedSkins()
        {
            string scoresDir = Path.Combine(Environment.CurrentDirectory, "Mods", "Minigamesbox", "Scores");
            Directory.CreateDirectory(scoresDir);
            string path = Path.Combine(scoresDir, "unlockedskins.json");
            File.WriteAllText(path, Newtonsoft.Json.JsonConvert.SerializeObject(new List<string>(unlockedSkins), Newtonsoft.Json.Formatting.Indented));
        }

        private void LoadHighScore()
        {
            if (File.Exists(meteorScorePath))
            {
                try
                {
                    var data = Newtonsoft.Json.JsonConvert.DeserializeObject<MeteorScoreData>(File.ReadAllText(meteorScorePath));
                    highScore = data.highScore;
                }
                catch
                {
                    highScore = 0;
                }
            }
            else
            {
                highScore = 0;
                SaveHighScore();
            }
            if (highScoreText != null)
                highScoreText.text = $"High Score: {highScore}";
        }

        private void SaveHighScore()
        {
            var data = new MeteorScoreData { highScore = highScore };
            File.WriteAllText(meteorScorePath, Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
        }

        private void SaveCoins()
        {
            if (File.Exists(coinsDataPath))
            {
                var data = Newtonsoft.Json.JsonConvert.DeserializeObject<CoinsData>(File.ReadAllText(coinsDataPath));
                data.coins++;
                File.WriteAllText(coinsDataPath, Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
            }
        }

        private class MeteorScoreData
        {
            public int highScore = 0;
        }
        private class CoinsData
        {
            public int coins = 0;
            public List<string> ownedDogers = new List<string>();
            public string selectedDoger = "dogerskin1";
        }
    }

    public class LogoSpinner : MonoBehaviour
    {
        public bool isSpinning = false;
        private GameObject restartButton;

        void Start()
        {
            CreateRestartButton();
        }

        private void CreateRestartButton()
        {
            if (restartButton != null) Destroy(restartButton);
            restartButton = new GameObject("RestartButton");
            restartButton.transform.SetParent(transform, false);
            Image buttonImage = restartButton.AddComponent<Image>();
            Sprite restartSprite = SpriteTextureLoader.getSprite("ui/restart.png");
            if (restartSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.white);
                t.Apply();
                restartSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            buttonImage.sprite = restartSprite;
            buttonImage.rectTransform.sizeDelta = new Vector2(60f, 60f);
            buttonImage.rectTransform.anchorMin = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchorMax = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchoredPosition = new Vector2(-70f, -70f);

            Button btn = restartButton.AddComponent<Button>();
            btn.onClick.AddListener(RestartLogo);
        }

        private void RestartLogo()
        {
            isSpinning = false;
            transform.rotation = Quaternion.identity;
        }

        void Update()
        {
            if (isSpinning)
            {
                transform.Rotate(0, 0, 180 * Time.deltaTime);
            }
        }
    }

    public class SnakeGameLogic : MonoBehaviour
    {
        private List<Vector2> snake = new List<Vector2>();
        private Vector2 direction = Vector2.right;
        private Vector2 foodPosition;
        private float timer;
        private float speed = 0.1f;
        private bool isGameOver;
        private int score = 0;
        private int highScore = 0;
        private Text scoreText;
        private Text highScoreText;
        private GameObject foodObject;
        private GameObject gameArea;
        private string snakeScorePath;
        private GameObject restartButton;

        public void Setup(GameObject scoreObj, GameObject highScoreObj, string scorePath)
        {
            string scoresDir = Path.Combine(Environment.CurrentDirectory, "Mods", "Minigamesbox", "Scores");
            Directory.CreateDirectory(scoresDir);
            snakeScorePath = Path.Combine(scoresDir, "snakescore.json");
            scoreText = scoreObj.GetComponent<Text>();
            highScoreText = highScoreObj.GetComponent<Text>();
            LoadHighScore();
            CreateRestartButton();
        }

        private void CreateRestartButton()
        {
            if (restartButton != null) Destroy(restartButton);
            restartButton = new GameObject("RestartButton");
            restartButton.transform.SetParent(transform, false);
            Image buttonImage = restartButton.AddComponent<Image>();
            Sprite restartSprite = SpriteTextureLoader.getSprite("ui/restart.png");
            if (restartSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.white);
                t.Apply();
                restartSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            buttonImage.sprite = restartSprite;
            buttonImage.rectTransform.sizeDelta = new Vector2(60f, 60f);
            buttonImage.rectTransform.anchorMin = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchorMax = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchoredPosition = new Vector2(-70f, -70f);

            Button btn = restartButton.AddComponent<Button>();
            btn.onClick.AddListener(RestartGame);
        }

        private void RestartGame()
        {
            snake.Clear();
            direction = Vector2.right;
            timer = 0f;
            speed = 0.1f;
            isGameOver = false;
            score = 0;
            scoreText.text = $"Score: {score}";
            if (foodObject != null) Destroy(foodObject);
            foreach (Transform child in transform)
                if (child.name.StartsWith("SnakePart")) Destroy(child.gameObject);
            if (gameArea == null)
                gameArea = transform.Find("GameArea")?.gameObject;
            snake.Add(new Vector2(5, 5));
            SpawnFood();
        }

        void Start()
        {
            snake.Add(new Vector2(5, 5));
            gameArea = transform.Find("GameArea")?.gameObject;
            SpawnFood();
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.UpArrow) && direction != Vector2.down) direction = Vector2.up;
            if (Input.GetKeyDown(KeyCode.DownArrow) && direction != Vector2.up) direction = Vector2.down;
            if (Input.GetKeyDown(KeyCode.LeftArrow) && direction != Vector2.right) direction = Vector2.left;
            if (Input.GetKeyDown(KeyCode.RightArrow) && direction != Vector2.left) direction = Vector2.right;
            if (isGameOver) return;
            timer += Time.deltaTime;
            if (timer >= speed)
            {
                timer = 0;
                MoveSnake();
            }
        }

        void MoveSnake()
        {
            Vector2 head = snake[0] + direction;
            Rect gameAreaRect = gameArea.GetComponent<RectTransform>().rect;
            Vector2 gameAreaPos = gameArea.GetComponent<RectTransform>().anchoredPosition;
            float minX = (gameAreaPos.x - gameAreaRect.width / 2) / 15;
            float maxX = (gameAreaPos.x + gameAreaRect.width / 2) / 15;
            float minY = (gameAreaPos.y - gameAreaRect.height / 2) / 15;
            float maxY = (gameAreaPos.y + gameAreaRect.height / 2) / 15;
            if (head.x < minX || head.x >= maxX || head.y < minY || head.y >= maxY || snake.Contains(head))
            {
                isGameOver = true;
                SaveHighScore();
                return;
            }
            snake.Insert(0, head);
            if (Vector2.Distance(head, foodPosition) < 0.5f)
            {
                score++;
                scoreText.text = $"Score: {score}";
                if (score > highScore)
                {
                    highScore = score;
                    highScoreText.text = $"High Score: {highScore}";
                    SaveHighScore();
                }
                SpawnFood();
            }
            else
            {
                snake.RemoveAt(snake.Count - 1);
            }
            UpdateSnakeVisuals();
        }

        void SpawnFood()
        {
            Rect gameAreaRect = gameArea.GetComponent<RectTransform>().rect;
            Vector2 gameAreaPos = gameArea.GetComponent<RectTransform>().anchoredPosition;
            float minX = (gameAreaPos.x - gameAreaRect.width / 2) / 15;
            float maxX = (gameAreaPos.x + gameAreaRect.width / 2) / 15;
            float minY = (gameAreaPos.y - gameAreaRect.height / 2) / 15;
            float maxY = (gameAreaPos.y + gameAreaRect.height / 2) / 15;
            foodPosition = new Vector2(
                Mathf.Floor(UnityEngine.Random.Range(minX, maxX)),
                Mathf.Floor(UnityEngine.Random.Range(minY, maxY))
            );
            while (snake.Contains(foodPosition))
            {
                foodPosition = new Vector2(
                    Mathf.Floor(UnityEngine.Random.Range(minX, maxX)),
                    Mathf.Floor(UnityEngine.Random.Range(minY, maxY))
                );
            }
            UpdateFoodVisual();
        }

        void UpdateSnakeVisuals()
        {
            foreach (Transform child in transform)
            {
                if (child.name.StartsWith("SnakePart")) UnityEngine.Object.Destroy(child.gameObject);
            }
            foreach (Vector2 part in snake)
            {
                GameObject partObject = new GameObject("SnakePart");
                partObject.transform.SetParent(transform, false);
                Image partImage = partObject.AddComponent<Image>();
                Sprite spr = SpriteTextureLoader.getSprite("ui/minigames/snakepart.png");
                if (spr == null)
                {
                    Texture2D t = new Texture2D(2, 2);
                    t.SetPixel(0, 0, Color.green);
                    t.Apply();
                    spr = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
                }
                partImage.sprite = spr;
                partImage.rectTransform.sizeDelta = new Vector2(15f, 15f);
                partImage.rectTransform.anchoredPosition = new Vector2(part.x * 15 - gameArea.GetComponent<RectTransform>().anchoredPosition.x, part.y * 15 - gameArea.GetComponent<RectTransform>().anchoredPosition.y);
            }
        }

        void UpdateFoodVisual()
        {
            if (foodObject != null) UnityEngine.Object.Destroy(foodObject);
            foodObject = new GameObject("Food");
            foodObject.transform.SetParent(transform, false);
            Image foodImage = foodObject.AddComponent<Image>();
            Sprite spr = SpriteTextureLoader.getSprite("ui/minigames/snakefood.png");
            if (spr == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.red);
                t.Apply();
                spr = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            foodImage.sprite = spr;
            foodImage.rectTransform.sizeDelta = new Vector2(15f, 15f);
            foodImage.rectTransform.anchoredPosition = new Vector2(foodPosition.x * 15 - gameArea.GetComponent<RectTransform>().anchoredPosition.x, foodPosition.y * 15 - gameArea.GetComponent<RectTransform>().anchoredPosition.y);
        }

        private void LoadHighScore()
        {
            if (File.Exists(snakeScorePath))
            {
                try
                {
                    var data = Newtonsoft.Json.JsonConvert.DeserializeObject<SnakeScoreData>(File.ReadAllText(snakeScorePath));
                    highScore = data.highScore;
                }
                catch
                {
                    highScore = 0;
                }
            }
            else
            {
                highScore = 0;
                SaveHighScore();
            }
            if (highScoreText != null)
                highScoreText.text = $"High Score: {highScore}";
        }

        private void SaveHighScore()
        {
            var data = new SnakeScoreData { highScore = highScore };
            File.WriteAllText(snakeScorePath, Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
        }

        private class SnakeScoreData
        {
            public int highScore = 0;
        }
    }

    public class TicTacToeUI : MonoBehaviour
    {
        public event Action<bool> OnGameEnd;
        private GameObject[,] cells = new GameObject[3, 3];
        private int[,] board = new int[3, 3];
        private int currentPlayer = 1;
        private int playerScore = 0;
        private int cpuScore = 0;
        private Text scoreText;
        private Text infoText;
        private bool gameActive = true;
        private string tttScorePath;
        private GameObject restartButton;

        public void Setup(string scorePath)
        {
            string scoresDir = Path.Combine(Environment.CurrentDirectory, "Mods", "Minigamesbox", "Scores");
            Directory.CreateDirectory(scoresDir);
            tttScorePath = Path.Combine(scoresDir, "scoretictactoe.json");
            LoadScore();
        }

        private void SaveScore()
        {
            var data = new TicTacToeScoreData { playerWins = playerScore, cpuWins = cpuScore };
            File.WriteAllText(tttScorePath, Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
        }

        private void LoadScore()
        {
            if (File.Exists(tttScorePath))
            {
                try
                {
                    var data = Newtonsoft.Json.JsonConvert.DeserializeObject<TicTacToeScoreData>(File.ReadAllText(tttScorePath));
                    playerScore = data.playerWins;
                    cpuScore = data.cpuWins;
                }
                catch
                {
                    playerScore = 0;
                    cpuScore = 0;
                }
            }
            else
            {
                playerScore = 0;
                cpuScore = 0;
                SaveScore();
            }
        }

        public void StartGame()
        {
            GameObject boardObject = new GameObject("Board");
            boardObject.transform.SetParent(transform, false);
            Image boardImage = boardObject.AddComponent<Image>();
            boardImage.color = Color.white;
            boardImage.rectTransform.sizeDelta = new Vector2(450f, 450f);
            boardImage.rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            boardImage.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            boardImage.rectTransform.anchoredPosition = Vector2.zero;

            float cellSize = 140f;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    GameObject cellObject = new GameObject($"Cell_{i}_{j}");
                    cellObject.transform.SetParent(boardObject.transform, false);
                    Image cellImage = cellObject.AddComponent<Image>();
                    cellImage.color = new Color(0.9f, 0.9f, 0.9f, 1f);
                    cellImage.rectTransform.sizeDelta = new Vector2(cellSize, cellSize);
                    cellImage.rectTransform.anchorMin = new Vector2(0f, 1f);
                    cellImage.rectTransform.anchorMax = new Vector2(0f, 1f);
                    cellImage.rectTransform.anchoredPosition = new Vector2(j * cellSize - 140f, -i * cellSize + 140f);

                    Button cellButton = cellObject.AddComponent<Button>();
                    int row = i;
                    int col = j;
                    cellButton.onClick.AddListener(() => OnCellClick(row, col));

                    cells[i, j] = cellObject;
                    board[i, j] = 0;
                }
            }

            GameObject scoreObject = new GameObject("Score");
            scoreObject.transform.SetParent(transform, false);
            scoreText = scoreObject.AddComponent<Text>();
            scoreText.text = $"Player: {playerScore} | CPU: {cpuScore}";
            scoreText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            scoreText.fontSize = 20;
            scoreText.color = Color.white;
            scoreText.alignment = TextAnchor.MiddleCenter;
            scoreText.rectTransform.sizeDelta = new Vector2(450f, 40f);
            scoreText.rectTransform.anchorMin = new Vector2(0.5f, 0f);
            scoreText.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            scoreText.rectTransform.anchoredPosition = new Vector2(0f, 30f);

            GameObject infoObject = new GameObject("Info");
            infoObject.transform.SetParent(transform, false);
            infoText = infoObject.AddComponent<Text>();
            infoText.text = "";
            infoText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            infoText.fontSize = 18;
            infoText.color = Color.yellow;
            infoText.alignment = TextAnchor.MiddleCenter;
            infoText.rectTransform.sizeDelta = new Vector2(450f, 40f);
            infoText.rectTransform.anchorMin = new Vector2(0.5f, 0.0f);
            infoText.rectTransform.anchorMax = new Vector2(0.5f, 0.0f);
            infoText.rectTransform.anchoredPosition = new Vector2(0f, 0f);

            UpdateScoreText();
            CreateRestartButton();
        }

        private void CreateRestartButton()
        {
            if (restartButton != null) Destroy(restartButton);
            restartButton = new GameObject("RestartButton");
            restartButton.transform.SetParent(transform, false);
            Image buttonImage = restartButton.AddComponent<Image>();
            Sprite restartSprite = SpriteTextureLoader.getSprite("ui/restart.png");
            if (restartSprite == null)
            {
                Texture2D t = new Texture2D(2, 2);
                t.SetPixel(0, 0, Color.white);
                t.Apply();
                restartSprite = Sprite.Create(t, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f));
            }
            buttonImage.sprite = restartSprite;
            buttonImage.rectTransform.sizeDelta = new Vector2(60f, 60f);
            buttonImage.rectTransform.anchorMin = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchorMax = new Vector2(1f, 1f);
            buttonImage.rectTransform.anchoredPosition = new Vector2(-70f, -70f);

            Button btn = restartButton.AddComponent<Button>();
            btn.onClick.AddListener(RestartGame);
        }

        private void RestartGame()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    foreach (Transform child in cells[i, j].transform)
                    {
                        UnityEngine.Object.Destroy(child.gameObject);
                    }
                    board[i, j] = 0;
                }
            }
            currentPlayer = 1;
            infoText.text = "";
            gameActive = true;
            UpdateScoreText();
        }

        public void OnCellClick(int row, int col)
        {
            if (!gameActive || board[row, col] != 0) return;
            SetMark(row, col, currentPlayer);
            if (CheckWin(currentPlayer))
            {
                infoText.text = currentPlayer == 1 ? "You Win!" : "CPU Wins!";
                if (currentPlayer == 1) playerScore++; else cpuScore++;
                SaveScore();
                gameActive = false;
                if (OnGameEnd != null) OnGameEnd(currentPlayer == 1);
                Invoke("NewRound", 1.5f);
            }
            else if (IsBoardFull())
            {
                infoText.text = "Draw!";
                gameActive = false;
                SaveScore();
                if (OnGameEnd != null) OnGameEnd(false);
                Invoke("NewRound", 1.5f);
            }
            else
            {
                currentPlayer = currentPlayer == 1 ? 2 : 1;
                if (currentPlayer == 2)
                    StartCoroutine(CPUMoveCoroutine());
            }
        }

        private void SetMark(int row, int col, int player)
        {
            board[row, col] = player;
            GameObject markObject = new GameObject("Mark");
            markObject.transform.SetParent(cells[row, col].transform, false);
            Image markImage = markObject.AddComponent<Image>();
            markImage.color = player == 1 ? Color.blue : Color.red;
            markImage.rectTransform.sizeDelta = new Vector2(100f, 100f);
            markImage.rectTransform.anchoredPosition = Vector2.zero;
        }

        private IEnumerator CPUMoveCoroutine()
        {
            yield return new WaitForSeconds(0.3f);
            if (!gameActive) yield break;
            int bestScore = int.MinValue;
            int moveRow = -1, moveCol = -1;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i, j] == 0)
                    {
                        board[i, j] = 2;
                        int score = Minimax(board, 0, false);
                        board[i, j] = 0;
                        if (score > bestScore)
                        {
                            bestScore = score;
                            moveRow = i;
                            moveCol = j;
                        }
                    }
                }
            }
            if (moveRow != -1 && moveCol != -1)
            {
                OnCellClick(moveRow, moveCol);
            }
        }

        private int Minimax(int[,] b, int depth, bool isMax)
        {
            int result = Winner(b);
            if (result != 0) return result == 2 ? 1 : result == 1 ? -1 : 0;
            if (IsFull(b)) return 0;
            int best = isMax ? int.MinValue : int.MaxValue;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (b[i, j] == 0)
                    {
                        b[i, j] = isMax ? 2 : 1;
                        int score = Minimax(b, depth + 1, !isMax);
                        b[i, j] = 0;
                        if (isMax)
                            best = Math.Max(best, score);
                        else
                            best = Math.Min(best, score);
                    }
                }
            }
            return best;
        }

        private int Winner(int[,] b)
        {
            for (int i = 0; i < 3; i++)
            {
                if (b[i, 0] != 0 && b[i, 0] == b[i, 1] && b[i, 1] == b[i, 2]) return b[i, 0];
                if (b[0, i] != 0 && b[0, i] == b[1, i] && b[1, i] == b[2, i]) return b[0, i];
            }
            if (b[0, 0] != 0 && b[0, 0] == b[1, 1] && b[1, 1] == b[2, 2]) return b[0, 0];
            if (b[0, 2] != 0 && b[0, 2] == b[1, 1] && b[1, 1] == b[2, 0]) return b[0, 2];
            return 0;
        }

        private bool IsFull(int[,] b)
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (b[i, j] == 0) return false;
            return true;
        }

        private bool CheckWin(int player)
        {
            for (int i = 0; i < 3; i++)
                if (board[i, 0] == player && board[i, 1] == player && board[i, 2] == player) return true;
            for (int i = 0; i < 3; i++)
                if (board[0, i] == player && board[1, i] == player && board[2, i] == player) return true;
            if (board[0, 0] == player && board[1, 1] == player && board[2, 2] == player) return true;
            if (board[0, 2] == player && board[1, 1] == player && board[2, 0] == player) return true;
            return false;
        }

        private bool IsBoardFull()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (board[i, j] == 0) return false;
            return true;
        }

        private void NewRound()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    foreach (Transform child in cells[i, j].transform)
                    {
                        UnityEngine.Object.Destroy(child.gameObject);
                    }
                    board[i, j] = 0;
                }
            }
            currentPlayer = 1;
            infoText.text = "";
            gameActive = true;
            UpdateScoreText();
        }

        private void UpdateScoreText()
        {
            if (scoreText != null) scoreText.text = $"Player: {playerScore} | CPU: {cpuScore}";
        }

        private class TicTacToeScoreData
        {
            public int playerWins = 0;
            public int cpuWins = 0;
        }
    }
}