using System;
using NCMS;
using UnityEngine;
using HarmonyLib;
using MinigamesBox;

namespace MinigamesBox
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
            MinigamesBoxTab.Init();
            Harmony harmony = new Harmony("MinigamesBoxMod");
            harmony.PatchAll();
        }
    }
}