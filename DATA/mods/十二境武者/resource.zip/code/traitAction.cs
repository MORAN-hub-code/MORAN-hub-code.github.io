﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class traitAction
    {
        public static bool lei3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningBig(pTile, 0.15f);
                if (pTarget.a.data.health > 1000)
                {
                    pTarget.a.restoreHealth(-1000);
                }
                if (pTarget.a.data.health > 100)
                {
                    pTarget.a.restoreHealth(-100);
                }
                if (pTarget.a.data.health > 10)
                {
                    pTarget.a.restoreHealth(-10);
                }
            }

            return false;
        }

        public static bool lei2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningBig(pTile, 0.10f);
                if (pTarget.a.data.health > 100)
                {
                    pTarget.a.restoreHealth(-100);
                }
                if (pTarget.a.data.health > 10)
                {
                    pTarget.a.restoreHealth(-10);
                }
            }

            return false;
        }

        public static bool lei_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningMedium(pTile, 0.05f);
                if (pTarget.a.data.health > 10)
                {
                    pTarget.a.restoreHealth(-10);
                }
            }

            return false;
        }

        public static bool Knight1_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.学徒骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 4.99)
            {
                return false;
            }

            string[] forbiddenTraits = { "Knight2", "Knight3", "Knight4", "Knight5", "Knight6", "Knight7", "Knight8", "Knight9", "Knight10", "Knight11", "Knight12" };
            foreach (string trait in forbiddenTraits)
            {
                if (pTarget.a.hasTrait(trait))
                {
                    return false;
                }
            }

            upTrait(
                "特质",
                "Knight1",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "plague",
                    "madness"
                },
                new string[] { "特质" }
            );

            return true;
        }

        public static bool Knight2_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.预备骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            if (a.GetKnight() <= 9.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.8;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.6;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.8;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight1",
                "Knight2",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores" },
                new string[] { "Knight22" }
            );

            return true;
        }

        public static bool Knight3_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.初级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 8)
            {
                // 添加Knight1特质
                upTrait("特质", "Knight1", a, new string[] { "Knight2" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 19.99)
            {
                return false;
            }

            a.ChangeKnight(-2);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.4;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomIndex = UnityEngine.Random.Range(0, optionalTraits.Length);
            string selectedTrait = optionalTraits[randomIndex];

            upTrait(
                "Knight2",
                "Knight3",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight22"
                },
                new string[] { "Knight3+", selectedTrait }
            );

            return true;
        }

        public static bool Knight4_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.中级骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 18)
            {
                upTrait("特质", "Knight2", a, new string[] { "Knight3" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 39.99)
            {
                return false;
            }

            a.ChangeKnight(-3);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.05;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.3;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }

            upTrait(
                "Knight3",
                "Knight4",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight3+"
                },
                new string[] { "Knight4+" }
            );

            return true;
        }

        public static bool Knight5_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.高骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 37)
            {
                upTrait("特质", "Knight3", a, new string[] { "Knight4" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 79.99)
            {
                return false;
            }

            a.ChangeKnight(-4);
            double successRate = 0.6;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.2;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.6;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false;
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }


            upTrait(
                "Knight4",
                "Knight5",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight4+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight5+", selectedTrait } :
                new string[] { "Knight5+" }
            );

            return true;
        }

        public static bool Knight6_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.大骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 76)
            {
                upTrait("特质", "Knight4", a, new string[] { "Knight5" }, new string[] { });
                return true; // 趺落境界处理完毕，返回true
            }

            if (a.GetKnight() <= 99.99)
            {
                return false;
            }

            a.ChangeKnight(-5);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.02;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            double randomValue = UnityEngine.Random.Range(0.0f, 1.0f);
            if (randomValue > successRate)
            {
                return false; // 随机数大于成功率，则操作失败
            }
            string[] optionalTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            string selectedTrait = null;
            // 检查是否所有可选特质都已被拥有
            bool allTraitsOwned = optionalTraits.All(trait => a.hasTrait(trait));
            if (!allTraitsOwned)
            {
                var availableTraits = optionalTraits.Where(t => !a.hasTrait(t)).ToList();
                selectedTrait = availableTraits[UnityEngine.Random.Range(0, availableTraits.Count)];
            }

            string actorName = a.getName();
            bool hasTitle = _knightTitles.Any(title => actorName.Contains(title));
            if (!hasTitle)
            {
                int index = UnityEngine.Random.Range(0, _knightTitles.Length);
                string selectedTitle = _knightTitles[index];
                a.data.setName($"{actorName}  —{selectedTitle}");
            }

            upTrait(
                "Knight5",
                "Knight6",
                a,
                new string[]
                {
                    "tumorInfection",
                    "cursed",
                    "infected",
                    "mushSpores",
                    "Knight5+"
                },
                (selectedTrait != null) ?
                new string[] { "Knight6+", "freeze_proof", "fire_proof", selectedTrait } :
                new string[] { "Knight6+", "freeze_proof", "fire_proof" }
            );

            return true;
        }

        public static bool Knight7_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 检查骑士值是否小于x，如果是，则趺落境界
            if (a.GetKnight() < 95)
            {
                upTrait("特质", "Knight6", a, new string[] { "Knight7" }, new string[] { });
                return true;
            }

            if (a.GetKnight() <= 299.99)
            {
                return false;
            }

            a.ChangeKnight(-6);
            double successRate = 0.1;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.005;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.01;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.05;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight6",
                "Knight7",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight6+" },
                new string[] { "Knight7+" }
            );

            return true;
        }

        public static bool Knight8_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.皇家骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 499.99)
            {
                return false;
            }

            a.ChangeKnight(-9);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight7",
                "Knight8",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight7+" },
                new string[] { "Knight8+", "strong_minded", "immune" }
            );

            return true;
        }

        public static bool Knight9_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.传奇骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 799.99)
            {
                return false;
            }

            a.ChangeKnight(-15);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight8",
                "Knight9",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight8+" },
                new string[] { "Knight9+" }
            );

            // 确保获得防火特质
            a.addTrait("fire_proof");

            return true;
        }

        public static bool Knight10_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.圣殿骑士长
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 999.99)
            {
                return false;
            }

            a.ChangeKnight(-20);
            double successRate = 0.08;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.004;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.008;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.04;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight9",
                "Knight10",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight9+" },
                new string[] { "Knight10+" }
            );

            string[] inheritanceLaws = { "inheritanceLaw1", "inheritanceLaw2", "inheritanceLaw3", "inheritanceLaw4", "inheritanceLaw5", "inheritanceLaw6", "inheritanceLaw7", "inheritanceLaw8", "inheritanceLaw9", "inheritanceLaw10", "inheritanceLaw11", "inheritanceLaw12", "inheritanceLaw13" }; // 可以添加更多传承法特质名
            int randomIndex = UnityEngine.Random.Range(0, inheritanceLaws.Length);
            string selectedInheritanceLaw = inheritanceLaws[randomIndex];
            a.addTrait(selectedInheritanceLaw);

            NotificationHelper.ShowBreakthroughNotification(a, "Knight9", "Knight10");

            return true;
        }

        public static bool Knight11_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.骑士王
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;

            if (a.GetKnight() <= 2999.99)
            {
                return false;
            }

            a.ChangeKnight(-30);
            double successRate = 0.06;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.003;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.006;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.03;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight10",
                "Knight11",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight10+" },
                new string[] { "Knight11+" }
            );

            // 添加突破提示
            NotificationHelper.ShowBreakthroughNotification(a, "Knight10", "Knight11");

            return true;
        }

        public static bool Knight12_effectAction(BaseSimObject pTarget, WorldTile pTile = null) //升.天启骑士
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            // 最高境界不会趺落

            if (a.GetKnight() <= 8999.99)
            {
                return false;
            }

            a.ChangeKnight(-60);
            double successRate = 0.02;
            if (a.hasTrait("talent1"))
            {
                successRate = 0.0001;
            }
            else if (a.hasTrait("talent2"))
            {
                successRate = 0.0002;
            }
            else if (a.hasTrait("talent3"))
            {
                successRate = 0.001;
            }

            if (UnityEngine.Random.Range(0.0f, 1.0f) > successRate)
            {
                return false;
            }

            upTrait(
                "Knight11",
                "Knight12",
                a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "Knight11+" },
                new string[] { "Knight12+" }
            );

            NotificationHelper.ShowBreakthroughNotification(a, "Knight11", "Knight12");

            return true;
        }

        private static readonly string[] _knightTitles = { "「凌云剑尊」", "「丹霞孟尝」", "「玉面修罗」", "「寒江钓叟」", "「蚩尤」", "「麒麟」", "「烛龙」", "「过山峰」", "「青岚君」", "「听涛叟」", "「追星」", "「落霞剑客」", "「判官」", "「分水刺」", "「白额虎」", "「金翅雕」", "「赤练蛇」", "「穿山鼠」"
, "「梼杌」", "「狻猊」", "「青虹剑仙」", "「铁掌震北」", "「无痕神偷」", "「白莲圣使」", "「不动明王」", "「风雪狂刀」", "「镇岳神枪」", "「血手人屠」", "「千面神捕」", "「九尾狐」", "「赤练蛇」", "「穿山鼠」", "「笑面虎」", "「千面客」", "「睡罗汉」", "「妙手回春」", "「漠北苍狼」", "「塞北孤影」", "「夜游神」"
, "「幽冥」", "「血河教主」", "「铁尸太岁」", "「大黑天」", "「勾魂使者」", "「至上光明大尊」", "「罗浮剑仙」", "「泣血南山」", "「青铜罗汉」", "「赤风」", "「雨水真人」", "「移山力士」" , "「通臂猿」", "「画皮师」", "「胖米勒」", "「瞎判官」", "「布衣神相」", "「铁面无私」", "「流火将」", "「华盖君」", "「云中游」", "「霜寒刀」"
, "「暗夜修罗」", "「催命阎王」", "「噬魂长枪」", "「腐心太岁」", "「血魔刀客」", "「铁面人屠」", "「毒龙尊者」", "「寒铁龙骑」", "「碧落剑圣」", "「醉里乾坤」", "「三台客」", "「罗睺影」", "「夜行舟」", "「计都踪」", "「踏月来」", "「青棠客」", "「谢春池」", "「折柳生」", "「灞桥别」", "「墨玉箫」"
, "「棋魔子」", "「画圣笔仙」" , "「铁幕游侠」", "「天机神算」" , "「铁笔书生」", "「炽火剑」", "「寒山长枪」" , "「慈悲先生」", "「万神殿主」", "「大漠孤狼」", "「泣竹郎」", "「照夜白」" , "「鱼肠客」", "「焦尾生」" , "「焚琴子」", "「桑落翁」", "「醉扶疏」" , "「金错刀」", "「斩楼兰」", "「博山炉」"
, "「波斯圣使」", "「太初道君」" , "「两仪剑尊」", "「四象神君」", "「周天星主」", "「剑心」", "「五行尊者」", "「混沌魔主」", "「不落残阳」", "「昆仑天柱」", "「沧海龙皇」", "「焚天炎君」", "「波斯圣使」", "「太初道君」" , "「两仪剑尊」", "「四象神君」", "「周天星主」", "「剑心」", "「五行尊者」", "「混沌魔主」", "「不落残阳」", "「昆仑天柱」", "「沧海龙皇」", "「焚天炎君」"
, "「须弥圣僧」", "「毒蛇」", "「巨熊」", "「黄泉引路人」", "「钧天琴尊」", "「紫微剑仙」", "「藏獒」", "「太韶乐圣」", "「北斗武圣」", "「七杀刀魔」", "「画师」", "「白居士」", "「篆烟客」", "「五弦使」", "「弄宫商」", "「白泽生」", "「晓百鬼」", "「饕餮客」", "「吞山河」", "「驺虞刃」", "「毕方使」", "「鲲鹏客」", "「渡沧溟」", "「獬豸眼」"
, "「黄庭真人」", "「南华老仙」", "「干将剑尊」", "「刑天战神」" , "「精卫刀客」", "「大日如来」", "「东瀛天照巫」", "「苗疆祖巫」", "「四极天柱」", "「天宪使者」", "「乾坤镇北」", "「辨忠奸」", "「解千愁」", "「乘黄」", "「穷奇」" , "「乱黑白」", "「奔日月」", "「陵鱼姬」", "「泣珠引」", "「采薇翁」", "「击筑客」", "「题桥生」"
, "「移山圣尊」", "「天命执棋」", "「芥子须弥」", "「凌波剑仙」", "「北冥剑尊」", "「紫微星主」", "「东王公」", "「波斯光明王」", "「太极阴阳子」", "「苍梧神主」", "「断首修罗」", "「 烂柯子」", "「弈春秋」", "「请缨使」", "「砺肝胆」", "「漱石生」", "「然藜客」", "「秦淮影」", "「破胡尘」", "「蓟北枪」", "「灞陵尉」", "「岭南樵」"
, "「垂天剑尊」", "「血河剑奴」", "「生死人屠」" , "「金乌剑尊」", "「九天真尊」", "「圣火明王」", "「沧海冥王」", "「玉清圣主」", "「万神雷主」", "「九阴灼日神」", "「四象伏魔棍尊」", "「焚天煮海尊王」", "「青莲剑仙」", "「吹角将」", "「扎草人」", "「烧丹客」", "「炼龙虎」", "「相面客」", "「镇天元」", "「走龙蛇」", "「解牛功」", "「雕龙手」", "「挽千帆」", "「缝千伤」"
, "「大魔」", "「九霄玄上无量大尊者」", "「阴煞炼魂君」", "「鬼面」", "「大力掌」", "「江城开碑手」", "「黑大虫」", "「霹雳火」", "「云中金刚」", "「追风客」", "「踏雪豹子」" };

        //骑士的恢复生命值效果
        public static bool Knight1_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight2_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(3);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight3_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(4);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight4_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight5_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(16);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight6_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(40);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight7_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight8_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight9_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight10_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight11_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool Knight12_Regen(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="old_trait">升级前的特质</param>
        /// <param name="new_trait">升级到的特质</param>
        /// <param name="actor">单位传入</param>
        /// <param name="other_Oldtraits">升级要删掉的特质(不包括升级前的主特质)</param>
        /// <param name="other_newTrait">升级后要伴随添加的特质(不包含主特质)</param>
        /// <returns></returns>
        public static bool upTrait(
            string old_trait,
            string new_trait,
            Actor actor,
            string[] other_Oldtraits = null,
            string[] other_newTrait = null
        )
        {
            if (actor == null)
            {
                return false;
            }

            foreach (string VARIABLE in other_newTrait)
            {
                actor.addTrait(VARIABLE);
            }

            foreach (var VARIABLE in other_Oldtraits)
            {
                actor.removeTrait(VARIABLE);
            }

            actor.addTrait(new_trait);
            actor.removeTrait(old_trait);
            return true;
        }
    }
}
