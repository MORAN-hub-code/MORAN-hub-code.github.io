﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;

namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }

        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_KnightPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasTalent6 = __instance.hasTrait("talent6");// 检查是否具有特质
            bool hasTalent5 = __instance.hasTrait("talent5");
            bool hasCongenitalPerfection = __instance.hasTrait("congenitalPerfection"); // 检查是否拥有“先天圆满”特质

            // 出生时（年龄为0）有一定概率获得“先天圆满”特质
            if (Mathf.FloorToInt(age) == 0 && !hasCongenitalPerfection && Randy.randomChance(0.05f)) // 5% 的概率
            {
                __instance.addTrait("congenitalPerfection", false);
            }

            // 9岁时获得talent1-talent4的随机特质
            if (Mathf.FloorToInt(age) == 9 && !hasTalent5 && !hasTalent6 &&
                !HasAnyFlairTalen(__instance) &&
                Randy.randomChance(0.2f))
            {
                var talentWeights = new (string traitId, int weight)[]
                {
                    ("talent1", 30),
                    ("talent2", 10),
                    ("talent3", 5),
                    ("talent4", 1)
                };

                // 计算总权重
                int totalWeight = talentWeights.Sum(t => t.weight);

                // 生成随机数
                int randomValue = UnityEngine.Random.Range(0, totalWeight);

                // 遍历权重选择特质
                string selectedTalent = "talent1"; // 默认值
                foreach (var talent in talentWeights)
                {
                    if (randomValue < talent.weight)
                    {
                        selectedTalent = talent.traitId;
                        break;
                    }
                    randomValue -= talent.weight;
                }

                __instance.addTrait(selectedTalent, false);
            }

            // 特质增加武者气血的处理
            var talentKnightChanges = new Dictionary<string, (float, float)>
            {
                { "talent1", (0.5f, 1.5f) },//下
                { "talent2", (1.5f, 3.0f) },//中
                { "talent3", (3.5f, 5.5f) },//上
                { "talent4", (5.5f, 10.0f) },//完美
                { "talent6", (-1.0f, -2.0f) }//安享晚年
            };

            foreach (var change in talentKnightChanges)
            {
                // 如果具有talent6特质，并且当前特质是talent1到talent4，则跳过
                if ((hasTalent6 || hasTalent5) && (change.Key == "talent1" || change.Key == "talent2" || change.Key == "talent3" || change.Key == "talent4"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomKnightIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeKnight(randomKnightIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var knightTraitThresholds = new Dictionary<string, float>
            {
                { "Knight1", 40f },//骑士学徒
                { "Knight2", 50f },//预备骑士+10
                { "Knight3", 50f },//初级骑士+20
                { "Knight4", 65f },//中级骑士+25
                { "Knight5", 70f },//高级骑士+30
                { "Knight6", 100f },//大骑士+60
                { "Knight7", 150f },//骑士学徒
                { "Knight8", 220f },//预备骑士+10
                { "Knight9", 400f },//初级骑士+20
                { "Knight10", 600f },//中级骑士+25
                { "Knight11", 1000f },//高级骑士+30
                { "Knight12", 2000f }//大骑士+60
            };
            const float talent6Chance = 0.1f;
            foreach (var threshold in knightTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(talent6Chance) && !hasCongenitalPerfection)
                {
                    __instance.addTrait("talent6", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Knight1", 10f },
                { "Knight2", 20f },
                { "Knight3", 40f },
                { "Knight4", 80f },
                { "Knight5", 100f },
                { "Knight6", 300f },
                { "Knight7", 500f },
                { "Knight8", 800f },
                { "Knight9", 1000f },
                { "Knight10", 3000f },
                { "Knight11", 9000f },
                { "Knight12", 18000f },
            };
            foreach (var grade in grades)
            {
                UpdateKnightBasedOnGrade(__instance, grade.Key, grade.Value);
            }

            // 检查是否突破到合天境（Knight10）
            if (__instance.hasTrait("Knight10"))
            {
                __instance.data.favorite = true;
            }

            // 检查是否突破到领域境界（Knight9），如果是则赋予防火特质
            if (__instance.hasTrait("Knight9"))
            {
                __instance.addTrait("fire_proof");
            }
        }

        private static void UpdateKnightBasedOnGrade(Actor actor, string traitName, float maxKnight)
        {
            if (actor.hasTrait(traitName))
            {
                float currentKnight = actor.GetKnight();
                float newValue = Mathf.Min(maxKnight, currentKnight);
                actor.SetKnight(newValue);
            }
        }

        private static readonly string[] FlairTalentTraits = new[] { "talent1", "talent2", "talent3", "talent4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairTalentTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}