﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;

namespace ChivalryWizardingWorld.code
{
    internal class traits
    {
        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();
            
            return trait;
        }
        public static ActorTrait talent_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait talent = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "SeedsofLife",
                needs_to_be_explored = false
            };
            talent.action_special_effect += traitAction.Knight1_effectAction;
            AssetManager.traits.add(talent);
            return talent;
        }
        public static void Init()
        {
            _=talent_AddActorTrait("talent1", "trait/talent1");//骑士天赋•下
            _=talent_AddActorTrait("talent2", "trait/talent2");//骑士天赋•中
            _=talent_AddActorTrait("talent3", "trait/talent3");//骑士天赋•上
            _=talent_AddActorTrait("talent4", "trait/talent4");//骑士天赋•完美

            ActorTrait talent5 = CreateTrait("talent5", "trait/talent5", "SeedsofLife");
            talent5.rate_inherit = 100;
            AssetManager.traits.add(talent5);
            
            ActorTrait talent6 = CreateTrait("talent6", "trait/talent6", "SeedsofLife");
            AssetManager.traits.add(talent6);

            ActorTrait knight02 = CreateTrait("Knight2+", "trait/Knight2+", "Knight");
            SafeSetStat(knight02.base_stats, S.lifespan, 10f);
            SafeSetStat(knight02.base_stats, S.skill_combat, 0.1f);
            AssetManager.traits.add(knight02);

            ActorTrait knight03 = CreateTrait("Knight3+", "trait/knight3+", "Knight");
            SafeSetStat(knight03.base_stats , S.lifespan, 20f);
            SafeSetStat(knight03.base_stats , S.skill_combat, 0.2f);
            AssetManager.traits.add(knight03);
            
            ActorTrait Knight04 = CreateTrait("Knight4+", "trait/Knight4+", "Knight");
            SafeSetStat(Knight04.base_stats , S.lifespan, 30f);
            SafeSetStat(Knight04.base_stats , S.skill_combat, 0.3f);
            AssetManager.traits.add(Knight04);

            ActorTrait Knight05 = CreateTrait("Knight5+", "trait/Knight5+", "Knight");
            SafeSetStat(Knight05.base_stats , S.lifespan, 50f);
            SafeSetStat(Knight05.base_stats , S.skill_combat, 0.4f);
            AssetManager.traits.add(Knight05);

            ActorTrait Knight06 = CreateTrait("Knight6+", "trait/Knight6+", "Knight");
            SafeSetStat(Knight06.base_stats , S.lifespan, 80f);
            SafeSetStat(Knight06.base_stats , S.skill_combat, 0.5f);
            AssetManager.traits.add(Knight06);

            ActorTrait Knight07 = CreateTrait("Knight7+", "trait/Knight7+", "Knight");
            SafeSetStat(Knight07.base_stats, S.lifespan, 100f);
            SafeSetStat(Knight07.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Knight07);

            ActorTrait Knight08 = CreateTrait("Knight8+", "trait/Knight8+", "Knight");
            SafeSetStat(Knight08.base_stats, S.lifespan, 150f);
            SafeSetStat(Knight08.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Knight08);

            ActorTrait Knight09 = CreateTrait("Knight9+", "trait/Knight9+", "Knight");
            SafeSetStat(Knight09.base_stats, S.lifespan, 300f);
            SafeSetStat(Knight09.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Knight09);

            ActorTrait Knight091 = CreateTrait("Knight10+", "trait/Knight10+", "Knight");
            SafeSetStat(Knight091.base_stats, S.lifespan, 500f);
            SafeSetStat(Knight091.base_stats, S.skill_combat, 0.6f);
            AssetManager.traits.add(Knight091);

            ActorTrait Knight092 = CreateTrait("Knight11+", "trait/Knight11+", "Knight");
            SafeSetStat(Knight092.base_stats, S.lifespan, 1000f);
            SafeSetStat(Knight092.base_stats, S.skill_combat, 0.7f);
            AssetManager.traits.add(Knight092);

            ActorTrait Knight093 = CreateTrait("Knight12+", "trait/Knight12+", "Knight");
            SafeSetStat(Knight093.base_stats, S.lifespan, 10000f);
            SafeSetStat(Knight093.base_stats, S.skill_combat, 0.8f);
            AssetManager.traits.add(Knight093);

            ActorTrait Knight1 = CreateTrait("Knight1", "trait/Knight1", "Knight");
            SafeSetStat(Knight1.base_stats , S.damage, 30f);
            SafeSetStat(Knight1.base_stats , S.health, 200f);
            SafeSetStat(Knight1.base_stats , S.stamina, 10f);
            //SafeSetStat(Knight1.base_stats , S.knockback_reduction, 0.5f);
            Knight1.action_special_effect += traitAction.Knight2_effectAction;
            Knight1.action_special_effect += traitAction.Knight1_Regen;
            AssetManager.traits.add(Knight1);

            ActorTrait Knight2 = CreateTrait("Knight2", "trait/Knight2", "Knight");
            SafeSetStat(Knight2.base_stats , S.damage, 50f);
            SafeSetStat(Knight2.base_stats , S.health, 300f);
            SafeSetStat(Knight2.base_stats , S.accuracy, 2f);
            SafeSetStat(Knight2.base_stats , S.multiplier_speed, 0.1f);
            SafeSetStat(Knight2.base_stats , S.stamina, 20f);
            //SafeSetStat(Knight2.base_stats , S.knockback_reduction, 0.6f);
            Knight2.action_special_effect += traitAction.Knight3_effectAction;
            Knight2.action_special_effect += traitAction.Knight2_Regen;
            AssetManager.traits.add(Knight2);

            ActorTrait Knight3 = CreateTrait("Knight3", "trait/Knight3", "Knight");
            SafeSetStat(Knight3.base_stats , S.damage, 60f);
            SafeSetStat(Knight3.base_stats , S.health, 400f);
            SafeSetStat(Knight3.base_stats , S.armor, 5f);
            SafeSetStat(Knight3.base_stats , S.targets, 0.1f);
            SafeSetStat(Knight3.base_stats , S.accuracy, 5f);
            SafeSetStat(Knight3.base_stats , S.multiplier_speed, 0.2f);
            SafeSetStat(Knight3.base_stats , S.stamina, 30f);
            //SafeSetStat(Knight3.base_stats , S.knockback_reduction, 0.7f);
            Knight3.action_special_effect += traitAction.Knight4_effectAction;
            Knight3.action_special_effect += traitAction.Knight3_Regen;
            AssetManager.traits.add(Knight3);

            ActorTrait Knight4 = CreateTrait("Knight4", "trait/Knight4", "Knight");
            SafeSetStat(Knight4.base_stats , S.damage, 70f);
            SafeSetStat(Knight4.base_stats , S.health, 500f);
            SafeSetStat(Knight4.base_stats , S.speed, 5f);
            SafeSetStat(Knight4.base_stats , S.armor, 10f);
            SafeSetStat(Knight4.base_stats , S.targets, 1f);
            SafeSetStat(Knight4.base_stats , S.critical_chance, 0.2f);
            SafeSetStat(Knight4.base_stats , S.accuracy, 10f);
            SafeSetStat(Knight4.base_stats , S.multiplier_speed, 0.3f);
            SafeSetStat(Knight4.base_stats , S.stamina, 40f);
            //SafeSetStat(Knight4.base_stats , S.knockback_reduction, 0.8f);
            Knight4.action_special_effect += traitAction.Knight5_effectAction;
            Knight4.action_special_effect += traitAction.Knight4_Regen;
            AssetManager.traits.add(Knight4);

            ActorTrait Knight5 = CreateTrait("Knight5", "trait/Knight5", "Knight");
            SafeSetStat(Knight5.base_stats , S.warfare, 10f);
            SafeSetStat(Knight5.base_stats , S.damage, 100f);
            SafeSetStat(Knight5.base_stats , S.health, 800f);
            SafeSetStat(Knight5.base_stats , S.speed, 10f);
            SafeSetStat(Knight5.base_stats , S.armor, 15f);
            SafeSetStat(Knight5.base_stats , S.targets, 2f);
            SafeSetStat(Knight5.base_stats , S.critical_chance, 0.3f);
            SafeSetStat(Knight5.base_stats , S.accuracy, 20f);
            SafeSetStat(Knight5.base_stats , S.multiplier_speed, 0.4f);
            SafeSetStat(Knight5.base_stats , S.stamina, 50f);
            //SafeSetStat(Knight5.base_stats , S.knockback_reduction, 1f);
            Knight5.action_special_effect += traitAction.Knight6_effectAction;
            Knight5.action_special_effect += traitAction.Knight5_Regen;
            AssetManager.traits.add(Knight5);

            ActorTrait Knight6 = CreateTrait("Knight6", "trait/Knight6", "Knight");
            SafeSetStat(Knight6.base_stats , S.warfare, 20f);
            SafeSetStat(Knight6.base_stats , S.damage, 180f);
            SafeSetStat(Knight6.base_stats , S.armor, 25f);
            SafeSetStat(Knight6.base_stats , S.health, 1500f);
            SafeSetStat(Knight6.base_stats , S.speed, 15f);
            SafeSetStat(Knight6.base_stats , S.area_of_effect, 1f);
            SafeSetStat(Knight6.base_stats , S.targets, 5f);
            SafeSetStat(Knight6.base_stats , S.critical_chance, 0.5f);
            SafeSetStat(Knight6.base_stats , S.accuracy, 30f);
            SafeSetStat(Knight6.base_stats , S.multiplier_speed, 0.6f);
            SafeSetStat(Knight6.base_stats , S.stamina, 70f);
            //SafeSetStat(Knight6.base_stats , S.knockback_reduction, 1f);
            Knight6.action_special_effect += traitAction.Knight7_effectAction;
            Knight6.action_special_effect += traitAction.Knight6_Regen;
            AssetManager.traits.add(Knight6);

            ActorTrait Knight7 = CreateTrait("Knight7", "trait/Knight7", "Knight");
            SafeSetStat(Knight7.base_stats, S.warfare, 30f);
            SafeSetStat(Knight7.base_stats, S.damage, 250f);
            SafeSetStat(Knight7.base_stats, S.mass, 25f);
            SafeSetStat(Knight7.base_stats, S.armor, 35f);
            SafeSetStat(Knight7.base_stats, S.health, 3000f);
            SafeSetStat(Knight7.base_stats, S.speed, 20f);
            SafeSetStat(Knight7.base_stats, S.area_of_effect, 2f);
            SafeSetStat(Knight7.base_stats, S.targets, 7f);
            SafeSetStat(Knight7.base_stats, S.critical_chance, 0.6f);
            SafeSetStat(Knight7.base_stats, S.accuracy, 40f);
            SafeSetStat(Knight7.base_stats, S.multiplier_speed, 0.8f);
            SafeSetStat(Knight7.base_stats, S.stamina, 140f);
            SafeSetStat(Knight7.base_stats, S.range, 2f);
            SafeSetStat(Knight7.base_stats, S.attack_speed, 2f);
            SafeSetStat(Knight7.base_stats, S.multiplier_health, 0.2f);
            SafeSetStat(Knight7.base_stats, S.multiplier_damage, 0.2f);
            Knight7.action_special_effect += traitAction.Knight8_effectAction;
            Knight7.action_special_effect += traitAction.Knight7_Regen;
            AssetManager.traits.add(Knight7);

            ActorTrait Knight8 = CreateTrait("Knight8", "trait/Knight8", "Knight");
            SafeSetStat(Knight8.base_stats, S.warfare, 40f);
            SafeSetStat(Knight8.base_stats, S.damage, 600f);
            SafeSetStat(Knight8.base_stats, S.mass, 60f);
            SafeSetStat(Knight8.base_stats, S.armor, 45f);
            SafeSetStat(Knight8.base_stats, S.health, 6000f);
            SafeSetStat(Knight8.base_stats, S.speed, 25f);
            SafeSetStat(Knight8.base_stats, S.area_of_effect, 3f);
            SafeSetStat(Knight8.base_stats, S.targets, 9f);
            SafeSetStat(Knight8.base_stats, S.critical_chance, 0.7f);
            SafeSetStat(Knight8.base_stats, S.accuracy, 50f);
            SafeSetStat(Knight8.base_stats, S.multiplier_speed, 1.0f);
            SafeSetStat(Knight8.base_stats, S.stamina, 240f);
            SafeSetStat(Knight8.base_stats, S.range, 4f);
            SafeSetStat(Knight8.base_stats, S.attack_speed, 4f);
            SafeSetStat(Knight8.base_stats, S.multiplier_health, 0.4f);
            SafeSetStat(Knight8.base_stats, S.multiplier_damage, 0.4f);
            Knight8.action_attack_target += traitAction.lei_attackAction;
            Knight8.action_special_effect += traitAction.Knight9_effectAction;
            Knight8.action_special_effect += traitAction.Knight8_Regen;
            AssetManager.traits.add(Knight8);

            ActorTrait Knight9 = CreateTrait("Knight9", "trait/Knight9", "Knight");
            SafeSetStat(Knight9.base_stats, S.warfare, 50f);
            SafeSetStat(Knight9.base_stats, S.damage, 1400f);
            SafeSetStat(Knight9.base_stats, S.mass, 140f);
            SafeSetStat(Knight9.base_stats, S.armor, 60f);
            SafeSetStat(Knight9.base_stats, S.health, 12000f);
            SafeSetStat(Knight9.base_stats, S.speed, 30f);
            SafeSetStat(Knight9.base_stats, S.area_of_effect, 4f);
            SafeSetStat(Knight9.base_stats, S.targets, 12f);
            SafeSetStat(Knight9.base_stats, S.critical_chance, 0.8f);
            SafeSetStat(Knight9.base_stats, S.accuracy, 60f);
            SafeSetStat(Knight9.base_stats, S.multiplier_speed, 1.2f);
            SafeSetStat(Knight9.base_stats, S.stamina, 400f);
            SafeSetStat(Knight9.base_stats, S.range, 6f);
            SafeSetStat(Knight9.base_stats, S.attack_speed, 6f);
            SafeSetStat(Knight9.base_stats, S.multiplier_health, 0.6f);
            SafeSetStat(Knight9.base_stats, S.multiplier_damage, 0.6f);
            Knight9.action_attack_target += traitAction.lei_attackAction;
            Knight9.action_special_effect += traitAction.Knight10_effectAction;
            Knight9.action_special_effect += traitAction.Knight9_Regen;
            AssetManager.traits.add(Knight9);

            ActorTrait Knight10 = CreateTrait("Knight10", "trait/Knight10", "Knight");
            SafeSetStat(Knight10.base_stats, S.warfare, 70f);
            SafeSetStat(Knight10.base_stats, S.damage, 3000f);
            SafeSetStat(Knight10.base_stats, S.mass, 400f);
            SafeSetStat(Knight10.base_stats, S.armor, 80f);
            SafeSetStat(Knight10.base_stats, S.health, 30000f);
            SafeSetStat(Knight10.base_stats, S.speed, 50f);
            SafeSetStat(Knight10.base_stats, S.area_of_effect, 5f);
            SafeSetStat(Knight10.base_stats, S.targets, 15f);
            SafeSetStat(Knight10.base_stats, S.critical_chance, 0.9f);
            SafeSetStat(Knight10.base_stats, S.accuracy, 80f);
            SafeSetStat(Knight10.base_stats, S.multiplier_speed, 1.5f);
            SafeSetStat(Knight10.base_stats, S.stamina, 600f);
            SafeSetStat(Knight10.base_stats, S.range, 12f);
            SafeSetStat(Knight10.base_stats, S.attack_speed, 12f);
            SafeSetStat(Knight10.base_stats, S.multiplier_health, 1.2f);
            SafeSetStat(Knight10.base_stats, S.multiplier_damage, 1.2f);
            Knight10.action_attack_target += traitAction.lei2_attackAction;
            Knight10.action_special_effect += traitAction.Knight11_effectAction;
            Knight10.action_special_effect += traitAction.Knight10_Regen;
            AssetManager.traits.add(Knight10);

            ActorTrait Knight11 = CreateTrait("Knight11", "trait/Knight11", "Knight");
            SafeSetStat(Knight11.base_stats, S.warfare, 100f);
            SafeSetStat(Knight11.base_stats, S.damage, 10000f);
            SafeSetStat(Knight11.base_stats, S.mass, 1600f);
            SafeSetStat(Knight11.base_stats, S.armor, 100f);
            SafeSetStat(Knight11.base_stats, S.health, 100000f);
            SafeSetStat(Knight11.base_stats, S.speed, 100f);
            SafeSetStat(Knight11.base_stats, S.area_of_effect, 7f);
            SafeSetStat(Knight11.base_stats, S.targets, 20f);
            SafeSetStat(Knight11.base_stats, S.critical_chance, 1.0f);
            SafeSetStat(Knight11.base_stats, S.accuracy, 100f);
            SafeSetStat(Knight11.base_stats, S.multiplier_speed, 2.0f);
            SafeSetStat(Knight11.base_stats, S.stamina, 1000f);
            SafeSetStat(Knight11.base_stats, S.range, 20f);
            SafeSetStat(Knight11.base_stats, S.attack_speed, 20f);
            SafeSetStat(Knight11.base_stats, S.multiplier_health, 2f);
            SafeSetStat(Knight11.base_stats, S.multiplier_damage, 2f);
            Knight11.action_attack_target += traitAction.lei2_attackAction;
            Knight11.action_special_effect += traitAction.Knight12_effectAction;
            Knight11.action_special_effect += traitAction.Knight11_Regen;
            AssetManager.traits.add(Knight11);

            ActorTrait Knight12 = CreateTrait("Knight12", "trait/Knight12", "Knight");
            SafeSetStat(Knight12.base_stats, S.warfare, 150f);
            SafeSetStat(Knight12.base_stats, S.damage, 20000f);
            SafeSetStat(Knight12.base_stats, S.mass, 2000f);
            SafeSetStat(Knight12.base_stats, S.armor, 150f);
            SafeSetStat(Knight12.base_stats, S.health, 500000f);
            SafeSetStat(Knight12.base_stats, S.speed, 300f);
            SafeSetStat(Knight12.base_stats, S.area_of_effect, 10f);
            SafeSetStat(Knight12.base_stats, S.targets, 25f);
            SafeSetStat(Knight12.base_stats, S.critical_chance, 1.5f);
            SafeSetStat(Knight12.base_stats, S.accuracy, 150f);
            SafeSetStat(Knight12.base_stats, S.multiplier_speed, 3.0f);
            SafeSetStat(Knight12.base_stats, S.stamina, 10000f);
            SafeSetStat(Knight12.base_stats, S.range, 30f);
            SafeSetStat(Knight12.base_stats, S.attack_speed, 30f);
            SafeSetStat(Knight12.base_stats, S.multiplier_health, 3f);
            SafeSetStat(Knight12.base_stats, S.multiplier_damage, 3f);
            Knight12.action_attack_target += traitAction.lei3_attackAction;
            Knight12.action_special_effect += traitAction.Knight12_Regen;
            AssetManager.traits.add(Knight12);

            ActorTrait inheritanceLaw1 = CreateTrait("inheritanceLaw1", "trait/inheritanceLaw1", "InheritanceLaw");
            SafeSetStat(inheritanceLaw1.base_stats, S.damage, 500f); // 示例属性提升
            SafeSetStat(inheritanceLaw1.base_stats, S.health, 500f);
            SafeSetStat(inheritanceLaw1.base_stats, S.speed, 30f);
            SafeSetStat(inheritanceLaw1.base_stats, S.armor, 15f);
            SafeSetStat(inheritanceLaw1.base_stats, S.lifespan, 10f);
            SafeSetStat(inheritanceLaw1.base_stats, S.stamina, 80f);
            SafeSetStat(inheritanceLaw1.base_stats, S.attack_speed, 80f);
            inheritanceLaw1.rate_inherit = 20; // 设定一定的遗传率
            AssetManager.traits.add(inheritanceLaw1);

            ActorTrait inheritanceLaw2 = CreateTrait("inheritanceLaw2", "trait/inheritanceLaw2", "InheritanceLaw");
            SafeSetStat(inheritanceLaw2.base_stats, S.speed, 80f);
            SafeSetStat(inheritanceLaw2.base_stats, S.armor, 20f);
            SafeSetStat(inheritanceLaw2.base_stats, S.damage, 800f); // 示例属性提升
            SafeSetStat(inheritanceLaw2.base_stats, S.health, 400f);
            SafeSetStat(inheritanceLaw2.base_stats, S.lifespan, 30f);
            SafeSetStat(inheritanceLaw2.base_stats, S.stamina, 50f);
            SafeSetStat(inheritanceLaw2.base_stats, S.attack_speed, 40f);
            inheritanceLaw2.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw2);

            ActorTrait inheritanceLaw3 = CreateTrait("inheritanceLaw3", "trait/inheritanceLaw3", "InheritanceLaw");
            SafeSetStat(inheritanceLaw3.base_stats, S.damage, 200f); // 攻击力 +200
            SafeSetStat(inheritanceLaw3.base_stats, S.health, 1000f); // 生命值 +1000
            SafeSetStat(inheritanceLaw3.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(inheritanceLaw3.base_stats, S.armor, 80f); // 护甲 +80
            SafeSetStat(inheritanceLaw3.base_stats, S.lifespan, 50f);
            SafeSetStat(inheritanceLaw3.base_stats, S.stamina, 200f);
            SafeSetStat(inheritanceLaw3.base_stats, S.attack_speed, 20f);
            inheritanceLaw3.rate_inherit = 20;
            AssetManager.traits.add(inheritanceLaw3);

            ActorTrait inheritanceLaw4 = CreateTrait("inheritanceLaw4", "trait/inheritanceLaw4", "InheritanceLaw");
            SafeSetStat(inheritanceLaw4.base_stats, S.speed, 60f); // 速度 +60
            SafeSetStat(inheritanceLaw4.base_stats, S.armor, 50f); // 护甲 +50
            SafeSetStat(inheritanceLaw4.base_stats, S.damage, 400f); // 攻击力 +400
            SafeSetStat(inheritanceLaw4.base_stats, S.health, 400f); // 生命值 +400
            SafeSetStat(inheritanceLaw4.base_stats, S.lifespan, 100f);
            SafeSetStat(inheritanceLaw4.base_stats, S.stamina, 120f);
            SafeSetStat(inheritanceLaw4.base_stats, S.attack_speed, 10f);
            inheritanceLaw4.rate_inherit = 20;
            AssetManager.traits.add(inheritanceLaw4);

            ActorTrait inheritanceLaw5 = CreateTrait("inheritanceLaw5", "trait/inheritanceLaw5", "InheritanceLaw");
            SafeSetStat(inheritanceLaw5.base_stats, S.speed, 40f); // 速度 +40
            SafeSetStat(inheritanceLaw5.base_stats, S.armor, 60f); // 护甲 +60
            SafeSetStat(inheritanceLaw5.base_stats, S.health, 200f); // 生命值 +200
            SafeSetStat(inheritanceLaw5.base_stats, S.damage, 300f); // 攻击力 +300 
            SafeSetStat(inheritanceLaw5.base_stats, S.lifespan, 300f);
            SafeSetStat(inheritanceLaw5.base_stats, S.stamina, 30f);
            SafeSetStat(inheritanceLaw5.base_stats, S.attack_speed, 40f);
            inheritanceLaw5.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw5);

            ActorTrait inheritanceLaw6 = CreateTrait("inheritanceLaw6", "trait/inheritanceLaw6", "InheritanceLaw");
            SafeSetStat(inheritanceLaw6.base_stats, S.speed, 50f); // 速度 +50
            SafeSetStat(inheritanceLaw6.base_stats, S.armor, 50f); // 护甲 +50
            SafeSetStat(inheritanceLaw6.base_stats, S.health, 100f); // 生命值 +100
            SafeSetStat(inheritanceLaw6.base_stats, S.damage, 200f); // 攻击力 +200 
            SafeSetStat(inheritanceLaw6.base_stats, S.lifespan, 30f);
            SafeSetStat(inheritanceLaw6.base_stats, S.stamina, 90f);
            SafeSetStat(inheritanceLaw6.base_stats, S.attack_speed, 70f);
            inheritanceLaw6.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw6);

            ActorTrait inheritanceLaw7 = CreateTrait("inheritanceLaw7", "trait/inheritanceLaw7", "InheritanceLaw");
            SafeSetStat(inheritanceLaw7.base_stats, S.speed, 60f); // 速度 +60
            SafeSetStat(inheritanceLaw7.base_stats, S.armor, 20f); // 护甲 +20
            SafeSetStat(inheritanceLaw7.base_stats, S.health, 180f); // 生命值 +180
            SafeSetStat(inheritanceLaw7.base_stats, S.damage, 120f); // 攻击力 +120 
            SafeSetStat(inheritanceLaw7.base_stats, S.lifespan, 50f);
            SafeSetStat(inheritanceLaw7.base_stats, S.stamina, 40f);
            SafeSetStat(inheritanceLaw7.base_stats, S.attack_speed, 40f);
            inheritanceLaw7.rate_inherit = 20;
            AssetManager.traits.add(inheritanceLaw7);

            ActorTrait inheritanceLaw8 = CreateTrait("inheritanceLaw8", "trait/inheritanceLaw8", "InheritanceLaw");
            SafeSetStat(inheritanceLaw8.base_stats, S.speed, 45f); // 速度 +45
            SafeSetStat(inheritanceLaw8.base_stats, S.armor, 55f); // 护甲 +55
            SafeSetStat(inheritanceLaw8.base_stats, S.health, 600f); // 生命值 +600
            SafeSetStat(inheritanceLaw8.base_stats, S.damage, 100f); // 攻击力 +100 
            SafeSetStat(inheritanceLaw8.base_stats, S.lifespan, 40f);
            SafeSetStat(inheritanceLaw8.base_stats, S.stamina, 70f);
            SafeSetStat(inheritanceLaw8.base_stats, S.attack_speed, 30f);
            inheritanceLaw8.rate_inherit = 20;
            AssetManager.traits.add(inheritanceLaw8);

            ActorTrait inheritanceLaw9 = CreateTrait("inheritanceLaw9", "trait/inheritanceLaw9", "InheritanceLaw");
            SafeSetStat(inheritanceLaw9.base_stats, S.speed, 40f); // 速度 +40
            SafeSetStat(inheritanceLaw9.base_stats, S.armor, 60f); // 护甲 +60
            SafeSetStat(inheritanceLaw9.base_stats, S.health, 800f); // 生命值 +800
            SafeSetStat(inheritanceLaw9.base_stats, S.damage, 240f); // 攻击力 +240 
            SafeSetStat(inheritanceLaw9.base_stats, S.lifespan, 30f);
            SafeSetStat(inheritanceLaw9.base_stats, S.stamina, 90f);
            SafeSetStat(inheritanceLaw9.base_stats, S.attack_speed, 60f);
            inheritanceLaw9.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw9);

            ActorTrait inheritanceLaw10 = CreateTrait("inheritanceLaw10", "trait/inheritanceLaw10", "InheritanceLaw");
            SafeSetStat(inheritanceLaw10.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(inheritanceLaw10.base_stats, S.armor, 10f); // 护甲 +10
            SafeSetStat(inheritanceLaw10.base_stats, S.health, 2000f); // 生命值 +2000
            SafeSetStat(inheritanceLaw10.base_stats, S.damage, 90f); // 攻击力 +90 
            SafeSetStat(inheritanceLaw10.base_stats, S.lifespan, 500f);
            SafeSetStat(inheritanceLaw10.base_stats, S.stamina, 60f);
            SafeSetStat(inheritanceLaw10.base_stats, S.attack_speed, 50f);
            inheritanceLaw10.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw10);
            
            ActorTrait inheritanceLaw11 = CreateTrait("inheritanceLaw11", "trait/inheritanceLaw11", "InheritanceLaw");
            SafeSetStat(inheritanceLaw11.base_stats, S.speed, 10f); // 速度 +10
            SafeSetStat(inheritanceLaw11.base_stats, S.armor, -10f); // 护甲 -10
            SafeSetStat(inheritanceLaw11.base_stats, S.health, -50f); // 生命值 -50
            SafeSetStat(inheritanceLaw11.base_stats, S.damage, 5000f); // 攻击力 +5000 
            SafeSetStat(inheritanceLaw11.base_stats, S.lifespan, -10f);
            SafeSetStat(inheritanceLaw11.base_stats, S.stamina, -30f);
            SafeSetStat(inheritanceLaw11.base_stats, S.attack_speed, 100f);
            inheritanceLaw11.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw11);

            ActorTrait inheritanceLaw12 = CreateTrait("inheritanceLaw12", "trait/inheritanceLaw12", "InheritanceLaw");
            SafeSetStat(inheritanceLaw12.base_stats, S.speed, 40f);
            SafeSetStat(inheritanceLaw12.base_stats, S.armor, 1000f);
            SafeSetStat(inheritanceLaw12.base_stats, S.health, 10000f);
            SafeSetStat(inheritanceLaw12.base_stats, S.damage, 40f); 
            SafeSetStat(inheritanceLaw12.base_stats, S.lifespan, 1000f);
            SafeSetStat(inheritanceLaw12.base_stats, S.stamina, 1000f);
            SafeSetStat(inheritanceLaw12.base_stats, S.attack_speed, 20f);
            inheritanceLaw12.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw12);

            ActorTrait inheritanceLaw13 = CreateTrait("inheritanceLaw13", "trait/inheritanceLaw13", "InheritanceLaw");
            SafeSetStat(inheritanceLaw13.base_stats, S.speed, 80f);
            SafeSetStat(inheritanceLaw13.base_stats, S.armor, 80f);
            SafeSetStat(inheritanceLaw13.base_stats, S.health, 800f);
            SafeSetStat(inheritanceLaw13.base_stats, S.damage, 800f); 
            SafeSetStat(inheritanceLaw13.base_stats, S.lifespan, 80f);
            SafeSetStat(inheritanceLaw13.base_stats, S.stamina, 80f);
            SafeSetStat(inheritanceLaw13.base_stats, S.attack_speed, 80f);
            inheritanceLaw13.rate_inherit = 10;
            AssetManager.traits.add(inheritanceLaw13);
        }

        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}