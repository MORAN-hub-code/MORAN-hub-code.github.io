using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;

namespace PeerlessThedayofGodswrath.code
{
    internal class traits
    {
        public static ActorTrait Divinity_AddActorTrait(string id, string pathIcon)
        {
            ActorTrait Divinity = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "Divinity",
                needs_to_be_explored = false
            };
            Divinity.action_special_effect += traitAction.GodsandBuddhas1_effectAction;//升级条件
            AssetManager.traits.add(Divinity);
            return Divinity;
        }
        public static void Init()
        {
            _ = Divinity_AddActorTrait("Divinity1", "trait/Divinity1");//F天赋
            _ = Divinity_AddActorTrait("Divinity2", "trait/Divinity2");//E天赋
            _ = Divinity_AddActorTrait("Divinity3", "trait/Divinity3");//D天赋
            _ = Divinity_AddActorTrait("Divinity4", "trait/Divinity4");//C天赋
            _ = Divinity_AddActorTrait("Divinity5", "trait/Divinity5");//B天赋
            _ = Divinity_AddActorTrait("Divinity91", "trait/Divinity91");

            ActorTrait Divinity6 = new ActorTrait();
            Divinity6.id = "Divinity6";// A天赋
            Divinity6.path_icon = "trait/Divinity6";
            Divinity6.needs_to_be_explored = false;
            Divinity6.group_id = "Divinity";
            Divinity6.action_special_effect += traitAction.GodsandBuddhas1_effectAction;//升级条件
            AssetManager.traits.add(Divinity6);

            ActorTrait Divinity7 = new ActorTrait();
            Divinity7.id = "Divinity7";// EX天赋
            Divinity7.path_icon = "trait/Divinity7";
            Divinity7.needs_to_be_explored = false;
            Divinity7.group_id = "Divinity";
            Divinity7.action_special_effect += traitAction.SSS_Collection;//收藏
            Divinity7.action_special_effect += traitAction.GodsandBuddhas1_effectAction;//升级条件
            AssetManager.traits.add(Divinity7);

            ActorTrait Divinity92 = new ActorTrait
            {
                id = "Divinity92",
                path_icon = "trait/Divinity92",
                needs_to_be_explored = false,
                group_id = "Divinity",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = -0.3f,//伤害
                    ["multiplier_health"] = -0.3f,//生命
                }
            };
            AssetManager.traits.add(Divinity92);

            ActorTrait GodsandBuddhas1 = new ActorTrait
            {
                id = "GodsandBuddhas1",
                path_icon = "trait/GodsandBuddhas1",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 10f,
                    ["damage"] = 10f,
                    ["health"] = 100f,
                    ["armor"] = 10f,
                    ["targets"] = 1f,
                    ["area_of_effect"] = 1f,
                    ["range"] = 1f,
                    ["attack_speed"] = 1f,
                }
            };
            GodsandBuddhas1.action_special_effect += traitAction.GodsandBuddhas2_effectAction;
            GodsandBuddhas1.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas1.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas1_effect));
            AssetManager.traits.add(GodsandBuddhas1);


            ActorTrait GodsandBuddhas2 = new ActorTrait
            {
                id = "GodsandBuddhas2",
                path_icon = "trait/GodsandBuddhas2",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 20f,
                    ["damage"] = 20f,
                    ["health"] = 200f,
                    ["armor"] = 20f,
                    ["targets"] = 2f,
                    ["area_of_effect"] = 2f,
                    ["range"] = 2f,
                    ["attack_speed"] = 2f,
                }
            };
            GodsandBuddhas2.action_special_effect += traitAction.GodsandBuddhas3_effectAction;
            GodsandBuddhas2.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas2.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas2_effect));
            AssetManager.traits.add(GodsandBuddhas2);

            ActorTrait GodsandBuddhas3 = new ActorTrait
            {
                id = "GodsandBuddhas3",
                path_icon = "trait/GodsandBuddhas3",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 50f,
                    ["damage"] = 50f,
                    ["health"] = 500f,
                    ["armor"] = 50f,
                    ["targets"] = 5f,
                    ["area_of_effect"] = 5f,
                    ["range"] = 5f,
                    ["attack_speed"] = 5f,
                }
            };
            GodsandBuddhas3.action_special_effect += traitAction.GodsandBuddhas4_effectAction;
            GodsandBuddhas3.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas3.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas3_effect));
            AssetManager.traits.add(GodsandBuddhas3);

            ActorTrait GodsandBuddhas4 = new ActorTrait
            {
                id = "GodsandBuddhas4",
                path_icon = "trait/GodsandBuddhas4",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 100f,
                    ["damage"] = 100f,
                    ["health"] = 1000f,
                    ["armor"] = 100f,
                    ["targets"] = 10f,
                    ["area_of_effect"] = 10f,
                    ["range"] = 10f,
                    ["attack_speed"] = 10f,
                }
            };
            GodsandBuddhas4.action_special_effect += traitAction.GodsandBuddhas5_effectAction;
            GodsandBuddhas4.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas4.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas4_effect));
            AssetManager.traits.add(GodsandBuddhas4);

            ActorTrait GodsandBuddhas5 = new ActorTrait
            {
                id = "GodsandBuddhas5",
                path_icon = "trait/GodsandBuddhas5",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 500f,
                    ["damage"] = 500f,
                    ["health"] = 5000f,
                    ["armor"] = 500f,
                    ["targets"] = 50f,
                    ["area_of_effect"] = 50f,
                    ["range"] = 50f,
                    ["attack_speed"] = 50f,
                }
            };
            GodsandBuddhas5.action_special_effect += traitAction.GodsandBuddhas6_effectAction;
            GodsandBuddhas5.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas5.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas5_effect));
            AssetManager.traits.add(GodsandBuddhas5);

            ActorTrait GodsandBuddhas6 = new ActorTrait
            {
                id = "GodsandBuddhas6",
                path_icon = "trait/GodsandBuddhas6",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 1000f,
                    ["damage"] = 1000f,
                    ["health"] = 10000f,
                    ["armor"] = 1000f,
                    ["targets"] = 100f,
                    ["area_of_effect"] = 100f,
                    ["range"] = 100f,
                    ["attack_speed"] = 100f,
                }
            };
            GodsandBuddhas6.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas6));
            GodsandBuddhas6.action_special_effect += traitAction.GodsandBuddhas7_effectAction;
            GodsandBuddhas6.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas6.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas6_effect));
            AssetManager.traits.add(GodsandBuddhas6);

            ActorTrait GodsandBuddhas7 = new ActorTrait
            {
                id = "GodsandBuddhas7",
                path_icon = "trait/GodsandBuddhas7",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 5000f,
                    ["damage"] = 5000f,
                    ["health"] = 50000f,
                    ["armor"] = 5000f,
                    ["targets"] = 500f,
                    ["area_of_effect"] = 500f,
                    ["range"] = 500f,
                    ["attack_speed"] = 500f,
                }
            };
            GodsandBuddhas7.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas7));
            GodsandBuddhas7.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas7));
            GodsandBuddhas7.action_special_effect += traitAction.GodsandBuddhas8_effectAction;
            GodsandBuddhas7.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas7.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas7_effect));
            AssetManager.traits.add(GodsandBuddhas7);

            ActorTrait GodsandBuddhas8 = new ActorTrait
            {
                id = "GodsandBuddhas8",
                path_icon = "trait/GodsandBuddhas8",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["lifespan"] = 10000f,
                    ["damage"] = 10000f,
                    ["health"] = 100000f,
                    ["armor"] = 10000f,
                    ["targets"] = 1000f,
                    ["area_of_effect"] = 1000f,
                    ["range"] = 1000f,
                    ["attack_speed"] = 1000f,
                }
            };

            GodsandBuddhas8.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas8));
            GodsandBuddhas8.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas8));
            GodsandBuddhas8.action_special_effect += traitAction.GodsandBuddhas9_effectAction;
            GodsandBuddhas8.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas8.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas8_effect));
            AssetManager.traits.add(GodsandBuddhas8);

            ActorTrait GodsandBuddhas9 = new ActorTrait
            {
                id = "GodsandBuddhas9",
                path_icon = "trait/GodsandBuddhas9",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["loyalty_traits"] = -1000000000f,
                    ["lifespan"] = 5000f,
                    ["damage"] = 50000f,
                    ["health"] = 500000f,
                    ["armor"] = 5000f,
                    ["targets"] = 5000f,
                    ["area_of_effect"] = 5000f,
                    ["range"] = 5000f,
                    ["attack_speed"] = 500f,
                }
            };
            GodsandBuddhas9.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas9));
            GodsandBuddhas9.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas9));
            GodsandBuddhas9.action_special_effect += traitAction.GodsandBuddhas91_effectAction;
            GodsandBuddhas9.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas9.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas9_effect));
            AssetManager.traits.add(GodsandBuddhas9);

            ActorTrait GodsandBuddhas91 = new ActorTrait
            {
                id = "GodsandBuddhas91",
                path_icon = "trait/GodsandBuddhas91",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["loyalty_traits"] = -1000000000f,
                    ["lifespan"] = 10000f,
                    ["damage"] = 100000f,
                    ["health"] = 1000000f,
                    ["armor"] = 10000f,
                    ["targets"] = 10000f,
                    ["area_of_effect"] = 10000f,
                    ["range"] = 10000f,
                    ["attack_speed"] = 1000f,
                }
            };
            GodsandBuddhas91.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas91));
            GodsandBuddhas91.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas91));
            GodsandBuddhas91.action_special_effect += traitAction.GodsandBuddhas92_effectAction;
            GodsandBuddhas91.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas91.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas91_effect));
            AssetManager.traits.add(GodsandBuddhas91);

            ActorTrait GodsandBuddhas92 = new ActorTrait
            {
                id = "GodsandBuddhas92",
                path_icon = "trait/GodsandBuddhas92",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["loyalty_traits"] = -1000000000f,
                    ["lifespan"] = 50000f,
                    ["damage"] = 500000f,
                    ["health"] = 5000000f,
                    ["armor"] = 50000f,
                    ["targets"] = 50000f,
                    ["area_of_effect"] = 50000f,
                    ["range"] = 50000f,
                    ["attack_speed"] = 5000f,
                }
            };
            GodsandBuddhas92.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas92));
            GodsandBuddhas92.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas92));
            GodsandBuddhas92.action_special_effect += traitAction.GodsandBuddhas93_effectAction;
            GodsandBuddhas92.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas92.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas92_effect));
            AssetManager.traits.add(GodsandBuddhas92);

            ActorTrait GodsandBuddhas93 = new ActorTrait
            {
                id = "GodsandBuddhas93",
                path_icon = "trait/GodsandBuddhas93",
                needs_to_be_explored = false,
                group_id = "GodsandBuddhas",
                base_stats = new BaseStats
                {
                    ["loyalty_traits"] = -1000000000f,
                    ["lifespan"] = 100000f,
                    ["damage"] = 10000000f,
                    ["health"] = 100000000f,
                    ["armor"] = 100000f,
                    ["targets"] = 100000f,
                    ["area_of_effect"] = 100000f,
                    ["range"] = 100000f,
                    ["attack_speed"] = 10000f,
                }
            };
            GodsandBuddhas93.action_attack_target += new AttackAction((traitAction.damage_GodsandBuddhas93));
            GodsandBuddhas93.action_attack_target += new AttackAction((traitAction.attack_GodsandBuddhas93));
            GodsandBuddhas93.action_special_effect += (WorldAction)Delegate.Combine(GodsandBuddhas93.action_special_effect,
                    new WorldAction(traitAction.GodsandBuddhas93_effect));
            AssetManager.traits.add(GodsandBuddhas93);

            ActorTrait Godsgift1 = new ActorTrait
            {
                id = "Godsgift1",
                path_icon = "trait/Godsgift1",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            AssetManager.traits.add(Godsgift1);

            ActorTrait Godsgift2 = new ActorTrait
            {
                id = "Godsgift2",
                path_icon = "trait/Godsgift2",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 10f,//生命
                    ["armor"] = 100f,//护甲
                }
            };
            AssetManager.traits.add(Godsgift2);

            ActorTrait Godsgift3 = new ActorTrait
            {
                id = "Godsgift3",
                path_icon = "trait/Godsgift3",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                    ["critical_chance"] = 100f,//暴击率
                }
            };
            AssetManager.traits.add(Godsgift3);

            ActorTrait Godsgift4 = new ActorTrait
            {
                id = "Godsgift4",
                path_icon = "trait/Godsgift4",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 5f,//伤害
                    ["multiplier_health"] = 5f,//生命
                }
            };
            Godsgift4.action_special_effect += (WorldAction)Delegate.Combine(Godsgift4.action_special_effect,
                    new WorldAction(traitAction.Godsgift4_effectAction));
            AssetManager.traits.add(Godsgift4);

            ActorTrait Godsgift5 = new ActorTrait
            {
                id = "Godsgift5",
                path_icon = "trait/Godsgift5",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };

            AssetManager.traits.add(Godsgift5);

            ActorTrait Godsgift6 = new ActorTrait
            {
                id = "Godsgift6",
                path_icon = "trait/Godsgift6",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            Godsgift6.action_attack_target += new AttackAction((traitAction.attack_Godsgift6));
            AssetManager.traits.add(Godsgift6);

            ActorTrait Godsgift7 = new ActorTrait
            {
                id = "Godsgift7",
                path_icon = "trait/Godsgift7",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                    ["targets"] = 10000000f,//目标
                    ["range"] = 10000000f,//射程
                    ["area_of_effect"] = 10000000f,//范围

                }
            };
            AssetManager.traits.add(Godsgift7);

            ActorTrait Godsgift8 = new ActorTrait
            {
                id = "Godsgift8",
                path_icon = "trait/Godsgift8",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            AssetManager.traits.add(Godsgift8);

            ActorTrait Godsgift9 = new ActorTrait
            {
                id = "Godsgift9",
                path_icon = "trait/Godsgift9",
                needs_to_be_explored = false,
                group_id = "Godsgift",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 10f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            AssetManager.traits.add(Godsgift9);

            ActorTrait HolyTruth1 = new ActorTrait
            {
                id = "HolyTruth1",
                path_icon = "trait/HolyTruth1",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth1.action_attack_target += new AttackAction((traitAction.attack_HolyTruth1));
            AssetManager.traits.add(HolyTruth1);

            ActorTrait HolyTruth2 = new ActorTrait
            {
                id = "HolyTruth2",
                path_icon = "trait/HolyTruth2",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth2.action_attack_target += new AttackAction((traitAction.attack_HolyTruth2));
            AssetManager.traits.add(HolyTruth2);

            ActorTrait HolyTruth3 = new ActorTrait
            {
                id = "HolyTruth3",
                path_icon = "trait/HolyTruth3",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth3.action_attack_target += new AttackAction((attack_HolyTruth3));
            AssetManager.traits.add(HolyTruth3);

            ActorTrait HolyTruth4 = new ActorTrait
            {
                id = "HolyTruth4",
                path_icon = "trait/HolyTruth4",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth4.action_get_hit = (GetHitAction)Delegate.Combine(HolyTruth4.action_get_hit, new GetHitAction(traitAction.attack_HolyTruth4));
            AssetManager.traits.add(HolyTruth4);

            ActorTrait HolyTruth5 = new ActorTrait
            {
                id = "HolyTruth5",
                path_icon = "trait/HolyTruth5",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth5.action_attack_target += new AttackAction((traitAction.attack_HolyTruth5));
            AssetManager.traits.add(HolyTruth5);

            ActorTrait HolyTruth6 = new ActorTrait
            {
                id = "HolyTruth6",
                path_icon = "trait/HolyTruth6",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 5f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth6.action_attack_target += new AttackAction((traitAction.attack_HolyTruth6));
            AssetManager.traits.add(HolyTruth6);

            ActorTrait HolyTruth7 = new ActorTrait
            {
                id = "HolyTruth7",
                path_icon = "trait/HolyTruth7",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth7.action_attack_target += new AttackAction((traitAction.attack_HolyTruth7));
            AssetManager.traits.add(HolyTruth7);

            ActorTrait HolyTruth8 = new ActorTrait
            {
                id = "HolyTruth8",
                path_icon = "trait/HolyTruth8",
                needs_to_be_explored = false,
                group_id = "HolyTruth",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            HolyTruth8.action_special_effect += (WorldAction)Delegate.Combine(HolyTruth8.action_special_effect,
                    new WorldAction(traitAction.HolyTruth8_effectAction));
            AssetManager.traits.add(HolyTruth8);

            ActorTrait GuardianDharma1 = new ActorTrait
            {
                id = "GuardianDharma1",
                path_icon = "trait/GuardianDharma1",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 1f,//伤害
                    ["multiplier_health"] = 1f,//生命
                }
            };
            GuardianDharma1.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma1.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma1);

            ActorTrait GuardianDharma2 = new ActorTrait
            {
                id = "GuardianDharma2",
                path_icon = "trait/GuardianDharma2",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 2f,//伤害
                    ["multiplier_health"] = 2f,//生命
                }
            };
            GuardianDharma2.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma2.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma2);

            ActorTrait GuardianDharma3 = new ActorTrait
            {
                id = "GuardianDharma3",
                path_icon = "trait/GuardianDharma3",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 3f,//伤害
                    ["multiplier_health"] = 3f,//生命
                }
            };
            GuardianDharma3.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma3.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma3);

            ActorTrait GuardianDharma4 = new ActorTrait
            {
                id = "GuardianDharma4",
                path_icon = "trait/GuardianDharma4",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 4f,//伤害
                    ["multiplier_health"] = 4f,//生命
                }
            };
            GuardianDharma4.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma4.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma4);

            ActorTrait GuardianDharma5 = new ActorTrait
            {
                id = "GuardianDharma5",
                path_icon = "trait/GuardianDharma5",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 5f,//伤害
                    ["multiplier_health"] = 5f,//生命
                }
            };
            GuardianDharma5.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma5.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma5);

            ActorTrait GuardianDharma6 = new ActorTrait
            {
                id = "GuardianDharma6",
                path_icon = "trait/GuardianDharma6",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 6f,//伤害
                    ["multiplier_health"] = 6f,//生命
                }
            };
            GuardianDharma6.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma6.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma6);

            ActorTrait GuardianDharma7 = new ActorTrait
            {
                id = "GuardianDharma7",
                path_icon = "trait/GuardianDharma7",
                needs_to_be_explored = false,
                group_id = "GuardianDharma",
                base_stats = new BaseStats
                {
                    ["multiplier_damage"] = 7f,//伤害
                    ["multiplier_health"] = 7f,//生命
                }
            };
            GuardianDharma7.action_special_effect = (WorldAction)Delegate.Combine(GuardianDharma7.action_special_effect, new WorldAction(traitAction.tamedBeastSpecialEffect));
            AssetManager.traits.add(GuardianDharma7);
        }

        private static bool attack_HolyTruth3(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 10% 触发几率
            if (!Randy.randomChance(0.1f))
            {
                return false;
            }
            // 检查目标有效性
            if (pTarget == null || !pTarget.isActor() || !pTarget.isAlive())
            {
                return false;
            }
            Actor targetActor = pTarget.a;
            if (targetActor == null)
            {
                return false;
            }
            // 获取目标所有特质
            IReadOnlyCollection<ActorTrait> traits = targetActor.getTraits();
            if (traits == null || traits.Count == 0)
            {
                return false;
            }

            // 收集可移除特质ID（先提取ID，避免移除时枚举集合被修改）
            List<string> removableIds = new List<string>();
            foreach (ActorTrait trait in traits)
            {
                string traitId = trait.getId();

                removableIds.Add(traitId);
            }

            if (removableIds.Count == 0)
            {
                return false;
            }

            // 随机移除最多两个特质（不可重复）
            int removedCount = 0;
            int toRemove = Mathf.Min(2, removableIds.Count);
            for (int i = 0; i < toRemove; i++)
            {
                int idx = UnityEngine.Random.Range(0, removableIds.Count);
                string removeTraitId = removableIds[idx];
                removableIds.RemoveAt(idx); // 确保第二次不会选到同一个

                if (targetActor.hasTrait(removeTraitId))
                {
                    targetActor.removeTrait(removeTraitId);
                    removedCount++;
                }
            }

            if (removedCount > 0)
            {
                // 视觉反馈
                pTarget.a.spawnParticle(Toolbox.color_black);
                return true;
            }

            return false;
        }
    }
}