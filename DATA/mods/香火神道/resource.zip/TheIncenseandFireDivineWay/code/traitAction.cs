using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using UnityEngine;
using HarmonyLib;
using AttributeExpansion.code.utils;

namespace PeerlessThedayofGodswrath.code
{
    internal class traitAction
    {
        // ======== 后缀系统 ========
        private static readonly Dictionary<string, string> _xianSuffixMap = new Dictionary<string, string>
        {
            {"GodsandBuddhas1", "感神"},
            {"GodsandBuddhas2", "聚信"},
            {"GodsandBuddhas3", "铸坛"},
            {"GodsandBuddhas4", "灵应"},
            {"GodsandBuddhas5", "司辰"},
            {"GodsandBuddhas6", "金身"},
            {"GodsandBuddhas7", "权柄"},
            {"GodsandBuddhas8", "法域"},
            {"GodsandBuddhas9", "显圣"},
            {"GodsandBuddhas91", "香火"},
            {"GodsandBuddhas92", "神念"},
            {"GodsandBuddhas93", "归一"}
        };

        private static void UpdateXianSuffix(Actor actor, string newTrait)
        {
            if (_xianSuffixMap.TryGetValue(newTrait, out string suffix))
            {
                string currentName = actor.getName();

                // 1) 分离基础名称和旧境界后缀
                int lastDashIndex = currentName.LastIndexOf('-');
                string basePart = lastDashIndex >= 0
                    ? currentName.Substring(0, lastDashIndex).Trim()
                    : currentName;

                // 2) 高阶境界移除多余体质称号
                string[] highGradeTraits = { "GodsandBuddhas9", "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93" };
                if (highGradeTraits.Contains(newTrait))
                {
                    basePart = basePart
                        .Replace(" 圣体", "").Replace("圣体", "")
                        .Replace(" 道胎", "").Replace("道胎", "")
                        .Trim();
                }

                // 3) 设置新名称
                actor.data.setName($"{basePart}-{suffix}");
            }
        }

        private static void ApplyXianTitle(Actor actor, string newTrait)
        {
            if (_xianTitleMap.TryGetValue(newTrait, out string[] titles))
            {
                string currentName = actor.getName();

                // 1) 分离境界后缀
                int lastDashIndex = currentName.LastIndexOf('-');
                string suffixPart = lastDashIndex > 0
                    ? currentName.Substring(lastDashIndex)
                    : "";

                string basePart = lastDashIndex > 0
                    ? currentName.Substring(0, lastDashIndex).Trim()
                    : currentName;

                // 2) 移除旧尊号
                int firstDashIndex = basePart.IndexOf('-');
                if (firstDashIndex > 0)
                {
                    basePart = basePart.Substring(firstDashIndex + 1).Trim();
                }

                // 3) 高阶境界移除多余体质称号
                string[] highGradeTraits = { "GodsandBuddhas9", "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93" };
                if (highGradeTraits.Contains(newTrait))
                {
                    basePart = basePart
                        .Replace(" 圣体", "").Replace("圣体", "")
                        .Replace(" 道胎", "").Replace("道胎", "")
                        .Trim();
                }

                // 4) 随机尊号
                string title = titles[UnityEngine.Random.Range(0, titles.Length)];

                // 5) 设置新名称
                actor.data.setName($"{title}-{basePart}{suffixPart}");
            }
        }

        // ======== 尊号系统 ========
        private static readonly Dictionary<string, string[]> _xianTitleMap = new Dictionary<string, string[]>
        {
            {"GodsandBuddhas9", new string[] {
            "碧落飞霞元君", "紫府丹霄真宰", "青冥浩气法主", "赤霄炎灵圣尊", "玄霜玉雪真君", "黄庭内景法王",
            "白虹贯日真宰", "黑水玄冥圣尊", "朱明耀真元君", "苍龙扶桑法主", "翠微山岳真宰", "金精耀魄圣尊",
            "银汉星河真君", "玉露凝香法王", "琼枝瑶草真宰", "珠光宝炁圣尊", "珊瑚海藏元君", "琉璃净界法主",
            "琥珀晨光真宰", "玛瑙霞辉圣尊", "水晶宫阙真君", "翡翠林渊法王", "云锦天章真宰", "霞帔霓裳圣尊",
            "雾縠轻纱元君", "露华凝珠法主", "霜刃寒光真宰", "雪魄冰魂圣尊", "风伯飞廉真君", "雨师玄冥法王",
            "雷公震吼真宰", "电母耀光圣尊", "虹霓跨天元君", "月窟桂影法主", "日宫金乌真宰", "星槎渡汉圣尊",
            "天河织女真君", "地脉龙神法王", "山灵岳渎真宰", "水府洞渊圣尊"
            }},

            { "GodsandBuddhas91", new string[] {
            "九霄雷声普化天尊", "南极长生大帝", "五岳群山之尊", "四海八渎龙神", "太阳金焰真皇", "太阴幽荧元君",
            "战争兵燹之主", "文昌运禄帝君", "幽冥度厄真王", "造化玉碟", "天命气运枢机", "大道纶音宣化",
            "周天星斗共主", "三界十方总摄", "万法归宗道祖", "混元仙箓敕令", "无极雷渊帝君", "永昼光明化身"
            }},

            {"GodsandBuddhas92", new string[] {
            "九霄雷府真王", "五岳巡天真圣", "四海龙脉法主", "北斗枢机天尊", "南斗延寿真君", "东华青阳道君",
            "西灵白帝真宰", "中黄太乙法王", "九地枢机圣尊", "三天执法真宰", "二十八宿星主", "三十六天罡尊",
            "七十二地煞君", "五行造化真圣", "八卦衍化法王", "十方护法天尊", "三界巡狩真君", "九泉溟冷法主",
            "六合阴阳真宰", "四象枢机圣尊", "十二元辰真君", "二十四节气神", "六十甲子法王", "九宫飞星真宰",
            "三台华盖天尊", "五方揭谛真圣", "七政四余法主", "九曜星君真宰", "三元九运圣尊", "六丁六甲真君",
            "太岁流年法王", "五雷都司真宰", "八门遁甲圣尊", "十殿阎罗真君", "三官大帝法主", "四值功曹真宰",
            "五岳四渎圣尊", "九幽拔罪真君", "六道轮回法王", "三山符箓真宰"
            }},

            {"GodsandBuddhas93", new string[] {
            "混元祖炁梵天", "太虚玄穹上帝", "九光妙境天尊", "万象根源道母", "紫微星枢大帝", "玉清境妙行尊",
            "混沌未形真宰", "太极先天道祖", "玄牝之门化身", "周天列曜主宸", "鸿蒙未判元君", "璇玑玉衡主宰",
            "阴阳未分法王", "十方三世法身", "寂照灵明真如", "无极太极道枢", "虚空妙有法界", "乾坤未肇玄帝",
            "万象寂灭天尊", "造化根源圣祖", "玄珠洞照真王", "太初先天道母", "混洞赤文上帝", "玉京山妙境尊",
            "紫金阙中法王", "玄都妙有真宰", "九霄云极天尊", "太易未形元君", "周流六虚道祖", "玄黄未分法身",
            "万象枢机大帝", "清静自然真如", "混成先天道母", "玉虚境中圣尊", "紫炁玄元上帝", "太素妙行天尊",
            "玄牝造化法王", "周天星斗主宸", "无极妙有真宰", "鸿钧未判元君"
            }}
        };

        // ======== 基础工具 ========
        private static string GetNewRandomTrait(string[] additionalTraits)
        {
            if (additionalTraits == null || additionalTraits.Length == 0) return null;
            int randomIndex = UnityEngine.Random.Range(0, additionalTraits.Length);
            return additionalTraits[randomIndex];
        }

        public static bool upTrait(string old_trait, string new_trait, Actor actor, string[] other_Oldtraits = null,
                                   string[] other_newTrait = null)
        {
            if (actor == null) return false;

            if (other_newTrait != null)
            {
                foreach (var t in other_newTrait)
                {
                    if (string.IsNullOrEmpty(t)) continue;
                    if (!actor.hasTrait(t)) actor.addTrait(t);
                }
            }

            if (other_Oldtraits != null)
            {
                foreach (var t in other_Oldtraits)
                {
                    if (string.IsNullOrEmpty(t)) continue;
                    if (actor.hasTrait(t)) actor.removeTrait(t);
                }
            }

            if (!string.IsNullOrEmpty(old_trait) && actor.hasTrait(old_trait))
                actor.removeTrait(old_trait);

            if (!string.IsNullOrEmpty(new_trait) && !actor.hasTrait(new_trait))
                actor.addTrait(new_trait);

            return true;
        }
        // ======== HolyTruth 唯一池（用于 92 可选赋予，非门槛） ========
        private static readonly string[] s_HolyTruthTraits = new string[]
        {
            "HolyTruth1","HolyTruth2","HolyTruth3","HolyTruth4","HolyTruth5","HolyTruth6","HolyTruth7","HolyTruth8"
        };

        private static HashSet<string> GetGloballyUsedHolyTruthTraits()
        {
            var used = new HashSet<string>();
            var list = MapBox.instance.units?.getSimpleList();
            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    var u = list[i];
                    if (u == null || !u.isAlive()) continue;
                    for (int k = 0; k < s_HolyTruthTraits.Length; k++)
                    {
                        string t = s_HolyTruthTraits[k];
                        if (u.hasTrait(t))
                            used.Add(t);
                    }
                }
            }
            return used;
        }

        // ======== 各阶段效果 ========
        public static bool GodsandBuddhas1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 10) return false;

            string[] forbiddenTraits =
            {
                "GodsandBuddhas1","GodsandBuddhas2","GodsandBuddhas3","GodsandBuddhas4","GodsandBuddhas5",
                "GodsandBuddhas6","GodsandBuddhas7","GodsandBuddhas8","GodsandBuddhas9","GodsandBuddhas91",
                "GodsandBuddhas92","GodsandBuddhas93"
            };
            foreach (string trait in forbiddenTraits)
            {
                if (a.hasTrait(trait)) return false;
            }

            upTrait("特质", "GodsandBuddhas1", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "weak", "tiny", "short_sighted", "ugly", "fragile_health" },
                new string[] { "fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive" });
            UpdateXianSuffix(a, "GodsandBuddhas1");
            return true;
        }

        public static bool GodsandBuddhas2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 20) return false;

            a.ChangeIncenseandfire(-5);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.4;
            else if (a.hasTrait("Divinity2")) successRate = 0.5;
            else if (a.hasTrait("Divinity3")) successRate = 0.6;
            else if (a.hasTrait("Divinity4")) successRate = 0.7;
            else if (a.hasTrait("Divinity5")) successRate = 0.8;
            else if (a.hasTrait("Divinity6")) successRate = 0.9;
            else if (a.hasTrait("Divinity7")) successRate = 1;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas2", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas1" },
                new string[] { });
            UpdateXianSuffix(a, "GodsandBuddhas2");
            return true;
        }

        public static bool GodsandBuddhas3_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 50) return false;

            a.ChangeIncenseandfire(-12);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.3;
            else if (a.hasTrait("Divinity2")) successRate = 0.4;
            else if (a.hasTrait("Divinity3")) successRate = 0.5;
            else if (a.hasTrait("Divinity4")) successRate = 0.6;
            else if (a.hasTrait("Divinity5")) successRate = 0.7;
            else if (a.hasTrait("Divinity6")) successRate = 0.8;
            else if (a.hasTrait("Divinity7")) successRate = 0.9;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas3", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas2" },
                new string[] { });
            UpdateXianSuffix(a, "GodsandBuddhas3");
            return true;
        }

        public static bool GodsandBuddhas4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 100) return false;

            a.ChangeIncenseandfire(-25);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.2;
            else if (a.hasTrait("Divinity2")) successRate = 0.3;
            else if (a.hasTrait("Divinity3")) successRate = 0.4;
            else if (a.hasTrait("Divinity4")) successRate = 0.5;
            else if (a.hasTrait("Divinity5")) successRate = 0.6;
            else if (a.hasTrait("Divinity6")) successRate = 0.7;
            else if (a.hasTrait("Divinity7")) successRate = 0.8;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas4", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas3" },
                new string[] { });
            UpdateXianSuffix(a, "GodsandBuddhas4");

            bool hasAnyGodsgift =
                a.hasTrait("Godsgift1") ||
                a.hasTrait("Godsgift2") ||
                a.hasTrait("Godsgift3") ||
                a.hasTrait("Godsgift4") ||
                a.hasTrait("Godsgift5") ||
                a.hasTrait("Godsgift6") ||
                a.hasTrait("Godsgift7") ||
                a.hasTrait("Godsgift8") ||
                a.hasTrait("Godsgift9");

            string selectedTrait = null; // 初始化选中的特质变量

            if (!hasAnyGodsgift)
            {
                Dictionary<string, float> traitProbabilities = new Dictionary<string, float>
                {
                    {"Divinity6", 0.1f},
                    {"Divinity7", 1f},
                };

                Dictionary<string, string[]> traitMartialBodies = new Dictionary<string, string[]>
                {
                    {"Divinity6", new string[] {"Godsgift1", "Godsgift2", "Godsgift3", "Godsgift4", "Godsgift5", "Godsgift6", "Godsgift7", "Godsgift8", "Godsgift9"}},
                    {"Divinity7", new string[] {"Godsgift1", "Godsgift2", "Godsgift3", "Godsgift4", "Godsgift5", "Godsgift6", "Godsgift7", "Godsgift8", "Godsgift9"}},
                };

                // 检查角色拥有的每个特质
                foreach (var traitProb in traitProbabilities)
                {
                    string trait = traitProb.Key;
                    float probability = traitProb.Value;

                    // 如果角色拥有该特质且随机概率命中
                    if (a.hasTrait(trait) && UnityEngine.Random.Range(0f, 1f) < probability)
                    {
                        if (traitMartialBodies.TryGetValue(trait, out string[] availableBodies))
                        {
                            selectedTrait = availableBodies[UnityEngine.Random.Range(0, availableBodies.Length)];

                            // 添加选中的特质
                            a.addTrait(selectedTrait, false);

                            //标记为最爱
                            if (selectedTrait == "Godsgifty1" ||
                                selectedTrait == "Godsgifty2" ||
                                selectedTrait == "Godsgifty3" ||
                                selectedTrait == "Godsgifty4" ||
                                selectedTrait == "Godsgifty5" ||
                                selectedTrait == "Godsgifty6" ||
                                selectedTrait == "Godsgifty7" ||
                                selectedTrait == "Godsgifty8" ||
                                selectedTrait == "Godsgifty9")
                            {
                                a.data.favorite = true;
                            }

                            // 找到匹配特质后跳出循环，避免多次添加
                            break;
                        }
                    }
                }
            }
            return true;
        }

        public static bool GodsandBuddhas5_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 200) return false;

            a.ChangeIncenseandfire(-50);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.1;
            else if (a.hasTrait("Divinity2")) successRate = 0.2;
            else if (a.hasTrait("Divinity3")) successRate = 0.3;
            else if (a.hasTrait("Divinity4")) successRate = 0.4;
            else if (a.hasTrait("Divinity5")) successRate = 0.5;
            else if (a.hasTrait("Divinity6")) successRate = 0.6;
            else if (a.hasTrait("Divinity7")) successRate = 0.7;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            string[] additionalTraits = { "Taoisthoa21", "Taoisthoa22", "Taoisthoa23", "Taoisthoa24" };
            string randomTrait = GetNewRandomTrait(additionalTraits);

            upTrait("特质", "GodsandBuddhas5", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas4" },
                new string[] { randomTrait });
            UpdateXianSuffix(a, "GodsandBuddhas5");
            return true;
        }

        public static bool GodsandBuddhas6_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 500) return false;

            a.ChangeIncenseandfire(-125);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.5;
            else if (a.hasTrait("Divinity2")) successRate = 0.1;
            else if (a.hasTrait("Divinity3")) successRate = 0.2;
            else if (a.hasTrait("Divinity4")) successRate = 0.3;
            else if (a.hasTrait("Divinity5")) successRate = 0.4;
            else if (a.hasTrait("Divinity6")) successRate = 0.5;
            else if (a.hasTrait("Divinity7")) successRate = 0.6;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            string[] additionalTraits = { "Taoisthoa31", "Taoisthoa32", "Taoisthoa33" };
            string randomTrait = GetNewRandomTrait(additionalTraits);

            upTrait("特质", "GodsandBuddhas6", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas5" },
                new string[] { randomTrait });
            UpdateXianSuffix(a, "GodsandBuddhas6");
            return true;
        }

        public static bool GodsandBuddhas7_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 1000) return false;

            a.ChangeIncenseandfire(-250);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.02;
            else if (a.hasTrait("Divinity2")) successRate = 0.05;
            else if (a.hasTrait("Divinity3")) successRate = 0.1;
            else if (a.hasTrait("Divinity4")) successRate = 0.2;
            else if (a.hasTrait("Divinity5")) successRate = 0.3;
            else if (a.hasTrait("Divinity6")) successRate = 0.4;
            else if (a.hasTrait("Divinity7")) successRate = 0.5;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas7", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas6" },
                new string[] { "特质" });
            UpdateXianSuffix(a, "GodsandBuddhas7");
            return true;
        }

        public static bool GodsandBuddhas8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 2000) return false;

            a.ChangeIncenseandfire(-500);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.01;
            else if (a.hasTrait("Divinity2")) successRate = 0.02;
            else if (a.hasTrait("Divinity3")) successRate = 0.05;
            else if (a.hasTrait("Divinity4")) successRate = 0.1;
            else if (a.hasTrait("Divinity5")) successRate = 0.2;
            else if (a.hasTrait("Divinity6")) successRate = 0.3;
            else if (a.hasTrait("Divinity7")) successRate = 0.4;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas8", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas7" },
                new string[] { "特质" });
            UpdateXianSuffix(a, "GodsandBuddhas8");
            return true;
        }

        public static bool GodsandBuddhas9_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;

            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 5000) return false;

            // 92：即便没有 HolyTruth 空位也可晋升；仅在可用时尝试授予
            bool actorAlreadyHasHolyTruth = s_HolyTruthTraits.Any(t => a.hasTrait(t));

            a.ChangeIncenseandfire(-1250);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.005;
            else if (a.hasTrait("Divinity2")) successRate = 0.01;
            else if (a.hasTrait("Divinity3")) successRate = 0.02;
            else if (a.hasTrait("Divinity4")) successRate = 0.05;
            else if (a.hasTrait("Divinity5")) successRate = 0.1;
            else if (a.hasTrait("Divinity6")) successRate = 0.2;
            else if (a.hasTrait("Divinity7")) successRate = 0.3;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            string randomHolyTruthTraitToAdd = null;
            if (!actorAlreadyHasHolyTruth)
            {
                var used = GetGloballyUsedHolyTruthTraits();
                var available = s_HolyTruthTraits.Where(t => !used.Contains(t)).ToArray();
                if (available.Length > 0)
                {
                    randomHolyTruthTraitToAdd = available[UnityEngine.Random.Range(0, available.Length)];
                }
                // 没空位则不添加，但仍晋升
            }
            pTarget.a.data.favorite = true;

            upTrait("特质", "GodsandBuddhas9", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas8" },
                randomHolyTruthTraitToAdd == null ? Array.Empty<string>() : new string[] { randomHolyTruthTraitToAdd });

            UpdateXianSuffix(a, "GodsandBuddhas9");
            ApplyXianTitle(a, "GodsandBuddhas9");
            return true;
        }

        public static bool GodsandBuddhas91_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 10000) return false;
            if (a.GetBelievers() <= 100) return false;

            a.ChangeIncenseandfire(-2500);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.002;
            else if (a.hasTrait("Divinity2")) successRate = 0.005;
            else if (a.hasTrait("Divinity3")) successRate = 0.01;
            else if (a.hasTrait("Divinity4")) successRate = 0.02;
            else if (a.hasTrait("Divinity5")) successRate = 0.05;
            else if (a.hasTrait("Divinity6")) successRate = 0.1;
            else if (a.hasTrait("Divinity7")) successRate = 0.2;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas91", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas9" },
                new string[] { "特质" });
            UpdateXianSuffix(a, "GodsandBuddhas91");
            ApplyXianTitle(a, "GodsandBuddhas91");

            if (!a.hasTrait("Godsgift1") &&
               !a.hasTrait("Divinity7") &&
               Randy.randomChance(0.25f))
            {
                a.addTrait("Divinity92", false);
            }
            return true;
        }

        public static bool GodsandBuddhas92_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;
            if (a.GetIncenseandfire() <= 20000) return false;
            if (a.GetBelievers() <= 500) return false;

            a.ChangeIncenseandfire(-2500);
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.001;
            else if (a.hasTrait("Divinity2")) successRate = 0.002;
            else if (a.hasTrait("Divinity3")) successRate = 0.005;
            else if (a.hasTrait("Divinity4")) successRate = 0.01;
            else if (a.hasTrait("Divinity5")) successRate = 0.02;
            else if (a.hasTrait("Divinity6")) successRate = 0.05;
            else if (a.hasTrait("Divinity7")) successRate = 0.1;

            // 检查是否拥有武道六难特质，如果有则成功率减半
            string[] martialDifficulties = { "Divinity92" };
            foreach (string difficulty in martialDifficulties)
            {
                if (a.hasTrait(difficulty))
                {
                    successRate /= 2;
                    break;
                }
            }

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            upTrait("特质", "GodsandBuddhas92", a,
                new string[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness", "GodsandBuddhas91", "Divinity92" },
                new string[] { "特质" });
            UpdateXianSuffix(a, "GodsandBuddhas92");
            ApplyXianTitle(a, "GodsandBuddhas92");

            return true;
        }

        // 只保留最终境界（唯一席位）
        private const string FinalStageTrait = "GodsandBuddhas93";

        // 缓存唯一 94 持有人
        private static Actor s_FinalStageOwner = null;
        private static bool s_FinalStageOwnerScannedOnce = false;

        // 一次性扫描已有的 94
        private static void EnsureFinalOwnerCachedOnce()
        {
            if (s_FinalStageOwnerScannedOnce) return;
            s_FinalStageOwnerScannedOnce = true;

            var list = MapBox.instance.units?.getSimpleList();
            if (list == null) return;

            for (int i = 0; i < list.Count; i++)
            {
                var u = list[i];
                if (u != null && u.isAlive() && u.hasTrait(FinalStageTrait))
                {
                    s_FinalStageOwner = u;
                    break;
                }
            }
        }

        // O(1) 维护缓存
        private static void MaintainFinalOwner()
        {
            if (s_FinalStageOwner == null) return;
            if (!s_FinalStageOwner.isAlive() || !s_FinalStageOwner.hasTrait(FinalStageTrait))
                s_FinalStageOwner = null;
        }

        // 94 席位是否可用（空位或自己）
        private static bool IsFinalStageAvailableFor(Actor requester)
        {
            EnsureFinalOwnerCachedOnce();
            MaintainFinalOwner();
            return s_FinalStageOwner == null || s_FinalStageOwner == requester;
        }

        // 设置 94 持有人
        private static void SetFinalStageOwner(Actor owner)
        {
            s_FinalStageOwner = owner;
            s_FinalStageOwnerScannedOnce = true;
        }

        public static bool GodsandBuddhas93_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor()) return false;
            Actor a = pTarget.a;

            if (a.hasTrait(FinalStageTrait)) return false;

            // 感悟门槛：10 万
            if (a.GetIncenseandfire() <= 10) return false;

            a.ChangeIncenseandfire(-25000);

            // 突破成功率（保持你原来的 Insight 阶梯）
            double successRate = 1;
            if (a.hasTrait("Godsgift1")) successRate = 1;
            else if (a.hasTrait("Divinity1")) successRate = 0.0005;
            else if (a.hasTrait("Divinity2")) successRate = 0.001;
            else if (a.hasTrait("Divinity3")) successRate = 0.002;
            else if (a.hasTrait("Divinity4")) successRate = 0.005;
            else if (a.hasTrait("Divinity5")) successRate = 0.01;
            else if (a.hasTrait("Divinity6")) successRate = 0.02;
            else if (a.hasTrait("Divinity7")) successRate = 0.05;

            if (UnityEngine.Random.Range(0f, 1f) > successRate) return false;

            // 仅看 94 唯一席位
            if (!IsFinalStageAvailableFor(a)) return false;

            // 晋升为 94（移除 92，顺带清理負面）
            try { UpdateXianSuffix(a, FinalStageTrait); } catch { /* 没有该方法可忽略 */ }

            // 若你有 upTrait，可用它；否则用 add/remove
            try
            {
                upTrait("SwordImmortal92", FinalStageTrait, a,
                    new[] { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" },
                    null);
            }
            catch
            {
                a.removeTrait("SwordImmortal92");
                a.addTrait(FinalStageTrait);
                // 负面清理可选
                string[] negatives = { "tumorInfection", "cursed", "infected", "mushSpores", "plague", "madness" };
                for (int i = 0; i < negatives.Length; i++) if (a.hasTrait(negatives[i])) a.removeTrait(negatives[i]);
            }
            ApplyXianTitle(a, "GodsandBuddhas93");
            SetFinalStageOwner(a);

            // 初始化newName为当前名称
            string currentName = a.getName();
            string newName = currentName;

            PlayWavDirectly.Instance.PlaySoundFromFile(PeerlessThedayofGodswrathClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
            // 随机选择一条提示信息
            System.Random random = new System.Random();
            int index = random.Next(grade91Tips.Count);
            string tip = grade91Tips[index];

            // 如果提示信息中包含占位符（比如 {0}），则替换为角色的名称
            if (tip.Contains("{0}"))
            {
                tip = string.Format(tip, newName);
            }

            // 显示随机选择的提示信息
            ActionLibrary.showWhisperTip(tip);
            return true;
        }

        private static readonly List<string> grade91Tips = new List<string>
        {
            "「曾有万千神祇如萤火游荡，在虚妄的殿堂编织法则的罗网。而今钟摆停在第十一重震颤——所有冠冕皆成尘烟中飘散的谎。\n看那凡人脱下血肉的旧裳，荆棘王冠在祂眉间化作白金光环。河流逆向奔赴发光的穹顶，群星成为祂指尖迟延的砝码。\n从此时间只是祂掌心的纹脉；生死簿上再无墨迹 只映照祂双眼的深渊。诸界沉入祂呼吸的潮汐，万物在祂真名中重塑形貌——祂是初 亦是终。\n无需圣歌队颂唱，因风声已浸透祂的尊号。不必筑通天高塔，每一级阶梯皆是祂垂落的思绪。\n让旧纪元的香火熄灭吧：祂从祭坛起身 撕下经卷的封条，以沉默宣告独一权的降临——「{0}」",
        };

        public static bool damage_GodsandBuddhas6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.1f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas7(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.13f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.15f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas9(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.2f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas91(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.3f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas92(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;
                if (!targetActor.hasHealth())
                    return false;
                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.4f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool damage_GodsandBuddhas93(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;

                // 目标已死亡则不再处理
                if (!targetActor.hasHealth())
                    return false;

                float attackDamage = attacker.stats["damage"];
                int trueDamage = (int)(attackDamage * 0.5f);
                if (trueDamage > 0 && targetActor.data.health > 0)
                {
                    int hpBefore = targetActor.data.health;
                    int actualDamage = Mathf.Min(trueDamage, hpBefore);

                    // 至少造成 1 点伤害；且不让生命值变成负数
                    int finalDmg = Mathf.Max(1, actualDamage);
                    targetActor.changeHealth(-finalDmg);

                    // 0血死亡：生命值降到 0 时，立刻进入死亡流程
                    if (!targetActor.hasHealth())
                    {
                        targetActor.batch.c_check_deaths.Add(targetActor);
                        targetActor.checkCallbacksOnDeath();
                    }
                }
            }
            return false;
        }

        public static bool GodsandBuddhas1_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas2_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(2);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas3_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(5);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas4_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas5_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(50);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas6_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas7_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(500);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas8_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas9_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(5000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas91_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas92_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(50000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            return true;
        }

        public static bool GodsandBuddhas93_effect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
                return true;

            Actor actor = pTarget.a;
            if (actor == null || !actor.hasHealth())
                return true;
            int maxHP = actor.getMaxHealth();
            int curHP = actor.data.health;
            if (curHP >= maxHP)
                return true;
            float healPercent = 1f;
            if (healPercent > 1f) healPercent *= 1f;
            if (healPercent <= 0f) return true;
            int healAmount = Mathf.CeilToInt(maxHP * healPercent);
            healAmount = Mathf.Clamp(healAmount, 1, maxHP - curHP);
            int before = curHP;
            actor.restoreHealth(healAmount);
            if (actor.data.health > before)
                actor.spawnParticle(Toolbox.color_heal);

            return true;
        }

        public static bool Godsgift4_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
                return true;

            Actor actor = pTarget.a;
            if (actor == null || !actor.hasHealth())
                return true;
            int maxHP = actor.getMaxHealth();
            int curHP = actor.data.health;
            if (curHP >= maxHP)
                return true;
            float healPercent = 1f;
            if (healPercent > 1f) healPercent *= 1f;
            if (healPercent <= 0f) return true;
            int healAmount = Mathf.CeilToInt(maxHP * healPercent);
            healAmount = Mathf.Clamp(healAmount, 1, maxHP - curHP);
            int before = curHP;
            actor.restoreHealth(healAmount);
            if (actor.data.health > before)
                actor.spawnParticle(Toolbox.color_heal);

            return true;
        }

        private static float s_windowStartTime = 0f; // 本窗口起始时间（秒）
        private static int s_triggerCount = 0;       // 本窗口已触发次数

        public static bool attack_Godsgift6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 每秒最多 10 次（固定 1 秒窗口）
            float now = Time.time;
            if (now - s_windowStartTime >= 1f) { s_windowStartTime = now; s_triggerCount = 0; }
            if (s_triggerCount >= 10) return false;
            s_triggerCount++;

            if (pTarget != null && pSelf != null)
            {
                // 确保pSelf是Actor类型
                if (pSelf.isActor())
                {
                    Actor attacker = pSelf.a;
                    Vector2Int pos = pTile.pos;
                    float pDist = Vector2.Distance(pTarget.current_position, pos);
                    Vector3 newPoint = Toolbox.getNewPoint(pSelf.current_position.x, pSelf.current_position.y, (float)pos.x, (float)pos.y, pDist, true);
                    Vector3 newPoint2 = Toolbox.getNewPoint(pTarget.current_position.x, pTarget.current_position.y, (float)pos.x, (float)pos.y, pTarget.a.stats["size"], true);

                    // 创建一个自定义的kill action来确保应用攻击者的伤害
                    Action customKillAction = () =>
                    {
                        if (pTarget.isAlive())
                        {
                            // 应用攻击者的伤害到目标
                            float damage = attacker.stats["damage"] + Randy.randomFloat(0f, attacker.stats["damage"] * 1f);
                            pTarget.getHit(damage, false, AttackType.Weapon, pSelf, false, false, true);
                        }
                    };

                    // 使用带有自定义kill action的spawn方法
                    World.world.projectiles.spawn(pSelf, pTarget, "fx_wind_trail_t", newPoint, newPoint2, 0f, 0.25f, customKillAction);
                    return true;
                }
            }
            return false;
        }

        // ======== 其它赠礼/效果 ========
        public static bool attack_HolyTruth1(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (UnityEngine.Random.value < 0.1f)
            {
                pSelf.a.addStatusEffect("Invincible", 5f); //二环•岩石护壁
            }
            return true;
        }

        public static bool attack_HolyTruth2(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pSelf == null || pTarget == null) return false;
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            var attacker = pSelf.a;
            var target = pTarget.a;

            // 以攻击者的伤害属性作为回血基数
            float baseDamage = 0f;
            try
            {
                baseDamage = attacker.stats != null ? attacker.stats["damage"] : 0f;
            }
            catch
            {
                baseDamage = 0f;
            }

            // 可调回血系数
            const float HealFactor = 1f;

            // 随机波动（可选）；这里给到 0% 的上浮
            float variance = Randy.randomFloat(0f, baseDamage * 0f);

            float healAmountFloat = Mathf.Max(1f, baseDamage * HealFactor + variance);
            int healAmount = Mathf.RoundToInt(healAmountFloat);

            if (target.data.health < target.getMaxHealth())
            {
                target.restoreHealth(healAmount);
                target.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_HolyTruth4(BaseSimObject pSelf, BaseSimObject pAttackedBy, WorldTile pTile)
        {
            if (pAttackedBy != null && pSelf.isActor() && pAttackedBy.isActor())
            {
                Actor Self = pSelf.a;
                pAttackedBy.a.getHit(Self.stats["damage"] / 1f, true, AttackType.Weapon, Self, false, false);
            }
            return true;
        }

        // 转换后授予给“转换者”的特质列表（自行填入真实特质ID）
        private static readonly string[] GrantedTraitsHolyTruth5 = {
            "GuardianDharma7","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };


        public static bool attack_HolyTruth5(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 1f) return false;

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsHolyTruth5 != null)
            {
                for (int i = 0; i < GrantedTraitsHolyTruth5.Length; i++)
                {
                    string traitId = GrantedTraitsHolyTruth5[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool attack_HolyTruth6(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;

                if (Randy.randomChance(0.1f))
                {
                    float attackDamage = attacker.stats["damage"];
                    int trueDamage = (int)(attackDamage * 3f);
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int hpBefore = targetActor.data.health;
                        int actualDamage = Mathf.Min(trueDamage, hpBefore);
                        int finalDmg = Mathf.Max(1, actualDamage);
                        targetActor.changeHealth(-finalDmg);
                        if (!targetActor.hasHealth())
                        {
                            targetActor.batch.c_check_deaths.Add(targetActor);
                            targetActor.checkCallbacksOnDeath();
                        }
                    }
                }
            }
            return false;
        }



        public static bool attack_HolyTruth7(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null && pTarget.isActor() && pSelf.isActor())
            {
                Actor attacker = pSelf.a;
                Actor targetActor = pTarget.a;

                if (Randy.randomChance(0.01f))
                {
                    float attackDamage = attacker.stats["health"];
                    int trueDamage = (int)(attackDamage * 3f);
                    if (trueDamage > 0 && targetActor.data.health > 0)
                    {
                        int hpBefore = targetActor.data.health;
                        int actualDamage = Mathf.Min(trueDamage, hpBefore);
                        int finalDmg = Mathf.Max(1, actualDamage);
                        targetActor.changeHealth(-finalDmg);
                        if (!targetActor.hasHealth())
                        {
                            targetActor.batch.c_check_deaths.Add(targetActor);
                            targetActor.checkCallbacksOnDeath();
                        }
                    }
                }
            }
            return false;
        }

        // 传送冷却记录：每个单位 60 秒一次
        private static readonly Dictionary<Actor, float> s_ResurrectionCD = new Dictionary<Actor, float>();

        public static bool HolyTruth8_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor() || !pTarget.isAlive())
                return false;

            Actor actor = pTarget.a;
            if (actor == null) return false;

            float maxHP = actor.getMaxHealth();
            if (maxHP <= 0f) return false;

            // 仅当血量低于 50% 时触发
            if (actor.data.health >= maxHP * 0.5f)
                return false;

            // 冷却判定：60 秒
            const float CD = 60f;
            float now = Time.time;
            if (s_ResurrectionCD.TryGetValue(actor, out float lastTime))
            {
                if (now - lastTime < CD)
                    return false;
            }

            // 执行传送
            bool ok = teleportRandom(actor);
            if (ok)
            {
                s_ResurrectionCD[actor] = now;
            }
            return ok;
        }
        public static bool teleportRandom(Actor a)
        {
            MapBox mapBox = World.world as MapBox;
            if (mapBox == null)
            {
                return false;
            }

            CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
            if (citiesManager == null)
            {
                return false;
            }
            // 优先传送至首都
            City originalCity = citiesManager.list.FirstOrDefault(city =>
                city.kingdom == a.kingdom &&
                city.isCapitalCity() &&
                city.isAlive()
            );
            WorldTile targetTile = null;
            // 优先传送至首都
            if (originalCity != null)
            {
                targetTile = originalCity.getTile();
            }
            else // 次选随机王国存活城市
            {
                List<City> kingdomCities = citiesManager.list
                    .Where(city =>
                        city.kingdom == a.kingdom &&
                        city.isAlive())
                    .ToList();

                if (kingdomCities.Count == 0)
                {
                    return false;
                }

                int randomIndex = UnityEngine.Random.Range(0, kingdomCities.Count);
                targetTile = kingdomCities[randomIndex].getTile();
            }

            if (targetTile == null || targetTile.Type.block || !targetTile.Type.ground)
            {
                return false;
            }

            a.cancelAllBeh();
            a.spawnOn(targetTile, 0f);
            return true;
        }

        public static readonly Dictionary<Actor, Actor> listOfTamedBeasts = new Dictionary<Actor, Actor>();
        private const string KeyBeliefMasterName = "belief_master_name"; // 存“信仰来源”的 key
        private const string KeyMasterId = "master_id";

        // 确保这是 public，避免 CS0122
        public static string TryGetBeliefMasterName(Actor a)
        {
            if (a == null) return null;

            string name = null;
            try
            {
                // 优先从 data 里取
                var t = a.data.GetType();
                var m = t.GetMethod("getString", new[] { typeof(string), typeof(string) });
                if (m != null)
                {
                    name = m.Invoke(a.data, new object[] { "belief_master_name", null }) as string;
                }
                else
                {
                    m = t.GetMethod("getString", new[] { typeof(string) });
                    if (m != null)
                    {
                        name = m.Invoke(a.data, new object[] { "belief_master_name" }) as string;
                    }
                    else
                    {
                        m = t.GetMethod("get", new[] { typeof(string) });
                        if (m != null)
                        {
                            var obj = m.Invoke(a.data, new object[] { "belief_master_name" });
                            if (obj != null) name = obj.ToString();
                        }
                    }
                }
            }
            catch { }

            // 兜底：从驯服映射取 master 名字
            if (string.IsNullOrEmpty(name))
            {
                if (listOfTamedBeasts != null && listOfTamedBeasts.TryGetValue(a, out var master) && master != null && master.isAlive())
                    name = master.getName();
            }

            return name;
        }

        // 新增：统计某个“转换者”的信徒数量（基于 listOfTamedBeasts）
        public static int CountBelieversOf(Actor master)
        {
            if (master == null) return 0;
            int cnt = 0;
            foreach (var kv in listOfTamedBeasts)
            {
                var follower = kv.Key;
                var m = kv.Value;
                if (m == master && follower != null && follower.isAlive())
                    cnt++;
            }
            return cnt;
        }

        // 转换后给予的特质
        private static readonly string[] GrantedTraitsAfterConvert7 = {
            "GuardianDharma1","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };

        public static bool attack_GodsandBuddhas7(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 0.3f) return false; // 目标血量不低于30%则返回

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas6","GodsandBuddhas7", "GodsandBuddhas8", "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert7 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert7.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert7[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        // 转换后给予的特质
        private static readonly string[] GrantedTraitsAfterConvert8 = {
            "GuardianDharma2","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };

        public static bool attack_GodsandBuddhas8(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 0.4f) return false; // 目标血量不低于40%则返回

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas7", "GodsandBuddhas8", "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert8 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert8.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert8[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        // 转换后给予的特质
        private static readonly string[] GrantedTraitsAfterConvert9 = {
            "GuardianDharma3","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };

        public static bool attack_GodsandBuddhas9(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 0.5f) return false; // 目标血量不低于50%则返回

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas8", "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert9 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert9.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert9[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }


        // 转换后授予给“转换者”的特质列表（自行填入真实特质ID）
        private static readonly string[] GrantedTraitsAfterConvert91 = {
            "GuardianDharma4","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };


        public static bool attack_GodsandBuddhas91(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 0.6f) return false; // 目标血量不低于60%则返回

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert91 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert91.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert91[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        // 转换后授予给“转换者”的特质列表（自行填入真实特质ID）
        private static readonly string[] GrantedTraitsAfterConvert92 = {
            "GuardianDharma5","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };


        public static bool attack_GodsandBuddhas92(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 0.7f) return false; // 目标血量不低于70%则返回

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert92 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert92.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert92[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        // 转换后授予给“转换者”的特质列表（自行填入真实特质ID）
        private static readonly string[] GrantedTraitsAfterConvert93 = {
            "GuardianDharma6","fire_proof", "tough", "immune", "freeze_proof", "strong_minded", "attractive"
        };


        public static bool attack_GodsandBuddhas93(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            // 基础空值检查
            if (pSelf == null || pTarget == null) return false;

            // 检查双方是否都是Actor对象
            if (!pSelf.isActor() || !pTarget.isActor()) return false;

            // 获取双方的Actor组件并检查是否存活
            Actor selfActor = pSelf.a;
            Actor targetActor = pTarget.a;
            if (!selfActor.isAlive() || !targetActor.isAlive()) return false;

            float maxHP = targetActor.getMaxHealth();
            if (maxHP <= 0f) return false; // 确保最大生命值有效
            if (targetActor.data.health >= maxHP * 1f) return false;

            // 条件2：目标不含禁止被转换的特质
            string[] protectedTraits = {
                "GuardianDharma1","GuardianDharma2","GuardianDharma3","GuardianDharma4","GuardianDharma5","GuardianDharma6","GuardianDharma7",
                "GodsandBuddhas9",
                "GodsandBuddhas91", "GodsandBuddhas92", "GodsandBuddhas93"
            };

            // 检查目标是否拥有任何受保护的特质
            for (int i = 0; i < protectedTraits.Length; i++)
            {
                string t = protectedTraits[i];
                if (!string.IsNullOrEmpty(t) && targetActor.hasTrait(t))
                    return false; // 如果目标有受保护特质，则转换失败
            }

            // 条件3：攻击者不含某些禁止转换的特质
            string[] protectedTraits2 = {
                "HolyTruth5"
            };

            for (int i = 0; i < protectedTraits2.Length; i++)
            {
                string t = protectedTraits2[i];
                if (!string.IsNullOrEmpty(t) && selfActor.hasTrait(t))
                    return false;
            }

            // 执行转换（目标 加入 攻击者的王国）
            targetActor.setProfession(UnitProfession.Unit); // 设置为普通单位职业
            targetActor.forgetKingdomAndCity(); // 忘记原来的王国和城市
            targetActor.joinKingdom(selfActor.kingdom); // 加入攻击者的王国

            selfActor.ChangeBelievers(+1);

            // 保存主人信息
            targetActor.data.set(KeyMasterId, selfActor.data.id);

            // 不再改名
            // targetActor.data.setName($"{selfActor.getName()} 的护法");

            // 在数据中记录“信仰来源”（转换者名字）
            targetActor.data.set(KeyBeliefMasterName, selfActor.getName());

            // 让目标移动到攻击者所在的位置
            targetActor.goTo(pSelf.current_tile);

            listOfTamedBeasts[targetActor] = selfActor;

            // 转换后：给予特质（给 目标）
            if (GrantedTraitsAfterConvert93 != null)
            {
                for (int i = 0; i < GrantedTraitsAfterConvert93.Length; i++)
                {
                    string traitId = GrantedTraitsAfterConvert93[i];
                    if (!string.IsNullOrEmpty(traitId) && !targetActor.hasTrait(traitId))
                        targetActor.addTrait(traitId);
                }
            }

            // 转换后：回满血（目标）
            int heal = targetActor.getMaxHealth() - targetActor.data.health;
            if (heal > 0)
            {
                targetActor.restoreHealth(heal);
                targetActor.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        private static void AlignBeastToMasterKingdom(Actor beast, Actor master)
        {
            if (beast == null || master == null || !beast.isAlive() || !master.isAlive()) return;

            var targetKingdom = master.kingdom;
            try
            {
                if (targetKingdom == null)
                {
                    // 主人无阵营，则让护法也无阵营
                    if (beast.kingdom != null)
                        beast.forgetKingdomAndCity();
                }
                else if (beast.kingdom != targetKingdom)
                {
                    // 切换到主人的阵营
                    beast.forgetKingdomAndCity();
                    beast.joinKingdom(targetKingdom);
                }
            }
            catch { /* ignore */ }
        }

        public static bool tamedBeastSpecialEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || pTarget.a == null || !pTarget.a.isAlive())
                return false;

            Actor beast = pTarget.a;

            // 情况1：已在映射
            if (listOfTamedBeasts != null && listOfTamedBeasts.TryGetValue(beast, out Actor master))
            {
                if (master == null || !master.isAlive())
                {
                    return KillBeast_UseGetHitDeathFlow(beast);
                }

                // 同步阵营（关键改动）
                AlignBeastToMasterKingdom(beast, master);

                // 原有“偶尔跟随主人”逻辑
                if (Randy.randomChance(0.09f))
                {
                    if (master.current_tile != null)
                        beast.goTo(master.current_tile);
                    return true;
                }
                return false;
            }

            // 情况2：未在映射，但有 master_id（兜底重建/判死）
            if (beast.data?.custom_data_long != null &&
                beast.data.custom_data_long.TryGetValue(KeyMasterId, out long masterId)) // 注意：统一使用 KeyMasterId
            {
                Actor m = null;
                try { m = World.world?.units?.get(masterId); } catch { m = null; }

                if (m == null || !m.isAlive())
                {
                    return KillBeast_UseGetHitDeathFlow(beast);
                }

                // 主人活着：回填映射、对齐势力（关键改动：用 API 不是直接赋值）
                try { listOfTamedBeasts[beast] = m; } catch { }
                AlignBeastToMasterKingdom(beast, m);
                return true;
            }

            return false;
        }

        // 单体护法处死：同 getHit 的死亡流程
        private static bool KillBeast_UseGetHitDeathFlow(Actor beast)
        {
            if (beast == null || !beast.isAlive()) return false;

            try { listOfTamedBeasts?.Remove(beast); } catch { }
            try { beast.data?.custom_data_long?.Remove("master_id"); } catch { }

            try
            {
                beast.changeHealth(-Mathf.Max(1, beast.data.health));
                beast.timer_action = 0.002f;

                bool dead = !beast.hasHealth();
                if (dead) beast.batch.c_check_deaths.Add(beast);

                beast.checkCallbacksOnDeath();
            }
            catch { }
            return true;
        }

        public static bool SSS_Collection(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a != null)
            {
                string actorName = pTarget.a.getName();
                if (!actorName.Contains("先天神"))
                {
                    if (!actorTipsShown.ContainsKey(pTarget.a))
                    {
                        actorTipsShown[pTarget.a] = (false, false); // 初始化状态
                    }

                    var tipsShown = actorTipsShown[pTarget.a];
                    if (!tipsShown.hasShownSSSTip)
                    {
                        pTarget.a.data.favorite = true;
                        PlayWavDirectly.Instance.PlaySoundFromFile(PeerlessThedayofGodswrathClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
                        ActionLibrary.showWhisperTip("NewSSS");
                        pTarget.a.data.setName(pTarget.a.getName() + " 先天神");
                        actorTipsShown[pTarget.a] = (tipsShown.hasShownSSTip, true); // 更新状态
                        return true;
                    }
                    return false;
                }
            }
            return false;
        }
        private static Dictionary<Actor, (bool hasShownSSTip, bool hasShownSSSTip)> actorTipsShown = new Dictionary<Actor, (bool, bool)>();
    }
}