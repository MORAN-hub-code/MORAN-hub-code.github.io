using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using System;
using System.Collections.Generic;
using ai;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using ai.behaviours;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using AttributeExpansion.code.utils;
using System.Text;
using System.Reflection;
using ReflectionUtility;
using System.IO;
using AttributeExpansion.code.window;
using AttributeExpansion.code;

namespace PeerlessThedayofGodswrath.code
{
    internal class Upgradethesystem
    {
        public static bool window_creature_info_initialized;
        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive()) return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                WindowCreatureInfoPatchHelper.Initialize(__instance);
            }

            //WindowCreatureInfoPatchHelper.OnEnable(__instance, __instance.actor);
        }
        [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
        private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
        {
            var actor = __instance.actor;
            if (actor == null || !actor.isAlive()) return;
            __instance.setIconValue("Incenseandfire", actor.GetIncenseandfire());
            __instance.setIconValue("Believers", actor.GetBelievers());
        }

        [Hotfixable]
        [HarmonyPrefix, HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void OnEnable_prefix(UnitWindow __instance)
        {
            if (!(__instance.actor?.isAlive() ?? false)) return;

            var bg = __instance.transform.Find("Background");
            if (bg == null) return;

            // 旧的单行控件清理（防止残留）
            var old = bg.Find("TempInfo");
            if (old != null) UnityEngine.Object.Destroy(old.gameObject);

            // 两个独立的文本行
            var faithText = GetOrCreateText(bg, "TempInfoFaith", new Vector3(230f, 100f, 0f));
            var believersText = GetOrCreateText(bg, "TempInfoBelievers", new Vector3(230f, 85f, 0f));

            var actor = __instance.actor;

            // 1) 信仰（跟随者看到转换者名字）
            traitAction.listOfTamedBeasts.TryGetValue(actor, out var master);
            string beliefName = master != null ? master.getName() : null;
            faithText.text = $"信仰: {(string.IsNullOrEmpty(beliefName) ? "无" : beliefName)}";

            // 2) 信徒（只在“转换者”的窗口显示）
            int believersCount = 0;
            foreach (var kv in traitAction.listOfTamedBeasts)
            {
                var follower = kv.Key;
                var m = kv.Value;
                if (m == actor && follower != null && follower.isAlive())
                    believersCount++;
            }

            if (believersCount > 0)
            {
                believersText.gameObject.SetActive(true);
                believersText.text = $"信徒: {believersCount}";
            }
            else
            {
                // 没有信徒时，不显示该行（只在转换者那里显示）
                believersText.gameObject.SetActive(false);
            }
        }

        private static Text GetOrCreateText(Transform parent, string name, Vector3 localPos)
        {
            var node = parent.Find(name);
            if (node != null)
                return node.GetComponent<Text>();

            var obj = new GameObject(name, typeof(Text), typeof(ContentSizeFitter));
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = localPos;
            obj.transform.localScale = Vector3.one;

            var text = obj.GetComponent<Text>();
            text.font = LocalizedTextManager.current_font;
            text.alignment = TextAnchor.UpperLeft;
            text.color = Color.white;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 1;
            text.resizeTextMaxSize = 8;

            var fitter = obj.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            return text;
        }
    }
}