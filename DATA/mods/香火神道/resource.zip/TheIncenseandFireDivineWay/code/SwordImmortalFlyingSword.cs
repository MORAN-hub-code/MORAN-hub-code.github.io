using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace PeerlessThedayofGodswrath.code
{
    internal class SwordImmortalFlyingSword
    {
        public static void Init()
        {
            AssetManager.projectiles.add(new ProjectileAsset
            {
                id = "fx_wind_trail_t", // 新ID
                speed = 20f, // 原版arrow速度
                speed_random = 3f, // 速度随机值
                texture = "fx_wind_trail_t", // 你的贴图名（需放在effects/projectiles/thesword.png）
                texture_shadow = "shadows/projectiles/shadow_arrow", // 原版箭影子
                sound_launch = "event:/SFX/WEAPONS/WeaponStartArrow", // 原版箭发射音效
                sound_impact = "event:/SFX/HIT/HitGeneric", // 原版箭命中音效
                scale_start = 0.1f, // 初始缩放
                scale_target = 0.1f, // 目标缩放
                can_be_left_on_ground = false, // 命中后可留在地面
                can_be_blocked = false, // 可被格挡
                animated = true, // 启用动画
                animation_speed = 8f, // 动画速度
                look_at_target = true, // 朝向目标
                can_be_collided = false, // 可被碰撞
            });
        }
    }
}