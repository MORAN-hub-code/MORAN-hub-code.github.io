﻿using UnityEngine;

namespace AttributeExpansion.code.utils
{
    public static class ActorExtensions
    {
    private const string Incenseandfire_key = "wushu.IncenseandfireNum";
    private const string Believers_key = "wushu.BelieversNum";
    private const string nirvana_key = "wushu.nirvanaNum";
    private const string Eternalreincarnation_key = "wushu.EternalreincarnationNum";
    private const string Willpower_key = "wushu.Willpower";
    private const string magicDefense_key = "wushu.magicDefense";
    public static float GetWillpower(this Actor actor)
    {
        actor.data.get(Willpower_key, out float val, 0);
        return val;
    }

    public static void SetWillpower(this Actor actor, float val)
    {
        actor.data.set(Willpower_key, val);
    }

    public static void ChangeWillpower(this Actor actor, float delta)
    {
        actor.data.get(Willpower_key, out float val, 0);
        val += delta;
        actor.data.set(Willpower_key, Mathf.Max(0, val));
    }

    public static float GetMagicDefense(this Actor actor)
    {
        actor.data.get(magicDefense_key, out float val, 0);
        return val;
    }

    public static void SetMagicDefense(this Actor actor, float val)
    {
        actor.data.set(magicDefense_key, val);
    }

    public static void ChangeMagicDefense(this Actor actor, float delta)
    {
        actor.data.get(magicDefense_key, out float val, 0);
        val += delta;
        actor.data.set(magicDefense_key, Mathf.Max(0, val));
    }
    public static float GetEternalreincarnation(this Actor actor)
    {
        actor.data.get(Eternalreincarnation_key, out float val, 1);
        return val;
    }
    public static void SetEternalreincarnation(this Actor actor, float val)
    {
        actor.data.set(Eternalreincarnation_key, val);
    }
    public static void ChangeEternalreincarnation(this Actor actor, float delta)
    {
        actor.data.get(Eternalreincarnation_key, out float val, 0);
        val += delta;
        actor.data.set(Eternalreincarnation_key, Mathf.Max(1, val));
    }

    public static float GetNirvana(this Actor actor)
    {
        actor.data.get(nirvana_key, out float val, 0);
        return val;
    }
    public static void SetNirvana(this Actor actor, float val)
    {
        actor.data.set(nirvana_key, val);
    }
    public static void ChangeNirvana(this Actor actor, float delta)
    {
        actor.data.get(nirvana_key, out float val, 0);
        val += delta;
        actor.data.set(nirvana_key, Mathf.Max(0, val));
    }

    public static float GetBelievers(this Actor actor)
    {
        actor.data.get(Believers_key, out float val, 0);
        return val;
    }
    public static void SetBelievers(this Actor actor, float val)
    {
        actor.data.set(Believers_key, val);
    }
    public static void ChangeBelievers(this Actor actor, float delta)
    {
        actor.data.get(Believers_key, out float val, 0);
        val += delta;
        actor.data.set(Believers_key, val);
    }

    public static float GetIncenseandfire(this Actor actor)
    {
        actor.data.get(Incenseandfire_key, out float val, 0);

        return val;
    }

    public static void SetIncenseandfire(this Actor actor, float val)
    {
        actor.data.set(Incenseandfire_key, val);
    }

    public static void ChangeIncenseandfire(this Actor actor, float delta)
    {
        actor.data.get(Incenseandfire_key, out float val, 0);
        val += delta;
        actor.data.set(Incenseandfire_key, Mathf.Max(0, val));
    }
    }
}