﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeerlessThedayofGodswrath.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset Divinity = new ActorTraitGroupAsset();
            Divinity.id = "Divinity";
            Divinity.name = "trait_group_Divinity";
            Divinity.color = "#FFFF00";
            AssetManager.trait_groups.add(Divinity);

            ActorTraitGroupAsset GodsandBuddhas = new ActorTraitGroupAsset();
            GodsandBuddhas.id = "GodsandBuddhas";
            GodsandBuddhas.name = "trait_group_GodsandBuddhas";
            GodsandBuddhas.color = "#FFFF00";
            AssetManager.trait_groups.add(GodsandBuddhas);

            ActorTraitGroupAsset Godsgift = new ActorTraitGroupAsset();
            Godsgift.id = "Godsgift";
            Godsgift.name = "trait_group_Godsgift";
            Godsgift.color = "#FFFF00";
            AssetManager.trait_groups.add(Godsgift);

            ActorTraitGroupAsset HolyTruth = new ActorTraitGroupAsset();
            HolyTruth.id = "HolyTruth";
            HolyTruth.name = "trait_group_HolyTruth";
            HolyTruth.color = "#FFFF00";
            AssetManager.trait_groups.add(HolyTruth);

            ActorTraitGroupAsset GuardianDharma = new ActorTraitGroupAsset();
            GuardianDharma.id = "GuardianDharma";
            GuardianDharma.name = "trait_group_GuardianDharma";
            GuardianDharma.color = "#FFFF00";
            AssetManager.trait_groups.add(GuardianDharma);
        }
    }
}