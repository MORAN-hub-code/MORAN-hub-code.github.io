﻿namespace PeerlessThedayofGodswrath.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset Incenseandfire = new BaseStatAsset();
            Incenseandfire.id = "Incenseandfire";
            Incenseandfire.normalize = true;
            Incenseandfire.normalize_min = -99999;
            Incenseandfire.normalize_max = 2100000000;
            // Incenseandfire.multiplier = true;
            Incenseandfire.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Incenseandfire);

            BaseStatAsset Believers = new BaseStatAsset();
            Believers.id = "Believers";
            Believers.normalize = true;
            Believers.normalize_min = -99999;
            Believers.normalize_max = 2100000000;
            // Believers.multiplier = true;
            Believers.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Believers);          
        }
    }
}