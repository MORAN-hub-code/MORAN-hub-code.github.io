using System;
using System.Collections.Generic;
using System.Linq;
using ai;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using ai.behaviours;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using AttributeExpansion.code.utils;
using System.Text;
using System.Reflection;
using ReflectionUtility;
using System.IO;

namespace PeerlessThedayofGodswrath.code
{
    internal class patch
    {
        private static readonly HashSet<string> BasicRaces = new() { "orc", "human", "elf", "dwarf" };
        private static readonly HashSet<string> FlairDivinityTraits = new()
        {
            "Divinity1", "Divinity2", "Divinity3", "Divinity4","Divinity5", "Divinity6", "Divinity7"
        };

        private const float DivinityRandomChance = 0.1f;
        private const float Divinity91Chance = 0f;


        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_KnightPostfix(Actor __instance)
        {
            if (__instance == null) return;

            float age = (float)__instance.getAge();
            bool hasDivinity5 = __instance.hasTrait("Divinity91");
            bool hasDivinity6 = __instance.hasTrait("Divinity91");
            bool hasDivinity7 = __instance.hasTrait("Divinity7");

            if (IsBasicRaceOrCiv(__instance.asset.id))
            {
                HandleBasicRaceTraits(__instance, age, hasDivinity5, hasDivinity6);
            }

            ApplyTraitEffects(__instance, hasDivinity5, hasDivinity6);

            ApplyKnightGrades(__instance);
        }

        private static bool IsBasicRaceOrCiv(string assetId)
        {
            return BasicRaces.Contains(assetId) || assetId.StartsWith("civ_");
        }

        private static void HandleBasicRaceTraits(Actor actor, float age, bool hasDivinity5, bool hasDivinity6)
        {
            if (Mathf.FloorToInt(age) == 9 &&
                !hasDivinity5 &&
                !hasDivinity6 &&
                !HasAnyFlairDivinity(actor) &&
                Randy.randomChance(DivinityRandomChance))
            {
                string selectedDivinity = SelectRandomDivinity();
                actor.addTrait(selectedDivinity, false);
            }
        }

        private static string SelectRandomDivinity()
        {
            var DivinityWeights = new (string traitId, int weight)[]
            {
                ("Divinity1", 1000),
                ("Divinity2", 500),
                ("Divinity3", 100),
                ("Divinity4", 50),
                ("Divinity5", 10),
                ("Divinity6", 5),
                ("Divinity7", 1)

            };

            int totalWeight = DivinityWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);

            foreach (var Divinity in DivinityWeights)
            {
                if (randomValue < Divinity.weight)
                {
                    return Divinity.traitId;
                }
                randomValue -= Divinity.weight;
            }

            return "Divinity1";
        }

        private static void ApplyTraitEffects(Actor actor, bool hasDivinity5, bool hasDivinity6)
        {
            var DivinityEffects = new Dictionary<string, (float min, float max)>
            {
                { "Divinity1", (1f, 6f) },
                { "Divinity2", (3f, 9f) },
                { "Divinity3", (6f, 12f) },
                { "Divinity4", (9f, 15f) },
                { "Divinity5", (12f, 18f) },
                { "Divinity6", (20f, 25f) },
                { "Divinity7", (25f, 30f) },
            };

            foreach (var effect in DivinityEffects)
            {
                string traitId = effect.Key;

                if ((hasDivinity6 || hasDivinity5) &&
                    (traitId == "Divinity1" || traitId == "Divinity2" || traitId == "Divinity3" || traitId == "Divinity4" || traitId == "Divinity5" || traitId == "Divinity6" || traitId == "Divinity7"))
                {
                    continue;
                }

                if (actor.hasTrait(traitId))
                {
                    (float min, float max) = effect.Value;
                    float knightChange = UnityEngine.Random.Range(min, max);
                    actor.ChangeIncenseandfire(knightChange);
                }
            }

            if (!actor.hasTrait("Divinity7"))
            {
                var knightThresholds = new Dictionary<string, float>
                {

                };

                foreach (var threshold in knightThresholds)
                {
                    if (actor.hasTrait(threshold.Key) &&
                        (float)actor.getAge() > threshold.Value &&
                        Randy.randomChance(Divinity91Chance))
                    {
                        actor.addTrait("Divinity91", false);
                    }
                }
            }
        }

        private static void ApplyKnightGrades(Actor actor)
        {
            var knightGrades = new Dictionary<string, float>
            {

            };

            foreach (var grade in knightGrades)
            {
                if (actor.hasTrait(grade.Key))
                {
                    float currentIncenseandfire = actor.GetIncenseandfire();
                    actor.SetIncenseandfire(Mathf.Min(grade.Value, currentIncenseandfire));
                }
            }
        }

        private static bool HasAnyFlairDivinity(Actor actor)
        {
            foreach (string trait in FlairDivinityTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
        public static bool actorGetHit_prefix(
                Actor __instance,
                ref float pDamage,
                bool pFlash,
                AttackType pAttackType,
                BaseSimObject pAttacker,
                bool pSkipIfShake,
                bool pMetallicWeapon)
        {
            if (pDamage >= 0f)
            {
                // 定义所有减伤组（按优先级从高到低排序）
                var damageReductionGroups = new List<Tuple<string[], float>>()
                    {
                    // 格式: (特质数组, 伤害乘数)
                        new Tuple<string[], float>(new string[] { "Godsgift8" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas93" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas92" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas91" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas9" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas8" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas7" }, 0f),
                        new Tuple<string[], float>(new string[] { "GodsandBuddhas6" }, 0f)
                    };

                // 按优先级检查减伤
                foreach (var group in damageReductionGroups)
                {
                    foreach (string trait in group.Item1)
                    {
                        if (__instance.hasTrait(trait))
                        {
                            pDamage *= group.Item2; // 应用减伤
                            goto AfterDamageReduction; // 跳出所有循环
                        }
                    }
                }
            AfterDamageReduction:; // 优先级检查结束标记
            }
            return true; // 继续执行原方法
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addInjuryTrait))]
        private static bool PreventInjuryForProtectedTraits(Actor __instance, string pTraitID)
        {
            if (HasProtectedQWE(__instance) && (pTraitID == "crippled" || pTraitID == "eyepatch"))
            {
                return false;
            }
            return true;
        }


        [HarmonyPostfix, HarmonyPatch(typeof(Actor), nameof(Actor.updateStamina))]
        public static void LockStaminaForSpecialTrait(Actor __instance)
        {

            if (HasProtectedQWE(__instance))
            {
                __instance.setStamina(__instance.getMaxStamina(), true);
            }
        }


        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
        public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
        {
            return !HasProtectedQWE(__instance);
        }


        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
        public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
        {
            return !HasProtectedQWE(__instance);
        }

        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.makeSleep))]
        public static bool MakeSleep_Protection(Actor __instance, float pTime)
        {
            return !HasProtectedQWE(__instance);
        }


        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), nameof(Actor.makeStunned))]
        public static bool MakeStunned_Protection(Actor __instance, float pTime = 5f)
        {
            return !HasProtectedQWE(__instance);
        }


        [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
        public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
        {
            if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
            {
                return !HasProtectedQWE(__instance);
            }
            return true;
        }

        private static readonly HashSet<string> ProtectedQWE = new()
        {
            "GodsandBuddhas1","GodsandBuddhas2","GodsandBuddhas3",
            "GodsandBuddhas4","GodsandBuddhas5","GodsandBuddhas6",
            "GodsandBuddhas7","GodsandBuddhas8","GodsandBuddhas9",
            "GodsandBuddhas91","GodsandBuddhas92","GodsandBuddhas93",
        };
        private static bool HasProtectedQWE(Actor actor)
        {
            if (actor == null) return false;
            return ProtectedQWE.Any(trait => actor.hasTrait(trait));
        }

        [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "showWhisperTip")]
        public static bool Prefix(string pText)
        {
            // 自定义逻辑：显示停留时间为x秒的提示信息
            string text = LocalizedTextManager.getText(pText, null);
            if (Config.whisper_A != null)
            {
                text = text.Replace("$kingdom_A$", Config.whisper_A.name);
            }
            if (Config.whisper_B != null)
            {
                text = text.Replace("$kingdom_B$", Config.whisper_B.name);
            }
            WorldTip.showNow(text, false, "top", 15f);


            // 如果不需要跳过原方法，则返回true.
            return false;
        }
    }
}