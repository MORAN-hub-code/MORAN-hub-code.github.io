using System.Collections.Generic;

namespace Cultivatingimmortals.code;

/// <summary>
/// 全局配置类，管理修仙世界的核心参数和事件状态
/// </summary>
public class Globals
{
    // ==== 灵气系统 ====
    
    /// <summary>
    /// 当前世界的总灵气值（Total Spirit of the World）
    /// </summary>
    public static float Tsotw;
    
    /// <summary>
    /// 基础灵气值（世界创建时的初始灵气）
    /// </summary>
    public static float baseTsotw = 1000;
    
    /// <summary>
    /// 每年自然增长的灵气量
    /// </summary>
    public static float TsotwAdd = 1000;
    
    /// <summary>
    /// 当前世界名称
    /// </summary>
    public static string WorldName = "null";
    
    /// <summary>
    /// 所有修士的字典（ID -> Actor）
    /// </summary>
    public static Dictionary<string, Actor> Actors = new Dictionary<string, Actor>();

    // ==== 事件周期配置 ====
    
    /// <summary>
    /// 当前活跃的世界事件（normal/daozhang/linghuang/super_daozhang/mochao）
    /// </summary>
    public static string CurrentEvent = "normal";
    
    /// <summary>
    /// 道涨期持续时间（年）
    /// </summary>
    public static int DaozhangDuration = 80;
    
    /// <summary>
    /// 灵荒期持续时间（年）
    /// </summary>
    public static int LinghuangDuration = 80;
    
    /// <summary>
    /// 超级道涨期持续时间（年）
    /// </summary>
    public static int SuperDaozhangDuration = 80;
    
    /// <summary>
    /// 魔潮期持续时间（年）
    /// </summary>
    public static int MochaoDuration = 50;
    
    /// <summary>
    /// 平缓期持续时间（年）
    /// </summary>
    public static int NormalDuration = 100;
    
    /// <summary>
    /// 完整周期年数（360年）
    /// </summary>
    public static int FullCycle = 360;
    
    /// <summary>
    /// 道涨期周期（每多少年发生一次）
    /// </summary>
    public static int DaozhangCycle = 30;
    
    /// <summary>
    /// 灵荒期周期（每多少年发生一次）
    /// </summary>
    public static int LinghuangCycle = 20;
    
    /// <summary>
    /// 基础周期计数（用于触发超级道涨期）
    /// </summary>
    public static int BaseCycleCount = 5;
    
    /// <summary>
    /// 道涨期灵气增长倍数（基础值的倍数）
    /// </summary>
    public static float DaozhangEffectMultiplier = 4.5f;
    
    /// <summary>
    /// 超级道涨期灵气增长倍数（基础值的倍数）
    /// </summary>
    public static float SuperDaozhangEffectMultiplier = 10.0f;
    
    /// <summary>
    /// 灵荒期灵气衰减系数（保留的比例）
    /// </summary>
    public static float LinghuangEffectReduction = 0.08f;
    
    /// <summary>
    /// 灵荒期年增长率系数（基础值的比例）
    /// </summary>
    public static float LinghuangGrowthRate = 0.05f;
    
    /// <summary>
    /// 道涨期效果触发间隔（年）
    /// </summary>
    public static int DaozhangEffectInterval = 26;
    
    /// <summary>
    /// 灵荒期效果触发间隔（年）
    /// </summary>
    public static int LinghuangEffectInterval = 26;
    
    /// <summary>
    /// 超级道涨期效果触发间隔（年）
    /// </summary>
    public static int SuperDaozhangEffectInterval = 26;
    
    /// <summary>
    /// 魔潮期效果触发间隔（年）
    /// </summary>
    public static int MochaoEffectInterval = 16;
    
    /// <summary>
    /// 道涨期修士真元奖励比例
    /// </summary>
    public static float DaozhangBonusRatio = 0.2f;
    
    /// <summary>
    /// 超级道涨期修士真元奖励比例
    /// </summary>
    public static float SuperDaozhangBonusRatio = 0.4f;
    
    /// <summary>
    /// 灵荒期修士真元惩罚比例
    /// </summary>
    public static float LinghuangPenaltyRatio = 0.5f;
    
    /// <summary>
    /// 魔潮期修士腐化概率
    /// </summary>
    public static float MochaoCorruptionChance = 0.15f;

    // ==== 运行时状态 ====
    
    /// <summary>
    /// 下一次道涨期开始年份
    /// </summary>
    public static int NextDaozhangYear = 100;
    
    /// <summary>
    /// 下一次灵荒期开始年份
    /// </summary>
    public static int NextLinghuangYear = 280;
    
    /// <summary>
    /// 当前事件结束年份
    /// </summary>
    public static int CurrentEventEndYear = 0;
    
    /// <summary>
    /// 当前事件开始年份
    /// </summary>
    public static int EventStartYear = 0;
    
    /// <summary>
    /// 上次效果触发年份
    /// </summary>
    public static int LastEffectYear = 0;
    
    /// <summary>
    /// 基础周期计数（用于触发超级道涨期）
    /// </summary>
    public static int CycleCount = 0;
    
    /// <summary>
    /// 标记上次事件是否为灵荒期
    /// </summary>
    public static bool LastEventWasLinghuang = false;
    
    /// <summary>
    /// 下一次超级道涨期开始年份
    /// </summary>
    public static int NextSuperDaozhangYear = -1;
    
    /// <summary>
    /// 魔潮开始年份
    /// </summary>
    public static int MochaoStartYear = 0;
    
    /// <summary>
    /// 魔潮结束年份
    /// </summary>
    public static int MochaoEndYear = 0;

    // ==== 状态标志 ====
    
    /// <summary>
    /// 魔潮是否激活
    /// </summary>
    public static bool MochaoActivated = false;
    
    /// <summary>
    /// 正常时期的灵气年增量
    /// </summary>
    public static float NormalTsotwAdd = 1000;


/// <summary>
/// 已觉醒体质的修士ID列表（用于收藏功能）
/// </summary>
public static List<string> FavoriteCultivators = new List<string>();

/// <summary>
/// 已触发体质觉醒的年份列表（防止重复触发）
/// </summary>
public static List<int> TizhiAwakenedYears = new List<int>();


    // ==== 资源管理 ====
    
    /// <summary>
    /// 防止资源重复加载的标志
    /// </summary>
    private static bool _resourcesLoaded = false;
    
    /// <summary>
    /// 确保资源加载（防止重复初始化）
    /// </summary>
    public static void EnsureResourcesLoaded()
    {
        if (!_resourcesLoaded)
        {
            _resourcesLoaded = true;
        }
    }
}
