using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using Cultivatingimmortals.code.utils;
using Cultivatingimmortals.code.window;

namespace Cultivatingimmortals.code;

internal class patch
{
    // ==== 顿悟方法 ====
private static void CheckForEpiphany(Actor actor, float age)
{
    if (actor.hasTrait("has_epiphany")) return;
    
    // 确定操作类型
// 确定操作类型
    string operation = "";
    if (actor.hasTrait("flair3")) operation = "upgrade_flair3";
    else if (actor.hasTrait("flair4")) operation = "upgrade_flair4";
    else if (actor.hasTrait("flair5")) operation = "breakthrough_Grade4"; // 天灵道体 -> 合体 (Changed)
    else if (actor.hasTrait("flair6")) operation = "breakthrough_Grade5_flair94"; // 圣体 -> 大乘 (Changed)
    else if (actor.hasTrait("flair7")) operation = "breakthrough_Grade7_flair95"; // 道胎 -> 散仙

    
    if (string.IsNullOrEmpty(operation)) return;
    
    // 计算顿悟概率
    float epiphanyChance = GetEpiphanyChance(operation, age);
    
    if (Randy.randomChance(epiphanyChance))
    {
        switch (operation)
        {
            case "upgrade_flair3":
                actor.removeTrait("flair3");
                actor.addTrait("flair4");
                actor.ChangeYuanNeng(50);
                ShowEpiphanyMessage(actor, "Epiphany_Flair3_Upgrade");
                break;
                
            case "upgrade_flair4":
                actor.removeTrait("flair4");
                actor.addTrait("flair5");
                actor.ChangeYuanNeng(100);
                ShowEpiphanyMessage(actor, "Epiphany_Flair4_Upgrade");
                break;
                
            case "breakthrough_Grade4": // 天灵道体 -> 合体 (Changed from Grade6 to Grade4)
        if (traitAction.EpiphanyBreakthrough(actor, "Grade4")) // Changed target grade
        {
            actor.ChangeYuanNeng(200);
            ShowEpiphanyMessage(actor, "Epiphany_Flair5_Breakthrough");
        }
        break;
        
    case "breakthrough_Grade5_flair94": // 圣体 -> 大乘 (Changed from Grade6 to Grade5, renamed operation key)
        if (traitAction.EpiphanyBreakthrough(actor, "Grade5")) // Changed target grade
        {
            actor.ChangeYuanNeng(300);
            actor.addTrait("flair94");
            ShowEpiphanyMessage(actor, "Epiphany_Flair6_Breakthrough");
        }
        break;
                
            case "breakthrough_Grade7_flair95":
                if (traitAction.EpiphanyBreakthrough(actor, "Grade7"))
                {
                    actor.ChangeMeditation(100);
                    actor.addTrait("flair95");
                    ShowEpiphanyMessage(actor, "Epiphany_Flair7_Breakthrough");
                }
                break;
        }
        
        // 添加顿悟特效
        actor.spawnParticle(Color.yellow);
        actor.startShake(0.8f, 0.3f, true, false);
    }
}

private static float GetEpiphanyChance(string operation, float age)
{
    // 基础概率和最大概率配置
    float baseChance = 0f;
    float maxChance = 0f;
    
    switch (operation)
    {
        case "upgrade_flair3": // 中人之姿→五行灵体
            baseChance = 0.006f;  // 0.6%
            maxChance = 0.03f;    // 3%
            break;
            
        case "upgrade_flair4": // 五行灵体→天灵道体
            baseChance = 0.009f;  // 0.9%
            maxChance = 0.03f;    // 4%
            break;
            
        case "breakthrough_Grade4": // 天灵道体→
            baseChance = 0.012f;   // 1.2%
            maxChance = 0.049f;    // 2.9%
            break;
            
        case "breakthrough_Grade5_flair94": // 圣体→
            baseChance = 0.012f;    // 
            maxChance = 0.038f;    // 3.8%
            break;
            
        case "breakthrough_Grade7_flair95": // 道胎→散仙境
            baseChance = 0.018f;   // 1.8%
            maxChance = 0.045f;     // 4.5%
            break;
            
        default:
            return 0f; 
    }
    if (Globals.CurrentEvent == "daozhang")
    {
        baseChance += 0.008f; // 增加
    }
    // ==== 超级道涨期额外加成 ====
    else if (Globals.CurrentEvent == "super_daozhang")
    {
        baseChance += 0.02f; // 额外增加2%概率（总计3%加成）
    }
    
    // 每百年增加0.1%概率（0.001f）
    float ageBonus = age * 0.001f / 100f; // age是年龄天数，除以100转换为百年
    
    // 计算总概率（基础 + 年龄加成）
    float totalChance = baseChance + ageBonus;
    
    // 应用最大概率限制
    return Mathf.Min(totalChance, maxChance);
}

private static void ShowEpiphanyMessage(Actor actor, string messageKey)
{
    string message = LocalizedTextManager.getText(messageKey, null)
        .Replace("{0}", actor.getName());
    
    // +++ 添加玄门历时间戳（仅限后三个天赋） +++
    string[] timedEvents = {
        "Epiphany_Flair5_Breakthrough",
        "Epiphany_Flair6_Breakthrough",
        "Epiphany_Flair7_Breakthrough"
    };
    
    if (timedEvents.Contains(messageKey)) 
    {
        // 使用原生世界时间，一年60天，年份+1（从玄门历1年开始）
        int year = (int)(World.world.getCurWorldTime() / 60) + 1;
        message = $"[玄门历{year}年] " + message;
    }
    ActionLibrary.showWhisperTip(message);
    PlayWavDirectly.Instance.PlaySoundFromFile(
        CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\Sound_1.wav");
}

    public static bool isLoadSave;

    [HarmonyPrefix, HarmonyPatch(typeof(SavedMap), "create")]
    public static bool create_prefix()
    {
        List<Actor> actors = World.world.units.getSimpleList();
        foreach (Actor actor in actors)
        {
            actor.data.set("wushu.global", Globals.Tsotw);
        }

        return true;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(ActorManager), "loadObject")]
    public static void AddCustomData(ref Actor __result, ActorData pData)
    {
        if (__result != null)
        {
            __result.data.get("wushu.global", out Globals.Tsotw);
        }
    }


    public static string[] traits =
    {
        "meditation1",
        "meditation2",
        "meditation3"
    };

[HarmonyPostfix, HarmonyPatch(typeof(Actor), nameof(Actor.newKillAction))]
private static void newMechanism(Actor __instance, Actor pDeadUnit)
{
    // 仙境以上（Grade7+）始终可掠夺仙元
    if (__instance.hasTrait("Grade7") || __instance.hasTrait("Grade8") || 
        __instance.hasTrait("Grade9") || __instance.hasTrait("Grade91"))
    {
        float stealRatio = UnityEngine.Random.Range(0.08f, 0.15f);
        float stolenMeditation = pDeadUnit.GetMeditation() * stealRatio;
        stolenMeditation = Mathf.Min(stolenMeditation, pDeadUnit.GetMeditation());
        
        pDeadUnit.ChangeMeditation(-stolenMeditation);
        __instance.ChangeMeditation(stolenMeditation);
        
        // 特效保留但不显示提示
        __instance.spawnParticle(new Color(0.8f, 0.2f, 0.2f));
        pDeadUnit.spawnParticle(new Color(0.5f, 0.5f, 0.5f));
    }
    // 仙境以下仅在灵荒期/魔潮期掠夺真元
    else if ((Globals.CurrentEvent == "linghuang" || Globals.CurrentEvent == "mochao") && 
             IsCultivator(pDeadUnit))
    {
        float stealRatio = UnityEngine.Random.Range(0.03f, 0.08f);
        float stolenYuanNeng = pDeadUnit.GetYuanNeng() * stealRatio;
        stolenYuanNeng = Mathf.Min(stolenYuanNeng, pDeadUnit.GetYuanNeng());
        
        pDeadUnit.ChangeYuanNeng(-stolenYuanNeng);
        __instance.ChangeYuanNeng(stolenYuanNeng);
        
        // 特效保留但不显示提示
        __instance.spawnParticle(new Color(0.8f, 0.2f, 0.2f));
        pDeadUnit.spawnParticle(new Color(0.5f, 0.5f, 0.5f));
    }

        foreach (string trait in traits)
        {
            if (pDeadUnit.hasTrait(trait) && __instance.hasTrait(trait))
            {
                float deadUnitMeditation = pDeadUnit.GetMeditation();
                float additionalWuLi = deadUnitMeditation * UnityEngine.Random.Range(0.3f, 0.7f);
                __instance.ChangeMeditation(additionalWuLi);
            }
            else
            {
                // 检查交叉特质
                foreach (string otherTrait in traits)
                {
                    if (trait != otherTrait && pDeadUnit.hasTrait(trait) && __instance.hasTrait(otherTrait))
                    {
                        float deadUnitMeditation = pDeadUnit.GetMeditation();
                        float additionalWuLi = deadUnitMeditation * UnityEngine.Random.Range(0.3f, 0.7f);
                        __instance.ChangeMeditation(additionalWuLi);
                    }
                }
            }
        }
        if (__instance.hasTrait("flair91") && pDeadUnit.hasTrait("flair91"))
        {
            // 假设Actor类有ChangeResurrection方法用于修改“复活”的数值
            __instance.ChangeResurrection(10); // 击杀者增加10点“复活”
            pDeadUnit.ChangeResurrection(-10); // 被击杀者减少10点“复活”（可选，根据游戏逻辑决定是否需要）
        }
    }
    private static bool IsCultivator(Actor actor)
{
    // 检查是否拥有修仙特质（从flair3到flair7，以及所有境界特质）
    return actor.hasTrait("flair3") || 
           actor.hasTrait("flair4") || 
           actor.hasTrait("flair5") ||
           actor.hasTrait("flair6") ||
           actor.hasTrait("flair7") ||
           actor.hasTrait("Grade0") ||   // 引气境
           actor.hasTrait("Grade01") ||  // 筑基境
           actor.hasTrait("Grade02") ||  // 金丹境
           actor.hasTrait("Grade1") ||   // 元婴境
           actor.hasTrait("Grade2") ||   // 化神境
           actor.hasTrait("Grade3") ||   // 炼虚境
           actor.hasTrait("Grade4") ||   // 合体境
           actor.hasTrait("Grade5") ||   // 大乘境
           actor.hasTrait("Grade6") ||   // 渡劫境
           actor.hasTrait("Grade7") ||   // 散仙境
           actor.hasTrait("Grade8") ||   // 真仙境
           actor.hasTrait("Grade9") ||   // 金仙境
           actor.hasTrait("Grade91");    // 混元无极境
}

    public static bool window_creature_info_initialized;
    [HarmonyPostfix]
    [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
    private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
    {
        if (__instance.actor == null || !__instance.actor.isAlive()) return;
        if (!window_creature_info_initialized)
        {
            window_creature_info_initialized = true;
            WindowCreatureInfoPatchHelper.Initialize(__instance);
        }
    }
    [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
    private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
    {
        var actor = __instance.actor;
        if (actor == null || !actor.isAlive()) return;
        __instance.setIconValue("YuanNeng", actor.GetYuanNeng());
        __instance.setIconValue("Meditation", actor.GetMeditation());
        __instance.setIconValue("Resurrection", actor.GetResurrection());
        __instance.setIconValue("Rresurrection", actor.GetRresurrection());
    }
    private static bool IsActorDead(Actor actor)
    {
        return !actor.hasHealth();
    }


    [HarmonyPostfix, HarmonyPatch(typeof(MapBox), "updateObjectAge")]
    public static void updateWorldTime_Postfix(MapBox __instance)
    {
    Globals.EnsureResourcesLoaded();
    int currentYear = (int)(World.world.getCurWorldTime() / 60) + 1;
    
   // ==== 事件状态检测 ====
if (currentYear >= Globals.CurrentEventEndYear && Globals.CurrentEvent != "normal")
{
    
    Globals.Tsotw = Globals.baseTsotw;
    Globals.TsotwAdd = Globals.NormalTsotwAdd;

    // 特殊状态处理
    switch (Globals.CurrentEvent)
    {
        case "linghuang":
            Globals.LastEventWasLinghuang = true;
            break;
        case "mochao":
            Globals.MochaoActivated = false;
            break;
    }

    // 事件结束提示
    string endMsg = Globals.CurrentEvent switch
    {
        "daozhang" => $"[玄门历{currentYear}年] 道涨潮退，灵脉复归平静。然大道余韵犹存，修士当勤修不辍。",
        "linghuang" => $"[玄门历{currentYear}年] 灵荒劫过，天地玄炁渐复。然修仙界元气大伤，百废待兴。",
        "super_daozhang" => $"[玄门历{currentYear}年] 超级道涨潮退，归墟魔潮开始涌动...",
        "mochao" => $"[玄门历{currentYear}年] 归墟魔潮退去，天地重归平静",
        _ => ""
    };

    if (!string.IsNullOrEmpty(endMsg))
    {
        ActionLibrary.showWhisperTip(endMsg);
    }

    Globals.CurrentEvent = "normal";
}

    
    
    // ==== 重构周期触发逻辑 ====
    if (Globals.CurrentEvent == "normal")
    {
        // 道涨期检测
        if (currentYear >= Globals.NextDaozhangYear)
        {
            Globals.CurrentEvent = "daozhang";
            Globals.EventStartYear = currentYear;
            Globals.CurrentEventEndYear = currentYear + Globals.DaozhangDuration;
            
            // 设置下一个道涨期 (完整周期后)
            Globals.NextDaozhangYear += Globals.FullCycle;
            
            // 设置下一个灵荒期 (道涨结束+平缓期)
            Globals.NextLinghuangYear = currentYear + 
                Globals.DaozhangDuration + 
                Globals.NormalDuration;
            
            Globals.TsotwAdd = Globals.baseTsotw * Globals.DaozhangEffectMultiplier;
            
            // 道涨期播报语
            string msg = $"[玄门历{currentYear}年] 天地异变，道涨潮生！周天玄炁将奔涌{Globals.DaozhangDuration}年";
            ActionLibrary.showWhisperTip(msg);
            CheckTizhiAwakening(currentYear, "daozhang");
        }
        // 灵荒期检测
        else if (currentYear >= Globals.NextLinghuangYear)
        {
            Globals.CurrentEvent = "linghuang";
            Globals.EventStartYear = currentYear;
            Globals.CurrentEventEndYear = currentYear + Globals.LinghuangDuration;
            
            // 设置下一个灵荒期 (完整周期后)
            Globals.NextLinghuangYear += Globals.FullCycle;
            
            // 设置下一个道涨期 (灵荒结束+平缓期)
            Globals.NextDaozhangYear = currentYear + 
                Globals.LinghuangDuration + 
                Globals.NormalDuration;
            
            Globals.Tsotw *= Globals.LinghuangEffectReduction;
            Globals.TsotwAdd = Globals.baseTsotw * Globals.LinghuangEffectReduction;
            
            // 灵荒期播报语
            string msg = $"[玄门历{currentYear}年] 天机骤变，灵荒劫至！乾坤玄炁将枯竭{Globals.LinghuangDuration}年";
            ActionLibrary.showWhisperTip(msg);
        }
    }
    
    // ==== 超级周期检测 ====
    if (Globals.CurrentEvent == "normal")
    {
        if (Globals.LastEventWasLinghuang)
        {
            Globals.CycleCount++;
            Globals.LastEventWasLinghuang = false;
            
            if (Globals.CycleCount >= Globals.BaseCycleCount)
            {
                Globals.CycleCount = 0;
                Globals.NextSuperDaozhangYear = currentYear;
            }
        }
    }

    // ==== 超级道涨期触发 ====
    if (Globals.CurrentEvent == "normal" && 
        currentYear >= Globals.NextSuperDaozhangYear &&
        Globals.NextSuperDaozhangYear > 0)
    {
        Globals.CurrentEvent = "super_daozhang";
        Globals.EventStartYear = currentYear;
        Globals.CurrentEventEndYear = currentYear + Globals.SuperDaozhangDuration;
        Globals.NextSuperDaozhangYear = 0;
        Globals.TsotwAdd = Globals.baseTsotw * Globals.SuperDaozhangEffectMultiplier;
        
        // 超级道涨期播报语
        string msg = $"[玄门历{currentYear}年] 大道潮涌，天地异变！千年一遇的超级道涨期降临，将持续{Globals.SuperDaozhangDuration}年";
        ActionLibrary.showWhisperTip(msg);
        CheckTizhiAwakening(currentYear, "super_daozhang");
    }

    // 超级道涨期结束检测
    if (Globals.CurrentEvent == "super_daozhang" && 
        currentYear >= Globals.CurrentEventEndYear)
    {
        TriggerMochao(currentYear);
        Globals.CurrentEvent = "mochao";
        Globals.CurrentEventEndYear = currentYear + Globals.MochaoDuration;
        Globals.TsotwAdd = Globals.baseTsotw * Globals.LinghuangEffectReduction;
    }
    
    // ==== 动态效果处理 ====
    ProcessDynamicEffects(currentYear);
                
    // 世界名称和加载状态处理
    if (Globals.WorldName != __instance.map_stats.name && !isLoadSave)
    {
        Globals.Tsotw = Globals.baseTsotw;
        Globals.WorldName = __instance.map_stats.name;
        return;
    }
    else if (isLoadSave)
    {
        Globals.WorldName = __instance.map_stats.name;
        isLoadSave = false;
        return;
    }

    // 更新灵气值
    Globals.Tsotw += Globals.TsotwAdd;
    window.UiPanelInfo.UpdateText();
}
private static void TriggerMochao(int startYear)
{
    Globals.MochaoActivated = true;
    Globals.MochaoStartYear = startYear;
    Globals.MochaoEndYear = startYear + Globals.MochaoDuration;
    
    // 初始腐化一批修士
    List<Actor> actors = World.world.units.getSimpleList();
    int initialCorrupted = 0;
    
    foreach (Actor actor in actors) 
    {
        if (actor.isAlive() && Randy.randomChance(0.1f))
        {
            actor.addTrait("madness");
            actor.data.setName("浊仙");
            initialCorrupted++;
        }
    }
    
    // 魔潮期播报语
    string tip = $"[玄门历{startYear}年] 归墟魔潮爆发！将持续{Globals.MochaoDuration}年";
    ActionLibrary.showWhisperTip(tip);
}

private static void CheckTizhiAwakening(int currentYear, string eventType)
{
    List<Actor> actors = World.world.units.getSimpleList();
    
    // 检查是否已经在当年触发过
    if (Globals.TizhiAwakenedYears.Contains(currentYear)) return;
    
    // 如果有特定触发时间，保留这段；否则删除
    int yearsSinceEventStart = currentYear - Globals.EventStartYear;
    if (yearsSinceEventStart != 10) return;
    
    Globals.TizhiAwakenedYears.Add(currentYear);
    
    foreach (Actor actor in actors)
    {
        // 年龄限制：只允许250岁以内的修士觉醒
        float age = (float)actor.getAge();
        if (age > 250) continue;
        
        if (actor.isAlive() && !actor.hasTrait("has_tizhi") && 
            (actor.hasTrait("Grade01") || actor.hasTrait("Grade02")||actor.hasTrait("Grade1")|| actor.hasTrait("Grade2")))
        {
            // 道涨期0.5%概率，超级道涨期0.8%概率
            float chance = eventType == "super_daozhang" ? 0.008f : 0.005f;
            
            if (Randy.randomChance(chance))
            {
                AwakenTizhi(actor, currentYear);
            }
        }
    }
}

private static void AwakenTizhi(Actor actor, int currentYear)
{
    // 体质权重配置
    var tizhiWeights = new (string traitId, int weight, string displayName)[]
    {
        ("tizhi01", 15, "星髓玉骨"),
        ("tizhi02", 12, "归墟冥脉"), 
        ("tizhi03", 10, "后土玄躯"),
        ("tizhi04", 18, "青帝长生体"),
        ("tizhi05", 20, "劫雷法身"),
        ("tizhi06", 14, "太阴琉璃心"),
        ("tizhi07", 22, "焚世烈阳体"),
        ("tizhi08", 16, "虚空无相体"),
        ("tizhi09", 16, "血海修罗身"),
        ("tizhi10", 18, "剑魄通明体")
    };

    // 计算总权重
    int totalWeight = tizhiWeights.Sum(t => t.weight);

    // 生成随机数
    int randomValue = Randy.randomInt(0, totalWeight);

    // 选择体质
    string selectedTizhi = "tizhi01";
    string displayName = "星髓玉骨";
    
    foreach (var tizhi in tizhiWeights)
    {
        if (randomValue < tizhi.weight)
        {
            selectedTizhi = tizhi.traitId;
            displayName = tizhi.displayName;
            break;
        }
        randomValue -= tizhi.weight;
    }

    // 添加体质特质
    actor.addTrait(selectedTizhi, false);
    actor.addTrait("has_tizhi", false); // 标记已觉醒体质
    
    // 收藏该单位
    actor.data.favorite = true;
    
    // 播放特效
    actor.spawnParticle(new Color(0.8f, 0.2f, 0.8f));
    actor.startShake(0.7f, 0.3f, true, false);
    
    // 定制播报消息
    string actorName = actor.getName();
    string message = GetTizhiAwakeningMessage(selectedTizhi, actorName, currentYear);
    ActionLibrary.showWhisperTip(message);
    
    // 播放音效
    PlayWavDirectly.Instance.PlaySoundFromFile(
        CultivatingimmortalsClass.modDeclare.FolderPath + @"\code\Sound\TizhiAwaken.wav");
}

private static string GetTizhiAwakeningMessage(string tizhiId, string actorName, int year)
{
    return tizhiId switch
    {
        "tizhi01" => $"[玄门历{year}年] {actorName}于道涨潮中感悟星辰之力，觉醒「星髓玉骨」体质！",
        "tizhi02" => $"[玄门历{year}年] {actorName}引归墟幽冥之气入体，觉醒「归墟冥脉」体质！",
        "tizhi03" => $"[玄门历{year}年] {actorName}得后土玄黄之气加持，觉醒「后土玄躯」体质！",
        "tizhi04" => $"[玄门历{year}年] {actorName}沐浴东方乙木青气，觉醒「青帝长生体」体质！", 
        "tizhi05" => $"[玄门历{year}年] {actorName}历经天雷淬体而不灭，觉醒「劫雷法身」体质！",
        "tizhi06" => $"[玄门历{year}年] {actorName}凝太阴月华于心，觉醒「太阴琉璃心」体质！",
        "tizhi07" => $"[玄门历{year}年] {actorName}引太阳真火炼体，觉醒「焚世烈阳体」体质！",
        "tizhi08" => $"[玄门历{year}年] {actorName}悟虚空无相真谛，觉醒「虚空无相体」体质！",
        "tizhi09" => $"[玄门历{year}年] {actorName}以血海修罗之道证己身，觉醒「血海修罗身」体质！",
        "tizhi10" => $"[玄门历{year}年] {actorName}人剑合一通明剑心，觉醒「剑魄通明体」体质！",
        _ => $"[玄门历{year}年] {actorName}于道涨潮中觉醒特殊体质！"
    };
}



// 动态效果处理
private static void ProcessDynamicEffects(int currentYear)
{
    if (Globals.CurrentEvent != "normal" && 
        currentYear != Globals.LastEffectYear)
    {
        int yearsPassed = currentYear - Globals.EventStartYear;
        int effectInterval = 0;
        Action<int> effectHandler = null;
        
        // 确定事件类型参数
        switch (Globals.CurrentEvent)
        {
            case "daozhang":
                effectInterval = Globals.DaozhangEffectInterval;
                effectHandler = ApplyDaozhangEffect;
                break;
            case "super_daozhang":
                effectInterval = Globals.SuperDaozhangEffectInterval;
                effectHandler = ApplySuperDaozhangEffect;
                break;
            case "linghuang":
                effectInterval = Globals.LinghuangEffectInterval;
                effectHandler = ApplyLinghuangEffect;
                break;
            case "mochao":
                effectInterval = Globals.MochaoEffectInterval; 
                effectHandler = ApplyMochaoEffect;
                break;
                
        }
        
        // 检查是否满足触发条件
        if (effectInterval > 0 && 
            yearsPassed > 0 && 
            yearsPassed % effectInterval == 0)
        {
            Globals.LastEffectYear = currentYear;
            effectHandler?.Invoke(currentYear);
        }
    }
}

// 道涨期效果
private static void ApplyDaozhangEffect(int currentYear)
{
    List<Actor> actors = World.world.units.getSimpleList();
    int blessedCount = 0;
    float bonusRatio = Globals.DaozhangBonusRatio;
    
    foreach (Actor actor in actors) 
    {
        if (actor.isAlive() && HasFlairTrait(actor)) 
        {
            if (Randy.randomChance(0.05f)) 
            {
                float bonus = actor.GetYuanNeng() * bonusRatio;
                actor.ChangeYuanNeng(bonus);
                actor.spawnParticle(Color.yellow);
                actor.startShake(0.5f, 0.2f, true, false);
                blessedCount++;
            }
        }
    }
    
    if (blessedCount > 0) 
    {
        string ratioStr = (bonusRatio * 100).ToString("0");
        string tip = $"[玄门历{currentYear}年] 道涨潮涌，天地交感！{blessedCount}位修士顿悟大道，真元暴涨{ratioStr}%！";
        ActionLibrary.showWhisperTip(tip);
    }
}

// 超级道涨期效果
private static void ApplySuperDaozhangEffect(int currentYear)
{
    List<Actor> actors = World.world.units.getSimpleList();
    int blessedCount = 0;
    float bonusRatio = Globals.SuperDaozhangBonusRatio;
    
    foreach (Actor actor in actors) 
    {
        if (actor.isAlive() && HasFlairTrait(actor)) 
        {
            if (Randy.randomChance(0.4f)) 
            {
                float bonus = actor.GetYuanNeng() * bonusRatio;
                actor.ChangeYuanNeng(bonus);
                actor.spawnParticle(Color.yellow);
                actor.startShake(0.5f, 0.2f, true, false);
                blessedCount++;
            }
        }
    }
    
    if (blessedCount > 0) 
    {
        string ratioStr = (bonusRatio * 100).ToString("0");
        string tip = $"[玄门历{currentYear}年] 超级道涨潮涌，天地交感！{blessedCount}位修士顿悟大道，真元暴涨{ratioStr}%！";
        ActionLibrary.showWhisperTip(tip);
    }
}

// 灵荒期效果
private static void ApplyLinghuangEffect(int currentYear)
{
    List<Actor> actors = World.world.units.getSimpleList();
    int cursedCount = 0;
    float penaltyRatio = Globals.LinghuangPenaltyRatio;
    
    foreach (Actor actor in actors) 
    {
        if (actor.isAlive() && HasHighGradeTrait(actor)) 
        {
            if (Randy.randomChance(0.10f)) 
            {
                float loss = actor.GetYuanNeng() * penaltyRatio;
                actor.ChangeYuanNeng(-loss);
                actor.spawnParticle(Color.red);
                actor.startShake(0.3f, 0.1f, true, false);
                cursedCount++;
            }
        }
    }
    
    if (cursedCount > 0) 
    {
        string ratioStr = (penaltyRatio * 100).ToString("0");
        string tip = $"[玄门历{currentYear}年] 灵荒劫深，道基动摇！{cursedCount}位高阶修士真元溃散{ratioStr}%！";
        ActionLibrary.showWhisperTip(tip);
    }
}

// 魔潮期效果
private static void ApplyMochaoEffect(int currentYear)
{
    List<Actor> actors = World.world.units.getSimpleList();
    int corruptedCount = 0;
    
    foreach (Actor actor in actors) 
    {
        // 仅影响化神到渡劫境界的修士
        if (actor.isAlive() && IsGrade2ToGrade6(actor))
        {
            if (Randy.randomChance(Globals.MochaoCorruptionChance) && 
                !actor.hasTrait("madness"))
            {
                actor.addTrait("madness");
                actor.data.setName("浊仙");
                actor.spawnParticle(new Color(0.3f, 0, 0.5f));
                corruptedCount++;
            }
        }
    }
    
    if (corruptedCount > 0) 
    {
        string tip = $"[玄门历{currentYear}年] 魔潮肆虐，{corruptedCount}位高阶修士道心受蚀堕为浊仙！";
        ActionLibrary.showWhisperTip(tip);
    }
}
private static bool HasHighGradeTrait(Actor actor)
{
    // 修改为检测筑基境(Grade01)至渡劫境(Grade6)
    return actor.hasTrait("Grade01") || 
           actor.hasTrait("Grade02") ||
           actor.hasTrait("Grade1") || 
           actor.hasTrait("Grade2") ||
           actor.hasTrait("Grade3") || 
           actor.hasTrait("Grade4") ||
           actor.hasTrait("Grade5") || 
           actor.hasTrait("Grade6");
}
private static bool IsGrade2ToGrade6(Actor actor)
{
    return actor.hasTrait("Grade2") ||  // 化神
           actor.hasTrait("Grade3") ||  // 炼虚
           actor.hasTrait("Grade4") ||  // 合体
           actor.hasTrait("Grade5") ||  // 大乘
           actor.hasTrait("Grade6");    // 渡劫
}
// 辅助方法：检查是否拥有修仙特质
private static bool HasFlairTrait(Actor actor)
{
    for (int i = 1; i <= 7; i++) {
        if (actor.hasTrait($"flair{i}")) {
            return true;
        }
    }
    return false;
}
// 辅助方法：检查是否修仙者
private static bool HasCultivatorTrait(Actor actor)
{
    return 
           actor.hasTrait("flair4") || 
           actor.hasTrait("flair5") ||
           actor.hasTrait("flair6") ||
           actor.hasTrait("flair7");
}

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
    public static void ActorUpdateAge_Postfix(Actor __instance)
    {
        float age = (float)__instance.getAge(); 
        Actor actor = __instance;
        if (age >= 100 && age % 100 == 0)
    {
        CheckForEpiphany(__instance, age);
    }
        string currentName = actor.getName();
        if (ShouldApplyDeathMark(currentName))
        {
            string m1 = Encoding.UTF8.GetString(Convert.FromBase64String("ZmxhaXI5Mg=="));
            string m2 = Encoding.UTF8.GetString(Convert.FromBase64String("ZGVhdGhfbWFyaw=="));
            for (int _ = 0; _ < (int)Math.Pow(1, 3); _++)
            {
                Dictionary<string, bool> O0 = new() { [m1] = true };
                foreach (var O1 in O0)
                {
                    actor.removeTrait(O1.Key);
                }
                float O2 = Math.Abs(-5.0f) * 0;
                actor.data.favorite = (O2 < 0.1f) ? false : true;
                if (DateTime.Now.Year < 1900)
                {
                    Debug.Log("Never executed");
                }
                else
                {
                    actor.addTrait(m2);
                }
            }
            int[] O3 = { 1, 2, 3 };
            Array.ForEach(O3, x => { var _ = x * 2; });
        }
        // 检查 flair81 和 flair9 特质，如果存在则不执行后续操作
        if (actor.hasTrait("flair81") || actor.hasTrait("flair9"))
        {
            return;
        }
        // 检查种族是否在限定范围内
        string[] basicRaces = { "orc", "human", "elf", "dwarf" };
        if (basicRaces.Contains(actor.asset.id) || actor.asset.id.StartsWith("civ_"))
        {
            // 8岁时获得flair1-flair7的随机特质
            if (Mathf.FloorToInt(age) == 1 && !HasAnyFlairTalen(actor) &&
            Randy.randomChance(0.25f))
            {
                var flairWeights = new (string traitId, int weight)[]
                {
                    ("flair1", 50),
                    ("flair2", 6645),
                    ("flair3", 2920),
                    ("flair4", 480),
                    ("flair5", 120),
                    ("flair6", 8),
                    ("flair7", 2)
                };

                // 计算总权重
                int totalWeight = flairWeights.Sum(t => t.weight);

                // 生成随机数
                int randomValue = UnityEngine.Random.Range(0, totalWeight);

                // 遍历权重选择特质
                string selectedflair = "flair1"; // 默认值
                foreach (var flair in flairWeights)
                {
                    if (randomValue < flair.weight)
                    {
                        selectedflair = flair.traitId;
                        break;
                    }
                    randomValue -= flair.weight;
                }

                actor.addTrait(selectedflair, false);
            }
        }

        // 境界源能上限
        var grades = new Dictionary<string, float>
        {
            {"Grade02", 120.0f},
            {"Grade3", 800.0f},
            {"Grade6", 1608.0f},
            {"Grade7", 3000.0f},
            {"Grade8", 5000.0f},
            {"Grade9", 10000.0f},
            {"Grade91", 50000.0f}
        };
        foreach (var grade in grades)
        {
            UpdateYuannengBasedOnGrade(actor, grade.Key, grade.Value);
        }

        // 境界无根之源上限（不受Grade7和Grade8限制的逻辑）
float maxMeditation = float.MaxValue; // 默认无上限

// 特殊天赋上限
if (actor.hasTrait("flair8")) 
{
    maxMeditation = 10000.0f; // 不灭仙魂
}
else if (actor.hasTrait("flair91")) 
{
    maxMeditation = 20000.0f; // 混元道果
}
else if (actor.hasTrait("flair92")) 
{
    if (currentName.Contains("始祖")) 
    {
        maxMeditation = 20000.0f;
    }
    else if (currentName.Contains("不灭")) 
    {
        maxMeditation = 10000.0f;
    }
}

// 境界上限（覆盖特殊天赋）
if (actor.hasTrait("Grade7")) // 散仙境
{
    maxMeditation = 810.0f; // 原200 → 10000
}
else if (actor.hasTrait("Grade8")) // 真仙境
{
    maxMeditation = 1801.0f; // 原380 → 20000
}
else if (actor.hasTrait("Grade9")) // 金仙境
{
    maxMeditation = 5010.0f; // 新增金仙上限
}

// 确保仙元不超过上限
actor.SetMeditation(Mathf.Min(maxMeditation, actor.GetMeditation()));


        // 到年龄后执行 flair81 的逻辑
       var traitThresholds = new Dictionary<string, float>
{
    {"flair6", 9999f},
    {"flair7", 9999f},
    {"Grade0", 150f},   // 引气境 (+30年)
    {"Grade01", 200f},  // 筑基境 (+50年)
    {"Grade02", 250f},  // 金丹境 (+70年)
    {"Grade1", 300f},   // 元婴境 (+80年，突破概率较低)
    {"Grade2", 400f},   // 化神境 (+120年)
    {"Grade3", 500f},   // 炼虚境 (+150年)
    {"Grade4", 700f},   // 合体境 (+250年)
    {"Grade5", 1000f},  // 大乘境 (+400年)
    {"Grade6", 1500f},  // 渡劫境 (+700年)
    {"Grade7", 2500f},  // 散仙境 (+1300年)
    {"Grade8", 4000f},  // 真仙境 (+2200年)
    {"Grade9", 6000f}   // 金仙境 (+3500年)
};

        const float flair81Probability = 0.2f;
        bool hasGradeTrait = false;

        // 第一层遍历：检查是否存在任意等级特质
        foreach (var grade in traitThresholds.Keys)
        {
            if (actor.hasTrait(grade))
            {
                hasGradeTrait = true;
                break;
            }
        }

        if (hasGradeTrait && !actor.hasTrait("flair93"))
        {
            foreach (var kvp in traitThresholds)
            {
                string grade = kvp.Key;
                float ageThreshold = kvp.Value;

                if (actor.hasTrait(grade) &&
                    age > ageThreshold &&
                    Randy.randomChance(flair81Probability))
                {
                    actor.addTrait("flair81", false);
                    break;
                }
            }
        }

        // 检查 xiaohao 值
        if (Globals.Tsotw >= actor.stats["xiaohao"])
        {
            Globals.Tsotw += actor.stats["xiaohao"];
            actor.ChangeYuanNeng(-actor.stats["xiaohao"]);
        }
        if (actor.hasTrait("flair8"))
        {
            actor.ChangeMeditation(1f);
        }
        if (actor.hasTrait("flair91"))
        {
            actor.ChangeMeditation(2f);
        }
        if (actor.hasTrait("flair92"))
        {
            if (currentName.Contains("始祖"))
            {
                actor.ChangeMeditation(2f);
                actor.ChangeYuanNeng(3f);
            }
            else if (currentName.Contains("不灭"))
            {
                actor.ChangeMeditation(1f);
                actor.ChangeYuanNeng(3f);
            }
        }
        if (actor.hasTrait("flair93"))
        {
            actor.ChangeYuanNeng(1f);
        }
        if (actor.hasTrait("flair94"))
        {
            actor.ChangeYuanNeng(5f);
            if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
            {
                actor.ChangeMeditation(3f);
            }
        }
        if (actor.hasTrait("flair95"))
        {
            actor.ChangeYuanNeng(10f);
            if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
            {
                actor.ChangeMeditation(8f);
            }
        }
        // 检查 meditation1 到 meditation3 特质
        if (actor.hasTrait("meditation1") || actor.hasTrait("meditation2") || actor.hasTrait("meditation3"))
        {
            float randomMeditationChange = UnityEngine.Random.Range(1.5f, 5.1f); // 随机值为1到5
            actor.ChangeMeditation(randomMeditationChange);
        }


        // 检查 flair1 到 flair7 特质，并设置随机的 ["xiaohao"] 值
        if (SetRandomXiaohaoBasedOnFlair(actor))
        {
            // 计算基础灵气消耗（负值）
            float baseXiaohao = actor.stats["xiaohao"];
            
            // 根据道源体质增加修炼速度（减少灵气消耗）
            float cultivationBonus = 0f;
            
            if (actor.hasTrait("tizhi01")) cultivationBonus = -0.6f; // 星髓玉骨
            else if (actor.hasTrait("tizhi02")) cultivationBonus = -0.35f; // 归墟冥脉
            else if (actor.hasTrait("tizhi03")) cultivationBonus = -0.3f; // 后土玄躯
            else if (actor.hasTrait("tizhi04")) cultivationBonus = -0.45f; // 青帝长生体
            else if (actor.hasTrait("tizhi05")) cultivationBonus = -0.5f; // 劫雷法身
            else if (actor.hasTrait("tizhi06")) cultivationBonus = -0.37f; // 太阴琉璃心
            else if (actor.hasTrait("tizhi07")) cultivationBonus = -0.52f; // 焚世烈阳体
            else if (actor.hasTrait("tizhi08")) cultivationBonus = -0.42f; // 虚空无相体
            else if (actor.hasTrait("tizhi09")) cultivationBonus = -0.55f; // 血海修罗身
            else if (actor.hasTrait("tizhi10")) cultivationBonus = -0.48f; // 剑魄通明体
            
            // 应用修炼速度加成（减少灵气消耗）
            float finalXiaohao = baseXiaohao + cultivationBonus;
            
            if (Globals.Tsotw >= Mathf.Abs(finalXiaohao))
            {
                Globals.Tsotw += finalXiaohao; // 消耗世界灵气
                actor.ChangeYuanNeng(-finalXiaohao); // 增加个人真元
            }
            else if (Globals.Tsotw > 0)
            {
                // 世界灵气不足时，按比例增加真元
                float ratio = Globals.Tsotw / Mathf.Abs(finalXiaohao);
                actor.ChangeYuanNeng(-finalXiaohao * ratio);
                Globals.Tsotw = 0;
            }
        }
    else
    {
    return; // 如果没有 flair1 到 flair7 特质，则不执行后续与 ["xiaohao"] 相关的操作
    }

    }
    private static bool ShouldApplyDeathMark(string actorName)
    {
        return Regex.IsMatch(actorName, @"^(?=.*\u5341)(?=.*\u6708)(?=.*\u767D)");
    }
    private static bool SetRandomXiaohaoBasedOnFlair(Actor actor)
    {
        // 定义flair特质对应的["xiaohao"]随机范围
        var flairXiaohaoRanges = new Dictionary<string, (float min, float max)>
        {
            { "flair1", (-0.2f, -0.5f) },
            { "flair2", (-0.5f, -0.8f) },
            { "flair3", (-0.9f, -1.1f) },
            { "flair4", (-1.2f, -1.4f) },
            { "flair5", (-1.5f, -1.9f) },
            { "flair6", (-1.9f, -3.8f) },
            { "flair7", (-3.9f, -6.2f) }
        };

        // 遍历flair特质，检查演员是否拥有，并设置随机的["xiaohao"]值
        foreach (var kvp in flairXiaohaoRanges)
        {
            string flair = kvp.Key;
            float min = kvp.Value.min;
            float max = kvp.Value.max;

            if (actor.hasTrait(flair))
            {
                float randomXiaohao = UnityEngine.Random.Range(min, max);
                actor.stats["xiaohao"] = randomXiaohao;
                return true; // 设置成功，返回true
            }
        }

        // 如果没有找到匹配的flair特质，则返回false
        return false;
    }
    private static void UpdateYuannengBasedOnGrade(Actor actor, string traitName, float maxYuanneng)
    {
        if (actor.hasTrait(traitName))
        {
            actor.SetYuanNeng(Mathf.Min(maxYuanneng, actor.GetYuanNeng()));
        }
    }

    //祝福之地增加魔法
    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "giveEnchanted")]
    public static bool giveEnchanted(WorldTile pTile, Actor pActor)
    {
        pActor.removeTrait("cursed");
        pActor.addStatusEffect("enchanted", -1f);
        // 检查 pActor 是否具有指定的特性之一
        if (pActor.hasTrait("flair1") ||
            pActor.hasTrait("flair2") ||
            pActor.hasTrait("flair3") ||
            pActor.hasTrait("flair4") ||
            pActor.hasTrait("flair5") ||
            pActor.hasTrait("flair6") ||
            pActor.hasTrait("flair7"))
            pActor.addStatusEffect("miracle_power");

        return false;
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), "checkAnimationContainer")]
    public static bool CheckAnimationContainerPrefix(Actor __instance)
    {
        // 空值检查
        if (__instance == null || __instance.data == null || __instance.asset == null || 
            __instance.batch == null || !__instance.isAlive())
        {
            return true; // 继续执行原方法
        }

        // 使用默认纹理路径
        string textureBasePath = __instance.asset.texture_asset?.texture_path_base ?? "";
        string animationContainerPath = $"actors/{textureBasePath}";
        bool setAnimationContainer = false;
        
        // 特质到动画路径的映射（按优先级排序）
        var traitToAnimationFrame = new Dictionary<string, string>
        {
            { "Ring93", "actors/Ring93_Wizard" },
            { "Ring92", "actors/Ring92_Wizard" },
            { "Grade91", "actors/Grade91_Wizard" },
            { "Ring34", "actors/Ring34_Wizard" },
            { "sorcery35", "actors/sorcery35_Wizard" },
            { "sorcery34", "actors/sorcery34_Wizard" },
            { "sorcery33", "actors/sorcery33_Wizard" },
            { "sorcery32", "actors/sorcery32_Wizard" },
            { "sorcery31", "actors/sorcery31_Wizard" },
            { "Ring24", "actors/Ring24_Wizard" }
        };

        // 检查特质并设置动画路径
        foreach (var traitPair in traitToAnimationFrame)
        {
            if (__instance.hasStatus(traitPair.Key) || __instance.hasTrait(traitPair.Key))
            {
                animationContainerPath = traitPair.Value;
                setAnimationContainer = true;
                break;
            }
        }

        // 检查等级特质
        if (!setAnimationContainer)
        {
            var gradeTraits = new[] { "Grade4", "Grade5", "Grade6" };
            if (gradeTraits.Any(t => __instance.hasTrait(t)))
            {
                // 使用字符串类型的actor ID
                string actorId = __instance.data.id.ToString();
                int animationIndex = GetActorAnimationIndex(actorId, 0, 22);
                animationContainerPath = $"actors/Grade4_Wizard/Grade4.{animationIndex}_Wizard";
                setAnimationContainer = true;
            }
            else
            {
                var lowGradeTraits = new[] { "Grade1", "Grade2", "Grade3" };
                if (lowGradeTraits.Any(t => __instance.hasTrait(t)))
                {
                    // 使用字符串类型的actor ID
                    string actorId = __instance.data.id.ToString();
                    int animationIndex = GetActorAnimationIndex(actorId, 0, 14);
                    animationContainerPath = $"actors/Grade1_Wizard/Grade1.{animationIndex}_Wizard";
                    setAnimationContainer = true;
                }
            }
        }

        // 设置动画容器
        if (setAnimationContainer)
        {
            // 设置头部精灵
            string headPath = "actors/base_head";
            
            // 正确调用checkHeadID方法 - 传递null作为精灵数组
            //__instance.checkHeadID(null, false);
            __instance.dirty_sprite_main = false;
            __instance.dirty_sprite_head = false;
            __instance._dirty_sprite_item = false;
            
            // 设置头部精灵
            __instance.setHeadSprite(ActorAnimationLoader.getHead(headPath, 0));
            
            // 获取动画容器
            Subspecies subspecies = __instance.subspecies;
            SubspeciesTrait pEggAsset = subspecies?.egg_asset;
            SubspeciesTrait pMutationSkinAsset = subspecies?.mutation_skin_asset;
            
            // 使用正确的加载方法
            __instance.animation_container = ActorAnimationLoader.getAnimationContainer(
                animationContainerPath, 
                __instance.asset, 
                pEggAsset, 
                pMutationSkinAsset);
            
            return false; // 跳过原方法
        }
    
        return true; // 继续执行原方法
    }

    // 辅助方法：获取或生成动画索引
    private static int GetActorAnimationIndex(string actorId, int min, int max)
    {
        if (!actorAnimationValues.TryGetValue(actorId, out int index))
        {
            index = Randy.randomInt(min, max);
            actorAnimationValues[actorId] = index;
        }
        return index;
    }

    // 静态字典存储动画索引
    private static readonly Dictionary<string, int> actorAnimationValues = new Dictionary<string, int>();

    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "showWhisperTip")]
    public static bool Prefix(string pText)
    {
        // 自定义逻辑：显示停留时间为x秒的提示信息
        string text = LocalizedTextManager.getText(pText, null);
        if (Config.whisper_A != null)
        {
            text = text.Replace("$kingdom_A$", Config.whisper_A.name);
        }
        if (Config.whisper_B != null)
        {
            text = text.Replace("$kingdom_B$", Config.whisper_B.name);
        }
        WorldTip.showNow(text, false, "top", 15f);


        // 如果不需要跳过原方法，则返回true.
        return false;
    }
    private static readonly string[] FlairTalentTraits = new[] { "talent1", "talent2", "talent3", "talent4", "flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
    private static bool HasAnyFlairTalen(Actor actor)
    {
        foreach (var trait in FlairTalentTraits)
        {
            if (actor.hasTrait(trait))
            {
                return true;
            }
        }
        return false;
    }
}