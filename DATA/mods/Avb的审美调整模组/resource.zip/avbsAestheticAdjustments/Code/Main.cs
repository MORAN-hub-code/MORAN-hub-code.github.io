using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;
using ai.behaviours;

namespace aaaMod{
    class Main : BasicMod<Main>{
        public static Main instance;
        static Harmony _harmony;
        protected override void OnModLoad(){
            if (Configs.UnevoColor == true){
                CreaturesPowersUnevo.init();
            }
            if (Configs.EvoColor == true){
                CreaturesPowersEvo.init();
            }
            OtherAssetEdits.init();
            _harmony = new Harmony("AvbCCC");
            _harmony.PatchAll();
        }
    }
    public class CheckIcons{
        public static void checkOtherPowerButtons()
        {
            foreach (PowerButton power in PowerButton.power_buttons)
            {
                PowerButton tButton = power;
                if (tButton.godPower.path_icon != null)
                {
                    tButton.icon.sprite = SpriteTextureLoader.getSprite($"ui/Icons/" + tButton.godPower.path_icon);
                }
                if (tButton == null){
                    break;
                }
                if (tButton.godPower.type == PowerActionType.PowerSpawnBuilding){   
                    tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/buildingbutton");
                }
                if (tButton.godPower.id.Contains("printer")){   
                    tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/terraformerbuttonEmpty");
                }
            }
        }	
    }
    [HarmonyPatch(typeof(ToolbarButtons), "Update")]
	public class buttonIconPatchMain{
		static bool Prefix()
    	{
            if (Time.frameCount % 30 == 0)
            {
                CheckIcons.checkOtherPowerButtons();
                PowerButton.checkActorSpawnButtons();
            }
            return false;
        }
    }
    [HarmonyPatch(typeof(PowerButton), "checkActorSpawnButtons")]
	public class buttonIconPatchActors{
		static bool Prefix()
    	{
            Color tColorNoPopulation = new Color(0.75f, 0.75f, 0.75f, 0.9f);
            foreach (KeyValuePair<ActorAsset, PowerButton> tPair in PowerButton.actor_spawn_buttons)
            {
                ActorAsset tAsset = tPair.Key;
                PowerButton tButton = tPair.Value;
                if (tAsset.isAvailable())
                {
                    if (tButton.godPower.path_icon != null)
                    {
                        tButton.icon.sprite = SpriteTextureLoader.getSprite($"ui/Icons/" + tButton.godPower.path_icon);
                    }
                    if (tAsset.countPopulation() > 0 || tButton.godPower.id == "crabzilla")
                    {
                        if (tButton.godPower.id.Contains("civ") || tButton.godPower.id == "bandit"){   
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/evolvedbuttonExist");
                        }
                        else if (tButton.godPower.id == "human" || tButton.godPower.id == "elf" || tButton.godPower.id == "orc" || tButton.godPower.id == "dwarf"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/goldbuttonExist");
                        }
                        else if (tButton.godPower.id == "evil_mage" || tButton.godPower.id == "white_mage" || tButton.godPower.id == "druid" || tButton.godPower.id == "necromancer" || tButton.godPower.id == "plague_doctor"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/magebuttonExist");
                        }
                        else if (tButton.godPower.id.Contains("ant_") || tButton.godPower.id == "god_finger" || tButton.godPower.id == "worm" || tButton.godPower.id == "sand_spider"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/terraformerbuttonExist");
                        }
                        else if (tButton.godPower.id == "greg"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/gregbuttonExist");
                        }
                        else if (tButton.godPower.id == "crabzilla"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/crabzillabuttonBoth");
                        }
                        else {
                            tButton._image.sprite = ToolbarButtons.getSpriteButtonUnitExists();
                        }
                        tButton.icon.color = Toolbox.color_white;
                    }
                    else
                    {
                        if (tButton.godPower.id.Contains("civ") || tButton.godPower.id == "bandit"){   
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/evolvedbuttonEmpty");
                        }
                        else if (tButton.godPower.id == "human" || tButton.godPower.id == "elf" || tButton.godPower.id == "orc" || tButton.godPower.id == "dwarf"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/goldbuttonEmpty");
                        }
                        else if (tButton.godPower.id == "evil_mage" || tButton.godPower.id == "white_mage" || tButton.godPower.id == "druid" || tButton.godPower.id == "necromancer" || tButton.godPower.id == "plague_doctor"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/magebuttonEmpty");
                        }
                        else if (tButton.godPower.id.Contains("ant_") || tButton.godPower.id == "god_finger" || tButton.godPower.id == "worm" || tButton.godPower.id == "sand_spider"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/terraformerbuttonEmpty");
                        }
                        else if (tButton.godPower.id == "greg"){
                            tButton._image.sprite = SpriteTextureLoader.getSprite($"ui/Icons/gregbuttonEmpty");
                        }
                        else {
                            tButton._image.sprite = ToolbarButtons.getSpriteButtonNormal();
                        }
                        tButton.icon.color = tColorNoPopulation;
                    }
                }
                else
                {
                    tButton.icon.color = Toolbox.color_black;
                }
            }
            return false;
        }
    }
    // [HarmonyPatch(typeof(Plot), "getSprite")]
	// public class plotIconPatch{
	// 	static bool Prefix(Plot __instance, ref Sprite __result)
    // 	{
    //         string result = $"ui/Icons/" + __instance._plot_asset.path_icon;
    //         if (__instance.isFinished())
    //         {
    //             result = "plots/icons/progress/plot_finished";
    //         }
    //         if (__instance.isCancelled())
    //         {
    //             result = "plots/icons/progress/plot_cancelled";
    //         }
    //         __result = SpriteTextureLoader.getSprite(result);
    //         return false;
    //     }
    // }
}




