using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;

namespace aaaMod{
    internal static class Configs{
        public static bool UnevoColor { get; set; } = true;
        public static bool EvoColor { get; set; } = true;

        public static void TurnOffUnevoColor(bool pCurrentValue)
        {
            if (!pCurrentValue){
                UnevoColor = false;
            }
        }
        public static void TurnOffEvoColor(bool pCurrentValue)
        {
            if (!pCurrentValue){
                EvoColor = false;
            }
        }
    }
}




