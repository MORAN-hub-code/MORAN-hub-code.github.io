using System;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using System.Globalization;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;

namespace aaaMod{
    internal static class OtherAssetEdits{
        public static void init(){
//Summon Angle
            PlotAsset editAngleRite = AssetManager.plots_library.get("summon_angles");
            editAngleRite.path_icon = $"ui/Icons/angleRiteNew";
//Summon Demon
            PlotAsset editDemonRite = AssetManager.plots_library.get("summon_demons");
            editDemonRite.path_icon = $"ui/Icons/demonRiteNew";
//Summon Skeleton
            PlotAsset editSkeletonRite = AssetManager.plots_library.get("summon_skeletons");
            editSkeletonRite.path_icon = $"ui/Icons/skeletonRiteNew";
//Summon Living Plants
            PlotAsset editLivingPlantRite = AssetManager.plots_library.get("summon_living_plants");
            editLivingPlantRite.path_icon = $"ui/Icons/livingplantRiteNew";
//Join Alliance
            PlotAsset editAllianceJoin = AssetManager.plots_library.get("alliance_join");
            editAllianceJoin.path_icon = $"ui/Icons/plot_alliance_joinNew";
//Cloud Acid
            GodPower editCloudAcidPower = AssetManager.powers.get("cloud_acid");
            editCloudAcidPower.path_icon  = "iconCloudAcidNew";
//Cloud Lava
            GodPower editCloudLavaPower = AssetManager.powers.get("cloud_lava");
            editCloudLavaPower.path_icon  = "iconCloudLavaNew";
//Cloud Rain
            GodPower editCloudRainPower = AssetManager.powers.get("cloud_rain");
            editCloudRainPower.path_icon  = "iconCloudRainNew";
//Sponge
            GodPower editSpongePower = AssetManager.powers.get("sponge");
            editSpongePower.path_icon  = "iconSpongeNew";

            LocalizedTextManager.add("sponge", "Broom", true, "", true);
//Sickle
            GodPower editSicklePower = AssetManager.powers.get("sickle");
            editSicklePower.path_icon  = "iconSickleNew";
//Pickaxe
            GodPower editPickaxePower = AssetManager.powers.get("pickaxe");
            editPickaxePower.path_icon  = "iconPickaxeNew";
//Axe
            GodPower editAxePower = AssetManager.powers.get("axe");
            editAxePower.path_icon  = "iconAxeNew";
//Atomic Bomb
            GodPower editAtomicBombPower = AssetManager.powers.get("atomic_bomb");
            editAtomicBombPower.path_icon  = "iconAtomicBombNew";
//SpiteFix
            GodPower fixSpitePower = AssetManager.powers.get("spite");
            fixSpitePower.path_icon  = "iconSpite";
//FingerFix
            GodPower fixFingerPower = AssetManager.powers.get("finger");
            fixFingerPower.path_icon  = "iconFinger";
//LootRainEditFix
            GodPower fixLootRainEditPower = AssetManager.powers.get("equipment_rain_edit");
            fixLootRainEditPower.path_icon  = "iconRainLootEdit";
//GammaRainFix
            GodPower fixGammaRainPower = AssetManager.powers.get("traits_gamma_rain");
            fixGammaRainPower.path_icon  = "iconRainGamma";
//OmegaRainFix
            GodPower fixOmegaRainPower = AssetManager.powers.get("traits_omega_rain");
            fixOmegaRainPower.path_icon  = "iconRainOmega";
//DeltaRainFix
            GodPower fixDeltaRainPower = AssetManager.powers.get("traits_delta_rain");
            fixDeltaRainPower.path_icon  = "iconRainDelta";

//Phenotype Locale Edits-------------------------------------------------------------------------------------------------------
            foreach (PhenotypeAsset pt in AssetManager.phenotype_library.list){
                SubspeciesTrait pt2 = AssetManager.subspecies_traits.get($"phenotype_skin_{pt.id}");
                pt2.special_locale_id = $"pt_{pt.id}";
                LocalizedTextManager.add(pt2.special_locale_id, OtherAssetEdits.fixLowercaseAndUnderscore(pt.id), false, "", true);
            }
        }
        public static string fixLowercaseAndUnderscore(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }
            string inputSpaced = input.Replace("_", " ");
            int firstlettercount = 0;
            bool needsCapitalized = false;
            StringBuilder stringBuilder = new StringBuilder();
            foreach (char i in inputSpaced)
            {
                firstlettercount++;
                if (firstlettercount == 1)
                {
                    stringBuilder.Append(char.ToUpper(i));
                }
                if (char.IsWhiteSpace(i))
                {
                    stringBuilder.Append(i);
                    needsCapitalized = true;
                }
                else if (needsCapitalized)
                {
                    stringBuilder.Append(char.ToUpper(i));
                    needsCapitalized = false;
                }
                else if (firstlettercount != 1)
                {
                    stringBuilder.Append(i);
                }
            }
            return stringBuilder.ToString();
		}
    }	
}





