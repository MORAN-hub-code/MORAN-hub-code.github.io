using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using NeoModLoader.General;
using System.Collections.Generic;
using NCMS.Utils;
using UnityEngine.UI;
using UnityEngine.Analytics;
using JetBrains.Annotations;
using static UnityEngine.GraphicsBuffer;
using System.IO;
using System.Text;
using System.Collections;
using UnityEngine;
using NeoModLoader.api;
using NeoModLoader.api.attributes;

namespace aaaMod{
    internal static class CreaturesPowersUnevo{
        public static void init(){
//Cat
            ActorAsset editCatActor = AssetManager.actor_library.get("cat");
            editCatActor.icon = "iconCatNew";

            GodPower editCatPower = AssetManager.powers.get("cat");
            editCatPower.path_icon  = "iconCatNew";
//Dog
            ActorAsset editDogActor = AssetManager.actor_library.get("dog");
            editDogActor.icon = "iconDogNew";

            GodPower editDogPower = AssetManager.powers.get("dog");
            editDogPower.path_icon  = "iconDogNew";
//Chicken
            ActorAsset editChickenActor = AssetManager.actor_library.get("chicken");
            editChickenActor.icon = "iconChickenNew";

            GodPower editChickenPower = AssetManager.powers.get("chicken");
            editChickenPower.path_icon  = "iconChickenNew";
//Rabbit
            ActorAsset editRabbitActor = AssetManager.actor_library.get("rabbit");
            editRabbitActor.icon = "iconRabbitNew";

            GodPower editRabbitPower = AssetManager.powers.get("rabbit");
            editRabbitPower.path_icon  = "iconRabbitNew";
//Monkey
            ActorAsset editMonkeyActor = AssetManager.actor_library.get("monkey");
            editMonkeyActor.icon = "iconMonkeyNew";

            GodPower editMonkeyPower = AssetManager.powers.get("monkey");
            editMonkeyPower.path_icon  = "iconMonkeyNew";
//Fox
            ActorAsset editFoxActor = AssetManager.actor_library.get("fox");
            editFoxActor.icon = "iconFoxNew";

            GodPower editFoxPower = AssetManager.powers.get("fox");
            editFoxPower.path_icon  = "iconFoxNew";
//Sheep
            ActorAsset editSheepActor = AssetManager.actor_library.get("sheep");
            editSheepActor.icon = "iconSheepNew";

            GodPower editSheepPower = AssetManager.powers.get("sheep");
            editSheepPower.path_icon  = "iconSheepNew";
//Cow
            ActorAsset editCowActor = AssetManager.actor_library.get("cow");
            editCowActor.icon = "iconCowNew";

            GodPower editCowPower = AssetManager.powers.get("cow");
            editCowPower.path_icon  = "iconCowNew";
//Armadillo (skipped)
//Raccoon
            ActorAsset editRaccoonActor = AssetManager.actor_library.get("raccoon");
            editRaccoonActor.icon = "iconRaccoonNew";

            GodPower editRaccoonPower = AssetManager.powers.get("raccoon");
            editRaccoonPower.path_icon  = "iconRaccoonNew";
//-------------------------------------------------------------------------------------------------------
//Wolf
            ActorAsset editWolfActor = AssetManager.actor_library.get("wolf");
            editWolfActor.icon = "iconWolfNew";

            GodPower editWolfPower = AssetManager.powers.get("wolf");
            editWolfPower.path_icon  = "iconWolfNew";
//Bear
            ActorAsset editBearActor = AssetManager.actor_library.get("bear");
            editBearActor.icon = "iconBearNew";

            GodPower editBearPower = AssetManager.powers.get("bear");
            editBearPower.path_icon  = "iconBearNew";
//Rhino
            ActorAsset editRhinoActor = AssetManager.actor_library.get("rhino");
            editRhinoActor.icon = "iconRhinoNew";

            GodPower editRhinoPower = AssetManager.powers.get("rhino");
            editRhinoPower.path_icon  = "iconRhinoNew";
//Buffalo
            ActorAsset editBuffaloActor = AssetManager.actor_library.get("buffalo");
            editBuffaloActor.icon = "iconBuffaloNew";

            GodPower editBuffaloPower = AssetManager.powers.get("buffalo");
            editBuffaloPower.path_icon  = "iconBuffaloNew";
//Hyena
            ActorAsset editHyenaActor = AssetManager.actor_library.get("hyena");
            editHyenaActor.icon = "iconHyenaNew";

            GodPower editHyenaPower = AssetManager.powers.get("hyena");
            editHyenaPower.path_icon  = "iconHyenaNew";
//Rat
            ActorAsset editRatActor = AssetManager.actor_library.get("rat");
            editRatActor.icon = "iconRatNew";

            GodPower editRatPower = AssetManager.powers.get("rat");
            editRatPower.path_icon  = "iconRatNew";
//Alpaca
            ActorAsset editAlpacaActor = AssetManager.actor_library.get("alpaca");
            editAlpacaActor.icon = "iconAlpacaNew";

            GodPower editAlpacaPower = AssetManager.powers.get("alpaca");
            editAlpacaPower.path_icon  = "iconAlpacaNew";
//Capybara
            ActorAsset editCapybaraActor = AssetManager.actor_library.get("capybara");
            editCapybaraActor.icon = "iconCapybaraNew";

            GodPower editCapybaraPower = AssetManager.powers.get("capybara");
            editCapybaraPower.path_icon  = "iconCapybaraNew";
//Penguin
            ActorAsset editPenguinActor = AssetManager.actor_library.get("penguin");
            editPenguinActor.icon = "iconPenguinNew";

            GodPower editPenguinPower = AssetManager.powers.get("penguin");
            editPenguinPower.path_icon  = "iconPenguinNew";
//-------------------------------------------------------------------------------------------------------
//Scorpion
            ActorAsset editScorpionActor = AssetManager.actor_library.get("scorpion");
            editScorpionActor.icon = "iconScorpionNew";

            GodPower editScorpionPower = AssetManager.powers.get("scorpion");
            editScorpionPower.path_icon  = "iconScorpionNew";
//Turtle
            ActorAsset editTurtleActor = AssetManager.actor_library.get("turtle");
            editTurtleActor.icon = "iconTurtleNew";

            GodPower editTurtlePower = AssetManager.powers.get("turtle");
            editTurtlePower.path_icon  = "iconTurtleNew";
//Crocodile
            ActorAsset editCrocodileActor = AssetManager.actor_library.get("crocodile");
            editCrocodileActor.icon = "iconCrocodileNew";

            GodPower editCrocodilePower = AssetManager.powers.get("crocodile");
            editCrocodilePower.path_icon  = "iconCrocodileNew";
//Snake
            ActorAsset editSnakeActor = AssetManager.actor_library.get("snake");
            editSnakeActor.icon = "iconSnakeNew";

            GodPower editSnakePower = AssetManager.powers.get("snake");
            editSnakePower.path_icon  = "iconSnakeNew";
//Frog
            ActorAsset editFrogActor = AssetManager.actor_library.get("frog");
            editFrogActor.icon = "iconFrogNew";

            GodPower editFrogPower = AssetManager.powers.get("frog");
            editFrogPower.path_icon  = "iconFrogNew";
//Piranha
            ActorAsset editPiranhaActor = AssetManager.actor_library.get("piranha");
            editPiranhaActor.icon = "iconPiranhaNew";

            GodPower editPiranhaPower = AssetManager.powers.get("piranha");
            editPiranhaPower.path_icon  = "iconPiranhaNew";
//-------------------------------------------------------------------------------------------------------
//Assimilator
            ActorAsset editAssimilatorActor = AssetManager.actor_library.get("assimilator");
            editAssimilatorActor.icon = "iconAssimilatorNew";

            GodPower editAssimilatorPower = AssetManager.powers.get("assimilator");
            editAssimilatorPower.path_icon  = "iconAssimilatorNew";
        }
    }
}




