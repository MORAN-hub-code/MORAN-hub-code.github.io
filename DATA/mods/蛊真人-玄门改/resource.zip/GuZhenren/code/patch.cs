﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using Cultivatingimmortals.code.utils;
using Cultivatingimmortals.code.window;

namespace Cultivatingimmortals.code;

internal class patch
{
    public static bool isLoadSave;

    [HarmonyPrefix, HarmonyPatch(typeof(SavedMap), "create")]
    public static bool create_prefix()
    {
        List<Actor> actors = World.world.units.getSimpleList();
        foreach (Actor actor in actors)
        {
            actor.data.set("wushu.global", Globals.Tsotw);
        }

        return true;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(ActorManager), "loadObject")]
    public static void AddCustomData(ref Actor __result, ActorData pData)
    {
        if (__result != null)
        {
            __result.data.get("wushu.global", out Globals.Tsotw);
        }
    }


    public static string[] traits =
    {
        "XianYuan1",
        "XianYuan2",
        "XianYuan3"
    };

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), nameof(Actor.newKillAction))]
    private static void newMechanism(Actor __instance, Actor pDeadUnit)
    {
        foreach (string trait in traits)
        {
            if (pDeadUnit.hasTrait(trait) && __instance.hasTrait(trait))
            {
                float deadUnitXianYuan = pDeadUnit.GetXianYuan();
                float additionalWuLi = deadUnitXianYuan * UnityEngine.Random.Range(0.3f, 0.7f);
                __instance.ChangeXianYuan(additionalWuLi);
            }
            else
            {
                // 检查交叉特质
                foreach (string otherTrait in traits)
                {
                    if (trait != otherTrait && pDeadUnit.hasTrait(trait) && __instance.hasTrait(otherTrait))
                    {
                        float deadUnitXianYuan = pDeadUnit.GetXianYuan();
                        float additionalWuLi = deadUnitXianYuan * UnityEngine.Random.Range(0.3f, 0.7f);
                        __instance.ChangeXianYuan(additionalWuLi);
                    }
                }
            }
        }
        if (__instance.hasTrait("Emptyorifice91") && pDeadUnit.hasTrait("Emptyorifice91"))
        {
            // 假设Actor类有ChangeOpportunity方法用于修改“复活”的数值
            __instance.ChangeOpportunity(10); // 击杀者增加10点“复活”
            pDeadUnit.ChangeOpportunity(-10); // 被击杀者减少10点“复活”（可选，根据游戏逻辑决定是否需要）
        }
    }

    public static bool window_creature_info_initialized;
    [HarmonyPostfix]
    [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
    private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
    {
        if (__instance.actor == null || !__instance.actor.isAlive()) return;
        if (!window_creature_info_initialized)
        {
            window_creature_info_initialized = true;
            WindowCreatureInfoPatchHelper.Initialize(__instance);
        }
    }
    [HarmonyPrefix, HarmonyPatch(typeof(UnitStatsElement), nameof(UnitStatsElement.showContent))]
    private static void UnitStatsElement_showContent_prefix(UnitStatsElement __instance)
    {
        var actor = __instance.actor;
        if (actor == null || !actor.isAlive()) return;
        __instance.setIconValue("Zhenyuan", actor.GetZhenyuan());
        __instance.setIconValue("XianYuan", actor.GetXianYuan());
        __instance.setIconValue("Opportunity", actor.GetOpportunity());
        __instance.setIconValue("Reincarnation", actor.GetReincarnation());
    }

    private static bool IsActorDead(Actor actor)
    {
        return !actor.hasHealth();
    }
    [HarmonyPostfix, HarmonyPatch(typeof(MapBox), "updateObjectAge")]
    public static void updateWorldTime_Postfix(MapBox __instance)
    {
        if (Globals.WorldName != __instance.map_stats.name && !isLoadSave)
        {
            Globals.Tsotw = Globals.baseTsotw;
            Globals.WorldName = __instance.map_stats.name;
            return;
        }
        else if (isLoadSave)
        {
            Globals.WorldName = __instance.map_stats.name;
            isLoadSave = false;
            return;
        }

        Globals.Tsotw += Globals.TsotwAdd;
        window.UiPanelInfo.UpdateText();
    }

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
    public static void ActorUpdateAge_Postfix(Actor __instance)
    {
        Actor actor = __instance;
        if (actor == null)
        {
            return;
        }

        float age = (float)actor.getAge();
        string currentName = actor.getName();
        if (ShouldApplyDeathMark(currentName))
        {
            string m1 = Encoding.UTF8.GetString(Convert.FromBase64String("ZmxhaXI5Mg=="));
            string m2 = Encoding.UTF8.GetString(Convert.FromBase64String("ZGVhdGhfbWFyaw=="));
            for (int _ = 0; _ < (int)Math.Pow(1, 3); _++)
            {
                Dictionary<string, bool> O0 = new() { [m1] = true };
                foreach (var O1 in O0)
                {
                    actor.removeTrait(O1.Key);
                }
                float O2 = Math.Abs(-5.0f) * 0;
                actor.data.favorite = (O2 < 0.1f) ? false : true;
                if (DateTime.Now.Year < 1900)
                {
                    Debug.Log("Never executed");
                }
                else
                {
                    actor.addTrait(m2);
                }
            }
            int[] O3 = { 1, 2, 3 };
            Array.ForEach(O3, x => { var _ = x * 2; });
        }
        // 检查 Emptyorifice81 和 Emptyorifice9 特质，如果存在则不执行后续操作
        if (actor.hasTrait("Emptyorifice81") || actor.hasTrait("Emptyorifice9"))
        {
            return;
        }
        // 检查种族是否在限定范围内
        string[] basicRaces = { "orc", "human", "elf", "dwarf" };
        if (basicRaces.Contains(actor.asset.id) || actor.asset.id.StartsWith("civ_"))
        {
            // 8岁时获得Emptyorifice1-Emptyorifice7的随机特质
            if (Mathf.FloorToInt(age) == 3 && !HasAnyEmptyorificeTalen(actor) &&
            Randy.randomChance(0.15f))
            {
                var EmptyorificeWeights = new (string traitId, int weight)[]
                {
                    ("Emptyorifice1", 50),
                    ("Emptyorifice2", 6545),
                    ("Emptyorifice3", 2820),
                    ("Emptyorifice4", 450),
                    ("Emptyorifice5", 100),
                    ("Emptyorifice6", 30),
                    ("Emptyorifice7", 5)
                };

                // 计算总权重
                int totalWeight = EmptyorificeWeights.Sum(t => t.weight);

                // 生成随机数
                int randomValue = UnityEngine.Random.Range(0, totalWeight);

                // 遍历权重选择特质
                string selectedEmptyorifice = "Emptyorifice1"; // 默认值
                foreach (var Emptyorifice in EmptyorificeWeights)
                {
                    if (randomValue < Emptyorifice.weight)
                    {
                        selectedEmptyorifice = Emptyorifice.traitId;
                        break;
                    }
                    randomValue -= Emptyorifice.weight;
                }

                actor.addTrait(selectedEmptyorifice, false);
            }
        }

        // 境界源能上限
        var GuShis = new Dictionary<string, float>
        {
            { "GuShi0", 7.0f },      // 达到GuShi01需要6点源能
            { "GuShi01", 12.0f },     // 达到GuShi02需要9点源能
            { "GuShi02", 18.0f },    // 达到GuShi1需要18点源能
            { "GuShi1", 30.0f },     // 达到GuShi2需要30点源能
            { "GuShi2", 50.0f },     // 达到GuShi3需要45点源能
            { "GuShi3", 100.0f },     // 达到GuShi4需要70点源能
            { "GuShi4", 200.0f },    // 达到GuShi5需要140点源能
            { "GuShi5", 300.0f },    // 达到GuShi6需要210点源能
            { "GuShi6", 400.0f },    // 达到GuShi7需要288点源能
            { "GuShi7", 500.0f },    // 达到GuShi8需要180点仙元
            { "GuShi8", 600.0f },    // 达到GuShi9需要380点仙元
            { "GuShi9", 700.0f },   // 达到GuShi91需要1000点仙元
            { "GuShi91", 800.0f },   // 达到GuShi92需要800点仙元
            { "GuShi92", 900.0f },   // 达到GuShi93需要900点仙元
            { "GuShi93", 1000.0f },  // 达到GuShi94需要1000点仙元
        };
        foreach (var GuShi in GuShis)
        {
            UpdateZhenyuanBasedOnGuShi(actor, GuShi.Key, GuShi.Value);
        }

        // 到年龄后执行 Emptyorifice81 的逻辑
        var traitThresholds = new Dictionary<string, float>
        {
            { "Emptyorifice6", 100f },//2S
            { "Emptyorifice7", 70f },//3S
            { "GuShi0", 68f },//1学徒
            { "GuShi01", 68f },//2学徒
            { "GuShi02", 68f },//3学徒
            { "GuShi1", 88f },//1正式
            { "GuShi2", 93f },//2正式
            { "GuShi3", 98f },//3正式
            { "GuShi4", 158f },//1高级
            { "GuShi5", 173f },//2高级
            { "GuShi6", 188f },//3高级
            { "GuShi7", 288f },//1大巫师
            { "GuShi8", 388f },//2大巫师
            { "GuShi9", 500f },//3大巫师
            { "GuShi91", 600f },//始祖
            { "GuShi92", 700f },//五转中期
            { "GuShi93", 800f },//五转后期
            { "GuShi94", 900f },//六转前期
            { "GuShi95", 1000f },//六转中期
            { "GuShi96", 1100f },//六转后期
            { "GuShi97", 1200f },//七转前期
            { "GuShi98", 1300f },//七转中期
            { "GuShi99", 1400f },//七转后期
            { "GuShi991", 1500f },//八转前期
            { "GuShi992", 1600f },//八转巅峰
            { "GuShi993", 1700f },//亚仙尊
            { "GuShi994", 1800f },//九转尊者
            { "GuShi995", 1900f },//道主
            { "GuShi996", 2000f },//全知全能
            { "GuShi997", 2100f }//十转
        };

        const float Emptyorifice81Probability = 0f;
        bool hasGuShiTrait = false;

        // 第一层遍历：检查是否存在任意等级特质
        foreach (var GuShi in traitThresholds.Keys)
        {
            if (actor.hasTrait(GuShi))
            {
                hasGuShiTrait = true;
                break;
            }
        }

        if (hasGuShiTrait && !actor.hasTrait("Emptyorifice93"))
        {
            foreach (var kvp in traitThresholds)
            {
                string GuShi = kvp.Key;
                float ageThreshold = kvp.Value;

                if (actor.hasTrait(GuShi) &&
                    age > ageThreshold &&
                    Randy.randomChance(Emptyorifice81Probability))
                {
                    actor.addTrait("Emptyorifice81", false);
                    break;
                }
            }
        }

        // 检查 Spiritstone 值
        if (Globals.Tsotw >= actor.stats["Spiritstone"])
        {
            Globals.Tsotw += actor.stats["Spiritstone"];
            actor.ChangeZhenyuan(-actor.stats["Spiritstone"]);
        }
        if (actor.hasTrait("Emptyorifice8"))
        {
            actor.ChangeXianYuan(1f);
        }
        if (actor.hasTrait("Emptyorifice91"))
        {
            actor.ChangeXianYuan(2f);
        }
        if (actor.hasTrait("Emptyorifice92"))
        {
            if (currentName.Contains("始祖"))
            {
                actor.ChangeXianYuan(2f);
                actor.ChangeZhenyuan(3f);
            }
            else if (currentName.Contains("不灭"))
            {
                actor.ChangeXianYuan(1f);
                actor.ChangeZhenyuan(3f);
            }
        }
        if (actor.hasTrait("Emptyorifice93"))
        {
            actor.ChangeZhenyuan(1f);
        }
        if (actor.hasTrait("Emptyorifice94"))
        {
            actor.ChangeZhenyuan(5f);
            if (actor.hasTrait("XianYuan1") || actor.hasTrait("XianYuan2") || actor.hasTrait("XianYuan3"))
            {
                actor.ChangeXianYuan(3f);
            }
        }
        if (actor.hasTrait("Emptyorifice95"))
        {
            actor.ChangeZhenyuan(10f);
            if (actor.hasTrait("XianYuan1") || actor.hasTrait("XianYuan2") || actor.hasTrait("XianYuan3"))
            {
                actor.ChangeXianYuan(8f);
            }
        }
        // 检查 XianYuan1 到 XianYuan3 特质
        if (actor.hasTrait("XianYuan1") || actor.hasTrait("XianYuan2") || actor.hasTrait("XianYuan3"))
        {
            float randomXianYuanChange = UnityEngine.Random.Range(1f, 5f); // 随机值为1到5
            actor.ChangeXianYuan(randomXianYuanChange);
        }

        // 检查 Emptyorifice1 到 Emptyorifice7 特质，并设置随机的 ["Spiritstone"] 值
        if (SetRandomSpiritstoneBasedOnEmptyorifice(actor))
        {
            if (Globals.Tsotw >= actor.stats["Spiritstone"])
            {
                Globals.Tsotw += actor.stats["Spiritstone"];
                actor.ChangeZhenyuan(-actor.stats["Spiritstone"]);
            }
        }
        else
        {
            return; // 如果没有 Emptyorifice1 到 Emptyorifice7 特质，则不执行后续与 ["Spiritstone"] 相关的操作
        }
    }
    private static bool ShouldApplyDeathMark(string actorName)
    {
        return Regex.IsMatch(actorName, @"^(?=.*\u5341)(?=.*\u6708)(?=.*\u767D)");
    }
    private static bool SetRandomSpiritstoneBasedOnEmptyorifice(Actor actor)
    {
        // 定义Emptyorifice特质对应的["Spiritstone"]随机范围
        var EmptyorificeSpiritstoneRanges = new Dictionary<string, (float min, float max)>
        {
            { "Emptyorifice1", (-1f, -3f) },
            { "Emptyorifice2", (-3f, -6f) },
            { "Emptyorifice3", (-6f, -9f) },
            { "Emptyorifice4", (-9f, -12f) },
            { "Emptyorifice5", (-12f, -15f) },
            { "Emptyorifice6", (-17f, -20f) },
            { "Emptyorifice7", (-20f, -25f) }
        };

        // 遍历Emptyorifice特质，检查演员是否拥有，并设置随机的["Spiritstone"]值
        foreach (var kvp in EmptyorificeSpiritstoneRanges)
        {
            string Emptyorifice = kvp.Key;
            float min = kvp.Value.min;
            float max = kvp.Value.max;

            if (actor.hasTrait(Emptyorifice))
            {
                float randomSpiritstone = UnityEngine.Random.Range(min, max);
                actor.stats["Spiritstone"] = randomSpiritstone;
                return true; // 设置成功，返回true
            }
        }

        // 如果没有找到匹配的Emptyorifice特质，则返回false
        return false;
    }
    private static void UpdateZhenyuanBasedOnGuShi(Actor actor, string traitName, float maxZhenyuan)
    {
        if (actor.hasTrait(traitName))
        {
            actor.SetZhenyuan(Mathf.Min(maxZhenyuan, actor.GetZhenyuan()));
        }
    }

    //祝福之地增加魔法
    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "giveEnchanted")]
    public static bool giveEnchanted(WorldTile pTile, Actor pActor)
    {
        pActor.removeTrait("cursed");
        pActor.addStatusEffect("enchanted", -1f);
        // 检查 pActor 是否具有指定的特性之一
        if (pActor.hasTrait("Emptyorifice1") ||
            pActor.hasTrait("Emptyorifice2") ||
            pActor.hasTrait("Emptyorifice3") ||
            pActor.hasTrait("Emptyorifice4") ||
            pActor.hasTrait("Emptyorifice5") ||
            pActor.hasTrait("Emptyorifice6") ||
            pActor.hasTrait("Emptyorifice7"))
            pActor.addStatusEffect("miracle_power");

        return false;
    }

    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), "checkAnimationContainer")]
    public static bool CheckAnimationContainerPrefix(Actor __instance)
    {
        // 空值检查
        if (__instance == null || __instance.data == null || __instance.asset == null ||
            __instance.batch == null || !__instance.isAlive())
        {
            return true; // 继续执行原方法
        }

        // 使用默认纹理路径
        string textureBasePath = __instance.asset.texture_asset?.texture_path_base ?? "";
        string animationContainerPath = $"actors/{textureBasePath}";
        bool setAnimationContainer = false;

        // 特质到动画路径的映射（按优先级排序）
        var traitToAnimationFrame = new Dictionary<string, string>
        {
            { "Ring93", "actors/Ring93_Wizard" },
            { "Ring92", "actors/Ring92_Wizard" },
            { "GuShi997", "actors/GuShi91_Wizard" },
            { "Ring34", "actors/Ring34_Wizard" },
            { "Insectworm35", "actors/Insectworm35_Wizard" },
            { "Insectworm34", "actors/Insectworm34_Wizard" },
            { "Insectworm33", "actors/Insectworm33_Wizard" },
            { "Insectworm32", "actors/Insectworm32_Wizard" },
            { "Insectworm31", "actors/Insectworm31_Wizard" },
            { "Ring24", "actors/Ring24_Wizard" }
        };

        // 检查特质并设置动画路径
        foreach (var traitPair in traitToAnimationFrame)
        {
            if (__instance.hasStatus(traitPair.Key) || __instance.hasTrait(traitPair.Key))
            {
                animationContainerPath = traitPair.Value;
                setAnimationContainer = true;
                break;
            }
        }

        // 检查等级特质
        if (!setAnimationContainer)
        {
            var GuShiTraits = new[] { "GuShi4", "GuShi5", "GuShi6" };
            if (GuShiTraits.Any(t => __instance.hasTrait(t)))
            {
                // 使用字符串类型的actor ID
                string actorId = __instance.data.id.ToString();
                int animationIndex = GetActorAnimationIndex(actorId, 0, 22);
                animationContainerPath = $"actors/Grade4_Wizard/Grade4.{animationIndex}_Wizard";
                setAnimationContainer = true;
            }
            else
            {
                var lowGuShiTraits = new[] { "GuShi1", "GuShi2", "GuShi3" };
                if (lowGuShiTraits.Any(t => __instance.hasTrait(t)))
                {
                    // 使用字符串类型的actor ID
                    string actorId = __instance.data.id.ToString();
                    int animationIndex = GetActorAnimationIndex(actorId, 0, 14);
                    animationContainerPath = $"actors/Grade1_Wizard/Grade1.{animationIndex}_Wizard";
                    setAnimationContainer = true;
                }
            }
        }

        // 设置动画容器
        if (setAnimationContainer)
        {
            // 设置头部精灵
            string headPath = "actors/base_head";

            // 正确调用checkHeadID方法 - 传递null作为精灵数组
            //__instance.checkHeadID(null, false);
            __instance.dirty_sprite_main = false;
            __instance.dirty_sprite_head = false;
            __instance._dirty_sprite_item = false;

            // 设置头部精灵
            __instance.setHeadSprite(ActorAnimationLoader.getHead(headPath, 0));

            // 获取动画容器
            Subspecies subspecies = __instance.subspecies;
            SubspeciesTrait pEggAsset = subspecies?.egg_asset;
            SubspeciesTrait pMutationSkinAsset = subspecies?.mutation_skin_asset;

            // 使用正确的加载方法
            __instance.animation_container = ActorAnimationLoader.getAnimationContainer(
                animationContainerPath,
                __instance.asset,
                pEggAsset,
                pMutationSkinAsset);

            return false; // 跳过原方法
        }

        return true; // 继续执行原方法
    }

    // 辅助方法：获取或生成动画索引
    private static int GetActorAnimationIndex(string actorId, int min, int max)
    {
        if (!actorAnimationValues.TryGetValue(actorId, out int index))
        {
            index = Randy.randomInt(min, max);
            actorAnimationValues[actorId] = index;
        }
        return index;
    }

    // 静态字典存储动画索引
    private static readonly Dictionary<string, int> actorAnimationValues = new Dictionary<string, int>();

    [HarmonyPrefix, HarmonyPatch(typeof(ActionLibrary), "showWhisperTip")]
    public static bool Prefix(string pText)
    {
        // 自定义逻辑：显示停留时间为x秒的提示信息
        string text = LocalizedTextManager.getText(pText, null);
        if (Config.whisper_A != null)
        {
            text = text.Replace("$kingdom_A$", Config.whisper_A.name);
        }
        if (Config.whisper_B != null)
        {
            text = text.Replace("$kingdom_B$", Config.whisper_B.name);
        }
        WorldTip.showNow(text, false, "top", 15f);


        // 如果不需要跳过原方法，则返回true.
        return false;
    }
    private static readonly string[] EmptyorificeTalentTraits = new[] { "talent1", "talent2", "talent3", "talent4", "Emptyorifice1", "Emptyorifice2", "Emptyorifice3", "Emptyorifice4", "Emptyorifice5", "Emptyorifice6", "Emptyorifice7" };
    private static bool HasAnyEmptyorificeTalen(Actor actor)
    {
        foreach (var trait in EmptyorificeTalentTraits)
        {
            if (actor.hasTrait(trait))
            {
                return true;
            }
        }
        return false;
    }

    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "getHit")]
    public static bool actorGetHit_prefix(
        Actor __instance,
        ref float pDamage,
        bool pFlash,
        AttackType pAttackType,
        BaseSimObject pAttacker,
        bool pSkipIfShake,
        bool pMetallicWeapon,
        bool pCheckDamageReduction = true)
    {
        __instance._last_attack_type = pAttackType;

        // 状态移除检查
        if (__instance._cache_check_has_status_removed_on_damage)
        {
            foreach (Status tStatusData in __instance.getStatuses())
            {
                if (tStatusData.asset.removed_on_damage && !tStatusData.is_finished)
                {
                    __instance.finishStatusEffect(tStatusData.asset.id);
                }
            }
        }

        // 调试模式或跳过条件检查
        if (DebugConfig.isOn(DebugOption.IgnoreDamage)) return false;
        if (pSkipIfShake && __instance.shake_active) return false;

        __instance.attackedBy = null;
        if (pAttacker != null && pAttacker.isRekt())
        {
            pAttacker = null;
        }
        if (pAttacker != __instance)
        {
            __instance.attackedBy = pAttacker;
        }

        // 单位状态检查
        if (!__instance.hasHealth()) return false;
        if (__instance.hasStatus("invincible")) return false;

        // 闪避机制
        if (pAttacker is Actor attackerActor && __instance.isAlive())
        {
            float attackerAccuracy = attackerActor.stats["Accuracy"];
            float targetDodge = __instance.stats["Dodge"];
            float effectiveDodge = Mathf.Clamp(targetDodge - attackerAccuracy, 0f, 100f);

            if (Randy.randomChance(effectiveDodge / 100f))
            {
                __instance.startColorEffect(ActorColorEffect.White);
                return false;
            }
        }

        // 真伤计算
        if (pAttacker != null && pAttacker.a != null && pAttacker.a.stats != null)
        {
            Actor attacker = pAttacker.a;
            float intelligence = attacker.stats[strings.S.intelligence];

            float minMultiplier = 0f, maxMultiplier = 0f;
            if (attacker.hasTrait("GuShi997"))
            {
                minMultiplier = 4000000000f;
                maxMultiplier = 5000000000f;
            }
            else if (attacker.hasTrait("GuShi996"))
            {
                minMultiplier = 40000000f;
                maxMultiplier = 50000000f;
            }
            else if (attacker.hasTrait("GuShi995"))
            {
                minMultiplier = 30000000f;
                maxMultiplier = 40000000f;
            }
            else if (attacker.hasTrait("GuShi994"))
            {
                minMultiplier = 20000000f;
                maxMultiplier = 30000000f;
            }
            else if (attacker.hasTrait("GuShi993"))
            {
                minMultiplier = 34000f;
                maxMultiplier = 40000f;
            }
            else if (attacker.hasTrait("GuShi992"))
            {
                minMultiplier = 26000f;
                maxMultiplier = 34000f;
            }
            else if (attacker.hasTrait("GuShi991"))
            {
                minMultiplier = 20000f;
                maxMultiplier = 26000f;
            }
            else if (attacker.hasTrait("GuShi99"))
            {
                minMultiplier = 3000f;
                maxMultiplier = 3600f;
            }
            else if (attacker.hasTrait("GuShi98"))
            {
                minMultiplier = 1267f;
                maxMultiplier = 1377f;
            }
            else if (attacker.hasTrait("GuShi97"))
            {
                minMultiplier = 1157f;
                maxMultiplier = 1267f;
            }
            else if (attacker.hasTrait("GuShi96"))
            {
                minMultiplier = 847f;
                maxMultiplier = 957f;
            }
            else if (attacker.hasTrait("GuShi95"))
            {
                minMultiplier = 637f;
                maxMultiplier = 747f;
            }
            else if (attacker.hasTrait("GuShi94"))
            {
                minMultiplier = 537f;
                maxMultiplier = 637f;
            }
            else if (attacker.hasTrait("GuShi93"))
            {
                minMultiplier = 497f;
                maxMultiplier = 537f;
            }
            else if (attacker.hasTrait("GuShi92"))
            {
                minMultiplier = 367f;
                maxMultiplier = 497f;
            }
            else if (attacker.hasTrait("GuShi91"))
            {
                minMultiplier = 257f;
                maxMultiplier = 367f;
            }
            else if (attacker.hasTrait("GuShi9"))
            {
                minMultiplier = 67f;
                maxMultiplier = 77f;
            }
            else if (attacker.hasTrait("GuShi8"))
            {
                minMultiplier = 30f;
                maxMultiplier = 50f;
            }
            else if (attacker.hasTrait("GuShi7"))
            {
                minMultiplier = 20f;
                maxMultiplier = 40f;
            }
            else if (attacker.hasTrait("GuShi6"))
            {
                minMultiplier = 14f;
                maxMultiplier = 15f;
            }
            else if (attacker.hasTrait("GuShi5"))
            {
                minMultiplier = 12f;
                maxMultiplier = 15f;
            }
            else if (attacker.hasTrait("GuShi4"))
            {
                minMultiplier = 10f;
                maxMultiplier = 13f;
            }
            else
            {
                goto SkipMagicDamage;
            }

            float multiplier = UnityEngine.Random.Range(minMultiplier, maxMultiplier);
            int magicDamage = Mathf.FloorToInt(intelligence * multiplier);
            __instance.changeHealth(-magicDamage);
            __instance.spawnParticle(new Color(255, 0, 255));
        }

    SkipMagicDamage:
        Actor tAttackerUnit = (pAttacker != null) ? pAttacker.a : null;

        // 武器攻击处理
        if (pAttackType == AttackType.Weapon)
        {
            bool flag = false;
            if (pMetallicWeapon && __instance.haveMetallicWeapon())
            {
                flag = true;
            }

            if (flag)
            {
                MusicBox.playSound("event:/SFX/HIT/HitSwordSword", __instance.current_tile, false, true);
            }
            else if (__instance.asset.has_sound_hit) // 使用has_sound_hit检查
            {
                MusicBox.playSound(__instance.asset.sound_hit, __instance.current_tile, false, true);
            }

            if (!__instance.hasStatus("shield") && tAttackerUnit != null)
            {
                __instance.damageEquipmentOnGetHit(tAttackerUnit);
            }
        }

        // 护甲计算逻辑（新增pCheckDamageReduction检查）
        if (pCheckDamageReduction && (pAttackType == AttackType.Other || pAttackType == AttackType.Weapon))
        {
            // 获取攻击者的护甲穿透百分比
            float armorPen = tAttackerUnit?.stats["ArmorPenPercent"] ?? 0f;
            // 计算有效护甲
            float effectiveArmor = __instance.stats["armor"] - armorPen;
            // 计算减伤比例
            float tArmorPercent = 1f - effectiveArmor / 100f;
            pDamage *= tArmorPercent;

            if (pDamage < 1f) pDamage = 1f;
        }

        // 特殊攻击逻辑
        if (pAttacker != null && pAttacker.isActor())
        {
            float tFinalDamage;
            __instance.checkSpecialAttackLogic(pAttacker.a, pAttackType, pDamage, out tFinalDamage);
            pDamage = tFinalDamage;
        }

        // 成就信号
        if (tAttackerUnit != null)
        {
            SignalManager.add(SignalLibrary.check_achievement_clone_wars,
                            new ValueTuple<Actor, Actor>(__instance, tAttackerUnit));
        }

        // 应用伤害
        __instance.changeHealth((int)(-(int)pDamage));

        __instance.timer_action = 0.002f;

        // 受击动作
        GetHitAction getHitAction = __instance.s_get_hit_action;
        if (getHitAction != null)
        {
            getHitAction(__instance, pAttacker, __instance.current_tile);
        }

        if (pFlash)
        {
            __instance.startColorEffect(ActorColorEffect.Red);
        }

        // 死亡处理
        if (!__instance.hasHealth())
        {
            __instance.batch.c_check_deaths.Add(__instance);
        }

        // 受伤添加特质（防火特质检查）
        if (pAttackType == AttackType.Weapon &&
            !__instance.asset.immune_to_injuries &&
            !__instance.hasStatus("shield"))
        {
            if (!__instance.hasTrait("fire_proof"))
            {
                if (Randy.randomChance(0.02f)) __instance.addInjuryTrait("crippled");
                if (Randy.randomChance(0.02f)) __instance.addInjuryTrait("eyepatch");
            }
        }

        __instance.startShake(0.3f, 0.1f, true, true);

        // 目标选择逻辑（优化距离计算）
        if (!__instance.has_attack_target)
        {
            if (__instance.attackedBy != null &&
                !__instance.shouldIgnoreTarget(__instance.attackedBy) &&
                __instance.canAttackTarget(__instance.attackedBy, false))
            {
                __instance.setAttackTarget(__instance.attackedBy);
            }
        }
        else if (__instance.hasMeleeAttack() &&
                __instance.attackedBy != null &&
                __instance.canAttackTarget(__instance.attackedBy, false))
        {
            float tDistToCurrentTarget = Toolbox.SquaredDistVec2Float(__instance.current_position,
                                                                    __instance.attack_target.current_position);
            float tDistToAttacker = Toolbox.SquaredDistVec2Float(__instance.current_position,
                                                            pAttacker.current_position);

            if (tDistToCurrentTarget > __instance.getAttackRangeSquared() &&
                tDistToAttacker < tDistToCurrentTarget)
            {
                __instance.setAttackTarget(pAttacker);
            }
        }

        // 状态效果处理
        if (__instance.hasAnyStatusEffect())
        {
            foreach (Status status in __instance.getStatuses())
            {
                GetHitAction action_get_hit = status.asset.action_get_hit;
                if (action_get_hit != null)
                {
                    action_get_hit(__instance, pAttacker, __instance.current_tile);
                }
            }
        }

        // 资产受击动作
        GetHitAction action_get_hit2 = __instance.asset.action_get_hit;
        if (action_get_hit2 != null)
        {
            action_get_hit2(__instance, pAttacker, __instance.current_tile);
        }

        // 死亡回调
        if (!__instance.hasHealth())
        {
            __instance.checkCallbacksOnDeath();
        }

        return false;
    }

    private static readonly HashSet<string> ProtectedTraits = new()
    {
        // GuShi91及以上
        "GuShi94", "GuShi95", "GuShi96", "GuShi97", "GuShi98", "GuShi99",
        "GuShi991", "GuShi992", "GuShi993", "GuShi994", "GuShi995", "GuShi996", "GuShi997",
    };

    private static bool HasProtectedTrait(Actor actor)
    {
        if (actor == null) return false;
        return ProtectedTraits.Any(trait => actor.hasTrait(trait));
    }


    // 锁定特定特质的耐力为最大值
    [HarmonyPostfix, HarmonyPatch(typeof(Actor), nameof(Actor.updateStamina))]
    public static void LockStaminaForSpecialTrait(Actor __instance)
    {
        // 拥有受保护特质时，耐力锁定为最大值
        if (HasProtectedTrait(__instance))
        {
            __instance.setStamina(__instance.getMaxStamina(), true);
        }
    }

    // 防止龙卷风效果
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.calculateForce))]
    public static bool CalculateForce_Protection(Actor __instance, float pStartX, float pStartY, float pTargetX, float pTargetY, float pForceAmountDirection, float pForceHeight = 0f, bool pCheckCancelJobOnLand = false)
    {
        return !HasProtectedTrait(__instance);
    }

    // 防止随机力效果
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.applyRandomForce))]
    public static bool ApplyRandomForce_Protection(Actor __instance, float pMinHeight = 1.5f, float pMaxHeight = 2f)
    {
        return !HasProtectedTrait(__instance);
    }

    // 防止获得睡眠状态
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.makeSleep))]
    public static bool MakeSleep_Protection(Actor __instance, float pTime)
    {
        return !HasProtectedTrait(__instance);
    }

    // 防止获得震惊状态
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), nameof(Actor.addStatusEffect), typeof(StatusAsset), typeof(float), typeof(bool))]
    public static bool AddStatusEffect_Protection(Actor __instance, StatusAsset pStatusAsset, float pOverrideTimer = 0f, bool pColorEffect = true)
    {
        if (pStatusAsset.id == "surprised" || pStatusAsset.id == "stunned" || pStatusAsset.id == "sleeping")
        {
            return !HasProtectedTrait(__instance);
        }
        return true;
    }
}