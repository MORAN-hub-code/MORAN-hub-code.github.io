﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cultivatingimmortals.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset GuZhenren2 = new ActorTraitGroupAsset();
            GuZhenren2.id = "GuZhenren2";
            GuZhenren2.name = "蛊道十境";
            GuZhenren2.color = "#00FFFF";
            AssetManager.trait_groups.add(GuZhenren2);

            ActorTraitGroupAsset GuZhenren3 = new ActorTraitGroupAsset();
            GuZhenren3.id = "GuZhenren3";
            GuZhenren3.name = "空窍";
            GuZhenren3.color = "#D02090";
            AssetManager.trait_groups.add(GuZhenren3);

            ActorTraitGroupAsset GuZhenren4 = new ActorTraitGroupAsset();
            GuZhenren4.id = "GuZhenren4";
            GuZhenren4.name = "蛊虫";
            GuZhenren4.color = "#FFC20E";
            AssetManager.trait_groups.add(GuZhenren4);
        }
    }
}
