using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace Cultivatingimmortals.code
{
    internal class SorceryEffect
    {
        public static void Init()
        {
            StatusAsset miracle_power = new StatusAsset();
            miracle_power.id = "miracle_power";//元素共呜
            miracle_power.locale_id = "status_title_miracle_power";
            miracle_power.path_icon = "Ring/miracle_power";
            miracle_power.base_stats["Spiritstone"] = -0.5f;
            miracle_power.duration = 120f;
            AssetManager.status.add(pAsset:miracle_power);
            //零环
            StatusAsset Ring01 = new StatusAsset();
            Ring01.id = "Ring01";//零环•轻身术
            Ring01.path_icon = "Ring/Ring01";
            Ring01.locale_id = "status_title_Ring01";
            Ring01.locale_description = "status_desc_Ring01";
            Ring01.base_stats[strings.S.speed] = 1f;//速度+10
            Ring01.base_stats[strings.S.attack_speed] = 1;//攻击速度+10
            Ring01.base_stats[strings.S.armor] = -5f;//防御-5
            Ring01.base_stats["Dodge"] = 10f;
            AssetManager.status.add(pAsset:Ring01);

            StatusAsset Ring02 = new StatusAsset();
            Ring02.id = "Ring02";//零环•水幻迷障
            Ring02.path_icon = "Ring/Ring02";
            Ring02.locale_id = "status_title_Ring02";
            Ring02.locale_description = "status_desc_Ring02";
            Ring02.base_stats[strings.S.range] = -1f;//射程-1
            Ring02.base_stats[strings.S.area_of_effect] = -0.5f;//近战范围-5%
            AssetManager.status.add(pAsset:Ring02);

            StatusAsset Ring03 = new StatusAsset();
            Ring03.id = "Ring03";//零环•大地壁垒
            Ring03.path_icon = "Ring/Ring03";
            Ring03.locale_id = "status_title_Ring03";
            Ring03.locale_description = "status_desc_Ring03";
            Ring03.base_stats[strings.S.armor] = 10f;//防御+10
            Ring03.base_stats[strings.S.speed] = -0.5f;//速度-5
            Ring03.base_stats[strings.S.attack_speed] = -0.5f;//攻击速度-5
            AssetManager.status.add(pAsset:Ring03);

            StatusAsset Ring04 = new StatusAsset();
            Ring04.id = "Ring04";//零环•蔓藤囚牢
            Ring04.path_icon = "Ring/Ring04";
            Ring04.locale_id = "status_title_Ring04";
            Ring04.locale_description = "status_desc_Ring04";
            Ring04.base_stats[strings.S.speed] = -1f;//速度-10
            Ring04.base_stats[strings.S.attack_speed] = -1f;//攻击速度-10
            AssetManager.status.add(pAsset:Ring04);

            StatusAsset Ring05 = new StatusAsset();
            Ring05.id = "Ring05";//零环•烈焰之握
            Ring05.locale_id = "status_title_Ring05";
            Ring05.locale_description = "status_desc_Ring05";
            Ring05.allow_timer_reset = false;// 不允许重置计时器
            Ring05.action_interval = 0.5f;// 动作触发的时间间隔秒
            Ring05.path_icon = "Ring/Ring05";
            Ring05.action = new WorldAction(traitAction.attack_Ring05);
            AssetManager.status.add(pAsset:Ring05);

            StatusAsset Ring06 = new StatusAsset();
            Ring06.id = "Ring06";//零环•鹰隼凝视
            Ring06.path_icon = "Ring/Ring06";
            Ring06.locale_id = "status_title_Ring06";
            Ring06.locale_description = "status_desc_Ring06";
            Ring06.base_stats[strings.S.intelligence] = 10f;
            Ring06.base_stats["Accuracy"] = 20f;
            AssetManager.status.add(pAsset:Ring06);
            //一环
            StatusAsset Ring11 = new StatusAsset();
            Ring11.id = "Ring11";//一环•疲惫之手
            Ring11.path_icon = "Ring/Ring11";
            Ring11.locale_id = "status_title_Ring11";
            Ring11.locale_description = "status_desc_Ring11";
            Ring11.base_stats[strings.S.damage] = -120f;//伤害-120
            Ring11.base_stats[strings.S.speed] = -0.5f;//速度-5
            Ring11.base_stats[strings.S.attack_speed] = -5f;//攻击速度-5
            AssetManager.status.add(pAsset:Ring11);

            StatusAsset Ring12 = new StatusAsset();
            Ring12.id = "Ring12";//一环•缠绕之网
            Ring12.path_icon = "Ring/Ring12";
            Ring12.locale_id = "status_title_Ring12";
            Ring12.locale_description = "status_desc_Ring12";
            Ring12.base_stats[strings.S.damage] = -30f;//伤害-50
            Ring12.base_stats[strings.S.speed] = -1.5f;//速度-15
            Ring12.base_stats[strings.S.attack_speed] = -30f;//攻击速度-20
            AssetManager.status.add(pAsset:Ring12);

            StatusAsset Ring13 = new StatusAsset();
            Ring13.id = "Ring13";//一环•土之坚甲
            Ring13.path_icon = "Ring/Ring13";
            Ring13.locale_id = "status_title_Ring13";
            Ring13.locale_description = "status_desc_Ring13";
            Ring13.base_stats[strings.S.damage] = 100f;//伤害+100
            Ring13.base_stats[strings.S.armor] = 20f;//防御+20
            Ring13.base_stats[strings.S.speed] = -1f;//速度-10
            Ring13.base_stats[strings.S.attack_speed] = -1f;//攻击速度-10
            AssetManager.status.add(pAsset:Ring13);

            StatusAsset Ring14 = new StatusAsset();
            Ring14.id = "Ring14";//一环•风行术
            Ring14.path_icon = "Ring/Ring14";
            Ring14.locale_id = "status_title_Ring14";
            Ring14.locale_description = "status_desc_Ring14";
            Ring14.base_stats[strings.S.speed] = 4f;//速度+40
            Ring14.base_stats[strings.S.attack_speed] = 3f;//攻击速度+30
            Ring14.base_stats[strings.S.armor] = -10f;
            Ring14.base_stats["Dodge"] = 20f;
            AssetManager.status.add(pAsset:Ring14);

            StatusAsset Ring15 = new StatusAsset();
            Ring15.id = "Ring15";//一环•水雾术
            Ring15.path_icon = "Ring/Ring15";
            Ring15.locale_id = "status_title_Ring15";
            Ring15.locale_description = "status_desc_Ring15";
            Ring15.base_stats[strings.S.range] = -3f;//射程-3
            Ring15.base_stats[strings.S.area_of_effect] = -3f;//近战范围-3
            AssetManager.status.add(pAsset:Ring15);

            StatusAsset Ring16 = new StatusAsset();
            Ring16.id = "Ring16";//一环•气机牵引
            Ring16.path_icon = "Ring/Ring16";
            Ring16.locale_id = "status_title_Ring16";
            Ring16.locale_description = "status_desc_Ring16";
            Ring16.base_stats[strings.S.intelligence] = 20f;
            Ring16.base_stats["Accuracy"] = 40f;
            AssetManager.status.add(pAsset:Ring16);

            StatusAsset Ring17 = new StatusAsset();
            Ring17.id = "Ring17";//一环•破甲符刃
            Ring17.path_icon = "Ring/Ring17";
            Ring17.locale_id = "status_title_Ring17";
            Ring17.locale_description = "status_desc_Ring17";
            Ring17.base_stats[strings.S.damage] = 30f;//伤害+30
            Ring17.base_stats[strings.S.multiplier_damage] = 0.1f;//伤害倍率+10%
            Ring17.base_stats[strings.S.critical_chance] = 0.1f;//暴击+10%
            Ring17.base_stats[strings.S.critical_damage_multiplier] = 0.2f;//暴击伤害倍率10%
            Ring17.base_stats["ArmorPenPercent"] = 15f; //护甲穿透+15%
            AssetManager.status.add(pAsset:Ring17);
            //二环
            StatusAsset Ring22 = new StatusAsset();
            Ring22.id = "Ring22";//二环•星之致幻
            Ring22.path_icon = "Ring/Ring22";
            Ring22.locale_id = "status_title_Ring22";
            Ring22.locale_description = "status_desc_Ring22";
            Ring22.base_stats[strings.S.intelligence] = -50f;//智力-50
            Ring22.base_stats[strings.S.warfare] = -50f;
            Ring22.base_stats[strings.S.damage] = -1200f;//伤害-1200
            Ring22.base_stats[strings.S.speed] = -1f;//速度-10
            Ring22.base_stats[strings.S.attack_speed] = -1f;//攻击速度-10
            AssetManager.status.add(pAsset:Ring22);

            StatusAsset Ring24 = new StatusAsset();
            Ring24.id = "Ring24";//二环•岩石护壁
            Ring24.path_icon = "Ring/Ring24";
            Ring24.locale_id = "status_title_Ring24";
            Ring24.locale_description = "status_desc_Ring24";
            Ring24.base_stats[strings.S.damage] = 2000f;//伤害+3000
            Ring24.base_stats[strings.S.health] = 3000f;//生命+3000
            Ring24.base_stats[strings.S.critical_chance] = 0.1f;//暴击+10%
            Ring24.base_stats[strings.S.area_of_effect] = 1f;//近战范围+1
            Ring24.base_stats[strings.S.armor] = 40f;//防御+40
            Ring24.base_stats[strings.S.speed] = -1.5f; //-移动速度15
            Ring24.base_stats[strings.S.attack_speed] = -3f;//-攻击速度15
            AssetManager.status.add(pAsset:Ring24);

            StatusAsset Ring25 = new StatusAsset();
            Ring25.id = "Ring25";//二环•生命流逝
            Ring25.locale_id = "status_title_Ring25";
            Ring25.locale_description = "status_desc_Ring25";
            Ring25.allow_timer_reset = false;// 不允许重置计时器
            Ring25.action_interval = 0.5f;// 动作触发的时间间隔秒
            Ring25.path_icon = "Ring/Ring25";
            Ring25.base_stats[strings.S.health] = -5000f;//-生命值5000
            Ring25.base_stats[strings.S.speed] = -1f;//-移动速度10
            Ring25.base_stats[strings.S.attack_speed] = -1f;//-攻击速度10
            Ring25.action = new WorldAction(traitAction.attack_Ring25);
            AssetManager.status.add(pAsset:Ring25);

            StatusAsset Ring26 = new StatusAsset();
            Ring26.id = "Ring26";//二环•因果印记
            Ring26.locale_id = "status_title_Ring26";
            Ring26.locale_description = "status_desc_Ring26";
            Ring26.path_icon = "Ring/Ring26";
            Ring26.base_stats[strings.S.intelligence] = 30f;
            Ring26.base_stats["Accuracy"] = 60f;
            AssetManager.status.add(pAsset:Ring26);

            StatusAsset Ring27 = new StatusAsset();
            Ring27.id = "Ring27";//二环•相位星痕步
            Ring27.path_icon = "Ring/Ring27";
            Ring27.locale_id = "status_title_Ring27";
            Ring27.locale_description = "status_desc_Ring27";
            Ring27.base_stats[strings.S.speed] = 6f;//速度+60
            Ring27.base_stats[strings.S.attack_speed] = 5f;//攻击速度+50
            Ring27.base_stats[strings.S.armor] = -15f;
            Ring27.base_stats[strings.S.multiplier_damage] = -0.15f;
            Ring27.base_stats["Dodge"] = 35f;
            Ring27.base_stats["Accuracy"] = -15f;
            AssetManager.status.add(pAsset:Ring27);

            StatusAsset Ring28 = new StatusAsset();
            Ring28.id = "Ring28";//二环•贯星之锋
            Ring28.path_icon = "Ring/Ring28";
            Ring28.locale_id = "status_title_Ring28";
            Ring28.locale_description = "status_desc_Ring28";
            Ring28.base_stats[strings.S.damage] = 50f;//伤害+50
            Ring28.base_stats[strings.S.multiplier_damage] = 0.2f;//伤害倍率+20%
            Ring28.base_stats[strings.S.critical_chance] = 0.2f;//暴击+20%
            Ring28.base_stats[strings.S.critical_damage_multiplier] = 0.3f;//暴击伤害倍率30%
            Ring28.base_stats["ArmorPenPercent"] = 30f; //护甲穿透+30%
            AssetManager.status.add(pAsset:Ring28);

            StatusAsset Ring31 = new StatusAsset();
            Ring31.id = "Ring31";//三环•斥力场
            Ring31.path_icon = "Ring/Ring31";
            Ring31.locale_id = "status_title_Ring31";
            Ring31.locale_description = "status_desc_Ring31";
            Ring31.base_stats[strings.S.armor] = -20f;
            AssetManager.status.add(pAsset:Ring31);

            StatusAsset Ring32 = new StatusAsset();
            Ring32.id = "Ring32";//三环•裂界爆炎
            Ring32.path_icon = "Ring/Ring32";
            Ring32.locale_id = "status_title_Ring32";
            Ring32.locale_description = "status_desc_Ring32";
            Ring32.base_stats[strings.S.armor] = -20f;//防御-20
            AssetManager.status.add(pAsset:Ring32);

            StatusAsset Ring33 = new StatusAsset();
            Ring33.id = "Ring33";//三环•雷霆术
            Ring33.path_icon = "Ring/Ring33";
            Ring33.locale_id = "status_title_Ring33";
            Ring33.locale_description = "status_desc_Ring33";
            Ring33.base_stats[strings.S.armor] = -20f;//防御20
            AssetManager.status.add(pAsset:Ring33);

            StatusAsset Ring34 = new StatusAsset();
            Ring34.id = "Ring34";//三环•诡异之眼充血
            Ring34.path_icon = "Ring/Ring34";
            Ring34.locale_id = "status_title_Ring34";
            Ring34.locale_description = "status_desc_Ring34";
            Ring34.base_stats[strings.S.armor] = -20f;//防御-20
            Ring34.base_stats[strings.S.intelligence] = 90f;
            AssetManager.status.add(pAsset:Ring34);

            StatusAsset Ring35 = new StatusAsset();
            Ring35.id = "Ring35";//三环•黯镰噬魂·万灵湮灭之仪
            Ring35.path_icon = "Ring/Ring35";
            Ring35.locale_id = "status_title_Ring35";
            Ring35.locale_description = "status_desc_Ring35";
            Ring35.base_stats[strings.S.armor] = -20f;
            AssetManager.status.add(pAsset:Ring35);

            StatusAsset Ring92 = new StatusAsset();
            Ring92.id = "Ring92";
            Ring92.locale_id = "status_title_Ring92";
            Ring92.locale_description = "status_desc_Ring92";
            Ring92.path_icon = "Ring/Ring92";
            Ring92.base_stats[strings.S.scale] = 0.03f;
            AssetManager.status.add(pAsset:Ring92);

            StatusAsset Ring93 = new StatusAsset();
            Ring93.id = "Ring93";
            Ring93.locale_id = "status_title_Ring93";
            Ring93.locale_description = "status_desc_Ring93";
            Ring93.path_icon = "Ring/Ring93";
            Ring93.base_stats[strings.S.scale] = 0.02f;
            AssetManager.status.add(pAsset:Ring93);
        }
    }
}