using UnityEngine;

namespace Cultivatingimmortals.code.utils;

public static class ActorExtensions
{
    private const string Zhenyuan_key = "wushu.ZhenyuanNum";
    private const string XianYuan_key = "wushu.XianYuanNum";
    private const string Opportunity_key = "wushu.OpportunityNum";
    private const string Reincarnation_key = "wushu.ReincarnationNum";
    public static float GetReincarnation(this Actor actor)
    {
        actor.data.get(Reincarnation_key, out float val, 1);
        return val;
    }
    public static void SetReincarnation(this Actor actor, float val)
    {
        actor.data.set(Reincarnation_key, val);
    }
    public static void ChangeReincarnation(this Actor actor, float delta)
    {
        actor.data.get(Reincarnation_key, out float val, 0);
        val += delta;
        actor.data.set(Reincarnation_key, Mathf.Max(1, val));
    }

    public static float GetOpportunity(this Actor actor)
    {
        actor.data.get(Opportunity_key, out float val, 0);
        return val;
    }
    public static void SetOpportunity(this Actor actor, float val)
    {
        actor.data.set(Opportunity_key, val);
    }
    public static void ChangeOpportunity(this Actor actor, float delta)
    {
        actor.data.get(Opportunity_key, out float val, 0);
        val += delta;
        actor.data.set(Opportunity_key, Mathf.Max(0, val));
    }

    public static float GetXianYuan(this Actor actor)
    {
        actor.data.get(XianYuan_key, out float val, 0);
        return val;
    }
    public static void SetXianYuan(this Actor actor, float val)
    {
        actor.data.set(XianYuan_key, val);
    }
    public static void ChangeXianYuan(this Actor actor, float delta)
    {
        actor.data.get(XianYuan_key, out float val, 0);
        val += delta;
        actor.data.set(XianYuan_key, val);
    }

    public static float GetZhenyuan(this Actor actor)
    {
        actor.data.get(Zhenyuan_key, out float val, 0);

        return val;
    }

    public static void SetZhenyuan(this Actor actor, float val)
    {
        actor.data.set(Zhenyuan_key, val);
    }

    public static void ChangeZhenyuan(this Actor actor, float delta)
    {
        actor.data.get(Zhenyuan_key, out float val, 0);
        val += delta;
        actor.data.set(Zhenyuan_key, Mathf.Max(0, val));
    }
}