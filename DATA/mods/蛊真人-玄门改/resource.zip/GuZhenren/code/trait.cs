﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ReflectionUtility;
using ai;
using System.Numerics;
using UnityEngine;

namespace Cultivatingimmortals.code
{
    internal class traits
    {

        private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
        {
            ActorTrait trait = new ActorTrait();
            trait.id = id;
            trait.path_icon = path_icon;
            trait.needs_to_be_explored = false;
            trait.group_id = group_id;
            trait.base_stats = new BaseStats();

            return trait;
        }
        private static ClanTrait CclanTrait(string id, string path_icon, string group_id)
		{
			ClanTrait trait = new ClanTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
        public static void AddActorTrait(string id, string pathIcon)
        {
            ActorTrait Emptyorifice = new ActorTrait
            {
                id = id,
                path_icon = pathIcon,
                group_id = "GuZhenren3",
                needs_to_be_explored = false
            };
            Emptyorifice.action_special_effect += traitAction.GuShi0_effectAction; //学徒•初识的升级条件
            AssetManager.traits.add(Emptyorifice);
        }
        public static bool ClanEmptyorificeMethod(BaseSimObject pTarget, WorldTile pTile = null, int minEmptyorificeLevel = 1)
        {
            if (!(pTarget is Actor actor)) return false;
            
            float age = actor.getAge();
            if (Mathf.FloorToInt(age) != 8) return true;
            
            // 定义需要检查的特质列表
            string[] traitsToCheck = 
            {
                "talent1", "talent2", "talent3", "talent4",
                "Emptyorifice1", "Emptyorifice2", "Emptyorifice3", "Emptyorifice4", "Emptyorifice5", "Emptyorifice6", "Emptyorifice7"
            };
            
            // 检查是否已拥有任何相关特质
            if (traitsToCheck.Any(actor.hasTrait)) return true;
            
            // 根据 minEmptyorificeLevel 设置不同的天赋范围
            var EmptyorificeWeights = new List<(string traitId, int weight)>();
            if (minEmptyorificeLevel <= 1) EmptyorificeWeights.Add(("Emptyorifice1", 5442));
            if (minEmptyorificeLevel <= 2) EmptyorificeWeights.Add(("Emptyorifice2", 2750));
            if (minEmptyorificeLevel <= 3) EmptyorificeWeights.Add(("Emptyorifice3", 1200));
            if (minEmptyorificeLevel <= 4) EmptyorificeWeights.Add(("Emptyorifice4", 500));
            if (minEmptyorificeLevel <= 5) EmptyorificeWeights.Add(("Emptyorifice5", 100));
            if (minEmptyorificeLevel <= 6) EmptyorificeWeights.Add(("Emptyorifice6", 6));
            if (minEmptyorificeLevel <= 7) EmptyorificeWeights.Add(("Emptyorifice7", 2));
            
            if (EmptyorificeWeights.Count == 0) return true;
            
            // 计算总权重并随机选择
            int totalWeight = EmptyorificeWeights.Sum(t => t.weight);
            int randomValue = UnityEngine.Random.Range(0, totalWeight);
            
            foreach (var Emptyorifice in EmptyorificeWeights)
            {
                if (randomValue < Emptyorifice.weight)
                {
                    actor.addTrait(Emptyorifice.traitId, false);
                    break;
                }
                randomValue -= Emptyorifice.weight;
            }
            
            return true;
        }
        public static void Init()
        {
            //特质id↓ //贴图路径↓ //诞生率↓ //排斥的特质↓
            AddActorTrait("Emptyorifice1", "trait/Emptyorifice1");//D天赋
            AddActorTrait("Emptyorifice2", "trait/Emptyorifice2");//C天赋
            AddActorTrait("Emptyorifice3", "trait/Emptyorifice3");//B天赋
            AddActorTrait("Emptyorifice4", "trait/Emptyorifice4");//A天赋
            AddActorTrait("Emptyorifice5", "trait/Emptyorifice5");//S天赋

            // 定义氏族特质配置（包含图标路径）
            var clanTraits = new List<(string id, string iconPath, int minLevel)>
            {
                ("ClanEmptyorifice1", "trait/Emptyorifice1", 1),
                ("ClanEmptyorifice2", "trait/Emptyorifice2", 2),
                ("ClanEmptyorifice3", "trait/Emptyorifice3", 3),
                ("ClanEmptyorifice4", "trait/Emptyorifice4", 4),
                ("ClanEmptyorifice5", "trait/Emptyorifice5", 5)
            };

            // 批量创建并添加氏族特质
            foreach (var (id, iconPath, minLevel) in clanTraits)
            {
                ClanTrait clanTrait = CclanTrait(
                    id: id,
                    path_icon: iconPath, // 使用指定的图标路径
                    group_id: "spirit"
                );
                
                clanTrait.action_special_effect += (target, tile) => 
                    ClanEmptyorificeMethod(target, tile, minLevel);
                
                AssetManager.clan_traits.add(clanTrait);
            }

            ActorTrait Emptyorifice6 = CreateTrait("Emptyorifice6", "trait/Emptyorifice6", "GuZhenren3");
            SafeSetStat(Emptyorifice6.base_stats, strings.S.multiplier_lifespan, -0.4f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.intelligence, 15f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.damage, 60f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.critical_chance, 0.2f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.health, 300f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.armor, 10f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.targets, 2f);
            SafeSetStat(Emptyorifice6.base_stats, strings.S.knockback, 1f);
            SafeSetStat(Emptyorifice6.base_stats, "Resist", 1f);
            Emptyorifice6.action_special_effect += traitAction.SS_Collection;//收藏
            Emptyorifice6.action_special_effect += traitAction.GuShi0_effectAction;//学徒•初识的升级条件
            Emptyorifice6.action_special_effect += (WorldAction)Delegate.Combine(Emptyorifice6.action_special_effect,
new WorldAction(traitAction.Emptyorifice6_Regen)); //再生效果
            AssetManager.traits.add(Emptyorifice6);

            ActorTrait Emptyorifice7 = CreateTrait("Emptyorifice7", "trait/Emptyorifice7", "GuZhenren3");
            SafeSetStat(Emptyorifice7.base_stats, strings.S.multiplier_lifespan, -0.6f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.intelligence, 30f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.damage, 100f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.critical_chance, 0.5f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.health, 500f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.armor, 20f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.targets, 3f);
            SafeSetStat(Emptyorifice7.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(Emptyorifice7.base_stats, "Resist", 1f);
            Emptyorifice7.action_special_effect += traitAction.SSS_Collection;//收藏
            Emptyorifice7.action_special_effect += traitAction.GuShi0_effectAction;//学徒•初识的升级条件
            Emptyorifice7.action_special_effect += (WorldAction)Delegate.Combine(Emptyorifice7.action_special_effect,
new WorldAction(traitAction.Emptyorifice7_Regen)); //再生效果
            AssetManager.traits.add(Emptyorifice7);

            ActorTrait XianYuan1 = CreateTrait("XianYuan1", "trait/XianYuan1", "GuZhenren3");
            AssetManager.traits.add(XianYuan1);

            ActorTrait XianYuan2 = CreateTrait("XianYuan2", "trait/XianYuan2", "GuZhenren3");
            AssetManager.traits.add(XianYuan2);

            ActorTrait XianYuan3 = CreateTrait("XianYuan3", "trait/XianYuan3", "GuZhenren3");
            AssetManager.traits.add(XianYuan3);

            ActorTrait Emptyorifice8 = CreateTrait("Emptyorifice8", "trait/Emptyorifice8", "GuZhenren3");//大巫师•灵魂
            SafeSetStat(Emptyorifice8.base_stats, strings.S.intelligence, 30f);
            SafeSetStat(Emptyorifice8.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(Emptyorifice8.base_stats, strings.S.damage, 60f);
            SafeSetStat(Emptyorifice8.base_stats, strings.S.armor, 20f);
            SafeSetStat(Emptyorifice8.base_stats, strings.S.health, 300f);
            SafeSetStat(Emptyorifice8.base_stats, strings.S.multiplier_offspring, -100f);
            SafeSetStat(Emptyorifice8.base_stats, "Spiritstone", -2f);//每年-2点世界源力+2点源能
            SafeSetStat(Emptyorifice8.base_stats, strings.S.stamina, 100f);//耐力+100
            Emptyorifice8.action_death = traitAction.Emptyorifice8_death;//重生效果+随机BAS
            Emptyorifice8.action_special_effect += (WorldAction)Delegate.Combine(Emptyorifice8.action_special_effect,
new WorldAction(traitAction.Emptyorifice8_Regen)); //再生效果
            AssetManager.traits.add(Emptyorifice8);

            ActorTrait Emptyorifice81 = CreateTrait("Emptyorifice81", "trait/Emptyorifice81", "GuZhenren3");//禁巫
            AssetManager.traits.add(Emptyorifice81);

            ActorTrait Emptyorifice9 = CreateTrait("Emptyorifice9", "trait/Emptyorifice9", "GuZhenren3");//禁巫之族
            AssetManager.traits.add(Emptyorifice9);

            ActorTrait Emptyorifice91 = CreateTrait("Emptyorifice91", "trait/Emptyorifice91", "GuZhenren3");
            SafeSetStat(Emptyorifice91.base_stats, strings.S.intelligence, 88f);
            SafeSetStat(Emptyorifice91.base_stats, strings.S.lifespan, 10f);//寿命+10
            SafeSetStat(Emptyorifice91.base_stats, strings.S.damage, 120f);
            SafeSetStat(Emptyorifice91.base_stats, strings.S.armor, 30f);
            SafeSetStat(Emptyorifice91.base_stats, strings.S.health, 900f);
            SafeSetStat(Emptyorifice91.base_stats, strings.S.multiplier_offspring, -10f);
            SafeSetStat(Emptyorifice91.base_stats, "Spiritstone", -2f);//每年-2点世界源力+2点源能
            SafeSetStat(Emptyorifice91.base_stats, strings.S.stamina, 200f);//耐力+200
            Emptyorifice91.action_death = traitAction.Emptyorifice91_death;//重生效果
            Emptyorifice91.action_special_effect += (WorldAction)Delegate.Combine(Emptyorifice91.action_special_effect,
new WorldAction(traitAction.Emptyorifice91_Regen)); //再生效果
            AssetManager.traits.add(Emptyorifice91);

            ActorTrait Emptyorifice92 = CreateTrait("Emptyorifice92", "trait/Emptyorifice92", "GuZhenren3");
            SafeSetStat(Emptyorifice92.base_stats, strings.S.multiplier_offspring, -10f);
            Emptyorifice92.action_death = traitAction.Emptyorifice92_death; //重生效果
            Emptyorifice92.action_special_effect += (WorldAction)Delegate.Combine(Emptyorifice92.action_special_effect,
new WorldAction(traitAction.Emptyorifice92_Regen)); //再生效果
            AssetManager.traits.add(Emptyorifice92);

            ActorTrait Emptyorifice93 = CreateTrait("Emptyorifice93", "trait/Emptyorifice93", "GuZhenren3");
            AssetManager.traits.add(Emptyorifice93);

            ActorTrait Emptyorifice94 = CreateTrait("Emptyorifice94", "trait/Emptyorifice94", "GuZhenren3");
            AssetManager.traits.add(Emptyorifice94);

            ActorTrait Emptyorifice95 = CreateTrait("Emptyorifice95", "trait/Emptyorifice95", "GuZhenren3");
            AssetManager.traits.add(Emptyorifice95);
            //巫师境界↓
            ActorTrait GuShi0 = CreateTrait("GuShi0", "trait/GuShi0", "GuZhenren2");//学徒•初识
            SafeSetStat(GuShi0.base_stats, strings.S.lifespan, 10f);
            SafeSetStat(GuShi0.base_stats, strings.S.damage, 10f);
            SafeSetStat(GuShi0.base_stats, strings.S.health, 100f);
            SafeSetStat(GuShi0.base_stats, strings.S.intelligence, 1f);
            SafeSetStat(GuShi0.base_stats, "Dodge", 10f);
            GuShi0.action_special_effect += traitAction.GuShi01_effectAction; //学徒•掌控的升级条件
            AssetManager.traits.add(GuShi0);

            ActorTrait GuShi01 = CreateTrait("GuShi01", "trait/GuShi01", "GuZhenren2");//学徒•掌控
            SafeSetStat(GuShi01.base_stats, strings.S.lifespan, 20f);//寿命+20
            SafeSetStat(GuShi01.base_stats, strings.S.damage, 20f);//伤害+40
            SafeSetStat(GuShi01.base_stats, strings.S.health, 200f);//生命+400
            SafeSetStat(GuShi01.base_stats, strings.S.intelligence, 2f);//智力+2
            SafeSetStat(GuShi01.base_stats, strings.S.targets, 1f);
            SafeSetStat(GuShi01.base_stats, strings.S.accuracy, 2f); //准确度+2
            SafeSetStat(GuShi01.base_stats, "Dodge", 20f);
            GuShi01.action_special_effect += traitAction.GuShi02_effectAction; //学徒•精通的升级条件
            GuShi01.action_special_effect += (WorldAction)Delegate.Combine(GuShi01.action_special_effect,
new WorldAction(traitAction.GuShi01_Regen)); //学徒•掌控的再生效果
            AssetManager.traits.add(GuShi01);

            ActorTrait GuShi02 = CreateTrait("GuShi02", "trait/GuShi02", "GuZhenren2"); // 学徒•精通
            SafeSetStat(GuShi02.base_stats, strings.S.lifespan, 30f); // 寿命+30
            SafeSetStat(GuShi02.base_stats, strings.S.damage, 40f);
            SafeSetStat(GuShi02.base_stats, strings.S.health, 400f);
            SafeSetStat(GuShi02.base_stats, strings.S.speed, 5f);
            SafeSetStat(GuShi02.base_stats, strings.S.intelligence, 3f);
            SafeSetStat(GuShi02.base_stats, strings.S.range, 1f); // 射程+1
            SafeSetStat(GuShi02.base_stats, strings.S.area_of_effect, 1f);
            SafeSetStat(GuShi02.base_stats, strings.S.targets, 2f);
            SafeSetStat(GuShi02.base_stats, strings.S.accuracy, 5f); // 准确度+5
            SafeSetStat(GuShi02.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(GuShi02.base_stats, "Resist", 1f);
            SafeSetStat(GuShi02.base_stats, "Dodge", 30f);
            GuShi02.action_special_effect += traitAction.GuShi1_effectAction; // 正式巫师•塑造的升级条件
            GuShi02.action_special_effect += (WorldAction)Delegate.Combine(GuShi02.action_special_effect,
                new WorldAction(traitAction.GuShi02_Regen)); // 学徒•精通的再生效果
            AssetManager.traits.add(GuShi02);

            ActorTrait GuShi1 = CreateTrait("GuShi1", "trait/GuShi1", "GuZhenren2"); // 正式巫师•塑造
            SafeSetStat(GuShi1.base_stats, strings.S.lifespan, 70f); // 寿命+20
            SafeSetStat(GuShi1.base_stats, strings.S.damage, 100f);
            SafeSetStat(GuShi1.base_stats, strings.S.health, 1000f);
            SafeSetStat(GuShi1.base_stats, strings.S.armor, 20f);
            SafeSetStat(GuShi1.base_stats, strings.S.speed, 10f);
            SafeSetStat(GuShi1.base_stats, strings.S.intelligence, 10f);
            SafeSetStat(GuShi1.base_stats, strings.S.range, 3f); // 射程+3
            SafeSetStat(GuShi1.base_stats, strings.S.area_of_effect, 4f); // 近战范围+3
            SafeSetStat(GuShi1.base_stats, strings.S.targets, 3f); // 可攻击目标+1
            SafeSetStat(GuShi1.base_stats, strings.S.knockback, 1f); // 击退+1
            SafeSetStat(GuShi1.base_stats, "Resist", 1f);
            SafeSetStat(GuShi1.base_stats, "Dodge", 50f);
            SafeSetStat(GuShi1.base_stats, "Accuracy", 20f);
            SafeSetStat(GuShi1.base_stats, strings.S.mass_2, 10f);//体重+10
            SafeSetStat(GuShi1.base_stats, strings.S.accuracy, 10f); // 准确度+10
            SafeSetStat(GuShi1.base_stats, strings.S.stamina, 30f); //耐力+30
            GuShi1.action_special_effect += traitAction.GuShi2_effectAction; // 升正式巫师•元素的条件
            GuShi1.action_special_effect += (WorldAction)Delegate.Combine(GuShi1.action_special_effect,
                new WorldAction(traitAction.GuShi1_Regen)); // 正式巫师•塑造的再生效果
            AssetManager.traits.add(GuShi1);

            ActorTrait GuShi2 = new ActorTrait();
            GuShi2.id = "GuShi2"; //正式巫师•元素
            GuShi2.path_icon = "trait/GuShi2";
            GuShi2.needs_to_be_explored = false;
            GuShi2.group_id = "GuZhenren2";
            GuShi2.base_stats = new BaseStats();
            GuShi2.base_stats[strings.S.lifespan] = 80f;
            GuShi2.base_stats[strings.S.damage] = 200f;
            GuShi2.base_stats[strings.S.health] = 2000f;
            GuShi2.base_stats[strings.S.armor] = 20f;
            GuShi2.base_stats[strings.S.speed] = 12f;
            GuShi2.base_stats[strings.S.intelligence] = 20f;
            GuShi2.base_stats[strings.S.range] = 3f;
            GuShi2.base_stats[strings.S.area_of_effect] = 5f;
            GuShi2.base_stats[strings.S.targets] = 3f;
            GuShi2.base_stats[strings.S.knockback] = 1f;//击退+1
            GuShi2.base_stats["Resist"] = 1f;
            GuShi2.base_stats["Dodge"] = 60f;
            GuShi2.base_stats["Accuracy"] = 30f;
            GuShi2.base_stats[strings.S.mass_2] = 15f;//体重+15
            GuShi2.base_stats[strings.S.accuracy] = 15f; //准确度+15
            GuShi2.base_stats[strings.S.stamina] = 40f; //耐力+40
            GuShi2.action_special_effect += traitAction.GuShi3_effectAction; //正式巫师•冥想的条件
            GuShi2.action_special_effect += (WorldAction)Delegate.Combine(GuShi2.action_special_effect,
                new WorldAction(traitAction.GuShi2_Regen)); //正式巫师•元素的再生效果
            AssetManager.traits.add(GuShi2);

            ActorTrait GuShi3 = new ActorTrait();
            GuShi3.id = "GuShi3"; //正式巫师•冥想
            GuShi3.path_icon = "trait/GuShi3";
            GuShi3.needs_to_be_explored = false;
            GuShi3.group_id = "GuZhenren2";
            GuShi3.base_stats = new BaseStats();
            GuShi3.base_stats[strings.S.lifespan] = 90f;
            GuShi3.base_stats[strings.S.damage] = 400f;
            GuShi3.base_stats[strings.S.health] = 4000f;
            GuShi3.base_stats[strings.S.armor] = 30f;
            GuShi3.base_stats[strings.S.speed] = 15f;
            GuShi3.base_stats[strings.S.intelligence] = 30f;
            GuShi3.base_stats[strings.S.range] = 5f;
            GuShi3.base_stats[strings.S.area_of_effect] = 6f;
            GuShi3.base_stats[strings.S.targets] = 3f;
            GuShi3.base_stats[strings.S.knockback] = 1f;//击退+1
            GuShi3.base_stats["Resist"] = 1f;
            GuShi3.base_stats[strings.S.warfare] = 5f;
            GuShi3.base_stats[strings.S.stewardship] = 10f;
            GuShi3.base_stats["Dodge"] = 70f;
            GuShi3.base_stats["Accuracy"] = 40f;
            GuShi3.base_stats[strings.S.mass_2] = 20f;//体重+20
            GuShi3.base_stats[strings.S.accuracy] = 20f; //准确度+20
            GuShi3.base_stats[strings.S.stamina] = 50f; //耐力+50
            GuShi3.action_special_effect += traitAction.GuShi4_effectAction; //升高级巫师•黎明的条件
            GuShi3.action_special_effect += (WorldAction)Delegate.Combine(GuShi3.action_special_effect,
                new WorldAction(traitAction.GuShi3_Regen)); //正式巫师•冥想的再生效果
            AssetManager.traits.add(GuShi3);

            ActorTrait GuShi4 = new ActorTrait();
            GuShi4.id = "GuShi4"; //高级巫师•黎明
            GuShi4.path_icon = "trait/GuShi4";
            GuShi4.needs_to_be_explored = false;
            GuShi4.group_id = "GuZhenren2";
            GuShi4.base_stats = new BaseStats();
            GuShi4.base_stats[strings.S.lifespan] = 140f;
            GuShi4.base_stats[strings.S.damage] = 1000f;
            GuShi4.base_stats[strings.S.health] = 10000f;
            GuShi4.base_stats[strings.S.armor] = 40f;
            GuShi4.base_stats[strings.S.speed] = 20f;
            GuShi4.base_stats[strings.S.intelligence] = 60f;
            GuShi4.base_stats[strings.S.range] = 8f;
            GuShi4.base_stats[strings.S.area_of_effect] = 10f;
            GuShi4.base_stats[strings.S.targets] = 5f;
            GuShi4.base_stats[strings.S.knockback] = 2f;
            GuShi4.base_stats["Resist"] = 2f;
            GuShi4.base_stats[strings.S.warfare] = 6f;
            GuShi4.base_stats[strings.S.stewardship] = 12f;
            GuShi4.base_stats["Dodge"] = 100f;
            GuShi4.base_stats["Accuracy"] = 70f;
            GuShi4.base_stats[strings.S.mass_2] = 30f;//体重+30
            GuShi4.base_stats[strings.S.accuracy] = 30f; //准确度+30
            GuShi4.base_stats[strings.S.stamina] = 80f; //耐力+80
            GuShi4.action_special_effect += traitAction.GuShi5_effectAction; //升高级巫师•扩展的条件
            GuShi4.action_special_effect += (WorldAction)Delegate.Combine(GuShi4.action_special_effect,
                new WorldAction(traitAction.GuShi4_Regen)); //高级巫师•黎明的再生效果
            AssetManager.traits.add(GuShi4);


            ActorTrait GuShi5 = new ActorTrait();
            GuShi5.id = "GuShi5"; //高级巫师•扩展
            GuShi5.path_icon = "trait/GuShi5";
            GuShi5.needs_to_be_explored = false;
            GuShi5.group_id = "GuZhenren2";
            GuShi5.base_stats = new BaseStats();
            GuShi5.base_stats[strings.S.lifespan] = 155f;
            GuShi5.base_stats[strings.S.damage] = 2000f;
            GuShi5.base_stats[strings.S.health] = 20000f;
            GuShi5.base_stats[strings.S.armor] = 40f;
            GuShi5.base_stats[strings.S.speed] = 25f;
            GuShi5.base_stats[strings.S.intelligence] = 100f;
            GuShi5.base_stats[strings.S.range] = 8f;
            GuShi5.base_stats[strings.S.area_of_effect] = 10f;
            GuShi5.base_stats[strings.S.targets] = 5f;
            GuShi5.base_stats[strings.S.knockback] = 2f;//击退+1
            GuShi5.base_stats["Resist"] = 2f;
            GuShi5.base_stats[strings.S.warfare] = 7f;
            GuShi5.base_stats[strings.S.stewardship] = 16f;
            GuShi5.base_stats["Dodge"] = 110f;
            GuShi5.base_stats["Accuracy"] = 80f;
            GuShi5.base_stats[strings.S.mass_2] = 35f;//体重+35
            GuShi5.base_stats[strings.S.accuracy] = 35f; //准确度+35
            GuShi5.base_stats[strings.S.stamina] = 100f; //耐力+100
            GuShi5.action_special_effect += traitAction.GuShi6_effectAction; //升高级巫师•巅峰的条件
            GuShi5.action_special_effect += (WorldAction)Delegate.Combine(GuShi5.action_special_effect,
                new WorldAction(traitAction.GuShi5_Regen)); //高级巫师•扩展的再生效果
            AssetManager.traits.add(GuShi5);


            ActorTrait GuShi6 = new ActorTrait();
            GuShi6.id = "GuShi6"; //高级巫师•巅峰
            GuShi6.path_icon = "trait/GuShi6";
            GuShi6.needs_to_be_explored = false;
            GuShi6.group_id = "GuZhenren2";
            GuShi6.base_stats = new BaseStats();
            GuShi6.base_stats[strings.S.lifespan] = 170f;
            GuShi6.base_stats[strings.S.damage] = 4000f;
            GuShi6.base_stats[strings.S.health] = 40000f;
            GuShi6.base_stats[strings.S.armor] = 50f;
            GuShi6.base_stats[strings.S.speed] = 30f;
            GuShi6.base_stats[strings.S.intelligence] = 150f;
            GuShi6.base_stats[strings.S.attack_speed] = 1f;
            GuShi6.base_stats[strings.S.range] = 8f;
            GuShi6.base_stats[strings.S.area_of_effect] = 10f;
            GuShi6.base_stats[strings.S.targets] = 6f;
            GuShi6.base_stats[strings.S.knockback] = 2f;
            GuShi6.base_stats["Resist"] = 2f;
            GuShi6.base_stats[strings.S.warfare] = 9f;
            GuShi6.base_stats[strings.S.stewardship] = 18f;
            GuShi6.base_stats["Dodge"] = 120f;
            GuShi6.base_stats["Accuracy"] = 90f;
            GuShi6.base_stats[strings.S.mass_2] = 40f;//体重+40
            GuShi6.base_stats[strings.S.accuracy] = 40f; //准确度+40
            GuShi6.base_stats[strings.S.stamina] = 120f; //耐力+120
            GuShi6.action_special_effect += traitAction.GuShi7_effectAction; //升大巫师•铭刻的条件
            GuShi6.action_special_effect += (WorldAction)Delegate.Combine(GuShi6.action_special_effect,
                new WorldAction(traitAction.GuShi6_Regen)); //高级巫师•巅峰三阶的再生效果
            AssetManager.traits.add(GuShi6);


            ActorTrait GuShi7 = new ActorTrait();
            GuShi7.id = "GuShi7"; //大巫师•铭刻
            GuShi7.path_icon = "trait/GuShi7";
            GuShi7.needs_to_be_explored = false;
            GuShi7.group_id = "GuZhenren2";
            GuShi7.base_stats = new BaseStats();
            GuShi7.base_stats[strings.S.lifespan] = 240f;
            GuShi7.base_stats[strings.S.damage] = 10000f;
            GuShi7.base_stats[strings.S.health] = 100000f;
            GuShi7.base_stats[strings.S.intelligence] = 250f;
            GuShi7.base_stats[strings.S.critical_chance] = 0.10f;
            GuShi7.base_stats[strings.S.armor] = 80f;
            GuShi7.base_stats[strings.S.speed] = 50f;
            GuShi7.base_stats[strings.S.multiplier_damage] = 0.20f;
            GuShi7.base_stats[strings.S.multiplier_health] = 0.20f;
            GuShi7.base_stats[strings.S.range] = 10f;
            GuShi7.base_stats[strings.S.area_of_effect] = 15f;
            GuShi7.base_stats[strings.S.targets] = 10f;
            GuShi7.base_stats[strings.S.knockback] = 3f;
            GuShi7.base_stats["Resist"] = 3f;
            GuShi7.base_stats[strings.S.warfare] = 10f;
            GuShi7.base_stats[strings.S.stewardship] = 20f;
            GuShi7.base_stats["Dodge"] = 150f;
            GuShi7.base_stats["Accuracy"] = 120f;
            GuShi7.base_stats[strings.S.mass_2] = 50f;//体重+50
            GuShi7.base_stats[strings.S.accuracy] = 50f; //准确度+50
            GuShi7.base_stats[strings.S.stamina] = 240f; //耐力+240
            GuShi7.action_special_effect += traitAction.GuShi8_effectAction; //大巫师•巅峰的条件
            GuShi7.action_special_effect += (WorldAction)Delegate.Combine(GuShi7.action_special_effect,
                new WorldAction(traitAction.GuShi7_Regen)); //大巫师•铭刻的再生效果
            AssetManager.traits.add(GuShi7);


            ActorTrait GuShi8 = new ActorTrait();
            GuShi8.id = "GuShi8"; //大巫师•巅峰
            GuShi8.path_icon = "trait/GuShi8";
            GuShi8.needs_to_be_explored = false;
            GuShi8.group_id = "GuZhenren2";
            GuShi8.base_stats = new BaseStats();
            GuShi8.base_stats[strings.S.lifespan] = 340f;
            GuShi8.base_stats[strings.S.damage] = 20000f;
            GuShi8.base_stats[strings.S.health] = 200000f;
            GuShi8.base_stats[strings.S.intelligence] = 350f;
            GuShi8.base_stats[strings.S.critical_chance] = 0.10f;
            GuShi8.base_stats[strings.S.armor] = 100f;
            GuShi8.base_stats[strings.S.speed] = 60f;
            GuShi8.base_stats[strings.S.multiplier_damage] = 0.20f;
            GuShi8.base_stats[strings.S.multiplier_health] = 0.20f;
            GuShi8.base_stats[strings.S.range] = 10f;
            GuShi8.base_stats[strings.S.area_of_effect] = 20f;
            GuShi8.base_stats[strings.S.targets] = 15f;
            GuShi8.base_stats[strings.S.knockback] = 3f;
            GuShi8.base_stats["Resist"] = 3f;
            GuShi8.base_stats[strings.S.warfare] = 12f;
            GuShi8.base_stats[strings.S.stewardship] = 23f;
            GuShi8.base_stats["Dodge"] = 180f;
            GuShi8.base_stats["Accuracy"] = 150f;
            GuShi8.base_stats[strings.S.mass_2] = 60f;//体重+60
            GuShi8.base_stats[strings.S.accuracy] = 60f; //准确度+60
            GuShi8.base_stats[strings.S.stamina] = 360f; //耐力+360
            GuShi8.action_special_effect += traitAction.GuShi9_effectAction; //升大巫师•不死的条件
            GuShi8.action_special_effect += (WorldAction)Delegate.Combine(GuShi8.action_special_effect,
                new WorldAction(traitAction.GuShi8_Regen)); //大巫师•巅峰的再生效果
            AssetManager.traits.add(GuShi8);


            ActorTrait GuShi9 = new ActorTrait();
            GuShi9.id = "GuShi9"; //大巫师•不死
            GuShi9.path_icon = "trait/GuShi9";
            GuShi9.needs_to_be_explored = false;
            GuShi9.group_id = "GuZhenren2";
            GuShi9.base_stats = new BaseStats();
            GuShi9.base_stats[strings.S.lifespan] = 500f;
            GuShi9.base_stats[strings.S.damage] = 40000f;
            GuShi9.base_stats[strings.S.health] = 400000f;
            GuShi9.base_stats[strings.S.armor] = 200f;
            GuShi9.base_stats[strings.S.speed] = 80f;
            GuShi9.base_stats[strings.S.intelligence] = 550f;
            GuShi9.base_stats[strings.S.critical_chance] = 0.10f;
            GuShi9.base_stats[strings.S.multiplier_damage] = 0.20f;
            GuShi9.base_stats[strings.S.multiplier_health] = 0.20f;
            GuShi9.base_stats[strings.S.range] = 10f;
            GuShi9.base_stats[strings.S.area_of_effect] = 25f;
            GuShi9.base_stats[strings.S.targets] = 20f;
            GuShi9.base_stats[strings.S.knockback] = 5f;
            GuShi9.base_stats["Resist"] = 5f;
            GuShi9.base_stats[strings.S.warfare] = 12f;
            GuShi9.base_stats[strings.S.stewardship] = 25f;
            GuShi9.base_stats["Dodge"] = 210f;
            GuShi9.base_stats["Accuracy"] = 180f;
            GuShi9.base_stats[strings.S.mass_2] = 80f;//体重+80
            GuShi9.base_stats[strings.S.accuracy] = 80f; //准确度+80
            GuShi9.base_stats[strings.S.stamina] = 500f; //耐力+500
            GuShi9.action_special_effect += traitAction.GuShi91_effectAction; //升始祖的条件
            GuShi9.action_special_effect += (WorldAction)Delegate.Combine(GuShi9.action_special_effect,
                new WorldAction(traitAction.GuShi9_Regen)); //大巫师•不死的再生效果
            AssetManager.traits.add(GuShi9);

            ActorTrait GuShi91 = new ActorTrait();
            GuShi91.id = "GuShi91"; //始祖
            GuShi91.path_icon = "trait/GuShi11";
            GuShi91.needs_to_be_explored = false;
            GuShi91.group_id = "GuZhenren2";
            GuShi91.base_stats = new BaseStats();
            GuShi91.base_stats[strings.S.lifespan] = 20000f;//10E寿命
            GuShi91.base_stats[strings.S.damage] = 200000f;//1000w伤害
            GuShi91.base_stats[strings.S.health] = 2000000f;//1E血量
            GuShi91.base_stats[strings.S.armor] = 300f;
            GuShi91.base_stats[strings.S.speed] = 100f;
            GuShi91.base_stats[strings.S.intelligence] = 999f;
            GuShi91.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi91.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi91.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi91.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi91.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi91.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi91.base_stats[strings.S.knockback] = 10f;//击退
            GuShi91.base_stats["Resist"] = 10f;
            GuShi91.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi91.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi91.base_stats["Dodge"] = 270f;
            GuShi91.base_stats["Accuracy"] = 240f;
            GuShi91.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi91.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi91.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi91.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi91.action_special_effect += traitAction.GuShi92_effectAction;
            GuShi91.action_special_effect += (WorldAction)Delegate.Combine(GuShi91.action_special_effect,
                new WorldAction(traitAction.GuShi91_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi91);

            ActorTrait GuShi92 = new ActorTrait();
            GuShi92.id = "GuShi92"; //始祖
            GuShi92.path_icon = "trait/GuShi11";
            GuShi92.needs_to_be_explored = false;
            GuShi92.group_id = "GuZhenren2";
            GuShi92.base_stats = new BaseStats();
            GuShi92.base_stats[strings.S.lifespan] = 20000f;//10E寿命
            GuShi92.base_stats[strings.S.damage] = 200000f;//1000w伤害
            GuShi92.base_stats[strings.S.health] = 2000000f;//1E血量
            GuShi92.base_stats[strings.S.armor] = 300f;
            GuShi92.base_stats[strings.S.speed] = 100f;
            GuShi92.base_stats[strings.S.intelligence] = 999f;
            GuShi92.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi92.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi92.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi92.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi92.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi92.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi92.base_stats[strings.S.knockback] = 10f;//击退
            GuShi92.base_stats["Resist"] = 10f;
            GuShi92.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi92.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi92.base_stats["Dodge"] = 270f;
            GuShi92.base_stats["Accuracy"] = 240f;
            GuShi92.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi92.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi92.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi92.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi92.action_special_effect += traitAction.GuShi93_effectAction;
            GuShi92.action_special_effect += (WorldAction)Delegate.Combine(GuShi92.action_special_effect,
                new WorldAction(traitAction.GuShi92_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi92);

            ActorTrait GuShi93 = new ActorTrait();
            GuShi93.id = "GuShi93"; //始祖
            GuShi93.path_icon = "trait/GuShi12";
            GuShi93.needs_to_be_explored = false;
            GuShi93.group_id = "GuZhenren2";
            GuShi93.base_stats = new BaseStats();
            GuShi93.base_stats[strings.S.lifespan] = 30000f;//10E寿命
            GuShi93.base_stats[strings.S.damage] = 400000f;//1000w伤害
            GuShi93.base_stats[strings.S.health] = 4000000f;//1E血量
            GuShi93.base_stats[strings.S.armor] = 300f;
            GuShi93.base_stats[strings.S.speed] = 100f;
            GuShi93.base_stats[strings.S.intelligence] = 999f;
            GuShi93.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi93.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi93.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi93.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi93.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi93.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi93.base_stats[strings.S.knockback] = 10f;//击退
            GuShi93.base_stats["Resist"] = 10f;
            GuShi93.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi93.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi93.base_stats["Spiritstone"] = -10f;
            GuShi93.base_stats["Dodge"] = 300f;
            GuShi93.base_stats["Accuracy"] = 270f;
            GuShi93.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi93.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi93.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi93.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi93.action_special_effect += traitAction.GuShi94_effectAction;
            GuShi93.action_special_effect += (WorldAction)Delegate.Combine(GuShi93.action_special_effect,
                new WorldAction(traitAction.GuShi93_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi93);

            ActorTrait GuShi94 = new ActorTrait();
            GuShi94.id = "GuShi94"; //始祖
            GuShi94.path_icon = "trait/GuShi13";
            GuShi94.needs_to_be_explored = false;
            GuShi94.group_id = "GuZhenren2";
            GuShi94.base_stats = new BaseStats();
            GuShi94.base_stats[strings.S.lifespan] = 50000f;//10E寿命
            GuShi94.base_stats[strings.S.damage] = 1000000f;//1000w伤害
            GuShi94.base_stats[strings.S.health] = 10000000f;//1E血量
            GuShi94.base_stats[strings.S.armor] = 300f;
            GuShi94.base_stats[strings.S.speed] = 100f;
            GuShi94.base_stats[strings.S.intelligence] = 999f;
            GuShi94.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi94.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi94.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi94.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi94.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi94.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi94.base_stats[strings.S.knockback] = 10f;//击退
            GuShi94.base_stats["Resist"] = 10f;
            GuShi94.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi94.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi94.base_stats["Dodge"] = 500f;
            GuShi94.base_stats["Accuracy"] = 470f;
            GuShi94.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi94.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi94.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi94.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi94.action_attack_target += new AttackAction((traitAction.attack_GuShi9));
            GuShi94.action_special_effect += traitAction.GuShi95_effectAction;
            GuShi94.action_special_effect += (WorldAction)Delegate.Combine(GuShi94.action_special_effect,
                new WorldAction(traitAction.GuShi94_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi94);

            ActorTrait GuShi95 = new ActorTrait();
            GuShi95.id = "GuShi95"; //始祖
            GuShi95.path_icon = "trait/GuShi14";
            GuShi95.needs_to_be_explored = false;
            GuShi95.group_id = "GuZhenren2";
            GuShi95.base_stats = new BaseStats();
            GuShi95.base_stats[strings.S.lifespan] = 100000f;//10E寿命
            GuShi95.base_stats[strings.S.damage] = 2000000f;//1000w伤害
            GuShi95.base_stats[strings.S.health] = 20000000f;//1E血量
            GuShi95.base_stats[strings.S.armor] = 300f;
            GuShi95.base_stats[strings.S.speed] = 100f;
            GuShi95.base_stats[strings.S.intelligence] = 999f;
            GuShi95.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi95.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi95.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi95.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi95.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi95.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi95.base_stats[strings.S.knockback] = 10f;//击退
            GuShi95.base_stats["Resist"] = 10f;
            GuShi95.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi95.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi95.base_stats["Dodge"] = 530f;
            GuShi95.base_stats["Accuracy"] = 500f;
            GuShi95.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi95.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi95.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi95.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi95.action_attack_target += new AttackAction((traitAction.attack_GuShi9));
            GuShi95.action_special_effect += traitAction.GuShi96_effectAction;
            GuShi95.action_special_effect += (WorldAction)Delegate.Combine(GuShi95.action_special_effect,
                new WorldAction(traitAction.GuShi95_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi95);

            ActorTrait GuShi96 = new ActorTrait();
            GuShi96.id = "GuShi96"; //始祖
            GuShi96.path_icon = "trait/GuShi15";
            GuShi96.needs_to_be_explored = false;
            GuShi96.group_id = "GuZhenren2";
            GuShi96.base_stats = new BaseStats();
            GuShi96.base_stats[strings.S.lifespan] = 1000000f;//10E寿命
            GuShi96.base_stats[strings.S.damage] = 4000000f;//1000w伤害
            GuShi96.base_stats[strings.S.health] = 40000000f;//1E血量
            GuShi96.base_stats[strings.S.armor] = 300f;
            GuShi96.base_stats[strings.S.speed] = 100f;
            GuShi96.base_stats[strings.S.intelligence] = 999f;
            GuShi96.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi96.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi96.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi96.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi96.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi96.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi96.base_stats[strings.S.knockback] = 10f;//击退
            GuShi96.base_stats["Resist"] = 10f;
            GuShi96.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi96.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi96.base_stats["Dodge"] = 560f;
            GuShi96.base_stats["Accuracy"] = 530f;
            GuShi96.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi96.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi96.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi96.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi96.action_attack_target += new AttackAction((traitAction.attack_GuShi9));
            GuShi96.action_special_effect += traitAction.GuShi97_effectAction;
            GuShi96.action_special_effect += (WorldAction)Delegate.Combine(GuShi96.action_special_effect,
                new WorldAction(traitAction.GuShi96_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi96);

            ActorTrait GuShi97 = new ActorTrait();
            GuShi97.id = "GuShi97"; //始祖
            GuShi97.path_icon = "trait/GuShi16";
            GuShi97.needs_to_be_explored = false;
            GuShi97.group_id = "GuZhenren2";
            GuShi97.base_stats = new BaseStats();
            GuShi97.base_stats[strings.S.lifespan] = 10000000f;//10E寿命
            GuShi97.base_stats[strings.S.damage] = 10000000f;//1000w伤害
            GuShi97.base_stats[strings.S.health] = 100000000f;//1E血量
            GuShi97.base_stats[strings.S.armor] = 300f;
            GuShi97.base_stats[strings.S.speed] = 100f;
            GuShi97.base_stats[strings.S.intelligence] = 999f;
            GuShi97.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi97.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi97.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi97.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi97.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi97.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi97.base_stats[strings.S.knockback] = 10f;//击退
            GuShi97.base_stats["Resist"] = 10f;
            GuShi97.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi97.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi97.base_stats["Dodge"] = 590f;
            GuShi97.base_stats["Accuracy"] = 560f;
            GuShi97.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi97.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi97.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi97.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi97.action_attack_target += new AttackAction((traitAction.attack_GuShi97));
            GuShi97.action_special_effect += traitAction.GuShi98_effectAction;
            GuShi97.action_special_effect += (WorldAction)Delegate.Combine(GuShi97.action_special_effect,
                new WorldAction(traitAction.GuShi97_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi97);

            ActorTrait GuShi98 = new ActorTrait();
            GuShi98.id = "GuShi98"; //始祖
            GuShi98.path_icon = "trait/GuShi17";
            GuShi98.needs_to_be_explored = false;
            GuShi98.group_id = "GuZhenren2";
            GuShi98.base_stats = new BaseStats();
            GuShi98.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi98.base_stats[strings.S.damage] = 20000000f;//1000w伤害
            GuShi98.base_stats[strings.S.health] = 200000000f;//1E血量
            GuShi98.base_stats[strings.S.armor] = 300f;
            GuShi98.base_stats[strings.S.speed] = 100f;
            GuShi98.base_stats[strings.S.intelligence] = 999f;
            GuShi98.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi98.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi98.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi98.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi98.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi98.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi98.base_stats[strings.S.knockback] = 10f;//击退
            GuShi98.base_stats["Resist"] = 10f;
            GuShi98.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi98.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi98.base_stats["Dodge"] = 620f;
            GuShi98.base_stats["Accuracy"] = 590f;
            GuShi98.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi98.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi98.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi98.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi98.action_attack_target += new AttackAction((traitAction.attack_GuShi97));
            GuShi98.action_special_effect += traitAction.GuShi99_effectAction;
            GuShi98.action_special_effect += (WorldAction)Delegate.Combine(GuShi98.action_special_effect,
                new WorldAction(traitAction.GuShi98_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi98);

            ActorTrait GuShi99 = new ActorTrait();
            GuShi99.id = "GuShi99"; //始祖
            GuShi99.path_icon = "trait/GuShi18";
            GuShi99.needs_to_be_explored = false;
            GuShi99.group_id = "GuZhenren2";
            GuShi99.base_stats = new BaseStats();
            GuShi99.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi99.base_stats[strings.S.damage] = 40000000f;//1000w伤害
            GuShi99.base_stats[strings.S.health] = 400000000f;//1E血量
            GuShi99.base_stats[strings.S.armor] = 300f;
            GuShi99.base_stats[strings.S.speed] = 100f;
            GuShi99.base_stats[strings.S.intelligence] = 999f;
            GuShi99.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi99.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi99.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi99.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi99.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi99.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi99.base_stats[strings.S.knockback] = 10f;//击退
            GuShi99.base_stats["Resist"] = 10f;
            GuShi99.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi99.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi99.base_stats["Dodge"] = 650f;
            GuShi99.base_stats["Accuracy"] = 630f;
            GuShi99.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi99.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi99.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi99.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi99.action_attack_target += new AttackAction((traitAction.attack_GuShi97));
            GuShi99.action_special_effect += traitAction.GuShi991_effectAction;
            GuShi99.action_special_effect += (WorldAction)Delegate.Combine(GuShi99.action_special_effect,
                new WorldAction(traitAction.GuShi99_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi99);

            ActorTrait GuShi991 = new ActorTrait();
            GuShi991.id = "GuShi991"; //始祖
            GuShi991.path_icon = "trait/GuShi19";
            GuShi991.needs_to_be_explored = false;
            GuShi991.group_id = "GuZhenren2";
            GuShi991.base_stats = new BaseStats();
            GuShi991.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi991.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi991.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi991.base_stats[strings.S.armor] = 300f;
            GuShi991.base_stats[strings.S.speed] = 100f;
            GuShi991.base_stats[strings.S.intelligence] = 999f;
            GuShi991.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi991.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi991.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi991.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi991.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi991.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi991.base_stats[strings.S.knockback] = 10f;//击退
            GuShi991.base_stats["Resist"] = 10f;
            GuShi991.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi991.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi991.base_stats["Spiritstone"] = -500f;
            GuShi991.base_stats["Dodge"] = 740f;
            GuShi991.base_stats["Accuracy"] = 710f;
            GuShi991.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi991.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi991.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi991.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi991.action_attack_target += new AttackAction((traitAction.attack_GuShi991));
            GuShi991.action_special_effect += traitAction.GuShi992_effectAction;
            GuShi991.action_special_effect += (WorldAction)Delegate.Combine(GuShi991.action_special_effect,
                new WorldAction(traitAction.GuShi991_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi991);

            ActorTrait GuShi992 = new ActorTrait();
            GuShi992.id = "GuShi992"; //始祖
            GuShi992.path_icon = "trait/GuShi20";
            GuShi992.needs_to_be_explored = false;
            GuShi992.group_id = "GuZhenren2";
            GuShi992.base_stats = new BaseStats();
            GuShi992.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi992.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi992.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi992.base_stats[strings.S.armor] = 300f;
            GuShi992.base_stats[strings.S.speed] = 100f;
            GuShi992.base_stats[strings.S.intelligence] = 999f;
            GuShi992.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi992.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi992.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi992.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi992.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi992.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi992.base_stats[strings.S.knockback] = 10f;//击退
            GuShi992.base_stats["Resist"] = 10f;
            GuShi992.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi992.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi992.base_stats["Spiritstone"] = -500f;
            GuShi992.base_stats["Dodge"] = 770f;
            GuShi992.base_stats["Accuracy"] = 740f;
            GuShi992.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi992.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi992.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi992.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi992.action_attack_target += new AttackAction((traitAction.attack_GuShi991));
            GuShi992.action_special_effect += traitAction.GuShi993_effectAction;
            GuShi992.action_special_effect += (WorldAction)Delegate.Combine(GuShi992.action_special_effect,
                new WorldAction(traitAction.GuShi992_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi992);

            ActorTrait GuShi993 = new ActorTrait();
            GuShi993.id = "GuShi993"; //始祖
            GuShi993.path_icon = "trait/GuShi21";
            GuShi993.needs_to_be_explored = false;
            GuShi993.group_id = "GuZhenren2";
            GuShi993.base_stats = new BaseStats();
            GuShi993.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi993.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi993.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi993.base_stats[strings.S.armor] = 300f;
            GuShi993.base_stats[strings.S.speed] = 100f;
            GuShi993.base_stats[strings.S.intelligence] = 999f;
            GuShi993.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi993.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi993.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi993.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi993.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi993.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi993.base_stats[strings.S.knockback] = 10f;//击退
            GuShi993.base_stats["Resist"] = 10f;
            GuShi993.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi993.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi993.base_stats["Spiritstone"] = -500f;
            GuShi993.base_stats["Dodge"] = 800f;
            GuShi993.base_stats["Accuracy"] = 770f;
            GuShi993.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi993.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi993.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi993.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi993.action_attack_target += new AttackAction((traitAction.attack_GuShi991));
            GuShi993.action_special_effect += traitAction.GuShi994_effectAction;
            GuShi993.action_special_effect += (WorldAction)Delegate.Combine(GuShi993.action_special_effect,
                new WorldAction(traitAction.GuShi993_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi993);

            ActorTrait GuShi994 = new ActorTrait();
            GuShi994.id = "GuShi994"; //始祖
            GuShi994.path_icon = "trait/GuShi22";
            GuShi994.needs_to_be_explored = false;
            GuShi994.group_id = "GuZhenren2";
            GuShi994.base_stats = new BaseStats();
            GuShi994.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi994.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi994.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi994.base_stats[strings.S.armor] = 300f;
            GuShi994.base_stats[strings.S.speed] = 100f;
            GuShi994.base_stats[strings.S.intelligence] = 999f;
            GuShi994.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi994.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi994.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi994.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi994.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi994.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi994.base_stats[strings.S.knockback] = 10f;//击退
            GuShi994.base_stats["Resist"] = 10f;
            GuShi994.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi994.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi994.base_stats["Spiritstone"] = -500f;
            GuShi994.base_stats["Dodge"] = 900f;
            GuShi994.base_stats["Accuracy"] = 870f;
            GuShi994.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi994.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi994.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi994.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi994.action_attack_target += new AttackAction((traitAction.attack_GuShi996));
            GuShi994.action_special_effect += traitAction.GuShi995_effectAction;
            GuShi994.action_special_effect += (WorldAction)Delegate.Combine(GuShi994.action_special_effect,
                new WorldAction(traitAction.GuShi994_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi994);

            ActorTrait GuShi995 = new ActorTrait();
            GuShi995.id = "GuShi995"; //始祖
            GuShi995.path_icon = "trait/GuShi23";
            GuShi995.needs_to_be_explored = false;
            GuShi995.group_id = "GuZhenren2";
            GuShi995.base_stats = new BaseStats();
            GuShi995.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi995.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi995.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi995.base_stats[strings.S.armor] = 300f;
            GuShi995.base_stats[strings.S.speed] = 100f;
            GuShi995.base_stats[strings.S.intelligence] = 999f;
            GuShi995.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi995.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi995.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi995.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi995.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi995.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi995.base_stats[strings.S.knockback] = 10f;//击退
            GuShi995.base_stats["Resist"] = 10f;
            GuShi995.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi995.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi995.base_stats["Spiritstone"] = -500f;
            GuShi995.base_stats["Dodge"] = 930f;
            GuShi995.base_stats["Accuracy"] = 900f;
            GuShi995.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi995.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi995.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi995.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi995.action_attack_target += new AttackAction((traitAction.attack_GuShi996));
            GuShi995.action_special_effect += traitAction.GuShi996_effectAction;
            GuShi995.action_special_effect += (WorldAction)Delegate.Combine(GuShi995.action_special_effect,
                new WorldAction(traitAction.GuShi995_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi995);

            ActorTrait GuShi996 = new ActorTrait();
            GuShi996.id = "GuShi996"; //始祖
            GuShi996.path_icon = "trait/GuShi24";
            GuShi996.needs_to_be_explored = false;
            GuShi996.group_id = "GuZhenren2";
            GuShi996.base_stats = new BaseStats();
            GuShi996.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi996.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi996.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi996.base_stats[strings.S.armor] = 300f;
            GuShi996.base_stats[strings.S.speed] = 100f;
            GuShi996.base_stats[strings.S.intelligence] = 999f;
            GuShi996.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi996.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi996.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi996.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi996.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi996.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi996.base_stats[strings.S.knockback] = 10f;//击退
            GuShi996.base_stats["Resist"] = 10f;
            GuShi996.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi996.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi996.base_stats["Spiritstone"] = -500f;
            GuShi996.base_stats["Dodge"] = 960f;
            GuShi996.base_stats["Accuracy"] = 930f;
            GuShi996.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi996.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi996.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi996.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi996.action_attack_target += new AttackAction((traitAction.attack_GuShi996));
            GuShi996.action_special_effect += traitAction.GuShi997_effectAction;
            GuShi996.action_special_effect += (WorldAction)Delegate.Combine(GuShi996.action_special_effect,
                new WorldAction(traitAction.GuShi996_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi996);

            ActorTrait GuShi997 = new ActorTrait();
            GuShi997.id = "GuShi997"; //始祖
            GuShi997.path_icon = "trait/GuShi25";
            GuShi997.needs_to_be_explored = false;
            GuShi997.group_id = "GuZhenren2";
            GuShi997.base_stats = new BaseStats();
            GuShi997.base_stats[strings.S.lifespan] = 1000000000f;//10E寿命
            GuShi997.base_stats[strings.S.damage] = 100000000f;//1000w伤害
            GuShi997.base_stats[strings.S.health] = 1000000000f;//1E血量
            GuShi997.base_stats[strings.S.armor] = 300f;
            GuShi997.base_stats[strings.S.speed] = 100f;
            GuShi997.base_stats[strings.S.intelligence] = 999f;
            GuShi997.base_stats[strings.S.critical_chance] = 0.30f;
            GuShi997.base_stats[strings.S.multiplier_damage] = 0.30f;
            GuShi997.base_stats[strings.S.multiplier_health] = 0.30f;
            GuShi997.base_stats[strings.S.range] = 20f;//攻击范围
            GuShi997.base_stats[strings.S.area_of_effect] = 60f;//近战攻击范围
            GuShi997.base_stats[strings.S.targets] = 30f;//可攻击的目标
            GuShi997.base_stats[strings.S.knockback] = 10f;//击退
            GuShi997.base_stats["Resist"] = 10f;
            GuShi997.base_stats[strings.S.warfare] = 15f;//指挥
            GuShi997.base_stats[strings.S.stewardship] = 30f;//组织
            GuShi997.base_stats["Spiritstone"] = -500f;
            GuShi997.base_stats["Dodge"] = 10030f;
            GuShi997.base_stats["Accuracy"] = 10000f;
            GuShi997.base_stats[strings.S.mass_2] = 300f;//体重+100
            GuShi997.base_stats[strings.S.accuracy] = 300f;//准确度
            GuShi997.base_stats[strings.S.attack_speed] = 10f;//攻速
            GuShi997.base_stats[strings.S.stamina] = 10000000f; //耐力+1000w
            GuShi997.action_attack_target += new AttackAction((traitAction.attack_GuShi997));
            GuShi997.action_special_effect += new WorldAction((traitAction.hunger_GuShi91));//不会饥饿
            GuShi997.action_get_hit += new GetHitAction(traitAction.GuShi91_Attack);
            GuShi997.action_special_effect += (WorldAction)Delegate.Combine(GuShi997.action_special_effect,
                new WorldAction(traitAction.GuShi997_EffectAction)); //始祖的再生效果
            AssetManager.traits.add(GuShi997);

            ActorTrait Insectworm01 = new ActorTrait();
            Insectworm01.id = "Insectworm01"; //零环•轻身术
            Insectworm01.path_icon = "trait/Insectworm01";
            Insectworm01.needs_to_be_explored = false;
            Insectworm01.group_id = "GuZhenren4";
            Insectworm01.action_attack_target += new AttackAction((traitAction.attack_Insectworm01));
            AssetManager.traits.add(Insectworm01);

            ActorTrait Insectworm02 = new ActorTrait();
            Insectworm02.id = "Insectworm02"; //零环•烈焰之握
            Insectworm02.path_icon = "trait/Insectworm02";
            Insectworm02.needs_to_be_explored = false;
            Insectworm02.group_id = "GuZhenren4";
            Insectworm02.action_attack_target += new AttackAction((traitAction.attack_Insectworm02));
            AssetManager.traits.add(Insectworm02);

            ActorTrait Insectworm03 = new ActorTrait();
            Insectworm03.id = "Insectworm03"; //零环•水幻迷障
            Insectworm03.path_icon = "trait/Insectworm03";
            Insectworm03.needs_to_be_explored = false;
            Insectworm03.group_id = "GuZhenren4";
            Insectworm03.action_attack_target += new AttackAction((traitAction.attack_Insectworm03));
            AssetManager.traits.add(Insectworm03);

            ActorTrait Insectworm04 = new ActorTrait();
            Insectworm04.id = "Insectworm04"; //零环•生命祈愈
            Insectworm04.path_icon = "trait/Insectworm04";
            Insectworm04.needs_to_be_explored = false;
            Insectworm04.group_id = "GuZhenren4";
            Insectworm04.base_stats = new BaseStats();
            Insectworm04.base_stats[strings.S.health] = 100f;
            Insectworm04.action_special_effect += (WorldAction)Delegate.Combine(Insectworm04.action_special_effect,
                new WorldAction(traitAction.Insectworm04_Regen)); //再生效果
            AssetManager.traits.add(Insectworm04);

            ActorTrait Insectworm05 = new ActorTrait();
            Insectworm05.id = "Insectworm05"; //零环•大地壁垒
            Insectworm05.path_icon = "trait/Insectworm05";
            Insectworm05.needs_to_be_explored = false;
            Insectworm05.group_id = "GuZhenren4";
            Insectworm05.action_attack_target += new AttackAction((traitAction.attack_Insectworm05));
            AssetManager.traits.add(Insectworm05);

            ActorTrait Insectworm06 = new ActorTrait();
            Insectworm06.id = "Insectworm06"; //零环•蔓藤囚牢
            Insectworm06.path_icon = "trait/Insectworm06";
            Insectworm06.needs_to_be_explored = false;
            Insectworm06.group_id = "GuZhenren4";
            Insectworm06.action_attack_target += new AttackAction((traitAction.attack_Insectworm06));
            AssetManager.traits.add(Insectworm06);

            ActorTrait Insectworm07 = new ActorTrait();
            Insectworm07.id = "Insectworm07"; //零环•鹰隼凝视
            Insectworm07.path_icon = "trait/Insectworm07";
            Insectworm07.needs_to_be_explored = false;
            Insectworm07.group_id = "GuZhenren4";
            Insectworm07.action_attack_target += new AttackAction((traitAction.attack_Insectworm07));
            AssetManager.traits.add(Insectworm07);

            ActorTrait Insectworm11 = new ActorTrait();
            Insectworm11.id = "Insectworm11"; //一环•肌肉松弛术
            Insectworm11.path_icon = "trait/Insectworm11";
            Insectworm11.needs_to_be_explored = false;
            Insectworm11.group_id = "GuZhenren4";
            Insectworm11.action_attack_target += new AttackAction((traitAction.attack_Insectworm11));
            AssetManager.traits.add(Insectworm11);

            ActorTrait Insectworm12 = new ActorTrait();
            Insectworm12.id = "Insectworm12"; //一环•缠绕之网
            Insectworm12.path_icon = "trait/Insectworm12";
            Insectworm12.needs_to_be_explored = false;
            Insectworm12.group_id = "GuZhenren4";
            Insectworm12.action_attack_target += new AttackAction((traitAction.attack_Insectworm12));
            AssetManager.traits.add(Insectworm12);

            ActorTrait Insectworm13 = new ActorTrait();
            Insectworm13.id = "Insectworm13"; //一环•土之坚甲
            Insectworm13.path_icon = "trait/Insectworm13";
            Insectworm13.needs_to_be_explored = false;
            Insectworm13.group_id = "GuZhenren4";
            Insectworm13.action_attack_target += new AttackAction((traitAction.attack_Insectworm13));
            AssetManager.traits.add(Insectworm13);

            ActorTrait Insectworm14 = new ActorTrait();
            Insectworm14.id = "Insectworm14"; //一环•复苏之流
            Insectworm14.path_icon = "trait/Insectworm14";
            Insectworm14.needs_to_be_explored = false;
            Insectworm14.group_id = "GuZhenren4";
            Insectworm14.base_stats = new BaseStats();
            Insectworm14.base_stats[strings.S.health] = 250f;
            Insectworm14.action_special_effect += (WorldAction)Delegate.Combine(Insectworm14.action_special_effect,
                new WorldAction(traitAction.Insectworm14_Regen)); //再生效果
            AssetManager.traits.add(Insectworm14);

            ActorTrait Insectworm15 = new ActorTrait();
            Insectworm15.id = "Insectworm15"; //一环•风行术
            Insectworm15.path_icon = "trait/Insectworm15";
            Insectworm15.needs_to_be_explored = false;
            Insectworm15.group_id = "GuZhenren4";
            Insectworm15.action_attack_target += new AttackAction((traitAction.attack_Insectworm15));
            AssetManager.traits.add(Insectworm15);

            ActorTrait Insectworm16 = new ActorTrait();
            Insectworm16.id = "Insectworm16"; //一环•水雾术
            Insectworm16.path_icon = "trait/Insectworm16";
            Insectworm16.needs_to_be_explored = false;
            Insectworm16.group_id = "GuZhenren4";
            Insectworm16.action_attack_target += new AttackAction((traitAction.attack_Insectworm16));
            AssetManager.traits.add(Insectworm16);

            ActorTrait Insectworm17 = new ActorTrait();
            Insectworm17.id = "Insectworm17"; //一环•气机牵引
            Insectworm17.path_icon = "trait/Insectworm17";
            Insectworm17.needs_to_be_explored = false;
            Insectworm17.group_id = "GuZhenren4";
            Insectworm17.action_attack_target += new AttackAction((traitAction.attack_Insectworm17));
            AssetManager.traits.add(Insectworm17);

            ActorTrait Insectworm18 = new ActorTrait();
            Insectworm18.id = "Insectworm18"; //一环•破甲附魔
            Insectworm18.path_icon = "trait/Insectworm18";
            Insectworm18.needs_to_be_explored = false;
            Insectworm18.group_id = "GuZhenren4";
            Insectworm18.action_attack_target += new AttackAction((traitAction.attack_Insectworm18));
            AssetManager.traits.add(Insectworm18);

            ActorTrait Insectworm22 = new ActorTrait();
            Insectworm22.id = "Insectworm22"; //二环•星之致幻
            Insectworm22.path_icon = "trait/Insectworm22";
            Insectworm22.needs_to_be_explored = false;
            Insectworm22.group_id = "GuZhenren4";
            Insectworm22.action_attack_target += new AttackAction((traitAction.attack_Insectworm22));
            AssetManager.traits.add(Insectworm22);

            ActorTrait Insectworm23 = new ActorTrait();
            Insectworm23.id = "Insectworm23"; //二环•血液汲取
            Insectworm23.path_icon = "trait/Insectworm23";
            Insectworm23.needs_to_be_explored = false;
            Insectworm23.group_id = "GuZhenren4";
            Insectworm23.action_attack_target += new AttackAction((traitAction.attack_Insectworm23));
            AssetManager.traits.add(Insectworm23);

            ActorTrait Insectworm24 = new ActorTrait();
            Insectworm24.id = "Insectworm24"; //二环•岩石护壁
            Insectworm24.path_icon = "trait/Insectworm24";
            Insectworm24.needs_to_be_explored = false;
            Insectworm24.group_id = "GuZhenren4";
            Insectworm24.action_attack_target += new AttackAction((traitAction.attack_Insectworm24));
            AssetManager.traits.add(Insectworm24);

            ActorTrait Insectworm25 = new ActorTrait();
            Insectworm25.id = "Insectworm25"; //二环•生命涌泉
            Insectworm25.path_icon = "trait/Insectworm25";
            Insectworm25.needs_to_be_explored = false;
            Insectworm25.group_id = "GuZhenren4";
            Insectworm25.base_stats = new BaseStats();
            Insectworm25.base_stats[strings.S.health] = 2000f;
            Insectworm25.action_special_effect += (WorldAction)Delegate.Combine(Insectworm25.action_special_effect,
                new WorldAction(traitAction.Insectworm25_Regen)); //再生效果
            AssetManager.traits.add(Insectworm25);

            ActorTrait Insectworm26 = new ActorTrait();
            Insectworm26.id = "Insectworm26"; //二环•生命流逝
            Insectworm26.path_icon = "trait/Insectworm26";
            Insectworm26.needs_to_be_explored = false;
            Insectworm26.group_id = "GuZhenren4";
            Insectworm26.action_attack_target += new AttackAction((traitAction.attack_Insectworm26));
            AssetManager.traits.add(Insectworm26);

            ActorTrait Insectworm27 = new ActorTrait
            {
                id = "Insectworm27", //二环•因果印记
                path_icon = "trait/Insectworm27",
                needs_to_be_explored = false,
                group_id = "GuZhenren4"
            };
            Insectworm27.action_attack_target += new AttackAction((traitAction.attack_Insectworm27));
            AssetManager.traits.add(Insectworm27);

            ActorTrait Insectworm28 = new ActorTrait
            {
                id = "Insectworm28", //二环•相位星痕步
                path_icon = "trait/Insectworm28",
                needs_to_be_explored = false,
                group_id = "GuZhenren4"
            };
            Insectworm28.action_attack_target += new AttackAction((traitAction.attack_Insectworm28));
            AssetManager.traits.add(Insectworm28);

            ActorTrait Insectworm29 = new ActorTrait
            {
                id = "Insectworm29", //二环•贯穿之锋
                path_icon = "trait/Insectworm29",
                needs_to_be_explored = false,
                group_id = "GuZhenren4"
            };
            Insectworm29.action_attack_target += new AttackAction((traitAction.attack_Insectworm29));
            AssetManager.traits.add(Insectworm29);

            ActorTrait Insectworm31 = new ActorTrait
            {
                id = "Insectworm31", //三环•斥力场
                path_icon = "trait/Insectworm31",
                needs_to_be_explored = false,
                group_id = "GuZhenren4",
                base_stats = new BaseStats
                {
                    [strings.S.health] = 250f,
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            Insectworm31.action_attack_target += new AttackAction((traitAction.attack_Insectworm31));
            AssetManager.traits.add(Insectworm31);

            ActorTrait Insectworm32 = new ActorTrait
            {
                id = "Insectworm32", //三环•裂界爆炎
                path_icon = "trait/Insectworm32",
                needs_to_be_explored = false,
                group_id = "GuZhenren4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            Insectworm32.action_attack_target += new AttackAction((traitAction.attack_Insectworm32));
            AssetManager.traits.add(Insectworm32);

            ActorTrait Insectworm33 = new ActorTrait
            {
                id = "Insectworm33", //三环•雷霆术
                path_icon = "trait/Insectworm33",
                needs_to_be_explored = false,
                group_id = "GuZhenren4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.05f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            Insectworm33.action_attack_target += new AttackAction((traitAction.attack_Insectworm33));
            AssetManager.traits.add(Insectworm33);

            ActorTrait Insectworm34 = new ActorTrait
            {
                id = "Insectworm34", //三环•血眸通界·万象饲己之仪
                path_icon = "trait/Insectworm34",
                needs_to_be_explored = false,
                group_id = "GuZhenren4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f
                }
            };
            Insectworm34.action_get_hit += new GetHitAction(traitAction.Insectworm34_Attack);//狂暴状态方法
            AssetManager.traits.add(Insectworm34);

            ActorTrait Insectworm35 = new ActorTrait
            {
                id = "Insectworm35", //三环•黯镰噬魂·万灵湮灭之仪
                path_icon = "trait/Insectworm35",
                needs_to_be_explored = false,
                group_id = "GuZhenren4",
                base_stats = new BaseStats
                {
                    [strings.S.damage] = 100f,
                    [strings.S.scale] = -0.03f,
                    ["ArmorPenPercent"] = 20f
                }
            };
            AssetManager.traits.add(Insectworm35);
        }
        private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
        {
            baseStats[statKey]= value;
        }
    }
}