﻿
namespace Cultivatingimmortals.code
{
    internal class stats
    {
        public static void Init()
        {
            BaseStatAsset Zhenyuan = new BaseStatAsset();
            Zhenyuan.id = "Zhenyuan";
            Zhenyuan.normalize = true;
            Zhenyuan.normalize_min = -99999;
            Zhenyuan.normalize_max = 1000000;
            // Zhenyuan.multiplier = true;
            Zhenyuan.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Zhenyuan);

            BaseStatAsset Spiritstone = new BaseStatAsset();
            Spiritstone.id = "Spiritstone";
            Spiritstone.normalize = true;
            Spiritstone.normalize_min = -99999;
            Spiritstone.normalize_max = 9990099;
            // Spiritstone.multiplier = true;
            Spiritstone.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Spiritstone);

            BaseStatAsset XianYuan = new BaseStatAsset();
            XianYuan.id = "XianYuan";
            XianYuan.normalize = true;
            XianYuan.normalize_min = -99999;
            XianYuan.normalize_max = 9990099;
            // XianYuan.multiplier = true;
            XianYuan.used_only_for_civs = false;
            AssetManager.base_stats_library.add(XianYuan);
            // 复活次数
            BaseStatAsset Opportunity = new BaseStatAsset();
            Opportunity.id = "Opportunity";
            Opportunity.normalize = true;
            Opportunity.normalize_min = -99999;
            Opportunity.normalize_max = 9990099;
            // Opportunity.multiplier = true;
            Opportunity.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Opportunity);

            BaseStatAsset Reincarnation = new BaseStatAsset();
            Reincarnation.id = "Reincarnation";
            Reincarnation.normalize = true;
            Reincarnation.normalize_min = 1;
            Reincarnation.normalize_max = 9990099;
            // Reincarnation.multiplier = true;
            Reincarnation.used_only_for_civs = false;
            AssetManager.base_stats_library.add(Reincarnation);
        }
    }
}