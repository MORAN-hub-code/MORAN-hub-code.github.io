using System;
using System.Runtime.CompilerServices;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using life;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;

namespace WorldSystem2
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        private float update;
        public static Main instance;

        void Awake()
        {
            instance = this;
            GameObject go = new GameObject("WorldSystem2");
            DontDestroyOnLoad(go);

            try { TraitGroup.init(); } catch (Exception e) { Debug.LogError("Failed in TraitGroup.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }
            try { Realms.init(); } catch (Exception e) { Debug.LogError("Failed in Realms.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }
            try { MartialArts.init(); } catch (Exception e) { Debug.LogError("Failed in MartialArts.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }
            try { Seals.init(); } catch (Exception e) { Debug.LogError("Failed in Seals.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }
            try { Talismans.init(); } catch (Exception e) { Debug.LogError("Failed in Talismans.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }
            try { PatchWorldLawCursed.init(); } catch (Exception e) { Debug.LogError("Failed in PatchWorldLawCursed.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); }

            InvokeRepeating("level", 2.0f, 0.7f);
        }

        void Start()
        {
            StartCoroutine(DelayedInit());
        }

        private IEnumerator DelayedInit()
        {
            yield return new WaitForSeconds(1f);
            try 
            { 
                Modify.init(); 
            } 
            catch (Exception e) 
            { 
                Debug.LogError("Failed in Modify.init(): " + e.Message + "\nStackTrace: " + e.StackTrace); 
            }
        }

        void level()
        {
            CreatureCheck();
        }

        void CreatureCheck()
        {
            var Units = MapBox.instance.units.getSimpleList();
            foreach (var unit in Units)
            {
                if (unit.hasTrait("System"))
                {
                    unit.addExperience(6);
                }
            }
        }

        public static class PatchWorldLawCursed
        {
            public static void init()
            {
                var cursedworld = AssetManager.world_laws_library.get("world_law_cursed_world");
                if (cursedworld == null)
                {
                    Debug.LogError("world_law_cursed_world not found in AssetManager!");
                    return;
                }
                cursedworld.default_state = true;
            }
        }
    }
}