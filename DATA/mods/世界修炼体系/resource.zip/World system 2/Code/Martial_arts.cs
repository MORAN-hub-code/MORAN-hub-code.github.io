using System;
using System.Collections.Generic;
using UnityEngine;
using ReflectionUtility;
using NCMS;

namespace WorldSystem2
{
    class MartialArts
    {
        public static void init()
        {
            Debug.Log("MartialArts.init() called");

            ActorTrait spaceTeleport = new ActorTrait();
            spaceTeleport.id = "space_teleport";
            spaceTeleport.rarity = Rarity.R0_Normal;
            spaceTeleport.path_icon = "ui/icons/spaceTeleport.png";
            spaceTeleport.rate_inherit = 5;
            spaceTeleport.group_id = "worldsystemtg2";
            spaceTeleport.unlocked_with_achievement = false;
            spaceTeleport.action_special_effect = new WorldAction(SpaceTeleportEffect);
            AssetManager.traits.add(spaceTeleport);
            LocalizedTextManager.add("trait_space_teleport", "Space Teleport");

            ActorTrait spaceCollapse = new ActorTrait();
            spaceCollapse.id = "space_collapse";
            spaceCollapse.rarity = Rarity.R0_Normal;
            spaceCollapse.path_icon = "ui/icons/spaceCollapse.png";
            spaceCollapse.rate_inherit = 5;
            spaceCollapse.group_id = "worldsystemtg2";
            spaceCollapse.unlocked_with_achievement = false;
            spaceCollapse.action_special_effect = new WorldAction(SpaceCollapseEffect);
            AssetManager.traits.add(spaceCollapse);
            LocalizedTextManager.add("trait_space_collapse", "Space Collapse");

            ActorTrait voidShield = new ActorTrait();
            voidShield.id = "void_shield";
            voidShield.rarity = Rarity.R0_Normal;
            voidShield.path_icon = "ui/icons/voidShield.png";
            voidShield.rate_inherit = 4;
            voidShield.group_id = "worldsystemtg2";
            voidShield.unlocked_with_achievement = false;
            AssetManager.traits.add(voidShield);
            LocalizedTextManager.add("trait_void_shield", "Void Shield");

            ActorTrait voidSlash = new ActorTrait();
            voidSlash.id = "void_slash";
            voidSlash.rarity = Rarity.R0_Normal;
            voidSlash.path_icon = "ui/icons/voidSlash.png";
            voidSlash.rate_inherit = 4;
            voidSlash.group_id = "worldsystemtg2";
            voidSlash.unlocked_with_achievement = false;
            AssetManager.traits.add(voidSlash);
            LocalizedTextManager.add("trait_void_slash", "Void Slash");

            ActorTrait timeSlash = new ActorTrait();
            timeSlash.id = "time_slash";
            timeSlash.rarity = Rarity.R0_Normal;
            timeSlash.path_icon = "ui/icons/timeSlash.png";
            timeSlash.rate_inherit = 3;
            timeSlash.group_id = "worldsystemtg2";
            timeSlash.unlocked_with_achievement = false;
            AssetManager.traits.add(timeSlash);
            LocalizedTextManager.add("trait_time_slash", "Time Slash");

            ActorTrait timeStop = new ActorTrait();
            timeStop.id = "time_stop";
            timeStop.rarity = Rarity.R0_Normal;
            timeStop.path_icon = "ui/icons/timeStop.png";
            timeStop.rate_inherit = 3;
            timeStop.group_id = "worldsystemtg2";
            timeStop.unlocked_with_achievement = false;
            AssetManager.traits.add(timeStop);
            LocalizedTextManager.add("trait_time_stop", "Time Stop");

            ActorTrait fire = new ActorTrait();
            fire.id = "fire";
            fire.rarity = Rarity.R0_Normal;
            fire.path_icon = "ui/icons/fire.png";
            fire.rate_inherit = 3;
            fire.group_id = "worldsystemtg2";
            fire.unlocked_with_achievement = false;
            AssetManager.traits.add(fire);
            LocalizedTextManager.add("trait_fire", "Fire");

            ActorTrait ice = new ActorTrait();
            ice.id = "ice";
            ice.rarity = Rarity.R0_Normal;
            ice.path_icon = "ui/icons/ice.png";
            ice.rate_inherit = 3;
            ice.group_id = "worldsystemtg2";
            ice.unlocked_with_achievement = false;
            AssetManager.traits.add(ice);
            LocalizedTextManager.add("trait_ice", "Ice");

            ActorTrait poison = new ActorTrait();
            poison.id = "poison";
            poison.rarity = Rarity.R0_Normal;
            poison.path_icon = "ui/icons/poison.png";
            poison.rate_inherit = 2;
            poison.group_id = "worldsystemtg2";
            poison.unlocked_with_achievement = false;
            AssetManager.traits.add(poison);
            LocalizedTextManager.add("trait_poison", "Poison");

            ActorTrait speed = new ActorTrait();
            speed.id = "speed";
            speed.rarity = Rarity.R0_Normal;
            speed.path_icon = "ui/icons/speed.png";
            speed.rate_inherit = 2;
            speed.group_id = "worldsystemtg2";
            speed.unlocked_with_achievement = false;
            AssetManager.traits.add(speed);
            LocalizedTextManager.add("trait_speed", "Speed");

            ActorTrait goldenSkeleton = new ActorTrait();
            goldenSkeleton.id = "golden_skeleton";
            goldenSkeleton.rarity = Rarity.R0_Normal;
            goldenSkeleton.path_icon = "ui/icons/goldenSkeleton.png";
            goldenSkeleton.rate_inherit = 2;
            goldenSkeleton.group_id = "worldsystemtg2";
            goldenSkeleton.unlocked_with_achievement = false;
            AssetManager.traits.add(goldenSkeleton);
            LocalizedTextManager.add("trait_golden_skeleton", "Golden Skeleton");

            ActorTrait eyeOfHeaven = new ActorTrait();
            eyeOfHeaven.id = "eye_of_heaven";
            eyeOfHeaven.rarity = Rarity.R0_Normal;
            eyeOfHeaven.path_icon = "ui/icons/heavenEye.png";
            eyeOfHeaven.rate_inherit = 1;
            eyeOfHeaven.group_id = "worldsystemtg2";
            eyeOfHeaven.unlocked_with_achievement = false;
            AssetManager.traits.add(eyeOfHeaven);
            LocalizedTextManager.add("trait_eye_of_heaven", "Eye of Heaven");

            ActorTrait immortalTree = new ActorTrait();
            immortalTree.id = "immortal_tree";
            immortalTree.rarity = Rarity.R0_Normal;
            immortalTree.path_icon = "ui/icons/immortalTree.png";
            immortalTree.rate_inherit = 1;
            immortalTree.group_id = "worldsystemtg2";
            immortalTree.unlocked_with_achievement = false;
            AssetManager.traits.add(immortalTree);
            LocalizedTextManager.add("trait_immortal_tree", "Immortal Tree");

            ActorTrait windAndThunderWings = new ActorTrait();
            windAndThunderWings.id = "wind_and_thunder_wings";
            windAndThunderWings.rarity = Rarity.R0_Normal;
            windAndThunderWings.path_icon = "ui/icons/windAndThunderWings.png";
            windAndThunderWings.rate_inherit = 1;
            windAndThunderWings.group_id = "worldsystemtg2";
            windAndThunderWings.unlocked_with_achievement = false;
            AssetManager.traits.add(windAndThunderWings);
            LocalizedTextManager.add("trait_wind_and_thunder_wings", "Wind and Thunder Wings");

            ActorTrait voidRupt = new ActorTrait();
            voidRupt.id = "void_rupt";
            voidRupt.rarity = Rarity.R0_Normal;
            voidRupt.path_icon = "ui/icons/voidRupt.png";
            voidRupt.rate_inherit = 1;
            voidRupt.group_id = "worldsystemtg2";
            voidRupt.unlocked_with_achievement = false;
            AssetManager.traits.add(voidRupt);
            LocalizedTextManager.add("trait_void_rupt", "Void Rupt");

            Dictionary<string, Dictionary<string, float>> traitStats = new Dictionary<string, Dictionary<string, float>>
            {
                {"space_teleport", new Dictionary<string, float>(){
                    {S.damage, 20f},
                    {S.mana, 300f},
                    {S.health, 500f},
                    {S.accuracy, 30f},
                    {S.attack_speed, 100f},
                    {S.critical_chance, 0.05f},
                    {S.range, 5f},
                    {S.speed, 90f},
                    {S.max_nutrition, 30f},
                    {S.offspring, 80f},
                }},
                {"space_collapse", new Dictionary<string, float>(){
                    {S.damage, 25f},
                    {S.mana, 350f},
                    {S.health, 550f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 110f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 95f},
                    {S.max_nutrition, 35f},
                    {S.offspring, 85f},
                }},
                {"void_shield", new Dictionary<string, float>(){
                    {S.damage, 30f},
                    {S.mana, 400f},
                    {S.health, 600f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.07f},
                    {S.range, 7f},
                    {S.speed, 100f},
                    {S.max_nutrition, 40f},
                    {S.offspring, 90f},
                }},
                {"void_slash", new Dictionary<string, float>(){
                    {S.damage, 35f},
                    {S.mana, 350f},
                    {S.health, 700f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 115f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 90f},
                    {S.max_nutrition, 45f},
                    {S.offspring, 80f},
                }},
                {"time_slash", new Dictionary<string, float>(){
                    {S.damage, 40f},
                    {S.mana, 400f},
                    {S.health, 800f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.08f},
                    {S.range, 8f},
                    {S.speed, 95f},
                    {S.max_nutrition, 50f},
                    {S.offspring, 85f},
                }},
                {"time_stop", new Dictionary<string, float>(){
                    {S.damage, 50f},
                    {S.mana, 450f},
                    {S.health, 900f},
                    {S.accuracy, 45f},
                    {S.attack_speed, 130f},
                    {S.critical_chance, 0.09f},
                    {S.range, 9f},
                    {S.speed, 100f},
                    {S.max_nutrition, 55f},
                    {S.offspring, 90f},
                }},
                {"fire", new Dictionary<string, float>(){
                    {S.damage, 60f},
                    {S.mana, 500f},
                    {S.health, 1000f},
                    {S.accuracy, 50f},
                    {S.attack_speed, 140f},
                    {S.critical_chance, 0.10f},
                    {S.range, 10f},
                    {S.speed, 105f},
                    {S.max_nutrition, 60f},
                    {S.offspring, 95f},
                }},
                {"ice", new Dictionary<string, float>(){
                    {S.damage, 70f},
                    {S.mana, 550f},
                    {S.health, 1100f},
                    {S.accuracy, 55f},
                    {S.attack_speed, 150f},
                    {S.critical_chance, 0.11f},
                    {S.range, 11f},
                    {S.speed, 110f},
                    {S.max_nutrition, 65f},
                    {S.offspring, 100f},
                }},
                {"poison", new Dictionary<string, float>(){
                    {S.damage, 80f},
                    {S.mana, 600f},
                    {S.health, 1200f},
                    {S.accuracy, 60f},
                    {S.attack_speed, 160f},
                    {S.critical_chance, 0.12f},
                    {S.range, 12f},
                    {S.speed, 115f},
                    {S.max_nutrition, 70f},
                    {S.offspring, 105f},
                }},
                {"speed", new Dictionary<string, float>(){
                    {S.damage, 90f},
                    {S.mana, 650f},
                    {S.health, 1300f},
                    {S.accuracy, 65f},
                    {S.attack_speed, 170f},
                    {S.critical_chance, 0.13f},
                    {S.range, 13f},
                    {S.speed, 120f},
                    {S.max_nutrition, 75f},
                    {S.offspring, 110f},
                }},
                {"golden_skeleton", new Dictionary<string, float>(){
                    {S.damage, 100f},
                    {S.mana, 700f},
                    {S.health, 1400f},
                    {S.accuracy, 70f},
                    {S.attack_speed, 180f},
                    {S.critical_chance, 0.14f},
                    {S.range, 14f},
                    {S.speed, 125f},
                    {S.max_nutrition, 80f},
                    {S.offspring, 115f},
                }},
                {"eye_of_heaven", new Dictionary<string, float>(){
                    {S.damage, 110f},
                    {S.mana, 750f},
                    {S.health, 1500f},
                    {S.accuracy, 75f},
                    {S.attack_speed, 190f},
                    {S.critical_chance, 0.15f},
                    {S.range, 15f},
                    {S.speed, 130f},
                    {S.max_nutrition, 85f},
                    {S.offspring, 120f},
                }},
                {"immortal_tree", new Dictionary<string, float>(){
                    {S.damage, 120f},
                    {S.mana, 800f},
                    {S.health, 1600f},
                    {S.accuracy, 80f},
                    {S.attack_speed, 200f},
                    {S.critical_chance, 0.16f},
                    {S.range, 16f},
                    {S.speed, 135f},
                    {S.max_nutrition, 90f},
                    {S.offspring, 125f},
                }},
                {"wind_and_thunder_wings", new Dictionary<string, float>(){
                    {S.damage, 130f},
                    {S.mana, 850f},
                    {S.health, 1700f},
                    {S.accuracy, 85f},
                    {S.attack_speed, 210f},
                    {S.critical_chance, 0.17f},
                    {S.range, 17f},
                    {S.speed, 140f},
                    {S.max_nutrition, 95f},
                    {S.offspring, 130f},
                }},
                {"void_rupt", new Dictionary<string, float>(){
                    {S.damage, 150f},
                    {S.mana, 1000f},
                    {S.health, 2000f},
                    {S.accuracy, 100f},
                    {S.attack_speed, 250f},
                    {S.critical_chance, 0.20f},
                    {S.range, 20f},
                    {S.speed, 150f},
                    {S.max_nutrition, 100f},
                    {S.offspring, 150f},
                }}
            };

            foreach (string traitId in traitStats.Keys)
            {
                ActorTrait trait = AssetManager.traits.get(traitId);
                if (trait != null)
                {
                    foreach (KeyValuePair<string, float> stat in traitStats[traitId])
                    {
                        trait.base_stats[stat.Key] = stat.Value;
                    }
                }
            }
        }

        private static bool SpaceTeleportEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("SpaceTeleportEffect called on " + pTarget);
            return true;
        }

        private static bool SpaceCollapseEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("SpaceCollapseEffect called on " + pTarget);
            return true;
        }
    }
}