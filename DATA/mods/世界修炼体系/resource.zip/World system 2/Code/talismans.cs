using System;
using System.Collections.Generic;
using UnityEngine;
using ReflectionUtility;
using NCMS;

namespace WorldSystem2
{
    class Talismans
    {
        public static void init()
        {
            ActorTrait whisperingMoonstone = new ActorTrait();
            whisperingMoonstone.id = "whispering_moonstone";
            whisperingMoonstone.rarity = Rarity.R0_Normal;
            whisperingMoonstone.path_icon = "ui/icons/whispering_moonstone";
            whisperingMoonstone.rate_inherit = 5;
            whisperingMoonstone.group_id = "worldsystemtg3";
            whisperingMoonstone.unlocked_with_achievement = false;
            whisperingMoonstone.action_special_effect = new WorldAction(WhisperingMoonstoneEffect);
            AssetManager.traits.add(whisperingMoonstone);
            LocalizedTextManager.add("trait_whispering_moonstone", "Whispering Moonstone");

            ActorTrait emberheartSigil = new ActorTrait();
            emberheartSigil.id = "emberheart_sigil";
            emberheartSigil.rarity = Rarity.R0_Normal;
            emberheartSigil.path_icon = "ui/icons/emberheart_sigil";
            emberheartSigil.rate_inherit = 5;
            emberheartSigil.group_id = "worldsystemtg3";
            emberheartSigil.unlocked_with_achievement = false;
            emberheartSigil.action_special_effect = new WorldAction(EmberheartSigilEffect);
            AssetManager.traits.add(emberheartSigil);
            LocalizedTextManager.add("trait_emberheart_sigil", "Emberheart Sigil");

            ActorTrait starwovenCharm = new ActorTrait();
            starwovenCharm.id = "starwoven_charm";
            starwovenCharm.rarity = Rarity.R0_Normal;
            starwovenCharm.path_icon = "ui/icons/starwoven_charm";
            starwovenCharm.rate_inherit = 4;
            starwovenCharm.group_id = "worldsystemtg3";
            starwovenCharm.unlocked_with_achievement = false;
            AssetManager.traits.add(starwovenCharm);
            LocalizedTextManager.add("trait_starwoven_charm", "Starwoven Charm");

            ActorTrait shadowveilRelic = new ActorTrait();
            shadowveilRelic.id = "shadowveil_relic";
            shadowveilRelic.rarity = Rarity.R0_Normal;
            shadowveilRelic.path_icon = "ui/icons/shadowveil_relic";
            shadowveilRelic.rate_inherit = 4;
            shadowveilRelic.group_id = "worldsystemtg3";
            shadowveilRelic.unlocked_with_achievement = false;
            AssetManager.traits.add(shadowveilRelic);
            LocalizedTextManager.add("trait_shadowveil_relic", "Shadowveil Relic");

            ActorTrait dawnbreakerAmulet = new ActorTrait();
            dawnbreakerAmulet.id = "dawnbreaker_amulet";
            dawnbreakerAmulet.rarity = Rarity.R0_Normal;
            dawnbreakerAmulet.path_icon = "ui/icons/dawnbreaker_amulet";
            dawnbreakerAmulet.rate_inherit = 3;
            dawnbreakerAmulet.group_id = "worldsystemtg3";
            dawnbreakerAmulet.unlocked_with_achievement = false;
            AssetManager.traits.add(dawnbreakerAmulet);
            LocalizedTextManager.add("trait_dawnbreaker_amulet", "Dawnbreaker Amulet");

            ActorTrait frostspireWard = new ActorTrait();
            frostspireWard.id = "frostspire_ward";
            frostspireWard.rarity = Rarity.R0_Normal;
            frostspireWard.path_icon = "ui/icons/frostspire_ward";
            frostspireWard.rate_inherit = 3;
            frostspireWard.group_id = "worldsystemtg3";
            frostspireWard.unlocked_with_achievement = false;
            AssetManager.traits.add(frostspireWard);
            LocalizedTextManager.add("trait_frostspire_ward", "Frostspire Ward");

            ActorTrait sunkenOracle = new ActorTrait();
            sunkenOracle.id = "sunken_oracle";
            sunkenOracle.rarity = Rarity.R0_Normal;
            sunkenOracle.path_icon = "ui/icons/sunken_oracle";
            sunkenOracle.rate_inherit = 2;
            sunkenOracle.group_id = "worldsystemtg3";
            sunkenOracle.unlocked_with_achievement = false;
            AssetManager.traits.add(sunkenOracle);
            LocalizedTextManager.add("trait_sunken_oracle", "Sunken Oracle");

            ActorTrait voidtouchedCrest = new ActorTrait();
            voidtouchedCrest.id = "voidtouched_crest";
            voidtouchedCrest.rarity = Rarity.R0_Normal;
            voidtouchedCrest.path_icon = "ui/icons/voidtouched_crest";
            voidtouchedCrest.rate_inherit = 2;
            voidtouchedCrest.group_id = "worldsystemtg3";
            voidtouchedCrest.unlocked_with_achievement = false;
            AssetManager.traits.add(voidtouchedCrest);
            LocalizedTextManager.add("trait_voidtouched_crest", "Voidtouched Crest");

            Dictionary<string, Dictionary<string, float>> traitStats = new Dictionary<string, Dictionary<string, float>>
            {
                {"whispering_moonstone", new Dictionary<string, float>(){
                    {S.damage, 20f},
                    {S.mana, 300f},
                    {S.health, 500f},
                    {S.accuracy, 30f},
                    {S.attack_speed, 100f},
                    {S.critical_chance, 0.05f},
                    {S.range, 5f},
                    {S.speed, 90f},
                    {S.max_nutrition, 30f},
                    {S.offspring, 80f},
                }},
                {"emberheart_sigil", new Dictionary<string, float>(){
                    {S.damage, 25f},
                    {S.mana, 350f},
                    {S.health, 550f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 110f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 95f},
                    {S.max_nutrition, 35f},
                    {S.offspring, 85f},
                }},
                {"starwoven_charm", new Dictionary<string, float>(){
                    {S.damage, 30f},
                    {S.mana, 400f},
                    {S.health, 600f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.07f},
                    {S.range, 7f},
                    {S.speed, 100f},
                    {S.max_nutrition, 40f},
                    {S.offspring, 90f},
                }},
                {"shadowveil_relic", new Dictionary<string, float>(){
                    {S.damage, 35f},
                    {S.mana, 350f},
                    {S.health, 700f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 115f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 90f},
                    {S.max_nutrition, 45f},
                    {S.offspring, 80f},
                }},
                {"dawnbreaker_amulet", new Dictionary<string, float>(){
                    {S.damage, 40f},
                    {S.mana, 400f},
                    {S.health, 800f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.08f},
                    {S.range, 8f},
                    {S.speed, 95f},
                    {S.max_nutrition, 50f},
                    {S.offspring, 85f},
                }},
                {"frostspire_ward", new Dictionary<string, float>(){
                    {S.damage, 50f},
                    {S.mana, 450f},
                    {S.health, 900f},
                    {S.accuracy, 45f},
                    {S.attack_speed, 130f},
                    {S.critical_chance, 0.09f},
                    {S.range, 9f},
                    {S.speed, 100f},
                    {S.max_nutrition, 55f},
                    {S.offspring, 90f},
                }},
                {"sunken_oracle", new Dictionary<string, float>(){
                    {S.damage, 60f},
                    {S.mana, 500f},
                    {S.health, 1000f},
                    {S.accuracy, 50f},
                    {S.attack_speed, 140f},
                    {S.critical_chance, 0.10f},
                    {S.range, 10f},
                    {S.speed, 105f},
                    {S.max_nutrition, 60f},
                    {S.offspring, 95f},
                }},
                {"voidtouched_crest", new Dictionary<string, float>(){
                    {S.damage, 70f},
                    {S.mana, 550f},
                    {S.health, 1100f},
                    {S.accuracy, 55f},
                    {S.attack_speed, 150f},
                    {S.critical_chance, 0.11f},
                    {S.range, 11f},
                    {S.speed, 110f},
                    {S.max_nutrition, 65f},
                    {S.offspring, 100f},
                }}
            };

            foreach (string traitId in traitStats.Keys)
            {
                ActorTrait trait = AssetManager.traits.get(traitId);
                if (trait != null)
                {
                    foreach (KeyValuePair<string, float> stat in traitStats[traitId])
                    {
                        trait.base_stats[stat.Key] = stat.Value;
                    }
                }
            }
        }

        private static bool WhisperingMoonstoneEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }

        private static bool EmberheartSigilEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            return true;
        }
    }
}