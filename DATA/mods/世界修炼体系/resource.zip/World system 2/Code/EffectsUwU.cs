using System;
using System.Collections.Generic;
using UnityEngine;
using ReflectionUtility;
using NCMS;

namespace WorldSystem2
{
    class EffectsUwU
    {
        public static void init()
        {
            StatusAsset sealedStatus = new StatusAsset();
            sealedStatus.id = "Sealed";
            sealedStatus.duration = 5f;
            sealedStatus.path_icon = "ui/icons/iconMadness";
            sealedStatus.locale_id = "Sealed";
            sealedStatus.locale_description = "Bound by an ancient seal, movement is nearly impossible!";
            sealedStatus.base_stats[S.speed] = -10000f;
            sealedStatus.base_stats[S.multiplier_speed] = -0.99f;
            sealedStatus.base_stats.addTag("frozen_ai");
            sealedStatus.base_stats.addTag("stop_idle_animation");
            sealedStatus.action_interval = 0.01f;
            sealedStatus.action = new WorldAction(InvisibleSealedEffect);
            sealedStatus.action_finish = new WorldAction(FinishInvisibility);
            localizeStatus(sealedStatus.id, sealedStatus.locale_id, sealedStatus.locale_description);
            AssetManager.status.add(sealedStatus);

            StatusAsset soulSnatchStatus = new StatusAsset();
            soulSnatchStatus.id = "SoulSnatch";
            soulSnatchStatus.duration = 15f;
            soulSnatchStatus.base_stats[S.health] += 300f;
            soulSnatchStatus.base_stats[S.mana] += 200f;
            soulSnatchStatus.base_stats[S.damage] += 20f;
            soulSnatchStatus.path_icon = "ui/icons/soul";
            soulSnatchStatus.locale_id = "Soul Snatch";
            soulSnatchStatus.locale_description = "Your soul is empowered, drawing strength from the void!";
            soulSnatchStatus.action_interval = 2f;
            soulSnatchStatus.action = new WorldAction(SoulSnatchEffect);
            localizeStatus(soulSnatchStatus.id, soulSnatchStatus.locale_id, soulSnatchStatus.locale_description);
            AssetManager.status.add(soulSnatchStatus);

            StatusAsset trinityAuraStatus = new StatusAsset();
            trinityAuraStatus.id = "TrinityAura";
            trinityAuraStatus.duration = 20f;
            trinityAuraStatus.base_stats[S.armor] += 15f;
            trinityAuraStatus.base_stats[S.attack_speed] += 50f;
            trinityAuraStatus.base_stats[S.critical_chance] += 0.05f;
            trinityAuraStatus.path_icon = "ui/icons/trinity";
            trinityAuraStatus.locale_id = "Trinity Aura";
            trinityAuraStatus.locale_description = "A radiant aura enhances your combat prowess!";
            trinityAuraStatus.action_interval = 2f;
            trinityAuraStatus.action = new WorldAction(TrinityAuraEffect);
            localizeStatus(trinityAuraStatus.id, trinityAuraStatus.locale_id, trinityAuraStatus.locale_description);
            AssetManager.status.add(trinityAuraStatus);

            StatusAsset moonstoneWhisperStatus = new StatusAsset();
            moonstoneWhisperStatus.id = "MoonstoneWhisper";
            moonstoneWhisperStatus.duration = 12f;
            moonstoneWhisperStatus.base_stats[S.mana] += 150f;
            moonstoneWhisperStatus.base_stats[S.accuracy] += 20f;
            moonstoneWhisperStatus.path_icon = "ui/icons/whispering_moonstone";
            moonstoneWhisperStatus.locale_id = "Moonstone Whisper";
            moonstoneWhisperStatus.locale_description = "The moonstone's whispers guide your aim and power!";
            moonstoneWhisperStatus.action_interval = 2f;
            moonstoneWhisperStatus.action = new WorldAction(MoonstoneWhisperEffect);
            localizeStatus(moonstoneWhisperStatus.id, moonstoneWhisperStatus.locale_id, moonstoneWhisperStatus.locale_description);
            AssetManager.status.add(moonstoneWhisperStatus);

            StatusAsset emberheartGlowStatus = new StatusAsset();
            emberheartGlowStatus.id = "EmberheartGlow";
            emberheartGlowStatus.duration = 10f;
            emberheartGlowStatus.base_stats[S.damage] += 25f;
            emberheartGlowStatus.base_stats[S.health] += 200f;
            emberheartGlowStatus.path_icon = "ui/icons/emberheart_sigil";
            emberheartGlowStatus.locale_id = "Emberheart Glow";
            emberheartGlowStatus.locale_description = "The sigil's fire fuels your strength and vitality!";
            emberheartGlowStatus.action_interval = 2f;
            emberheartGlowStatus.action = new WorldAction(EmberheartGlowEffect);
            localizeStatus(emberheartGlowStatus.id, emberheartGlowStatus.locale_id, emberheartGlowStatus.locale_description);
            AssetManager.status.add(emberheartGlowStatus);

            StatusAsset mysticBarrierStatus = new StatusAsset();
            mysticBarrierStatus.id = "MysticBarrier";
            mysticBarrierStatus.duration = 15f;
            mysticBarrierStatus.base_stats[S.armor] += 20f;
            mysticBarrierStatus.base_stats[S.health] += 300f;
            mysticBarrierStatus.path_icon = "ui/icons/mysticBarrierSeal";
            mysticBarrierStatus.locale_id = "Mystic Barrier";
            mysticBarrierStatus.locale_description = "A mystical barrier shields you from harm!";
            mysticBarrierStatus.action_interval = 2f;
            mysticBarrierStatus.action = new WorldAction(MysticBarrierEffect);
            localizeStatus(mysticBarrierStatus.id, mysticBarrierStatus.locale_id, mysticBarrierStatus.locale_description);
            AssetManager.status.add(mysticBarrierStatus);

            StatusAsset celestialBindingStatus = new StatusAsset();
            celestialBindingStatus.id = "CelestialBinding";
            celestialBindingStatus.duration = 12f;
            celestialBindingStatus.base_stats[S.mana] += 200f;
            celestialBindingStatus.base_stats[S.critical_chance] += 0.07f;
            celestialBindingStatus.path_icon = "ui/icons/celestialPyramidSeal";
            celestialBindingStatus.locale_id = "Celestial Binding";
            celestialBindingStatus.locale_description = "Celestial forces enhance your critical strikes!";
            celestialBindingStatus.action_interval = 2f;
            celestialBindingStatus.action = new WorldAction(CelestialBindingEffect);
            localizeStatus(celestialBindingStatus.id, celestialBindingStatus.locale_id, celestialBindingStatus.locale_description);
            AssetManager.status.add(celestialBindingStatus);

            StatusAsset spaceTeleportStatus = new StatusAsset();
            spaceTeleportStatus.id = "SpaceTeleport";
            spaceTeleportStatus.duration = 8f;
            spaceTeleportStatus.base_stats[S.speed] += 100f;
            spaceTeleportStatus.base_stats[S.range] += 10f;
            spaceTeleportStatus.path_icon = "ui/icons/spaceTeleport";
            spaceTeleportStatus.locale_id = "Space Teleport";
            spaceTeleportStatus.locale_description = "Warp through space with unmatched speed!";
            spaceTeleportStatus.action_interval = 1f;
            spaceTeleportStatus.action = new WorldAction(SpaceTeleportEffect);
            localizeStatus(spaceTeleportStatus.id, spaceTeleportStatus.locale_id, spaceTeleportStatus.locale_description);
            AssetManager.status.add(spaceTeleportStatus);

            StatusAsset spaceCollapseStatus = new StatusAsset();
            spaceCollapseStatus.id = "SpaceCollapse";
            spaceCollapseStatus.duration = 10f;
            spaceCollapseStatus.base_stats[S.damage] += 30f;
            spaceCollapseStatus.base_stats[S.knockback] += 2f;
            spaceCollapseStatus.path_icon = "ui/icons/spaceCollapse";
            spaceCollapseStatus.locale_id = "Space Collapse";
            spaceCollapseStatus.locale_description = "Collapse space to crush your foes!";
            spaceCollapseStatus.action_interval = 2f;
            spaceCollapseStatus.action = new WorldAction(SpaceCollapseEffect);
            localizeStatus(spaceCollapseStatus.id, spaceCollapseStatus.locale_id, spaceCollapseStatus.locale_description);
            AssetManager.status.add(spaceCollapseStatus);

            StatusAsset primordialRealmStatus = new StatusAsset();
            primordialRealmStatus.id = "PrimordialRealm";
            primordialRealmStatus.duration = 12f;
            primordialRealmStatus.base_stats[S.health] += 400f;
            primordialRealmStatus.base_stats[S.damage] += 30f;
            primordialRealmStatus.path_icon = "ui/icons/primordial_realm";
            primordialRealmStatus.locale_id = "Primordial Realm";
            primordialRealmStatus.locale_description = "Ancient energies bolster your vitality and strength!";
            primordialRealmStatus.action_interval = 2f;
            primordialRealmStatus.action = new WorldAction(PrimordialRealmEffect);
            localizeStatus(primordialRealmStatus.id, primordialRealmStatus.locale_id, primordialRealmStatus.locale_description);
            AssetManager.status.add(primordialRealmStatus);

            StatusAsset temperedBodyStatus = new StatusAsset();
            temperedBodyStatus.id = "TemperedBody";
            temperedBodyStatus.duration = 14f;
            temperedBodyStatus.base_stats[S.health] += 500f;
            temperedBodyStatus.base_stats[S.armor] += 15f;
            temperedBodyStatus.path_icon = "ui/icons/tempered_body_realm";
            temperedBodyStatus.locale_id = "Tempered Body";
            temperedBodyStatus.locale_description = "Your body is forged anew, resilient and unyielding!";
            temperedBodyStatus.action_interval = 2f;
            temperedBodyStatus.action = new WorldAction(TemperedBodyEffect);
            localizeStatus(temperedBodyStatus.id, temperedBodyStatus.locale_id, temperedBodyStatus.locale_description);
            AssetManager.status.add(temperedBodyStatus);

            StatusAsset earthRealmStatus = new StatusAsset();
            earthRealmStatus.id = "EarthRealm";
            earthRealmStatus.duration = 15f;
            earthRealmStatus.base_stats[S.health] += 600f;
            earthRealmStatus.base_stats[S.damage] += 40f;
            earthRealmStatus.path_icon = "ui/icons/Earth";
            earthRealmStatus.locale_id = "Earth Realm";
            earthRealmStatus.locale_description = "The earth’s might empowers your strikes and endurance!";
            earthRealmStatus.action_interval = 2f;
            earthRealmStatus.action = new WorldAction(EarthRealmEffect);
            localizeStatus(earthRealmStatus.id, earthRealmStatus.locale_id, earthRealmStatus.locale_description);
            AssetManager.status.add(earthRealmStatus);

            StatusAsset lordRealmStatus = new StatusAsset();
            lordRealmStatus.id = "LordRealm";
            lordRealmStatus.duration = 16f;
            lordRealmStatus.base_stats[S.damage] += 50f;
            lordRealmStatus.base_stats[S.critical_chance] += 0.09f;
            lordRealmStatus.path_icon = "ui/icons/Lord";
            lordRealmStatus.locale_id = "Lord Realm";
            lordRealmStatus.locale_description = "Commanding presence amplifies your devastating blows!";
            lordRealmStatus.action_interval = 2f;
            lordRealmStatus.action = new WorldAction(LordRealmEffect);
            localizeStatus(lordRealmStatus.id, lordRealmStatus.locale_id, lordRealmStatus.locale_description);
            AssetManager.status.add(lordRealmStatus);

            StatusAsset kingRealmStatus = new StatusAsset();
            kingRealmStatus.id = "KingRealm";
            kingRealmStatus.duration = 17f;
            kingRealmStatus.base_stats[S.damage] += 60f;
            kingRealmStatus.base_stats[S.attack_speed] += 60f;
            kingRealmStatus.path_icon = "ui/icons/King";
            kingRealmStatus.locale_id = "King Realm";
            kingRealmStatus.locale_description = "Royal might fuels relentless assaults!";
            kingRealmStatus.action_interval = 2f;
            kingRealmStatus.action = new WorldAction(KingRealmEffect);
            localizeStatus(kingRealmStatus.id, kingRealmStatus.locale_id, kingRealmStatus.locale_description);
            AssetManager.status.add(kingRealmStatus);

            StatusAsset emperorRealmStatus = new StatusAsset();
            emperorRealmStatus.id = "EmperorRealm";
            emperorRealmStatus.duration = 18f;
            emperorRealmStatus.base_stats[S.damage] += 70f;
            emperorRealmStatus.base_stats[S.mana] += 300f;
            emperorRealmStatus.path_icon = "ui/icons/Emperor";
            emperorRealmStatus.locale_id = "Emperor Realm";
            emperorRealmStatus.locale_description = "Imperial power surges through your veins!";
            emperorRealmStatus.action_interval = 2f;
            emperorRealmStatus.action = new WorldAction(EmperorRealmEffect);
            localizeStatus(emperorRealmStatus.id, emperorRealmStatus.locale_id, emperorRealmStatus.locale_description);
            AssetManager.status.add(emperorRealmStatus);

            StatusAsset heavenRealmStatus = new StatusAsset();
            heavenRealmStatus.id = "HeavenRealm";
            heavenRealmStatus.duration = 19f;
            heavenRealmStatus.base_stats[S.mana] += 400f;
            heavenRealmStatus.base_stats[S.critical_chance] += 0.12f;
            heavenRealmStatus.path_icon = "ui/icons/heaven_realm";
            heavenRealmStatus.locale_id = "Heaven Realm";
            heavenRealmStatus.locale_description = "Divine energies enhance your mystical prowess!";
            heavenRealmStatus.action_interval = 2f;
            heavenRealmStatus.action = new WorldAction(HeavenRealmEffect);
            localizeStatus(heavenRealmStatus.id, heavenRealmStatus.locale_id, heavenRealmStatus.locale_description);
            AssetManager.status.add(heavenRealmStatus);

            StatusAsset demiGodRealmStatus = new StatusAsset();
            demiGodRealmStatus.id = "DemiGodRealm";
            demiGodRealmStatus.duration = 20f;
            demiGodRealmStatus.base_stats[S.damage] += 90f;
            demiGodRealmStatus.base_stats[S.health] += 800f;
            demiGodRealmStatus.path_icon = "ui/icons/DemiGod";
            demiGodRealmStatus.locale_id = "Demi God Realm";
            demiGodRealmStatus.locale_description = "Godly strength courses through you!";
            demiGodRealmStatus.action_interval = 2f;
            demiGodRealmStatus.action = new WorldAction(DemiGodRealmEffect);
            localizeStatus(demiGodRealmStatus.id, demiGodRealmStatus.locale_id, demiGodRealmStatus.locale_description);
            AssetManager.status.add(demiGodRealmStatus);

            StatusAsset trueGodRealmStatus = new StatusAsset();
            trueGodRealmStatus.id = "TrueGodRealm";
            trueGodRealmStatus.duration = 20f;
            trueGodRealmStatus.base_stats[S.damage] += 100f;
            trueGodRealmStatus.base_stats[S.mana] += 500f;
            trueGodRealmStatus.path_icon = "ui/icons/TrueGod";
            trueGodRealmStatus.locale_id = "True God Realm";
            trueGodRealmStatus.locale_description = "True divinity empowers your every action!";
            trueGodRealmStatus.action_interval = 2f;
            trueGodRealmStatus.action = new WorldAction(TrueGodRealmEffect);
            localizeStatus(trueGodRealmStatus.id, trueGodRealmStatus.locale_id, trueGodRealmStatus.locale_description);
            AssetManager.status.add(trueGodRealmStatus);

            StatusAsset godKingRealmStatus = new StatusAsset();
            godKingRealmStatus.id = "GodKingRealm";
            godKingRealmStatus.duration = 20f;
            godKingRealmStatus.base_stats[S.damage] += 110f;
            godKingRealmStatus.base_stats[S.attack_speed] += 80f;
            godKingRealmStatus.path_icon = "ui/icons/GodKing";
            godKingRealmStatus.locale_id = "God King Realm";
            godKingRealmStatus.locale_description = "Sovereign divinity fuels your relentless might!";
            godKingRealmStatus.action_interval = 2f;
            godKingRealmStatus.action = new WorldAction(GodKingRealmEffect);
            localizeStatus(godKingRealmStatus.id, godKingRealmStatus.locale_id, godKingRealmStatus.locale_description);
            AssetManager.status.add(godKingRealmStatus);

            StatusAsset godEmperorRealmStatus = new StatusAsset();
            godEmperorRealmStatus.id = "GodEmperorRealm";
            godEmperorRealmStatus.duration = 20f;
            godEmperorRealmStatus.base_stats[S.damage] += 120f;
            godEmperorRealmStatus.base_stats[S.health] += 1000f;
            godEmperorRealmStatus.path_icon = "ui/icons/GodEmperor";
            godEmperorRealmStatus.locale_id = "God Emperor Kazakh";
            godEmperorRealmStatus.locale_description = "Supreme rule enhances your godly presence!";
            godEmperorRealmStatus.action_interval = 2f;
            godEmperorRealmStatus.action = new WorldAction(GodEmperorRealmEffect);
            localizeStatus(godEmperorRealmStatus.id, godEmperorRealmStatus.locale_id, godEmperorRealmStatus.locale_description);
            AssetManager.status.add(godEmperorRealmStatus);

            StatusAsset supremeGodRealmStatus = new StatusAsset();
            supremeGodRealmStatus.id = "SupremeGodRealm";
            supremeGodRealmStatus.duration = 20f;
            supremeGodRealmStatus.base_stats[S.damage] += 150f;
            supremeGodRealmStatus.base_stats[S.mana] += 600f;
            supremeGodRealmStatus.path_icon = "ui/icons/SupremeGod";
            supremeGodRealmStatus.locale_id = "Supreme God Realm";
            supremeGodRealmStatus.locale_description = "Ultimate divinity makes you unstoppable!";
            supremeGodRealmStatus.action_interval = 2f;
            supremeGodRealmStatus.action = new WorldAction(SupremeGodRealmEffect);
            localizeStatus(supremeGodRealmStatus.id, supremeGodRealmStatus.locale_id, supremeGodRealmStatus.locale_description);
            AssetManager.status.add(supremeGodRealmStatus);

            StatusAsset voidShieldStatus = new StatusAsset();
            voidShieldStatus.id = "VoidShield";
            voidShieldStatus.duration = 12f;
            voidShieldStatus.base_stats[S.armor] += 25f;
            voidShieldStatus.base_stats[S.health] += 400f;
            voidShieldStatus.path_icon = "ui/icons/voidShield.png";
            voidShieldStatus.locale_id = "Void Shield";
            voidShieldStatus.locale_description = "A void barrier absorbs incoming damage!";
            voidShieldStatus.action_interval = 2f;
            voidShieldStatus.action = new WorldAction(VoidShieldEffect);
            localizeStatus(voidShieldStatus.id, voidShieldStatus.locale_id, voidShieldStatus.locale_description);
            AssetManager.status.add(voidShieldStatus);

            StatusAsset voidSlashStatus = new StatusAsset();
            voidSlashStatus.id = "VoidSlash";
            voidSlashStatus.duration = 10f;
            voidSlashStatus.base_stats[S.damage] += 35f;
            voidSlashStatus.base_stats[S.critical_chance] += 0.06f;
            voidSlashStatus.path_icon = "ui/icons/voidSlash.png";
            voidSlashStatus.locale_id = "Void Slash";
            voidSlashStatus.locale_description = "Void-infused strikes tear through foes!";
            voidSlashStatus.action_interval = 2f;
            voidSlashStatus.action = new WorldAction(VoidSlashEffect);
            localizeStatus(voidSlashStatus.id, voidSlashStatus.locale_id, voidSlashStatus.locale_description);
            AssetManager.status.add(voidSlashStatus);

            StatusAsset timeSlashStatus = new StatusAsset();
            timeSlashStatus.id = "TimeSlash";
            timeSlashStatus.duration = 12f;
            timeSlashStatus.base_stats[S.damage] += 40f;
            timeSlashStatus.base_stats[S.attack_speed] += 50f;
            timeSlashStatus.path_icon = "ui/icons/timeSlash.png";
            timeSlashStatus.locale_id = "Time Slash";
            timeSlashStatus.locale_description = "Time bends, accelerating your deadly strikes!";
            timeSlashStatus.action_interval = 2f;
            timeSlashStatus.action = new WorldAction(TimeSlashEffect);
            localizeStatus(timeSlashStatus.id, timeSlashStatus.locale_id, timeSlashStatus.locale_description);
            AssetManager.status.add(timeSlashStatus);

            StatusAsset timeStopStatus = new StatusAsset();
            timeStopStatus.id = "TimeStop";
            timeStopStatus.duration = 8f;
            timeStopStatus.base_stats[S.speed] += 200f;
            timeStopStatus.base_stats[S.attack_speed] += 100f;
            timeStopStatus.path_icon = "ui/icons/timeStop.png";
            timeStopStatus.locale_id = "Time Stop";
            timeStopStatus.locale_description = "Freeze time to dominate the battlefield!";
            timeStopStatus.action_interval = 1f;
            timeStopStatus.action = new WorldAction(TimeStopEffect);
            localizeStatus(timeStopStatus.id, timeStopStatus.locale_id, timeStopStatus.locale_description);
            AssetManager.status.add(timeStopStatus);

            StatusAsset fireStatus = new StatusAsset();
            fireStatus.id = "Fire";
            fireStatus.duration = 12f;
            fireStatus.base_stats[S.damage] += 60f;
            fireStatus.base_stats[S.critical_chance] += 0.10f;
            fireStatus.path_icon = "ui/icons/fire.png";
            fireStatus.locale_id = "Fire";
            fireStatus.locale_description = "Blazing fury incinerates your enemies!";
            fireStatus.action_interval = 2f;
            fireStatus.action = new WorldAction(FireEffect);
            localizeStatus(fireStatus.id, fireStatus.locale_id, fireStatus.locale_description);
            AssetManager.status.add(fireStatus);

            StatusAsset iceStatus = new StatusAsset();
            iceStatus.id = "Ice";
            iceStatus.duration = 12f;
            iceStatus.base_stats[S.damage] += 70f;
            iceStatus.base_stats[S.armor] += 20f;
            iceStatus.path_icon = "ui/icons/ice.png";
            iceStatus.locale_id = "Ice";
            iceStatus.locale_description = "Freezing power chills and shatters foes!";
            iceStatus.action_interval = 2f;
            iceStatus.action = new WorldAction(IceEffect);
            localizeStatus(iceStatus.id, iceStatus.locale_id, iceStatus.locale_description);
            AssetManager.status.add(iceStatus);

            StatusAsset poisonStatus = new StatusAsset();
            poisonStatus.id = "Poison";
            poisonStatus.duration = 15f;
            poisonStatus.base_stats[S.damage] += 80f;
            poisonStatus.base_stats[S.health] += 600f;
            poisonStatus.path_icon = "ui/icons/poison.png";
            poisonStatus.locale_id = "Poison";
            poisonStatus.locale_description = "Venom courses through, weakening enemies!";
            poisonStatus.action_interval = 2f;
            poisonStatus.action = new WorldAction(PoisonEffect);
            localizeStatus(poisonStatus.id, poisonStatus.locale_id, poisonStatus.locale_description);
            AssetManager.status.add(poisonStatus);

            StatusAsset speedStatus = new StatusAsset();
            speedStatus.id = "Speed";
            speedStatus.duration = 10f;
            speedStatus.base_stats[S.speed] += 150f;
            speedStatus.base_stats[S.attack_speed] += 80f;
            speedStatus.path_icon = "ui/icons/speed.png";
            speedStatus.locale_id = "Speed";
            speedStatus.locale_description = "Lightning speed overwhelms your foes!";
            speedStatus.action_interval = 1f;
            speedStatus.action = new WorldAction(SpeedEffect);
            localizeStatus(speedStatus.id, speedStatus.locale_id, speedStatus.locale_description);
            AssetManager.status.add(speedStatus);

            StatusAsset goldenSkeletonStatus = new StatusAsset();
            goldenSkeletonStatus.id = "GoldenSkeleton";
            goldenSkeletonStatus.duration = 15f;
            goldenSkeletonStatus.base_stats[S.health] += 800f;
            goldenSkeletonStatus.base_stats[S.armor] += 30f;
            goldenSkeletonStatus.path_icon = "ui/icons/goldenSkeleton.png";
            goldenSkeletonStatus.locale_id = "Golden Skeleton";
            goldenSkeletonStatus.locale_description = "A golden frame grants unmatched resilience!";
            goldenSkeletonStatus.action_interval = 2f;
            goldenSkeletonStatus.action = new WorldAction(GoldenSkeletonEffect);
            localizeStatus(goldenSkeletonStatus.id, goldenSkeletonStatus.locale_id, goldenSkeletonStatus.locale_description);
            AssetManager.status.add(goldenSkeletonStatus);

            StatusAsset eyeOfHeavenStatus = new StatusAsset();
            eyeOfHeavenStatus.id = "EyeOfHeaven";
            eyeOfHeavenStatus.duration = 18f;
            eyeOfHeavenStatus.base_stats[S.damage] += 110f;
            eyeOfHeavenStatus.base_stats[S.accuracy] += 50f;
            eyeOfHeavenStatus.path_icon = "ui/icons/heavenEye.png";
            eyeOfHeavenStatus.locale_id = "Eye of Heaven";
            eyeOfHeavenStatus.locale_description = "Heaven’s gaze ensures deadly precision!";
            eyeOfHeavenStatus.action_interval = 2f;
            eyeOfHeavenStatus.action = new WorldAction(EyeOfHeavenEffect);
            localizeStatus(eyeOfHeavenStatus.id, eyeOfHeavenStatus.locale_id, eyeOfHeavenStatus.locale_description);
            AssetManager.status.add(eyeOfHeavenStatus);

            StatusAsset immortalTreeStatus = new StatusAsset();
            immortalTreeStatus.id = "ImmortalTree";
            immortalTreeStatus.duration = 20f;
            immortalTreeStatus.base_stats[S.health] += 1000f;
            immortalTreeStatus.base_stats[S.mana] += 400f;
            immortalTreeStatus.path_icon = "ui/icons/immortalTree.png";
            immortalTreeStatus.locale_id = "Immortal Tree";
            immortalTreeStatus.locale_description = "Life’s essence grants eternal vitality!";
            immortalTreeStatus.action_interval = 2f;
            immortalTreeStatus.action = new WorldAction(ImmortalTreeEffect);
            localizeStatus(immortalTreeStatus.id, immortalTreeStatus.locale_id, immortalTreeStatus.locale_description);
            AssetManager.status.add(immortalTreeStatus);

            StatusAsset windAndThunderWingsStatus = new StatusAsset();
            windAndThunderWingsStatus.id = "WindAndThunderWings";
            windAndThunderWingsStatus.duration = 15f;
            windAndThunderWingsStatus.base_stats[S.speed] += 200f;
            windAndThunderWingsStatus.base_stats[S.damage] += 130f;
            windAndThunderWingsStatus.path_icon = "ui/icons/windAndThunderWings.png";
            windAndThunderWingsStatus.locale_id = "Wind and Thunder Wings";
            windAndThunderWingsStatus.locale_description = "Storm wings propel you with devastating force!";
            windAndThunderWingsStatus.action_interval = 1f;
            windAndThunderWingsStatus.action = new WorldAction(WindAndThunderWingsEffect);
            localizeStatus(windAndThunderWingsStatus.id, windAndThunderWingsStatus.locale_id, windAndThunderWingsStatus.locale_description);
            AssetManager.status.add(windAndThunderWingsStatus);

            StatusAsset voidRuptStatus = new StatusAsset();
            voidRuptStatus.id = "VoidRupt";
            voidRuptStatus.duration = 20f;
            voidRuptStatus.base_stats[S.damage] += 150f;
            voidRuptStatus.base_stats[S.knockback] += 3f;
            voidRuptStatus.path_icon = "ui/icons/voidRupt.png";
            voidRuptStatus.locale_id = "Void Rupt";
            voidRuptStatus.locale_description = "The void erupts, annihilating all in its path!";
            voidRuptStatus.action_interval = 2f;
            voidRuptStatus.action = new WorldAction(VoidRuptEffect);
            localizeStatus(voidRuptStatus.id, voidRuptStatus.locale_id, voidRuptStatus.locale_description);
            AssetManager.status.add(voidRuptStatus);

            StatusAsset starwovenCharmStatus = new StatusAsset();
            starwovenCharmStatus.id = "StarwovenCharm";
            starwovenCharmStatus.duration = 12f;
            starwovenCharmStatus.base_stats[S.mana] += 200f;
            starwovenCharmStatus.base_stats[S.accuracy] += 30f;
            starwovenCharmStatus.path_icon = "ui/icons/starwoven_charm";
            starwovenCharmStatus.locale_id = "Starwoven Charm";
            starwovenCharmStatus.locale_description = "Starlight guides your precise strikes!";
            starwovenCharmStatus.action_interval = 2f;
            starwovenCharmStatus.action = new WorldAction(StarwovenCharmEffect);
            localizeStatus(starwovenCharmStatus.id, starwovenCharmStatus.locale_id, starwovenCharmStatus.locale_description);
            AssetManager.status.add(starwovenCharmStatus);

            StatusAsset shadowveilRelicStatus = new StatusAsset();
            shadowveilRelicStatus.id = "ShadowveilRelic";
            shadowveilRelicStatus.duration = 10f;
            shadowveilRelicStatus.base_stats[S.speed] += 100f;
            shadowveilRelicStatus.base_stats[S.armor] += 15f;
            shadowveilRelicStatus.path_icon = "ui/icons/shadowveil_relic";
            shadowveilRelicStatus.locale_id = "Shadowveil Relic";
            shadowveilRelicStatus.locale_description = "Shadows cloak you, enhancing agility and defense!";
            shadowveilRelicStatus.action_interval = 1f;
            shadowveilRelicStatus.action = new WorldAction(ShadowveilRelicEffect);
            localizeStatus(shadowveilRelicStatus.id, shadowveilRelicStatus.locale_id, shadowveilRelicStatus.locale_description);
            AssetManager.status.add(shadowveilRelicStatus);

            StatusAsset dawnbreakerAmuletStatus = new StatusAsset();
            dawnbreakerAmuletStatus.id = "DawnbreakerAmulet";
            dawnbreakerAmuletStatus.duration = 12f;
            dawnbreakerAmuletStatus.base_stats[S.damage] += 40f;
            dawnbreakerAmuletStatus.base_stats[S.critical_chance] += 0.08f;
            dawnbreakerAmuletStatus.path_icon = "ui/icons/dawnbreaker_amulet";
            dawnbreakerAmuletStatus.locale_id = "Dawnbreaker Amulet";
            dawnbreakerAmuletStatus.locale_description = "Dawn’s light fuels your radiant strikes!";
            dawnbreakerAmuletStatus.action_interval = 2f;
            dawnbreakerAmuletStatus.action = new WorldAction(DawnbreakerAmuletEffect);
            localizeStatus(dawnbreakerAmuletStatus.id, dawnbreakerAmuletStatus.locale_id, dawnbreakerAmuletStatus.locale_description);
            AssetManager.status.add(dawnbreakerAmuletStatus);

            StatusAsset frostspireWardStatus = new StatusAsset();
            frostspireWardStatus.id = "FrostspireWard";
            frostspireWardStatus.duration = 14f;
            frostspireWardStatus.base_stats[S.armor] += 20f;
            frostspireWardStatus.base_stats[S.health] += 500f;
            frostspireWardStatus.path_icon = "ui/icons/frostspire_ward";
            frostspireWardStatus.locale_id = "Frostspire Ward";
            frostspireWardStatus.locale_description = "Icy wards shield you from harm!";
            frostspireWardStatus.action_interval = 2f;
            frostspireWardStatus.action = new WorldAction(FrostspireWardEffect);
            localizeStatus(frostspireWardStatus.id, frostspireWardStatus.locale_id, frostspireWardStatus.locale_description);
            AssetManager.status.add(frostspireWardStatus);

            StatusAsset sunkenOracleStatus = new StatusAsset();
            sunkenOracleStatus.id = "SunkenOracle";
            sunkenOracleStatus.duration = 15f;
            sunkenOracleStatus.base_stats[S.mana] += 300f;
            sunkenOracleStatus.base_stats[S.accuracy] += 40f;
            sunkenOracleStatus.path_icon = "ui/icons/sunken_oracle";
            sunkenOracleStatus.locale_id = "Sunken Oracle";
            sunkenOracleStatus.locale_description = "Ancient wisdom enhances your precision and power!";
            sunkenOracleStatus.action_interval = 2f;
            sunkenOracleStatus.action = new WorldAction(SunkenOracleEffect);
            localizeStatus(sunkenOracleStatus.id, sunkenOracleStatus.locale_id, sunkenOracleStatus.locale_description);
            AssetManager.status.add(sunkenOracleStatus);

            StatusAsset voidtouchedCrestStatus = new StatusAsset();
            voidtouchedCrestStatus.id = "VoidtouchedCrest";
            voidtouchedCrestStatus.duration = 16f;
            voidtouchedCrestStatus.base_stats[S.damage] += 70f;
            voidtouchedCrestStatus.base_stats[S.health] += 600f;
            voidtouchedCrestStatus.path_icon = "ui/icons/voidtouched_crest";
            voidtouchedCrestStatus.locale_id = "Voidtouched Crest";
            voidtouchedCrestStatus.locale_description = "The void’s touch empowers your might!";
            voidtouchedCrestStatus.action_interval = 2f;
            voidtouchedCrestStatus.action = new WorldAction(VoidtouchedCrestEffect);
            localizeStatus(voidtouchedCrestStatus.id, voidtouchedCrestStatus.locale_id, voidtouchedCrestStatus.locale_description);
            AssetManager.status.add(voidtouchedCrestStatus);

            StatusAsset abyssalLockStatus = new StatusAsset();
            abyssalLockStatus.id = "AbyssalLock";
            abyssalLockStatus.duration = 12f;
            abyssalLockStatus.base_stats[S.damage] += 30f;
            abyssalLockStatus.base_stats[S.mana] += 250f;
            abyssalLockStatus.path_icon = "ui/icons/abyssalLockSeal";
            abyssalLockStatus.locale_id = "Abyssal Lock";
            abyssalLockStatus.locale_description = "Abyssal forces bind and empower you!";
            abyssalLockStatus.action_interval = 2f;
            abyssalLockStatus.action = new WorldAction(AbyssalLockEffect);
            localizeStatus(abyssalLockStatus.id, abyssalLockStatus.locale_id, abyssalLockStatus.locale_description);
            AssetManager.status.add(abyssalLockStatus);
        }

        public static bool InvisibleSealedEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null)
            {
                Debug.LogWarning("InvisibleSealedEffect: Target or Actor is null!");
                return false;
            }

            Debug.Log($"InvisibleSealedEffect: Target {pTarget.a.name} speed before: {pTarget.a.stats[S.speed]}, multiplier: {pTarget.a.stats[S.multiplier_speed]}");

            pTarget.a.stats[S.speed] = Mathf.Min(pTarget.a.stats[S.speed], -10000f);
            pTarget.a.stats[S.multiplier_speed] = Mathf.Min(pTarget.a.stats[S.multiplier_speed], -0.99f);

            Debug.Log($"InvisibleSealedEffect: Target {pTarget.a.name} speed after: {pTarget.a.stats[S.speed]}, multiplier: {pTarget.a.stats[S.multiplier_speed]}");

            Color mycolor = pTarget.a.color;
            if (mycolor.a != 0.3f)
            {
                pTarget.a.color = new Color(mycolor.r, mycolor.g, mycolor.b, 0.3f);
                Debug.Log($"InvisibleSealedEffect: Set {pTarget.a.name} invisibility to alpha 0.3");
            }

            Debug.Log($"InvisibleSealedEffect: Added tags 'frozen_ai' and 'stop_idle_animation' to {pTarget.a.name} via base_stats");

            return true;
        }

        public static bool FinishInvisibility(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null)
            {
                Debug.LogWarning("FinishInvisibility: Target or Actor is null!");
                return false;
            }

            pTarget.a.color = new Color(1, 1, 1, 1);
            Debug.Log($"FinishInvisibility: Reset {pTarget.a.name} visibility to alpha 1");

            Debug.Log($"FinishInvisibility: Target {pTarget.a.name} speed: {pTarget.a.stats[S.speed]}, multiplier: {pTarget.a.stats[S.multiplier_speed]}");

            return true;
        }

        public static bool SoulSnatchEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(50f, true, AttackType.Other, pTarget, false);
                pTarget.a.addMana(20);
            }
            return true;
        }

        public static bool TrinityAuraEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(30f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool MoonstoneWhisperEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.addMana(10);
            return true;
        }

        public static bool EmberheartGlowEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(20f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool MysticBarrierEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(15);
            pTarget.a.addStatusEffect("MysticBarrier");
            return true;
        }

        public static bool CelestialBindingEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(25f, true, AttackType.Other, pTarget, false);
                pTarget.a.addStatusEffect("CelestialBinding");
            }
            return true;
        }

        public static bool SpaceTeleportEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            WorldTile randomTile = Toolbox.getRandomTileWithinDistance(pTile, 5);
            if (randomTile != null)
            {
                ActorMove.goTo(pTarget.a, randomTile, true, true);
            }
            return true;
        }

        public static bool SpaceCollapseEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(40f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool PrimordialRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(20);
            return true;
        }

        public static bool TemperedBodyEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(25);
            return true;
        }

        public static bool EarthRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(35f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool LordRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(40f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool KingRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(45f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool EmperorRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(50f, true, AttackType.Other, pTarget, false);
                pTarget.a.addMana(15);
            }
            return true;
        }

        public static bool HeavenRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.addMana(20);
            return true;
        }

        public static bool DemiGodRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(60f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool TrueGodRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(70f, true, AttackType.Other, pTarget, false);
                pTarget.a.addMana(25);
            }
            return true;
        }

        public static bool GodKingRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(80f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool GodEmperorRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(90f, true, AttackType.Other, pTarget, false);
                pTarget.a.restoreHealth(30);
            }
            return true;
        }

        public static bool SupremeGodRealmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(100f, true, AttackType.Other, pTarget, false);
                pTarget.a.addMana(30);
            }
            return true;
        }

        public static bool VoidShieldEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(20);
            return true;
        }

        public static bool VoidSlashEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(30f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool TimeSlashEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(35f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool TimeStopEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.addStatusEffect("Sealed");
            }
            return true;
        }

        public static bool FireEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(50f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool IceEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(55f, true, AttackType.Other, pTarget, false);
                target.addStatusEffect("Sealed");
            }
            return true;
        }

        public static bool PoisonEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(60f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool SpeedEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            WorldTile randomTile = Toolbox.getRandomTileWithinDistance(pTile, 3);
            if (randomTile != null)
            {
                ActorMove.goTo(pTarget.a, randomTile, true, true);
            }
            return true;
        }

        public static bool GoldenSkeletonEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(30);
            return true;
        }

        public static bool EyeOfHeavenEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(80f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool ImmortalTreeEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(40);
            pTarget.a.addMana(20);
            return true;
        }

        public static bool WindAndThunderWingsEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(90f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool VoidRuptEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(100f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool StarwovenCharmEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.addMana(15);
            return true;
        }

        public static bool ShadowveilRelicEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            WorldTile randomTile = Toolbox.getRandomTileWithinDistance(pTile, 4);
            if (randomTile != null)
            {
                ActorMove.goTo(pTarget.a, randomTile, true, true);
            }
            return true;
        }

        public static bool DawnbreakerAmuletEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(35f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool FrostspireWardEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.restoreHealth(25);
            return true;
        }

        public static bool SunkenOracleEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null) return false;
            pTarget.a.addMana(20);
            return true;
        }

        public static bool VoidtouchedCrestEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(50f, true, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool AbyssalLockEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            if (pTarget?.a == null || !pTarget.a.checkCurrentEnemyTarget()) return false;
            Actor target = pTarget.a.attack_target?.a;
            if (target != null && target.isAlive())
            {
                target.getHit(30f, true, AttackType.Other, pTarget, false);
                pTarget.a.addStatusEffect("AbyssalLock");
            }
            return true;
        }

        public static void localizeStatus(string id, string name, string description)
        {
            Dictionary<string, string> localizedText = LocalizedTextManager.instance._localized_text;
            localizedText.Add(name, id);
            localizedText.Add(description, description);
        }

        public static void ApplySealedToAttacker(BaseSimObject pTarget, BaseSimObject pAttacker, WorldTile pTile)
        {
            if (pTarget?.a == null || pAttacker?.a == null)
            {
                Debug.LogWarning("ApplySealedToAttacker: Target or Attacker is null!");
                return;
            }

            Debug.Log($"ApplySealedToAttacker: Checking seals on target {pTarget.a.name} attacked by {pAttacker.a.name}");

            if (pTarget.a.hasTrait("mystic_barrier_seal"))
            {
                pAttacker.addStatusEffect("MysticBarrier");
                pAttacker.addStatusEffect("Sealed");
                Debug.Log($"ApplySealedToAttacker: Applied MysticBarrier and Sealed to {pAttacker.a.name}");
            }
            if (pTarget.a.hasTrait("celestial_binding_seal"))
            {
                pAttacker.addStatusEffect("CelestialBinding");
                pAttacker.addStatusEffect("Sealed");
                Debug.Log($"ApplySealedToAttacker: Applied CelestialBinding and Sealed to {pAttacker.a.name}");
            }
            if (pTarget.a.hasTrait("abyssal_lock_seal"))
            {
                pAttacker.addStatusEffect("AbyssalLock");
                pAttacker.addStatusEffect("Sealed");
                Debug.Log($"ApplySealedToAttacker: Applied AbyssalLock and Sealed to {pAttacker.a.name}");
            }
        }
    }
}