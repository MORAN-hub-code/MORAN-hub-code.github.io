using System;
using System.Collections.Generic;
using UnityEngine;
using ReflectionUtility;
using NCMS;

namespace WorldSystem2
{
    class Realms
    {
        public static void init()
        {
            Debug.Log("Realms.init() called");

            ActorTrait soul = new ActorTrait();
            soul.id = "soul";
            soul.rarity = Rarity.R0_Normal;
            soul.path_icon = "ui/icons/soul";
            soul.rate_inherit = 5;
            soul.group_id = "worldsystemtg";
            soul.unlocked_with_achievement = false;
            soul.action_special_effect = new WorldAction(soulSnatch);
            AssetManager.traits.add(soul);
            LocalizedTextManager.add("trait_soul", "Soul realm");

            ActorTrait trinity = new ActorTrait();
            trinity.id = "trinity";
            trinity.rarity = Rarity.R0_Normal;
            trinity.path_icon = "ui/icons/trinity";
            trinity.rate_inherit = 5;
            trinity.group_id = "worldsystemtg";
            trinity.unlocked_with_achievement = false;
            trinity.action_special_effect = new WorldAction(FeelMyAura);
            AssetManager.traits.add(trinity);
            LocalizedTextManager.add("trait_trinity", "Trinity realm");

            ActorTrait primordialRealm = new ActorTrait();
            primordialRealm.id = "primordial_realm";
            primordialRealm.rarity = Rarity.R0_Normal;
            primordialRealm.path_icon = "ui/icons/primordial_realm";
            primordialRealm.rate_inherit = 4;
            primordialRealm.group_id = "worldsystemtg";
            primordialRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(primordialRealm);
            LocalizedTextManager.add("trait_primordial_realm", "Primordial Realm");

            ActorTrait temperedBodyRealm = new ActorTrait();
            temperedBodyRealm.id = "tempered_body_realm";
            temperedBodyRealm.rarity = Rarity.R0_Normal;
            temperedBodyRealm.path_icon = "ui/icons/tempered_body_realm";
            temperedBodyRealm.rate_inherit = 4;
            temperedBodyRealm.group_id = "worldsystemtg";
            temperedBodyRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(temperedBodyRealm);
            LocalizedTextManager.add("trait_tempered_body_realm", "Tempered Body Realm");

            ActorTrait earthRealm = new ActorTrait();
            earthRealm.id = "earth_realm";
            earthRealm.rarity = Rarity.R0_Normal;
            earthRealm.path_icon = "ui/icons/Earth";
            earthRealm.rate_inherit = 3;
            earthRealm.group_id = "worldsystemtg";
            earthRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(earthRealm);
            LocalizedTextManager.add("trait_earth_realm", "Earth Realm");

            ActorTrait lordRealm = new ActorTrait();
            lordRealm.id = "lord_realm";
            lordRealm.rarity = Rarity.R0_Normal;
            lordRealm.path_icon = "ui/icons/Lord";
            lordRealm.rate_inherit = 3;
            lordRealm.group_id = "worldsystemtg";
            lordRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(lordRealm);
            LocalizedTextManager.add("trait_lord_realm", "Lord Realm");

            ActorTrait kingRealm = new ActorTrait();
            kingRealm.id = "king_realm";
            kingRealm.rarity = Rarity.R0_Normal;
            kingRealm.path_icon = "ui/icons/King";
            kingRealm.rate_inherit = 2;
            kingRealm.group_id = "worldsystemtg";
            kingRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(kingRealm);
            LocalizedTextManager.add("trait_king_realm", "King Realm");

            ActorTrait emperorRealm = new ActorTrait();
            emperorRealm.id = "emperor_realm";
            emperorRealm.rarity = Rarity.R0_Normal;
            emperorRealm.path_icon = "ui/icons/Emperor";
            emperorRealm.rate_inherit = 2;
            emperorRealm.group_id = "worldsystemtg";
            emperorRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(emperorRealm);
            LocalizedTextManager.add("trait_emperor_realm", "Emperor Realm");

            ActorTrait heavenRealm = new ActorTrait();
            heavenRealm.id = "heaven_realm";
            heavenRealm.rarity = Rarity.R0_Normal;
            heavenRealm.path_icon = "ui/icons/heaven_realm";
            heavenRealm.rate_inherit = 1;
            heavenRealm.group_id = "worldsystemtg";
            heavenRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(heavenRealm);
            LocalizedTextManager.add("trait_heaven_realm", "Heaven Realm");

            ActorTrait demiGodRealm = new ActorTrait();
            demiGodRealm.id = "demi_god_realm";
            demiGodRealm.rarity = Rarity.R0_Normal;
            demiGodRealm.path_icon = "ui/icons/DemiGod";
            demiGodRealm.rate_inherit = 1;
            demiGodRealm.group_id = "worldsystemtg";
            demiGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(demiGodRealm);
            LocalizedTextManager.add("trait_demi_god_realm", "Demi God Realm");

            ActorTrait trueGodRealm = new ActorTrait();
            trueGodRealm.id = "true_god_realm";
            trueGodRealm.rarity = Rarity.R0_Normal;
            trueGodRealm.path_icon = "ui/icons/TrueGod";
            trueGodRealm.rate_inherit = (int)0.5f;
            trueGodRealm.group_id = "worldsystemtg";
            trueGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(trueGodRealm);
            LocalizedTextManager.add("trait_true_god_realm", "True God Realm");

            ActorTrait godKingRealm = new ActorTrait();
            godKingRealm.id = "god_king_realm";
            godKingRealm.rarity = Rarity.R0_Normal;
            godKingRealm.path_icon = "ui/icons/GodKing";
            godKingRealm.rate_inherit = (int)0.5f;
            godKingRealm.group_id = "worldsystemtg";
            godKingRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(godKingRealm);
            LocalizedTextManager.add("trait_god_king_realm", "God King Realm");

            ActorTrait godEmperorRealm = new ActorTrait();
            godEmperorRealm.id = "god_emperor_realm";
            godEmperorRealm.rarity = Rarity.R0_Normal;
            godEmperorRealm.path_icon = "ui/icons/GodEmperor";
            godEmperorRealm.rate_inherit = (int)0.5f;
            godEmperorRealm.group_id = "worldsystemtg";
            godEmperorRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(godEmperorRealm);
            LocalizedTextManager.add("trait_god_emperor_realm", "God Emperor Realm");

            ActorTrait supremeGodRealm = new ActorTrait();
            supremeGodRealm.id = "supreme_god_realm";
            supremeGodRealm.rarity = Rarity.R0_Normal;
            supremeGodRealm.path_icon = "ui/icons/SupremeGod";
            supremeGodRealm.rate_inherit = (int)0.1f;
            supremeGodRealm.group_id = "worldsystemtg";
            supremeGodRealm.unlocked_with_achievement = false;
            AssetManager.traits.add(supremeGodRealm);
            LocalizedTextManager.add("trait_supreme_god_realm", "Supreme God Realm");

            Dictionary<string, Dictionary<string, float>> traitStats = new Dictionary<string, Dictionary<string, float>>
            {
                {"soul", new Dictionary<string, float>(){
                    {S.damage, 20f},
                    {S.mana, 300f},
                    {S.health, 500f},
                    {S.accuracy, 30f},
                    {S.attack_speed, 100f},
                    {S.critical_chance, 0.05f},
                    {S.range, 5f},
                    {S.speed, 90f},
                    {S.max_nutrition, 30f},
                    {S.offspring, 80f},
                }},
                {"trinity", new Dictionary<string, float>(){
                    {S.damage, 25f},
                    {S.mana, 350f},
                    {S.health, 550f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 110f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 95f},
                    {S.max_nutrition, 35f},
                    {S.offspring, 85f},
                }},
                {"primordial_realm", new Dictionary<string, float>(){
                    {S.damage, 30f},
                    {S.mana, 400f},
                    {S.health, 600f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.07f},
                    {S.range, 7f},
                    {S.speed, 100f},
                    {S.max_nutrition, 40f},
                    {S.offspring, 90f},
                }},
                {"tempered_body_realm", new Dictionary<string, float>(){
                    {S.damage, 35f},
                    {S.mana, 350f},
                    {S.health, 700f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 115f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 90f},
                    {S.max_nutrition, 45f},
                    {S.offspring, 80f},
                }},
                {"earth_realm", new Dictionary<string, float>(){
                    {S.damage, 40f},
                    {S.mana, 400f},
                    {S.health, 800f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.08f},
                    {S.range, 8f},
                    {S.speed, 95f},
                    {S.max_nutrition, 50f},
                    {S.offspring, 85f},
                }},
                {"lord_realm", new Dictionary<string, float>(){
                    {S.damage, 50f},
                    {S.mana, 450f},
                    {S.health, 900f},
                    {S.accuracy, 45f},
                    {S.attack_speed, 130f},
                    {S.critical_chance, 0.09f},
                    {S.range, 9f},
                    {S.speed, 100f},
                    {S.max_nutrition, 55f},
                    {S.offspring, 90f},
                }},
                {"king_realm", new Dictionary<string, float>(){
                    {S.damage, 60f},
                    {S.mana, 500f},
                    {S.health, 1000f},
                    {S.accuracy, 50f},
                    {S.attack_speed, 140f},
                    {S.critical_chance, 0.10f},
                    {S.range, 10f},
                    {S.speed, 105f},
                    {S.max_nutrition, 60f},
                    {S.offspring, 95f},
                }},
                {"emperor_realm", new Dictionary<string, float>(){
                    {S.damage, 70f},
                    {S.mana, 550f},
                    {S.health, 1100f},
                    {S.accuracy, 55f},
                    {S.attack_speed, 150f},
                    {S.critical_chance, 0.11f},
                    {S.range, 11f},
                    {S.speed, 110f},
                    {S.max_nutrition, 65f},
                    {S.offspring, 100f},
                }},
                {"heaven_realm", new Dictionary<string, float>(){
                    {S.damage, 80f},
                    {S.mana, 600f},
                    {S.health, 1200f},
                    {S.accuracy, 60f},
                    {S.attack_speed, 160f},
                    {S.critical_chance, 0.12f},
                    {S.range, 12f},
                    {S.speed, 115f},
                    {S.max_nutrition, 70f},
                    {S.offspring, 105f},
                }},
                {"demi_god_realm", new Dictionary<string, float>(){
                    {S.damage, 90f},
                    {S.mana, 650f},
                    {S.health, 1300f},
                    {S.accuracy, 65f},
                    {S.attack_speed, 170f},
                    {S.critical_chance, 0.13f},
                    {S.range, 13f},
                    {S.speed, 120f},
                    {S.max_nutrition, 75f},
                    {S.offspring, 110f},
                }},
                {"true_god_realm", new Dictionary<string, float>(){
                    {S.damage, 100f},
                    {S.mana, 700f},
                    {S.health, 1400f},
                    {S.accuracy, 70f},
                    {S.attack_speed, 180f},
                    {S.critical_chance, 0.14f},
                    {S.range, 14f},
                    {S.speed, 125f},
                    {S.max_nutrition, 80f},
                    {S.offspring, 115f},
                }},
                {"god_king_realm", new Dictionary<string, float>(){
                    {S.damage, 110f},
                    {S.mana, 750f},
                    {S.health, 1500f},
                    {S.accuracy, 75f},
                    {S.attack_speed, 190f},
                    {S.critical_chance, 0.15f},
                    {S.range, 15f},
                    {S.speed, 130f},
                    {S.max_nutrition, 85f},
                    {S.offspring, 120f},
                }},
                {"god_emperor_realm", new Dictionary<string, float>(){
                    {S.damage, 120f},
                    {S.mana, 800f},
                    {S.health, 1600f},
                    {S.accuracy, 80f},
                    {S.attack_speed, 200f},
                    {S.critical_chance, 0.16f},
                    {S.range, 16f},
                    {S.speed, 135f},
                    {S.max_nutrition, 90f},
                    {S.offspring, 125f},
                }},
                {"supreme_god_realm", new Dictionary<string, float>(){
                    {S.damage, 150f},
                    {S.mana, 1000f},
                    {S.health, 2000f},
                    {S.accuracy, 100f},
                    {S.attack_speed, 250f},
                    {S.critical_chance, 0.20f},
                    {S.range, 20f},
                    {S.speed, 150f},
                    {S.max_nutrition, 100f},
                    {S.offspring, 150f},
                }}
            };

            foreach (string traitId in traitStats.Keys)
            {
                ActorTrait trait = AssetManager.traits.get(traitId);
                if (trait != null)
                {
                    foreach (KeyValuePair<string, float> stat in traitStats[traitId])
                    {
                        trait.base_stats[stat.Key] = stat.Value;
                    }
                }
            }
        }

        private static bool soulSnatch(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("soulSnatch called on " + pTarget);
            return true;
        }

        private static bool FeelMyAura(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("FeelMyAura called on " + pTarget);
            return true;
        }
    }
}