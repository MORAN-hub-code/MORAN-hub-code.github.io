using System;
using System.Threading;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace WorldSystem2 
{
    class Modify
    {
        public static void init()
        {
            var bandit = AssetManager.actor_library.get("bandit");
            if (bandit != null)
            {
                bandit.traits.Remove("energized");
            }
            else
            {
                Debug.LogWarning("Actor 'bandit' not found in AssetManager.actor_library!");
            }

            var human = AssetManager.actor_library.get("unit_human");
            if (human != null)
            {
                human.traits.Add("genius");
                human.traits.Add("soul");
            }
            else
            {
                Debug.LogWarning("Actor 'unit_human' not found in AssetManager.actor_library!");
            }

            var elf = AssetManager.actor_library.get("unit_elf");
            if (elf != null)
            {
                elf.traits.Add("fast");
                elf.traits.Add("whispering_moonstone");
            }
            else
            {
                Debug.LogWarning("Actor 'unit_elf' not found in AssetManager.actor_library!");
            }

            var orc = AssetManager.actor_library.get("unit_orc");
            if (orc != null)
            {
                orc.traits.Add("eagle_eyed");
                orc.traits.Add("space_teleport");
            }
            else
            {
                Debug.LogWarning("Actor 'unit_orc' not found in AssetManager.actor_library!");
            }

            var dwarf = AssetManager.actor_library.get("unit_dwarf");
            if (dwarf != null)
            {
                dwarf.traits.Add("tough");
                dwarf.traits.Add("mystic_barrier_seal");
            }
            else
            {
                Debug.LogWarning("Actor 'unit_dwarf' not found in AssetManager.actor_library!");
            }

            var skeleton = AssetManager.actor_library.get("skeleton");
            if (skeleton != null)
            {
                skeleton.traits.Add("evil");
                skeleton.traits.Add("abyssal_lock_seal");
            }
            else
            {
                Debug.LogWarning("Actor 'skeleton' not found in AssetManager.actor_library!");
            }

            var bloodlust = AssetManager.traits.get("bloodlust");
            if (bloodlust != null)
            {
                bloodlust.rate_birth = (int)5f;
            }
            else
            {
                Debug.LogWarning("Trait 'bloodlust' not found in AssetManager.traits!");
            }

            var tough = AssetManager.traits.get("tough");
            if (tough != null)
            {
                tough.rate_birth = (int)5f;
            }
            else
            {
                Debug.LogWarning("Trait 'tough' not found in AssetManager.traits!");
            }

            var pyromaniac = AssetManager.traits.get("pyromaniac");
            if (pyromaniac != null)
            {
                pyromaniac.rate_birth = (int)0f;
            }
            else
            {
                Debug.LogWarning("Trait 'pyromaniac' not found in AssetManager.traits!");
            }

            var regeneration = AssetManager.traits.get("regeneration");
            if (regeneration != null)
            {
                regeneration.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'regeneration' not found in AssetManager.traits!");
            }

            var flesh_eater = AssetManager.traits.get("flesh_eater");
            if (flesh_eater != null)
            {
                flesh_eater.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'flesh_eater' not found in AssetManager.traits!");
            }

            var blessed = AssetManager.traits.get("blessed");
            if (blessed != null)
            {
                blessed.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'blessed' not found in AssetManager.traits!");
            }

            var cursed = AssetManager.traits.get("cursed");
            if (cursed != null)
            {
                cursed.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'cursed' not found in AssetManager.traits!");
            }

            var evil = AssetManager.traits.get("evil");
            if (evil != null)
            {
                evil.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'evil' not found in AssetManager.traits!");
            }

            var lucky = AssetManager.traits.get("lucky");
            if (lucky != null)
            {
                lucky.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'lucky' not found in AssetManager.traits!");
            }

            var unlucky = AssetManager.traits.get("unlucky");
            if (unlucky != null)
            {
                unlucky.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'unlucky' not found in AssetManager.traits!");
            }

            var immune = AssetManager.traits.get("immune");
            if (immune != null)
            {
                immune.rate_birth = (int)10f;
            }
            else
            {
                Debug.LogWarning("Trait 'immune' not found in AssetManager.traits!");
            }

            var strong = AssetManager.traits.get("strong");
            if (strong != null)
            {
                strong.rate_birth = (int)8f;
            }
            else
            {
                Debug.LogWarning("Trait 'strong' not found in AssetManager.traits!");
            }

            var weak = AssetManager.traits.get("weak");
            if (weak != null)
            {
                weak.rate_birth = (int)8f;
            }
            else
            {
                Debug.LogWarning("Trait 'weak' not found in AssetManager.traits!");
            }

            var fast = AssetManager.traits.get("fast");
            if (fast != null)
            {
                fast.rate_birth = (int)7f;
            }
            else
            {
                Debug.LogWarning("Trait 'fast' not found in AssetManager.traits!");
            }

            var slow = AssetManager.traits.get("slow");
            if (slow != null)
            {
                slow.rate_birth = (int)7f;
            }
            else
            {
                Debug.LogWarning("Trait 'slow' not found in AssetManager.traits!");
            }

            var mysticBarrierSeal = AssetManager.traits.get("mystic_barrier_seal");
            if (mysticBarrierSeal != null)
            {
                mysticBarrierSeal.base_stats[S.armor] += 10f;
            }
            else
            {
                Debug.LogWarning("Trait 'mystic_barrier_seal' not found in AssetManager.traits!");
            }

            var celestialBindingSeal = AssetManager.traits.get("celestial_binding_seal");
            if (celestialBindingSeal != null)
            {
                celestialBindingSeal.base_stats[S.critical_chance] += 0.05f;
            }
            else
            {
                Debug.LogWarning("Trait 'celestial_binding_seal' not found in AssetManager.traits!");
            }

            var abyssalLockSeal = AssetManager.traits.get("abyssal_lock_seal");
            if (abyssalLockSeal != null)
            {
                abyssalLockSeal.base_stats[S.mana] += 100f;
            }
            else
            {
                Debug.LogWarning("Trait 'abyssal_lock_seal' not found in AssetManager.traits!");
            }
        }
    }
}