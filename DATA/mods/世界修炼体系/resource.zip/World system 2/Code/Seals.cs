using System;
using System.Collections.Generic;
using UnityEngine;
using ReflectionUtility;
using NCMS;

namespace WorldSystem2
{
    class Seals
    {
        public static void init()
        {
            Debug.Log("Seals.init() called");

            ActorTrait mysticBarrierSeal = new ActorTrait();
            mysticBarrierSeal.id = "mystic_barrier_seal";
            mysticBarrierSeal.rarity = Rarity.R0_Normal;
            mysticBarrierSeal.path_icon = "ui/icons/mysticBarrierSeal";
            mysticBarrierSeal.rate_inherit = 5;
            mysticBarrierSeal.group_id = "worldsystemtg4";
            mysticBarrierSeal.unlocked_with_achievement = false;
            mysticBarrierSeal.action_special_effect = new WorldAction(MysticBarrierEffect);
            AssetManager.traits.add(mysticBarrierSeal);
            LocalizedTextManager.add("trait_mystic_barrier_seal", "Mystic Box Seal");

            ActorTrait celestialBindingSeal = new ActorTrait();
            celestialBindingSeal.id = "celestial_binding_seal";
            celestialBindingSeal.rarity = Rarity.R0_Normal;
            celestialBindingSeal.path_icon = "ui/icons/celestialPyramidSeal";
            celestialBindingSeal.rate_inherit = 5;
            celestialBindingSeal.group_id = "worldsystemtg4";
            celestialBindingSeal.unlocked_with_achievement = false;
            celestialBindingSeal.action_special_effect = new WorldAction(CelestialBindingEffect);
            AssetManager.traits.add(celestialBindingSeal);
            LocalizedTextManager.add("trait_celestial_binding_seal", "Celestial Pyramid Seal");

            ActorTrait abyssalLockSeal = new ActorTrait();
            abyssalLockSeal.id = "abyssal_lock_seal";
            abyssalLockSeal.rarity = Rarity.R0_Normal;
            abyssalLockSeal.path_icon = "ui/icons/abyssalLockSeal";
            abyssalLockSeal.rate_inherit = 4;
            abyssalLockSeal.group_id = "worldsystemtg4";
            abyssalLockSeal.unlocked_with_achievement = false;
            AssetManager.traits.add(abyssalLockSeal);
            LocalizedTextManager.add("trait_abyssal_lock_seal", "Abyssal Lock Seal");

            Dictionary<string, Dictionary<string, float>> traitStats = new Dictionary<string, Dictionary<string, float>>
            {
                {"mystic_barrier_seal", new Dictionary<string, float>(){
                    {S.damage, 20f},
                    {S.mana, 300f},
                    {S.health, 500f},
                    {S.accuracy, 30f},
                    {S.attack_speed, 100f},
                    {S.critical_chance, 0.05f},
                    {S.range, 5f},
                    {S.speed, 90f},
                    {S.max_nutrition, 30f},
                    {S.offspring, 80f},
                }},
                {"celestial_binding_seal", new Dictionary<string, float>(){
                    {S.damage, 25f},
                    {S.mana, 350f},
                    {S.health, 550f},
                    {S.accuracy, 35f},
                    {S.attack_speed, 110f},
                    {S.critical_chance, 0.06f},
                    {S.range, 6f},
                    {S.speed, 95f},
                    {S.max_nutrition, 35f},
                    {S.offspring, 85f},
                }},
                {"abyssal_lock_seal", new Dictionary<string, float>(){
                    {S.damage, 30f},
                    {S.mana, 400f},
                    {S.health, 600f},
                    {S.accuracy, 40f},
                    {S.attack_speed, 120f},
                    {S.critical_chance, 0.07f},
                    {S.range, 7f},
                    {S.speed, 100f},
                    {S.max_nutrition, 40f},
                    {S.offspring, 90f},
                }}
            };

            foreach (string traitId in traitStats.Keys)
            {
                ActorTrait trait = AssetManager.traits.get(traitId);
                if (trait != null)
                {
                    foreach (KeyValuePair<string, float> stat in traitStats[traitId])
                    {
                        trait.base_stats[stat.Key] = stat.Value;
                    }
                }
            }
        }

        private static bool MysticBarrierEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("MysticBarrierEffect called on " + pTarget);
            return true;
        }

        private static bool CelestialBindingEffect(BaseSimObject pTarget, WorldTile pTile)
        {
            Debug.Log("CelestialBindingEffect called on " + pTarget);
            return true;
        }
    }
}