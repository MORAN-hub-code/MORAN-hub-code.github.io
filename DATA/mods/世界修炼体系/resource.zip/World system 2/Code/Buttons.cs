///////////////////////////////////////////////////////Wip\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\



using UnityEngine;
using UnityEngine.UI;
using NCMS;
using NCMS.Utils;
using ReflectionUtility;

namespace WorldSystem2
{
    class Buttons : MonoBehaviour
    {
        public static void Init()
        {
            CreateTab("Button_Tab_Ws2", "Tab_Ws2", "Ws2", "World System 2", -150);
        }

        private static void CreateTab(string buttonID, string tabID, string name, string desc, int xPos)
        {
            GameObject otherTabButton = GameObjects.FindEvenInactive("Button_Other");
            if (otherTabButton == null) return;

            Localization.AddOrSet(buttonID, name);
            Localization.AddOrSet($"{buttonID} Description", desc);
            Localization.AddOrSet("ws2_mod_creator", "Made By Shangri-la");
            Localization.AddOrSet(tabID, name);

            GameObject newTabButton = GameObject.Instantiate(otherTabButton);
            if (newTabButton == null) return;
            GraphicRaycaster raycaster = newTabButton.GetComponent<GraphicRaycaster>();
            if (raycaster != null) GameObject.Destroy(raycaster);
            Component componentToRemove = newTabButton.GetComponents<Component>().Length > 9 ? newTabButton.GetComponents<Component>()[9] : null;
            if (componentToRemove != null) GameObject.Destroy(componentToRemove);

            newTabButton.transform.SetParent(otherTabButton.transform.parent);
            UnityEngine.UI.Button buttonComponent = newTabButton.GetComponent<UnityEngine.UI.Button>();
            if (buttonComponent == null) return;
            TipButton tipButton = buttonComponent.gameObject.GetComponent<TipButton>();
            if (tipButton != null)
            {
                tipButton.textOnClick = buttonID;
                tipButton.textOnClickDescription = $"{buttonID} Description";
                tipButton.text_description_2 = "ws2_mod_creator";
            }

            newTabButton.transform.localPosition = new Vector3(xPos, 49.57f);
            newTabButton.transform.localScale = Vector3.one;
            newTabButton.name = buttonID;

            var spriteForTab = Resources.Load<Sprite>("ui/icons/TabIcon");
            if (spriteForTab == null) spriteForTab = Resources.Load<Sprite>("ui/Icons/icon");
            Transform iconTransform = newTabButton.transform.Find("Icon");
            if (iconTransform != null)
            {
                Image iconImage = iconTransform.GetComponent<Image>();
                if (iconImage != null) iconImage.sprite = spriteForTab;
            }

            GameObject otherTab = GameObjects.FindEvenInactive("Tab_Other");
            if (otherTab == null) return;

            foreach (Transform child in otherTab.transform) child.gameObject.SetActive(false);

            GameObject additionalPowersTab = GameObject.Instantiate(otherTab);
            if (additionalPowersTab == null) return;

            foreach (Transform child in additionalPowersTab.transform)
            {
                if (child.gameObject.name == "tabBackButton" || child.gameObject.name == "-space")
                {
                    child.gameObject.SetActive(true);
                    continue;
                }
                GameObject.Destroy(child.gameObject);
            }

            foreach (Transform child in otherTab.transform) child.gameObject.SetActive(true);

            additionalPowersTab.transform.SetParent(otherTab.transform.parent);
            PowersTab powersTabComponent = additionalPowersTab.GetComponent<PowersTab>();
            if (powersTabComponent == null) return;
            powersTabComponent.powerButton = buttonComponent;
            powersTabComponent.powerButtons.Clear();

            additionalPowersTab.name = tabID;
            powersTabComponent.powerButton.onClick = new UnityEngine.UI.Button.ButtonClickedEvent();
            powersTabComponent.powerButton.onClick.AddListener(() => TabOnClick(tabID));
            Reflection.SetField<GameObject>(powersTabComponent, "parentObj", otherTab.transform.parent.parent.gameObject);

            additionalPowersTab.SetActive(true);
            powersTabComponent.powerButton.gameObject.SetActive(true);
        }

        private static void TabOnClick(string tabID)
        {
            GameObject additionalTab = GameObjects.FindEvenInactive(tabID);
            if (additionalTab == null) return;
            PowersTab additionalPowersTab = additionalTab.GetComponent<PowersTab>();
            if (additionalPowersTab != null) additionalPowersTab.showTab(additionalPowersTab.powerButton);
        }
    }
}