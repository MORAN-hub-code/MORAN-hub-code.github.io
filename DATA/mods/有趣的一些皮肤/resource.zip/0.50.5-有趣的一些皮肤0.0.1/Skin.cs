﻿using NeoModLoader.api;
using Skin.code;
using HarmonyLib;

namespace Skin
{
    internal class SkinClass : BasicMod<SkinClass>
    {
        public static string id = "shiyue.worldbox.mod.Skin";

        protected override void OnModLoad()
        {            
            traits.Init();
            traitGroup.Init();
            new Harmony(id).PatchAll(typeof(patch));
        }
    }
}