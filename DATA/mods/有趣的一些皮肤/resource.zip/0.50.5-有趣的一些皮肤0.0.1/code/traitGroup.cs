﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Skin.code
{
    internal class traitGroup
    {
        public static void Init()
        {
            ActorTraitGroupAsset Skin = new ActorTraitGroupAsset();
            Skin.id = "Skin";
            Skin.name = "trait_group_Skin";
            Skin.color = "#FFFAFA";
            AssetManager.trait_groups.add(Skin);
        }
    }
}
