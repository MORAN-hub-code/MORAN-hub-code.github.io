using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;

namespace Skin.code
{
	internal class traits
	{
		private static ActorTrait CreateTrait(string id, string path_icon, string group_id)
		{
			ActorTrait trait = new ActorTrait();
			trait.id = id;
			trait.path_icon = path_icon;
			trait.needs_to_be_explored = false;
			trait.group_id = group_id;
			trait.base_stats = new BaseStats();

			return trait;
		}
		public static void Init()
		{
			ActorTrait Skin1 = CreateTrait("Skin1", "trait/Skin1", "Skin");
			AssetManager.traits.add(Skin1);

			ActorTrait Skin2 = CreateTrait("Skin2", "trait/Skin2", "Skin");
			AssetManager.traits.add(Skin2);

			ActorTrait Skin3 = CreateTrait("Skin3", "trait/Skin3", "Skin");
			AssetManager.traits.add(Skin3);

			ActorTrait Skin4 = CreateTrait("Skin4", "trait/Skin4", "Skin");
			AssetManager.traits.add(Skin4);

			ActorTrait Skin5 = CreateTrait("Skin5", "trait/Skin5", "Skin");
			AssetManager.traits.add(Skin5);

			ActorTrait Skin6 = CreateTrait("Skin6", "trait/Skin6", "Skin");
			AssetManager.traits.add(Skin6);

			ActorTrait Skin7 = CreateTrait("Skin7", "trait/Skin7", "Skin");
			SafeSetStat(Skin7.base_stats, strings.S.scale, -0.07f);
			AssetManager.traits.add(Skin7);

			ActorTrait Skin8 = CreateTrait("Skin8", "trait/Skin8", "Skin");
			SafeSetStat(Skin8.base_stats, strings.S.scale, -0.05f);
			AssetManager.traits.add(Skin8);
		}
		private static void SafeSetStat(BaseStats baseStats, string statKey, float value)
		{
			baseStats[statKey] = value;
		}
    }
}
