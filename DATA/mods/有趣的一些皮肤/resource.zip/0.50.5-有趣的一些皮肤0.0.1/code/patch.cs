﻿using System.Collections.Generic;
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using ai.behaviours;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using ReflectionUtility;
using UnityEngine.UI;
using ai;
using Skin.code;

namespace Skin.code;

internal class patch
{
    [HarmonyPrefix]
    [HarmonyPatch(typeof(Actor), "checkAnimationContainer")]
    public static bool CheckAnimationContainerPrefix(Actor __instance)
    {
        // 空值检查
        if (__instance == null || __instance.data == null || __instance.asset == null || 
            __instance.batch == null || !__instance.isAlive())
        {
            return true; // 继续执行原方法
        }

        // 使用默认纹理路径
        string textureBasePath = __instance.asset.texture_asset?.texture_path_base ?? "";
        string animationContainerPath = $"{textureBasePath}";
        bool setAnimationContainer = false;
        
        // 特质到动画路径的映射（按优先级排序）
        var traitToAnimationFrame = new Dictionary<string, string>
        {
            { "Skin1", "Skin_1" },
            { "Skin2", "Skin_2" },
            { "Skin3", "Skin_3" },
            { "Skin4", "Skin_4" },
            { "Skin5", "Skin_5" },
            { "Skin6", "Skin_6" },
            { "Skin7", "Skin_7" },
            { "Skin8", "Skin_8" }
        };

        // 检查特质并设置动画路径
        foreach (var traitPair in traitToAnimationFrame)
        {
            if (__instance.hasStatus(traitPair.Key) || __instance.hasTrait(traitPair.Key))
            {
                animationContainerPath = traitPair.Value;
                setAnimationContainer = true;
                break;
            }
        }

        // 设置动画容器
        if (setAnimationContainer)
        {
            // 设置头部精灵
            string headPath = "base_head";
            
            // 正确调用checkHeadID方法 - 传递null作为精灵数组
            //__instance.checkHeadID(null, false);
            __instance.dirty_sprite_main = false;
            __instance.dirty_sprite_head = false;
            __instance._dirty_sprite_item = false;
            
            // 设置头部精灵
            __instance.setHeadSprite(ActorAnimationLoader.getHead(headPath, 0));
            
            // 获取动画容器
            Subspecies subspecies = __instance.subspecies;
            SubspeciesTrait pEggAsset = subspecies?.egg_asset;
            SubspeciesTrait pMutationSkinAsset = subspecies?.mutation_skin_asset;
            
            // 使用正确的加载方法
            __instance.animation_container = ActorAnimationLoader.getAnimationContainer(
                animationContainerPath, 
                __instance.asset, 
                pEggAsset, 
                pMutationSkinAsset);
            
            return false; // 跳过原方法
        }
    
        return true; // 继续执行原方法
    }

    // 辅助方法：获取或生成动画索引
    private static int GetActorAnimationIndex(string actorId, int min, int max)
    {
        if (!actorAnimationValues.TryGetValue(actorId, out int index))
        {
            index = Randy.randomInt(min, max);
            actorAnimationValues[actorId] = index;
        }
        return index;
    }

    // 静态字典存储动画索引
    private static readonly Dictionary<string, int> actorAnimationValues = new Dictionary<string, int>();
}