﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using UnityEngine;
using UnityEngine.UI;
using VideoCopilot.code.utils;


namespace ChivalryWizardingWorld.code
{
    internal class patch
    {
        public static bool window_creature_info_initialized;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UnitWindow), nameof(UnitWindow.OnEnable))]
        private static void WindowCreatureInfo_OnEnable_postfix(UnitWindow __instance)
        {
            if (__instance.actor == null || !__instance.actor.isAlive())
                return;
            if (!window_creature_info_initialized)
            {
                window_creature_info_initialized = true;
                UnitWindowStatsIcon.Initialize(__instance);
            }

            UnitWindowStatsIcon.OnEnable(__instance, __instance.actor);
        }
        [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateAge")]
        public static void updateWorldTime_KnightPostfix(Actor __instance)
        {
            if (__instance == null)
            {
                return;
            }

            float age = (float)__instance.getAge();
            bool hasTalent6 = __instance.hasTrait("clone");// 检查是否具有特质
            bool hasTalent5 = __instance.hasTrait("talent5");
            {
                // 9岁时获得talent1-talent4的随机特质
                if (Mathf.FloorToInt(age) == 9 && !hasTalent5 && !hasTalent6 &&
                !HasAnyFlairTalen(__instance) &&
                Randy.randomChance(0.3f))
                {
                    var talentWeights = new (string traitId, int weight)[]
                    {
                        ("talent1", 580),
                        ("talent2", 300),
                        ("talent3", 90),
                        ("talent4", 10),
                        ("talent6", 9),
                        ("talent7", 7),                        
                        ("talent8", 3),
                        ("talent9", 1)
                    };

                    // 计算总权重
                    int totalWeight = talentWeights.Sum(t => t.weight);

                    // 生成随机数
                    int randomValue = UnityEngine.Random.Range(0, totalWeight);

                    // 遍历权重选择特质
                    string selectedTalent = "talent1"; // 默认值
                    foreach (var talent in talentWeights)
                    {
                        if (randomValue < talent.weight)
                        {
                            selectedTalent = talent.traitId;
                            break;
                        }
                        randomValue -= talent.weight;
                    }

                    __instance.addTrait(selectedTalent, false);
                }
            }

            // 特质增加生命之力的处理
                var talentKnightChanges = new Dictionary<string, (float, float)>
            {
                { "talent1", (1.0f, 2.0f) },//下
                { "talent2", (2.0f, 3.0f) },//中
                { "talent3", (3.0f, 4.0f) },//上
                { "talent4", (4.0f, 5.0f) },//完美
                { "talent6", (6.0f, 7.0f) },
                { "talent7", (7.0f, 8.0f) },         
                { "talent8", (8.0f, 9.0f) },
                { "talent9", (10.0f, 20.0f) }//安享晚年
            };

            foreach (var change in talentKnightChanges)
            {
                // 如果具有talent6特质，并且当前特质是talent1到talent4，则跳过
                if ((hasTalent6 || hasTalent5) && (change.Key == "talent1" || change.Key == "talent2" || change.Key == "talent3" || change.Key == "talent4" ||  change.Key == "talent6" || change.Key == "talent7" ||change.Key == "talent8" || change.Key == "talent9"))
                {
                    continue;
                }

                if (__instance.hasTrait(change.Key))
                {
                    float randomKnightIncrease = UnityEngine.Random.Range(change.Value.Item1, change.Value.Item2);
                    __instance.ChangeKnight(randomKnightIncrease);
                }
            }

            // 年龄和概率条件增加特质的处理
            var knightTraitThresholds = new Dictionary<string, float>
            {
                { "Knight1", 40f },//骑士学徒
                { "Knight2", 50f },//预备骑士+10
                { "Knight3", 50f },//初级骑士+20
                { "Knight4", 65f },//中级骑士+25
                { "Knight5", 70f },//高级骑士+30
                { "Knight6", 100f },//大骑士+60
                { "Knight7", 130f },//骑士学徒
                { "Knight8", 160f },//预备骑士+10
                { "Knight9", 220f },//初级骑士+20
                { "Knight10", 380f },//中级骑士+25
                { "Knight11", 850f },//高级骑士+30
                { "Knight12", 3000f },//大骑士+60
                { "Knight13", 5000f }
            };
            const float talent6Chance = 0.2f;
            foreach (var threshold in knightTraitThresholds)
            {
                if (__instance.hasTrait(threshold.Key) && age > threshold.Value && Randy.randomChance(talent6Chance))
                {
                    __instance.addTrait("blessed", false);
                }
            }

            var grades = new Dictionary<string, float>
            {
                { "Knight1", 10f },
                { "Knight2", 18f },
                { "Knight3", 32f },
                { "Knight4", 53f },
                { "Knight5", 68f },
                { "Knight6", 75f },
                { "Knight7", 120f },
                { "Knight8", 200f },
                { "Knight9", 300f },
                { "Knight10", 500f },
                { "Knight11", 850f },
                { "Knight12", 3000f },
                { "Knight13", 5000f },
            };
            foreach (var grade in grades)
            {
                UpdateKnightBasedOnGrade(__instance, grade.Key, grade.Value);
            }
        }
        private static void UpdateKnightBasedOnGrade(Actor actor, string traitName, float maxKnight)
        {
            if (actor.hasTrait(traitName))
            {
                float currentKnight = actor.GetKnight();
                float newValue = Mathf.Min(maxKnight, currentKnight);
                actor.SetKnight(newValue);
            }
        }
        private static readonly string[] FlairTalentTraits = new[] { "talent1", "talent2", "talent3", "talent4", "talent6", "talent7", "talent8", "talent9","flair1", "flair2", "flair3", "flair4", "flair5", "flair6", "flair7" };
        private static bool HasAnyFlairTalen(Actor actor)
        {
            foreach (var trait in FlairTalentTraits)
            {
                if (actor.hasTrait(trait))
                {
                    return true;
                }
            }
            return false;
        }
    }
}