using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using life;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace WestActions
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        private bool initiated;
        internal static Dictionary<string, UnityEngine.Object> modsResources;

        public static Main instance;
        internal static Harmony harmony;void Awake()
{


    Items.init();
}

         
       

    }
}
