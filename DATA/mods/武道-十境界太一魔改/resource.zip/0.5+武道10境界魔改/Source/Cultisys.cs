using System;
using System.Collections.ObjectModel;
using NeoModLoader.General;

namespace CustomModT001;

public static class Cultisys
{
    public const            int         MaxLevel = 10;
    private static readonly BaseStats[] _level_stats;
    private static readonly float[]     _level_exp_required;

    private static readonly string[] _traits_blacklist =
    {
        "eyepatch", "crippled", "cursed", "tumorInfection", "mushSpores", "plague", "skin_burns"
    };

    private static readonly string[] _statuses_blacklist =
    {
        "cough", "ash_fever"
    };

    static Cultisys()
    {
        _level_stats = new BaseStats[MaxLevel + 1];
        _level_exp_required = new float[MaxLevel];
        for (var i = 0; i <= MaxLevel; i++) _level_stats[i] = new BaseStats();

        _level_exp_required[0] = 50;
        _level_exp_required[1] = 200;
        _level_exp_required[2] = 500;
        _level_exp_required[3] = 1000;
        _level_exp_required[4] = 3000;
        _level_exp_required[5] = 10000;
        _level_exp_required[6] = 50000;
        _level_exp_required[7] = 200000;
        _level_exp_required[8] = 600000;
        _level_exp_required[9] = 2000000;
        LevelExpRequired = new ReadOnlyCollection<float>(_level_exp_required);
        LevelStats = new ReadOnlyCollection<BaseStats>(_level_stats);

        BaseStats stats = _level_stats[0];
        stats[S.mana] = 40;
        stats[Stats.mana_regen.id] = 0.5f;


        stats = _level_stats[1];
        stats[S.mana] = 50;
        stats[Stats.mana_regen.id] = 1;
        stats[S.health] = 200;
        stats[S.damage] = 40;


        stats = _level_stats[2];
        stats[S.mana] = 60;
        stats[Stats.mana_regen.id] = 1;
        stats[S.health] = 400;
        stats[S.damage] = 60;
        stats[S.lifespan] = 25;


        stats = _level_stats[3];
        stats[S.mana] = 100;
        stats[Stats.mana_regen.id] = 2;
        stats[S.health] = 1000;
        stats[S.damage] = 100;
        stats[S.speed] = 40;
        stats[S.lifespan] = 100;


        stats = _level_stats[4];
        stats[S.mana] = 400;
        stats[Stats.mana_regen.id] = 4;
        stats[S.health] = 2000;
        stats[S.damage] = 200;
        stats[S.speed] = 40;
        stats[S.lifespan] = 200;


        stats = _level_stats[5];
        stats[Stats.addition_armor.id] = 15;
        stats[Stats.control_get.id] = -0.5f;
        stats[S.mana] = 2000;
        stats[Stats.mana_regen.id] = 100;
        stats[S.health] = 5000;
        stats[S.damage] = 400;
        stats[S.speed] = 40;
        stats[S.lifespan] = 300;


        stats = _level_stats[6];
        stats[Stats.addition_armor.id] = 25;
        stats[Stats.control_get.id] = -0.8f;
        stats[S.mana] = 4000;
        stats[Stats.mana_regen.id] = 500;
        stats[S.health] = 30000;
        stats[S.damage] = 1000;
        stats[S.speed] = 80;
        stats[S.lifespan] = 500;
        stats[S.knockback_reduction] = 10000;


        stats = _level_stats[7];
        stats[Stats.addition_armor.id] = 35;
        stats[Stats.control_get.id] = -0.8f;
        stats[S.mana] = 50000;
        stats[Stats.mana_regen.id] = 500;
        stats[S.health] = 60000;
        stats[S.damage] = 3000;
        stats[S.speed] = 100;
        stats[S.lifespan] = 1000;
        stats[S.knockback_reduction] = 10000;


        stats = _level_stats[8];
        stats[Stats.addition_armor.id] = 45;
        stats[Stats.control_get.id] = -0.8f;
        stats[S.mana] = 60000;
        stats[Stats.mana_regen.id] = 500;
        stats[S.health] = 90000;
        stats[S.damage] = 9000;
        stats[S.speed] = 100;
        stats[S.lifespan] = 1500;
        stats[S.knockback_reduction] = 10000;


        stats = _level_stats[9];
        stats[Stats.addition_armor.id] = 55;
        stats[Stats.control_get.id] = -0.8f;
        stats[S.mana] = 70000;
        stats[Stats.mana_regen.id] = 500;
        stats[S.health] = 150000;
        stats[S.damage] = 25000;
        stats[S.speed] = 100;
        stats[S.lifespan] = 2000;
        stats[S.knockback_reduction] = 10000;


        stats = _level_stats[10];
        stats[Stats.addition_armor.id] = 85;
        stats[Stats.control_get.id] = -1.8f;
        stats[S.mana] = 100000;
        stats[Stats.mana_regen.id] = 1500;
        stats[S.health] = 5000000;
        stats[S.damage] = 50000;
        stats[S.speed] = 280;
        stats[S.lifespan] = 5000;
        stats[S.knockback_reduction] = 10000;
    }

    public static ReadOnlyCollection<BaseStats> LevelStats       { get; }
    public static ReadOnlyCollection<float>     LevelExpRequired { get; }

    public static ReadOnlyCollection<string> TraitsBlacklist { get; } = new(_traits_blacklist);

    public static ReadOnlyCollection<string> StatusesBlacklist { get; } = new(_statuses_blacklist);

    public static string GetName(int level)
    {
        level = Math.Min(MaxLevel, Math.Max(level, 0));
        return LM.Get($"{ModClass.asset_id_prefix}.wudao.{level}");
    }
}