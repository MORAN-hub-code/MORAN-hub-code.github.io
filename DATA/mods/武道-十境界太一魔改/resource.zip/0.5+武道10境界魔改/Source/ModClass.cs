﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using NeoModLoader.api;
using NeoModLoader.General;
using NeoModLoader.General.UI.Tab;
using NeoModLoader.ui;
using UnityEngine;
using UnityEngine.UI;

namespace CustomModT001;

public class ModClass : BasicMod<ModClass>, IReloadable
{
    internal const string asset_id_prefix = "inmny.custommodt001";
    internal const string trait_group_id  = $"{asset_id_prefix}.group";

    public void Reload()
    {
    }

    protected override void OnModLoad()
    {
        AssetManager.trait_groups.add(new ActorTraitGroupAsset
        {
            id = trait_group_id,
            name = trait_group_id,
            color = Toolbox.colorToHex(Color.yellow)
        });
        new ActorTasks().Init();
        new ActorJobs().Init();
        new MapIcons().Init();
        new Terraforms().Init();
        new Stats().Init();
        new Statuses().Init();
        new Traits().Init();
        new Actors().Init();
        new Tooltips().Init();
        new TraitPairs().Init();
        try
        {
            Harmony.CreateAndPatchAll(typeof(Patches), asset_id_prefix);
        }
        catch (Exception e)
        {
            do
            {
                Debug.LogError(e);
                e = e.InnerException;
            } while (e != null);
        }

        ScrollWindow intro_window =
            WindowCreator.CreateEmptyWindow($"{asset_id_prefix}.intro", $"{asset_id_prefix}.ui.intro");
        intro_window.scrollRect.gameObject.SetActive(true);

        var content_transform =
            intro_window.scrollRect.transform.Find("Viewport/Content").GetComponent<RectTransform>();
        content_transform.pivot = new Vector2(0.5f,    1);
        content_transform.sizeDelta = new Vector2(180, 0);
        var layout_group = content_transform.gameObject.AddComponent<VerticalLayoutGroup>();
        layout_group.childControlHeight = false;
        layout_group.childControlWidth = false;
        layout_group.childAlignment = TextAnchor.UpperCenter;
        layout_group.childScaleHeight = false;
        layout_group.childScaleWidth = false;
        content_transform.gameObject.AddComponent<ContentSizeFitter>().verticalFit =
            ContentSizeFitter.FitMode.PreferredSize;
        var intro = new GameObject("IntroText", typeof(RectTransform), typeof(Text), typeof(ContentSizeFitter));
        var intro_rect = intro.GetComponent<RectTransform>();
        intro_rect.SetParent(content_transform);
        intro_rect.localPosition = new Vector3(0, 0);
        intro_rect.localScale = new Vector3(1,    1);
        intro_rect.pivot = new Vector2(0.5f,    1);
        intro_rect.sizeDelta = new Vector2(180, 0);
        var fitter = intro.GetComponent<ContentSizeFitter>();
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        var intro_text = intro.GetComponent<Text>();
        intro_text.font = LocalizedTextManager.current_font;
        intro_text.fontSize = 10;
        intro_text.text = @"
功能:
    1. 世界排行榜(嵌在收藏夹中)
    2. 境界查看(人物界面鼠标悬停于头像)
    3. 关闭城市投降(模组列表->模组设置)
设定:
    1. 天赋: 数值与境界提升速度成正比
    2. 额外免伤: 累乘作用于所有非真实 伤害
    3. 蓝量: 用于释放技能
    4. 蓝量恢复: 每10秒恢复量
    5. 吸血: 按造成最终伤害回复生命
    6. 境界: 依次为凡人, 入品, 后天, 先天, 至臻, 超凡, 镇神
";

        ScrollWindow.showWindow(intro_window.screen_id);
        var tab = TabManager.CreateTab(asset_id_prefix, asset_id_prefix, "",
            SpriteTextureLoader.getSprite("inmny/custommodt001/cultilevel"));
        tab.SetLayout(new List<string>()
        {
            "tab"
        });
        
        tab.AddPowerButton("tab", PowerButtonCreator.CreateSimpleButton($"{asset_id_prefix}.config", () =>
        {
            ModConfigureWindow.ShowWindow(GetConfig());
        }, SpriteTextureLoader.getSprite("ui/icons/iconOptions")));
        tab.AddPowerButton("tab", PowerButtonCreator.CreateSimpleButton($"{asset_id_prefix}.top", ()=>
        {
            Patches.window_favorites_global_mode = true;
            ScrollWindow.showWindow("favorites");
        }, SpriteTextureLoader.getSprite("ui/icons/iconCommunity")));
            
        tab.UpdateLayout();
    }

    private void Update()
    {
        EventManager.ProcessDamageEvents();
    }
}