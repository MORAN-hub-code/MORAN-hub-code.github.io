namespace CustomModT001;

public static class ModConfigHelper
{
    public static bool WarRuleCitySurrender;
    public static float TalentMultiplier;
    public static float KillExpK;

    public static float GetKillExpK()
    {
        return KillExpK;
    }

    public static void SetKillExpK(float value)
    {
        KillExpK = value;
    }
    public static bool AllowWarRuleCitySurrender()
    {
        return WarRuleCitySurrender;
    }

    public static float GetTalentMultiplier()
    {
        return TalentMultiplier;
    }

    public static void SetTalentMultiplier(float value)
    {
        TalentMultiplier = value;
    }
    public static void SwitchWarRuleCitySurrender(bool value)
    {
        WarRuleCitySurrender = value;
    }
}