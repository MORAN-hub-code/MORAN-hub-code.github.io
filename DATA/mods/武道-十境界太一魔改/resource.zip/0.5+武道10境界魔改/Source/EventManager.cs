using System.Collections.Generic;

namespace CustomModT001;

public static class EventManager
{
    struct DamageEvent
    {
        public BaseSimObject attacker;
        public BaseSimObject target;
        public float damage;
        public AttackType type;
    }
    private static Queue<DamageEvent> damageEvents = new Queue<DamageEvent>();
    private static float totalDamage = 0;
    private static int damageEventInQueue = 0;
    public static void ProcessDamageEvents()
    {
        totalDamage = 0;
        
        var count = damageEvents.Count;
        damageEventInQueue = 0;
        while (count-- > 0)
        {
            DamageEvent ev = damageEvents.Dequeue();
            if (ev.target == null || !ev.target.isAlive()) continue;
            
            ev.target.getHit(ev.damage, true, ev.type, ev.attacker, false);
        }
    }
    public static void EnqueueDamageEvent(BaseSimObject attacker, BaseSimObject target, float damage, AttackType type)
    {
        if (target == null || !target.isAlive()) return;
        if (damageEventInQueue > 0)
        {
            var mean_damage = totalDamage / damageEventInQueue;
            if (Randy.randomChance(1 - damage / mean_damage))
            {
                return;
            }
        }
        
        damageEvents.Enqueue(new DamageEvent()
        {
            attacker = attacker,
            target = target,
            damage = damage,
            type = type
        });
        totalDamage += damage;
        damageEventInQueue++;
    }
}