using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;
using Newtonsoft.Json;
using System;
using NCMS;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using System.Threading.Tasks;
using static Config;
using System.Reflection.Emit;
using UnityEngine.Tilemaps;
using UnityEngine.Purchasing.MiniJSON;
using System.Collections;
using System.Text.RegularExpressions;
using System.Runtime.CompilerServices;
using UnityEngine.CrashReportHandler;
using System.IO.Compression;
using System.Threading;
using System.Text;
using Beebyte.Obfuscator;
using ai;
using ai.behaviours;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using System.Runtime.InteropServices;
using UnityEngine.EventSystems;
using WorldBoxConsole;
using UnityEngine.UI;
using SHToolkit.helps;

namespace SHToolkit
{
    [JsonObject(MemberSerialization.OptIn)]
    public class SHToolkitSet
    {
      [JsonProperty]
      public string Name = "NewSet";
      [JsonProperty]
      public bool Set = true;
    }
    [JsonObject(MemberSerialization.OptIn)]
    public class SHToolkitStorage
    {
      [JsonProperty]
      public string Name = "NewStorage";
      [JsonProperty]
      public sbyte nsm = 0;
      [JsonProperty]
      public byte nbm = 0;
      [JsonProperty]
      public short nhm = 0;
      [JsonProperty]
      public ushort nru = 0;
      [JsonProperty]
      public int num = 0;
      [JsonProperty]
      public uint niu = 0U;
      [JsonProperty]
      public long nlm = 0L;
      [JsonProperty]
      public ulong nmu = 0UL;
      [JsonProperty]
      public float nom = 0f;
      [JsonProperty]
      public double ndm = 0;
      [JsonProperty]
      public decimal nem = 0m;
    }
    [JsonObject(MemberSerialization.OptIn)]
    public class SHToolkitSave
    {
      [JsonProperty]
      public float version = 0f;
      [JsonProperty]
      public List<string> spawn_units = new List<string>();
      [JsonProperty]
      public float spawn_unit_interval = 24f;
      [JsonProperty]
      public float spawn_unit_interval_random = 30f;
      [JsonProperty]
      public float spawn_units_chance = 0.6f;
      [JsonProperty]
      public int spawn_units_check = 4;
      [JsonProperty]
      public int spawn_units_min = 2;
      [JsonProperty]
      public int spawn_units_max = 5;
      [JsonProperty]
      public int MultipleNum = 10;
      [JsonProperty]
      public int MapSize = 50;
      [JsonProperty]
      public float auto_save_interval = 300f;
      [JsonProperty]
      public float SHUI_pX = 0.6f;
    }
    [JsonObject(MemberSerialization.OptIn)]
    public class SHToolkitLocalizedSave
    {
      [JsonProperty]
      public string id = "cz";
      [JsonProperty]
      public string text = "null";
      [JsonProperty]
      public float version = 0f;
      [JsonProperty]
      public List<SHToolkitLocalizedsSave> list = new List<SHToolkitLocalizedsSave>();
      [JsonProperty]
      public Dictionary<string, string> dict = new Dictionary<string, string>();
    }
    public class SHToolkitLocalizedsSave
    {
      [JsonProperty]
      public string id = "null";
      [JsonProperty]
      public string text = "null";
      [JsonProperty]
      public Dictionary<string, int> dict = new Dictionary<string, int>();
    }
}