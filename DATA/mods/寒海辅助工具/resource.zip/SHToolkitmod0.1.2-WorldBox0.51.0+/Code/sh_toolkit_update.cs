using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.api;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.Collections.Concurrent;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_update
    {
        public static void update_texts()
        {
          foreach (string id in sh_toolkit_ui.CustomTexts.Keys)
          {
            Text text = sh_toolkit_ui.CustomTexts[id];
            if (text != null)
            {
              string text2 = sh_toolkit_ui.CustomText[id];
              if (sh_toolkit_ui.LocalizedTextIds.Contains(id))
              {
                text2 = LocalizedTextManager.getText(text2);
              }
              if (sh_toolkit_ui.CustomTextSizes.TryGetValue(id, out float size))
              {
                text2 = $"<size={size}>{text2}</size>";
              }
              if (sh_toolkit_ui.CustomTextColors.TryGetValue(id, out string color))
              {
                text2 = $"<color={color}>{text2}</color>";
              }
              text.text = text2;
              if (sh_toolkit_ui.CustomInputs.TryGetValue(id, out InputField input))
              {
                input.text = text2;
              }
            }
          }
        }
    }
}
