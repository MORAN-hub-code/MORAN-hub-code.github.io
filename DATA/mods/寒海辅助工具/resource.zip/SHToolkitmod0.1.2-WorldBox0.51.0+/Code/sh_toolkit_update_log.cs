using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NCMS.Utils;
using SHToolkit.helps;
using ReflectionUtility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace SHToolkit
{
    class sh_toolkit_update_log
    {
        public static string wid = "Window_SHToolkitUpdatelog";
        public static int w_count = 2;
        public static void init()
        {
          for (int i = 1; i < w_count + 1; i++)
          {
            int next = i + 1;
            string id = wid + i;
            ScrollWindow window = sh_toolkit_ui.NewWindow(id, "Updatelog", 0, "SHToolkitUpdatelog" + i, true);
            if (i != w_count)
            {
              PowerButton pButton = PowerButtons.CreateButton($"SHToolkitUpdatelog{next}", Resources.Load<Sprite>("ui/nextpage"), null, null, new Vector2(130f, 82f), ButtonType.Click, window.transform, () => Windows.ShowWindow(wid + next));
              pButton._button.image.sprite = Resources.Load<Sprite>("ui/sh_toolkit_right_button");
            }
            id.RTF();
          }
        }
    }
}
