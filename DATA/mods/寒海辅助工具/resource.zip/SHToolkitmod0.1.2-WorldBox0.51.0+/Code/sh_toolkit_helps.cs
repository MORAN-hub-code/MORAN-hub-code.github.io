using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;
using UnityEngine.Purchasing.MiniJSON;
using ai;
using EpPathFinding.cs;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using SHToolkit.helps;

namespace SHToolkit.helps
{
    public static class sh_toolkit_helps
    {
	    public static bool Any(this Actor a)
        {
		  return a != null && a.isAlive();
		}
		public static bool hasData(this Kingdom k)
		{
		  return k != null && k.data != null;
		}
		public static bool hasData(this City c)
		{
		  return c != null && c.data != null;
		}
        public static long getId(this Kingdom k)
        {
		  if (k.hasData())
		  {
		    return k.getID();
		  }
          return -1L;
        }
        public static long getId(this City c)
        {
		  if (c.hasData())
		  {
			return c.getID();
		  }
          return -1L;
        }
        public static int RoundUpToMultipleOf(this int num1, int mod)
        {
          if (mod == 0)
          {
            return num1;
          }
          int num2 = num1 % mod;
          return num2 == 0 ? num1 : num1 + (mod - num2);
        }
		public static bool IsError(this float num)
		{
		  return float.IsInfinity(num) || float.IsPositiveInfinity(num) || float.IsNegativeInfinity(num) || float.IsNaN(num) || !float.IsFinite(num);
		}
        public static void SetHeight(this string id, float height)
        {
		  if (sh_toolkit_ui.CustomWindowsHeight.ContainsKey(id))
		  {
		    sh_toolkit_ui.CustomWindowsHeight[id] = height;
		  }
		}
        public static void AddHeight(this string id, float height)
        {
		  if (sh_toolkit_ui.CustomWindowsHeight.ContainsKey(id))
		  {
			sh_toolkit_ui.CustomWindowsHeight[id] += height;
		  }
		}
        public static void FindNeighbours(this PowersTab tab)
        {
		  tab._power_buttons.Clear();
		  foreach (PowerButton button in tab.GetComponentsInChildren<PowerButton>())
		  {
			if (button != null && button.rect_transform != null && button.gameObject.active && button.gameObject.name != "tab_back_button")
			{
			  tab._power_buttons.Add(button);
			}
		  }
		  foreach (PowerButton button1 in tab._power_buttons)
		  {
			button1.left = null;
			button1.right = null;
			button1.down = null;
			button1.up = null;
			button1.findNeighbours(tab._power_buttons);
		  }
		}
		public static List<string> ToList(this string id, int num)
		{
          List<string> list = new List<string>();
          for (int i = 0; i < num; i++)
          {
            list.Add(id);
          }
          return list;
		}
        public static void RTF(this string id)
        {
		  if (sh_toolkit_ui.CustomWindows.ContainsKey(id))
		  {
			float pHeight = sh_toolkit_ui.CustomWindowsHeight[id];
			if (sh_toolkit_ui.CustomTextWindowIds.Contains(id))
			{
			  pHeight = sh_toolkit_ui.CustomWindowTexts[id].preferredHeight;
			}
			GameObject contentComponent = sh_toolkit_ui.CustomWindowObjects[id];
            GameObject Content = GameObject.Find($"/Canvas Container Main/Canvas - Windows/windows/{id}/Background/Scroll View/Viewport/Content");
            RectTransform rect = contentComponent.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 1f);
            rect.anchorMax = new Vector2(0.5f, 1f);
            rect.offsetMin = new Vector2(-90f, pHeight * -1f);
            rect.offsetMax = new Vector2(90f, -17f);
            rect.sizeDelta = new Vector2(180f, pHeight + 50f);
            Content.GetComponent<RectTransform>().sizeDelta = new Vector2(0f, pHeight + 50f);
            contentComponent.transform.localPosition = new Vector2(contentComponent.transform.localPosition.x, ((pHeight * 0.5f) + 30f) * -1f);
		  }
		}
        public static string ToFile(this string text)
        {
		  return Path.Combine(Main.SHToolkitFolder, text);
        }
        public static SHToolkitSet NewSetJson(this string text, string id, bool set)
        {
          SHToolkitSet News = new SHToolkitSet();
          News.Name = id;
          News.Set = set;
          File.WriteAllText(text, JsonConvert.SerializeObject(News, Formatting.Indented));
		  return News;
        }
        public static bool toSet(this string text, bool mr = false)
        {
          SHToolkitSet pSet = JsonConvert.DeserializeObject<SHToolkitSet>(File.ReadAllText(text));
          if (pSet != null)
		  {
			return pSet.Set;
		  }
		  return mr;
        }
    }
}