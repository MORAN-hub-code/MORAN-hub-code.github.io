using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using NeoModLoader.General;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_ui
    {
        public static List<string> LocalizedTextIds = new List<string>();
        public static List<string> CustomTextWindowIds = new List<string>();
        public static List<PowerButton> LJButtons = new List<PowerButton>();
        public static Dictionary<GameObject, string> CustomTips = new Dictionary<GameObject, string>();
        public static Dictionary<string, InputField> CustomInputs = new Dictionary<string, InputField>();
        public static Dictionary<string, float> CustomTextSizes = new Dictionary<string, float>();
        public static Dictionary<string, string> CustomText = new Dictionary<string, string>();
        public static Dictionary<string, Text> CustomTexts = new Dictionary<string, Text>();
        public static Dictionary<string, string> CustomTextColors = new Dictionary<string, string>();
        public static Dictionary<string, float> CustomWindowsHeight = new Dictionary<string, float>();
        public static Dictionary<string, Text> CustomWindowTexts = new Dictionary<string, Text>();
        public static Dictionary<string, ScrollWindow> CustomWindows = new Dictionary<string, ScrollWindow>();
        public static Dictionary<string, GameObject> CustomTextObjects = new Dictionary<string, GameObject>();
        public static Dictionary<string, GameObject> CustomWindowObjects = new Dictionary<string, GameObject>();
		    public static Dictionary<string, Button> CustomButtons = new Dictionary<string, Button>();
        public static Dictionary<string, Vector3> SizeButtons = new Dictionary<string, Vector3>();
		    public static Dictionary<string, GameObject> CustomToggleObjs = new Dictionary<string, GameObject>();
		    public static Dictionary<string, ToggleIcon> CustomToggle = new Dictionary<string, ToggleIcon>();
        public static Dictionary<string, GameObject> CustomIcons = new Dictionary<string, GameObject>();
        public static Transform General = GameObject.Find("Canvas - UI/General").transform;
        public static GameObject TemplateButton = NCMS.Utils.GameObjects.FindEvenInactive("Button_Other");
        public static GameObject ToolkitIcon = null;
        public static Button toolkit_close = null;
        public static Button toolkit_open = null;
        public static Button toolkit_modder = null;
        public static Button toolkit_updatelog = null;
        public static Button ToolkitTabButton = null;
        public static Button ToolkitWindowButton = null;
        public static PowersTab SHToolkitTab = null;
        public static float SHUI_pX = 0.6f;
        public static float SHUI_x = 0f;
        public static float SHUI_y = 0f;
        public static void action_0(){}
        public static void init()
        {
          open_buttons();
          init_other();
        }
        public static void init_other()
        {
          bool line = false;
          GameObject TemplateTab = PowerButtonCreator.GetTab("other").gameObject;
          GameObject pObj = GameObject.Instantiate(TemplateTab);
          pObj.transform.SetParent(TemplateTab.transform.parent);
          pObj.name = "sh_toolkit";
          SHToolkitTab = pObj.GetComponent<PowersTab>();
          foreach (Transform child in pObj.transform)
          {
            GameObject obj = child.gameObject;
            bool flag1 = obj.name != "tab_back_button";
            bool flag2 = obj.name != "pause";
            bool flag3 = obj.name != "clock";
            if (flag1 && flag2 && flag3)
            {
              if (line || obj.name != "_line")
              {
                GameObject.Destroy(obj);
              }
              else
              {
                line = true;
              }
            }
            else
            {
              RectTransform rect = obj.GetComponent<RectTransform>();
					    SHToolkitTab.prepareButtonPosition(rect);
              if (!flag1)
              {
                obj.transform.localPosition = new Vector3(20f, 34f);
              }
              if (!flag2)
              {
                obj.transform.localPosition = new Vector3(56f, 34f);
              }
              if (!flag3)
              {
                obj.transform.localPosition = new Vector3(56f, -2f);
              }
					    SHToolkitTab.restoreButtonPosition(rect);
            }
          }
          SHToolkitTab.parentObj = TemplateTab.transform.parent.parent.gameObject;
          SHToolkitTab.powerButton = ToolkitTabButton;
          SHToolkitTab._children = SHToolkitTab.transform.CountChildren((Transform pChild) => pChild.gameObject.activeSelf && !pChild.name.StartsWith("ButtonSelection"));
          SHToolkitTab._asset = new PowerTabAsset{id = "sh_toolkit", locale_key = "tab_sh_toolkit", tab_type_main = true};
          AssetManager.power_tab_library.add(SHToolkitTab._asset);
          pObj.SetActive(true);
        }
        public static void open_buttons()
        {
          float num1 = CanvasMain.instance.scaler_main_ui.referenceResolution.y;
          float num2 = num1 * Screen.width / 1440f / Screen.height * 838f;
          SHUI_x = num2 * SHUI_pX;
          SHUI_y = num1 * 0.5f;
          destroy_buttons();
          ToolkitIcon = new GameObject("ToolkitIcon");
          RectTransform ToolkitRTF = ToolkitIcon.AddComponent<RectTransform>();
          ToolkitIcon.AddComponent<CanvasRenderer>();
          ToolkitIcon.AddComponent<Image>().sprite = Resources.Load<Sprite>("ui/iconSHToolkitUi2");
          ToolkitIcon.transform.SetParent(General);
          ToolkitIcon.transform.localScale = Vector3.one;
          ToolkitRTF.localPosition = new Vector3(SHUI_x, SHUI_y - 25f);
          ToolkitRTF.sizeDelta = new Vector2(60f, 80f);
          toolkit_close = NewButton("sh_toolkit_close", new Vector3(SHUI_x, SHUI_y - 60f), General, Resources.Load<Sprite>("ui/SHToolkitClose"), Resources.Load<Sprite>("ui/Icons/wu"), close_buttons);
          toolkit_modder = NewButton("sh_toolkit_modder", new Vector3(SHUI_x, SHUI_y - 8f), General, Resources.Load<Sprite>("ui/iconSHToolkitUi"), Resources.Load<Sprite>("ui/Icons/SHToolkitModder"), () => Windows.ShowWindow(sh_toolkit_modder.wid));
          toolkit_updatelog = NewButton("sh_toolkit_updatelog", new Vector3(SHUI_x, SHUI_y - 23f), General, Resources.Load<Sprite>("ui/iconSHToolkitUi"), Resources.Load<Sprite>("ui/Icons/Updatelog"), () => Windows.ShowWindow("Window_SHToolkitUpdatelog1"));
          ToolkitTabButton = NewButton("sh_toolkit_tab_button", new Vector3(SHUI_x, SHUI_y - 38f), General, Resources.Load<Sprite>("ui/iconSHToolkitUi"), Resources.Load<Sprite>("ui/Icons/iconSHToolkitTab"), () => SHToolkitTab.showTab(null));
          ToolkitWindowButton = NewButton("sh_toolkit_window_button", new Vector3(SHUI_x, SHUI_y - 50f), General, Resources.Load<Sprite>("ui/iconSHToolkitUi"), Resources.Load<Sprite>("ui/Icons/iconSHToolkitWindow"), () => Windows.ShowWindow(sh_toolkit_set.wid1));
          Main.langUpdate = true;
        }
        public static void close_buttons()
        {
          float num1 = CanvasMain.instance.scaler_main_ui.referenceResolution.y;
          float num2 = num1 * Screen.width / 1440f / Screen.height * 838f;
          SHUI_x = num2 * SHUI_pX;
          SHUI_y = num1 * 0.5f;
          destroy_buttons();
          toolkit_open = NewButton("sh_toolkit_open", new Vector3(SHUI_x, SHUI_y - 5f), General, Resources.Load<Sprite>("ui/SHToolkitOpen"), Resources.Load<Sprite>("ui/Icons/wu"), open_buttons);
          Main.langUpdate = true;
        }
        public static void destroy_buttons()
        {
          if (ToolkitIcon != null)
          {
            UnityEngine.Object.Destroy(ToolkitIcon);
          }
          if (toolkit_modder != null)
          {
            UnityEngine.Object.Destroy(toolkit_modder.gameObject);
            CustomButtons.Remove("sh_toolkit_modder");
          }
          if (toolkit_updatelog != null)
          {
            UnityEngine.Object.Destroy(toolkit_updatelog.gameObject);
            CustomButtons.Remove("sh_toolkit_updatelog");
          }
          if (ToolkitTabButton != null)
          {
            UnityEngine.Object.Destroy(ToolkitTabButton.gameObject);
            CustomButtons.Remove("sh_toolkit_tab_button");
          }
          if (ToolkitWindowButton != null)
          {
            UnityEngine.Object.Destroy(ToolkitWindowButton.gameObject);
            CustomButtons.Remove("sh_toolkit_window_button");
          }
          if (toolkit_close != null)
          {
            UnityEngine.Object.Destroy(toolkit_close.gameObject);
            CustomButtons.Remove("sh_toolkit_close");
          }
          if (toolkit_open != null)
          {
            UnityEngine.Object.Destroy(toolkit_open.gameObject);
            CustomButtons.Remove("sh_toolkit_open");
          }
        }
        public static ToggleIcon NewToggle(Transform transform, Vector3 pos, string id, bool flag1, bool flag2 = false, float size = 10f)
        {
          GameObject toggleHolder = new GameObject("ToggleIcon");
          toggleHolder.transform.SetParent(transform);
          Image toggleImage = toggleHolder.AddComponent<Image>();
          ToggleIcon icon = toggleHolder.AddComponent<ToggleIcon>();
          icon.spriteON = Resources.Load<Sprite>("ui/SHAUX_ON");
          icon.spriteOFF = Resources.Load<Sprite>("ui/SHAUX_OFF");
          icon.updateIcon(flag1);
          RectTransform toggleRect = toggleHolder.GetComponent<RectTransform>();
          toggleRect.localPosition = pos;
          toggleRect.sizeDelta = new Vector2(size, size);
          if (flag2)
          {
				    Image component = transform.Find("Icon").GetComponent<Image>();
            if (flag1)
            {
              component.color = Toolbox.makeColor("#FFFFFF");
            }
            else
            {
              component.color = Toolbox.makeColor("#666666");
            }
          }
          CustomToggleObjs.Add(id, toggleHolder);
          CustomToggle.Add(id, icon);
          return icon;
        }
		    public static PowerButton NewPowerButton(string name, Sprite sprite, Sprite sprite2, Vector2 position, Vector3 size, Vector3 size2, ButtonType type = ButtonType.Click, Transform parent = null, UnityAction call = null)
		    {
          PowerButton button = PowerButtons.CreateButton(name, sprite, null, null, position, type, parent, call);
          button._initialized = false;
          button.OnEnable();
          if (sprite2 != null)
          {
            button._button.image.sprite = sprite2;
          }
          if (size != Main.None)
          {
            SetButtonSize(name, size, size2);
          }
			    return button;
		    }
        public static PowerButton SetButtonSize(string name, Vector3 size, Vector3 size2, bool set = true)
        {
          PowerButton button = PowerButtons.CustomButtons[name];
          if (button.type != PowerButtonType.Active)
          {
            Vector3 delta = button.rect_transform.sizeDelta;
				    button.rect_transform.sizeDelta = new Vector2(delta.x / button._default_scale.x * size.x, delta.y / button._default_scale.y * size.y);
          }
          if (set)
          {
            SizeButtons[name] = size;
          }
				  button.transform.localScale = size;
          button._default_scale = size;
          button._clicked_scale = size * 0.9f;
				  button.icon.transform.localScale = size2;
          return button;
        }
        public static Button NewButton(string id, Vector3 pos, Transform parent = null, Sprite sprite1 = null, Sprite sprite2 = null, UnityAction call = null)
        {
          GameObject pObj = GameObject.Instantiate(TemplateButton);
          pObj.name = id;
          if (parent != null)
          {
            pObj.transform.SetParent(parent);
          }
          else
          {
            pObj.transform.SetParent(TemplateButton.transform.parent);
          }
          pObj.transform.localPosition = pos;
          if (sprite1 != null)
          {
            pObj.GetComponent<Image>().sprite = sprite1;
          }
          if (sprite2 != null)
          {
            pObj.transform.Find("Icon").GetComponent<Image>().sprite = sprite2;
          }
          Button pB = pObj.GetComponent<Button>();
          if (call == null)
          {
            call = action_0;
          }
          pB.onClick = new Button.ButtonClickedEvent();
          pB.onClick.AddListener(call);
          TipButton pTip = pB.gameObject.GetComponent<TipButton>();
          pTip.textOnClick = id;
          pTip.textOnClickDescription = id + "_description";
          pTip.text_description_2 = id + "_description2";
          pB.gameObject.SetActive(true);
          CustomButtons.Add(id, pB);
          return pB;
        }
        public static ScrollWindow NewWindow(string id, string path, float height = 0f, string text = "null", bool textHeight = false)
        {
          CustomWindowsHeight.Add(id, height);
          ScrollWindow window = WindowCreator.CreateEmptyWindow(id, id, path);
          window._asset = AssetManager.window_library.get(id);
          window.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);
          GameObject contentComponent = window.transform.Find("Background").Find("Name").gameObject;
          Text contentText = contentComponent.GetComponent<Text>();
          string text2 = "";
          if (text != "null")
          {
            CustomTextObjects.Add(id, contentComponent);
            CustomTexts.Add(id, contentText);
            CustomText.Add(id, text);
            LocalizedTextIds.Add(id);
		        if (LocalizedTextManager.instance._localized_text.ContainsKey(text))
            {
              text2 = LocalizedTextManager.getText(text);
            }
          }
          contentText.text = text2;
          contentText.supportRichText = true;
          Transform pContent = window.transform.Find("Background").Find("Scroll View").Find("Viewport").Find("Content");
          if (textHeight)
          {
            contentText.transform.SetParent(pContent);
            CustomTextWindowIds.Add(id);
          }
          else
          {
            contentComponent.transform.SetParent(pContent);
          }
          contentComponent.SetActive(true);
          CustomWindows.Add(id, window);
          CustomWindowTexts.Add(id, contentText);
          CustomWindowObjects.Add(id, contentComponent);
          id.RTF();
          return window;
        }
        public static InputField NewInput(string id, Vector3 position, Vector3 size, UnityAction<string> action = null)
        {
          Text text = CustomTexts[id];
          GameObject obj = new GameObject(id, typeof(Text), typeof(InputField));
          obj.transform.SetParent(text.transform);
          obj.transform.localPosition = position;
          obj.transform.localScale = Vector3.one;
          obj.GetComponent<RectTransform>().sizeDelta = size;
          InputField input = obj.GetComponent<InputField>();
          input.textComponent = text;
          input.text = text.text;
          if (action != null)
          {
            input.onEndEdit = new InputField.EndEditEvent();
            input.onEndEdit.AddListener(action);
          }
          CustomInputs.Add(id, input);
          return input;
        }
        public static Text NewText(string id, string text, string color, bool localized, Transform parentr, Vector3 position, Vector3 size, float scale = -1f, GameObject MObj = null)
        {
          if (MObj == null)
          {
            GameObject MRef = GameObject.Find($"/Canvas Container Main/Canvas - Windows/windows/SHToolkitHelper/Background/Name");
            MObj = GameObject.Instantiate(MRef, parentr);
          }
          MObj.SetActive(true);
          Text MText = MObj.GetComponent<Text>();
          CustomText.Add(id, text);
          if (localized)
          {
		        if (LocalizedTextManager.instance._localized_text.ContainsKey(text))
            {
              text = LocalizedTextManager.getText(text);
            }
            LocalizedTextIds.Add(id);
            Main.langUpdate = true;
          }
          if (scale != -1f)
          {
            text = $"<size={scale}>{text}</size>";
            CustomTextSizes.Add(id , scale);
          }
          if (!string.IsNullOrEmpty(color))
          {
            text = $"<color={color}>{text}</color>";
            CustomTextColors.Add(id, color);
          }
          MText.text = text;
          MText.raycastTarget = false;
          MText.supportRichText = true;
          MText.transform.SetParent(parentr);
          RectTransform MObjRTF = MObj.GetComponent<RectTransform>();
          if (size != Main.None)
          {
            MObjRTF.sizeDelta = size;
          }
          MObjRTF.position = new Vector3(0f, 0f, 0f);
          MObjRTF.localPosition = position;
          CustomTextObjects.Add(id, MObj);
          CustomTexts.Add(id, MText);
          return MText;
        }
        public static GameObject NewIcon(string id, string icon, Transform parentr, Vector3 position, Vector3 size)
        {
          GameObject Icon = new GameObject(id);
          RectTransform IconRTF = Icon.AddComponent<RectTransform>();
          Icon.AddComponent<CanvasRenderer>();
          Icon.AddComponent<Image>().sprite = Resources.Load<Sprite>(icon);
          Icon.transform.SetParent(parentr);
          Icon.transform.localScale = Vector3.one;
          IconRTF.localPosition = position;
          IconRTF.sizeDelta = size;
          CustomIcons.Add(id, Icon);
          return Icon;
        }
    }
}