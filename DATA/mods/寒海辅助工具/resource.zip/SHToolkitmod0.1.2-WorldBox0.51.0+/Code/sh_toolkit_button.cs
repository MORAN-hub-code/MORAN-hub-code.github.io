using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using NeoModLoader.General;
using SHToolkit.helps;

namespace SHToolkit
{
    public static class sh_toolkit_button
    {
        public static int Buttons = 0;
        public static WorldTimeScaleAsset time = new WorldTimeScaleAsset{id = "toolkit_time", locale_key = "speed_x1", multiplier = 1f, ticks = 1, conway_ticks = 1, path_icon = "ui/Icons/wu"};
        public static PowerActionWithID PWspawnUnit = delegate(WorldTile pTile, string pPower)
        {
		      WorldTile mouseTilePos = World.world.getMouseTilePos();
		      if (mouseTilePos != null)
          {
		        for (int i = 0; i < Config.current_brush_data.pos.Length; i++)
		        {
		          BrushPixelData brushPixelData = Config.current_brush_data.pos[i];
		        	WorldTile tile = World.world.GetTile(brushPixelData.x + mouseTilePos.x, brushPixelData.y + mouseTilePos.y);
		        	if (tile != null)
		        	{
                AssetManager.powers.spawnUnit(tile, pPower);
		          }
	        	}
          }
          return true;
        };
        public static PowerActionWithID PWspawnDrops = new PowerActionWithID((WorldTile pTile, string pPower) => PspawnDrops(pTile, AssetManager.powers.get(pPower)));
        public static PowerActionWithID PWloopWithCurrentBrushPower = new PowerActionWithID((WorldTile pTile, string pPower) => PloopWithCurrentBrushPower(pTile, AssetManager.powers.get(pPower)));
        public static PowerActionWithID PWfalse = new PowerActionWithID((WorldTile pTile, string pPower) => true);
        public static PowerAction PspawnUnit = new PowerAction((WorldTile pTile, GodPower pPower) => PWspawnUnit(pTile, pPower.id));
        public static PowerAction PspawnDrops = new PowerAction((WorldTile pTile, GodPower pPower) => AssetManager.powers.spawnDrops(pTile, pPower));
        public static PowerAction PloopWithCurrentBrushPower = new PowerAction((WorldTile pTile, GodPower pPower) => AssetManager.powers.loopWithCurrentBrushPowerForDropsFull(pTile, pPower));
        public static PowerAction Pfalse = new PowerAction((WorldTile pTile, GodPower pPower) => true);
        public static Dictionary<char, Sprite> NumSprites = new Dictionary<char, Sprite>(){{'x', Resources.Load<Sprite>("ui/Icons/toolkit_time_x")}, {'0', Resources.Load<Sprite>("ui/Icons/toolkit_time_0")}, {'1', Resources.Load<Sprite>("ui/Icons/toolkit_time_1")}, {'2', Resources.Load<Sprite>("ui/Icons/toolkit_time_2")}, {'3', Resources.Load<Sprite>("ui/Icons/toolkit_time_3")}, {'4', Resources.Load<Sprite>("ui/Icons/toolkit_time_4")}, {'5', Resources.Load<Sprite>("ui/Icons/toolkit_time_5")}, {'6', Resources.Load<Sprite>("ui/Icons/toolkit_time_6")}, {'7', Resources.Load<Sprite>("ui/Icons/toolkit_time_7")}, {'8', Resources.Load<Sprite>("ui/Icons/toolkit_time_8")}, {'9', Resources.Load<Sprite>("ui/Icons/toolkit_time_9")}, {'.', Resources.Load<Sprite>("ui/Icons/toolkit_time_dot")}, {'E', Resources.Load<Sprite>("ui/Icons/toolkit_time_exponent")}, {'-', Resources.Load<Sprite>("ui/Icons/toolkit_time_minus")}, {'+', Resources.Load<Sprite>("ui/Icons/toolkit_time_plus")}};
        public static Sprite SpeedIcon = Main.wu;
        public static void init()
        {
          NewBT("SH_Minus1Speed", "ui/Icons/Minus1Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier - 1f);
            }
          });
          NewBT("SH_Plus1Speed", "ui/Icons/Plus1Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier + 1f);
            }
          });
          NewBT("SH_Minus10Speed", "ui/Icons/Minus10Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier - 10f);
            }
          });
          NewBT("SH_Plus10Speed", "ui/Icons/Plus10Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier + 10f);
            }
          });
          NewBT("SH_Minus100Speed", "ui/Icons/Minus100Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier - 100f);
            }
          });
          NewBT("SH_Plus100Speed", "ui/Icons/Plus100Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier + 100f);
            }
          });
          NewBT("SH_Minus1000Speed", "ui/Icons/Minus1000Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier - 1000f);
            }
          });
          NewBT("SH_Plus1000Speed", "ui/Icons/Plus1000Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier + 1000f);
            }
          });
          NewBT("SH_Divide1Speed", "ui/Icons/Divide1Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier / 10f);
            }
          });
          NewBT("SH_Multiply10Speed", "ui/Icons/Multiply10Speed", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 118, null, "?", 0f, false, delegate
          {
            if (Config.time_scale_asset != null)
            {
              SetSpeed(Config.time_scale_asset.multiplier * 10f);
            }
          });
          sh_toolkit_ui.CustomTips.Add(sh_toolkit_ui.NewIcon("WorldTickSetTZ", "ui/TextTZ", sh_toolkit_ui.SHToolkitTab.transform, new Vector3(340f, 18f), new Vector3(115f, 30f)).gameObject, "SH_WorldTickSet");
          sh_toolkit_ui.CustomTips.Add(sh_toolkit_ui.NewIcon("ConwayTickSetTZ", "ui/TextTZ", sh_toolkit_ui.SHToolkitTab.transform, new Vector3(340f, -18f), new Vector3(115f, 30f)), "SH_ConwayTickSet");
          sh_toolkit_ui.NewText("WorldTickSet", "SHWorldTickSet", string.Empty, true, sh_toolkit_ui.SHToolkitTab.transform, new Vector3(340f, -2f), new Vector3(100f, 50f));
          sh_toolkit_ui.CustomTips.Add(sh_toolkit_ui.NewInput("WorldTickSet", new Vector3(0f, 21f), new Vector3(115f, 15f), delegate(string text)
          {
            string text2 = "";
            foreach (char sub in text)
            {
              if (char.IsDigit(sub))
              {
                text2 += sub.ToString();
              }
              else
              {
                text2 = "";
                break;
              }
            }
            if (text2 == "")
            {
              Main.showText = LocalizedTextManager.getText("num_error_int");
            }
            else
            {
              int num;
              if (!int.TryParse(text2, out num))
              {
                num = int.MaxValue;
              }
              time.ticks = num;
            }
            Main.langUpdate = true;
          }).gameObject, "SH_WorldTickSet");
          sh_toolkit_ui.NewText("ConwayTickSet", "SHConwayTickSet", string.Empty, true, sh_toolkit_ui.SHToolkitTab.transform, new Vector3(340f, -38f), new Vector3(100f, 50f));
          sh_toolkit_ui.CustomTips.Add(sh_toolkit_ui.NewInput("ConwayTickSet", new Vector3(0f, 21f), new Vector3(115f, 15f), delegate(string text)
          {
            string text2 = "";
            foreach (char sub in text)
            {
              if (char.IsDigit(sub))
              {
                text2 += sub.ToString();
              }
              else
              {
                text2 = "";
                break;
              }
            }
            if (text2 == "")
            {
              Main.showText = LocalizedTextManager.getText("num_error_int");
            }
            else
            {
              int num;
              if (!int.TryParse(text2, out num))
              {
                num = int.MaxValue;
              }
              time.conway_ticks = num;
            }
            Main.langUpdate = true;
          }).gameObject, "SH_ConwayTickSet");
          NewBT("SH_MoveTraitRains", "ui/Icons/MoveTraitRains", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 238, null, "?", 0f, false, () => Windows.ShowWindow(sh_toolkit_drop.wid1))._button.image.sprite = Resources.Load<Sprite>("ui/SHToolkitButton");
          NewBT("SH_SuperPause", "ui/Icons/SuperPauseFalse", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 238, null, "?", 0f, false, delegate
          {
            Main.SuperPause = !Main.SuperPause;
			      World.world._is_paused = Main.SuperPause;
			      Config.paused = Main.SuperPause;
            PowerButton button = PowerButtons.CustomButtons["SH_SuperPause"];
            if (Main.SuperPause)
            {
              button.icon.sprite = Main.SuperPauseTrue;
              button.icon.overrideSprite = Main.SuperPauseTrue;
              Main.showText = LocalizedTextManager.getText("SuperPauseTrue");
            }
            else
            {
              button.icon.sprite = Main.SuperPauseFalse;
              button.icon.overrideSprite = Main.SuperPauseFalse;
              Main.showText = LocalizedTextManager.getText("SuperPauseFalse");
            }
          });
          NewBT("SH_MoveItemRains", "ui/Icons/item_rain_edit", "SpawnO", ButtonType.Click, PWfalse, Pfalse, Pfalse, 238, null, "?", 0f, false, () => Windows.ShowWindow(sh_toolkit_drop.wid2))._button.image.sprite = Resources.Load<Sprite>("ui/SHToolkitButton");
          GodPower SuperLifeEraser = NewBT("SH_SuperLifeEraser", "ui/Icons/SuperLifeEraser", "SpawnK", ButtonType.GodPower, PWfalse, Pfalse, new PowerAction(drawSuperLifeEraser), 238, "event:/SFX/POWERS/LifeEraser", "?", 0f, true, null).godPower;
			    SuperLifeEraser.draw_lines = true;
			    SuperLifeEraser.terraform = true;
			    SuperLifeEraser.type = PowerActionType.PowerDrawTile;
			    SuperLifeEraser.mouse_hold_animation = MouseHoldAnimation.Draw;
			    SuperLifeEraser.rank = PowerRank.Rank0_free;
			    SuperLifeEraser.show_tool_sizes = true;
			    SuperLifeEraser.unselect_when_window = true;
			    SuperLifeEraser.hold_action = true;
			    SuperLifeEraser.click_interval = 0f;
        }
        public static PowerButton NewBT(string id, string icon, string BType, ButtonType BuType, PowerActionWithID PAW, PowerAction PA, PowerAction PA2, int x, string Sound = null, string spawnID = "?", float SF = 3f, bool GodP = false, UnityAction call = null)
        {
          if (GodP && !AssetManager.powers.has(id))
          {
            GodPower New = new GodPower();
            New.id = id;
            New.name = id;
			      New.type = PowerActionType.PowerSpecial;
            AssetManager.powers.add(New);
            if (Sound != null)
            {
              New.sound_drawing = Sound;
            }
            switch (BType)
            {
              case "SpawnA":
              {
                New.show_tool_sizes = true;
                New.show_spawn_effect = true;
                New.actor_asset_id = spawnID;
                New.actor_spawn_height = SF;
                New.click_action = PAW;
                if (AssetManager.actor_library.has(spawnID))
                {
                  New.show_unit_stats_overview = true;
                  New.type = PowerActionType.PowerSpawnActor;
                }
                break;
              }
              case "SpawnD":
              {
                New.drop_id = spawnID;
				        New.cached_drop_asset = AssetManager.drops.get(spawnID);
                New.falling_chance = SF;
                New.show_tool_sizes = true;
                New.hold_action = true;
                New.click_power_brush_action = PA;
                New.click_power_action = PA2;
                New.type = PowerActionType.PowerSpawnDrops;
                break;
              }
              case "SpawnO":
              {
                New.falling_chance = SF;
                if (PA != Pfalse)
                {
                  New.click_power_brush_action = PA;
                }
                if (PA2 != Pfalse)
                {
                  New.click_power_action = PA2;
                }
                if (PAW != PWfalse)
                {
                  New.click_action = PAW;
                }
                break;
              }
              case "SpawnK":
              {
                New.show_tool_sizes = true;
                if (PA != Pfalse)
                {
                  New.click_power_brush_action = PA;
                }
                if (PA2 != Pfalse)
                {
                  New.click_power_action = PA2;
                }
                if (PAW != PWfalse)
                {
                  New.click_action = PAW;
                }
                break;
              }
            }
          }
          Buttons++;
          PowerButton button = PowerButtons.CreateButton(id, Resources.Load<Sprite>(icon), null, null, Buttons % 2 == 0 ? new Vector2(36f * ((Buttons / 2) - 1) + x, 18f) : new Vector2(36f * ((Buttons - 1) / 2) + x, -18f), BuType, sh_toolkit_ui.SHToolkitTab.transform, call);
          if (BuType == ButtonType.Click)
          {
            button.type = PowerButtonType.Options;
          }
          return button;
        }
        public static void SetSpeed(float num)
        {
          if (num <= 0f)
          {
            num = float.Epsilon;
          }
          if (num.IsError())
          {
            num = float.MaxValue;
          }
          time.multiplier = num;
          Config.setWorldSpeed(time, false);
          Main.showText = LocalizedTextManager.getText("changed_worldspeed").Replace("$speed$", num.ToString());
          float num2 = Mathf.Abs(num);
          List<char> numList = new List<char>{'x'};
          foreach (char c in num2 >= 0.001f && num2 < 1000000f ? num.ToString("0.#####") : num.ToString("0.#####E+0"))
          {
            if (NumSprites.ContainsKey(c))
            {
              numList.Add(c);
            }
          }
          if (numList.Any())
          {
            Sprite zero = NumSprites['0'];
            int width = (int)zero.rect.width;
            int height = (int)zero.rect.height * 3;
            Texture2D texture = new Texture2D(width * numList.Count, height, TextureFormat.RGBA32, false);
            Color[] pixels = new Color[texture.width * texture.height];
            for (int i = 0; i < pixels.Length; i++)
            {
              pixels[i] = Color.clear;
            }
            texture.SetPixels(pixels);
            for (int i = 0; i < numList.Count; i++)
            {
              Sprite sprite = NumSprites[numList[i]];
              Rect rect = sprite.rect;
              texture.SetPixels(i * width, 32, (int)rect.width, (int)rect.height, sprite.texture.GetPixels((int)rect.x, (int)rect.y, (int)rect.width, (int)rect.height));
            }
            texture.Apply();
            SpeedIcon = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero, 100f);
          }
          else
          {
            SpeedIcon = Main.wu;
          }
        }
	      public static bool drawSuperLifeEraser(WorldTile pTile, GodPower pPower)
	      {
		      WorldTile mouseTilePos = World.world.getMouseTilePos();
		      if (mouseTilePos != null)
          {
		        for (int i = 0; i < Config.current_brush_data.pos.Length; i++)
		        {
		          BrushPixelData brushPixelData = Config.current_brush_data.pos[i];
		        	WorldTile tile = World.world.GetTile(brushPixelData.x + mouseTilePos.x, brushPixelData.y + mouseTilePos.y);
		        	if (tile != null)
		        	{
		          	World.world.conway_layer.remove(tile);
		          	if (tile.Type.life)
		          	{
			          	MapAction.decreaseTile(tile, false, "destroy_life");
		          	}
		          	tile.doUnits(delegate(Actor actor)
		          	{
			          	if (actor.asset.can_be_killed_by_life_eraser)
			          	{
				          	AchievementLibrary.not_on_my_watch.check(actor);
				          	actor.applyRandomForce(1.5f, 2f);
                  	actor.die(false, AttackType.None, false);
                    if (actor != null && !actor.isAlive())
                    {
			                actor.checkCallbacksOnDeath();
                    }
			          	}
		          	});
		          	HashSet<TornadoEffect> effects = TornadoEffect.getTornadoesFromTile(tile);
		          	if (effects != null) foreach (TornadoEffect effect in effects.ToList())
			        	{
				        	effect.die();
			        	}
		          }
	        	}
          }
		      return true;
	      }
    }
}