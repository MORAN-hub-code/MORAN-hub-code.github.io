using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_save
    {
    	[HarmonyPrefix]
		[HarmonyPatch(typeof(AutoSaveManager), "update")]
	    public static void update()
	    {
		  if (sh_toolkit_set.isOpen("ModifyAutoSaveInterval"))
		  {
			if (AutoSaveManager._time > Main.auto_save_interval)
			{
			  AutoSaveManager.resetAutoSaveTimer();
			}
		  }
		  else if (AutoSaveManager._time > AutoSaveManager._interval)
		  {
			AutoSaveManager.resetAutoSaveTimer();
		  }
		  if (AutoSaveManager.lowMemory && Config.autosaves && sh_toolkit_set.isOpen("ForceAutoSave"))
		  {
			if (AutoSaveManager._time > 0f)
			{
			  AutoSaveManager._time -= Time.deltaTime;
			  return;
			}
			if (ScrollWindow.isWindowActive() || ControllableUnit.isControllingUnit())
			{
			  AutoSaveManager._time += 10f;
			  return;
			}
			AutoSaveManager.autoSave(false, true);
		  }
		}
    	[HarmonyPrefix]
		[HarmonyPatch(typeof(AutoSaveManager), "resetAutoSaveTimer")]
	    public static bool resetAutoSaveTimer()
	    {
		  if (sh_toolkit_set.isOpen("ModifyAutoSaveInterval"))
		  {
			AutoSaveManager._time = Main.auto_save_interval;
			return false;
		  }
		  return true;
		}
    	[HarmonyPostfix]
		[HarmonyPatch(typeof(MapBox), "generateNewMap")]
	    public static void generateNewMap(MapBox __instance)
	    {
		  Main.InLoad = true;
		  if (__instance._initiated) SmoothLoader.add(delegate
          {
        	loadToolkitData();
          }, "Clearing Toolkit", false, 0.001f);
		}
    	[HarmonyPostfix]
		[HarmonyPatch(typeof(SaveManager), "loadData")]
	    public static void loadData(string pPath)
	    {
		  Main.InLoad = true;
		  SmoothLoader.add(delegate
          {
        	loadToolkitData();
          }, "Clearing Toolkit", false, 0.001f);
        }
	    public static void loadToolkitData()
	    {
		  Main.landTile.Clear();
          foreach (WorldTile tile in World.world.tiles_list)
          {
			TileTypeBase type = tile.Type;
			if (type != null && type.layer_type == TileLayerType.Ground && type.biome_asset != null && type.biome_asset.pot_spawn_units_auto)
			{
              Main.landTile.Add(tile);
			}
          }
		  Main.InLoad = false;
		}
    }
}