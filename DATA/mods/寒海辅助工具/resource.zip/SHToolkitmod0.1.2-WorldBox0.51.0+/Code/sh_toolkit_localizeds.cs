using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_localizeds
    {
        public static HashSet<string> prohibitedUnderscore = new HashSet<string>();
        public static void loadLocalizedText()
        {
          string text = Path.Combine(Main.SHToolkitFolder, $"Texts/shsrhh_toolkit_text_{LocalizedTextManager.instance.language}.json");
          if (!File.Exists(text))
          {
            text = Path.Combine(SaveManager.persistentDataPath, $"shsrhhad/toolkit/Texts/shsrhh_toolkit_text_{LocalizedTextManager.instance.language}.json");
          }
          if (!File.Exists(text))
          {
            text = Path.Combine(SaveManager.persistentDataPath, "shsrhhad/toolkit/Texts/shsrhh_toolkit_text_en.json");
          }
          if (File.Exists(text))
          {
            AddToCurrentLocale("SHWorldTick", sh_toolkit_button.time.ticks.ToString());
            AddToCurrentLocale("SHConwayTick", sh_toolkit_button.time.conway_ticks.ToString());
            SHToolkitLocalizedSave pSave = JsonConvert.DeserializeObject<SHToolkitLocalizedSave>(File.ReadAllText(text));
		        if (pSave != null && pSave.dict != null)
            {
              foreach (string key in pSave.dict.Keys)
              {
		    	      AddToCurrentLocale(key, pSave.dict[key]);
              }
              foreach (SHToolkitLocalizedsSave save in pSave.list)
              {
                string pString = "";
                List<string> texts = new List<string>{""};
		            foreach (char sub in save.text)
                {
                  texts.Add(sub.ToString());
                }
                foreach (string str in save.dict.Keys)
                {
                  texts[save.dict[str]] += LocalizedTextManager.getText(str);
                }
                foreach (string str in texts)
                {
                  pString += str;
                }
		    	      AddToCurrentLocale(save.id, pString);
              }
            }
            AddToCurrentLocale($"寒海的辅助工具_{LocalizedTextManager.instance.language}", LocalizedTextManager.getText("SHToolkitName"));
            AddToCurrentLocale($"素和晟睿寒海_{LocalizedTextManager.instance.language}", LocalizedTextManager.getText("SHToolkitAuthor"));
            AddToCurrentLocale($"这个模组集合了一大堆辅助功能_{LocalizedTextManager.instance.language}", LocalizedTextManager.getText("SHToolkitDescription", null));
			      Dictionary<string, string> dictionary = LocalizedTextManager.instance._localized_text;
            foreach (string id in sh_toolkit_ui.CustomWindows.Keys)
            {
              if (Windows.AllWindows.ContainsKey(id))
              {
                string pText = dictionary.TryGetValue(id, out pText) ? pText : "";
                ScrollWindow window = Windows.GetWindow(id);
                if (pText != window.titleText.text)
                {
				          window.titleText.text = pText;
                }
              }
            }
            string GLLeft = LocalizedTextManager.getText("SHToolkitGLLeftButton");
            string GLLeftDescription = LocalizedTextManager.getText("SHToolkitGLLeftButton_description");
            string GLRight = LocalizedTextManager.getText("SHToolkitGLRightButton");
            string GLRightDescription = LocalizedTextManager.getText("SHToolkitGLRightButton_description");
            SetTranslate("CivUnitSCGL", LocalizedTextManager.getText("CivUnitSCGL").Replace("$num$", (Mathf.Round(Main.spawn_units_chance * 10000f) * 0.01f).ToString()), GLLeft, GLLeftDescription, GLRight, GLRightDescription);
            string JGLeft = LocalizedTextManager.getText("SHToolkitJGLeftButton");
            string JGLeftDescription = LocalizedTextManager.getText("SHToolkitJGLeftButton_description");
            string JGRight = LocalizedTextManager.getText("SHToolkitJGRightButton");
            string JGRightDescription = LocalizedTextManager.getText("SHToolkitJGRightButton_description");
            SetTranslate("CivUnitSCJG", LocalizedTextManager.getText("CivUnitSCJG").Replace("$num$", Main.ToTime(Main.spawn_unit_asset.interval)), JGLeft, JGLeftDescription, JGRight, JGRightDescription);
            SetTranslate("CivUnitSJJG", LocalizedTextManager.getText("CivUnitSJJG").Replace("$num$", Main.ToTime(Main.spawn_unit_asset.interval_random)), JGLeft, JGLeftDescription, JGRight, JGRightDescription);
            SetTranslate("SHAutoSaveInterval", LocalizedTextManager.getText("SHAutoSaveInterval").Replace("$num$", Main.ToTime(Main.auto_save_interval)), JGLeft, JGLeftDescription, JGRight, JGRightDescription);
            string SLLeft = LocalizedTextManager.getText("SHToolkitSLLeftButton");
            string SLLeftDescription = LocalizedTextManager.getText("SHToolkitSLLeftButton_description");
            string SLRight = LocalizedTextManager.getText("SHToolkitSLRightButton");
            string SLRightDescription = LocalizedTextManager.getText("SHToolkitSLRightButton_description");
            SetTranslate("CivUnitSCSX", LocalizedTextManager.getText("CivUnitSCSX").Replace("$num$", Main.spawn_units_check.ToString()), SLLeft, SLLeftDescription, SLRight, SLRightDescription);
            SetTranslate("CivUnitSCMax", LocalizedTextManager.getText("CivUnitSCMax").Replace("$num$", Main.spawn_units_max.ToString()), SLLeft, SLLeftDescription, SLRight, SLRightDescription);
            SetTranslate("CivUnitSCMin", LocalizedTextManager.getText("CivUnitSCMin").Replace("$num$", Main.spawn_units_min.ToString()), SLLeft, SLLeftDescription, SLRight, SLRightDescription);
            SetTranslate("MultipleSpawnNum", LocalizedTextManager.getText("MultipleSpawnNum").Replace("$num$", Main.MultipleNum.ToString()), SLLeft, SLLeftDescription, SLRight, SLRightDescription);
            SetTranslate("SHMapSizeNum", LocalizedTextManager.getText("SHMapSizeNum").Replace("$num$", Main.MapSize.ToString()), SLLeft, SLLeftDescription, SLRight, SLRightDescription);
            string ZBText = LocalizedTextManager.getText("SHToolkitZB");
            string ZBLeft = LocalizedTextManager.getText("SHToolkitZBLeftButton");
            string ZBLeftDescription = LocalizedTextManager.getText("SHToolkitZBLeftButton_description");
            string ZBRight = LocalizedTextManager.getText("SHToolkitZBRightButton");
            string ZBRightDescription = LocalizedTextManager.getText("SHToolkitZBRightButton_description");
            SetTranslate("SHUIX", LocalizedTextManager.getText("SHUIX").Replace("$num$", Mathf.Round(sh_toolkit_ui.SHUI_pX * 100f).ToString()), LocalizedTextManager.getText("SHToolkitWZLeftButton"), LocalizedTextManager.getText("SHToolkitWZLeftButton_description"), LocalizedTextManager.getText("SHToolkitWZLeftButton"), LocalizedTextManager.getText("SHToolkitWZLeftButton_description"));
            foreach (string id in sh_toolkit_set.races)
            {
              int num = 0;
              foreach (string pid in Main.spawn_units)
              {
                if (pid == id)
                {
                  num++;
                }
              }
              ActorAsset asset = AssetManager.actor_library.get(id);
              SetTranslate(id + "CreateCivSCBL", ZBText.Replace("$id$", TextTranslate(asset.name_locale)).Replace("$num$", num.ToString()), ZBLeft, ZBLeftDescription, ZBRight, ZBRightDescription);
            }
            string MapSize = LocalizedTextManager.getText("SHMapSize");
            foreach (int size in sh_toolkit_map_size.MapSizeDict.Keys)
            {
              AddToCurrentLocale("map_size_SHSize" + size, MapSize.Replace("$num$", size.ToString()));
            }
            sh_toolkit_update.update_texts();
          }
        }
        public static void SetTranslate(string id, string localName, string localB1, string localB1Description, string localB2, string localB2Description)
		    {
		    	AddToCurrentLocale($"#{id}Text", localName);
		    	AddToCurrentLocale(id + "ZILeftButton", localB1);
		    	AddToCurrentLocale(id + "ZILeftButton" + "_description", localB1Description);
		    	AddToCurrentLocale(id + "ZIRightButton", localB2);
		    	AddToCurrentLocale(id + "ZIRightButton" + "_description", localB2Description);
		    }
        public static string TextTranslate(string id)
        {
          string FYID = id;
			    Dictionary<string, string> dictionary = LocalizedTextManager.instance._localized_text;
          if (!string.IsNullOrEmpty(id))
          {
            if (dictionary.ContainsKey(id))
            {
              FYID = LocalizedTextManager.getText(id);
            }
            else if (dictionary.ContainsKey(id + "s"))
            {
              FYID = LocalizedTextManager.getText(id + "s");
            }
            else if (dictionary.ContainsKey("spawn" + id))
            {
              FYID = LocalizedTextManager.getText("spawn" + id);
            }
            else
            {
              string DYW = id.Substring(0, 1);
              string FYID2 = id.Replace(DYW, DYW.ToUpper());
              if (dictionary.ContainsKey(FYID2))
              {
                FYID = LocalizedTextManager.getText(FYID2);
              }
              else if (dictionary.ContainsKey(FYID2 + "s"))
              {
                FYID = LocalizedTextManager.getText(FYID2 + "s");
              }
              else if (dictionary.ContainsKey("spawn" + FYID2))
              {
                FYID = LocalizedTextManager.getText("spawn" + FYID2);
              }
              else
              {
                string DYW2 = FYID2.Substring(0, 1);
                string FYID3 = FYID2.Replace(DYW2, DYW2.ToLower());
                if (dictionary.ContainsKey(FYID3))
                {
                  FYID = LocalizedTextManager.getText(FYID3);
                }
                else if (dictionary.ContainsKey(FYID3 + "s"))
                {
                  FYID = LocalizedTextManager.getText(FYID3 + "s");
                }
                else if (dictionary.ContainsKey("spawn" + FYID3))
                {
                  FYID = LocalizedTextManager.getText("spawn" + FYID3);
                }
              }
            }
          }
          else
          {
            FYID = "null";
          }
          return FYID;
        }
        public static void AddToCurrentLocale(string key, string value)
        {
          prohibitedUnderscore.Add(key);
          prohibitedUnderscore.Add(key.Replace("_description2", "").Replace("_description", ""));
		    	LM.AddToCurrentLocale(key, value);
        }
    }
}