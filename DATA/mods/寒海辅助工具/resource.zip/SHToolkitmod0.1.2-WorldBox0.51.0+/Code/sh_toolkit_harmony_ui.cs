using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_ui
    {
        [HarmonyPrefix]
		[HarmonyPatch(typeof(PowerButton), "animate")]
	    public static bool animate(PowerButton __instance)
	    {
		  return !sh_toolkit_ui.LJButtons.Contains(__instance);
		}
        [HarmonyPrefix]
		[HarmonyPatch(typeof(PowerButton), "selectPowerTab")]
	    public static bool selectPowerTab(PowerButton __instance, TweenCallback pOnComplete)
	    {
		  if (sh_toolkit_ui.LJButtons.Contains(__instance))
		  {
			if (pOnComplete != null)
			{
			  pOnComplete();
			}
			return false;
		  }
		  return true;
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(PowersTab), "sortButtons")]
	    public static bool sortButtons(PowersTab __instance)
	    {
		  return __instance.gameObject.name != "sh_toolkit";
	    }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(PowerButton), "showTooltip")]
	    public static void showTooltip_PowerButton_Postfix(PowerButton __instance)
	    {
		  if (sh_toolkit_ui.SizeButtons.TryGetValue(__instance.name, out Vector3 size))
		  {
		    __instance.transform.localScale = size * 1.1f;
		    __instance.transform.DOKill(false);
		    __instance.transform.DOScale(size, 0.1f).SetEase(Ease.InBack);
		  }
		}
        [HarmonyPostfix]
        [HarmonyPatch(typeof(PowerButtonSelector), "highlightButton")]
	    public static void highlightButton(PowerButtonSelector __instance, PowerButton pButton)
	    {
		  if (pButton != null && __instance.buttonSelectionSprite != null && sh_toolkit_ui.SizeButtons.TryGetValue(pButton.name, out Vector3 size))
		  {
		    __instance.buttonSelectionSprite.transform.localScale = size;
		  }
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(DragOrderElement), "Start")]
	    public static bool Start_DragOrderElement(DragOrderElement __instance)
	    {
		  if (__instance.main_transform == null)
		  {
			__instance.main_transform = __instance.GetComponent<RectTransform>();
		  }
		  __instance._parent_canvas_sorting_order = __instance.main_transform.gameObject.GetComponentInParent<Canvas>().sortingOrder;
		  __instance._canvas = __instance.main_transform.gameObject.AddComponent<Canvas>();
		  if (__instance._canvas == null)
		  {
			return false;
		  }
		  __instance._canvas.sortingOrder = __instance._parent_canvas_sorting_order;
		  __instance._canvas.overrideSorting = false;
		  __instance._raycaster = __instance.main_transform.gameObject.AddComponent<GraphicRaycaster>();
		  __instance._raycaster.blockingObjects = GraphicRaycaster.BlockingObjects.All;
		  __instance._raycaster.blockingMask = -1;
		  __instance._raycaster.ignoreReversedGraphics = true;
		  __instance._button = __instance.GetComponent<Button>();
		  __instance._button.onClick.AddListener(delegate()
		  {
			DragOrderContainer container = __instance._container;
			if (container == null)
			{
			  return;
			}
			container.updateChildrenData();
		  });
		  __instance.is_target_reached = true;
		  __instance.checkContainer();
		  return false;
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(DragOrderElement), "setOnTop")]
	    public static bool setOnTop(DragOrderElement __instance)
	    {
		  return __instance._canvas != null;
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(DragOrderElement), "unsetOnTop")]
	    public static bool unsetOnTop(DragOrderElement __instance)
	    {
		  return __instance._canvas != null;
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(DragOrderElement), "OnEndDrag")]
	    public static bool OnEndDrag(DragOrderElement __instance)
	    {
		  return __instance._container != null;
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(PowerClockButton), "Update")]
	    public static bool Update_PowerClockButton(PowerClockButton __instance)
	    {
		  if (Config.time_scale_asset != null && Config.time_scale_asset.id == "toolkit_time")
		  {
			__instance._latest_used = Config.time_scale_asset.id;
			__instance.currentSpeedIcon.sprite = sh_toolkit_button.SpeedIcon;
			return false;
		  }
		  return true;
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(PowerLibrary), "spawnCrabzilla")]
        [HarmonyPatch(typeof(ControllableUnit), "setControllableCreature")]
		public static void spawnCrabzilla()
		{
          Main.SuperPause = false;
          PowerButton button = PowerButtons.CustomButtons["SH_SuperPause"];
          button.icon.sprite = Main.SuperPauseFalse;
          button.icon.overrideSprite = Main.SuperPauseFalse;
          Config.setWorldSpeed("x1", false);
        }
    }
}