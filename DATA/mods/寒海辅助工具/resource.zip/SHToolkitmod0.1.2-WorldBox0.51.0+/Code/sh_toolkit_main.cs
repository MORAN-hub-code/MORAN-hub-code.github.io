using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.api;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.Collections.Concurrent;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    [ModEntry]
    class Main : BasicMod<Main>
    {
        public static bool langUpdate = true;
        public static bool windowsRTF = true;
        public static bool InLoad = true;
        public static bool SuperPause = false;
        public static int icon_set = 0;
        public static float width = 0f;
        public static float height = 0f;
        public static string showText = "";
        public static WorldBehaviourAsset spawn_unit_asset;
        public static List<string> spawn_units = new List<string>();
        public static float auto_save_interval = 300f;
        public static float spawn_units_chance = 0.6f;
        public static int spawn_units_check = 4;
        public static int spawn_units_min = 2;
        public static int spawn_units_max = 5;
        public static int MultipleNum = 10;
        public static int MapSize = 100;
        public static string SHToolkitFolder = Path.Combine(SaveManager.persistentDataPath, "shsrhhad/toolkit/");
        public static string saveFile = Path.Combine(SHToolkitFolder, "toolkit_save.json");
        public static HashSet<WorldTile> landTile = new HashSet<WorldTile>();
        public static Vector3 None = new Vector3(14377341.1437f, 73411437.3241f);
        public static Sprite wu = Resources.Load<Sprite>("ui/Icons/wu");
        public static Sprite SuperPauseTrue = Resources.Load<Sprite>("ui/Icons/SuperPauseTrue");
        public static Sprite SuperPauseFalse = Resources.Load<Sprite>("ui/Icons/SuperPauseFalse");
        public static List<RaycastResult> raycastResults = new List<RaycastResult>();
        public static Tooltip toolTip = null;
        public static GameObject UIG = null;
        public static Main instance;
        public static UnityEvent debugEvent = GameObjects.FindEvenInactive("DebugButton").GetComponent<Button>().onClick;
        protected override void OnModLoad()
        {
          instance = this;
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_ui));
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_other));
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_world));
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_save));
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_obj));
          Harmony.CreateAndPatchAll(typeof(sh_toolkit_harmony_projectile));
          if (!System.IO.Directory.Exists(SHToolkitFolder))
          {
            System.IO.Directory.CreateDirectory(SHToolkitFolder);
          }
          string transl = Path.Combine(Main.SHToolkitFolder, "Texts");
          if (!Directory.Exists(transl))
          {
            System.IO.Directory.CreateDirectory(transl);
          }
          spawn_unit_asset = AssetManager.world_behaviours.add(new WorldBehaviourAsset
		      {
			      id = "sh_spawn_units",
			      interval = 7.2f,
			      interval_random = 14.4f,
			      action = delegate
            {
		          if (sh_toolkit_set.isOpen("RandomlyCreateCivUnit") && spawn_units.Any() && WorldLawLibrary.world_law_animals_spawn.isEnabled() && landTile.Any())
		          {
			          WorldTile tile = landTile.GetRandom<WorldTile>();
        	      if (tile != null && tile.zone.city == null && Finder.getUnitsFromChunk(tile, 1, 0f, false).Count() < spawn_units_check && Randy.randomChance(spawn_units_chance))
        	      {
			            ActorAsset asset = AssetManager.actor_library.get(spawn_units.GetRandom<string>());
			            if (asset != null) for (int i = 0; i < Randy.randomInt(spawn_units_min, spawn_units_max); i++)
			            {
				            World.world.units.createNewUnit(asset.id, tile, false, 0f, null, null, true, true);
			            }
                }
		          }
            }
          });
          spawn_unit_asset.manager = new WorldBehaviour(spawn_unit_asset);
          if (File.Exists(saveFile))
          {
            SHToolkitSave save = JsonConvert.DeserializeObject<SHToolkitSave>(File.ReadAllText(saveFile));
            spawn_units = save.spawn_units;
            spawn_unit_asset.interval = save.spawn_unit_interval;
            spawn_unit_asset.interval_random = save.spawn_unit_interval_random;
            spawn_units_chance = save.spawn_units_chance;
            spawn_units_check = save.spawn_units_check;
            spawn_units_min = save.spawn_units_min;
            spawn_units_max = save.spawn_units_max;
            MultipleNum = save.MultipleNum;
            MapSize = save.MapSize;
            auto_save_interval = save.auto_save_interval;
            sh_toolkit_ui.SHUI_pX = save.SHUI_pX;
          }
          else
          {
            foreach (ActorAsset asset in AssetManager.actor_library.list)
            {
              if (asset.civ)
              {
                spawn_units.Add(asset.id);
              }
            }
            SaveData();
          }
			    string modPath = this.GetDeclaration().FolderPath;
			    foreach (string text in Directory.GetFiles(Path.Combine(modPath, "GameResources/language/")))
			    {
            LoadLocalizedSave(File.ReadAllText(text));
          }
          try
          {
				    new FileInfo(Path.Combine(modPath, "bass.dll.shtoolkit")).CopyTo(Path.Combine(Core.WBGamePath, "bass.dll"), true);
          }
          catch
          {
          }
          Windows.CreateNewWindow("SHToolkitHelper", "");
          UIG = new GameObject("SHToolkit_UIG");
          UIG.AddComponent<RectTransform>().sizeDelta = new Vector2(200f, 30f);
          UIG.AddComponent<CanvasRenderer>();
          UIG.AddComponent<Image>().sprite = Resources.Load<Sprite>("ui/UIG");
          GameObject.Find("/Canvas Container Main/Canvas - Windows/windows/SHToolkitHelper/Background/Scroll View").SetActive(true);
          sh_toolkit_map_size.init();
          sh_toolkit_localizeds.loadLocalizedText();
          sh_toolkit_ui.init();
          sh_toolkit_modder.init();
          sh_toolkit_update_log.init();
          sh_toolkit_set.init();
          sh_toolkit_button.init();
          sh_toolkit_drop.init();
          sh_toolkit_ui.SHToolkitTab.FindNeighbours();
          InLoad = false;
        }
        void Update()
        {
          if (InLoad)
          {
            return;
          }
          raycastResults.Clear();
          PointerEventData eventData = new PointerEventData(EventSystem.current);
          eventData.position = Input.mousePosition;
          EventSystem.current.RaycastAll(eventData, raycastResults);
          if (raycastResults.Any())
          {
            GameObject obj = raycastResults[0].gameObject;
            if (obj != null && sh_toolkit_ui.CustomTips.TryGetValue(obj, out string text))
            {
		          Tooltip.hideTooltip(null, false, "normal");
              toolTip = Tooltip.getTooltip("normal");
		          toolTip.clear();
		          toolTip.data = new TooltipData{tip_name = text, tip_description =  $"{text}_description", tip_description_2 = $"{text}_description2"};
		          toolTip.showTooltip(obj, "normal");
            }
            else if (toolTip != null)
            {
              toolTip.hide();
              toolTip = null;
            }
          }
          else if (toolTip != null)
          {
            toolTip.hide();
            toolTip = null;
          }
          if (Main.showText != "")
          {
            WorldTip.showNow(Main.showText, false, "top");
            Main.showText = "";
          }
          if (langUpdate)
          {
            sh_toolkit_localizeds.loadLocalizedText();
            if (windowsRTF)
            {
              foreach (string id in sh_toolkit_ui.CustomWindows.Keys)
              {
                id.RTF();
              }
              windowsRTF = false;
            }
            langUpdate = false;
          }
          if (width != Screen.width)
          {
            width = Screen.width;
            icon_set = 2;
          }
          if (height != Screen.height)
          {
            height = Screen.height;
            icon_set = 2;
          }
          if (icon_set != 0)
          {
            if (sh_toolkit_ui.toolkit_close != null)
            {
              sh_toolkit_ui.open_buttons();
            }
            if (sh_toolkit_ui.toolkit_open != null)
            {
              sh_toolkit_ui.close_buttons();
            }
            icon_set--;
          }
          GameObject selectObj = EventSystem.current.currentSelectedGameObject;
          if (selectObj != null && selectObj.GetComponent<InputField>() != null)
          {
            return;
          }
          if (Input.GetKeyUp(KeyCode.F1) && Input.GetKeyUp(KeyCode.F2) || Input.GetKey(KeyCode.F1) && Input.GetKeyUp(KeyCode.F2) || Input.GetKey(KeyCode.F2) && Input.GetKeyUp(KeyCode.F1))
          {
            debugEvent.Invoke();
          }
        }
        public static void LoadLocalizedSave(string text)
        {
				  SHToolkitLocalizedSave pSave = JsonConvert.DeserializeObject<SHToolkitLocalizedSave>(text);
          if (pSave != null && pSave.text == "shsrhh_toolkit_language")
          {
            string text2 = Path.Combine(SHToolkitFolder, $"Texts/{pSave.id}.json");
            if (File.Exists(text2))
			      {
				      SHToolkitLocalizedSave pSave2 = JsonConvert.DeserializeObject<SHToolkitLocalizedSave>(File.ReadAllText(text2));
              if (pSave2 != null && pSave2.text == "shsrhh_toolkit_language" && pSave2.version > pSave.version)
              {
                return;
              }
			      }
            File.WriteAllText(text2, JsonConvert.SerializeObject(pSave, Formatting.Indented));
          }
		    }
        public static void SaveData()
        {
          SHToolkitSave save = new SHToolkitSave();
          save.spawn_units = spawn_units;
          save.spawn_unit_interval = spawn_unit_asset.interval;
          save.spawn_unit_interval_random = spawn_unit_asset.interval_random;
          save.spawn_units_chance = spawn_units_chance;
          save.spawn_units_check = spawn_units_check;
          save.spawn_units_min = spawn_units_min;
          save.spawn_units_max = spawn_units_max;
          save.MultipleNum = MultipleNum;
          save.MapSize = MapSize;
          save.auto_save_interval = auto_save_interval;
          save.SHUI_pX = sh_toolkit_ui.SHUI_pX;
          File.WriteAllText(saveFile, JsonConvert.SerializeObject(save, Formatting.Indented));
        }
        public static string ToTime(float num)
        {
          if (num < 1.2f)
          {
            return LocalizedTextManager.getText("sh_second").Replace("$num$", "0");
          }
          string text1;
          if (num < 103680f)
          {
            text1 = "";
          }
          else
          {
            text1 = LocalizedTextManager.getText("sh_day").Replace("$num$", Mathf.Round(num / 103680f).ToString());
            num %= 103680f;
          }
          string text2;
          if (num < 4320f)
          {
            text2 = "";
          }
          else
          {
            text2 = LocalizedTextManager.getText("sh_hour").Replace("$num$", Mathf.Round(num / 4320f).ToString());
            num %= 4320f;
          }
          string text3;
          if (num < 72f)
          {
            text3 = "";
          }
          else
          {
            text3 = LocalizedTextManager.getText("sh_minute").Replace("$num$", Mathf.Round(num / 72f).ToString());
            num %= 72f;
          }
          string text4;
          if (num < 1.2f)
          {
            text4 = "";
          }
          else
          {
            text4 = LocalizedTextManager.getText("sh_second").Replace("$num$", Mathf.Round(num / 1.2f).ToString());
          }
          return text1 + text2 + text3 + text4;
        }
    }
}
