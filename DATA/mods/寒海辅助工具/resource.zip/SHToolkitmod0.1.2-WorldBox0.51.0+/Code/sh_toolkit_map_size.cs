using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using NeoModLoader.General;
using SHToolkit.helps;

namespace SHToolkit
{
    public static class sh_toolkit_map_size
    {
        public static Dictionary<int, MapSizeAsset> MapSizeDict = new Dictionary<int, MapSizeAsset>();
        public static void init()
        {
          foreach (MapSizeAsset size in MapSizeDict.Values)
          {
            AssetManager.map_sizes.list.Remove(size);
          }
          for (int i = 1; i < Main.MapSize + 1; i++)
          {
            MapSizeAsset size;
            if (MapSizeDict.TryGetValue(i, out size))
            {
              AssetManager.map_sizes.list.Add(size);
            }
            else
            {
	            size = new MapSizeAsset();
              size.id = "SHSize" + i;
			        size.size = i;
			        size.path_icon = "iconSHWorld";
              MapSizeDict[i] = size;
              AssetManager.map_sizes.add(size);
            }
          }
          AssetManager.map_sizes.convertToOldFormat();
        }
    }
}