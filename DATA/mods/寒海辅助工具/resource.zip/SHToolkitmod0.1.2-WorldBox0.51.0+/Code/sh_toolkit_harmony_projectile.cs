using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_projectile
    {
        [HarmonyPrefix]
		[HarmonyPatch(typeof(ProjectileManager), "checkCollision")]
	    public static bool checkCollision() => sh_toolkit_set.isOpen("SHProjectileCollision");
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Projectile), "checkHitOnNearbyUnits")]
	    public static bool checkHitOnNearbyUnits(Projectile __instance, ref AttackDataResult __result)
	    {
		  if (sh_toolkit_set.isOpen("DisableProjectileMountainCrossing"))
		  {
			WorldTile pTile = World.world.GetTile((int)__instance._current_position_3d.x, (int)__instance._current_position_3d.y);
			if (pTile != null && pTile.Type.block)
			{
			  __result = AttackDataResult.Miss;
			  return false;
			}
		  }
		  return true;
		}
    }
}