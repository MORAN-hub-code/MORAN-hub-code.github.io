using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using NeoModLoader.General;
using SHToolkit.helps;

namespace SHToolkit
{
    public static class sh_toolkit_drop
    {
        public static string wid1 = "Window_SHToolkitTraitRains";
        public static string wid2 = "Window_SHToolkitItemRains";
        public static int Buttons = 0;
        public static int CXJZCS = 0;
        public static void init()
        {
          sh_toolkit_ui.NewWindow(wid1, "MoveTraitRains");
          AssetManager.drops.clone("sh_city_gamma_rain", "gamma_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("city", pTile, PlayerConfig.instance.data.trait_editor_gamma, PlayerConfig.instance.data.trait_editor_gamma_state);
          };
          AssetManager.drops.clone("sh_kingdom_gamma_rain", "gamma_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("kingdom", pTile, PlayerConfig.instance.data.trait_editor_gamma, PlayerConfig.instance.data.trait_editor_gamma_state);
          };
          AssetManager.drops.clone("sh_world_gamma_rain", "gamma_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("world", pTile, PlayerConfig.instance.data.trait_editor_gamma, PlayerConfig.instance.data.trait_editor_gamma_state);
          };
          AssetManager.drops.clone("sh_city_delta_rain", "delta_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("city", pTile, PlayerConfig.instance.data.trait_editor_delta, PlayerConfig.instance.data.trait_editor_delta_state);
          };
          AssetManager.drops.clone("sh_kingdom_delta_rain", "delta_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("kingdom", pTile, PlayerConfig.instance.data.trait_editor_delta, PlayerConfig.instance.data.trait_editor_delta_state);
          };
          AssetManager.drops.clone("sh_world_delta_rain", "delta_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("world", pTile, PlayerConfig.instance.data.trait_editor_delta, PlayerConfig.instance.data.trait_editor_delta_state);
          };
          AssetManager.drops.clone("sh_city_omega_rain", "omega_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("city", pTile, PlayerConfig.instance.data.trait_editor_omega, PlayerConfig.instance.data.trait_editor_omega_state);
          };
          AssetManager.drops.clone("sh_kingdom_omega_rain", "omega_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("kingdom", pTile, PlayerConfig.instance.data.trait_editor_omega, PlayerConfig.instance.data.trait_editor_omega_state);
          };
          AssetManager.drops.clone("sh_world_omega_rain", "omega_rain").action_landed = delegate(WorldTile pTile, string pDropID)
          {
            useTraitRain("world", pTile, PlayerConfig.instance.data.trait_editor_omega, PlayerConfig.instance.data.trait_editor_omega_state);
          };
          Transform transform1 = sh_toolkit_ui.CustomWindowObjects[wid1].transform;
          List<string> RainType = new List<string>{"city", "kingdom", "world"};
          foreach (string id in new List<string>{"gamma", "delta", "omega"})
          {
            PowerButtons.CreateButton($"sh_traits_{id}_rain_edit", Resources.Load<Sprite>($"ui/Icons/{id}_rain_edit"), null, null, getNextPos(5), ButtonType.Click, transform1, delegate
            {
              AssetManager.powers.clickTraitEditorRainButton($"traits_{id}_rain_edit");
            })._button.image.sprite = Resources.Load<Sprite>("ui/SHToolkitButton");
            string tid = $"traits_{id}_rain";
            GodPower trait_rain = AssetManager.powers.clone($"sh_{tid}", tid);
            trait_rain.name = trait_rain.id;
            trait_rain.unselect_when_window = false;
				    trait_rain.cached_drop_asset = AssetManager.drops.get(trait_rain.drop_id);
            sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(trait_rain.id, Resources.Load<Sprite>($"ui/Icons/{id}_rain"), null, null, getNextPos(5), ButtonType.GodPower, transform1, null));
            foreach (string type in RainType)
            {
              string pid = $"sh_traits_{type}_{id}_rain";
              GodPower traitRain = AssetManager.powers.clone(pid, tid);
              traitRain.name = pid;
              traitRain.drop_id = $"sh_{type}_{id}_rain";
              traitRain.unselect_when_window = false;
				      traitRain.cached_drop_asset = AssetManager.drops.get(traitRain.drop_id);
              sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(pid, Resources.Load<Sprite>($"ui/Icons/{type}_{id}_rain"), null, null, getNextPos(5), ButtonType.GodPower, transform1, null));
            }
          }
          Buttons -= 3;
          foreach (string id in new List<string>{"madness"})
          {
            ActorTrait trait = AssetManager.traits.get(id);
            if (trait != null)
            {
              GodPower trait_rain = AssetManager.powers.clone($"sh_{id}", id);
              trait_rain.name = trait_rain.id;
              trait_rain.unselect_when_window = false;
				      trait_rain.cached_drop_asset = AssetManager.drops.get(trait_rain.drop_id);
              sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(trait_rain.id, Resources.Load<Sprite>(trait.path_icon), null, null, getNextPos(4), ButtonType.GodPower, transform1, null));
              foreach (string type in RainType)
              {
                string pid = $"sh_{type}_{id}";
                GodPower traitRain = AssetManager.powers.clone(pid, id);
                traitRain.name = pid;
                traitRain.drop_id = pid;
                traitRain.unselect_when_window = false;
				        traitRain.cached_drop_asset = AssetManager.drops.clone(pid, id);
				        traitRain.cached_drop_asset.action_landed = new DropsAction((pTile, pDropID) => useTraitRain(type, pTile, new List<string>{id}, RainState.Add, true));
                sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(pid, Resources.Load<Sprite>($"ui/Icons/{type}_{id}"), null, null, getNextPos(4), ButtonType.GodPower, transform1, null));
              }
            }
          }
          for (int i = 0; i < CXJZCS; i++)
          {
            wid1.AddHeight(40f);
          }
          wid1.RTF();
          Buttons = 0;
          CXJZCS = 0;
          sh_toolkit_ui.NewWindow(wid2, "iconRainLoot");
          Transform transform2 = sh_toolkit_ui.CustomWindowObjects[wid2].transform;
          PowerButtons.CreateButton("sh_equipment_rain_edit", Resources.Load<Sprite>("ui/Icons/item_rain_edit"), null, null, getNextPos(5), ButtonType.Click, transform2, delegate
          {
            AssetManager.powers.clickEquipmentEditorRainButton("equipment_rain_edit");
          })._button.image.sprite = Resources.Load<Sprite>("ui/SHToolkitButton");
          string eid = "equipment_rain";
          GodPower equipment_rain = AssetManager.powers.clone($"sh_{eid}", eid);
          equipment_rain.name = equipment_rain.id;
          equipment_rain.unselect_when_window = false;
				  equipment_rain.cached_drop_asset = AssetManager.drops.get(equipment_rain.drop_id);
          sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(equipment_rain.id, Resources.Load<Sprite>("ui/Icons/iconRainLoot"), null, null, getNextPos(5), ButtonType.GodPower, transform2, null));
          foreach (string type in RainType)
          {
            string pid = $"sh_{type}_equipment_rain";
            GodPower equipmentRain = AssetManager.powers.clone(pid, eid);
            equipmentRain.name = pid;
            equipmentRain.drop_id = pid;
            equipmentRain.unselect_when_window = false;
				    equipmentRain.cached_drop_asset = AssetManager.drops.clone(pid, "loot_rain");
				    equipmentRain.cached_drop_asset.action_landed = delegate(WorldTile pTile, string pDropID)
            {
              useEquipmentRain(type, pTile, PlayerConfig.instance.data.equipment_editor, PlayerConfig.instance.data.equipment_editor_state);
            };
            sh_toolkit_ui.LJButtons.Add(PowerButtons.CreateButton(pid, Resources.Load<Sprite>($"ui/Icons/{type}_item_rain"), null, null, getNextPos(5), ButtonType.GodPower, transform2, null));
          }
          for (int i = 0; i < CXJZCS; i++)
          {
            wid2.AddHeight(40f);
          }
          wid2.RTF();
        }
        public static Vector3 getNextPos(int buttons)
        {
          int x = 0;
          int y = 2;
          int b = Buttons % buttons;
          x += b;
          y += ((Buttons - b) / buttons);
          Buttons++;
          if (b == 0)
          {
            CXJZCS++;
          }
          return new Vector2(-78f + (x * (160f / (buttons - 1))), 80f - (y * 40f));
        }
        public static void useTraitRain(string type, WorldTile pTile, List<string> list, RainState state, bool force = false)
        {
          List<Actor> actors = GetActors(type, pTile);
		      if (actors.Any() && list.Any())
          {
            bool flag1 = state == RainState.Add;
            foreach (Actor a in actors)
		        {
              bool flag2 = false;
			        if (a.Any() && a.asset != null && a.asset.can_edit_traits) foreach (string id in list)
			        {
				        ActorTrait trait = AssetManager.traits.get(id);
				        if (trait != null && trait.isAvailable())
				        {
                  if (flag1)
                  {
                    if (force || trait.can_be_given)
                    {
						          a.addTrait(trait, true);
                      flag2 = true;
                    }
                  }
                  else if (force || trait.can_be_removed)
                  {
						        a.removeTrait(trait);
                    flag2 = true;
                  }
				        }
			        }
              if (flag2)
              {
					      a.startShake(0.3f, 0.1f, true, true);
                if (!force)
                {
                  a.addTrait("scar_of_divinity");
					        a.makeConfused(-1f, true);
                }
              }
		        }
          }
        }
	      public static void useEquipmentRain(string type, WorldTile pTile, List<string> list, RainState state)
	      {
          List<Actor> actors = GetActors(type, pTile);
          if (actors.Any() && list.Any())
          {
            bool flag1 = state == RainState.Add;
            foreach (Actor a in actors)
		        {
              bool flag2 = false;
              if (a.Any() && a.asset != null && a.canEditEquipment() && a.equipment != null)
              {
                foreach (string id in list)
                {
                  EquipmentAsset asset = AssetManager.items.get(id);
                  if (asset != null && asset.isAvailable() && a.asset.canEditItem(asset))
                  {
				            ActorEquipmentSlot slot = a.equipment.getSlot(asset.equipment_type);
				            Item pItem = slot.getItem();
                    if ((flag1 && slot.isEmpty() || pItem != null && pItem.getAsset() != null && !pItem.isFavorite() && !pItem.isCursed()) && slot.canChangeSlot())
                    {
                      if (flag1)
                      {
                        if (asset.can_be_given)
                        {
					                Item item = World.world.items.generateItem(asset, a.kingdom, World.world.map_stats.player_name, 1, a, 0, true);
					                item.addMod("divine_rune");
					                a.equipment.setItem(item, a);
                          flag2 = true;
                        }
                      }
                      else if (asset.can_be_removed && pItem.getAsset().id == id)
                      {
					              slot.takeAwayItem();
                        flag2 = true;
                      }
                    }
                  }
                }
                if (flag2)
                {
			            a.startShake();
			            a.makeConfused(-1f, true);
                }
              }
            }
          }
	      }
        public static List<Actor> GetActors(string type, WorldTile pTile)
        {
          List<Actor> actors = new List<Actor>();
          switch (type)
          {
            case "city":
            {
              if (pTile != null && pTile.zone != null && pTile.zone.city != null)
              {
                long id = pTile.zone.city.getId();
                if (id != -1L)
                {
		              List<Actor> pList = World.world.units.getSimpleList();
                  for (int i = 0; i < pList.Count; i++)
                  {
                    Actor a = pList[i];
                    if (a.Any() && a.city.getId() == id)
                    {
                      actors.Add(a);
                    }
                  }
                }
              }
              break;
            }
            case "kingdom":
            {
              if (pTile != null && pTile.zone != null && pTile.zone.city != null && pTile.zone.city.kingdom != null)
              {
                long id = pTile.zone.city.kingdom.getId();
                if (id != -1L)
                {
		              List<Actor> pList = World.world.units.getSimpleList();
                  for (int i = 0; i < pList.Count; i++)
                  {
                    Actor a = pList[i];
                    if (a.Any() && a.kingdom.getId() == id)
                    {
                      actors.Add(a);
                    }
                  }
                }
              }
              break;
            }
            case "world":
            {
              actors.AddRange(World.world.units.getSimpleList());
              break;
            }
          }
          return actors;
        }
    }
}