using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_other
    {
		    public static bool canMultiple = true;
        [HarmonyPrefix]
        [HarmonyPatch(typeof(LocalizedTextManager), "loadLocalizedText")]
        public static void loadLocalizedText()
        {
          Main.langUpdate = true;
          sh_toolkit_localizeds.loadLocalizedText();
          Main.langUpdate = true;
		      Main.windowsRTF = true;
          Main.icon_set = 1;
        }
        [HarmonyPrefix]
		    [HarmonyPatch(typeof(CanvasMain), "changeCanvasSize")]
	      public static void changeCanvasSize()
	      {
          Main.icon_set = 2;
		    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(StringExtension), "ShouldUnderscore")]
		    public static bool ShouldUnderscore(string pString, ref bool __result)
		    {
		      if (sh_toolkit_localizeds.prohibitedUnderscore.Contains(pString))
		      {
			      __result = false;
			      return false;
		      }
		      return true;
		    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(PowerLibrary), "spawnUnit")]
	      public static void spawnUnit(WorldTile pTile, string pPowerID)
	      {
          if (canMultiple && (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl)) && sh_toolkit_set.isOpen("SHMultipleSpawn"))
          {
            canMultiple = false;
            for (int i = 1; i < Main.MultipleNum; i++)
            {
		          AssetManager.powers.spawnUnit(pTile, pPowerID);
            }
            canMultiple = true;
          }
	      }
        [HarmonyPrefix]
		    [HarmonyPatch(typeof(PlotAsset), "checkIsPossible")]
	      public static bool checkIsPossible(PlotAsset __instance, ref bool __result)
	      {
          if ((__instance.id == "alliance_create" || __instance.id == "alliance_join") && sh_toolkit_set.isOpen("SHDisableAlliances") || __instance.id == "alliance_destroy" && sh_toolkit_set.isOpen("SHUnbreakableAlliance"))
          {
            __result = false;
            return false;
          }
          return true;
		    }
    }
}