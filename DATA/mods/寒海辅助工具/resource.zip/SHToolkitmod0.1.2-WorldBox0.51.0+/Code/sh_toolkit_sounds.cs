using System;
using System.Collections.Concurrent;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.UI;
using NCMS.Utils;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_sounds
    {
        public static float bgm_volume = 1f;
        public static int bgm_stream = -1;
        [DllImport("bass.dll")]
        static extern bool BASS_Init(int device, int freq, int flags, IntPtr win, IntPtr dsguid);
        [DllImport("bass.dll")]
        static extern int BASS_StreamCreateFile(bool mem, string file, long offset, long length, int flags);
        [DllImport("bass.dll")]
        static extern bool BASS_ChannelPlay(int handle, bool restart);
        [DllImport("bass.dll")]
        static extern bool BASS_ChannelSlideAttribute(int handle, int attrib, float value, int time = 0);
        [DllImport("bass.dll")]
        static extern bool BASS_ChannelStop(int handle);
        [DllImport("bass.dll")]
        static extern int BASS_ChannelSetSync(int handle, int type, long param, SyncProc proc, IntPtr user);
        [DllImport("bass.dll")]
        static extern bool BASS_ChannelSetPosition(int handle, long pos, int mode);
        [DllImport("bass.dll")]
        static extern long BASS_ChannelGetPosition(int handle, int mode);
        [DllImport("bass.dll")]
        static extern bool BASS_ChannelSetAttribute(int handle, int attrib, float value);
        [DllImport("bass.dll")]
        static extern bool BASS_StreamFree(int handle);
        [DllImport("bass.dll")]
        static extern float BASS_ChannelBytes2Seconds(int handle, long pos);
        [DllImport("bass.dll")]
        static extern long BASS_ChannelSeconds2Bytes(int handle, float pos);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void SyncProc(int handle, int channel, int data, IntPtr user);
        public static void PlayBGM(string path, int time = 0, float seconds = 0f, int flag = 4)
        {
          StopBGM(time);
          int stream = BASS_StreamCreateFile(false, path, 0, 0, flag);
          if (!BASS_ChannelSetPosition(stream, BASS_ChannelSeconds2Bytes(stream, seconds), 0))
          {
            BASS_StreamFree(stream);
          }
          BASS_ChannelSetAttribute(stream, 2, 0f);
          BASS_ChannelPlay(stream, true);
          BASS_ChannelSlideAttribute(stream, 2, bgm_volume, time);
          bgm_stream = stream;
        }
        public static void StopBGM(int time = 0)
        {
          if (bgm_stream != -1)
          {
            BASS_ChannelSlideAttribute(bgm_stream, 2, 0f, time);
            BASS_ChannelSetSync(bgm_stream, 134217735, 0, delegate(int handle, int channel, int data, IntPtr user)
            {
              BASS_ChannelStop(channel);
              BASS_StreamFree(channel);
            }, IntPtr.Zero);
            bgm_stream = -1;
          }
        }
        public static float GetBGMPos()
        {
          if (bgm_stream == -1)
          {
            return 0f;
          }
          return BASS_ChannelBytes2Seconds(bgm_stream, BASS_ChannelGetPosition(bgm_stream, 0));
        }
    }
}