using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NCMS;
using NCMS.Utils;
using SHToolkit.helps;
using ReflectionUtility;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace SHToolkit
{
    class sh_toolkit_modder
    {
        public static int Buttons = 0;
        public static string wid = "Window_SHToolkitModder";
        public static void init()
        {
          sh_toolkit_ui.NewWindow(wid, "SHToolkitModder", 0f, "SHToolkitMContentText", true);
          sh_toolkit_ui.CustomTextColors.Add(wid, "#FFFFFF");
          NewWebsite("toolkit_afdian", "https://afdian.com/a/shsrhhad");
          NewWebsite("toolkit_QQ1", "https://qm.qq.com/q/Bxk559ZmaQ");
          NewWebsite("toolkit_QQ2", "https://qm.qq.com/q/76muYSsCCQ");
          NewWebsite("toolkit_bilibili", "https://space.bilibili.com/1013530615");
          NewWebsite("toolkit_gamebanana", "https://gamebanana.com/members/2160771");
          NewWebsite("toolkit_nexusmods", "https://www.nexusmods.com/users/153470848");
          NewWebsite("toolkit_youtube", "https://www.youtube.com/channel/UC1xyCNecgTtxpVR-YS1vYjg");
          NewWebsite("toolkit_discord", "https://discord.gg/z4TzApDGgn");
          NewWebsite("toolkit_Iworldbox", "https://bbs.iworldbox.top/?71");
          NewWebsite("toolkit_hanyigzs", "https://bbs.hanyigzs.cn/author/3750");
          Buttons = 0;
          NewWebsite("toolkit_123", "https://www.123912.com/s/HfrqVv-IXWc3", 130f, "ui/sh_toolkit_right_button");
          NewWebsite("toolkit_mega", "https://mega.nz/folder/pG5g0Tja#dSADdgmaxPcea07SSfNhqw", 130f, "ui/sh_toolkit_right_button");
          wid.RTF();
		}
        public static void NewWebsite(string id, string wz, float x = -127f, string button = "ui/sh_toolkit_left_button")
        {
		  GodPower NewL = new GodPower();
		  NewL.id = "shsrhh" + id;
		  NewL.name = "shsrhh" + id;
		  NewL.unselect_when_window = true;
		  NewL.toggle_action = new PowerToggleAction((pPower) => Application.OpenURL(@$"{wz}"));
		  AssetManager.powers.add(NewL);
          PowerButton NewB = sh_toolkit_ui.NewPowerButton("shsrhh" + id, Resources.Load<Sprite>($"ui/Icons/{id}"), Resources.Load<Sprite>(button), new Vector2(x, 122f - (Buttons * 26f)), new Vector3(0.8f, 0.8f), new Vector3(0.8f, 0.8f), ButtonType.Click, sh_toolkit_ui.CustomWindows[wid].transform);
		  Reflection.SetField<GodPower>(NewB, "godPower", NewL);
          NewB.type = PowerButtonType.Special;
          Buttons++;
        }
    }
}
