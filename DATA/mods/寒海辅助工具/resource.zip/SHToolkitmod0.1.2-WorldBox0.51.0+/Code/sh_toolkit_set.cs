using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using NeoModLoader.General;
using SHToolkit.helps;

namespace SHToolkit
{
    public static class sh_toolkit_set
    {
        public static string wid1 = "Window_SHToolkitSet";
        public static string wid2 = "Window_RandomlyCreateCivSet";
        public static string wid3 = "Window_SHToolkitParameterSet";
        public static Dictionary<string, UnityAction<bool>> toggleActions = new Dictionary<string, UnityAction<bool>>();
        public static Dictionary<string, bool> toggleBools = new Dictionary<string, bool>();
        public static Dictionary<string, bool> MRBools = new Dictionary<string, bool>();
        public static List<string> races = new List<string>();
        public static float pHeight = 500f;
        public static float height = pHeight * 0.5f;
        public static int Buttons = 0;
        public static int CXJZCS_Civ = 1;
        public static int CXJZCS_PS = 1;
        public static void init()
        {
          Transform transform1_main = sh_toolkit_ui.NewWindow(wid1, "iconSHToolkitTAB", pHeight).transform;
          Transform transform1 = sh_toolkit_ui.CustomWindowObjects[wid1].transform;
          sh_toolkit_ui.NewPowerButton("SHDebugButton", Resources.Load<Sprite>("ui/Icons/icondebug"), Resources.Load<Sprite>("ui/sh_toolkit_right_button"), new Vector2(130f, 115f), Main.None, Main.None, ButtonType.Click, transform1_main, Main.debugEvent.Invoke);
          sh_toolkit_ui.NewPowerButton("SHToolkitDefaultSetting", Resources.Load<Sprite>("ui/Icons/SHToolkitDefaultSetting"), Resources.Load<Sprite>("ui/sh_toolkit_left_button"), new Vector2(-130f, 49f), Main.None, Main.None, ButtonType.Click, transform1_main, DefaultSetting);
          sh_toolkit_ui.NewPowerButton("SHToolkitParameterSet", Resources.Load<Sprite>("ui/Icons/iconSHToolkitWindow"), Resources.Load<Sprite>("ui/sh_toolkit_left_button"), new Vector2(-130f, 14f), Main.None, Main.None, ButtonType.Click, transform1_main, () => Windows.ShowWindow(wid3));
          Vector3 TextSize = new Vector3(100f, 100f);
          sh_toolkit_ui.NewText("SHToolkitActorSet", "SHToolkitActorSet", "#FFFFFF", true, transform1, new Vector3(0f, height - 23f), TextSize, 9f);
          sh_toolkit_ui.NewIcon("CreateCivLine", "ui/SHToolkitline", transform1, new Vector2(-85f, height + 5.5f), new Vector3(5f, 25f));
          NewSet("RandomlyCreateCivUnit", transform1, false, -55f);
          NewSet("RemoveInvincibleFrames", transform1, false, -55f);
          NewSet("FastAdult", transform1, false, -55f, delegate(bool flag)
          {
		        List<Actor> pList = World.world.units.getSimpleList();
            for (int i = 0; i < pList.Count; i++)
            {
              Actor a = pList[i];
              if (a.Any())
              {
                a.setStatsDirty();
              }
            }
          });
          NewSet("CityCultureProtection", transform1, false, -55f);
          NewSet("KingdomCultureProtection", transform1, false, -55f);
          NewSet("SHMultipleSpawn", transform1, false, -55f);
          NewSet("SHDisableAlliances", transform1, false, -55f, delegate(bool flag)
          {
		        if (flag) foreach (Plot plot in World.world.plots)
		        {
			        if (plot._plot_asset.id == "alliance_create" || plot._plot_asset.id == "alliance_join")
			        {
				        World.world.plots.cancelPlot(plot);
			        }
		        }
          });
          NewSet("SHUnbreakableAlliance", transform1, false, -55f, delegate(bool flag)
          {
		        if (flag) foreach (Plot plot in World.world.plots)
		        {
			        if (plot._plot_asset.id == "alliance_destroy")
			        {
				        World.world.plots.cancelPlot(plot);
			        }
		        }
          });
          sh_toolkit_ui.NewText("SHToolkitOptimizeSet", "SHToolkitOptimizeSet", "#FFFFFF", true, transform1, new Vector3(0f, height - 75f - Buttons / 5 * 30f), TextSize, 9f);
          Buttons = Buttons.RoundUpToMultipleOf(5);
          NewSet("SHProjectileCollision", transform1, true, -33f);
          NewSet("DisableProjectileMountainCrossing", transform1, false, -33f);
          NewSet("ModifyAutoSaveInterval", transform1, true, -33f);
          NewSet("ForceAutoSave", transform1, false, -33f);
          Transform transform2_main = sh_toolkit_ui.NewWindow(wid2, "iconSHToolkitTAB").transform;
          Transform transform2 = sh_toolkit_ui.CustomWindowObjects[wid2].transform;
          List<GameObject> objs = new List<GameObject>();
          List<GameObject> objs_Civ = new List<GameObject>();
          sh_toolkit_ui.NewPowerButton("RandomlyCreateCivSet", Resources.Load<Sprite>("ui/Icons/iconSHToolkitTab"), null, new Vector3(-85f, height + 20f), new Vector3(0.7f, 0.7f), new Vector3(0.5f, 0.5f), ButtonType.Click, transform1, delegate
          {
            objs.Clear();
            wid2.SetHeight(0f);
            wid2.RTF();
            foreach (ActorAsset asset in AssetManager.actor_library.list)
            {
              if (asset.civ && !races.Contains(asset.id))
              {
                CXJZCS_Civ++;
                SZSet(asset.id + "CreateCivSCBL", $"ui/Icons/{asset.icon}", CXJZCS_Civ, 25f, objs, transform2, () => SetCivSCBL(asset.id, -1), () => SetCivSCBL(asset.id, 1));
                races.Add(asset.id);
                foreach (GameObject obj in objs_Civ)
                {
                  Vector3 pos = obj.transform.localPosition;
                  obj.transform.localPosition = new Vector3(pos.x, pos.y + 20f);
                }
              }
            }
            for (int i = 0; i < CXJZCS_Civ; i++)
            {
              wid2.AddHeight(40f);
              foreach (GameObject obj in objs)
              {
                Vector3 pos = obj.transform.localPosition;
                obj.transform.localPosition = new Vector3(pos.x, pos.y + 20f);
              }
              objs_Civ.AddRange(objs);
            }
            wid2.RTF();
            Windows.ShowWindow(wid2);
            Main.SaveData();
            Main.langUpdate = true;
          });
          sh_toolkit_ui.NewPowerButton("SHCivUnitDefaultSetting", Resources.Load<Sprite>("ui/Icons/SHToolkitDefaultSetting"), Resources.Load<Sprite>("ui/sh_toolkit_left_button"), new Vector2(-130f, 49f), Main.None, Main.None, ButtonType.Click, transform2_main, delegate
          {
            Main.spawn_units.Clear();
            Main.spawn_units.AddRange(races);
            Main.spawn_unit_asset.interval = 7.2f;
            Main.spawn_unit_asset.interval_random = 14.4f;
            Main.spawn_units_chance = 0.6f;
            Main.spawn_units_check = 4;
            Main.spawn_units_min = 2;
            Main.spawn_units_max = 5;
            Main.SaveData();
            Main.langUpdate = true;
          });
          Buttons++;
          SZSet("CivUnitSCGL", "ui/Icons/SHToolkitCreateCivUnit", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSCGL(-0.0001f), () => SetCivSCGL(0.0001f));
          CXJZCS_Civ++;
          SZSet("CivUnitSCJG", "ui/Icons/SHToolkitCreateCivUnitInterval", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSCJG(-1.2f), () => SetCivSCJG(1.2f));
          CXJZCS_Civ++;
          SZSet("CivUnitSJJG", "ui/Icons/SHToolkitCreateCivUnitRandomInterval", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSJJG(-1.2f), () => SetCivSJJG(1.2f));
          CXJZCS_Civ++;
          SZSet("CivUnitSCSX", "ui/Icons/SHToolkitCreateCivUnitCheck", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSCSX(-1), () => SetCivSCSX(1));
          CXJZCS_Civ++;
          SZSet("CivUnitSCMax", "ui/Icons/SHToolkitCreateCivUnitMax", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSCMax(-1), () => SetCivSCMax(1));
          CXJZCS_Civ++;
          SZSet("CivUnitSCMin", "ui/Icons/SHToolkitCreateCivUnitMin", CXJZCS_Civ, 28.5f, objs_Civ, transform2, () => SetCivSCMin(-1), () => SetCivSCMin(1));
          foreach (ActorAsset asset in AssetManager.actor_library.list)
          {
            if (asset.civ)
            {
              CXJZCS_Civ++;
              SZSet(asset.id + "CreateCivSCBL", $"ui/Icons/{asset.icon}", CXJZCS_Civ, 25f, objs_Civ, transform2, () => SetCivSCBL(asset.id, -1), () => SetCivSCBL(asset.id, 1));
              races.Add(asset.id);
            }
          }
          for (int i = 0; i < CXJZCS_Civ; i++)
          {
            wid2.AddHeight(40f);
            foreach (GameObject obj in objs_Civ)
            {
              Vector3 pos = obj.transform.localPosition;
              obj.transform.localPosition = new Vector3(pos.x, pos.y + 20f);
            }
          }
          wid2.RTF();
          Transform transform3_main = sh_toolkit_ui.NewWindow(wid3, "iconSHToolkitWindow").transform;
          Transform transform3 = sh_toolkit_ui.CustomWindowObjects[wid3].transform;
          List<GameObject> objs_PS = new List<GameObject>();
          SZSet("MultipleSpawnNum", "ui/Icons/SHMultipleSpawn", CXJZCS_PS, 28.5f, objs_PS, transform3, () => SetCPLSCSL(-1), () => SetCPLSCSL(1));
          CXJZCS_PS++;
          SZSet("SHMapSizeNum", "ui/Icons/iconSHWorld", CXJZCS_PS, 28.5f, objs_PS, transform3, () => SetDTGMSL(-1), () => SetDTGMSL(1));
          CXJZCS_PS++;
          SZSet("SHAutoSaveInterval", "ui/Icons/ModifyAutoSaveInterval", CXJZCS_PS, 28.5f, objs_PS, transform3, () => SetAutoSaveInterval(-1.2f), () => SetAutoSaveInterval(1.2f));
          CXJZCS_PS++;
          SZSet("SHUIX", "ui/Icons/SHUIX", CXJZCS_PS, 28.5f, objs_PS, transform3, () => SetSHUIY(-0.01f), () => SetSHUIY(0.01f));
          for (int i = 0; i < CXJZCS_PS; i++)
          {
            wid3.AddHeight(40f);
            foreach (GameObject obj in objs_PS)
            {
              Vector3 pos = obj.transform.localPosition;
              obj.transform.localPosition = new Vector3(pos.x, pos.y + 20f);
            }
          }
          wid3.RTF();
        }
        public static void SZSet(string id, string icon, int CXJZCS, float textY, List<GameObject> UIGs, Transform parent, UnityAction call = null, UnityAction call2 = null)
        {
          float JG = CXJZCS * 40f;
          GameObject UIG = GameObject.Instantiate(Main.UIG, parent);
          UIG.transform.localPosition = new Vector2(0f, 46f - JG);
          GameObject ZIIcon = sh_toolkit_ui.NewIcon($"{id}Icon", icon, parent, new Vector3(-80f, 45f - JG), new Vector2(25f, 25f));
          sh_toolkit_ui.NewText($"{id}Text", $"#{id}Text", string.Empty, true, parent, new Vector3(12f, textY - JG), new Vector2(100f, 50f));
          PowerButton button1 = PowerButtons.CreateButton(id + "ZILeftButton", Resources.Load<Sprite>("ui/SHToolkitLeft"), null, null, new Vector3(-60f, 50f - JG), ButtonType.Click, parent, call);
          button1.OnEnable();
          button1._button.image.sprite = Main.wu;
          PowerButton button2 = PowerButtons.CreateButton(id + "ZIRightButton", Resources.Load<Sprite>("ui/SHToolkitRight"), null, null, new Vector3(90f, 50f - JG), ButtonType.Click, parent, call2);
          button2.OnEnable();
          button2._button.image.sprite = Main.wu;
          UIGs.Add(UIG);
          UIGs.Add(ZIIcon);
        }
        public static Button NewSet(string id, Transform parent, bool option, float pY, UnityAction<bool> action = null)
        {
          int x = 0;
          int y = 2;
          int b = Buttons % 5;
          x += b;
          y += ((Buttons - b) / 5);
          float JG = y * 30f;
          Vector2 BVC = new Vector2(-85f + (x * 43f), height - pY - JG);
          if (b == 0)
          {
            GameObject UIG = GameObject.Instantiate(Main.UIG, parent);
            UIG.GetComponent<RectTransform>().sizeDelta = new Vector2(222f, 30f);
            UIG.transform.localPosition = new Vector2(0f, BVC.y);
            UIG.transform.SetAsFirstSibling();
          }
          MRBools.Add(id, option);
          string text = $"{id}_set.json".ToFile();
          if (File.Exists(text))
          {
            option = text.toSet(option);
          }
          else
          {
            text.NewSetJson(id, option);
          }
          if (action != null)
          {
            toggleActions.Add(id, action);
          }
          Button NewButton = sh_toolkit_ui.NewButton(id, BVC, parent, Resources.Load<Sprite>("ui/SHToolkitButtonUI"), Resources.Load<Sprite>($"ui/Icons/{id}"), () => toggleOption(id));
          NewButton.gameObject.GetComponent<RectTransform>().sizeDelta = new Vector3(36.55f, 15.3f);
          RectTransform icon = NewButton.transform.Find("Icon").GetComponent<RectTransform>();
          icon.sizeDelta = new Vector3(28.05f, 10.2f);
          icon.localPosition = new Vector3(5f, 0f, 0f);
          sh_toolkit_ui.NewToggle(NewButton.transform, new Vector3(-11f, 0f, 0f), id, option, true, 8.5f);
          toggleBools.Add(id, option);
          Buttons++;
          return NewButton;
        }
        public static void DefaultSetting()
        {
          foreach (string set in MRBools.Keys)
          {
            DSetting(set, MRBools[set]);
          }
        }
        public static void DSetting(string set, bool kq)
        {
          if (BLTD(kq, set))
          {
            toggleOption(set);
          }
        }
        public static bool BLTD(bool kq, string set)
        {
          return kq ? !toggleBools[set] : toggleBools[set];
        }
        public static void SetCivSCGL(float num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100f;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10f;
          }
          Main.spawn_units_chance += num;
          if (Main.spawn_units_chance > 1f)
          {
            Main.spawn_units_chance = 1f;
          }
          if (Main.spawn_units_chance < 0f)
          {
            Main.spawn_units_chance = 0f;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSCJG(float num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 60f;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10f;
          }
          Main.spawn_unit_asset.interval += num;
          if (Main.spawn_unit_asset.interval < 0f)
          {
            Main.spawn_unit_asset.interval = 0f;
          }
          float max = Main.spawn_unit_asset.interval + Main.spawn_unit_asset.interval_random;
          if (Main.spawn_unit_asset.manager._timer > max)
          {
            Main.spawn_unit_asset.manager._timer = max;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSJJG(float num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 60f;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10f;
          }
          Main.spawn_unit_asset.interval_random += num;
          if (Main.spawn_unit_asset.interval_random < 0f)
          {
            Main.spawn_unit_asset.interval_random = 0f;
          }
          float max = Main.spawn_unit_asset.interval + Main.spawn_unit_asset.interval_random;
          if (Main.spawn_unit_asset.manager._timer > max)
          {
            Main.spawn_unit_asset.manager._timer = max;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSCSX(int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          Main.spawn_units_check += num;
          if (Main.spawn_units_check < 0)
          {
            Main.spawn_units_check = 0;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSCMax(int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          Main.spawn_units_max += num;
          if (Main.spawn_units_max < Main.spawn_units_min)
          {
            Main.spawn_units_max = Main.spawn_units_min;
            Main.showText = LocalizedTextManager.getText("SHSpawnCivMaxLessMin");
          }
          if (Main.spawn_units_max < 0)
          {
            Main.spawn_units_max = 0;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSCMin(int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          Main.spawn_units_min += num;
          if (Main.spawn_units_min > Main.spawn_units_max)
          {
            Main.spawn_units_min = Main.spawn_units_max;
            Main.showText = LocalizedTextManager.getText("SHSpawnCivMinGreaterMax");
          }
          if (Main.spawn_units_min < 0)
          {
            Main.spawn_units_min = 0;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCivSCBL(string id, int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          if (num > 0)
          {
            Main.spawn_units.AddRange(id.ToList(num));
          }
          else for (int y = 0; y < -num; y++)
          {
            Main.spawn_units.Remove(id);
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetCPLSCSL(int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          Main.MultipleNum += num;
          if (Main.MultipleNum < 1)
          {
            Main.MultipleNum = 1;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetDTGMSL(int num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10;
          }
          Main.MapSize += num;
          if (Main.MapSize < 0)
          {
            Main.MapSize = 0;
          }
          sh_toolkit_map_size.init();
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetAutoSaveInterval(float num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 60f;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10f;
          }
          Main.auto_save_interval += num;
          if (Main.auto_save_interval < 0f)
          {
            Main.auto_save_interval = 0f;
          }
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void SetSHUIY(float num)
        {
          if (Input.GetKey(KeyCode.RightShift) || Input.GetKey(KeyCode.LeftShift))
          {
            num *= 100f;
          }
          else if (Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.LeftControl))
          {
            num *= 10f;
          }
          sh_toolkit_ui.SHUI_pX += num;
          if (sh_toolkit_ui.SHUI_pX > 0.8f)
          {
            sh_toolkit_ui.SHUI_pX = 0.8f;
          }
          if (sh_toolkit_ui.SHUI_pX < -0.8f)
          {
            sh_toolkit_ui.SHUI_pX = -0.8f;
          }
          Main.icon_set = 2;
          Main.SaveData();
          Main.langUpdate = true;
        }
        public static void toggleOption(string id)
        {
          bool flag = !toggleBools[id];
          toggleBools[id] = flag;
          sh_toolkit_ui.CustomToggle[id].updateIcon(flag);
          if (toggleActions.TryGetValue(id, out UnityAction<bool> action))
          {
            action(flag);
          }
				  Image component = sh_toolkit_ui.CustomButtons[id].transform.Find("Icon").GetComponent<Image>();
          if (flag)
          {
            component.color = Toolbox.makeColor("#FFFFFF");
          }
          else
          {
            component.color = Toolbox.makeColor("#666666");
          }
          $"{id}_set.json".ToFile().NewSetJson(id, flag);
        }
        public static bool isOpen(string set)
        {
          return toggleBools.TryGetValue(set, out bool flag) ? flag : false;
        }
    }
}