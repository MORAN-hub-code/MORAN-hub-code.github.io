using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_world
    {
        [HarmonyPostfix]
        [HarmonyPatch(typeof(WorldTile), "setTopTileType")]
        [HarmonyPatch(typeof(WorldTile), "setTileType", new Type[]{typeof(TileType), typeof(bool)})]
        [HarmonyPatch(typeof(WorldTile), "setTileType", new Type[]{typeof(string)})]
        public static void setTileType(WorldTile __instance)
	    {
		  TileTypeBase type = __instance.Type;
		  if (type != null && type.layer_type == TileLayerType.Ground && type.biome_asset != null && type.biome_asset.pot_spawn_units_auto)
          {
            Main.landTile.Add(__instance);
          }
          else
          {
            Main.landTile.Remove(__instance);
          }
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(MapBox), "checkMainSimulationUpdate")]
	    public static bool checkMainSimulationUpdate(MapBox __instance)
	    {
		  if (Main.SuperPause)
		  {
			if (!Config.paused)
			{
			  __instance._is_paused = true;
			  Config.paused = true;
			}
			return false;
		  }
		  return true;
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Config), "set_paused")]
		public static void set_paused(ref bool value)
		{
		  if (Main.SuperPause)
		  {
			if (!value)
			{
			  Main.showText = LocalizedTextManager.getText("SuperPauseTip");
			}
			value = true;
		  }
		}
        [HarmonyPrefix]
        [HarmonyPatch(typeof(MonthLibrary), "getMonth")]
	    public static void getMonth(MonthLibrary __instance, ref int pMonthIndex)
	    {
		  if (!__instance._month_indexes.ContainsKey(pMonthIndex))
		  {
			pMonthIndex %= 12;
			if (pMonthIndex < 1)
			{
			  pMonthIndex = 12;
			}
		  }
		}
    }
}