using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using HarmonyLib;
using NCMS;
using NCMS.Utils;
using NeoModLoader.General;
using Newtonsoft.Json;
using ReflectionUtility;
using UnityEngine;
using static Config;
using System.Collections;
using System.IO.Compression;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ai;
using ai.behaviours;
using Beebyte.Obfuscator;
using EpPathFinding.cs;
using life.taxi;
using SleekRender;
using tools;
using tools.debug;
using UnityEngine.CrashReportHandler;
using UnityEngine.EventSystems;
using UnityEngine.Purchasing.MiniJSON;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using WorldBoxConsole;
using SHToolkit.helps;

namespace SHToolkit
{
    class sh_toolkit_harmony_obj
    {
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), "getHit")]
	    public static void getHit_Actor(Actor __instance, ref bool pSkipIfShake)
	    {
          if (sh_toolkit_set.isOpen("RemoveInvincibleFrames"))
		  {
			pSkipIfShake = false;
			__instance._shake_active = false;
		  }
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Building), "getHit")]
	    public static void getHit_Building(ref bool pSkipIfShake)
	    {
          if (sh_toolkit_set.isOpen("RemoveInvincibleFrames"))
		  {
			pSkipIfShake = false;
		  }
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(BaseSimObject), "getHit")]
	    public static void getHit_BaseSimObject(ref bool pSkipIfShake)
	    {
          if (sh_toolkit_set.isOpen("RemoveInvincibleFrames"))
		  {
			pSkipIfShake = false;
		  }
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(Actor), "calcIsBaby")]
	    public static bool calcIsBaby()
	    {
          return !sh_toolkit_set.isOpen("FastAdult");
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(BehChangeCityActorCulture), "execute")]
	    public static bool BehChangeCityActorCulture(ref BehResult __result)
	    {
		  if (sh_toolkit_set.isOpen("CityCultureProtection"))
		  {
			__result = BehResult.Stop;
			return false;
		  }
          return true;
	    }
        [HarmonyPrefix]
        [HarmonyPatch(typeof(BehChangeKingdomCulture), "execute")]
	    public static bool BehChangeKingdomCulture(ref BehResult __result)
	    {
		  if (sh_toolkit_set.isOpen("KingdomCultureProtection"))
		  {
			__result = BehResult.Stop;
			return false;
		  }
          return true;
	    }
    }
}