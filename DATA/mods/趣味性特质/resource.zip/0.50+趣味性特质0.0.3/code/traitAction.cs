﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ai;
using UnityEngine;

namespace InterestingTrait.code
{
    internal class traitAction
    {
        public static bool bomb1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }


            {
                EffectsLibrary.spawn("fx_meteorite", pTile, "meteorite", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool bomb2_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }


            {
                EffectsLibrary.spawn("fx_nuke_flash", pTile, "atomicBomb", null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool bomb3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_antimatter_effect", pTile, null, null, 0f, -1f, -1f);
            }

            return true;
        }

        public static bool bomb4_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }

            if (pTile == null)
            {
                return false;
            }

            {
                EffectsLibrary.spawn("fx_napalm_flash", pTile, "NapalmBomb", null, 0f, -1f, -1f);
            }

            return true;
        }
        public static bool extraordinary1_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            int randomExp = UnityEngine.Random.Range(5, 50);
            pTarget.a.addExperience(randomExp);
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                int tHealthToRegen = pTarget.a.getMaxHealthPercent(0.01f);
                pTarget.a.restoreHealth(tHealthToRegen);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }
            Actor a = pTarget.a;
            var interestingTraits = new Dictionary<string, int>
            {
                {"interesting3_1", 10},
                {"interesting3_2", 24},
                {"interesting3_3", 45},
                {"interesting3_4", 56},
                {"interesting3_5", 68},
                {"interesting3_6", 80}
            };
            string highestTrait = null;
            int maxLevel = 0;
            foreach (var trait in interestingTraits)
            {
                if (a.data.level > trait.Value && trait.Value > maxLevel)
                {
                    maxLevel = trait.Value;
                    highestTrait = trait.Key;
                }
            }
            if (highestTrait != null)
            {
                foreach (var trait in interestingTraits)
                {
                    if (trait.Value < maxLevel && a.hasTrait(trait.Key))
                    {
                        a.removeTrait(trait.Key);
                    }
                }
                if (!a.hasTrait(highestTrait))
                {
                    a.addTrait(highestTrait);
                }
            }
            if(a.data.level > 30)
            {
                a.addTrait("fire_proof");
                a.addTrait("freeze_proof");
            }
            if (a.data.level > 35)
            {
                // 定义可随机的战斗动作特质列表
                string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
                bool hasCombatActionTrait = false;
                foreach (string trait in combatActionTraits)// 检查角色是否已拥有列表中的任何一个特质
                {
                    if (a.hasTrait(trait))
                    {
                        hasCombatActionTrait = true;
                        break;
                    }
                }
                if (!hasCombatActionTrait)// 如果未拥有，则随机选择一个特质并添加
                {
                    int randomIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
                    string selectedCombatTrait = combatActionTraits[randomIndex];
                    a.addTrait(selectedCombatTrait);
                }
            }
            if (a.data.level > 50)
            {
                a.addTrait("arcane_reflexes");
                a.addTrait("battle_reflexes");
            }
            if (a.data.level > 60)
            {
                // 定义可随机的元素特质列表
                string[] elementTraits = { "element0", "element1", "element3", "element4" };
                bool hasElementTrait = false;// 检查角色是否已拥有列表中的任何一个特质
                foreach (string trait in elementTraits)
                {
                    if (a.hasTrait(trait))
                    {
                        hasElementTrait = true;
                        break;
                    }
                }
                if (!hasElementTrait)
                {
                    int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
                    string selectedElementTrait = elementTraits[randomIndex];
                    a.addTrait(selectedElementTrait);
                }
            }
            return true;
        }

        public static bool extraordinary2_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            pTarget.a.addMoney(1);
            return true;
        }

        public static bool interesting3_10_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(10);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_20_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(20);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_30_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(30);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_50_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(50);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_80_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(80);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_100_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(100);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_200_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(200);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_300_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(300);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_777_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(777);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }

        public static bool interesting3_1000_effectAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.a.data.health < pTarget.a.getMaxHealth())
            {
                pTarget.a.restoreHealth(1000);
                pTarget.a.spawnParticle(Toolbox.color_heal);
            }

            return true;
        }
        public static bool brokenProof(BaseSimObject pTarget, WorldTile pTile = null)
        {
            Actor a = pTarget.a;
            a.addTrait("fire_proof");
            a.addTrait("freeze_proof");
            return false;
        }
        public static bool element0_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                pTile = pTarget.current_tile;
            }
            if (pTile == null)
            {
                return false;
            }
            World.world.drop_manager.spawn(pTile, "fire", 15f, -1f);
            for (int i = 0; i < 3; i++)
            {
                World.world.drop_manager.spawn(pTile.neighboursAll.GetRandom<WorldTile>(), "fire", 15f, -1f);
            }
            return true;
        }
        public static bool element1_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget.isBuilding())
            {
                return false;
            }
            if (pTarget.current_tile.Type.lava)
            {
                return false;
            }
            if (pTarget.current_tile.isOnFire())
            {
                return false;
            }
            pTarget.addStatusEffect("frozen", -1f);
            return true;
        }
        public static bool element3_attackAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget != null)
            {
                Actor a = pTarget.a;
                MapBox.spawnLightningMedium(pTile, 0.10f);
            }

            return false;
        }
        public static bool superforce(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile)
        {
            Actor a = pTarget.a;
            Actor s = pSelf.a;
            a.getHit(5f * s.stats[S.intelligence], true, AttackType.Other, pSelf, false, false);
            EffectsLibrary.spawnExplosionWave(pTile.posV3, 0.05f, 6f);

            return false;
        }
        public static bool extraordinary5_deathAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            IReadOnlyCollection<ActorTrait> traits = a.getTraits();
            List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
            foreach (string traitId in allTraitIds)
            {
                a.removeTrait(traitId);
            }
            a.addTrait("extraordinary5");
            a.addTrait("interesting3_6");
            a.addTrait("arcane_reflexes");
            a.addTrait("battle_reflexes");
            a.addTrait("fast");
            // 定义可随机的特质列表
            string[] elementTraits = { "element0", "element1", "element3", "element4", "interesting3_8", "interesting3_9", "blessed", "chosen_one", "heart_of_wizard" };
            string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
            string selectedCombatTrait = combatActionTraits[randomCombatIndex];
            a.addTrait(selectedCombatTrait);
            int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
            string selectedElementTrait = elementTraits[randomIndex];
            a.addTrait(selectedElementTrait);
            // 创建新单位并复制数据
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(a.getName());
            act.data.health = 999;
            act.data.level = 8;
            act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
            // 执行传送和特效
            teleportRandom(act);
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool extraordinary6_deathAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            IReadOnlyCollection<ActorTrait> traits = a.getTraits();
            List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
            foreach (string traitId in allTraitIds)
            {
                a.removeTrait(traitId);
            }
            a.addTrait("extraordinary6");
            a.addTrait("interesting3_5");
            a.addTrait("arcane_reflexes");
            a.addTrait("battle_reflexes");
            a.addTrait("fast");
            // 定义可随机的元素特质列表
            string[] elementTraits = { "element0", "element1", "element3", "element4", "interesting3_8", "blessed", "chosen_one", "heart_of_wizard" };
            string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
            string selectedCombatTrait = combatActionTraits[randomCombatIndex];
            a.addTrait(selectedCombatTrait);
            int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
            string selectedElementTrait = elementTraits[randomIndex];
            // 添加随机特质到原Actor
            a.addTrait(selectedElementTrait);
            // 创建新单位并复制数据
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age_overgrowth = 1;
            act.data.level = 10;
            act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
            // 执行传送和特效
            teleportRandom(act);
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool extraordinary7_deathAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null || !pTarget.isActor())
            {
                return false;
            }
            Actor a = pTarget.a;
            IReadOnlyCollection<ActorTrait> traits = a.getTraits();
            List<string> allTraitIds = traits.Select(t => t.getId()).ToList();
            foreach (string traitId in allTraitIds)
            {
                a.removeTrait(traitId);
            }
            a.addTrait("interesting3_5");
            a.addTrait("arcane_reflexes");
            a.addTrait("battle_reflexes");
            a.addTrait("fast");
            // 定义可随机的元素特质列表
            string[] elementTraits = { "element0", "element1", "element3", "element4", "interesting3_8", "blessed", "chosen_one", "heart_of_wizard" };
            string[] combatActionTraits = { "dash", "block", "dodge", "backstep", "deflect_projectile" };
            int randomCombatIndex = UnityEngine.Random.Range(0, combatActionTraits.Length);
            string selectedCombatTrait = combatActionTraits[randomCombatIndex];
            a.addTrait(selectedCombatTrait);
            int randomIndex = UnityEngine.Random.Range(0, elementTraits.Length);
            string selectedElementTrait = elementTraits[randomIndex];
            // 添加随机特质到原Actor
            a.addTrait(selectedElementTrait);
            // 创建新单位并复制数据
            var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
            ActorTool.copyUnitToOtherUnit(a, act);
            act.data.setName(a.getName());
            act.data.health = 999;
            act.data.created_time = World.world.getCurWorldTime();
            act.data.age = 1;
            act.data.level = 5;
            act.data.saved_traits = new List<string> { selectedElementTrait + selectedCombatTrait };
            // 执行传送和特效
            teleportRandom(act);
            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(a.current_tile, null);
            return true;
        }
        public static bool teleportRandom(Actor a)
        {
            MapBox mapBox = World.world as MapBox;
            if (mapBox == null)
            {
                return false;
            }

            CitiesManager citiesManager = mapBox._list_meta_main_managers.OfType<CitiesManager>().FirstOrDefault();
            if (citiesManager == null)
            {
                return false;
            }

            List<City> cities = citiesManager.list;
            if (cities.Count == 0)
            {
                return false;
            }

            int randomIndex = UnityEngine.Random.Range(0, citiesManager.list.Count);
            City randomCity = citiesManager.list[randomIndex];

            WorldTile cityCenterTile = randomCity.getTile();
            if (cityCenterTile == null || cityCenterTile.Type.block || !cityCenterTile.Type.ground)
            {
                return false;
            }

            a.cancelAllBeh();
            a.spawnOn(cityCenterTile, 0f);
            return true;
        }
        public static bool Lifeleaves4(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addTrait("extraordinary9");
            a.removeTrait("Lifeleaves4");
            a.removeTrait("tumorInfection");
            a.removeTrait("cursed");
            a.removeTrait("infected");
            a.removeTrait("mushSpores");
            a.removeTrait("plague");
            for (int i = 0; i < 30; i++)
            {
                var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
                ActorTool.copyUnitToOtherUnit(a, act);
                act.data.setName(pTarget.a.getName());
                act.data.saved_traits = new List<string>() { "extraordinary9" };
                act.data.health = 999;
                act.data.created_time = World.world.getCurWorldTime();
                act.data.age_overgrowth = 1;
                act.data.level = 5;
                teleportRandom(act);
            }

            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);

            return true;
        }
        public static bool Lifeleaves5(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addTrait("extraordinary9");
            a.removeTrait("Lifeleaves5");
            a.removeTrait("tumorInfection");
            a.removeTrait("cursed");
            a.removeTrait("infected");
            a.removeTrait("mushSpores");
            a.removeTrait("plague");
            for (int i = 0; i < 50; i++)
            {
                var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
                ActorTool.copyUnitToOtherUnit(a, act);
                act.data.setName(pTarget.a.getName());
                act.data.saved_traits = new List<string>() { "extraordinary9" };
                act.data.health = 999;
                act.data.created_time = World.world.getCurWorldTime();
                act.data.age_overgrowth = 1;
                act.data.level = 5;
                teleportRandom(act);
            }

            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);

            return true;
        }
        public static bool Lifeleaves6(BaseSimObject pTarget, WorldTile pTile = null)
        {
            if (pTarget == null)
            {
                return false;
            }

            if (!pTarget.isActor())
            {
                return false;
            }

            Actor a = pTarget.a;
            a.addTrait("extraordinary9");
            a.removeTrait("Lifeleaves6");
            a.removeTrait("tumorInfection");
            a.removeTrait("cursed");
            a.removeTrait("infected");
            a.removeTrait("mushSpores");
            a.removeTrait("plague");
            for (int i = 0; i < 80; i++)
            {
                var act = World.world.units.createNewUnit(a.asset.id, pTile, true);
                ActorTool.copyUnitToOtherUnit(a, act);
                act.data.setName(pTarget.a.getName());
                act.data.saved_traits = new List<string>() { "extraordinary9" };
                act.data.health = 999;
                act.data.created_time = World.world.getCurWorldTime();
                act.data.age_overgrowth = 1;
                act.data.level = 5;
                teleportRandom(act);
            }

            PowerLibrary pb = new PowerLibrary();
            pb.divineLightFX(pTarget.a.current_tile, null);

            return true;
        }
    }
}