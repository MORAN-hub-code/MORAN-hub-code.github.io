﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using ReflectionUtility;
using UnityEngine;

namespace InterestingTrait.code;
internal class patch
{
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "updateStats"),HarmonyPriority(Priority.First)]
    static void Prefix(Actor __instance,ref bool __state)
    {
        __state = __instance.stats_dirty;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateStats"),HarmonyPriority(Priority.Last)]
    static void Postfix(Actor __instance,bool __state)
    {
        if (!__state)
        {
            return;
        }
        float damageMultiplier = 0.03f;
        float attackSpeedMultiplier = 0.02f;
        float bonus = __instance.data.level * damageMultiplier * __instance.stats["damage"];
        float bonus2 = __instance.data.level * attackSpeedMultiplier * __instance.stats["attack_speed"];
        __instance.stats["damage"] = __instance.stats["damage"] + bonus;
        __instance.stats["attack_speed"] = __instance.stats["attack_speed"] + bonus2;
    }
    //禁止雷电劈出永生
    [HarmonyPrefix, HarmonyPatch(typeof(MapAction), "checkLightningAction")]
    public static bool checkLightningAction(Vector2Int pPos, int pRad)
    {
		List<Actor> tList = World.world.units.getSimpleList();
        for (int i = 0; i < tList.Count; i++)
        {
            Actor tActor = tList[i];
            if (Toolbox.DistVec2(tActor.current_tile.pos, pPos) > (float)pRad) 
                continue;

            if (tActor.asset.flag_finger)
            {
                tActor.getActorComponent<GodFinger>().lightAction();
            }
            else
            {
                SignalAsset signal = SignalLibrary.check_achievement_may_i_interrupt;
                var taskID = tActor.ai.task?.id;
                SignalManager.add(signal, taskID);
            }
        }
        return false;
    }
}