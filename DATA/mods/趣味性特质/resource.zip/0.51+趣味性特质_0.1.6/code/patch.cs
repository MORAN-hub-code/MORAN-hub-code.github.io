﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General;
using ReflectionUtility;
using UnityEngine;

namespace InterestingTrait.code;
internal class patch
{
    [HarmonyPrefix, HarmonyPatch(typeof(Actor), "updateStats"),HarmonyPriority(Priority.First)]
    static void Prefix(Actor __instance,ref bool __state)
    {
        __state = __instance._stats_dirty;
    }

    [HarmonyPostfix, HarmonyPatch(typeof(Actor), "updateStats"),HarmonyPriority(Priority.Last)]
    static void Postfix(Actor __instance,bool __state)
    {
        if (!__state)
        {
            return;
        }
        float damageMultiplier = 0.03f;
        float attackSpeedMultiplier = 0.02f;
        float bonus = __instance.data.level * damageMultiplier * __instance.stats["damage"];
        float bonus2 = __instance.data.level * attackSpeedMultiplier * __instance.stats["attack_speed"];
        __instance.stats["damage"] = __instance.stats["damage"] + bonus;
        __instance.stats["attack_speed"] = __instance.stats["attack_speed"] + bonus2;
    }
}