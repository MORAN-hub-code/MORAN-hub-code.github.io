using System;
using System.IO;
using HarmonyLib;
using NeoModLoader.api;
using NeoModLoader.General;
using UnityEngine.UI;

namespace SimpleTranslation;

internal class ModClass : BasicMod<ModClass>, IReloadable
{
    protected override void OnModLoad()
    {
        Harmony.CreateAndPatchAll(typeof(Patch));
        Config.isEditor = true;
    }
    
    private bool _possession_ui_cz = false;
    private void Update()
    {
        if (LocalizedTextManager.instance.language != "cz" && LocalizedTextManager.instance.language != "ch") return;
        if (!_possession_ui_cz && PossessionUI.instance != null && PossessionUI.instance.isActiveAndEnabled)
        {
            _possession_ui_cz = true;

            void set_text(Text text, string tip_key, string key_key)
            {
                string tip = Toolbox.coloredString(LM.Get(tip_key), "white");
                string key = Toolbox.coloredString(LM.Has(key_key) ? LM.Get(key_key) : key_key, "#F3961F");
                text.text = tip + " --> [ " + key + " ]";
            }
            set_text(PossessionUI.instance._text_backstep, "possession_tip_backstep", "CONTROL");
            set_text(PossessionUI.instance._text_dash, "possession_tip_dash", "SHIFT");
            set_text(PossessionUI.instance._text_steal, "possession_tip_steal", "Q");
            set_text(PossessionUI.instance._text_yell, "possession_tip_yell", "F");
            set_text(PossessionUI.instance._text_talk, "possession_tip_talk", "T");
            set_text(PossessionUI.instance._text_walk, "possession_tip_walk", "WASD/ARROWS");
            set_text(PossessionUI.instance._text_attack, "possession_tip_attack", "LEFT CLICK");
            set_text(PossessionUI.instance._text_special, "possession_tip_special", "MIDDLE CLICK");
            set_text(PossessionUI.instance._text_jump, "possession_tip_jump", "SPACE");
            set_text(PossessionUI.instance._text_kick, "possession_tip_kick", "RIGHT CLICK");
        }
    }

    public void Reload()
    {
        LM.LoadLocale("cz", Path.Combine(GetLocaleFilesDirectory(GetDeclaration()), "cz.json"));
        LM.LoadLocale("ch", Path.Combine(GetLocaleFilesDirectory(GetDeclaration()), "ch.json"));
        LM.ApplyLocale();
    }
}

static class Patch
{
    [HarmonyPostfix, HarmonyPatch(typeof(LocalizedText), nameof(LocalizedText.Start))]
    private static void OnLocalizedTextStart(LocalizedText __instance)
    {
        if (__instance.autoField) return;
        if (LM.Has(__instance.key))
        {
            __instance.updateText();
        }
    }
}