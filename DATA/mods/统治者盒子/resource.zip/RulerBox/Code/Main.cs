using System;
using NCMS;
using UnityEngine;
using System.Collections.Generic;
using HarmonyLib;
using NCMS.Utils;

namespace RulerBox
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        public static Main instance;
        public static Kingdom selectedKingdom;
        public static string ModPath;

        void Awake()
        {
            instance = this;
            Config.show_console_on_error = false;
            ModPath = System.AppDomain.CurrentDomain.BaseDirectory;
            // UI Systems
            KingdomUI.Initialize();
            LawsUI.Initialize();
            DiplomacyUI.Initialize();
        }

        private void Update()
        {
            // Open kingdomUI
            if (Input.GetKeyDown(KeyCode.K))
            {
                var targetTile = World.world.getMouseTilePos();
                if (targetTile != null && !targetTile.zone.hasCity())
                {
                    return;
                }
                var tKingdom = targetTile.zone.city.kingdom;
                if (tKingdom != null && tKingdom.isCiv())
                {
                    CloseAllWindows();
                    selectedKingdom = tKingdom;
                    KingdomUI.ToggleVisibility();
                    KingdomUI.ShowKingdomInfo();
                }
            }

            if(Config._paused == false){
                if (selectedKingdom != null)
                {
                    LawsUI.UpdateInfoBox();
                    LawsUI.RefreshHappinessIcon();
                    KingdomUI.ShowKingdomInfo();
                    LawSystem.Update(Time.deltaTime);
                }
                else{
                    CloseAllWindows();
                }
            }
        }

        public static void CloseAllWindows()
        {
            KingdomUI.SetVisibility(false);
            LawsUI.SetVisibility(false);
            DiplomacyUI.SetVisibility(false);
        }
    }
}