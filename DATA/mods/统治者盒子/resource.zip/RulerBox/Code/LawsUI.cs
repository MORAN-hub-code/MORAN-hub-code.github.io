using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NCMS;
using NCMS.Utils;

namespace RulerBox
{
    public static class LawsUI
    {
        private static GameObject LawsDisplay;
        private static GameObject CategoryBar;
        private static GameObject Content;
        private static GameObject ActiveLawsContainer;
        private static Text infoText;
        private static Dictionary<string, GameObject> categoryBars = new();
        public static List<LawData> laws = new();
        private static Image happinessIcon;

        public static string currentCategory = "城市法";

        public static void Initialize()
        {
            LoadLawsFromJSON();
            CreateLawsUI();
            SetVisibility(false);
        }

        private static void LoadLawsFromJSON()
        {
            string path = System.IO.Path.Combine(
                Main.ModPath,
                "Mods", "RulerBox", "Code", "Json", "laws.json"
            );
            //Debug.Log(path);
            if (System.IO.File.Exists(path))
            {
                string json = System.IO.File.ReadAllText(path);
                laws = Newtonsoft.Json.JsonConvert.DeserializeObject<List<LawData>>(json);
            }
            else
            {
                laws = new List<LawData>();
                Debug.LogWarning("[LawsUI] Could not find laws.json");
            }
        }

        private static void CreateLawsUI()
        {
            LawsDisplay = new GameObject("LawsDisplay");
            LawsDisplay.transform.SetParent(DebugConfig.instance.transform);

            Image bg = LawsDisplay.AddComponent<Image>();
            bg.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI.LawsUI.png");
            bg.type = Image.Type.Sliced;

            RectTransform rt = LawsDisplay.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(1f, 0.63f);
            rt.anchorMax = new Vector2(1f, 0.63f);
            rt.pivot = new Vector2(1f, 0.63f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(585, 650);

            CreateLeftPanel();
            CreateRightInfoBox();
            CreateCategoryButtons();
            CreateScrollArea();
        }

        private static void CreateLeftPanel()
        {
            GameObject leftPanel = new GameObject("LeftPanel");
            leftPanel.transform.SetParent(LawsDisplay.transform);
            RectTransform rt = leftPanel.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.15f, 0.875f);
            rt.anchorMax = new Vector2(0.15f, 0.875f);
            rt.pivot = new Vector2(0.15f, 0.875f);
            rt.anchoredPosition = new Vector2(0, 0);
            rt.sizeDelta = new Vector2(80, 80);

            happinessIcon = leftPanel.AddComponent<Image>();
            happinessIcon.sprite = Resources.Load<Sprite>("ui/icons/iconHumans");
            happinessIcon.preserveAspect = true;
        }

        public static void RefreshHappinessIcon()
        {
            if (happinessIcon == null) return;

            int level = GetHappinessLevel(Main.selectedKingdom);
            //Debug.Log(level);
            happinessIcon.sprite = Mod.EmbededResources.LoadSprite($"RulerBox.Resources.UI.iconHappiness_{level}.png");
        }

        private static void CreateRightInfoBox()
        {
            GameObject infoPanel = new GameObject("InfoPanel");
            infoPanel.transform.SetParent(LawsDisplay.transform);
            RectTransform panelRT = infoPanel.AddComponent<RectTransform>();
            panelRT.anchorMin = new Vector2(0.75f, 0.9f);
            panelRT.anchorMax = new Vector2(0.75f, 0.9f);
            panelRT.pivot = new Vector2(0.75f, 0.9f);
            panelRT.anchoredPosition = Vector2.zero;
            panelRT.sizeDelta = new Vector2(310, 120);

            Image bg = infoPanel.AddComponent<Image>();
            bg.color = new Color(0.15f, 0.15f, 0.15f, 0.00001f);

            // ScrollRect
            GameObject scrollGO = new GameObject("InfoScroll");
            scrollGO.transform.SetParent(infoPanel.transform, false);
            RectTransform scrollRT = scrollGO.AddComponent<RectTransform>();
            scrollRT.anchorMin = Vector2.zero;
            scrollRT.anchorMax = Vector2.one;
            scrollRT.offsetMin = Vector2.zero;
            scrollRT.offsetMax = Vector2.zero;

            Image scrollImg = scrollGO.AddComponent<Image>();
            scrollImg.color = new Color(0, 0, 0, 0.000001f);

            ScrollRect scroll = scrollGO.AddComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.scrollSensitivity = 25f;
            scroll.movementType = ScrollRect.MovementType.Elastic;

            // Viewport
            GameObject viewport = new GameObject("Viewport");
            viewport.transform.SetParent(scrollGO.transform, false);
            RectTransform viewportRT = viewport.AddComponent<RectTransform>();
            viewportRT.anchorMin = Vector2.zero;
            viewportRT.anchorMax = Vector2.one;
            viewportRT.offsetMin = Vector2.zero;
            viewportRT.offsetMax = Vector2.zero;

            Image viewportImg = viewport.AddComponent<Image>();
            viewportImg.color = new Color(0, 0, 0, 0.01f);
            Mask mask = viewport.AddComponent<Mask>();
            mask.showMaskGraphic = false;

            scroll.viewport = viewportRT;

            // Content (Text holder)
            GameObject textContent = new GameObject("InfoContent");
            textContent.transform.SetParent(viewport.transform, false);
            RectTransform contentRT = textContent.AddComponent<RectTransform>();
            contentRT.anchorMin = new Vector2(0, 1);
            contentRT.anchorMax = new Vector2(1, 1);
            contentRT.pivot = new Vector2(0.5f, 1);
            contentRT.anchoredPosition = Vector2.zero;
            contentRT.sizeDelta = new Vector2(0, 0);

            ContentSizeFitter fitter = textContent.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            VerticalLayoutGroup layout = textContent.AddComponent<VerticalLayoutGroup>();
            layout.childForceExpandHeight = false;
            layout.childForceExpandWidth = true;
            layout.childControlHeight = true;
            layout.childControlWidth = true;

            // Text
            GameObject textGO = new GameObject("InfoText");
            textGO.transform.SetParent(textContent.transform, false);
            infoText = textGO.AddComponent<Text>();
            infoText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            infoText.fontSize = 14;
            infoText.alignment = TextAnchor.UpperLeft;
            infoText.color = new Color(0.9f, 0.6f, 0, 1);
            infoText.horizontalOverflow = HorizontalWrapMode.Wrap;
            infoText.verticalOverflow = VerticalWrapMode.Overflow;

            RectTransform textRT = textGO.GetComponent<RectTransform>();
            textRT.anchorMin = Vector2.zero;
            textRT.anchorMax = Vector2.one;
            textRT.offsetMin = Vector2.zero;
            textRT.offsetMax = Vector2.zero;

            scroll.content = contentRT;
        }

        public static void UpdateInfoBox()
        {
            var actor = Main.selectedKingdom.king;
            if (actor == null || infoText == null || actor.kingdom == null)
                return;

            int gold = actor.data.money;
            Kingdom kingdom = actor.kingdom;

            // Income
            int pop = kingdom.getPopulationPeople();
            float rate = kingdom.getTaxRateTribute();
            float incomePerSecond = (pop * rate) / 5f;

            // Active laws and expenses
            Dictionary<string, float> expenseByCategory = new();
            float totalExpensePerSecond = 0f;

            foreach (var lawId in LawSystem.GetActiveLaws())
            {
                var law = laws.FirstOrDefault(l => l.id == lawId);
                if (law == null)
                    continue;

                // Handle scaling cost
                float cost = law.scalesWithPopulation ? (law.cost * pop) : law.cost;
                float costPerSecond = cost / 5f;

                if (costPerSecond <= 0f)
                    continue;

                totalExpensePerSecond += costPerSecond;

                if (!expenseByCategory.ContainsKey(law.category))
                    expenseByCategory[law.category] = 0f;

                expenseByCategory[law.category] += costPerSecond;
            }

            // Net income
            float netGoldPerSecond = incomePerSecond - totalExpensePerSecond;

            // Happiness
            float ratio = GetHappinessRatio(Main.selectedKingdom);
            int percent = Mathf.RoundToInt(ratio * 100);

            // Build output
            string output = $"<b>王国法律简介</b>\n\n" +
                            $"幸福度: {percent} %\n" +
                            $"黄金: {gold} g\n" +
                            $"收入: {incomePerSecond:F2} g/sec (人口: {pop}, 比例: {rate:F2})\n";

            // Only show expenses if there are any
            if (expenseByCategory.Count > 0)
            {
                output += $"\n<b>花费:</b>\n";
                foreach (var kvp in expenseByCategory.OrderBy(e => e.Key))
                {
                    output += $"- {kvp.Key}: {kvp.Value:F2} g/sec\n";
                }
            }

            // Net income
            string netColor = netGoldPerSecond >= 0 ? "#00FF00" : "#FF4444";
            output += $"\n<b>净:</b> <color={netColor}>{(netGoldPerSecond >= 0 ? "+" : "")}{netGoldPerSecond:F2} g/sec</color>";

            infoText.text = output;
        }



        private static void CreateCategoryButtons()
        {
            CategoryBar = new GameObject("CategoryBar");
            CategoryBar.transform.SetParent(LawsDisplay.transform);
            RectTransform rt = CategoryBar.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = new Vector2(0, -10);
            rt.sizeDelta = new Vector2(400, 400);

            HorizontalLayoutGroup layout = CategoryBar.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = 10;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childForceExpandWidth = false;

            AddCategoryButton("城市法", 0.15f);
            AddCategoryButton("军法", 0.50f);
            AddCategoryButton("资源法", 0.845f);
        }

        private static void AddCategoryButton(string category, float xPos)
        {
            GameObject buttonGO = new GameObject(category + "Button");
            buttonGO.transform.SetParent(LawsDisplay.transform, false);

            RectTransform buttonRect = buttonGO.AddComponent<RectTransform>();
            buttonRect.anchorMin = new Vector2(xPos, 0.705f);
            buttonRect.anchorMax = new Vector2(xPos, 0.705f);
            buttonRect.pivot = new Vector2(xPos, 0.705f);
            buttonRect.anchoredPosition = Vector2.zero;
            buttonRect.sizeDelta = new Vector2(100, 60);

            Image buttonImage = buttonGO.AddComponent<Image>();
            buttonImage.color = new Color(0.2f, 0.2f, 0.2f, 0f);

            Button buttonComponent = buttonGO.AddComponent<Button>();
            buttonComponent.targetGraphic = buttonImage;
            buttonComponent.onClick.AddListener(() =>
            {
                currentCategory = category;
                DisplayCategory(category);
            });

            GameObject textGO = new GameObject("ButtonText");
            textGO.transform.SetParent(buttonGO.transform, false);
            textGO.AddComponent<RectTransform>();

            Text textComponent = textGO.AddComponent<Text>();
            textComponent.text = category;
            textComponent.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            textComponent.color = new Color(0.9f, 0.6f, 0, 1);
            textComponent.fontSize = 18;
            textComponent.fontStyle = FontStyle.Bold;
            textComponent.alignment = TextAnchor.MiddleCenter;

            RectTransform textRect = textComponent.GetComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;
        }

        private static void CreateScrollArea()
        {
            // ── Scroll container (the “frame”)
            GameObject scrollGO = new GameObject("ScrollContainer");
            scrollGO.transform.SetParent(LawsDisplay.transform, false);

            RectTransform scrollRT = scrollGO.AddComponent<RectTransform>();
            scrollRT.anchorMin = new Vector2(0.5f, 0.21f);
            scrollRT.anchorMax = new Vector2(0.5f, 0.21f);
            scrollRT.pivot = new Vector2(0.5f, 0.21f);
            scrollRT.anchoredPosition = new Vector2(0, -10);
            scrollRT.sizeDelta = new Vector2(460, 360);

            // make it mask-able but invisible
            Image frameImg = scrollGO.AddComponent<Image>();
            frameImg.color = new Color(0, 0, 0, 0.01f);      // transparent
            Mask frameMsk = scrollGO.AddComponent<Mask>();
            frameMsk.showMaskGraphic = false;

            // ── Viewport (mandatory child for ScrollRect)
            GameObject viewGO = new GameObject("Viewport");
            viewGO.transform.SetParent(scrollGO.transform, false);
            RectTransform viewRT = viewGO.AddComponent<RectTransform>();
            viewRT.anchorMin = Vector2.zero;
            viewRT.anchorMax = Vector2.one;
            viewRT.offsetMin = Vector2.zero;
            viewRT.offsetMax = Vector2.zero;

            ScrollRect scroll = scrollGO.AddComponent<ScrollRect>();
            scroll.horizontal = false;
            scroll.scrollSensitivity = 25f;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.viewport = viewRT;

            Image viewImg = viewGO.AddComponent<Image>();    // transparent mask
            viewImg.color = new Color(0, 0, 0, 0.01f);
            Mask viewMask = viewGO.AddComponent<Mask>();
            viewMask.showMaskGraphic = false;

            // ── Content (holds the rows)
            Content = new GameObject("LawContent");
            Content.transform.SetParent(viewGO.transform, false);
            RectTransform contentRT = Content.AddComponent<RectTransform>();
            contentRT.anchorMin = new Vector2(0, 1);           // top-left origin
            contentRT.anchorMax = new Vector2(1, 1);
            contentRT.pivot = new Vector2(0.5f, 1);
            contentRT.anchoredPosition = Vector2.zero;
            contentRT.sizeDelta = Vector2.zero;

            // vertical layout so rows stack
            VerticalLayoutGroup vlay = Content.AddComponent<VerticalLayoutGroup>();
            vlay.spacing = 4;
            vlay.childAlignment = TextAnchor.UpperCenter;
            vlay.childForceExpandWidth = true;
            vlay.childForceExpandHeight = false;
            vlay.childControlWidth = true;
            vlay.childControlHeight = true;

            // make Content grow automatically
            ContentSizeFitter fit = Content.AddComponent<ContentSizeFitter>();
            fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // hook it to ScrollRect
            scroll.content = contentRT;
            scroll.vertical = true;
        }

        public static void DisplayCategory(string category)
        {
            // wipe previous rows
            foreach (Transform child in Content.transform)
                GameObject.Destroy(child.gameObject);

            // build one row (hub) per law
            foreach (LawData law in laws.Where(l => l.category == category))
            {
                // HUB  (one line in the list)
                GameObject hub = new GameObject($"LawHub_{law.id}");
                hub.transform.SetParent(Content.transform, false);

                // Let VerticalLayoutGroup determine width; just give preferred height
                LayoutElement hubLE = hub.AddComponent<LayoutElement>();
                hubLE.preferredHeight = 80;

                Image hubBg = hub.AddComponent<Image>();
                hubBg.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI.LawsUIHub.png");
                hubBg.type = Image.Type.Sliced;

                // add HorizontalLayoutGroup for icon | text | ❌
                HorizontalLayoutGroup hl = hub.AddComponent<HorizontalLayoutGroup>();
                hl.padding = new RectOffset(40, 12, 6, 6);
                hl.spacing = 8;
                hl.childAlignment = TextAnchor.MiddleCenter;
                hl.childForceExpandWidth = false;
                hl.childForceExpandHeight = false;

                // ── ICON
                GameObject iconGO = new GameObject("Icon");
                iconGO.transform.SetParent(hub.transform, false);
                Image iconImg = iconGO.AddComponent<Image>();
                iconImg.sprite = Mod.EmbededResources.LoadSprite($"RulerBox.Resources.Laws.{law.icon}.png");
                LayoutElement iconLE = iconGO.AddComponent<LayoutElement>();
                iconLE.preferredWidth = iconLE.preferredHeight = 32;

                // ── TEXT
                GameObject txtGO = new GameObject("LawText");
                txtGO.transform.SetParent(hub.transform, false);
                Text txt = txtGO.AddComponent<Text>();
                txt.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                txt.text = $"<b>{law.name}</b>\n<size=11>{law.description}</size>";
                txt.color = new Color(1f, .9f, .6f);
                txt.fontSize = 14;
                txt.alignment = TextAnchor.MiddleCenter;

                LayoutElement txtLE = txtGO.AddComponent<LayoutElement>();
                txtLE.flexibleWidth = 1;     // steals remaining space

                // ── BUTTON (dynamic: Apply or Remove)
                GameObject btnGO = new GameObject("LawActionBtn");
                btnGO.transform.SetParent(hub.transform, false);
                Image btnImg = btnGO.AddComponent<Image>();
                Button btn = btnGO.AddComponent<Button>();
                LayoutElement btnLE = btnGO.AddComponent<LayoutElement>();
                btnLE.preferredWidth = btnLE.preferredHeight = 54;
                btnImg.sprite = Mod.EmbededResources.LoadSprite(
                    LawSystem.IsLawActive(law.id)
                    ? "RulerBox.Resources.UI.Y.png"
                    : "RulerBox.Resources.UI.X.png"
                );

                btn.onClick.AddListener(() =>
                {
                    if (LawSystem.IsLawActive(law.id))
                    {
                        LawSystem.RemoveLaw(law.id);
                    }
                    else
                    {
                        LawSystem.ApplyLaw(law.id);
                    }

                    DisplayCategory(category);
                    UpdateInfoBox();
                });
            }
        }

        public static void SetVisibility(bool visible) => LawsDisplay?.SetActive(visible);
        public static void ToggleVisibility() => SetVisibility(!LawsDisplay.activeSelf);

        public static List<LawData> GetAllLaws()
        {
            return laws;
        }

        private static int GetHappinessLevel(Kingdom kingdom)
        {
            if (kingdom == null)
                return 1;

            int happy = 0;
            int total = 0;

            foreach (Actor unit in kingdom.units)
            {
                if (!unit.isAlive() || unit.asset.is_boat)
                    continue;

                total++;
                if (unit.isHappy())
                    happy++;
            }

            if (total == 0) return 1;

            float ratio = (float)happy / total;
            //Debug.Log($"[HappinessLevel] Happy: {happy}/{total} = {ratio}");

            if (ratio >= 0.95f) return 6;
            else if (ratio >= 0.80f) return 5;
            else if (ratio >= 0.65f) return 4;
            else if (ratio >= 0.45f) return 3;
            else if (ratio >= 0.25f) return 2;
            else return 1;
        }

        private static float GetHappinessRatio(Kingdom kingdom){
            if (kingdom == null || kingdom.units.Count == 0)
                return 0f;

            int happy = 0;
            int total = 0;

            foreach (Actor unit in kingdom.units)
            {
                if (!unit.isAlive() || unit.asset.is_boat)
                    continue;

                total++;
                if (unit.isHappy())
                    happy++;
            }

            if (total == 0) return 0f;

            return (float)happy / total; 
        }

        public static bool IsVisible() => LawsDisplay != null && LawsDisplay.activeSelf;
    }

    public class LawData
    {
        public string id;
        public string category;
        public string name;
        public string description;
        public string icon;
        public string action;
        public float cost;
        public int happiness;
        public bool scalesWithPopulation;
    }
}
