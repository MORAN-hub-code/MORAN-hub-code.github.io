using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using NCMS.Utils;

namespace RulerBox
{
    public static class DiplomacyUI
    {
        private static GameObject DiplomacyDisplay;
        private static GameObject ScrollContainer;

        public static void Initialize()
        {
            CreateDiplomacyUI();
            SetVisibility(false);
        }

        private static void CreateDiplomacyUI()
        {
            DiplomacyDisplay = new GameObject("DiplomacyDisplay");
            DiplomacyDisplay.transform.SetParent(DebugConfig.instance?.transform);

            Image bg = DiplomacyDisplay.AddComponent<Image>();
            bg.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI.Diplomacy.png");

            RectTransform rt = DiplomacyDisplay.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.98f, 0.545f);
            rt.anchorMax = new Vector2(0.98f, 0.545f);
            rt.pivot = new Vector2(0.98f, 0.545f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(800, 500);

            // Create Viewport
            GameObject viewportGO = new GameObject("Viewport");
            viewportGO.transform.SetParent(DiplomacyDisplay.transform, false);
            RectTransform viewportRT = viewportGO.AddComponent<RectTransform>();
            viewportRT.anchorMin = new Vector2(0.5f, 0.6f);   
            viewportRT.anchorMax = new Vector2(0.5f, 0.6f);  
            viewportRT.pivot = new Vector2(0.5f, 0.6f);
            viewportRT.anchoredPosition = new Vector2(0f, -10f);
            viewportRT.sizeDelta = new Vector2(730f, 408f);      
            Image viewportImage = viewportGO.AddComponent<Image>();
            viewportImage.color = new Color(0, 0, 0, 0.01f); 
            viewportGO.AddComponent<Mask>().showMaskGraphic = true; // enables clipping

            // Create ScrollRect and attach viewport
            GameObject scrollGO = new GameObject("ScrollRect");
            scrollGO.transform.SetParent(viewportGO.transform, false);
            ScrollRect scroll = scrollGO.AddComponent<ScrollRect>();
            scroll.viewport = viewportRT;
            RectTransform scrollRT = scrollGO.GetComponent<RectTransform>();
            scrollRT.anchorMin = new Vector2(0, 0);
            scrollRT.anchorMax = new Vector2(1, 1);
            scrollRT.offsetMin = Vector2.zero;
            scrollRT.offsetMax = Vector2.zero;

            // Content
            GameObject contentGO = new GameObject("Content");
            contentGO.transform.SetParent(scrollGO.transform, false);
            RectTransform contentRT = contentGO.AddComponent<RectTransform>();
            contentRT.anchorMin = new Vector2(0, 1);
            contentRT.anchorMax = new Vector2(1, 1);
            contentRT.pivot = new Vector2(0.5f, 1f);
            contentRT.anchoredPosition = Vector2.zero;
            contentRT.sizeDelta = new Vector2(0, 0);

            // Layout
            VerticalLayoutGroup layout = contentGO.AddComponent<VerticalLayoutGroup>();
            layout.childForceExpandHeight = false;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.spacing = 5f;
            ContentSizeFitter fitter = contentGO.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            // Final setup
            scroll.content = contentRT;
            scroll.vertical = true;
            ScrollContainer = contentGO;
        }

        private static void CreateDiplomacyRow(Kingdom target)
        {
            GameObject row = new GameObject("DiploRow_" + target.data.name);
            row.transform.SetParent(ScrollContainer.transform, false);

            RectTransform rt = row.AddComponent<RectTransform>();
            rt.sizeDelta = new Vector2(60, 60);

            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.preferredHeight = 60;
            rowLayout.minHeight = 60;

            HorizontalLayoutGroup hLayout = row.AddComponent<HorizontalLayoutGroup>();
            hLayout.childAlignment = TextAnchor.MiddleLeft;
            hLayout.spacing = 10;
            hLayout.childControlHeight = true;
            hLayout.childControlWidth = true;
            hLayout.childForceExpandWidth = false;
            hLayout.childForceExpandHeight = true;

            Image rowDebug = row.AddComponent<Image>();
            rowDebug.color = new Color(1f, 1f, 1f, 0.01f); // light gray

            // --- LeftSlot (Banner)
            GameObject leftSlot = new GameObject("LeftSlot");
            leftSlot.transform.SetParent(row.transform, false);
            RectTransform leftSlotRT = leftSlot.AddComponent<RectTransform>();
            leftSlotRT.sizeDelta = new Vector2(50, 60);
            LayoutElement leftLayout = leftSlot.AddComponent<LayoutElement>();
            leftLayout.preferredWidth = 50;
            leftLayout.minWidth = 50;

            // Background Layer
            GameObject bannerBg = new GameObject("BannerBackground");
            bannerBg.transform.SetParent(leftSlot.transform, false);
            RectTransform bgRT = bannerBg.AddComponent<RectTransform>();
            bgRT.anchorMin = Vector2.zero;
            bgRT.anchorMax = Vector2.one;
            bgRT.offsetMin = Vector2.zero;
            bgRT.offsetMax = Vector2.zero;

            Image bgImg = bannerBg.AddComponent<Image>();

            // Icon Layer
            GameObject bannerIcon = new GameObject("BannerIcon");
            bannerIcon.transform.SetParent(leftSlot.transform, false);
            RectTransform iconRT = bannerIcon.AddComponent<RectTransform>();
            iconRT.anchorMin = Vector2.zero;
            iconRT.anchorMax = Vector2.one;
            iconRT.offsetMin = Vector2.zero;
            iconRT.offsetMax = Vector2.zero;

            Image iconImg = bannerIcon.AddComponent<Image>();

            if (target != null)
            {
                bgImg.sprite = target.getElementBackground();
                bgImg.color = target.kingdomColor.getColorMain2();

                iconImg.sprite = target.getElementIcon();
                iconImg.color = target.kingdomColor.getColorBanner();
            }

            // --- Green: LabelContainer (narrower)
            GameObject labelContainer = new GameObject("LabelContainer");
            labelContainer.transform.SetParent(row.transform, false);
            RectTransform labelRect = labelContainer.AddComponent<RectTransform>();
            labelRect.sizeDelta = new Vector2(0, 40);
            LayoutElement labelLayout = labelContainer.AddComponent<LayoutElement>();
            labelLayout.flexibleWidth = 1f;
            labelLayout.minWidth = 100;

            Image labelBg = labelContainer.AddComponent<Image>();
            labelBg.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI.DiplomacyHub.png");
            labelBg.type = Image.Type.Sliced;
            //labelBg.color = new Color(0f, 1f, 0f, 0.2f); // green

            GameObject labelGO = new GameObject("Label");
            labelGO.transform.SetParent(labelContainer.transform, false);
            Text label = labelGO.AddComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            label.fontSize = 16;
            label.color = new Color(0.9f, 0.6f, 0, 1);
            label.alignment = TextAnchor.MiddleCenter;

            string name = target.data.name;
            string king = target.king?.getName() ?? "None";
            int pop = target.getPopulationTotal();
            int cities = target.countCities();

            label.text = $" <b>{name}</b> " + $"King: {king} | Cities: {cities} " + $"Population: {pop}";

            RectTransform lrt = label.GetComponent<RectTransform>();
            lrt.anchorMin = Vector2.zero;
            lrt.anchorMax = Vector2.one;
            lrt.offsetMin = Vector2.zero;
            lrt.offsetMax = Vector2.zero;

            // --- Blue: ButtonContainer (wider)
            GameObject buttonContainer = new GameObject("ButtonContainer");
            buttonContainer.transform.SetParent(row.transform, false);
            HorizontalLayoutGroup buttonsLayout = buttonContainer.AddComponent<HorizontalLayoutGroup>();
            buttonsLayout.spacing = 5f;
            buttonsLayout.childAlignment = TextAnchor.MiddleRight;
            buttonsLayout.childForceExpandWidth = false;
            buttonsLayout.childForceExpandHeight = false;

            RectTransform buttonContainerRT = buttonContainer.GetComponent<RectTransform>();
            buttonContainerRT.sizeDelta = new Vector2(243, 40);
            LayoutElement buttonLayout = buttonContainer.AddComponent<LayoutElement>();
            buttonLayout.preferredWidth = 243;

            Kingdom myKingdom = Main.selectedKingdom;
            AddDiploButton(buttonContainer, "战争", "WarBtn.png", () => {
                WarTypeAsset warType = AssetManager.war_types_library.get("normal");
                World.world.wars.newWar(myKingdom, target, warType);
                if (warType != null)
                    WorldTip.showNow($"<b>{myKingdom.data.name}</b> has declared war on <b>{target.data.name}</b>!", false, "top", 2.5f, "#FF4444");
                    
            });

            AddDiploButton(buttonContainer, "和平", "PeaceBtn.png", () => {
                War war = World.world.wars.getWar(myKingdom, target, true);
                if (war != null)
                    World.world.wars.endWar(war, WarWinner.Peace);
            });

            AddDiploButton(buttonContainer, "联盟", "allianceBtn.png", () => {
                World.world.alliances.forceAlliance(myKingdom, target);
            });

            AddDiploButton(buttonContainer, "解散联盟", "NotallianceBtn.png", () => {
                Alliance a = myKingdom.getAlliance();
                if (a != null && a.kingdoms_hashset.Contains(target))
                {
                    a.leave(myKingdom, true);
                    a.leave(target, true);
                }
            });
        }

        private static void AddDiploButton(GameObject parent, string name, string iconName, UnityEngine.Events.UnityAction action)
        {
            GameObject btnGO = new GameObject(name + "Btn");
            btnGO.transform.SetParent(parent.transform, false);

            Button btn = btnGO.AddComponent<Button>();
            Image img = btnGO.AddComponent<Image>();
            img.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI." + iconName);
            btn.targetGraphic = img;
            btn.onClick.AddListener(action);

            RectTransform rt = btnGO.GetComponent<RectTransform>();
            var layout = btnGO.AddComponent<LayoutElement>();
            layout.preferredWidth = 146;
            layout.preferredHeight = 156;
        }


        public static void ShowDiplomacy()
        {
            ClearRows();

            foreach (Kingdom k in World.world.kingdoms.list)
            {
                if (k == Main.selectedKingdom) continue; 
                CreateDiplomacyRow(k);
            }

            SetVisibility(true);
        }

        private static void ClearRows()
        {
            foreach (Transform child in ScrollContainer.transform)
            {
                GameObject.Destroy(child.gameObject);
            }
        }

        public static void SetVisibility(bool visible)
        {
            if (DiplomacyDisplay != null)
            {
                DiplomacyDisplay.SetActive(visible);
            }
        }

        public static bool IsVisible() => DiplomacyDisplay != null && DiplomacyDisplay.activeSelf;
    }
}