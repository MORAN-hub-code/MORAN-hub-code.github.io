using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using NCMS.Utils;

namespace RulerBox
{
    public static class KingdomUI
    {
        private static GameObject KingdomDisplay;
        private static GameObject bannerGO;
        private static GameObject infoPanel;
        private static Text infoText;
        private static Image bg;

        public static void Initialize()
        {
            CreateKingdomUI();
            SetVisibility(false); 
        }

        private static void CreateKingdomUI()
        {
            KingdomDisplay = new GameObject("KingdomDisplay");
            KingdomDisplay.transform.SetParent(DebugConfig.instance?.transform); 

            bg = KingdomDisplay.AddComponent<Image>();
            bg.sprite = Mod.EmbededResources.LoadSprite("RulerBox.Resources.UI.TalkUI.png");
            bg.raycastTarget = true;

            var clickTrigger = KingdomDisplay.AddComponent<EventTrigger>();
            var entry = new EventTrigger.Entry();
            entry.eventID = EventTriggerType.PointerClick;
            entry.callback.AddListener((data) => { 
                SetVisibility(false);
                CloseAllWindows();
            });
            clickTrigger.triggers.Add(entry);

            RectTransform rt = KingdomDisplay.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.13f, 1f); 
            rt.anchorMax = new Vector2(0.13f, 1f);
            rt.pivot = new Vector2(0.13f, 1f);      
            rt.anchoredPosition = Vector2.zero;       
            rt.sizeDelta = new Vector2(555, 170);

            // Banner Container
            bannerGO = new GameObject("BannerGO");
            bannerGO.transform.SetParent(KingdomDisplay.transform);

            RectTransform bannerRect = bannerGO.AddComponent<RectTransform>();
            bannerRect.anchorMin = new Vector2(0.1f, 0.58f);
            bannerRect.anchorMax = new Vector2(0.1f, 0.58f);
            bannerRect.pivot = new Vector2(0.1f, 0.58f);
            bannerRect.anchoredPosition = Vector2.zero;
            bannerRect.sizeDelta = new Vector2(90, 90);

            // Background Layer
            GameObject bannerBg = new GameObject("BannerBackground");
            bannerBg.transform.SetParent(bannerGO.transform, false);
            Image bgImage = bannerBg.AddComponent<Image>();

            RectTransform bgRect = bannerBg.GetComponent<RectTransform>();
            bgRect.anchorMin = Vector2.zero;
            bgRect.anchorMax = Vector2.one;
            bgRect.offsetMin = Vector2.zero;
            bgRect.offsetMax = Vector2.zero;

            // Icon Layer
            GameObject bannerIcon = new GameObject("BannerIcon");
            bannerIcon.transform.SetParent(bannerGO.transform, false);
            Image iconImage = bannerIcon.AddComponent<Image>();

            RectTransform iconRect = bannerIcon.GetComponent<RectTransform>();
            iconRect.anchorMin = Vector2.zero;
            iconRect.anchorMax = Vector2.one;
            iconRect.offsetMin = Vector2.zero;
            iconRect.offsetMax = Vector2.zero;

            // Info Panel
            CreateInfoPanel();

            // Buttons
            CreateButton("简介", 0.39f, () =>
            {
                Config.selected_kingdom = Main.selectedKingdom;
                ScrollWindow.showWindow("kingdom", false, false);
            });

            CreateButton("法律", 0.61f, () =>
            {
                if (LawsUI.IsVisible())
                    LawsUI.SetVisibility(false);
                else
                {
                    CloseAllWindows();
                    LawsUI.SetVisibility(true);
                }
            });

            CreateButton("外交", 0.83f, () =>
            {
                if (DiplomacyUI.IsVisible())
                    DiplomacyUI.SetVisibility(false);
                else
                {
                    CloseAllWindows();
                    DiplomacyUI.ShowDiplomacy();
                }
            });

        }

        public static void CloseAllWindows()
        {
            DiplomacyUI.SetVisibility(false);
            LawsUI.SetVisibility(false);
        }

        private static void CreateInfoPanel()
        {
            infoPanel = new GameObject("InfoPanel");
            infoPanel.transform.SetParent(KingdomDisplay.transform);
            
            Image panelImage = infoPanel.AddComponent<Image>();
            panelImage.color = new Color(0.5f, 0.1f, 0.1f, 0f);
            
            RectTransform infoRect = infoPanel.GetComponent<RectTransform>();
            infoRect.anchorMin = new Vector2(0.9f, 0.5f);
            infoRect.anchorMax = new Vector2(0.9f, 0.5f);
            infoRect.pivot = new Vector2(0.9f, 0.5f); 
            infoRect.anchoredPosition = new Vector2(-20, 20);
            infoRect.sizeDelta = new Vector2(380, 100);

            GameObject textGO = new GameObject("InfoText");
            textGO.transform.SetParent(infoPanel.transform);
            
            RectTransform textRect = textGO.AddComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.sizeDelta = Vector2.zero;
            textRect.offsetMin = new Vector2(10, 10); 
            textRect.offsetMax = new Vector2(-10, -10); 
            
            infoText = textGO.AddComponent<Text>();
            var font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (font != null) infoText.font = font;
            infoText.color = new Color(0.9f, 0.6f, 0, 1);
            infoText.fontSize = 16;
            infoText.alignment = TextAnchor.MiddleCenter;
            infoText.horizontalOverflow = HorizontalWrapMode.Wrap;
            infoText.verticalOverflow = VerticalWrapMode.Overflow;
            infoText.text = "Info";
        }

        private static void CreateButton(string buttonText, float xPosition, UnityEngine.Events.UnityAction onClickAction)
        {
            GameObject buttonGO = new GameObject(buttonText + "Button");
            buttonGO.transform.SetParent(KingdomDisplay.transform, false);

            RectTransform buttonRect = buttonGO.AddComponent<RectTransform>();
            buttonRect.anchorMin = new Vector2(xPosition, 0.02f);
            buttonRect.anchorMax = new Vector2(xPosition, 0.02f);
            buttonRect.pivot = new Vector2(0.5f, 0.02f);
            buttonRect.anchoredPosition = Vector2.zero;
            buttonRect.sizeDelta = new Vector2(100, 60);

            Image buttonImage = buttonGO.AddComponent<Image>();
            buttonImage.color = new Color(0.2f, 0.2f, 0.2f, 0f);

            Button buttonComponent = buttonGO.AddComponent<Button>();
            buttonComponent.targetGraphic = buttonImage;
            buttonComponent.onClick.AddListener(onClickAction);

            GameObject textGO = new GameObject("ButtonText");
            textGO.transform.SetParent(buttonGO.transform, false);
            textGO.AddComponent<RectTransform>();

            Text textComponent = textGO.AddComponent<Text>();
            var font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (font != null) textComponent.font = font;
            textComponent.text = buttonText;
            textComponent.color = Color.white;
            textComponent.fontSize = 18;
            textComponent.fontStyle = FontStyle.Bold;
            textComponent.alignment = TextAnchor.MiddleCenter;

            RectTransform textRect = textComponent.GetComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;
        }

        public static void ShowKingdomInfo()
        {
            if (KingdomDisplay == null) Initialize();
            
            if (Main.selectedKingdom != null)
            {
                Kingdom k = Main.selectedKingdom;

                string name = k.data.name;
                string king = k.king?.getName() ?? "None";
                int pop = k.getPopulationTotal();
                int cities = k.countCities();
                string motto = k.getMotto();

                infoText.text = $"\n<b>{name}</b>\n" +
                                $"国王: {king} | 城市: {cities}\n" +
                                $"人口: {pop}\n" +
                                $"格言: \"{motto}\"";

                if (bannerGO != null)
                {
                    Transform bg = bannerGO.transform.Find("BannerBackground");
                    Transform icon = bannerGO.transform.Find("BannerIcon");

                    if (Main.selectedKingdom != null)
                    {
                        var bannerColor = k.kingdomColor;

                        if (bg != null)
                        {
                            Image bgImg = bg.GetComponent<Image>();
                            if (bgImg != null)
                            {
                                bgImg.sprite = k.getElementBackground();
                                bgImg.color = bannerColor.getColorMain2();
                            }
                        }

                        if (icon != null)
                        {
                            Image iconImg = icon.GetComponent<Image>();
                            if (iconImg != null)
                            {
                                iconImg.sprite = k.getElementIcon();
                                iconImg.color = bannerColor.getColorBanner();
                            }
                        }
                    }
                }
            }
        }

        public static void ToggleVisibility()
        {
            if (KingdomDisplay != null)
            {
                bool newState = !KingdomDisplay.activeSelf;
                SetVisibility(newState);
            }
        }

        public static void SetVisibility(bool visible)
        {
            if (KingdomDisplay != null)
            {
                KingdomDisplay.SetActive(visible);
            }
        }
    }
}
