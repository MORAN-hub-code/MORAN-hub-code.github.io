using System;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;


namespace RulerBox
{
    public static class LawSystem
    {
        private static HashSet<string> activeLaws = new HashSet<string>();
        private static int lastKnownPopulation = -1;

        private static readonly string[] localTaxTraits = {
            "tax_rate_tribute_high",
            "tax_rate_tribute_low"
        };

        public static void ApplyLaw(string lawId)
        {
            float cost = GetLawCost(lawId);
            if (Main.selectedKingdom.king?.data.money < cost)
            {
                Debug.Log($"[LawSystem] Not enough gold to apply {lawId}");
                WorldTip.showNow("Not enough gold!", false, "top", 1.5f, "#FF0000");
                return;
            }

            if (activeLaws.Contains(lawId))
            {
                Debug.LogWarning($"[LawSystem] Tried to apply already active law: {lawId}");
                return;
            }

            if (lawId == "law_tax_low" || lawId == "law_tax_medium" || lawId == "law_tax_high")
            {
                var taxLaws = new[] { "law_tax_low", "law_tax_medium", "law_tax_high" };
                foreach (var taxLaw in taxLaws)
                {
                    if (taxLaw != lawId && activeLaws.Contains(taxLaw))
                        RemoveLaw(taxLaw);
                }
            }

            Debug.Log($"[LawSystem] Applying law: {lawId}");
            activeLaws.Add(lawId);


            switch (lawId)
            {
                case "law_tax_low":
                    SetLocalTaxTrait("tax_rate_tribute_low");
                    break;
                case "law_tax_medium":
                    SetLocalTaxTrait(null);
                    break;
                case "law_tax_high":
                    SetLocalTaxTrait("tax_rate_tribute_high");
                    break;
                case "law_freedom_of_speech":
                    break;
                case "law_censorship":
                    break;
                case "law_cultural_festival":
                    break;
                case "law_population_growth":
                    TryMakeBabies();
                    break;
                case "law_population_control":
                    RemoveCitizens();
                    break;
                case "law_mandatory_schooling":
                    GiveGeniusToRandomCitizen(Main.selectedKingdom);
                    break;
                case "law_mandatory_draft":
                    DraftCitizensIntoMilitary();
                    break;
                case "law_military_training":
                    BuffAllWarriors(+1);
                    break;
                case "law_peace_policy":
                    DemilitarizeAndCheer();
                    break;
                case "law_magical_training":
                    TryGrantMagicalTraits();
                    break;
                case "law_arcane_conscription":
                    ArcaneConscription();
                    break;
                case "law_elemental_arms":
                    ApplyElementalArms();
                    break;
                case "law_farm_subsidy":
                    BoostFoodProduction();
                    break;
                case "law_miner_quotas":
                    BoostMiningAtCostOfHappiness();
                    break;
                case "law_crafting_focus":
                    BoostCraftingOutput();
                    break;
                default:
                    Debug.Log($"[LawSystem] No logic implemented for {lawId}");
                    break;
            }
        }

        public static void RemoveLaw(string lawId)
        {
            if (!activeLaws.Contains(lawId))
            {
                Debug.LogWarning($"[LawSystem] Tried to remove inactive law: {lawId}");
                return;
            }

            Debug.Log($"[LawSystem] Removing law: {lawId}");
            activeLaws.Remove(lawId);

            switch (lawId)
            {
                case "law_tax_low":
                case "law_tax_medium":
                case "law_tax_high":
                    SetLocalTaxTrait(null);
                    break;
                case "law_military_training":
                    BuffAllWarriors(-1); 
                    break;
                default:
                    Debug.Log($"[LawSystem] No removal logic implemented for {lawId}");
                    break;
            }
        }

        public static bool IsLawActive(string lawId)
        {
            return activeLaws.Contains(lawId);
        }

        public static IEnumerable<string> GetActiveLaws()
        {
            return activeLaws;
        }

        public static void Reset()
        {
            Debug.Log("[LawSystem] Resetting all active laws.");
            activeLaws.Clear();
        }

        private static float logicCheckTimer = 5f;     
        private static float uiRefreshTimer = 0.7f;

        public static void Update(float deltaTime)
        {
            uiRefreshTimer -= deltaTime;
            if (uiRefreshTimer <= 0f)
            {
                uiRefreshTimer = 0.7f;
                LawsUI.DisplayCategory(LawsUI.currentCategory);
                LawsUI.RefreshHappinessIcon();
                LawsUI.UpdateInfoBox();
            }

            logicCheckTimer -= deltaTime;
            if (logicCheckTimer > 0f) return;
            logicCheckTimer = 5f;

            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            int pop = kingdom.getPopulationPeople();
            float rate = kingdom.getTaxRateTribute();
            int taxIncome = Mathf.RoundToInt(pop * rate);
            Main.selectedKingdom.king.data.money += taxIncome;

            Debug.Log($"[LawSystem] Collected {taxIncome} gold from taxes (pop: {pop}, rate: {rate})");

            if (IsLawActive("law_mandatory_schooling") && pop != lastKnownPopulation && UnityEngine.Random.Range(0f, 100f) < 20f)
            {
                lastKnownPopulation = pop;
                GiveGeniusToRandomCitizen(kingdom);
            }

            if (IsLawActive("law_freedom_of_speech"))
            {
                TryTriggerFreeSpeechRevolt(kingdom);
            }

            if (IsLawActive("law_population_growth"))
            {
                TryMakeBabies();
            }

            if (IsLawActive("law_population_control"))
            {
                RemoveCitizens();
            }


            foreach (var lawId in new List<string>(activeLaws))
            {
                float cost = GetLawCost(lawId);
                int happinessCost = GetLawHappiness(lawId);

                if (Main.selectedKingdom.king.data.money >= cost)
                {
                    Main.selectedKingdom.king.data.money -= (int)cost;
                    Debug.Log($"[LawSystem] Deducted {cost} gold for active law: {lawId}");
                    LawsUI.DisplayCategory(LawsUI.currentCategory);
                    if (happinessCost != 0)
                        ApplyHappinessToAllUnits(lawId, happinessCost);
                }
                else
                {
                    Debug.Log($"[LawSystem] Not enough gold for law: {lawId}, deactivating.");
                    RemoveLaw(lawId);
                    LawsUI.DisplayCategory(LawsUI.currentCategory);
                }
            }
        }

        private static void SetLocalTaxTrait(string traitId)
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var trait in localTaxTraits)
            {
                if (kingdom.hasTrait(trait))
                    kingdom.removeTrait(trait);
            }

            if (!string.IsNullOrEmpty(traitId))
            {
                kingdom.addTrait(traitId);
                Debug.Log($"[LawSystem] Applied local tax trait: {traitId}");
            }
            else
            {
                Debug.Log("[LawSystem] Cleared all local tax traits.");
            }
        }

        private static void ApplyHappinessToAllUnits(string reason, int amount)
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (Actor unit in kingdom.units)
            {
                if (unit == null || !unit.isAlive()) continue;
                unit.changeHappiness("paid_tax", amount);
            }
        }

        private static void TryMakeBabies()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var city in kingdom.cities)
            {
                // Get all eligible units: alive and fertile age range
                var units = city.units.Where(u => u != null && u.isAlive() && u.age >= 18 && u.age <= 45).ToList();
                if (units.Count < 2) continue;

                int births = 0;
                while (births < 2)
                {
                    var parent1 = units[UnityEngine.Random.Range(0, units.Count)];
                    var parent2 = units[UnityEngine.Random.Range(0, units.Count)];

                    if (parent1 == parent2) continue; // avoid self-breeding

                    BabyMaker.makeBaby(parent1, parent2, ActorSex.None, false, 0, null, true, true);
                    births++;
                }
            }

            Debug.Log("[LawSystem] Population growth: babies created.");
        }

        
        private static void RemoveCitizens()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var city in kingdom.cities)
            {
                var candidates = city.units.Where(u => u != null && u.isAlive() && u._profession == UnitProfession.Unit).ToList();

                if (candidates.Count == 0) return;

                var target = candidates[UnityEngine.Random.Range(0, candidates.Count)];
                target.die(false, AttackType.Divine, true, true);
            }
        }


        private static void GiveGeniusToRandomCitizen(Kingdom kingdom)
        {
            var eligible = kingdom.units
                .Where(u => u != null && u.isAlive() && !u.hasTrait("genius"))
                .ToList();

            if (eligible.Count == 0) return;

            var chosen = eligible[UnityEngine.Random.Range(0, eligible.Count)];
            chosen.addTrait("genius", false);
        }

        private static void TryTriggerFreeSpeechRevolt(Kingdom kingdom)
        {
            if (UnityEngine.Random.Range(0f, 100f) > 0.0001f)
                return;

            var cities = kingdom.cities
                .Where(c => c != null && !c.isNeutral() && !c.isCapitalCity() && c.hasLeader())
                .ToList();

            if (cities.Count < 2) return;

            var targetCity = cities[UnityEngine.Random.Range(0, cities.Count)];
            DropsLibrary.action_inspiration(targetCity.getTile());
        }

        private static void DraftCitizensIntoMilitary()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            int drafted = 0;
            foreach (var unit in kingdom.units)
            {
                if (!unit.isAlive()) continue;

                if (!unit.isWarrior())
                {
                    unit.setProfession(UnitProfession.Warrior, true);
                    unit.changeHappiness("paid_tax", -15);
                    drafted++;
                    if (drafted >= 10) break;
                }
            }
        }


        private static void BuffAllWarriors(int amount)
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            int buffed = 0;
            foreach (var unit in kingdom.units)
            {
                if (!unit.isAlive()) continue;

                if (unit.isWarrior())
                {
                    unit.addStatusEffect("rage", 15f, true); 
                    buffed++;
                }
            }
        }


        private static void DemilitarizeAndCheer()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var unit in kingdom.units)
            {
                if (unit.isWarrior() && unit.isAlive())
                {
                    unit.setProfession(UnitProfession.Unit, true);
                    unit.changeHappiness("paid_tax", +15);
                }
            }
        }

        private static void TryGrantMagicalTraits()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            var eligible = kingdom.units
                .Where(u => u.isAlive() && !u.hasTrait("arcane_reflexes") && !u.hasTrait("heart_of_wizard"))
                .OrderBy(_ => UnityEngine.Random.value)
                .Take(2)
                .ToList();

            foreach (var unit in eligible)
            {
                string trait = UnityEngine.Random.value < 0.01f ? "arcane_reflexes" : "heart_of_wizard";
                unit.addTrait(trait);
            }
        }

        private static void ArcaneConscription()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var unit in kingdom.units)
            {
                if (!unit.isAlive()) continue;
                if (!unit.isWarrior() && (unit.hasTrait("arcane_reflexes") || unit.hasTrait("heart_of_wizard")))
                {
                    unit.setProfession(UnitProfession.Warrior, true);
                    unit.changeHappiness("paid_tax", -10);
                }
            }
        }


        private static void ApplyElementalArms()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var unit in kingdom.units)
            {
                if (!unit.isAlive()) continue;
                if (unit.isWarrior() && (UnityEngine.Random.value < 0.1f))
                {
                    if (!unit.hasTrait("fire_proof"))
                        unit.addTrait("fire_proof");
                    if (!unit.hasTrait("resist_cold"))
                        unit.addTrait("resist_cold");
                }
            }
        }

        private static void BoostFoodProduction()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var city in kingdom.cities)
            {
                int foodGiven = UnityEngine.Random.Range(5, 10);
                city.addResourcesToRandomStockpile("bread", foodGiven);
            }
        }

        private static void BoostMiningAtCostOfHappiness()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var city in kingdom.cities)
            {
                int oreGiven = UnityEngine.Random.Range(1, 5);
                city.addResourcesToRandomStockpile("stone", oreGiven);
                city.addResourcesToRandomStockpile("common_metals", oreGiven);
            }

            foreach (var unit in kingdom.units)
            {
                if (unit.isAlive())
                    unit.changeHappiness("paid_tax", -10);
            }
        }

        private static void BoostCraftingOutput()
        {
            var kingdom = Main.selectedKingdom;
            if (kingdom == null) return;

            foreach (var city in kingdom.cities)
            {
                if (city.getEquipmentList(EquipmentType.Weapon).Count < 15)
                {
                    EquipmentAsset item = AssetManager.items.get("wooden_sword");
                    Item weaponItem = World.world.items.generateItem(item, kingdom, World.world.map_stats.player_name, 1, null, 0, true);
                    city.tryToPutItem(weaponItem);
                }
            }
        }

        //Helpers
        private static int GetLawHappiness(string lawId)
        {
            var list = LawsUI.GetAllLaws();
            if (list == null)
                return 0;

            var law = list.FirstOrDefault(l => l.id == lawId);
            if (law == null)
                return 0;

            return law.happiness;
        }


        private static float GetLawCost(string lawId)
        {
            var list = LawsUI.GetAllLaws();
            if (list == null)
                return 0;

            var law = list.FirstOrDefault(l => l.id == lawId);
            if (law == null)
                return 0;

            int pop = Main.selectedKingdom?.getPopulationPeople() ?? 0;

            if (law.scalesWithPopulation)
                return law.cost * pop;

            return law.cost;
        }

    }
}
