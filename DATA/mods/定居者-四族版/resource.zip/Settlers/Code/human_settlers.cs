using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Reflection;
using System.Text;

namespace A
{
    class human_settlers
    {
        public static void init()
        {
            DisasterAsset disasterAsset = new DisasterAsset();
            disasterAsset.id = "human_settlers";
            disasterAsset.rate = 100;
            disasterAsset.chance = 100f;
            disasterAsset.world_log = "Human settlers arrive!";
            disasterAsset.spawn_asset_unit = "human";
            disasterAsset.max_existing_units = 50;
            disasterAsset.units_min = 10;
            disasterAsset.units_max = 20;
            disasterAsset.action = new DisasterAction(AssetManager.disasters.spawnEvilMage);
            AssetManager.disasters.add(disasterAsset);
        }
    }
}
