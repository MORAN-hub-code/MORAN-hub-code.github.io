using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;

namespace A

{
    [ModEntry]
    class Main : MonoBehaviour
    {
        void Awake()
        {
            dwarf_settlers.init();
            elf_settlers.init();
            human_settlers.init();
            orc_settlers.init();
        }
    }
}
