using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using ReflectionUtility;
using System.Reflection;
using HarmonyLib;
using Newtonsoft.Json;
using static Config;
 
namespace AvengersMod
{
    class Buttons
    {
        public static void init()
        {
          
            Tab.createTab("Button Tab_Halalcat", "Tab_Halalcat", "Halalcat", "Avengers", -150);
            loadButtons();
 
        }
        private static void loadButtons()
        {
            PowersTab Tab = getPowersTab("Halalcat");
 
            #region HalalcatButtons
 
            var Avengers = new GodPower();
            Avengers.id = "Avengers";
            Avengers.showSpawnEffect = true;
            Avengers.multiple_spawn_tip = true;
            Avengers.actorSpawnHeight = 3f;
            Avengers.name = "Avengers";
            Avengers.spawnSound = "spawnelf";
            Avengers.actor_asset_id = "SpiderMan";
            Avengers.click_action = new PowerActionWithID(callSpawnUnit);
            AssetManager.powers.add(Avengers);
 
            var buttonAvengers = NCMS.Utils.PowerButtons.CreateButton(
            "Avengers",
            Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_SpiderMan.png"),
            "Avengers",
            "Spwan SpiderMan",
            new Vector2(72, 18),
            ButtonType.GodPower,
            Tab.transform,
             null
             );

      

            var Ironman = new GodPower();
            Ironman.id = "Ironman";
            Ironman.showSpawnEffect = true;
            Ironman.multiple_spawn_tip = true;
            Ironman.actorSpawnHeight = 3f;
            Ironman.name = "Ironman";
            Ironman.spawnSound = "spawnhuman";
            Ironman.actor_asset_id = "Ironman";
            Ironman.click_action = new PowerActionWithID(callSpawnUnit);
            AssetManager.powers.add(Ironman);

            var buttonIronman = NCMS.Utils.PowerButtons.CreateButton(
                "Ironman",
                 Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_Ironman.png"),
                 "Ironman",
                 "Spwan Ironman (I can Fly)",
                 new Vector2(72, -18),
                 ButtonType.GodPower,
                 Tab.transform,
                 null

               

            );

          var CaptainAmerica = new GodPower();
            CaptainAmerica.id = "CaptainAmerica";
            CaptainAmerica.showSpawnEffect = true;
            CaptainAmerica.multiple_spawn_tip = true;
            CaptainAmerica.actorSpawnHeight = 3f;
            CaptainAmerica.name = "CaptainAmerica";
            CaptainAmerica.spawnSound = "spawnhuman";
            CaptainAmerica.actor_asset_id = "CaptainAmerica";
            CaptainAmerica.click_action = new PowerActionWithID(callSpawnUnit);
            AssetManager.powers.add(CaptainAmerica);
 
            var buttonCaptainAmerica = NCMS.Utils.PowerButtons.CreateButton(
            "CaptainAmerica",
            Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_Captain.png"),
            "CaptainAmerica",
            "Spawn Cap",
            new Vector2(144, 18),
            ButtonType.GodPower,
            Tab.transform,
             null
             );

                var BlackPanther = new GodPower();
            BlackPanther.id = "BlackPanther";
            BlackPanther.showSpawnEffect = true;
            BlackPanther.multiple_spawn_tip = true;
            BlackPanther.actorSpawnHeight = 3f;
            BlackPanther.name = "BlackPanther";
            BlackPanther.spawnSound = "spawnhuman";
            BlackPanther.actor_asset_id = "Banner";
            BlackPanther.click_action = new PowerActionWithID(callSpawnUnit);
            AssetManager.powers.add(BlackPanther);
 
            var buttonBlackPanther = NCMS.Utils.PowerButtons.CreateButton(
            "BlackPanther",
            Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_Banner.png"),
            "Banner",
            "Spwan Banner",
            new Vector2(144, -18),
            ButtonType.GodPower,
            Tab.transform,
             null
             );

              var Thor = new GodPower();
            Thor.id = "Thor";
            Thor.showSpawnEffect = true;
            Thor.multiple_spawn_tip = true;
            Thor.actorSpawnHeight = 3f;
            Thor.name = "Thor";
            Thor.spawnSound = "spawnelf";
            Thor.actor_asset_id = "Thor";
            Thor.click_action = new PowerActionWithID(callSpawnUnit);
            AssetManager.powers.add(Thor);
 
            var buttonThor = NCMS.Utils.PowerButtons.CreateButton(
            "Thor",
            Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_Thor.png"),
            "Thor",
            "Spwan Thor",
            new Vector2(108, 18),
            ButtonType.GodPower,
            Tab.transform,
             null
             );

             var Loki = new GodPower();
             Loki.id = "Loki";
             Loki.showSpawnEffect = true;
             Loki.actorSpawnHeight = 3f;
             Loki.multiple_spawn_tip = true;
             Loki.name = "Loki";
             Loki.spawnSound = "spawnelf";
             Loki.actor_asset_id = "Loki";
             Loki.click_action = new PowerActionWithID(callSpawnUnit);
             AssetManager.powers.add(Loki);

             var buttonLoki = NCMS.Utils.PowerButtons.CreateButton(
              "Loki",
              Mod.EmbededResources.LoadSprite($"{Mod.Info.Name}.Resources.Units.ui_Loki.png"),
              "Loki",
              "Spwan Loki",
              new Vector2(235, 18),
              ButtonType.GodPower,
              Tab.transform,
              null

             );
       
 
 
            #endregion
 
		}
		public static bool callSpawnUnit(WorldTile pTile, string pPowerID)
		{
            AssetManager.powers.CallMethod("spawnUnit", pTile, pPowerID);
            return true;
		}
		private static PowersTab getPowersTab(string id)
		{
            GameObject gameObject = GameObjects.FindEvenInactive("Tab_" + id);
            return gameObject.GetComponent<PowersTab>();
		}
    }
}

