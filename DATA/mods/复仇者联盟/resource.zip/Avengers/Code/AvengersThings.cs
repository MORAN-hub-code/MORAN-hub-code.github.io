using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using NCMS.Utils;

namespace AvengersMod
{

    class AvengersThings
    {
        public static void init()
        {

            MakeCraftable();

            ItemAsset CaptainAmericaShield = AssetManager.items.clone("CaptainAmericaShield", "_accessory");
            CaptainAmericaShield.id = "CaptainAmericaShield";
            CaptainAmericaShield.name_templates = List.Of<string>(new string[]{ "amulet_name" });
            CaptainAmericaShield.materials = List.Of<string>(new string[] { "adamantine" });
            CaptainAmericaShield.base_stats[S.damage] = 150;
            CaptainAmericaShield.base_stats[S.attack_speed] = 20;
            CaptainAmericaShield.base_stats[S.speed] = 20f;
            CaptainAmericaShield.base_stats[S.armor] = 999;
            CaptainAmericaShield.base_stats[S.knockback] = 13f;
            CaptainAmericaShield.base_stats[S.knockback_reduction] = 999f;
            CaptainAmericaShield.equipment_value = 1500;
            CaptainAmericaShield.equipmentType = EquipmentType.Amulet;
            CaptainAmericaShield.tech_needed = "weapon_production";
            CaptainAmericaShield.quality = ItemQuality.Legendary;
            AssetManager.items.list.AddItem(CaptainAmericaShield);
            Localization.addLocalization("item_CaptainAmericaShield", "CaptainAmericaShield");

          ItemAsset ThorHammer = AssetManager.items.clone("ThorHammer", "sword");
          ThorHammer.id = "ThorHammer";
          ThorHammer.name_templates = Toolbox.splitStringIntoList(new string[]
          {
          "sword_name#30",
          "sword_name_king#3",
          "weapon_name_city",
          "weapon_name_kingdom",
          "weapon_name_culture",
          "weapon_name_enemy_king",
          "weapon_name_enemy_kingdom"
          });
          ThorHammer.materials = List.Of<string>(new string[]{"adamantine"});
          ThorHammer.base_stats[S.fertility] = 0.0f;
          ThorHammer.base_stats[S.max_children] = 0f;
          ThorHammer.base_stats[S.max_age] = 0f;
          ThorHammer.base_stats[S.attack_speed] = 20;
          ThorHammer.base_stats[S.damage] = 850;
          ThorHammer.base_stats[S.speed] = 20f;
          ThorHammer.base_stats[S.health] = 1500;
          ThorHammer.base_stats[S.accuracy] = 0f;
          ThorHammer.base_stats[S.range] = 15;
          ThorHammer.base_stats[S.armor] = 30;
          ThorHammer.base_stats[S.scale] = 0.05f;
          ThorHammer.base_stats[S.dodge] = 0f;
          ThorHammer.base_stats[S.targets] = 0f;
          ThorHammer.base_stats[S.critical_chance] = 0.0f;
          ThorHammer.base_stats[S.knockback] = 0.7f;
          ThorHammer.base_stats[S.knockback_reduction] = 1.0f;
          ThorHammer.base_stats[S.intelligence] = 0;
          ThorHammer.base_stats[S.warfare] = 20;
          ThorHammer.base_stats[S.diplomacy] = 60;
          ThorHammer.base_stats[S.stewardship] = 100;
          ThorHammer.base_stats[S.opinion] = 50f;
          ThorHammer.base_stats[S.loyalty_traits] = 890f;
          ThorHammer.base_stats[S.cities] = 0;
          ThorHammer.base_stats[S.zone_range] = 122;
          ThorHammer.equipment_value = 1500;
          ThorHammer.quality = ItemQuality.Legendary;
          ThorHammer.path_slash_animation = "effects/slashes/slash_hammer";
          ThorHammer.tech_needed = "weapon_hammer";
          ThorHammer.equipmentType = EquipmentType.Weapon;
          ThorHammer.name_class = "item_class_weapon";
          ThorHammer.action_special_effect = new WorldAction(NoneRegularAction);
          ThorHammer.action_attack_target = new AttackAction(Ham);
          AssetManager.items.list.AddItem(ThorHammer);
          Localization.addLocalization("item_ThorHammer", "To whield the power of thor you must be worthy Thor's Hammer");
          addWeaponsSprite(ThorHammer.id, ThorHammer.materials[0]);

          ItemAsset clintbartonBow = AssetManager.items.clone("clintbartonBow", "bow");
          clintbartonBow.id = "clintbartonBow";
          clintbartonBow.projectile = "arrow";
          clintbartonBow.name_templates = Toolbox.splitStringIntoList(new string[]
          {
          "sword_name#30",
          "sword_name_king#3",
          "weapon_name_city",
          "weapon_name_kingdom",
          "weapon_name_culture",
          "weapon_name_enemy_king",
          "weapon_name_enemy_kingdom"
          });
          clintbartonBow.materials =  List.Of<string>(new string[]{"adamantine"});
          clintbartonBow.base_stats[S.damage] = 200;
          clintbartonBow.base_stats[S.range] = 30;
          clintbartonBow.base_stats[S.attack_speed] = 60;
          clintbartonBow.equipment_value = 1500;
          clintbartonBow.path_slash_animation = "effects/slashes/slash_bow";
          clintbartonBow.quality = ItemQuality.Epic;
          clintbartonBow.action_special_effect = new WorldAction(NoneRegularAction);
          clintbartonBow.action_attack_target = new AttackAction(NoneAttackSomeoneAction);
          clintbartonBow.equipmentType = EquipmentType.Weapon;
          clintbartonBow.tech_needed = "weapon_bow";
          AssetManager.items.list.AddItem(clintbartonBow);
          Localization.addLocalization("item_clintbartonBow", "HawkEye");
          addWeaponsSprite(clintbartonBow.id, clintbartonBow.materials[0]);

          ItemAsset BlackPantherclaw = AssetManager.items.clone("BlackPantherclaw", "sword");
          BlackPantherclaw.id = "BlackPantherclaw";
          BlackPantherclaw.name_templates = Toolbox.splitStringIntoList(new string []
          {
          "sword_name#30",
          "sword_name_king#3",
          "weapon_name_city",
          "weapon_name_kingdom",
          "weapon_name_culture",
          "weapon_name_enemy_king",
          "weapon_name_enemy_kingdom"

          });
          BlackPantherclaw.materials = List.Of<string>(new string[]{"adamantine"});
          BlackPantherclaw.base_stats[S.damage] = 50;
          BlackPantherclaw.base_stats[S.attack_speed] = 99999;
          BlackPantherclaw.base_stats[S.speed] = 20f;
          BlackPantherclaw.base_stats[S.loyalty_traits] = 300f;
          BlackPantherclaw.base_stats[S.health] = 100;
          BlackPantherclaw.base_stats[S.range] = 20;
          BlackPantherclaw.base_stats[S.stewardship] = 200;
          BlackPantherclaw.base_stats[S.warfare] = 203;
          BlackPantherclaw.equipment_value = 1500;
          BlackPantherclaw.path_slash_animation = "effects/slashes/slash_base";
          BlackPantherclaw.quality = ItemQuality.Legendary;
          BlackPantherclaw.equipmentType = EquipmentType.Weapon;
          BlackPantherclaw.tech_needed = "weapon_production";
          AssetManager.items.list.AddItem(BlackPantherclaw);
          Localization.addLocalization("item_BlackPantherclaw", "Wakanda for ever");
          addWeaponsSprite(BlackPantherclaw.id, BlackPantherclaw.materials[0]);

          ItemAsset Spider = AssetManager.items.clone("SpiderManShooter", "bow");
          Spider.id = "SpiderManShooter";
          Spider.projectile = "bone";
          Spider.name_templates = Toolbox.splitStringIntoList(new string []
          {
          "sword_name#30",
          "sword_name_king#3",
          "weapon_name_city",
          "weapon_name_kingdom",
          "weapon_name_culture",
          "weapon_name_enemy_king",
          "weapon_name_enemy_kingdom"


          });
          Spider.materials = List.Of<string>(new string []{"adamantine"});
          Spider.base_stats[S.damage] = 200;
          Spider.base_stats[S.speed] = 15f;
          Spider.base_stats[S.attack_speed] = 23;
          Spider.base_stats[S.accuracy] = 9999f;
          Spider.base_stats[S.range] = 6;
          Spider.equipment_value = 1500;
          Spider.quality = ItemQuality.Epic;
          Spider.path_slash_animation = "effects/slashes/slash_bow";
          Spider.equipmentType = EquipmentType.Weapon;
          Spider.action_special_effect = new WorldAction(SpiderMan);
          Spider.action_attack_target = new AttackAction(addSlonEffectOnTarget);
          Spider.tech_needed = "weapon_bow";
          AssetManager.items.list.AddItem(Spider);
          Localization.addLocalization("item_SpiderManShooter", "pew pew");
          addWeaponsSprite(Spider.id, Spider.materials[0]);

          ItemAsset Tony = AssetManager.items.clone("IronmanWeapon", "sword");
          Tony.id = "IronmanWeapon";
          Tony.name_templates = Toolbox.splitStringIntoList(new string []
          {
            "sword_name#30",
            "sword_name_king#3",
            "weapon_name_city",
            "weapon_name_kingdom",
            "weapon_name_culture",
            "weapon_name_enemy_king",
            "weapon_name_enemy_kingdom"
          });
          Tony.materials = List.Of<string>(new string []{"adamantine"});
          Tony.base_stats[S.damage] = 450;
          Tony.base_stats[S.intelligence] = 9999;
          Tony.base_stats[S.health] = 999;
          Tony.base_stats[S.attack_speed] = 30;
          Tony.base_stats[S.range] = 25;
          Tony.equipment_value = 1500;
          Tony.quality = ItemQuality.Legendary;
          Tony.equipmentType = EquipmentType.Weapon;
          Tony.tech_needed = "weapon_production";
          Tony.path_slash_animation = "effects/slashes/slash_bow";
          Tony.action_attack_target = new AttackAction(Lasen);
          AssetManager.items.list.AddItem(Tony);
          Localization.addLocalization("item_IronmanWeapon", "I AM IRONMAN");
          addWeaponsSprite(Tony.id, Tony.materials[0]);

             ItemAsset ironmanhelmet = AssetManager.items.clone("ironmanhelmet", "_equipment");
          ironmanhelmet.id = "ironmanhelmet";
          ironmanhelmet.base_stats[S.fertility] = 0.0f;
          ironmanhelmet.base_stats[S.max_children] = 0f;
          ironmanhelmet.base_stats[S.max_age] = 0f;
          ironmanhelmet.base_stats[S.attack_speed] = 0;
          ironmanhelmet.base_stats[S.damage] = 200;
          ironmanhelmet.base_stats[S.speed] = 0f;
          ironmanhelmet.base_stats[S.health] = 400;
          ironmanhelmet.base_stats[S.accuracy] = 0f;
          ironmanhelmet.base_stats[S.range] = 0;
          ironmanhelmet.base_stats[S.armor] = 999;
          ironmanhelmet.base_stats[S.scale] = 0.0f;
          ironmanhelmet.base_stats[S.dodge] = 0f;
          ironmanhelmet.base_stats[S.targets] = 0f;
          ironmanhelmet.base_stats[S.critical_chance] = 0.0f;
          ironmanhelmet.base_stats[S.knockback] = 0.0f;
          ironmanhelmet.base_stats[S.knockback_reduction] = 0.0f;
          ironmanhelmet.base_stats[S.intelligence] = 200;
          ironmanhelmet.base_stats[S.warfare] = 999;
          ironmanhelmet.base_stats[S.diplomacy] = 0;
          ironmanhelmet.base_stats[S.stewardship] = 0;
          ironmanhelmet.base_stats[S.opinion] = 0f;
          ironmanhelmet.base_stats[S.loyalty_traits] = 0f;
          ironmanhelmet.base_stats[S.cities] = 0;
          ironmanhelmet.base_stats[S.zone_range] = 0;
          ironmanhelmet.equipmentType = EquipmentType.Helmet;
          ironmanhelmet.name_class = "item_class_armor";
          ironmanhelmet.name_templates = List.Of<string>(new string[]{ "helmet_name" });
          ironmanhelmet.materials = List.Of<string>(new string[]{ "adamantine" });
          ironmanhelmet.tech_needed = "armor_production";
          ironmanhelmet.equipment_value = 1500;
          ironmanhelmet.quality = ItemQuality.Legendary;
          AssetManager.items.list.AddItem(ironmanhelmet);
          Localization.addLocalization("item_ironmanhelmet", "ironman Helmet");

          ItemAsset Iron = AssetManager.items.clone("ironmansuit", "_equipment");
          Iron.id = "ironmansuit";
          Iron.base_stats[S.armor] = 9999;
          Iron.base_stats[S.damage] = 200;
          Iron.base_stats[S.speed] = 20f;
          Iron.equipmentType = EquipmentType.Armor;
          Iron.name_class = "item_class_armor";
          Iron.name_templates = List.Of<string>(new string []{"helmet_name"});
          Iron.materials = List.Of<string>(new string[]{"adamantine"});
          Iron.tech_needed = "armor_production";
          Iron.quality = ItemQuality.Legendary;
          Iron.equipment_value = 1500;
          AssetManager.items.list.AddItem(Iron);
          Localization.addLocalization("item_ironmansuit", "IRON MAN SUIT");

          ItemAsset Lokie = AssetManager.items.clone("Loki_Scepter", "bow");
          Lokie.id = "Loki_Scepter";
          Lokie.projectile = "freeze_orb";
          Lokie.name_templates = Toolbox.splitStringIntoList(new string []
          {
            "bow_name#30",
            "bow_name_king#3",
            "weapon_name_city",
            "weapon_name_kingdom",
            "weapon_name_culture",
            "weapon_name_enemy_king",
            "weapon_name_enemy_kingdom"
          });
          Lokie.materials = List.Of<string>(new string []{"adamantine"});
          Lokie.base_stats[S.damage] = 999;
          Lokie.base_stats[S.health] = 200;
          Lokie.base_stats[S.range] = 20;
          Lokie.base_stats[S.attack_speed] = 15;
          Lokie.base_stats[S.speed] = 20f;
          Lokie.equipmentType = EquipmentType.Weapon;
          Lokie.path_slash_animation = "effects/slashes/slash_bow";
          Lokie.tech_needed = "weapon_bow";
          Lokie.quality = ItemQuality.Legendary;
          Lokie.equipment_value = 25000;
          AssetManager.items.list.AddItem(Lokie);
          Localization.addLocalization("item_Loki_Scepter", "Loki Scepter");
          addWeaponsSprite(Lokie.id, Lokie.materials[0]);



          
          






            
            static void MakeCraftable() {
          Race human = AssetManager.raceLibrary.get("human");
          Race orc = AssetManager.raceLibrary.get("orc");
          Race dwarf = AssetManager.raceLibrary.get("dwarf");
          Race elf = AssetManager.raceLibrary.get("elf");


                
          
          // this is pretty ugly// wewe//wewe 
          human.preferred_weapons.Add("ironmansuit");
          elf.preferred_weapons.Add("ironmansuit");
          orc.preferred_weapons.Add("ironmansuit");
          dwarf.preferred_weapons.Add("ironmansuit");
          elf.preferred_weapons.Add("SpiderManShooter");
          human.preferred_weapons.Add("SpderManShooter");
          orc.preferred_weapons.Add("SpiderManShooter");
          dwarf.preferred_weapons.Add("SpiderManShooter");
          human.preferred_weapons.Add("ironmanhelmet");
          elf.preferred_weapons.Add("ironmanhelmet");
          orc.preferred_weapons.Add("ironmanhelmet");
          dwarf.preferred_weapons.Add("ironmanhelmet");
          human.preferred_weapons.Add("clintbartonBow");
          elf.preferred_weapons.Add("clintbartonBow");
          orc.preferred_weapons.Add("clintbartonBow");
          dwarf.preferred_weapons.Add("clintbartonBow");
          human.preferred_weapons.Add("IronmanWeapon");
          elf.preferred_weapons.Add("IronmanWeapon");
        //  human.preferred_weapons.Add("BlackPantherclaw");
          //elf.preferred_weapons.Add("BlackPantherclaw");
          //orc.preferred_weapons.Add("BlackPantherclaw");
         // dwarf.preferred_weapons.Add("BlackPantherclaw");
          human.preferred_weapons.Add("CaptainAmericaShield");
          elf.preferred_weapons.Add("CaptainAmericaShield");
          orc.preferred_weapons.Add("CaptainAmericaShield");
          dwarf.preferred_weapons.Add("CaptainAmericaShield");
            }





          

             
            



          
        }
        public static bool Ham(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
        if(pTarget != null){
        Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
        if(Toolbox.randomChance(100.0f)){
         MapBox.spawnLightningMedium(pTile, 0.15f);

         World.world.applyForce(pTile, 3, 0.3f, true, true, 0, null, pTarget, null);

          
      

        
        
    

          
          
          
          
        }}
        return false;


            }
        public static bool Lasen(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
        float x = pTile.x;
        float y = pTile.y;
        WorldTile tile = World.world.GetTile((int)x, (int)y);
        if (tile != null){
                     MapAction.damageWorld(tile, 4, AssetManager.terraform.get("crab_laser"), null);

           }
           return true;

               }
        public static bool SpiderMan(BaseSimObject pTarget, WorldTile pTile = null)
        {
        Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
        if(Toolbox.randomChance(0.05f)){
          
         ActionLibrary.teleportRandom(null, pTarget, null);

          
          
          
          
        }
        return false;

        }
        public static bool addSlonEffectOnTarget(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
         {
	if (pTarget.isBuilding())
	{
		return false;
	}
	pTarget.addStatusEffect("Web", -1f);
	return true;




        }
        public static bool NoneAttackSomeoneAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneRegularAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneGetAttackedAction(BaseSimObject pSelf, BaseSimObject pAttackedBy = null, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneDeathAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
    
            




               }
            static void addWeaponsSprite(string id, string material)
            {
              var dictItems = Reflection.GetField(typeof(ActorAnimationLoader), null, "dictItems") as Dictionary<string, Sprite>;
              var sprite = Resources.Load<Sprite>("Weapons/w_" + id + "_" + material);
              dictItems.Add(sprite.name, sprite);



            
            }
        }
    }

