using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;
using System.Threading;
using System.Threading.Tasks;
using System.Text;
using ai;
using ai.behaviours;
using System.IO;
using System.Collections.Generic;
using HarmonyLib;
using Newtonsoft.Json;

namespace AvengersMod
{
    class statuslib
    {
public static void init()
{
    StatusEffect S1 = new StatusEffect();
    S1.id = "Web";
    S1.name = "Web";
    S1.path_icon = "ui/Icons/web";
    S1.duration = 15;
    S1.base_stats[S.speed] = -999999999;
    AssetManager.status.add(S1);
    localizeStatusEffects(S1.id, S1.name, "Sticky");


          }
        public static void localizeStatusEffects(string id, string name, string description)
      	{
      		Dictionary<string, string> localizedText = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "localizedText") as Dictionary<string, string>;
      		localizedText.Add("status_title_" + id, name);
      		localizedText.Add("status_description_" + id, description);


}
    }
}