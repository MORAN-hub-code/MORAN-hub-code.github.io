using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;
 
namespace AvengersMod
{
    class Avengers
    {
        public static void init()
        {


     //
     
     KingdomAsset AvenKingdom = new KingdomAsset();
      AvenKingdom.id = "Aven";
      AvenKingdom.mobs = true;
      AvenKingdom.civ = false;
      AvenKingdom.addTag("Aven");
      AvenKingdom.addTag("human");
       AvenKingdom.addTag("human");
       AvenKingdom.addTag("good");
      AvenKingdom.addFriendlyTag("Aven");
          AvenKingdom.addFriendlyTag("good");
        AvenKingdom.addFriendlyTag("human");
          AvenKingdom.addFriendlyTag("good");
          AvenKingdom.addFriendlyTag("neutral");
         AvenKingdom.addFriendlyTag("neutral");;
         //AvenKingdom.addEnemyTag("civ");
        AvenKingdom.addFriendlyTag("nature_creature");
        AvenKingdom.addFriendlyTag("chicken");
        AvenKingdom.addFriendlyTag("animal");
        AvenKingdom.addFriendlyTag("elf");
        AvenKingdom.addFriendlyTag("dwarf");
        AvenKingdom.addEnemyTag("bandit");
        AvenKingdom.addEnemyTag("SK.bandit");
        AvenKingdom.addEnemyTag("orc");
        AvenKingdom.addEnemyTag("SK.orc");
          AssetManager.kingdoms.add(AvenKingdom);
         MapBox.instance.kingdoms.CallMethod("newHiddenKingdom", AvenKingdom);

         KingdomAsset EviKingdom = new KingdomAsset();
         EviKingdom.id = "Evi";
        EviKingdom.mobs = true;
         EviKingdom.addTag("Evi");
          EviKingdom.addEnemyTag("good");
           EviKingdom.addEnemyTag("SK.animal");
          EviKingdom.addEnemyTag("SK.chicken");
          EviKingdom.addEnemyTag("SK.crocodiles");
          EviKingdom.addEnemyTag("SK.neutral_animals");
          EviKingdom.addEnemyTag("SK.neutral");
          EviKingdom.addEnemyTag("SK.nature_creature");
          EviKingdom.addEnemyTag("SK.nature");
          EviKingdom.addFriendlyTag("orc");
          EviKingdom.addEnemyTag("human");
          EviKingdom.addEnemyTag("SK.human");
          EviKingdom.addEnemyTag("elf");
           EviKingdom.addEnemyTag("SK.elf");
           EviKingdom.addEnemyTag("dwarf");
           EviKingdom.addEnemyTag("SK.dwarf");
           AssetManager.kingdoms.add(EviKingdom);
         MapBox.instance.kingdoms.CallMethod("newHiddenKingdom", EviKingdom);






      create_SpiderMan();
 
        NameGeneratorAsset SpiderManName = new NameGeneratorAsset();
        SpiderManName.id = "SpiderMan";
        SpiderManName.part_groups.Add("SpiderMan");
        SpiderManName.templates.Add("part_group");
        AssetManager.nameGenerator.add(SpiderManName);

       create_Ironman();

        NameGeneratorAsset Ironman = new NameGeneratorAsset();
        Ironman.id = "Ironman";
        Ironman.part_groups.Add("Mark 1, Mark 2, Mark 3, Mark 4, Mark 5, Mark 6, Mark 7, Mark 8, Mark 9, Mark 10, Mark 11, Mark 12, Mark 13, Mark 14, Mark 15, Mark 16, Mark 17, Mark 18, Mark 19, Mark 20, Mark 21, Mark 22, Mark 23, Mark 24, Mark 25, Mark 26, Mark 27, Mark 28, Mark 29, Mark 30, Mark 31, Mark 32, Mark 33, Mark 34, Mark 35, Mark 36, Mark 37, Mark 38, Mark 39, Mark 40, Mark 41, Mark 42, Mark 43, Mark 44, Mark 45, Mark 46, Mark 47, Mark 48, Mark 49, Mark 50, Mark 85");
        Ironman.templates.Add("part_group");
        AssetManager.nameGenerator.add(Ironman);

          create_CaptainAmerica();
 
        NameGeneratorAsset CaptainAmericaName = new NameGeneratorAsset();
        CaptainAmericaName.id = "CaptainAmerica";
        CaptainAmericaName.part_groups.Add("CaptainAmerica");
        CaptainAmericaName.templates.Add("part_group");
        AssetManager.nameGenerator.add(CaptainAmericaName);
 
        create_BlackPanther();
 
        NameGeneratorAsset BlackPanther = new NameGeneratorAsset();
        BlackPanther.id = "BlackPanther";
        BlackPanther.part_groups.Add("BlackPanther");
        BlackPanther.templates.Add("part_group");
        AssetManager.nameGenerator.add(BlackPanther);

         create_Thor();
 
        NameGeneratorAsset ThorName = new NameGeneratorAsset();
        ThorName.id = "Thor";
        ThorName.part_groups.Add("Thor");
        ThorName.templates.Add("part_group");
        AssetManager.nameGenerator.add(ThorName);

        create_Hulk();

        NameGeneratorAsset HulkName = new NameGeneratorAsset();
        HulkName.id = "Hulk";
        HulkName.part_groups.Add("Smash,Ragnarok Hulk,Hulk");
        HulkName.templates.Add("part_group");
        AssetManager.nameGenerator.add(HulkName);

        create_Banner();

        NameGeneratorAsset Banner = new NameGeneratorAsset();
        Banner.id = "Banner";
        Banner.part_groups.Add("DR.Banner");
        Banner.templates.Add("part_group");
        AssetManager.nameGenerator.add(Banner);

        create_Loki();

        NameGeneratorAsset Loki = new NameGeneratorAsset();
        Loki.id = "Loki";
        Loki.part_groups.Add("Loki");
        Loki.templates.Add("part_group");
        AssetManager.nameGenerator.add(Loki);
        
          
        

        
 
                }
            public static void create_Ironman()
           {
              var Ironman = AssetManager.actor_library.clone("Ironman", "_mob");
              Ironman.nameLocale = "Ironman";
             Ironman.nameTemplate = "Ironman";
              Ironman.job = "random_move";
          Ironman.race = "Aven";
              Ironman.kingdom = "Aven";
              Ironman.icon = "ui_Ironman";
              Ironman.animation_swim = "swim_0,swim_1,swim_2";
              Ironman.animation_walk = "walk_0,walk_1,walk_2,walk_3";
             Ironman.texture_path = "Ironman";
              Ironman.defaultAttack = "IronmanWeapon";
          Ironman.has_soul = true;
             Ironman.flying = true;
              Ironman.very_high_flyer = true;
              Ironman.landCreature = true;
              Ironman.needFood = false;
              Ironman.base_stats[S.damage] = 200;
             Ironman.base_stats[S.health] = 900;
              Ironman.base_stats[S.speed] = 20f;
              Ironman.base_stats[S.warfare] = 9999f;
              Ironman.base_stats[S.stewardship] = 9999f;
              Ironman.base_stats[S.armor] = 999;
              Ironman.base_stats[S.attack_speed] = 20;
             AssetManager.actor_library.add(Ironman);
            AssetManager.actor_library.CallMethod("loadShadow", Ironman);
            AssetManager.actor_library.CallMethod("addTrait", "immortal");
           AssetManager.actor_library.CallMethod("addTrait", "Ironman");
            Localization.addLocalization(Ironman.nameLocale, Ironman.nameLocale);

      

             }
         public static void create_BlackPanther()
         {


      var BlackPanther = AssetManager.actor_library.clone("BlackPanther", "_mob");
      BlackPanther.nameLocale = "BlackPanther";
      BlackPanther.nameTemplate = "BlackPanther";
      BlackPanther.job = "random_move";
      BlackPanther.race = "Aven";
      BlackPanther.kingdom = "Aven";
      BlackPanther.icon = "ui_BlackPanther";
      BlackPanther.animation_swim = "swim_0,swim_1";
      BlackPanther.animation_walk = "walk_0,walk_1,walk_2,walk_3";
      BlackPanther.texture_path = "BlackPanther";
      BlackPanther.has_soul = true;
      BlackPanther.landCreature = true;
      BlackPanther.take_items = false;
      BlackPanther.use_items = false;
      BlackPanther.canBeInspected = true;
      BlackPanther.needFood = false;
      BlackPanther.run_to_water_when_on_fire = true;
      BlackPanther.actorSize = ActorSize.S13_Human;
      BlackPanther.action_liquid = new WorldAction(ActionLibrary.swimToIsland);
      BlackPanther.base_stats[S.max_age] = 1f;
      BlackPanther.base_stats[S.health] = 400;
      BlackPanther.base_stats[S.damage] = 234;
      BlackPanther.base_stats[S.speed] = 200f;
      BlackPanther.base_stats[S.armor] = 500;
      BlackPanther.base_stats[S.attack_speed] = 233;
      BlackPanther.base_stats[S.critical_chance] = 0.1f;
      BlackPanther.base_stats[S.knockback] = 0.1f;
      BlackPanther.base_stats[S.knockback_reduction] = 0.1f;
      BlackPanther.base_stats[S.accuracy] = 1f;
      BlackPanther.base_stats[S.range] = 32;
      BlackPanther.base_stats[S.targets] = 1f;
      BlackPanther.base_stats[S.dodge] = 1f;
      AssetManager.actor_library.add(BlackPanther);
      AssetManager.actor_library.CallMethod("loadShadow", BlackPanther);
      Localization.addLocalization(BlackPanther.nameLocale, BlackPanther.nameLocale);
 
    }
          public static void create_Thor()
          {
            var Thor = AssetManager.actor_library.clone("Thor", "_mob");
            Thor.nameLocale = "Thor";
            Thor.nameTemplate = "Thor";
            Thor.job = "random_move";
            Thor.race = "Aven";
            Thor.kingdom = "Aven";
            Thor.skeletonID = "skeleton_cursed";
            Thor.zombieID = "zombie";
            Thor.icon = "ui_Thor";
            Thor.animation_swim = "swim_1,swim_2";
            Thor.animation_walk = "walk_0,walk_1,walk_2,walk_3";
            Thor.texture_path = "Thor";
            Thor.defaultAttack = "ThorHammer";
            Thor.run_to_water_when_on_fire = true;
            Thor.canBeKilledByStuff = true;
            Thor.canBeKilledByLifeEraser = true;
            Thor.canBeMovedByPowers = true;
            Thor.canBeHurtByPowers = true;
            Thor.canTurnIntoZombie = false;
            Thor.canBeInspected = true;
            Thor.hideOnMinimap = false;
            Thor.use_items = false;
            Thor.take_items = false;
            Thor.needFood = false;
            Thor.diet_meat = false;
            Thor.inspect_home = true;
            Thor.disableJumpAnimation = false;
            Thor.has_soul = true;
            Thor.swampCreature = false;
            Thor.oceanCreature = false;
            Thor.landCreature = true;
            Thor.can_turn_into_demon_in_age_of_chaos = false;
            Thor.canTurnIntoIceOne = false;
            Thor.canTurnIntoTumorMonster = false;
            Thor.canTurnIntoMush = false;
            Thor.dieInLava = true;
            Thor.dieOnBlocks = false;
            Thor.dieOnGround = false;
            Thor.dieByLightning = true;
            Thor.damagedByOcean = true;
            Thor.damagedByRain = false;
            Thor.flying = false;
            Thor.very_high_flyer = false;
            Thor.hideFavoriteIcon = false;
            Thor.can_edit_traits = true;
            Thor.canBeKilledByDivineLight = false;
            Thor.ignoredByInfinityCoin = true;
            Thor.actorSize = ActorSize.S13_Human;
            Thor.attack_spells = List.Of<string>(new string[]{"lightning"});
            Thor.action_liquid = new WorldAction(ActionLibrary.swimToIsland);
            Thor.base_stats[S.max_age] = 99999999999f;
            Thor.base_stats[S.health] = 999;
            Thor.base_stats[S.damage] = 900;
            Thor.base_stats[S.speed] = 21f;
            Thor.base_stats[S.armor] = 9999;
            Thor.base_stats[S.attack_speed] = 12;
            Thor.base_stats[S.critical_chance] = 1.1f;
            Thor.base_stats[S.knockback] = 0.1f;
            Thor.base_stats[S.knockback_reduction] = 0.1f;
            Thor.base_stats[S.accuracy] = 1f;
            Thor.base_stats[S.range] = 20;
            Thor.base_stats[S.targets] = 1f;
            Thor.base_stats[S.dodge] = 50f;
            AssetManager.actor_library.add(Thor);
            AssetManager.actor_library.CallMethod("loadShadow", Thor);
            AssetManager.actor_library.CallMethod("addTrait", "immortal");
            AssetManager.actor_library.CallMethod("addTrait", "Thor");
            Localization.addLocalization(Thor.nameLocale, Thor.nameLocale);

          }
          public static void create_Hulk()
          {

            var Hulk = AssetManager.actor_library.clone("Hulk", "_mob");
            Hulk.nameLocale = "Hulk";
            Hulk.nameTemplate = "Hulk";
            Hulk.job = "random_move";
            Hulk.race = "Aven";
            Hulk.kingdom = "Aven";
            Hulk.skeletonID = "skeleton_cursed";
            Hulk.zombieID = "zombie";
            Hulk.icon = "ui_The-Hulk";
            Hulk.animation_walk = "walk_0,walk_1,walk_2,walk_3,walk_4";
            Hulk.animation_swim = "swim_0,swim_1";
            Hulk.texture_path = "Hulk";
            Hulk.run_to_water_when_on_fire = true;
            Hulk.canBeKilledByStuff = true;
            Hulk.canBeKilledByLifeEraser = true;
            Hulk.canBeKilledByDivineLight = false;
            Hulk.canAttackBuildings = true;
            Hulk.landCreature = true;
            Hulk.has_soul = true;
            Hulk.use_items = false;
            Hulk.take_items = false;
            Hulk.actorSize = ActorSize.S13_Human;
            Hulk.base_stats[S.damage] = 999;
            Hulk.base_stats[S.health] = 999;
            AssetManager.actor_library.add(Hulk);
            AssetManager.actor_library.CallMethod("loadShadow", Hulk);
            AssetManager.actor_library.CallMethod("addTrait", "The Hulk");
            Localization.addLocalization(Hulk.nameLocale, Hulk.nameLocale);

          }
          public static void create_CaptainAmerica()
          {

            var CaptainAmerica = AssetManager.actor_library.clone("CaptainAmerica", "_mob");
            CaptainAmerica.nameLocale = "CaptainAmerica";
            CaptainAmerica.nameTemplate = "CaptainAmerica";
            CaptainAmerica.job = "random_move";
            CaptainAmerica.race = "Aven";
            CaptainAmerica.kingdom = "Aven";
            CaptainAmerica.skeletonID = "skeleton_cursed";
            CaptainAmerica.zombieID = "zombie";
            CaptainAmerica.icon = "ui_CaptainAmerica";
            CaptainAmerica.animation_walk = "walk_0,walk_1,walk_2,walk_3";
            CaptainAmerica.animation_swim = "swim_0,swim_1";
            CaptainAmerica.texture_path = "CaptainAmerica";
            CaptainAmerica.run_to_water_when_on_fire = true;
            CaptainAmerica.canBeKilledByStuff = true;
            CaptainAmerica.use_items = false;
            CaptainAmerica.take_items = false;
            CaptainAmerica.has_soul = true;
            CaptainAmerica.landCreature = true;
            CaptainAmerica.needFood = false;
            CaptainAmerica.base_stats[S.damage] = 500;
            CaptainAmerica.base_stats[S.speed] = 20f;
            CaptainAmerica.base_stats[S.health] = 850;
            CaptainAmerica.base_stats[S.attack_speed] = 20;
            CaptainAmerica.base_stats[S.armor] = 9999;
            CaptainAmerica.actorSize = ActorSize.S13_Human;
            AssetManager.actor_library.add(CaptainAmerica);
            AssetManager.actor_library.CallMethod("loadShadow", CaptainAmerica);
            AssetManager.actor_library.CallMethod("addTrait", "");
            Localization.addLocalization(CaptainAmerica.nameLocale, CaptainAmerica.nameLocale);

          }
          public static void create_Banner()
          {

      var Banner = AssetManager.actor_library.clone("Banner", "_mob");
      Banner.nameLocale = "Banner";
      Banner.nameTemplate = "Banner";
      Banner.job = "random_move";
      Banner.race = "Aven";
      Banner.kingdom = "Aven";
      Banner.skeletonID = "skeleton_cursed";
      Banner.zombieID = "zombie";
      Banner.icon = "ui_Banner";
      Banner.animation_walk = "walk_0,walk_1,walk_2,walk_3";
      Banner.animation_swim = "swim_0.swim_1";
      Banner.texture_path = "Banner";
      Banner.run_to_water_when_on_fire = true;
      Banner.has_soul = true;
      Banner.needFood = false;
      Banner.landCreature = true;
      Banner.use_items = false;
      Banner.take_items = false;
      Banner.base_stats[S.max_age] = 100f;          // Humans live around 70-100 years
      Banner.base_stats[S.health] = 100;            // Typical health points for a human
      Banner.base_stats[S.damage] = 50;             // Moderate damage output
      Banner.base_stats[S.speed] = 25f;              // Average human running speed
      Banner.base_stats[S.armor] = 5;               // Basic natural armor (like resistance)
      Banner.base_stats[S.attack_speed] = 1.2f;     // Attack speed for a regular human
      Banner.base_stats[S.critical_chance] = 0.05f; // 5% chance for a critical hit
      Banner.base_stats[S.knockback] = 0.2f;        // Humans can generate some knockback force
      Banner.base_stats[S.knockback_reduction] = 0.1f; // Minimal knockback reduction
      Banner.base_stats[S.accuracy] = 0.8f;            // 80% accuracy rate
      Banner.base_stats[S.range] = 10;                 // Average range for thrown objects or melee
      Banner.base_stats[S.targets] = 1f;               // Can target one opponent at a time
      Banner.base_stats[S.dodge] = 0.1f;               // 10% chance to dodge attacks
      Banner.actorSize = ActorSize.S13_Human;
      AssetManager.actor_library.add(Banner);
      AssetManager.actor_library.CallMethod("loadShadow", Banner);
      AssetManager.actor_library.CallMethod("addTrait", "BANNER");






  }
 
         public static void create_SpiderMan()
          {
            var SpiderMan = AssetManager.actor_library.clone("SpiderMan", "_mob");
            SpiderMan.nameLocale = "SpiderMan";
            SpiderMan.nameTemplate = "SpiderMan";
            SpiderMan.job = "random_move";
            SpiderMan.race = "Aven";
            SpiderMan.kingdom = "Aven";
            SpiderMan.skeletonID = "skeleton_cursed";
            SpiderMan.zombieID = "zombie";
            SpiderMan.icon = "ui_SpiderMan";
            SpiderMan.animation_swim = "swim_0,swim_1,swim_3";
            SpiderMan.animation_walk = "walk_0,walk_1,walk_2,walk_3";
            SpiderMan.texture_path = "SpiderMan";
            SpiderMan.defaultAttack = "SpiderManShooter";
            SpiderMan.run_to_water_when_on_fire = true;
            SpiderMan.canBeKilledByStuff = true;
            SpiderMan.canBeKilledByLifeEraser = true;
            SpiderMan.canBeMovedByPowers = true;//Avengers//
            SpiderMan.canBeHurtByPowers = true;
            SpiderMan.canTurnIntoZombie = false;
            SpiderMan.canBeInspected = true;
            SpiderMan.hideOnMinimap = false;
            SpiderMan.use_items = false;
            SpiderMan.take_items = false;
            SpiderMan.needFood = true;
            SpiderMan.diet_meat = false;
            SpiderMan.inspect_home = true;
            SpiderMan.disableJumpAnimation = false;
            SpiderMan.has_soul = true;
            SpiderMan.swampCreature = false;
            SpiderMan.oceanCreature = false;
            SpiderMan.landCreature = true;
            SpiderMan.can_turn_into_demon_in_age_of_chaos = false;
            SpiderMan.canTurnIntoIceOne = false;
            SpiderMan.canTurnIntoTumorMonster = false;
            SpiderMan.canTurnIntoMush = false;
            SpiderMan.dieInLava = true;
            SpiderMan.dieOnBlocks = false;
            SpiderMan.dieOnGround = false;
            SpiderMan.dieByLightning = true;
            SpiderMan.damagedByOcean = false;
            SpiderMan.damagedByRain = false;
            SpiderMan.flying = false;
            SpiderMan.very_high_flyer = false;
            SpiderMan.hideFavoriteIcon = false;
            SpiderMan.can_edit_traits = true;
            SpiderMan.canBeKilledByDivineLight = false;
            SpiderMan.ignoredByInfinityCoin = false;
            SpiderMan.actorSize = ActorSize.S13_Human;
            SpiderMan.action_liquid = new WorldAction(ActionLibrary.swimToIsland);
            SpiderMan.base_stats[S.max_age] = 1f;
            SpiderMan.base_stats[S.health] = 900;
            SpiderMan.base_stats[S.damage] = 200;
            SpiderMan.base_stats[S.speed] = 15f;
            SpiderMan.base_stats[S.armor] = 999;
            SpiderMan.base_stats[S.attack_speed] = 1;
            SpiderMan.base_stats[S.critical_chance] = 0.1f;
            SpiderMan.base_stats[S.knockback] = 0.12f;
            SpiderMan.base_stats[S.knockback_reduction] = 0.1f;
            SpiderMan.base_stats[S.accuracy] = 1f;
            SpiderMan.base_stats[S.range] = 20;
            SpiderMan.base_stats[S.targets] = 1f;
            SpiderMan.base_stats[S.dodge] = 1f;
            AssetManager.actor_library.add(SpiderMan);
            AssetManager.actor_library.CallMethod("loadShadow", SpiderMan);
            AssetManager.actor_library.CallMethod("addTrait", "immortal");
            AssetManager.actor_library.CallMethod("addTrait", "SpiderMan");
            Localization.addLocalization(SpiderMan.nameLocale, SpiderMan.nameLocale);

          }
         public static void create_Loki()
        {

            var Loki = AssetManager.actor_library.clone("Loki", "bear");
            Loki.nameLocale = "Loki";
            Loki.nameTemplate = "Loki";
            Loki.job = "random_move";
            Loki.kingdom = "demons";
            Loki.race = "demons";
            Loki.skeletonID = "skeleton_cursed";
            Loki.zombieID = "zombie";
            Loki.icon = "ui_Loki";
            Loki.animation_walk = "walk_0,walk_1,walk_2,walk_3";
            Loki.animation_swim = "swim_0,swim_1";
            Loki.texture_path = "Loki";
            Loki.defaultAttack = "Loki_Scepter";
            Loki.use_items = false;
            Loki.take_items = false;
            Loki.needFood = false;
            Loki.has_soul = true;
            Loki.landCreature = true;
            Loki.run_to_water_when_on_fire = true;
            Loki.actorSize = ActorSize.S13_Human;
            Loki.action_liquid = new WorldAction(ActionLibrary.swimToIsland);
            Loki.base_stats[S.damage] = 800;
            Loki.base_stats[S.health] = 2500;
            Loki.base_stats[S.speed] = 20f;
            Loki.base_stats[S.attack_speed] = 10;
            Loki.base_stats[S.critical_chance] = 20;
            Loki.base_stats[S.range] = 15;
            Loki.base_stats[S.targets] = 200f;
            AssetManager.actor_library.add(Loki);
            AssetManager.actor_library.CallMethod("loadShadow", Loki);
            AssetManager.actor_library.CallMethod("addTrait", "immortal");
            AssetManager.actor_library.CallMethod("addTrait", "Loki");
            Localization.addLocalization(Loki.nameLocale, Loki.nameLocale);





      






















    }
 
    }
}