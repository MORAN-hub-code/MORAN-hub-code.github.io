using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using life;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Config;
using System.Reflection;
using UnityEngine.Tilemaps;
using System.IO;
 
namespace AvengersMod
{
    class Traits
    {
        
        public static void init()
        {
 
         ActorTrait TheHulk= new ActorTrait();
         TheHulk.id = "The Hulk";
         TheHulk.path_icon = "ui/Icons/The hulk";
         TheHulk.type = TraitType.Positive;
         TheHulk.group_id = AvengerstraitsGroup.Avengerstraits;
         TheHulk.can_be_cured = false;
         TheHulk.needs_to_be_explored = false;
         TheHulk.can_be_given = true;
         TheHulk.can_be_removed = true;
         TheHulk.opposite = "SpiderMan,Ironman,Thor,BlackPanther,BANNER";
         TheHulk.only_active_on_era_flag = false;
         TheHulk.era_active_night = false;
         TheHulk.era_active_moon = false;
         TheHulk.birth = 0.0f;
         TheHulk.inherit = 0.0f;
         TheHulk.base_stats[S.fertility] = 0.0f;
         TheHulk.base_stats[S.max_children] = 0f;
         TheHulk.base_stats[S.max_age] = 0f;
         TheHulk.base_stats[S.attack_speed] = -23;
         TheHulk.base_stats[S.damage] = 99999;
         TheHulk.base_stats[S.speed] = -30f;
         TheHulk.base_stats[S.health] = 10000;
         TheHulk.base_stats[S.accuracy] = 0f;
         TheHulk.base_stats[S.range] = 0;
         TheHulk.base_stats[S.armor] = 99999;
         TheHulk.base_stats[S.scale] = 0.10f;
         TheHulk.base_stats[S.dodge] = 0f;
         TheHulk.base_stats[S.targets] = 0f;
         TheHulk.base_stats[S.critical_chance] = 0.0f;
         TheHulk.base_stats[S.knockback] = 0.0f;
         TheHulk.base_stats[S.knockback_reduction] = 0.0f;
         TheHulk.base_stats[S.intelligence] = 0;
         TheHulk.base_stats[S.warfare] = 0;
         TheHulk.base_stats[S.diplomacy] = 0;
         TheHulk.base_stats[S.stewardship] = 0;
         TheHulk.base_stats[S.opinion] = 0f;
         TheHulk.base_stats[S.loyalty_traits] = 0f;
         TheHulk.base_stats[S.cities] = 0;
         TheHulk.base_stats[S.zone_range] = 0;
         TheHulk.action_death = new WorldAction(NoneDeathAction);
         TheHulk.action_special_effect = new WorldAction(NoneRegularAction);
         TheHulk.action_attack_target = new AttackAction(NoneAttackSomeoneAction);
         TheHulk.action_get_hit = new GetHitAction(NoneGetAttackedAction);
         AssetManager.traits.add(TheHulk);
         addTraitToLocalizedLibrary(TheHulk.id, "very strong");
         PlayerConfig.unlockTrait("TheHulk");

         ActorTrait Spider = new ActorTrait();
         Spider.id = "SpiderMan";
         Spider.path_icon = "ui/Icons/SpiderMan";
         Spider.group_id = AvengerstraitsGroup.Avengerstraits;
         Spider.type = TraitType.Positive;
         Spider.opposite = "Thor,Ironman,BlackPanther,TheHulk,BANNER";
         Spider.era_active_moon = true;
         Spider.base_stats[S.damage] = 150;
         Spider.base_stats[S.speed] = 15f;
         Spider.base_stats[S.attack_speed] =20;
         //Spider.action_attack_target = new AttackAction(addSlonEffectOnTarget);// DISABLED FOR NOW
         AssetManager.traits.add(Spider);
         addTraitToLocalizedLibrary(Spider.id, "your friendly neighborhood spider-man");

         ActorTrait iron = new ActorTrait();
         iron.id = "Ironman";
         iron.group_id = AvengerstraitsGroup.Avengerstraits;
         iron.type = TraitType.Positive;
         iron.path_icon = "ui/Icons/ui_Ironman";
         iron.opposite = "Thor,BlackPanther,SpiderMan,TheHulk,BANNER";
         iron.needs_to_be_explored = false;
         iron.birth = 0.1f;
         iron.base_stats[S.damage] = 150;
         iron.base_stats[S.armor] = 999;
         iron.base_stats[S.intelligence] = 99999;
         iron.base_stats[S.range] = 20;
         AssetManager.traits.add(iron);
         addTraitToLocalizedLibrary(iron.id, "I AM IRON MAN");

         ActorTrait Thor = new ActorTrait();
         Thor.id = "Thor";
         Thor.group_id = AvengerstraitsGroup.Avengerstraits;
         Thor.path_icon = "ui/Icons/ui_Thor";
         Thor.type = TraitType.Positive;
         Thor.opposite = "BlackPanther,SpiderMan,TheHulk,Ironman,BANNER";
         Thor.base_stats[S.damage] = 200;
         Thor.base_stats[S.speed] = 20f;
         Thor.base_stats[S.attack_speed] = 200;
         Thor.base_stats[S.health] = 999;
         AssetManager.traits.add(Thor);
         addTraitToLocalizedLibrary(Thor.id, "GOD OF THUNDER");

         ActorTrait Black = new ActorTrait();
         Black.id = "BlackPanther";
         Black.group_id = AvengerstraitsGroup.Avengerstraits;
         Black.path_icon= "ui/Icons/ui_BlackPanther";
         Black.type = TraitType.Positive;
         Black.needs_to_be_explored = false;
         Black.opposite = "Thor,Ironman,SpiderMan,TheHulk,BANNER";
         Black.base_stats[S.damage] = 200;
         Black.base_stats[S.speed] = 50f;
         Black.base_stats[S.attack_speed] = 200;
         Black.base_stats[S.health] = 800;
         AssetManager.traits.add(Black);
         addTraitToLocalizedLibrary(Black.id, "WAKANDA FOREVER");

         ActorTrait ActorTrait1 = new ActorTrait();
         ActorTrait1.id = "BANNER";
         ActorTrait1.group_id = AvengerstraitsGroup.Avengerstraits;
         ActorTrait1.path_icon = "ui/Icons/ui_Banner";
         ActorTrait1.type = TraitType.Positive;
         ActorTrait1.needs_to_be_explored = false;
         ActorTrait1.can_be_given = false;
         ActorTrait1.can_be_removed = false;
         ActorTrait1.opposite = "Thor,Ironman,SpderMan";
         ActorTrait1.action_death = new WorldAction(DeathIOITSELF);
         ActorTrait1.base_stats[S.intelligence] = 999f;
         AssetManager.traits.add(ActorTrait1);
         addTraitToLocalizedLibrary(ActorTrait1.id, "DR.BANNER HE JUST NEEDS TO DIE");

         ActorTrait ActorTrait2 = new ActorTrait();
         ActorTrait2.id = "Loki";
         ActorTrait2.group_id = AvengerstraitsGroup.Avengerstraits;
         ActorTrait2.path_icon = "ui/Icons/ui_Loki";
         ActorTrait2.type = TraitType.Positive;
         ActorTrait2.needs_to_be_explored = false;
         ActorTrait2.can_be_given = false;
         ActorTrait2.can_be_removed = false;
         ActorTrait2.base_stats[S.damage] = 20;
         ActorTrait2.base_stats[S.range] = 30;
         AssetManager.traits.add(ActorTrait2);
         addTraitToLocalizedLibrary(ActorTrait2.id, "Loki"); 


         
        }
        public static bool DeathIOITSELF(BaseSimObject pTarget, WorldTile pTile = null)
       {

          Actor a = Reflection.GetField(pTarget.GetType(), pTarget, "a") as Actor;
        if(Toolbox.randomChance(100.0f)){
         World.world.startShake(0.3f, 0.01f, 2f, true, true);
         Actor AvenA4 = World.world.units.createNewUnit("Hulk", pTile, 0f);
        

               }
        return false;
         






 
 
        }
        public static bool NoneAttackSomeoneAction(BaseSimObject pSelf, BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneRegularAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneGetAttackedAction(BaseSimObject pSelf, BaseSimObject pAttackedBy = null, WorldTile pTile = null)
        {
 
             return false;
 
        }
        public static bool NoneDeathAction(BaseSimObject pTarget, WorldTile pTile = null)
        {
 
             return false;
        
 
        }
        public static void addTraitToLocalizedLibrary(string id, string description)
        {
        string language = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
        Dictionary<string, string> localizedText = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "localizedText") as Dictionary<string, string>;
        localizedText.Add("trait_" + id, id);
        localizedText.Add("trait_" + id + "_info", description);
        
        
        }

}
}
