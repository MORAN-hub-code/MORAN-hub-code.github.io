namespace Chinese_Name.constants;

public static class DataS
{
    public const string family_name = "chinese_family_name";
    internal const string family_name_in_template = "family_name";
}