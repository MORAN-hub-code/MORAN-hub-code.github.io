using System;
using NCMS;
using UnityEngine;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine.UI;
using ReflectionUtility;
using HarmonyLib;
using System.Reflection;

namespace KillByDivine
{
    [ModEntry]
    class Main : MonoBehaviour
    {
        public static Main instance;
        public static string mainPath;
        private static bool initialized = false;
        string pastlanguage = "ru";
        string newlanguage = "";

        void Awake()
        {
            if (initialized)
            {
                Debug.LogWarning("[KillByDivine Mod] Main.Awake() already called, skipping initialization.");
                return;
            }

            instance = this;
            mainPath = Application.dataPath;
            GameObject go = new GameObject("KillByDivineTraits");
            DontDestroyOnLoad(go);

            KillByDivineTraits.Initialize();
            Patches.init();

            PatchWorldLawCursed.init();
            //LocalizedTextManager.add("NML_AUTHENTICATION", "Authentication");
            var harmony = new Harmony("com.KillByDivine.mod");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
            Debug.Log("[KillByDivine Mod] Harmony patching applied.");

            initialized = true;
            Debug.Log("[KillByDivine Mod] Main.Awake() completed successfully.");
        }

        void Start()
        {
            
            
        }

        void Update()
        {
            newlanguage = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
            
            if (newlanguage != pastlanguage)
            {
                KillByDivineTraits.Initialize();
            }
            pastlanguage = newlanguage;
        }

        public static class PatchWorldLawCursed
        {
            public static void init()
            {
                var cursedworld = AssetManager.world_laws_library.get("world_law_cursed_world");
                cursedworld.default_state = true;
                Debug.Log("[KillByDivine Mod] PatchWorldLawCursed initialized.");
            }
        }
    }
}