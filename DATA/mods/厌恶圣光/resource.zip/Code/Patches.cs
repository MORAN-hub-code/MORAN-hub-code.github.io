using ReflectionUtility;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using NCMS;
using NCMS.Utils;
using Newtonsoft.Json;
using ai;
using ai.behaviours;
using HarmonyLib;

namespace KillByDivine
{

    class Patches : MonoBehaviour
    {
        //private static MethodInfo goodForNewDockMethod;
        public static Harmony harmony = new Harmony("androlg.mod.worldbox.KillByDivine");
        public static void init()
        {
            //goodForNewDockMethod = AccessTools.Method("OceanHelper:goodForNewDock");

            harmony.Patch(
                AccessTools.Method(typeof(PowerLibrary), "drawDivineLight"),
                prefix: new HarmonyMethod(AccessTools.Method(typeof(Patches), "drawDivineLight_Prefix"))
            );

        }
        
        static bool drawDivineLight_Prefix(PowerLibrary __instance, WorldTile pCenterTile, string pPowerID)
        {
            pCenterTile.doUnits((Action<Actor>) (pActor =>
            {
                __instance.clearBadTraitsFrom(pActor);
                //Subspecies subspecies = pActor.subspecies;//)
                bool fugegehaimen = false;
                if (pActor.subspecies != null)
                    fugegehaimen = true;

                if (fugegehaimen)
                    if (pActor.subspecies.hasMetaTag("kill_by_divine") || pActor.hasTrait("zombie"))
                        pActor.getHit((float)pActor.getMaxHealthPercent(0.4f), true, pAttackType: AttackType.Divine);
                    else if (!fugegehaimen && pActor.asset.can_be_killed_by_divine_light)
                        pActor.getHit((float)pActor.getMaxHealthPercent(0.4f), true, pAttackType: AttackType.Divine);
                    else
                        pActor.startColorEffect();
                pActor.finishStatusEffect("ash_fever");
                pActor.finishAngryStatus();
                if (!pActor.isInLiquid())
                    pActor.cancelAllBeh();
                if (!pActor.hasPlot())
                    return;
                World.world.plots.cancelPlot(pActor.plot);
            }));
            return false;
        }
    }
}