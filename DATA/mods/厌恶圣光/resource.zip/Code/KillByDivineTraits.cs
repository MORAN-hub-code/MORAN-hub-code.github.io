using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using ReflectionUtility;
using NCMS;
using NCMS.Utils;

namespace KillByDivine
{
    [Serializable]
    public class KillByDivineTraits : MonoBehaviour
    {

        public static void Initialize()
        {
            AddKillByDivine();
            //AddLimits();
        }

        private static void AddKillByDivine()
        {
            SubspeciesTrait KillByDivine = new SubspeciesTrait();
            KillByDivine.id = "killbydivine";
            KillByDivine.group_id = "chaos";
            KillByDivine.path_icon = "ui/ws3icons/Impiety";
            KillByDivine.remove_for_zombies = true;
            KillByDivine.rarity = Rarity.R0_Normal;
            KillByDivine.unlocked_with_achievement = false;
            KillByDivine.base_stats_meta = new BaseStats();
            KillByDivine.base_stats_meta.addTag("kill_by_divine");
            AssetManager.subspecies_traits.add(KillByDivine);
            addTraitToLocalizedLibrary("ru", KillByDivine.id, "Нечестивость", "Уязвим к божественному свету");
            addTraitToLocalizedLibrary("en", KillByDivine.id, "Impiety", "Vulnerable to divine light");

            string[] maleficus_species = { "mush_unit" , "skeleton", "jumpy_skull", "demon","zombie"};//,"zombie_animal"};
            foreach (string evilspecies in maleficus_species)
            {
                var species = AssetManager.actor_library.get(evilspecies); 
                
                species.addSubspeciesTrait(KillByDivine.id);
            }
            

        }

        public static void addTraitToLocalizedLibrary(string planguage, string id, string name, string description)
        {
            string language = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "language") as string;
            string templanguage;
            templanguage = language;
            if (templanguage != "ru" && templanguage != "en")
            {
                templanguage = "en";
            }
            if (planguage == templanguage)
            {
                //Dictionary<string, string> localizedText = Reflection.GetField(LocalizedTextManager.instance.GetType(), LocalizedTextManager.instance, "localizedText") as Dictionary<string, string>;
                LocalizedTextManager.add("subspecies_trait_" + id, name);
                LocalizedTextManager.add("subspecies_trait_" + id + "_info", description);
            }
        }
       }
}

